import { world, system } from "@minecraft/server";

//アイテム実行
import { HARUPhone1 } from "./itemrun/haruphone1.js"
import { Advance } from "./itemrun/advance.js"

//ブロック実行
import { Titanium } from "./blockrun/titanium.js"
import { Atm } from "./blockrun/atm.js"
import { Register } from "./blockrun/register.js"

//常時実行
import { systemrun } from "./systemrun.js"

//ダメージ発生時実行
import { entityPOINT } from "./EntityPOINT.js"

//仕事募集を保存する為の設定
var quest = [];

//ブロック
world.beforeEvents.playerInteractWithBlock.subscribe((eventData) =>{
    if(eventData.block.typeId === "addblock:titanium") {
        Titanium(eventData)
    }
    
    if(eventData.block.typeId === "addblock:register") {
        Register(eventData)
    }

    if(eventData.block.typeId === "addblock:atm") {
        Atm(eventData)
    }
}) 

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === "additem:haruphone1"){
        HARUPhone1(eventData)
    }
    if (eventData.itemStack.typeId === "additem:advance"){
        Advance(eventData)
    }
})

//ダメージ
world.afterEvents.entityHurt.subscribe((event) => {
    entityPOINT(event)
})

//常時
system.runInterval(() => {
    systemrun();
})

//初期設定 >>>
 //キルカウントシステム
   const kill_id = ['killcount_zombie','killcount_skeleton','killcount_spider','killcount_creeper','killcount_enderman','killcount_warden','killcount_phantom']
   const kill_id_2 = ['killpoint_zombie','killpoint_skeleton','killpoint_spider','killpoint_creeper','killpoint_enderman','killpoint_warden','killpoint_phantom']
   for (let i = 0; i < kill_id.length; i++){
       if(world.getDynamicProperty(`${kill_id[i]}`)==undefined){
          world.setDynamicProperty(`${kill_id[i]}`,0)
       }
       if(world.getDynamicProperty(`${kill_id_2[i]}`)==undefined){
          world.setDynamicProperty(`${kill_id_2[i]}`,0)
       }
    }
 //管理者HARUPAY
    if(world.getDynamicProperty('harupay_op_money')==undefined){
       world.setDynamicProperty('harupay_op_money',0)
    }
 //QuickSAVE
 if(world.getDynamicProperty('Quick_DataSAVE')==undefined){
    world.setDynamicProperty('Quick_DataSAVE',false)
 }
 //Quick初期化
  if(world.getDynamicProperty('Quick_DataSAVE') == false){
    world.setDynamicProperty("shop_menu",undefined);
  }
 //AppNumber
 if(world.getDynamicProperty('HARUPhone1_AppNumber')==undefined){
   const HARUPhone1_AppNumber = [1,3,4,5,6,7,8,9,10,12,14,11,16]
   world.setDynamicProperty('HARUPhone1_AppNumber',JSON.stringify(HARUPhone1_AppNumber)) 
 }
//<<<

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if(eventData.id === "killcount:off") {
            world.setDynamicProperty('killPointSystem',false) 
        }
        if(eventData.id === "killcount:on") {
            world.setDynamicProperty('killPointSystem',true) 
        }
    })
})
