import { world, system } from '@minecraft/server';

export function FilesAppEngine(CommandData, player) {
    for (let i = 0; i < CommandData.length; i++) {
        const Command = CommandData[i];
        if (!Command || typeof Command !== 'string') {
            continue; // スキップ
        }
        // コマンド実行
        try {
            player.runCommand(Command);
        } catch (error) {
            player.sendMessage(`エラー: ${error}`);
        }
    }
}
