import { world, system } from '@minecraft/server';

export function LiteFrameA(Application_Data, player) {
    //money取得
    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
    const variables = {
        'player.name': player.name,
        'player.x': Math.floor(player.location.x),
        'player.y': Math.floor(player.location.y),
        'player.z': Math.floor(player.location.z),
        'player.dimension': player.dimension.id,
        'harupay.money': score,
    };

    for (let i = 0; i < Application_Data.CommandRunNumber; i++) {
        if (!Application_Data.CommandRunList) continue;
        let command = Application_Data.CommandRunList[i];

        if (typeof command !== 'string') {
            continue;
        }

        // 変数置換
        for (const key in variables) {
            command = command.split(`\${${key}}`).join(String(variables[key]));
        }

        // コマンド実行
        try {
            if (!(command == '' || command == undefined)) {
                player.runCommand(command);
            }
        } catch (error) {
            player.sendMessage(`エラー: ${error}`);
        }

        if (command.includes('haruapps')) {
            system.runTimeout(() => {
                if (!player.hasTag('haruapps')) {
                    player.sendMessage(`§r[§bシステム§r] §cHARUAPPSアドオンが見つかりません`);
                    player.sendMessage(`§a>>>§eHARUAPPSアドオンが有効になっていることを確認してください`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                }
            }, 1);
        }
    }
}
