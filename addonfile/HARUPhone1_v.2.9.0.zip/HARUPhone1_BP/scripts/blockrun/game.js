import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

//設定
import { setting } from '../Game/setting';

//スロット
import { openSlotMachine } from '../Game/slot';
//ハイアンドロー
import { openHighAndLowGame } from '../Game/highandlow';
//ラッキーレター
import { openBetForm } from '../Game/luckyletter';
//ブラックジャック
import { BlackJack } from '../Game/BlackJack';

var player_Cash_Data = {};

export function Game(player) {
    player_Cash_Data[player.id] = {};
    system.run(() => {
        if (!player_Cash_Data[player.id].GameStop) {
            player_Cash_Data[player.id].GameStop = true;
            //ここから実行
            Game_system(player);
            //ここまで
            system.runTimeout(() => {
                player_Cash_Data[player.id].GameStop = false;
            }, 20);
        }
    });
}

export function Game_system(player) {
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    const actions = [];
    var form = new ActionFormData();
    form.title('§1GAME');
    form.body(`§l§b${time}`);
    if (world.getDynamicProperty('LUCKY_LETTER_ENABLED') ?? true) {
        form.button('§1ラッキーレター', 'textures/ui/normalicon1');
        actions.push(() => openBetForm(player));
    }

    if (world.getDynamicProperty('HIGH_AND_LOW_ENABLED') ?? true) {
        form.button('§1ハイアンドロー', 'textures/ui/normalicon1');
        actions.push(() => openHighAndLowGame(player));
    }

    if (world.getDynamicProperty('SLOT_MACHINE_ENABLED') ?? true) {
        form.button('§1スロット', 'textures/ui/normalicon1');
        actions.push(() => openSlotMachine(player));
    }
    if (world.getDynamicProperty('BLACKJACK_ENABLED') ?? true) {
        form.button('§1ブラックジャック', 'textures/ui/normalicon1');
        actions.push(() => BlackJack(player));
    }
    if (player.hasTag('HARUPhoneOP')) {
        form.button('§0管理者設定', 'textures/ui/operatorcontroller');
        actions.push(() => setting(player));
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        actions[r.selection]();
    });
}


let internalSeedCache = null;

const imul = Math.imul;

function mix(h) {
    h ^= h >>> 16;
    h = imul(h, 0x85ebca6b);
    h ^= h >>> 13;
    h = imul(h, 0xc2b2ae35);
    h ^= h >>> 16;
    return h >>> 0;
}

function getGlobalChaos() {
    let chaos = 0;
    for (const p of world.getAllPlayers()) {
        const loc = p.location;
        const rot = p.getRotation();
        const locHash = (loc.x * 59349) ^ (loc.y * 48271) ^ (loc.z * 37199);
        const rotHash = (rot.x * 26183) ^ (rot.y * 19463);
        chaos = (chaos ^ locHash ^ rotHash) >>> 0;
        chaos = (chaos << 5) | (chaos >>> 27);
    }
    return chaos;
}

export function getSecureRandom(player, max) {
    if (internalSeedCache === null) {
        const savedSeed = world.getDynamicProperty('SERVER_HIDDEN_SEED');
        if (typeof savedSeed === 'number') {
            internalSeedCache = savedSeed;
        } else {
            internalSeedCache = Math.floor(Math.random() * 0xffffffff);
        }
    }

    let seed = internalSeedCache;

    const globalChaos = getGlobalChaos();
    const timestamp = Date.now();

    const tick = system.currentTick;

    seed = (seed + globalChaos) >>> 0;
    seed = (seed ^ timestamp) >>> 0;
    seed = (seed + tick) >>> 0;

    const randomVal = mix(seed + (internalSeedCache ^ 0x5deece66d));

    const nextSeed = (internalSeedCache + randomVal + 0x9e3779b9) >>> 0;
    internalSeedCache = nextSeed;

    world.setDynamicProperty('SERVER_HIDDEN_SEED', nextSeed);

    const randomFloat = (randomVal >>> 0) / 4294967296;
    return Math.floor(randomFloat * max);
}