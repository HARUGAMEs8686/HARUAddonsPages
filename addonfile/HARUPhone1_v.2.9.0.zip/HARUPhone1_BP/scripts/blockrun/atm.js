import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

var player_Cash_Data = {};

export function Atm(player) {
    player_Cash_Data[player.id] = {};
    system.run(() => {
        if (!player_Cash_Data[player.id].AtmStop) {
            player_Cash_Data[player.id].AtmStop = true;
            //ここから実行

            //残高取得
            player_Cash_Data[player.id].Myscore_A = world.scoreboard.getObjective('account').getScore(player.scoreboardIdentity);
            if (player_Cash_Data[player.id].Myscore_A == undefined) {
                player_Cash_Data[player.id].Myscore_A = 0;
            }
            player_Cash_Data[player.id].Myscore_B = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

            //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, '0');
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
            var time = `${hours}:${minutes}`;

            var form = new ActionFormData();
            form.title('§4ATM');
            form.body(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}`);
            form.button('§5預け入れ', 'textures/ui/normalicon1');
            form.button('§1引き出し', 'textures/ui/normalicon1');
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ModalFormData();
                        form.title('§4ATM');
                        form.textField(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§r預け入れ金額(半角数字)`, '0');
                        form.show(player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (isNaN(r.formValues[0])) {
                                player.sendMessage(`§r[§bATM§r] §c半角数字で入力してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }

                            //預け入れ金額を保存
                            player_Cash_Data[player.id].selection_money = 0;
                            if (r.formValues[0] == '') {
                                player_Cash_Data[player.id].selection_money = 0;
                            } else {
                                player_Cash_Data[player.id].selection_money = Number(r.formValues[0]);
                            }

                            if (player_Cash_Data[player.id].selection_money > 100000000) {
                                player.sendMessage(`§r[§bATM§r] §c1億以下で設定してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }
                            if (player_Cash_Data[player.id].selection_money < 1) {
                                player.sendMessage(`§r[§bATM§r] §c1未満は設定できません`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }

                            //処理
                            if (player_Cash_Data[player.id].Myscore_B >= player_Cash_Data[player.id].selection_money) {
                                player.runCommand(`scoreboard players add @s account ${player_Cash_Data[player.id].selection_money}`);
                                player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].selection_money}`);
                                player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}PAY§a預け入れました`);
                                player.playSound('haru.notification1', {
                                    pitch: 1.7,
                                    volume: config['Volume'],
                                });
                            } else {
                                player.sendMessage(`§r[§bATM§r] §cMoneyが不足しています`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                            }
                        });
                        break;
                    case 1:
                        var form = new ModalFormData();
                        form.title('§4ATM');
                        form.textField(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§r引き出し金額(半角数字)`, '0');
                        form.show(player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (isNaN(r.formValues[0])) {
                                player.sendMessage(`§r[§bATM§r] §c半角数字で入力してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }

                            //預け入れ金額を保存
                            player_Cash_Data[player.id].selection_money = 0;
                            if (r.formValues[0] == '') {
                                player_Cash_Data[player.id].selection_money = 0;
                            } else {
                                player_Cash_Data[player.id].selection_money = Number(r.formValues[0]);
                            }

                            if (player_Cash_Data[player.id].selection_money > 100000000) {
                                player.sendMessage(`§r[§bATM§r] §c1億以下で設定してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }
                            if (player_Cash_Data[player.id].selection_money < 1) {
                                player.sendMessage(`§r[§bATM§r] §c1未満は設定できません`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }

                            //処理
                            if (player_Cash_Data[player.id].Myscore_A >= player_Cash_Data[player.id].selection_money) {
                                player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].selection_money}`);
                                player.runCommand(`scoreboard players remove @s account ${player_Cash_Data[player.id].selection_money}`);
                                player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}PAY§a引き出しました`);
                                player.playSound('haru.notification1', {
                                    pitch: 1.7,
                                    volume: config['Volume'],
                                });
                            } else {
                                player.sendMessage(`§r[§bATM§r] §cMoneyが不足しています`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                            }
                        });
                        break;
                }
            });
            //ここまで
            system.runTimeout(() => {
                player_Cash_Data[player.id].AtmStop = false;
            }, 20);
        }
    });
}
