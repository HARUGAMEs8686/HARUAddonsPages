import { world, system, BlockInventoryComponent, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

// DynamicPropertiesのプレフィックス
const OWNER_PREFIX = 'penjualan:owner:';
const PRICE_PREFIX = 'penjualan:price:';
const REVENUE_PREFIX = 'penjualan:revenue:';
const DISPLAY_NAME_PREFIX = 'penjualan:displayName:';

// スコアボードの設定
const MONEY_OBJECTIVE = 'money';

// ショップブロックと樽のID
const SHOP_BLOCK = 'addblock:penjualan';
const BARREL_BLOCK = 'minecraft:barrel';

// クールダウン設定（ミリ秒）
const COOLDOWN_MS = 1000;

// プレイヤーのインタラクションクールダウンを管理
const interactionCooldowns = new Map();

// エンチャント情報を文字列として取得
function getEnchantmentString(itemStack) {
    const enchantable = itemStack.getComponent('minecraft:enchantable');
    if (!enchantable) return '';
    const enchantments = enchantable.getEnchantments();
    if (enchantments.length === 0) return '';
    return enchantments
        .map(e => `${e.type.id.replace('minecraft:', '')}${e.level}`)
        .sort()
        .join(',');
}

// エンチャントに基づく一意のキーを作成
function getItemUniqueKey(itemStack) {
    const enchantString = getEnchantmentString(itemStack);
    return enchantString ? `${itemStack.typeId}:${enchantString}` : itemStack.typeId;
}

const DAILY_LIMIT_PREFIX = 'penjualan:salesLimit:';
const LIMIT_PERIOD_PREFIX = 'penjualan:limitPeriod:';
const SALES_COUNT_PREFIX = 'penjualan:salesCount:';
const LAST_RESET_PREFIX = 'penjualan:lastReset:';
const HISTORY_PREFIX = 'penjualan:history:';

// アイテムの表示名を取得（カスタム優先、エンチャント情報含む）
function getItemDisplayName(block, itemStack) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const customName = world.getDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`);
    if (customName) return customName; // カスタム名がある場合はそれだけを表示
    const enchantString = getEnchantmentString(itemStack);
    const baseName = itemStack.typeId.split('minecraft:')[1] || itemStack.typeId;
    return enchantString ? `${baseName} (${enchantString})` : baseName;
}

// 販売上限とリセット日のチェック
function checkDailyLimit(block, itemStack, quantity) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const dailyLimit = Number(world.getDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`)) || 0;
    if (dailyLimit === 0) return true; // 上限未設定なら購入可

    const resetDate = world.getDynamicProperty(`${RESET_DATE_PREFIX}${key}:${uniqueKey}`);
    const currentDate = new Date().toISOString().split('T')[0]; // 今日の日付（YYYY-MM-DD）

    // リセット日が今日より前なら販売数をリセット
    if (resetDate && resetDate < currentDate) {
        world.setDynamicProperty(`${SALES_COUNT_PREFIX}${key}:${uniqueKey}`, 0);
        world.setDynamicProperty(`${RESET_DATE_PREFIX}${key}:${uniqueKey}`, currentDate);
    }

    const salesCount = Number(world.getDynamicProperty(`${SALES_COUNT_PREFIX}${key}:${uniqueKey}`)) || 0;
    if (salesCount + quantity > dailyLimit) {
        return false; // 上限を超える場合は購入不可
    }
    return true;
}

// 販売数を更新
function updateSalesCount(player, block, itemStack, quantity) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const playerKeySuffix = `${key}:${uniqueKey}:${player.id}`;

    const salesCount = Number(world.getDynamicProperty(`${SALES_COUNT_PREFIX}${playerKeySuffix}`)) || 0;
    world.setDynamicProperty(`${SALES_COUNT_PREFIX}${playerKeySuffix}`, salesCount + quantity);
}

// アイテムの価格を取得
function getItemPRICE(block, itemStack) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const customPRICE = Number(world.getDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`));
    return customPRICE || 0;
}

// 座標をキーとして変換（x:y:z形式）
function getLocationKey(location) {
    return `${location.x}:${location.y}:${location.z}`;
}

// プレイヤーのインベントリに空きがあるかチェック
function hasEnoughInventorySpace(player, quantity, itemStack) {
    const inventory = player.getComponent('minecraft:inventory').container;
    let emptySlots = 0;

    for (let i = 0; i < inventory.size; i++) {
        if (!inventory.getItem(i)) {
            emptySlots++;
        }
    }

    // アイテムのスタック上限を考慮して必要なスロット数を計算
    const maxStack = itemStack.maxAmount || 64;
    return emptySlots >= Math.ceil(quantity / maxStack);
}

// 販売上限とリセット期間のチェック
function checkSalesLimit(player, block, itemStack, quantity) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);

    const salesLimit = Number(world.getDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`)) || 0;
    if (salesLimit === 0) return true; // 上限未設定(0)なら無制限
    const limitPeriod = world.getDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`) || '86400000'; // デフォルト1日
    const playerKeySuffix = `${key}:${uniqueKey}:${player.id}`;
    const lastReset = Number(world.getDynamicProperty(`${LAST_RESET_PREFIX}${playerKeySuffix}`)) || 0;
    const now = Date.now();
    if (now - lastReset >= Number(limitPeriod)) {
        world.setDynamicProperty(`${SALES_COUNT_PREFIX}${playerKeySuffix}`, 0);
        world.setDynamicProperty(`${LAST_RESET_PREFIX}${playerKeySuffix}`, now);
    }

    const salesCount = Number(world.getDynamicProperty(`${SALES_COUNT_PREFIX}${playerKeySuffix}`)) || 0;

    if (salesCount + quantity > salesLimit) {
        return false; // 上限を超える場合は購入不可
    }
    return true;
}

// ショップブロックのインタラクト処理
export function registerShopInteractions() {
    // ショップブロックのインタラクト処理
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        const { player, block } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        // キャンセルしてデフォルト動作を防ぐ
        event.cancel = true;

        // クールダウンチェック
        const locationKey = getLocationKey(block.location);
        const playerId = player.id;
        const now = Date.now();
        const cooldownData = interactionCooldowns.get(playerId);

        if (cooldownData && cooldownData.location === locationKey && now - cooldownData.lastInteraction < COOLDOWN_MS) {
            return; // クールダウン中の場合はスキップ
        }

        // クールダウンデータを更新
        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

        system.run(() => {
            handleShopInteraction(player, block);
        });
    });

    // 樽へのインタラクトを制限
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        const { player, block } = event;
        if (block.typeId !== BARREL_BLOCK) return;

        // 樽の1ブロック上に自動販売機があるか確認
        const shopBlock = block.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        // 自動販売機の所有者を取得
        const key = getLocationKey(shopBlock.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        // 所有者でない場合、アクセスをキャンセル（メッセージにクールダウン適用）
        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;

            // クールダウンチェック
            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                // クールダウンデータを更新
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

                system.run(() => {
                    player.sendMessage(`§r[§b自動販売機§r] §cこの樽には設置者しかアクセスできません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                });
            }
        }
    });

    // ブロック設置時に所有者を記録
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(block.location);
        world.setDynamicProperty(`${OWNER_PREFIX}${key}`, player.name);
        world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
    });

    // ブロック破壊時のクリーンアップ（販売上限とリセット日を追加）
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(block.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;
            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                system.run(() => {
                    player.sendMessage(`§r[§b自動販売機§r] §cこの自動販売機は設置者しか破壊できません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                });
            }
            return;
        }

        system.run(() => {
            receiveRevenue_BreakBlock(player, block);
            world.setDynamicProperty(`${OWNER_PREFIX}${key}`, undefined);
            world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, undefined);

            const barrelBlock = block.below();
            if (barrelBlock && barrelBlock.typeId === BARREL_BLOCK) {
                const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
                if (inventoryComponent && inventoryComponent.container) {
                    const items = getInventoryItems(inventoryComponent.container);
                    items.forEach(item => {
                        const uniqueKey = getItemUniqueKey(item.itemStack);
                        world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${SALES_COUNT_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${LAST_RESET_PREFIX}${key}:${uniqueKey}`, undefined);
                    });
                }
            }
        });
    });

    world.beforeEvents.explosion.subscribe(event => {
        // 爆発で影響を受けるブロックのリストを取得
        const impactedBlocks = event.getImpactedBlocks();
        const dimension = event.dimension;

        // 保護対象のブロック（自動販売機と下の樽）を爆発リストから除外する
        const newImpactedBlocks = impactedBlocks.filter(blockLocation => {
            try {
                const block = dimension.getBlock(blockLocation);
                if (!block) return true; // ブロックが取得できなければ破壊対象のまま

                // 1. ブロックが自動販売機の場合
                if (block.typeId === SHOP_BLOCK) {
                    const key = getLocationKey(block.location);
                    // 所有者情報があれば保護対象
                    if (world.getDynamicProperty(`${OWNER_PREFIX}${key}`)) {
                        return false; // 破壊リストから除外
                    }
                }

                // 2. ブロックが樽の場合
                if (block.typeId === BARREL_BLOCK) {
                    const shopBlock = block.above();
                    // 真上のブロックが自動販売機かチェック
                    if (shopBlock && shopBlock.typeId === SHOP_BLOCK) {
                        const key = getLocationKey(shopBlock.location);
                        // その自動販売機に所有者情報があれば、この樽は保護対象
                        if (world.getDynamicProperty(`${OWNER_PREFIX}${key}`)) {
                            return false; // 破壊リストから除外
                        }
                    }
                }

                // 保護対象でなければ破壊リストに残す
                return true;
            } catch (e) {
                // エラーが発生した場合は、念のため破壊対象のままにする
                console.warn(`[自動販売機] 爆発保護チェック中にエラー: ${e}`);
                return true;
            }
        });

        // 更新された破壊リストをイベントに設定
        event.setImpactedBlocks(newImpactedBlocks);
    });

    // 収益受け取り
    async function receiveRevenue_BreakBlock(player, block) {
        const key = getLocationKey(block.location);
        const revenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
        if (revenue === 0) {
            return;
        }

        const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
        if (!objective) {
            player.sendMessage(`§r[§b自動販売機§r] §cスコアボード 'money' が見つかりません`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            return;
        }

        objective.addScore(player, revenue);
        world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
        player.sendMessage(`§r[§b自動販売機§r] §a売上§c${revenue}§aを回収し、データを初期化しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
    }

    // 設置者以外による樽の破壊を防ぐ
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== BARREL_BLOCK) return;

        // 樽の1ブロック上に自動販売機があるか確認
        const shopBlock = block.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        // 自動販売機の所有者を取得
        const key = getLocationKey(shopBlock.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;

            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

                system.run(() => {
                    player.sendMessage(`§r[§b自動販売機§r] §cこの樽は設置者しか破壊できません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                });
            }
        }
    });

    // 樽の下にホッパーを置けないようにする
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== 'minecraft:hopper') return;

        // ホッパーの上に樽があるか確認
        const barrelBlock = block.above();
        if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) return;

        // さらにその上に自動販売機があるか確認
        const shopBlock = barrelBlock.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        // 自販機と関連する樽の下にホッパーが置かれたので、ブロックを破壊
        block.setType('minecraft:air');

        // クールダウンチェック
        const locationKey = getLocationKey(block.location);
        const playerId = player.id;
        const now = Date.now();
        const cooldownData = interactionCooldowns.get(playerId);

        if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
            // クールダウンデータを更新
            interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

            system.run(() => {
                player.sendMessage(`§r[§b自動販売機§r] §cホッパーは樽の下に置けません`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
            });
        }
    });

    // 自販機と樽の周りにピストンや粘着ピストンを置けないようにする（2ブロック範囲）
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        const restrictedBlocks = ['minecraft:piston', 'minecraft:sticky_piston'];
        if (!restrictedBlocks.includes(block.typeId)) return;

        // 2ブロック範囲をチェック（X, Y, Z軸で-2から+2）
        const directions = [];
        for (let x = -2; x <= 2; x++) {
            for (let y = -2; y <= 2; y++) {
                for (let z = -2; z <= 2; z++) {
                    // 軸方向（X, Y, Z のいずれかが 0 でない、かつ斜め方向は除外）
                    if ((x === 0 && y === 0 && z === 0) || (x !== 0 && y !== 0) || (x !== 0 && z !== 0) || (y !== 0 && z !== 0)) continue;
                    directions.push({ x, y, z });
                }
            }
        }

        for (const dir of directions) {
            const checkLocation = {
                x: block.location.x + dir.x,
                y: block.location.y + dir.y,
                z: block.location.z + dir.z,
            };
            const adjacentBlock = block.dimension.getBlock(checkLocation);

            if (!adjacentBlock) continue;

            // 自販機ブロックかチェック
            if (adjacentBlock.typeId === SHOP_BLOCK) {
                block.setType('minecraft:air');

                // クールダウンチェック
                const locationKey = getLocationKey(block.location);
                const playerId = player.id;
                const now = Date.now();
                const cooldownData = interactionCooldowns.get(playerId);

                if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                    // クールダウンデータを更新
                    interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

                    system.run(() => {
                        player.sendMessage(`§r[§b自動販売機§r] §c自動販売機の周りにピストンは置けません`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                    });
                }
                return;
            }

            // 隣接ブロックが樽で、その上に自販機があるかチェック
            if (adjacentBlock.typeId === BARREL_BLOCK) {
                const shopBlock = adjacentBlock.above();
                if (shopBlock && shopBlock.typeId === SHOP_BLOCK) {
                    block.setType('minecraft:air');

                    // クールダウンチェック
                    const locationKey = getLocationKey(block.location);
                    const playerId = player.id;
                    const now = Date.now();
                    const cooldownData = interactionCooldowns.get(playerId);

                    if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                        // クールダウンデータを更新
                        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

                        system.run(() => {
                            player.sendMessage(`§r[§b自動販売機§r] §c自動販売機の樽の周りにピストンは置けません`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                        });
                    }
                    return;
                }
            }
        }
    });
}

// ショップのインタラクト処理
export async function handleShopInteraction(player, block, blockLocation) {
    let targetBlock;

    // blockが有効かチェック
    if (!block || !block) {
        // blockが無効な場合、Textの座標を使う
        try {
            const dimension = player.dimension;
            targetBlock = dimension.getBlock(blockLocation);

            if (!targetBlock || !targetBlock) {
                player.sendMessage(`§r[§b自動販売機§r] §c指定された座標のブロックを取得できませんでした: ${blockLocation.x}${blockLocation.y}${blockLocation.y}`);
                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                return;
            }
        } catch (error) {
            player.sendMessage(`§r[§b自動販売機§r] §c座標処理エラー: ${error.message}`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }
    } else {
        // blockが有効ならそのまま使う
        targetBlock = block;
    }

    const key = getLocationKey(targetBlock.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);
    const isOwner = ownerName === player.name;

    // 1ブロック下の樽を取得
    const barrelBlock = targetBlock.below();
    if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) {
        player.sendMessage(`§r[§b自動販売機§r] §c下に樽が必要です`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    // 樽のインベントリを取得
    const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
    if (!inventoryComponent || !inventoryComponent.container) {
        player.sendMessage(`§r[§b自動販売機§r] §c樽のインベントリを取得できませんでした`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }
    const inventory = inventoryComponent.container;

    if (isOwner) {
        // 設置者向けUIを表示
        await showOwnerMenu(player, targetBlock, inventory);
    } else {
        // 一般プレイヤー向け購入UIを表示
        await showBuyMenu(player, targetBlock, inventory);
    }
}

// 設置者向けメニュー
async function showOwnerMenu(player, block, inventory) {
    const form = new ActionFormData().title('§1自動販売機 §0(販売者)').body('>>> §e選択してください').button('§1商品カスタマイズ', 'textures/ui/normalicon1').button('§5購入履歴', 'textures/ui/normalicon1').button('§4売り上げ受け取り', 'textures/ui/pay').button('§9購入画面を表示', `textures/blocks/penjualan`);
    const response = await form.show(player);
    if (response.canceled) return;

    switch (response.selection) {
        case 0:
            await showPriceSettingMenu(player, block, inventory);
            break;
        case 1:
            await showPurchaseHistoryMenu(player, block);
            break;
        case 2:
            await receiveRevenue(player, block);
            break;
        case 3:
            await showBuyMenu(player, block, inventory);
            break;
    }
}

// 価格設定メニュー
async function showPriceSettingMenu(player, block, inventory) {
    const items = getInventoryItems(inventory);
    if (items.length === 0) {
        player.sendMessage(`§r[§b自動販売機§r] §c商品がありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    const selectionForm = new ActionFormData().title('§1商品カスタマイズ').body('>>> §eカスタマイズする商品を選択');
    selectionForm.button(`§l戻る`, 'textures/ui/icon_import.png');
    items.forEach(item => {
        const price = getItemPRICE(block, item.itemStack);
        selectionForm.button(`§1${getItemDisplayName(block, item.itemStack)} (${item.amount}) §5- §4${price}`, 'textures/ui/normalicon1');
    });

    const selectionResponse = await selectionForm.show(player);
    if (selectionResponse.canceled || selectionResponse.selection === undefined) return;

    if (selectionResponse.selection == 0) {
        await showOwnerMenu(player, block, inventory);
        return;
    }
    // 選択されたアイテムを取得
    const selectedItem = items[selectionResponse.selection - 1];

    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(selectedItem.itemStack);

    // 現在の設定値を取得
    const currentPrice = world.getDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`) || '';
    const currentDisplayName = world.getDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`) || '';
    const currentSalesLimit = world.getDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`) || 0;
    const currentPeriod = world.getDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`) || '86400000';
    const periods = ['3600000', '43200000', '86400000', '259200000', '604800000'];
    const periodLabels = ['1時間', '12時間', '1日', '3日', '7日'];
    const defaultPeriodIndex = periods.indexOf(currentPeriod) !== -1 ? periods.indexOf(currentPeriod) : 2;

    const form = new ModalFormData()
        .title(`§1${getItemDisplayName(block, selectedItem.itemStack)} の設定`)
        .textField('§a価格 §b(数値) §5- §e1個あたり', '例:10', {
            defaultValue: String(currentPrice),
        })
        .textField('§a表示名', '例:ダイヤモンド', {
            defaultValue: String(currentDisplayName),
        })
        .textField('§a販売上限 §b(整数, 0で無制限)', '例:100', {
            defaultValue: String(currentSalesLimit),
        })
        .dropdown('§a上限リセット期間', periodLabels, {
            defaultValueIndex: defaultPeriodIndex,
        });

    const response = await form.show(player);
    if (response.canceled || !response.formValues) {
        await showPriceSettingMenu(player, block, inventory);
        return;
    }

    const price = response.formValues[0];
    const displayName = response.formValues[1];

    let salesLimit = response.formValues[2];
    if (salesLimit === '') {
        salesLimit = '0';
    }

    const periodIndex = response.formValues[3];

    // バリデーション
    if (price !== '' && (isNaN(price) || price < 0)) {
        player.sendMessage(`§r[§b自動販売機§r] §c無効な価格です`);
        return;
    }

    if (isNaN(salesLimit) || Number(salesLimit) < 0) {
        player.sendMessage(`§r[§b自動販売機§r] §c無効な販売上限です`);
        return;
    }

    // 表示名設定
    if (displayName !== '') {
        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, displayName);
        player.sendMessage(`§r[§b自動販売機§r] §a表示名§r:§b${displayName}§aに設定しました`);
    } else {
        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, undefined);
    }

    // 価格設定
    if (price !== '') {
        world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, price);
        player.sendMessage(`§r[§b自動販売機§r] §a価格§r:§c${price} §aに設定しました`);
    }

    // 販売上限設定 (常に保存するように変更)
    world.setDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`, salesLimit);
    if (Number(salesLimit) === 0) {
        player.sendMessage(`§r[§b自動販売機§r] §a販売上限§r:§c無制限 §aに設定しました`);
    } else {
        player.sendMessage(`§r[§b自動販売機§r] §a販売上限§r:§c${salesLimit} §aに設定しました`);
    }

    // リセット期間設定
    const selectedPeriod = periods[periodIndex];
    const selectedPeriodLabel = periodLabels[periodIndex];
    if (currentPeriod !== selectedPeriod) {
        world.setDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`, selectedPeriod);
        player.sendMessage(`§r[§b自動販売機§r] §aリセット期間§r:§c${selectedPeriodLabel} §aに設定しました`);
    }

    player.playSound('haru.notification1', {
        pitch: 1.7,
        volume: config['Volume'],
    });
}

// 購入履歴表示メニュー
async function showPurchaseHistoryMenu(player, block) {
    const key = getLocationKey(block.location);
    let history = [];

    try {
        const rawHistory = world.getDynamicProperty(`${HISTORY_PREFIX}${key}`);
        if (rawHistory) {
            history = JSON.parse(rawHistory);
        }
    } catch (e) {}

    let bodyText = '';

    if (history.length === 0) {
        bodyText = '§7購入履歴はありません';
    } else {
        // 履歴をフォーマットして表示
        bodyText = history.map(h => `§e[${h.time}] §b${h.buyer}\n§r商品名: ${h.item} §a(x${h.amount})`).join('\n\n');
    }

    const form = new ActionFormData().title('§1購入履歴 (最新20件)').body(bodyText).button('§l戻る', 'textures/ui/icon_import.png');

    const response = await form.show(player);

    // 戻るボタンが押されたらオーナーメニューに戻る
    if (!response.canceled && response.selection === 0) {
        // インベントリが必要なので取得しなおす
        const barrelBlock = block.below();
        if (barrelBlock && barrelBlock.typeId === BARREL_BLOCK) {
            const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
            if (inventoryComponent) {
                await showOwnerMenu(player, block, inventoryComponent.container);
            }
        }
    }
}

// 購入確認メニュー
async function showConfirmPurchaseMenu(player, block, inventory, selectedItem, price, quantity) {
    const totalCost = Math.round(price * quantity);
    const form = new ActionFormData()
        .title('§1購入確認')
        .body(`商品詳細`)
        .divider()
        .label(`§a商品: §b${getItemDisplayName(block, selectedItem.itemStack)}\n§a数量: §e${quantity}個\n§a合計金額: §c${totalCost}`)
        .divider()
        .label(`>>> §e購入しますか？`)
        .button('§1購入する')
        .button('§4キャンセル');

    const response = await form.show(player);
    if (response.canceled || response.selection !== 0) {
        return;
    }

    // 販売上限チェック
    if (!checkSalesLimit(player, block, selectedItem.itemStack, quantity)) {
        const key = getLocationKey(block.location);
        const uniqueKey = getItemUniqueKey(selectedItem.itemStack);
        const playerKeySuffix = `${key}:${uniqueKey}:${player.id}`;
        const salesCount = Number(world.getDynamicProperty(`${SALES_COUNT_PREFIX}${playerKeySuffix}`)) || 0;

        // 設定されている上限数を取得
        const salesLimit = Number(world.getDynamicProperty(`${DAILY_LIMIT_PREFIX}${key}:${uniqueKey}`)) || 0;

        const remaining = salesLimit - salesCount;

        player.sendMessage(`§r[§b自動販売機§r] §c購入上限に達しているため、その数量は購入できません`);
        if (remaining > 0) {
            player.sendMessage(`>>> §aこの商品の残り購入可能数は §e${remaining}個§a です`);
        } else {
            player.sendMessage(`>>> §eこの商品を追加で購入することはできません`);
        }

        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) {
        player.sendMessage(`§r[§b自動販売機§r] §cスコアボード 'money' が見つかりません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    const playerMoney = objective.getScore(player) || 0;
    if (playerMoney < totalCost) {
        player.sendMessage(`§r[§b自動販売機§r] §cMoneyが不足しています`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    // インベントリ空きチェック
    if (!hasEnoughInventorySpace(player, quantity, selectedItem.itemStack)) {
        player.sendMessage(`§r[§b自動販売機§r] §cインベントリに空きがありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    // 在庫から指定数量を減らし、アイテムスタックを取得
    const itemStacks = await reduceInventory(inventory, selectedItem.itemStack, quantity);
    if (!itemStacks || itemStacks.length === 0) {
        player.sendMessage(`§r[§b自動販売機§r] §c在庫の更新に失敗しました`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    // プレイヤーにアイテムを付与（NBTデータを保持）
    const playerInventory = player.getComponent('minecraft:inventory').container;
    itemStacks.forEach(stack => {
        playerInventory.addItem(stack);
    });

    // 所持金を減らし、売り上げを加算
    objective.setScore(player, playerMoney - totalCost);
    const key = getLocationKey(block.location);
    const currentRevenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
    world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, currentRevenue + totalCost);

    // 販売数を更新
    updateSalesCount(player, block, selectedItem.itemStack, quantity);

    // ここから購入履歴の保存処理
    const historyKey = `${HISTORY_PREFIX}${key}`;
    let history = [];
    try {
        const rawHistory = world.getDynamicProperty(historyKey);
        if (rawHistory) {
            history = JSON.parse(rawHistory);
        }
    } catch (e) {
        console.warn('History parse error', e);
    }

    const now = new Date();
    const timeOffset = world.getDynamicProperty('Time_Setting') !== undefined ? world.getDynamicProperty('Time_Setting') : 9;
    const japanTime = new Date(now.getTime() + timeOffset * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const day = String(japanTime.getUTCDate()).padStart(2, '0');
    const timeString = `${month}/${day} ${hours}:${minutes}`;

    history.unshift({
        buyer: player.name,
        item: getItemDisplayName(block, selectedItem.itemStack),
        amount: quantity,
        time: timeString,
    });
    if (history.length > 20) {
        history = history.slice(0, 20);
    }

    // 保存
    world.setDynamicProperty(historyKey, JSON.stringify(history));

    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);
    const players = world.getAllPlayers();
    for (const player2 of players) {
        if (player2.name == ownerName) {
            player2.sendMessage(`§r[§b自動販売機§r] §b${player.name}§aが§b${getItemDisplayName(block, selectedItem.itemStack)}§aを§e${quantity}個 §a購入しました`);
            player2.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
        }
    }
    player.sendMessage(`§r[§b自動販売機§r] §b${getItemDisplayName(block, selectedItem.itemStack)}§aを§e${quantity}個 §c${totalCost}§aで購入しました`);
    player.playSound('haru.notification1', {
        pitch: 1.7,
        volume: config['Volume'],
    });
}

// 売り上げ受け取り
async function receiveRevenue(player, block) {
    const key = getLocationKey(block.location);
    const revenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
    if (revenue === 0) {
        player.sendMessage(`§r[§b自動販売機§r] §a現在売り上げはありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) {
        player.sendMessage(`§r[§b自動販売機§r] §cスコアボード 'money' が見つかりません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    objective.addScore(player, revenue);
    world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
    player.sendMessage(`§r[§b自動販売機§r] §c${revenue}§aの売り上げを受け取りました`);
    player.playSound('haru.notification1', {
        pitch: 1.7,
        volume: config['Volume'],
    });
}

// 購入メニュー
async function showBuyMenu(player, block, inventory) {
    const items = getInventoryItems(inventory);
    if (items.length === 0) {
        player.sendMessage(`§r[§b自動販売機§r] §c商品がありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    const key = getLocationKey(block.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`) || '不明';
    const form = new ActionFormData().title('§1自動販売機').body(`販売者:§a${ownerName}`).divider();

    const prices = items.map(item => world.getDynamicProperty(`${PRICE_PREFIX}${key}:${getItemUniqueKey(item.itemStack)}`) || 0);
    items.forEach((item, index) => {
        form.button(`§1${getItemDisplayName(block, item.itemStack)} (${item.amount}) §51個§r:§c${prices[index]}`, 'textures/ui/normalicon1');
    });

    const response = await form.show(player);
    if (response.canceled || response.selection == null) return;

    const selectedItem = items[response.selection];
    const price = prices[response.selection];
    await showQuantitySelectionMenu(player, block, inventory, selectedItem, price);
}

// 数量選択メニュー
// 数量選択メニュー（確認画面へ進む）
async function showQuantitySelectionMenu(player, block, inventory, selectedItem, price) {
    const form = new ModalFormData().title('§1数量選択').textField(`§a購入する数量 §r(§b1~${selectedItem.amount}§r)`, '半角整数');

    const response = await form.show(player);
    if (response.canceled || !response.formValues) return;

    const quantity = parseInt(response.formValues[0]);
    if (isNaN(quantity) || quantity <= 0) {
        player.sendMessage(`§r[§b自動販売機§r] §c数量は正の整数で入力してください`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }
    if (quantity > selectedItem.amount) {
        player.sendMessage(`§r[§b自動販売機§r] §c在庫§a（${selectedItem.amount}個）§4を超える数量です`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    if (quantity >= 1000) {
        player.sendMessage(`§r[§b自動販売機§r] §c1000以上の数量は購入できません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }

    // 確認画面を表示
    await showConfirmPurchaseMenu(player, block, inventory, selectedItem, price, quantity);
}

// 在庫から指定数量を減らす（NBTデータを保持、スタック上限を考慮）
async function reduceInventory(inventory, targetItemStack, quantity) {
    let remaining = quantity;
    const itemStacks = [];
    const targetUniqueKey = getItemUniqueKey(targetItemStack);

    for (let i = 0; i < inventory.size && remaining > 0; i++) {
        const item = inventory.getItem(i);
        if (item && getItemUniqueKey(item) === targetUniqueKey) {
            const maxStack = item.maxAmount || 64;

            if (item.amount <= remaining) {
                const stack = item.clone();
                stack.amount = item.amount;
                itemStacks.push(stack);
                remaining -= item.amount;
                inventory.setItem(i, undefined);
            } else {
                const stack = item.clone();
                stack.amount = remaining;
                itemStacks.push(stack);
                item.amount -= remaining;
                inventory.setItem(i, item);
                remaining = 0;
            }
        }
    }

    return remaining === 0 ? itemStacks : null;
}

// インベントリからアイテムリストを取得（エンチャントデータに基づいてグループ化）
function getInventoryItems(inventory) {
    const itemMap = new Map();

    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) {
            const uniqueKey = getItemUniqueKey(item);
            const current = itemMap.get(uniqueKey) || { typeId: item.typeId, amount: 0, itemStack: item };
            itemMap.set(uniqueKey, {
                typeId: item.typeId,
                amount: current.amount + item.amount,
                itemStack: current.itemStack,
            });
        }
    }

    return Array.from(itemMap.values());
}

// 特定のアイテムのスロットを探す（エンチャントデータ考慮）
function findItemSlot(inventory, itemStack) {
    const targetUniqueKey = getItemUniqueKey(itemStack);
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item && getItemUniqueKey(item) === targetUniqueKey) {
            return i;
        }
    }
    return -1;
}

//Command実行
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        let Penjualan_Command = [];
        if (world.getDynamicProperty('Penjualan_Command') != undefined) {
            Penjualan_Command = JSON.parse(world.getDynamicProperty('Penjualan_Command'));
        }

        for (let i = 0; i < Penjualan_Command.length; i++) {
            if (eventData.id === `${Penjualan_Command[i][0]}`) {
                // メッセージからセレクター/プレイヤー名を抽出
                const args = eventData.message.trim().split(/\s+/);
                const selectorOrPlayer = args[0] || '';

                // セレクターまたはプレイヤー名を解析
                const targetPlayers = parseSelector(selectorOrPlayer, eventData.sourceEntity);
                if (targetPlayers.length === 0) {
                    console.log(`[社会システム] エラー: セレクター/プレイヤー「${selectorOrPlayer}」に一致するプレイヤーが見つかりません。`);
                    // 実行者がプレイヤーの場合、エラーメッセージを送信
                    if (eventData.sourceEntity?.typeId === 'minecraft:player') {
                        eventData.sourceEntity.sendMessage(`§r[§b自動販売機§r] §c対象プレイヤーが見つかりません。`);
                    }
                    return;
                }

                // 各プレイヤーに対して自動販売機処理を実行
                targetPlayers.forEach(targetPlayer => {
                    targetPlayer.sendMessage(`§r[§b自動販売機§r] §a読み込み中...`);
                    targetPlayer.playSound('haru.notification1', {
                        pitch: 1.3,
                        volume: 0.5,
                    });
                    system.runTimeout(() => {
                        try {
                            if (targetPlayer) {
                                targetPlayer.playSound('haru.notification1', {
                                    pitch: 1.9,
                                    volume: 0.5,
                                });
                                handleShopInteraction(targetPlayer, undefined, Penjualan_Command[i][1]);
                            }
                        } catch (e) {
                            console.warn(`自動販売機処理エラー: ${e}`);
                        }
                    }, 20);
                });
            }
        }
    });
});

// セレクター
function parseSelector(selector) {
    if (!selector) return [];

    var players = [];
    for (const player of world.getPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}
