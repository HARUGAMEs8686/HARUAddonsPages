import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../../../config';
import { LiteFrame_SystemA } from './SystemA';
import { HARU_XEditor_LiteFrame_upload } from '../uploadApp';
import { HARU_XEditor_LiteFrame_delete } from '../deleteApp';
import { HARU_XEditor } from '../../../App/HARU-XEditor';
var player_Cash_Data = {};

export function LiteFrame_editor(player, Application) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    player_Cash_Data[player.id] = {};
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}\n§r§sLiteFrame\n\n§a${Application[0]}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§5編集`, 'textures/ui/normalicon1');
    form.button(`§1公開設定`, 'textures/ui/normalicon1');
    form.button(`§4アプリの削除`, 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                HARU_XEditor(player);
                break;
            case 1:
                if ((Application[1] = 'LiteFrameA')) {
                    LiteFrame_SystemA(player, Application);
                }
                break;
            case 2:
                HARU_XEditor_LiteFrame_upload(player, Application);
                break;
            case 3:
                HARU_XEditor_LiteFrame_delete(player, Application);
                break;
        }
    });
}
