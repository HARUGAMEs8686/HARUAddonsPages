import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { config } from '../../config';
import { LiteFrame_editor } from './editor/LiteFrame_editor';

var player_Cash_Data = {};

export function HARU_XEditor_LiteFrame_upload(player, Application) {
    system.run(() => {
        player_Cash_Data[player.id] = {};
        
        const appDataRaw = world.getDynamicProperty(`${Application[0]}`);
        if (!appDataRaw) {
            player.sendMessage(`§cエラー: アプリデータが見つかりません`);
            LiteFrame_editor(player, Application);
            return;
        }
        player_Cash_Data[player.id].Application = JSON.parse(appDataRaw);

        // AppData（公開リスト）を取得
        var AppData = world.getDynamicProperty(`AppData`);
        if (AppData == undefined) {
            AppData = [];
        } else {
            AppData = JSON.parse(AppData);
        }

        // 現在公開されているかチェック (IDとタイプで完全一致を探す)
        const publicIndex = AppData.findIndex(item => 
            Array.isArray(item) && item[0] === Application[0] && item[1] === Application[1]
        );
        const isPublic = publicIndex !== -1;

        // 時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        // フォーム作成
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        
        // 状態に応じたテキスト表示
        const statusText = isPublic ? "§a公開中" : "§c非公開";
        form.body(`§l§b${time}\n§r>>> §e公開設定を変更します\n\n§9対象アプリ§r: §b${player_Cash_Data[player.id].Application.ApplicationName}\n§d現在の状態§r: ${statusText}`);
        
        form.button(`§l戻る`, 'textures/ui/icon_import.png');

        // 状態に応じたボタン表示
        if (isPublic) {
            form.button(`§4非公開にする`, 'textures/ui/normalicon1'); // 公開中なら「非公開」ボタン
        } else {
            form.button(`§1公開する`, 'textures/ui/normalicon1');   // 非公開なら「公開」ボタン
        }

        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;

            switch (response) {
                case 0: // 戻る
                    LiteFrame_editor(player, Application);
                    break;

                case 1: // 切り替え処理
                    if (isPublic) {
                        // ■ 非公開にする処理（リストから削除）
                        AppData.splice(publicIndex, 1);
                        world.setDynamicProperty(`AppData`, JSON.stringify(AppData));
                        
                        player.sendMessage(`§r[§bHARU-XEditor§r] §c非公開に設定しました`);
                        player.playSound('random.toast', { pitch: 0.8, volume: 1.0 });
                    } else {
                        // ■ 公開する処理（リストに追加）
                        AppData.push(Application);
                        world.setDynamicProperty(`AppData`, JSON.stringify(AppData));
                        
                        player.sendMessage(`§r[§bHARU-XEditor§r] §a公開しました`);
                        player.playSound('random.toast', { pitch: 1.4, volume: 1.0 });
                    }
                    // 処理完了後、エディタ画面に戻る
                    LiteFrame_editor(player, Application);
                    break;
            }
        });
    });
}