import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

system.runTimeout(async () => {
    // --- モジュールの動的インポート ---
    //アイテム実行
    const { HARUPhone1, player_Cash_Data } = await import('./itemrun/haruphone1.js');
    const { Advance, showAdvanceBuyerMenu } = await import('./itemrun/advance.js');
    const { Money } = await import('./itemrun/money.js');

    //ブロック実行
    const { Game } = await import('./blockrun/game.js');
    const { Atm } = await import('./blockrun/atm.js');
    const { Register } = await import('./blockrun/register.js');
    const { Post } = await import('./itemrun/post.js');

    //常時実行
    const { First_grant } = await import('./First_grant.js');

    //ダメージ発生時実行
    const { entityPOINT } = await import('./EntityPOINT.js');

    //自動販売機
    const { registerShopInteractions } = await import('./blockrun/penjualan.js');
    //自動買取機
    const { registerPembelianInteractions } = await import('./blockrun/pembelian.js');

    //App
    const { App } = await import('./App/AppMenu.js');

    // --- システム機能 ---
    const { HARUPAY } = await import('./system/harupay.js');
    const { showMainUI } = await import('./system/country.js');
    const { openUserNavigationForm } = await import('./system/Map.js');
    const { Browser } = await import('./system/browser.js');
    const { showExchangeItems } = await import('./system/exchange.js');
    const { showPurchaseItems } = await import('./system/purchase.js');
    const { Quick } = await import('./system/quick.js');
    const { ClaimUI } = await import('./system/claim.js');
    const { Mail } = await import('./system/mail.js');
    const { Work } = await import('./system/work.js');
    const { OpenChat } = await import('./system/openchat.js');

    // --- 設定・コントローラー ---
    const { config } = await import('./config.js');
    const { Operator_Controller } = await import('./system/Operator_Controller.js');
    const { FileStting } = await import('./FilesSetting.js');

    // --- ここからメインの処理 ---

    //ブロック
    world.beforeEvents.playerInteractWithBlock.subscribe(eventData => {
        const player = eventData.player;

        if (eventData.block.typeId === 'addblock:game') {
            eventData.cancel = true;
            Game(player);
        }

        if (eventData.block.typeId === 'addblock:register') {
            eventData.cancel = true;
            Register(player);
        }

        if (eventData.block.typeId === 'addblock:atm') {
            eventData.cancel = true;
            Atm(player);
        }
    });

    //アイテム
    world.beforeEvents.itemUse.subscribe(eventData => {
        const player = eventData.source;
        if (eventData.itemStack.typeId === 'additem:haruphone1') {
            HARUPhone1(player);
        }
        if (eventData.itemStack.typeId === 'additem:advance') {
            Advance(player);
        }
        if (eventData.itemStack.typeId === 'additem:post') {
            Post(player);
        }
        if (eventData.itemStack.typeId.includes('additem:coin') || eventData.itemStack.typeId.includes('additem:bill')) {
            Money(player, eventData.itemStack.typeId);
        }
    });

    //ダメージ
    world.afterEvents.entityHurt.subscribe(event => {
        entityPOINT(event);
    });

    //初期設定 >>>
    //UI設定
    const HARUPhone1_AppNumber = [1, 3, 4, 5, 6, 7, 9, 10, 12, 14, 16, 13, 8, 11, 17];

    //HARUPAY
    if (world.getDynamicProperty('harupay_op_money') == undefined) {
        world.setDynamicProperty('harupay_op_money', 0);
    }
    if (world.getDynamicProperty('MoneyList_allow') == undefined) {
        world.setDynamicProperty('MoneyList_allow', true);
    }
    if (world.getDynamicProperty('money_start_system2') !== undefined && typeof world.getDynamicProperty('money_start_system2') !== 'number') {
        world.setDynamicProperty('money_start_system2', 1);
    }
    //QuickSAVE
    if (world.getDynamicProperty('Quick_DataSAVE') == undefined) {
        world.setDynamicProperty('Quick_DataSAVE', false);
    }
    //Quick初期化
    if (world.getDynamicProperty('Quick_DataSAVE') == false) {
        world.setDynamicProperty('shop_menu', undefined);
    }
    //仕事依頼SAVE
    if (world.getDynamicProperty('Work_DataSAVE') == undefined) {
        world.setDynamicProperty('Work_DataSAVE', false);
    }
    //仕事依頼初期化
    if (world.getDynamicProperty('Work_DataSAVE') == false) {
        world.setDynamicProperty('Work_Data', undefined);
    }
    //AppNumber
    if (world.getDynamicProperty('HARUPhone1_AppNumber') == undefined) {
        world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber));
    }

    //UI修正
    var HARUPhone1_AppNumber_Data = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'));
    var Check = false;

    for (let i = 0; i < HARUPhone1_AppNumber_Data.length; i++) {
        if (config.AppData[HARUPhone1_AppNumber_Data[i]] == 'Operator Controller') {
            Check = true;
        }
    }

    if (Check == false) {
        console.warn('[§bHARUPhone1§r] §cHARUPhone1UIをアップデートしています');
        console.warn('[§bHARUPhone1§r] §aデータをアップデートしました');
        HARUPhone1_AppNumber_Data.push(config.AppData.length - 1);
        world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber_Data));
    }

    //MoneyItems
    if (world.getDynamicProperty('MoneyItems_score') == undefined) {
        const MoneyItems_score = [0, 0, 0, 0, 0, 0, 0, 0];
        world.setDynamicProperty('MoneyItems_score', JSON.stringify(MoneyItems_score));
    }
    //browser初期マネー
    if (world.getDynamicProperty('browser_newpage_money') == undefined) {
        world.setDynamicProperty('browser_newpage_money', 0);
    }
    if (world.getDynamicProperty('browser_performance_money') == undefined) {
        world.setDynamicProperty('browser_performance_money', 0);
    }
    //社会システム関連
    if (world.getDynamicProperty('WorldgroupName') == undefined) {
        world.setDynamicProperty('WorldgroupName', '国');
    }
    if (world.getDynamicProperty('DANGEROUS_ITEMS') == undefined) {
        const DANGEROUS_ITEMS = ['additem:haruphone1', 'additem:advance'];
        world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
    }

    if (world.getDynamicProperty('WorldspaceNAME') == undefined) {
        world.setDynamicProperty('WorldspaceNAME', '無主の地');
    }

    if (world.getDynamicProperty('WorldTitle') == undefined) {
        world.setDynamicProperty('WorldTitle', true);
    }

    const UNOWNED_LAND_INTERACTION = 'unowned_land_interaction';
    if (world.getDynamicProperty(UNOWNED_LAND_INTERACTION) == undefined) {
        world.setDynamicProperty(UNOWNED_LAND_INTERACTION, true);
    }
    const MONEY_OBJECTIVE = 'money';
    const CHUNK_PRICE_PROPERTY = 'chunk_price';
    const NATION_CREATION_COST_PROPERTY = 'nation_creation_cost';
    const ALLOW_MULTIPLE_NATIONS_PROPERTY = 'allow_multiple_nations';
    const MAX_PURCHASE_CHUNKS_PROPERTY = 'max_purchase_chunks';
    const CHUNK_SELL_PRICE_PROPERTY = 'chunk_sell_price';
    const UNOWNED_LAND_INTERACT = 'unowned_land_interact';
    if (!world.scoreboard.getObjective(MONEY_OBJECTIVE)) {
        world.scoreboard.addObjective(MONEY_OBJECTIVE, 'money');
    }
    if (world.getDynamicProperty(CHUNK_PRICE_PROPERTY) == undefined) {
        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, 100);
    }
    if (world.getDynamicProperty(NATION_CREATION_COST_PROPERTY) == undefined) {
        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, 500);
    }
    if (world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === undefined) {
        world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, false);
    }
    if (world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) === undefined) {
        world.setDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY, 10);
    }
    if (world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY) === undefined) {
        world.setDynamicProperty(CHUNK_SELL_PRICE_PROPERTY, 50);
    }
    if (world.getDynamicProperty(UNOWNED_LAND_INTERACT) === undefined) {
        world.setDynamicProperty(UNOWNED_LAND_INTERACT, true);
    }
    if (world.getDynamicProperty('Anti-interference') === undefined) {
        world.setDynamicProperty('Anti-interference', false);
    }
    if (world.getDynamicProperty('OP_INTERACTION_ALLOWED') === undefined) {
        world.setDynamicProperty('OP_INTERACTION_ALLOWED', false);
    }
    //GAME関連
    if (world.getDynamicProperty('MULTIPLIER') == undefined) {
        world.setDynamicProperty('MULTIPLIER', 1);
    }
    if (world.getDynamicProperty('TOTAL_LETTERS') == undefined) {
        world.setDynamicProperty('TOTAL_LETTERS', 4);
    }
    if (world.getDynamicProperty('WINNING_COUNT') == undefined) {
        world.setDynamicProperty('WINNING_COUNT', 1);
    }
    if (world.getDynamicProperty('BET_AMOUNTS') == undefined) {
        world.setDynamicProperty('BET_AMOUNTS', '10,100,1000');
    }
    if (world.getDynamicProperty('LUCKY_LETTER_ENABLED') == undefined) {
        world.setDynamicProperty('LUCKY_LETTER_ENABLED', true);
    }
    if (world.getDynamicProperty('HIGH_AND_LOW_ENABLED') == undefined) {
        world.setDynamicProperty('HIGH_AND_LOW_ENABLED', true);
    }
    if (world.getDynamicProperty('SLOT_MACHINE_ENABLED') == undefined) {
        world.setDynamicProperty('SLOT_MACHINE_ENABLED', true);
    }
    if (world.getDynamicProperty('BLACKJACK_ENABLED') == undefined) {
        world.setDynamicProperty('BLACKJACK_ENABLED', true);
    }
    if (world.getDynamicProperty('BLACKJACK_SOLO_REWARD_CAP') == undefined) {
        world.setDynamicProperty('BLACKJACK_SOLO_REWARD_CAP', 1000);
    }

    //アドバンスポスト
    if (world.getDynamicProperty('advancepost') == undefined) {
        world.setDynamicProperty('advancepost', true);
    }

    //時刻
    if (world.getDynamicProperty('Time_Setting') == undefined) {
        world.setDynamicProperty('Time_Setting', 9);
    }

    //OPMONEY
    const settings = { browser: true, socialSystem: true, post: true };
    if (world.getDynamicProperty('harupay_op_settings') == undefined) {
        world.setDynamicProperty('harupay_op_settings', JSON.stringify(settings));
    }

    //ネーム
    if (world.getDynamicProperty('HARUPhone_Name_reload') == undefined) {
        world.setDynamicProperty('HARUPhone_Name_reload', false);
    }
    if (world.getDynamicProperty('HARUPhone_Name') == undefined) {
        world.setDynamicProperty('HARUPhone_Name', '§1HARUPhone1');
    }
    if (world.getDynamicProperty('HARUPhone_ServiceName') == undefined) {
        world.setDynamicProperty('HARUPhone_ServiceName', 'HARU');
    }

    //通知サウンド
    let soundSettings = {};
    try {
        const storedSettings = world.getDynamicProperty('Sound_Notification');
        soundSettings = storedSettings ? JSON.parse(storedSettings) : {};
    } catch (e) {
        soundSettings = {};
    }
    //キルカウント
    if (soundSettings['Kill Count'] == undefined) {
        soundSettings['Kill Count'] = {
            'Count Notification': true,
            'Money Acquisition Notification': true,
        };
    }
    world.setDynamicProperty('Sound_Notification', JSON.stringify(soundSettings));
    //<<<

    //scriptEvents実行
    system.afterEvents.scriptEventReceive.subscribe(eventData => {
        const player = eventData.sourceEntity;
        system.run(() => {
            if (eventData.id === 'haruphone1:start') {
                HARUPhone1(player);
            }
            if (eventData.id === 'haruphone1:apps') {
                App(player);
            }
            if (eventData.id === 'killcount:off') {
                world.setDynamicProperty('killPointSystem', false);
            }
            if (eventData.id === 'killcount:on') {
                world.setDynamicProperty('killPointSystem', true);
            }
            if (eventData.id === 'ui:reset') {
                world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber));
                player.sendMessage(`§r[§bシステム§r] §aUIをリセットしました`);
                player.playSound('random.toast', {
                    pitch: 1.6,
                    volume: 1.0,
                });
                HARUPhone1(player);
            }
            if (eventData.id === 'haruxe:datareset') {
                try {
                    let deletedCount = 0;

                    const allPropertyIds = world.getDynamicPropertyIds();

                    for (const id of allPropertyIds) {
                        if (id === 'AppData' || id.startsWith('App_')) {
                            world.setDynamicProperty(id, undefined);
                            deletedCount++;
                        }
                    }

                    // 2. 実行者がプレイヤーの場合、そのプレイヤーの所有リスト(MY_AppData)も削除
                    if (eventData.sourceEntity && eventData.sourceEntity.typeId === 'minecraft:player') {
                        eventData.sourceEntity.setDynamicProperty('MY_AppData', undefined);
                    }

                    // 完了メッセージ
                    if (eventData.sourceEntity) {
                        eventData.sourceEntity.sendMessage(`§r[§bHARU-XEditor§r] §a初期化完了: 合計 ${deletedCount} 個のデータを削除しました`);
                    }

                    console.warn(`[HARU-XEditor] Data Reset Complete. Deleted ${deletedCount} properties.`);
                } catch (e) {
                    if (eventData.sourceEntity) {
                        eventData.sourceEntity.sendMessage(`§r[§bHARU-XEditor§r] §cエラーが発生しました: ${e}`);
                    }
                    console.error(e);
                }
            }
            // スマホ名変更UI
            if (eventData.id === 'haruphonesecret:ui') {
                const phoneNameLoad = world.getDynamicProperty('HARUPhone_Name_reload');
                const smartphoneName = world.getDynamicProperty('HARUPhone_Name');
                const mainName = world.getDynamicProperty('HARUPhone_ServiceName');

                const form = new ModalFormData();
                form.title('§0スマホ名設定');
                form.toggle(`アイテムネームタグの更新`, {
                    defaultValue: phoneNameLoad,
                });
                form.textField('※§c反映まで少し時間がかかる場合があります§r\n\n>>> §e新しいスマホ名を入力してください', '例: §bMyPhone', {
                    defaultValue: smartphoneName,
                });
                form.textField('>>> §d機能メイン名', '例: §bMy', {
                    defaultValue: mainName,
                });

                form.show(player).then(r => {
                    if (r.canceled) return;
                    const newphoneNameLoad = r.formValues[0];
                    const newphoneName = r.formValues[1];
                    const newmainName = r.formValues[2];

                    world.setDynamicProperty('HARUPhone_Name_reload', newphoneNameLoad);
                    // 空文字じゃなければ保存
                    if (newphoneName && newphoneName.trim() !== '') {
                        world.setDynamicProperty('HARUPhone_Name', newphoneName);
                    }
                    if (newmainName && newmainName.trim() !== '') {
                        world.setDynamicProperty('HARUPhone_ServiceName', newmainName);
                    }
                    player.sendMessage(`§r[§bシステム§r] §a設定を更新しました`);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: 0.8,
                    });
                });
            }
            //HARUPhoneAPI
            //>>>HARUPAY
            if (eventData.id === 'haruphoneapi:harupay') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        HARUPAY(player);
                    });
                }, 6);
            }
            //>>>Quick
            if (eventData.id === 'haruphoneapi:quick') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Quick(player);
                    });
                }, 6);
            }
            //>>>メール
            if (eventData.id === 'haruphoneapi:mail') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Mail(player);
                    });
                }, 6);
            }
            //>>>オープンチャット
            if (eventData.id === 'haruphoneapi:openchat') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        OpenChat(player);
                    });
                }, 6);
            }
            //>>>仕事依頼
            if (eventData.id === 'haruphoneapi:work') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Work(player);
                    });
                }, 6);
            }
            //>>>換金
            if (eventData.id === 'haruphoneapi:exchange') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        showExchangeItems(player);
                    });
                }, 6);
            }
            //>>>購入
            if (eventData.id === 'haruphoneapi:purchase') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        showPurchaseItems(player);
                    });
                }, 6);
            }
            //>>>ブラウザ
            if (eventData.id === 'haruphoneapi:browser') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Browser(player);
                    });
                }, 6);
            }
            //>>>請求
            if (eventData.id === 'haruphoneapi:claim') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        ClaimUI(player);
                    });
                }, 6);
            }
            //>>>マップ
            if (eventData.id === 'haruphoneapi:map') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        openUserNavigationForm(player);
                    });
                }, 6);
            }
            //>>>社会システム
            if (eventData.id === 'haruphoneapi:socialsystem') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        showMainUI(player);
                    });
                }, 6);
            }
            //>>>OperatorController
            if (eventData.id === 'haruphoneapi:operatorcontroller') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Operator_Controller(player);
                    });
                }, 6);
            }
            //APPAdvance
            if (eventData.id === 'haruphoneapi:appadvance') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        showAdvanceBuyerMenu(player);
                    });
                }, 6);
            }
            //Post
            if (eventData.id === 'haruphoneapi:post') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Post(player);
                    });
                }, 6);
            }
            //Advance
            if (eventData.id === 'haruphoneapi:advance') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Advance(player);
                    });
                }, 6);
            }
            //GAME
            if (eventData.id === 'haruphoneapi:game') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Game(player);
                    });
                }, 6);
            }
            //ATM
            if (eventData.id === 'haruphoneapi:atm') {
                system.runTimeout(() => {
                    const selector = eventData.message.trim();
                    const targetPlayers = parseSelector(selector);

                    if (targetPlayers.length === 0) {
                        return;
                    }

                    targetPlayers.forEach(player => {
                        player_Cash_Data[player.id] = {};
                        player_Cash_Data[player.id].HARUPhoneMode = false;
                        Atm(player);
                    });
                }, 6);
            }
        });
    });

    // セレクター
    function parseSelector(selector) {
        if (!selector) return [];

        var players = [];
        for (const player of world.getPlayers()) {
            for (const Name of selector.split(', ')) {
                if (Name == player.name) {
                    players.push(player);
                }
            }
        }
        return players;
    }

    //スクリプトロード
    //自動販売機
    registerShopInteractions();
    //自動買取機
    registerPembelianInteractions();
    //初回付与
    First_grant();
    //FilesSetting
    FileStting();

    // --- スマホ名の定期更新 ---
    system.runInterval(() => {
        if (!world.getDynamicProperty('HARUPhone_Name_reload')) {
            return;
        }
        const rawName = config['main'][0];
        const phoneName = rawName.replace(/§./g, '§r');

        for (const player of world.getAllPlayers()) {
            const inventory = player.getComponent('inventory')?.container;
            if (!inventory) continue;

            const selectedSlot = player.selectedSlotIndex;
            const item = inventory.getItem(selectedSlot);

            if (item && item.typeId === 'additem:haruphone1') {
                if (item.nameTag !== phoneName) {
                    item.nameTag = phoneName;
                    inventory.setItem(selectedSlot, item);
                }
            }
        }
    }, 60);
}, 2);
