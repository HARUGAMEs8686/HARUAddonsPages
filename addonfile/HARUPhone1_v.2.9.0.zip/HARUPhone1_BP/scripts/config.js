import { world } from '@minecraft/server';

export const config = {
    get main() {
        return [
            //スマホ名
            world.getDynamicProperty('HARUPhone_Name') ?? '§1HARUPhone1'
        ];
    },

    get AppName() {
        const serviceName = world.getDynamicProperty('HARUPhone_ServiceName') ?? 'HARU';
        
        return [
            //アプリ表示名
            '広告',
            `${serviceName}PAY`,
            'Quick',
            'メール',
            'オープンチャット',
            '仕事依頼・探す',
            'Advance',
            '換金',
            '購入',
            '情報',
            'ブラウザ',
            '社会システム',
            '請求',
            'Operator Controller',
            `${serviceName}Assistant`,
            'アプリケーション',
            `${serviceName}-X Editor`,
            'マップ'
        ];
    },

    "AppData" : [
        '未設定',
        '広告',
        'アプリケーション',
        'HARUPAY',
        'Quick',
        'メール',
        'オープンチャット',
        '仕事依頼・探す',
        'Advance',
        '換金',
        '購入',
        '情報',
        'ブラウザ',
        '社会システム',
        '請求',
        'HARUAssistant',
        'Map',
        'Operator Controller'
    ],
    "Volume" : 0.7,
    "Version" : ['2.9.0','2026/3/23']
}