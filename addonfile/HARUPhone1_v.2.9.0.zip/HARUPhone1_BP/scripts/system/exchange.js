import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

export async function showExchangeItems(player) {
    try {
        // 換金情報の取得
        const kannkin_information = world.getDynamicProperty('kannkin_information');
        let kannkin_information_system2 = kannkin_information ? JSON.parse(kannkin_information) : [];

        // ジャンル情報の取得
        const kannkin_genres = world.getDynamicProperty('kannkin_genres');
        let genres = kannkin_genres ? JSON.parse(kannkin_genres) : ['一般'];

        // 既存データにジャンルがない場合、デフォルトジャンルを付与
        kannkin_information_system2 = kannkin_information_system2.map(item => {
            if (!item[4]) item[4] = '一般';
            return item;
        });
        world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));

        // 表示するジャンルをフィルタリング
        const displayGenres = genres.filter(genre => {
            if (genre === '一般') {
                return kannkin_information_system2.some(item => item[4] === '一般');
            }
            return true;
        });

        if (!displayGenres.length) {
            player.sendMessage(`§r[§b換金§r] §aジャンルが見つかりません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // --- ジャンル選択フォーム ---
        const genreForm = new ActionFormData();
        genreForm.title(`${config['main'][0]}`);
        genreForm.body('>>> §eジャンルを選択');
        if (player_Cash_Data[player.id].HARUPhoneMode) {
            genreForm.button(`§l戻る`, 'textures/ui/icon_import.png');
        } else {
            genreForm.button(`§0閉じる`, 'textures/ui/icon_import.png');
        }
        displayGenres.forEach(genre => {
            genreForm.button(`§1${genre}`, 'textures/ui/normalicon1');
        });

        const genreResponse = await genreForm.show(player);
        if (genreResponse.canceled) return;
        if (genreResponse.selection === 0) {
            if (player_Cash_Data[player.id].HARUPhoneMode) {
                HARUPhone1(player);
            }
            return;
        }

        const selectedGenre = displayGenres[genreResponse.selection - 1];
        const genreItems = kannkin_information_system2.filter(item => item[4] === selectedGenre);

        if (!genreItems.length) {
            player.sendMessage(`§r[§b換金§r] §a${selectedGenre}にアイテムが見つかりません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // --- アイテム選択フォーム ---
        const itemForm = new ActionFormData();
        itemForm.title(`${config['main'][0]}`);
        itemForm.body(`>>> §e${selectedGenre}の換金アイテムを選択`);
        itemForm.button(`§l戻る`, 'textures/ui/icon_import.png');
        genreItems.forEach(item => {
            const icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
            itemForm.button(`§1${item[0]} §51個§0:§s${item[1]}§r`, icon);
        });

        const itemResponse = await itemForm.show(player);
        if (itemResponse.canceled) return;
        if (itemResponse.selection === 0) {
            showExchangeItems(player);
            return;
        }

        const selectedItemObject = genreItems[itemResponse.selection - 1];
        const globalIndex = kannkin_information_system2.indexOf(selectedItemObject);
        if (globalIndex === -1) {
            player.sendMessage('§r[§b換金§r] §cエラー: アイテムの選択を正しく処理できませんでした。');
            return;
        }
        player_Cash_Data[player.id].select_item = globalIndex;

        // --- 換金数入力フォーム ---
        const amountForm = new ModalFormData();
        amountForm.title(`${config['main'][0]}`);

        const inventory = player.getComponent('minecraft:inventory').container;
        let itemCount = 0;
        const selectedItemInfo = kannkin_information_system2[globalIndex];
        const selectedItemId = selectedItemInfo[2];
        const normalizedItemId = selectedItemId.startsWith('minecraft:') ? selectedItemId : `minecraft:${selectedItemId}`;

        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (item && (item.typeId === normalizedItemId || item.typeId === selectedItemId)) {
                itemCount += item.amount;
            }
        }

        amountForm.textField(`§eアイテム§5>>>§c${selectedItemInfo[0]}\n\n§b所持数: §e${itemCount}\n§a換金数§s(半角数字)`, '0');

        const amountResponse = await amountForm.show(player);
        if (amountResponse.canceled) return;

        // 入力を文字列として取得
        let rawInput = (amountResponse.formValues[0] || '').toString();
        // 全角数字を半角数字に変換
        rawInput = rawInput.replace(/[０-９]/g, function (s) {
            return String.fromCharCode(s.charCodeAt(0) - 0xfee0);
        });
        // 数字以外の文字をすべて削除
        const cleanInput = rawInput.replace(/[^0-9]/g, '');
        // 数字が1つもなかった場合のエラー処理
        if (cleanInput === '') {
            player.sendMessage(`§r[§b換金§r] §4数字を入力してください`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // 数値化
        const amount = parseInt(cleanInput, 10);

        if (amount <= 0) {
            player.sendMessage(`§r[§b換金§r] §40以下は設定できません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }
        if (itemCount < amount) {
            player.sendMessage(`§r[§b換金§r] §4アイテム数が足りません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        const price = selectedItemInfo[1];
        const totalPay = price * amount;

        const confirmForm = new MessageFormData();
        confirmForm.title(`${config['main'][0]}`);
        confirmForm.body(`§eアイテム§5>>>§c ${selectedItemInfo[0]}\n` + `§a換金数§5>>>§e ${amount}個\n\n` + `§b取得PAY§5>>>§6 ${totalPay}PAY\n\n` + `§r上記の内容で換金しますか？`);
        confirmForm.button2('§0いいえ');
        confirmForm.button1('§1はい');

        const confirmResponse = await confirmForm.show(player);

        if (confirmResponse.canceled || confirmResponse.selection === 1) {
            showExchangeItems(player);
            return;
        }

        const objective = world.scoreboard.getObjective('money');
        if (!objective) {
            console.warn("[換金システム] スコアボード 'money' が存在しません。");
            player.sendMessage('§r[§b換金§r] §cエラー: 換金システムの準備ができていません。');
            return;
        }

        let remainingAmount = amount;
        for (let i = 0; i < inventory.size && remainingAmount > 0; i++) {
            const itemStack = inventory.getItem(i);
            if (itemStack && (itemStack.typeId === normalizedItemId || itemStack.typeId === selectedItemId)) {
                if (itemStack.amount > remainingAmount) {
                    itemStack.amount -= remainingAmount;
                    inventory.setItem(i, itemStack);
                    remainingAmount = 0;
                } else {
                    remainingAmount -= itemStack.amount;
                    inventory.setItem(i, undefined);
                }
            }
        }

        objective.addScore(player.scoreboardIdentity, totalPay);

        player.sendMessage(`§r[§b換金§r] §e換金し${totalPay}PAY取得しました`);
        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
    } catch (e) {
        console.error(`[換金システム] エラーが発生しました: ${e}, スタック: ${e.stack}`);
        player.sendMessage(`§r[§b換金§r] §4エラーが発生しました。`);
    }
}
