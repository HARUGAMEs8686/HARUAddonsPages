import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { App } from './App/AppMenu';
import { config } from './config';

export var FilesApplicationData = {
    AppLoad: [],
};

export function FileStting() {
    system.afterEvents.scriptEventReceive.subscribe(eventData => {
        const { id, message, sourceEntity: player } = eventData;

        if (id === 'filesstting:versioncheck') {
            player.addTag(`HARUPhone1_Version_${config['Version'][0]}`);
            system.runTimeout(() => {
                player.removeTag(`HARUPhone1_Version_${config['Version'][0]}`);
            }, 2);
        }

        //>>> 換金
        // haruexchange:add イベントの処理
        if (id === 'haruexchange:add') {
            system.run(() => {
                const args = message.split(' ');
                if (args.length < 5) {
                    return;
                }

                const itemId = args[0];
                const price = parseInt(args[1], 10);
                const genre = args[2];
                const iconPath = args[3];
                const itemName = args[4];

                if (isNaN(price)) {
                    return;
                }

                let kannkin_information = world.getDynamicProperty('kannkin_information');
                let kannkin_information_system2 = kannkin_information ? JSON.parse(kannkin_information) : [];

                kannkin_information_system2.push([itemName, String(price), itemId, iconPath, genre]);
                world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));

                let kannkin_log = world.getDynamicProperty('kannkin_log');
                let kannkin_log_system2 = kannkin_log ? JSON.parse(kannkin_log) : [];
                kannkin_log_system2.push(0);
                world.setDynamicProperty('kannkin_log', JSON.stringify(kannkin_log_system2));

                let kannkin_genres = world.getDynamicProperty('kannkin_genres');
                let genres = kannkin_genres ? JSON.parse(kannkin_genres) : ['一般'];
                if (genre && !genres.includes(genre)) {
                    genres.push(genre);
                    world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                }
            });
        }

        //>>> 購入
        // harupurchase:add イベントの処理
        if (id === 'harupurchase:add') {
            system.run(() => {
                const args = message.split(' ');
                if (args.length < 5) {
                    return;
                }

                const itemId = args[0];
                const price = parseInt(args[1], 10);
                const genre = args[2];
                const iconPath = args[3];
                const itemName = args[4];

                // priceが数値でない場合はエラーメッセージを表示
                if (isNaN(price)) {
                    player.sendMessage('§c価格には数値を入力してください。');
                    return;
                }

                let kounyuu_list = world.getDynamicProperty('kounyuu_list');
                let kounyuu_list_system2 = kounyuu_list ? JSON.parse(kounyuu_list) : [];

                kounyuu_list_system2.push([itemName, String(price), itemId, iconPath, genre]);
                world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));

                let kounyuu_log = world.getDynamicProperty('kounyuu_log');
                let kounyuu_log_system2 = kounyuu_log ? JSON.parse(kounyuu_log) : [];
                kounyuu_log_system2.push(0);
                world.setDynamicProperty('kounyuu_log', JSON.stringify(kounyuu_log_system2));

                let kounyuu_genres = world.getDynamicProperty('kounyuu_genres');
                let genres = kounyuu_genres ? JSON.parse(kounyuu_genres) : ['一般'];
                if (genre && !genres.includes(genre)) {
                    genres.push(genre);
                    world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                }
            });
        }

        if (id === 'haruexchange:reset') {
            world.setDynamicProperty('kannkin_information', undefined);
            world.setDynamicProperty('kannkin_log', undefined);
            world.setDynamicProperty('kannkin_genres', undefined);
        }
        if (id === 'harupurchase:reset') {
            world.setDynamicProperty('kounyuu_list', undefined);
            world.setDynamicProperty('kounyuu_log', undefined);
            world.setDynamicProperty('kounyuu_genres', undefined);
        }

        //>>> アプリケーション
        if (id === 'haruapplicationfile:push') {
            let message_String = binaryToString(message);
            const args = message_String.split(' ');
            if (args.length < 2) {
                return;
            }
            const ApplicationName = args[0];
            const Command = args.slice(1).join(' ');

            if (!FilesApplicationData.AppLoad.includes(ApplicationName)) {
                FilesApplicationData.AppLoad.push(ApplicationName);
                FilesApplicationData[ApplicationName] = [];
            }
            FilesApplicationData[ApplicationName].push(Command);
        }
        if (id === 'haruapplicationfile:reset') {
            FilesApplicationData = {
                AppLoad: [],
            };
        }
    });
}

function binaryToString(binary) {
    let resultString = '';
    const chunks = binary.match(/.{1,16}/g) || [];
    for (const chunk of chunks) {
        resultString += String.fromCharCode(parseInt(chunk, 2));
    }
    return resultString;
}
