import { world, system, BlockTypes, ItemStack } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';

import { config } from '../config';
import { IDConfig } from '../IDConfig';

// ポストデータの保存（ワールドカスタムプロパティを使用）
const POSTS_KEY = 'posts_data';
const SETTINGS_KEY = 'settings_data';

// デフォルト設定
let settings = {
    sendCost: 10, // アイテム送信時のコスト
    maxPosts: 5, // 1人あたりの最大ポスト数
};

// ポスト登録モードの管理
let registerMode = new Map(); // プレイヤーID -> モード状態
let uiCooldown = new Map(); // プレイヤーID -> クールタイム終了時刻

// クールタイム（ミリ秒）
const UI_COOLDOWN_MS = 1000;

// 初期化：スコアボードとワールドプロパティの設定
function initialize() {
    if (!world.getDynamicProperty(POSTS_KEY)) {
        world.setDynamicProperty(POSTS_KEY, JSON.stringify([]));
    }
    if (!world.getDynamicProperty(SETTINGS_KEY)) {
        world.setDynamicProperty(SETTINGS_KEY, JSON.stringify(settings));
    } else {
        settings = JSON.parse(world.getDynamicProperty(SETTINGS_KEY));
    }
}
//ID検索
function getItemDisplayName(itemId) {
    const configEntry = IDConfig.find(entry => entry[0] === itemId);
    if (configEntry) {
        return configEntry[1]; // 設定にあれば表示名を返す
    }
    return itemId.replace('minecraft:', ''); // なければIDから "minecraft:" を取り除いて返す
}

// ポストデータの取得/保存
function getPosts() {
    return JSON.parse(world.getDynamicProperty(POSTS_KEY) || '[]');
}
function savePosts(posts) {
    world.setDynamicProperty(POSTS_KEY, JSON.stringify(posts));
}
function saveSettings() {
    world.setDynamicProperty(SETTINGS_KEY, JSON.stringify(settings));
}

// テクスチャパス取得
function getItemTexture(itemId) {
    const configEntry = IDConfig.find(entry => entry[0] === itemId);
    if (configEntry && configEntry[2]) {
        return configEntry[2];
    }
    // 設定がない、またはパスが未定義の場合はデフォルトアイコン
    return 'textures/ui/normalicon1';
}

// エンチャント情報の取得
function getEnchantmentDisplay(item) {
    if (!item) return '';
    const enchantments = item.getComponent('minecraft:enchantable')?.getEnchantments();
    if (!enchantments || !enchantments[Symbol.iterator]) return '';
    let display = '';
    try {
        for (const enchantment of enchantments) {
            if (enchantment && enchantment.type && enchantment.type.id && typeof enchantment.level === 'number') {
                display += `${enchantment.type.id}:${enchantment.level}, `;
            }
        }
    } catch (e) {
        // エンチャント取得エラーを無視
    }
    return display ? ` [${display.slice(0, -2)}]` : '';
}

// メインUI
export function Post(player) {
    if (registerMode.has(player.id)) {
        system.runTimeout(() => {
            registerMode.delete(player.id);
        }, 1);
        return;
    }
    system.run(() => {
        if (player.dimension.id !== 'minecraft:overworld') {
            player.sendMessage('§r[§bPost§r] §cこの機能はオーバーワールドでのみ使用できます');
            return;
        }
        const form = new ActionFormData().title('§1ポスト').body('>>> §e選択してください').button(`§1ポストへ送信\n§0コスト§0>§4${settings.sendCost}`, 'textures/ui/normalicon1').button('§0ポスト§1登録/§4管理', 'textures/ui/normalicon1');
        if (player.hasTag('HARUPhoneOP')) {
            form.button('§0管理者設定', 'textures/ui/operatorcontroller');
        }
        form.show(player).then(response => {
            if (response.canceled) return;
            switch (response.selection) {
                case 0:
                    showSendPostSelectionUI(player);
                    break;
                case 1:
                    showMyPostsUI(player);
                    break;
                case 2:
                    if (player.hasTag('HARUPhoneOP')) showAdminSelectionUI(player);
                    else player.sendMessage('§r[§bPost§r] §c管理者権限が必要です');
                    break;
            }
        });
    });
}

// ポスト送信方法選択UI
function showSendPostSelectionUI(player) {
    const form = new ActionFormData().title('§1ポスト').body('>>> §eポストの選択方法を選択').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1オンラインのプレイヤーから選択', 'textures/ui/normalicon1').button('§5ポスト名で選択', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) return Post(player);
        if (response.selection === 1) {
            showOnlinePlayerSelectionUI(player);
        } else {
            showSendPostByNameUI(player);
        }
    });
}

// オンラインプレイヤー選択UI
function showOnlinePlayerSelectionUI(player) {
    const players = world.getAllPlayers();
    const form = new ActionFormData().title('§1ポスト').body('>>> §e送信先のプレイヤーを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    players.forEach(p => form.button(`§1${p.name}`, 'textures/ui/normalicon1'));

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) return showSendPostSelectionUI(player);
        const targetPlayer = players[response.selection - 1];
        showSendPostOnlineUI(player, targetPlayer);
    });
}

// プレイヤーのポスト選択UI
function showSendPostOnlineUI(player, targetPlayer) {
    const posts = getPosts().filter(p => p.owner === targetPlayer.name || p.shared.includes(player.name));
    if (posts.length === 0) return player.sendMessage('§r[§bPost§r] §cこのプレイヤーのポストは利用できません');

    const form = new ActionFormData().title(`§1ポスト`).body(`§a送信するポストを選んでください\n§5>>>§e${targetPlayer.name}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    posts.forEach(p => form.button(`§1${p.name}`, 'textures/ui/normalicon1'));

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) return showOnlinePlayerSelectionUI(player);
        const targetPost = posts[response.selection - 1];
        showItemSelectionUI(player, targetPost);
    });
}

// ポスト名で選択
function showSendPostByNameUI(player) {
    const form = new ModalFormData().title('§1ポスト').textField('ポスト名', 'ポスト名を入力');

    form.show(player).then(response => {
        if (response.canceled) return showSendPostSelectionUI(player);
        const [postName] = response.formValues;
        if (!postName) return player.sendMessage('§r[§bPost§r] §cポスト名を入力してください');
        const posts = getPosts();
        const targetPost = posts.find(p => p.name === postName);
        if (!targetPost) return player.sendMessage('§r[§bPost§r] §c指定されたポストが見つかりません');
        showItemSelectionUI(player, targetPost);
    });
}

// アイテム選択UI
function showItemSelectionUI(player, targetPost) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const items = [];
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) items.push({ slot: i, typeId: item.typeId, amount: item.amount });
    }
    if (items.length === 0) {
        const dimension = world.getDimension(targetPost.dimension);
        removeTickingArea(dimension, targetPost.name);
        return player.sendMessage('§r[§bPost§r] §c所持しているアイテムがありません');
    }

    const form = new ActionFormData().title('§1ポスト').body('送信するアイテムを選んでください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    items.forEach(item => {
        const displayName = getItemDisplayName(item.typeId);
        const texturePath = getItemTexture(item.typeId); // 追加：テクスチャパスを取得
        const enchantDisplay = getEnchantmentDisplay(inventory.getItem(item.slot));
        form.button(`§1${displayName} (${item.amount})${enchantDisplay}`, texturePath);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            const dimension = world.getDimension(targetPost.dimension);
            removeTickingArea(dimension, targetPost.name);
            showOnlinePlayerSelectionUI(player);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showItemAmountUI(player, targetPost, selectedItem);
    });
}

// 送信アイテム個数入力UI
function showItemAmountUI(player, targetPost, selectedItem) {
    const form = new ModalFormData().title('§1ポスト').textField('送信する個数', `1-${selectedItem.amount}`);

    form.show(player).then(response => {
        if (response.canceled) {
            return showItemSelectionUI(player, targetPost);
        }
        const [amountStr] = response.formValues;
        const amount = parseInt(amountStr);
        if (isNaN(amount) || amount < 1 || amount > selectedItem.amount) {
            // エラー時もtickingareaを保持して再表示
            return player.sendMessage(`§r[§bPost§r] §c1から${selectedItem.amount}の間で入力してください`);
        }
        showSendConfirmUI(player, targetPost, selectedItem, amount);
    });
}

// Tickingarea管理
function addTickingArea(dimension, location, postName) {
    const { x, y, z } = location;
    const command = `tickingarea add ${x} ${y} ${z} ${x} ${y} ${z} "post_${postName}" true`;
    try {
        dimension.runCommand(command);
    } catch (e) {
        // 既存のtickingareaがある場合など、エラーは無視
    }
}

function removeTickingArea(dimension, postName) {
    const command = `tickingarea remove "post_${postName}"`;
    try {
        dimension.runCommand(command);
    } catch (e) {
        // tickingareaが存在しない場合など、エラーは無視
    }
}

// 送信確認UI
function showSendConfirmUI(player, targetPost, selectedItem, amount) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const item = inventory.getItem(selectedItem.slot);
    const enchantDisplay = getEnchantmentDisplay(item);
    const form = new MessageFormData()
        .title('§1ポスト')
        .body(`§aポスト§r:§b${targetPost.name}\n§b${getItemDisplayName(selectedItem.typeId)}${enchantDisplay}§r:§e${amount}個§a送信します\n§cコスト§r: §b${settings.sendCost}Money`)
        .button1('§1送信')
        .button2('§0キャンセル');

    form.show(player).then(response => {
        const dimension = world.getDimension(targetPost.dimension);
        if (response.canceled || response.selection === 1) {
            return Post(player);
        }

        // 送信前にtickingareaを追加
        addTickingArea(dimension, targetPost.location, targetPost.name);

        system.runTimeout(() => {
            const money = world.scoreboard.getObjective('money').getScore(player) || 0;
            if (money < settings.sendCost) {
                player.sendMessage(`§r[§bPost§r] §c送信には§b${settings.sendCost}Money§cが必要です §e所持§r：§a${money}`);
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            if (!item || item.amount < amount) {
                player.sendMessage('§r[§bPost§r] §cアイテムが不足しています');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            const block = dimension.getBlock(targetPost.location);
            if (block.typeId !== 'minecraft:chest' && block.typeId !== 'minecraft:barrel') {
                player.sendMessage('§r[§bPost§r] §cポストが破壊されています');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            const container = block.getComponent('minecraft:inventory').container;
            const newItem = item.clone();
            newItem.amount = amount;

            // インベントリが満杯かチェック
            let emptySlots = 0;
            for (let i = 0; i < container.size; i++) {
                if (!container.getItem(i)) emptySlots++;
            }
            if (emptySlots === 0) {
                let canAdd = false;
                for (let i = 0; i < container.size; i++) {
                    const slotItem = container.getItem(i);
                    if (slotItem && slotItem.typeId === newItem.typeId && slotItem.amount < slotItem.maxAmount) {
                        canAdd = true;
                        break;
                    }
                }
                if (!canAdd) {
                    player.sendMessage('§r[§bPost§r] §cポストのインベントリが満杯です');
                    removeTickingArea(dimension, targetPost.name);
                    return;
                }
            }

            try {
                container.addItem(newItem);
            } catch (e) {
                player.sendMessage('§r[§bPost§r] §cポストのインベントリに追加できませんでした');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            if (item.amount === amount) {
                inventory.setItem(selectedItem.slot, null);
            } else {
                item.amount -= amount;
                inventory.setItem(selectedItem.slot, item);
            }

            try {
                player.runCommand(`scoreboard players add @s money -${settings.sendCost}`);
                let harupay_settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                if (harupay_settings.post != undefined && harupay_settings.post) {
                    world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(settings.sendCost));
                }
            } catch (e) {
                player.sendMessage('§r[§bPost§r] §cマネーの減算に失敗しました');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            player.sendMessage(`§r[§bPost§r] §a${targetPost.name}§5<<<§b${getItemDisplayName(selectedItem.typeId)}${enchantDisplay}§r:§e${amount}個§a送信しました§r（§b-${settings.sendCost}Money§r）`);
            // 所有者がオンラインで、かつ自分自身への送信ではない場合に通知
            const owner = world.getAllPlayers().find(p => p.name === targetPost.owner);
            if (owner && owner.id !== player.id) {
                const displayName = getItemDisplayName(selectedItem.typeId); // IDConfigを利用して表示名を取得
                owner.sendMessage(`§r[§bPost§r] §e${player.name}§aさんからポスト「§b${targetPost.name}§a」に §d${displayName}${enchantDisplay}§r(§ex${amount}§r)§a が届きました`);
            }
            removeTickingArea(dimension, targetPost.name);
        }, 1);
    });
}

// MYポスト登録/編集UI
function showMyPostsUI(player) {
    const form = new ActionFormData().title('§1ポスト').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1ポスト登録モード', 'textures/ui/normalicon1').button('§0所持ポストの管理', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) return Post(player);
        switch (response.selection) {
            case 1:
                registerMode.set(player.id, true);
                player.sendMessage('§r[§bPost§r] §aポスト登録モードを有効にしました\n>>> §eチェストまたは樽をクリックしてください');
                break;
            case 2:
                showPostManagementUI(player);
                break;
        }
    });
}

// ポスト登録モード時の処理
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;
    if (!registerMode.has(player.id)) return;
    event.cancel = true; // デフォルトのチェスト開く動作をキャンセル
    system.run(() => {
        if (block.typeId !== 'minecraft:chest' && block.typeId !== 'minecraft:barrel') {
            player.sendMessage('§r[§bPost§r] §cチェストまたは樽を選択してください');
            return;
        }

        // クールタイムチェック
        const currentTime = Date.now();
        if (uiCooldown.has(player.id) && currentTime < uiCooldown.get(player.id)) {
            return;
        }
        uiCooldown.set(player.id, currentTime + UI_COOLDOWN_MS);

        const posts = getPosts();
        // 既存ポストの位置重複チェック
        const existingPost = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
        if (existingPost) {
            player.sendMessage('§r[§bPost§r] §cこの位置には既にポストが登録されています');
            return;
        }

        if (posts.filter(p => p.owner === player.name).length >= settings.maxPosts) {
            player.sendMessage(`§r[§bPost§r] §cポスト登録上限（${settings.maxPosts}）に達しています`);
            return;
        }

        const form = new ModalFormData().title('§1ポスト').textField('ポスト名', '例: マイポスト1');

        form.show(player).then(response => {
            if (response.canceled) return showMyPostsUI(player);
            const [postName] = response.formValues;
            if (!postName) return player.sendMessage('§r[§bPost§r] §cポスト名を入力してください');

            // ポスト名の一意性チェック（大文字小文字を無視）
            if (posts.some(p => p.name.toLowerCase() === postName.toLowerCase())) {
                player.sendMessage('§r[§bPost§r] §cこのポスト名は既に使用されています。別の名前を試してください');
                return;
            }

            posts.push({
                name: postName,
                owner: player.name,
                location: block.location,
                dimension: block.dimension.id,
                shared: [],
            });
            savePosts(posts);
            player.sendMessage(`§r[§bPost§r] §aポスト「${postName}」を登録しました`);
            registerMode.delete(player.id);
        });
    });
});

// ポスト保護および破壊時のデータ削除
world.beforeEvents.playerBreakBlock.subscribe(event => {
    const { player, block } = event;
    const posts = getPosts();
    const post = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
    if (post) {
        if (post.owner !== player.name && !post.shared.includes(player.name) && !player.hasTag('HARUPhoneOP')) {
            event.cancel = true;
            player.sendMessage('§r[§bPost§r] §cこのポストはあなたが操作できません');
        } else {
            // ポスト破壊時にデータ削除
            const newPosts = posts.filter(p => p !== post);
            savePosts(newPosts);
            player.sendMessage(`§r[§bPost§r] §aポスト「§b${post.name}§a」§c登録を解除しました`);
        }
    }
});

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;
    const posts = getPosts();
    const post = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
    if (post && post.owner !== player.name && !post.shared.includes(player.name) && !player.hasTag('HARUPhoneOP')) {
        event.cancel = true;
        player.sendMessage('§r[§bPost§r] §cこのポストはあなたが操作できません');
    }
});

world.beforeEvents.explosion.subscribe(event => {
    const posts = getPosts();
    if (!posts || posts.length === 0) {
        return;
    }

    const impactedBlocks = event.getImpactedBlocks();
    const dimensionId = event.dimension.id;

    // 爆発で影響を受けるブロックのリストから、ポストとして登録されているブロックを除外する
    const newImpactedBlocks = impactedBlocks.filter(blockLocation => {
        return !posts.some(post => post.dimension === dimensionId && post.location.x === blockLocation.x && post.location.y === blockLocation.y && post.location.z === blockLocation.z);
    });
    event.setImpactedBlocks(newImpactedBlocks);
});

// 所持ポスト管理UI
function showPostManagementUI(player) {
    const posts = getPosts().filter(p => p.owner === player.name);
    if (posts.length === 0) {
        player.sendMessage(`§r[§bPost§r] §a操作できるポストが見つかりません`);
        showMyPostsUI(player);
        return;
    }

    const form = new ActionFormData().title('§1ポスト管理').body('>>> §e選択してください');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    posts.forEach(p => {
        const locationText = `§0(${p.location.x}, ${p.location.y}, ${p.location.z})`;
        form.button(`§1${p.name}\n${locationText}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            return showMyPostsUI(player);
        }
        const selectedPost = posts[response.selection - 1];
        showPostOperationChoiceUI(player, selectedPost);
    });
}

// ポストUI
function showPostOperationChoiceUI(player, post) {
    post = getPosts().filter(p => p.name === post.name)[0];

    const locationText = `§r座標: ${post.location.x}, ${post.location.y}, ${post.location.z}`;
    const form = new ActionFormData().title(`§1ポスト - ${post.name}`).body(`>>> §e選択してください\n${locationText}`).button(`§l戻る`, 'textures/ui/icon_import.png').button('§4ポストの削除', 'textures/ui/normalicon1').button('§1共有プレイヤーの管理', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            return showPostManagementUI(player);
        }

        switch (response.selection) {
            case 1: // 削除
                showDeleteConfirmUI(player, post);
                break;
            case 2: // 共有プレイヤー管理
                showSharedPlayerToggleUI(player, post);
                break;
        }
    });
}

// 新規追加: 共有プレイヤー切替UI (ワンタップトグル方式)
function showSharedPlayerToggleUI(player, post) {
    // 最新のポストデータを取得
    const posts = getPosts();
    const currentPost = posts.find(p => p.name === post.name && p.owner === player.name);

    if (!currentPost) {
        player.sendMessage(`§r[§bPost§r] §cポストデータが見つかりません`);
        return showPostManagementUI(player);
    }

    const sharedList = currentPost.shared || [];

    // 表示するプレイヤーリストを作成 (オンラインプレイヤー + 既に共有されているプレイヤー)
    const onlineNames = world.getAllPlayers().map(p => p.name);
    const allCandidateSet = new Set([...onlineNames, ...sharedList]);
    allCandidateSet.delete(player.name); // 自分はリストから除外

    const sortedPlayerNames = Array.from(allCandidateSet).sort();

    const form = new ActionFormData().title('§1ポスト - 共有切替').body(`§aポスト§r(§e${currentPost.name}§r)\n§r>>> §eタップして権限を切り替えます`).button(`§l戻る`, 'textures/ui/icon_import.png');

    // プレイヤーごとのボタンを生成
    sortedPlayerNames.forEach(targetName => {
        const isShared = sharedList.includes(targetName);
        if (isShared) {
            form.button(`§0${targetName}\n§0(§1許可§0)`, 'textures/ui/normalicon1');
        } else {
            form.button(`§0${targetName}\n§0(§4拒否§0)`, 'textures/ui/normalicon1');
        }
    });

    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            return showPostOperationChoiceUI(player, currentPost);
        }

        const selectedIndex = response.selection - 1;
        const targetName = sortedPlayerNames[selectedIndex];

        // 再度最新のポストデータを取得して更新する
        const latestPosts = getPosts();
        const targetPost = latestPosts.find(p => p.name === currentPost.name && p.owner === player.name);

        if (targetPost) {
            if (targetPost.shared.includes(targetName)) {
                // 削除処理
                targetPost.shared = targetPost.shared.filter(name => name !== targetName);
                player.sendMessage(`§r[§bPost§r] §c${targetName} §7の共有を解除しました`);
                player.playSound('random.toast', { pitch: 1.6, volume: 1.0 });
            } else {
                // 追加処理
                targetPost.shared.push(targetName);
                player.sendMessage(`§r[§bPost§r] §a${targetName} §7を共有に追加しました`);
                player.playSound('random.toast', { pitch: 1.8, volume: 1.0 });
            }
            savePosts(latestPosts);
        }

        system.run(() => {
            showSharedPlayerToggleUI(player, targetPost || currentPost);
        });
    });
}

// 新規追加: ポスト削除確認UI
function showDeleteConfirmUI(player, post) {
    const confirmForm = new MessageFormData().title('§4ポスト削除の確認').body(`§c本当にポスト「§l${post.name}§r§c」を削除しますか？\n§cこの操作は取り消せません。`).button1('§4削除する').button2('§l戻る');

    confirmForm.show(player).then(res => {
        if (res.canceled || res.selection === 1) {
            return showPostOperationChoiceUI(player, post);
        }
        if (res.selection === 0) {
            const allPosts = getPosts();
            const newPosts = allPosts.filter(p => !(p.name === post.name && p.owner === player.name));
            savePosts(newPosts);
            const dimension = world.getDimension(post.dimension);
            removeTickingArea(dimension, post.name);
            player.sendMessage(`§r[§bPost§r] §aポスト「§b${post.name}§a」を削除しました`);
        }
    });
}

// 管理者設定選択UI
function showAdminSelectionUI(player) {
    const form = new ActionFormData()
        .title('§1ポスト')
        .body('>>> §e設定項目を選んでください')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1アイテム送信コスト設定', 'textures/ui/normalicon1')
        .button('§5最大ポスト数設定', 'textures/ui/normalicon1')
        .button('§4ポスト管理', 'textures/ui/normalicon1')
        .button(`§0Advance連携\n§0(${world.getDynamicProperty('advancepost') ? '§1有効' : '§4無効'}§0)`, 'textures/items/advance');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) return Post(player);
        switch (response.selection) {
            case 1:
                showSendCostUI(player);
                break;
            case 2:
                showMaxPostsUI(player);
                break;
            case 3:
                showAdminPlayerSelectionUI(player);
                break;
            case 4:
                showAdvanceSetteingUI(player);
                break;
        }
    });
}

function showAdvanceSetteingUI(player) {
    var form = new ActionFormData();
    form.title('§1ポスト');
    form.body('>>> §eAdvance連携');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`${world.getDynamicProperty('advancepost') ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            showAdminSelectionUI(player);
            return;
        }
        if (r.selection == 1) {
            world.setDynamicProperty('advancepost', !world.getDynamicProperty('advancepost'));
            player.sendMessage(`§r[§bポスト§r] §aAdvance連携設定を更新しました`);
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            showAdminSelectionUI(player);
        }
    });
}

// 送信コスト設定UI
function showSendCostUI(player) {
    const form = new ModalFormData().title('§1ポスト').textField('アイテム送信コスト', settings.sendCost.toString());

    form.show(player).then(response => {
        if (response.canceled) return showAdminSelectionUI(player);
        const [sendCost] = response.formValues;
        settings.sendCost = parseInt(sendCost) || settings.sendCost;
        saveSettings();
        player.sendMessage(`§r[§bPost§r] §a送信コストを${settings.sendCost}に更新しました`);
    });
}

// 最大ポスト数設定UI
function showMaxPostsUI(player) {
    const form = new ModalFormData().title('§1ポスト').textField('1人あたりの最大ポスト数', settings.maxPosts.toString());

    form.show(player).then(response => {
        if (response.canceled) return showAdminSelectionUI(player);
        const [maxPosts] = response.formValues;
        settings.maxPosts = parseInt(maxPosts) || settings.maxPosts;
        saveSettings();
        player.sendMessage(`§r[§bPost§r] §a最大ポスト数を${settings.maxPosts}に更新しました`);
    });
}

// 管理者：ポスト所有者の選択 (データ上の全所有者を表示)
function showAdminPlayerSelectionUI(player) {
    const posts = getPosts();
    // 全ポストデータから重複なしで所有者リストを作成
    const owners = [...new Set(posts.map(p => p.owner))].sort();

    if (owners.length === 0) {
        player.sendMessage('§r[§bPost§r] §c登録されているポストがありません');
        return showAdminSelectionUI(player);
    }

    const form = new ActionFormData().title('§1管理者: 所有者選択').body('>>> §eポストを所有しているプレイヤーを選択');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    owners.forEach(owner => {
        const count = posts.filter(p => p.owner === owner).length;
        form.button(`§1${owner}\n§0所有数: ${count}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showAdminSelectionUI(player);
        const selectedOwner = owners[res.selection - 1];
        showAdminPostSelectionUI(player, selectedOwner);
    });
}

// 管理者：選択したプレイヤーのポスト一覧
function showAdminPostSelectionUI(player, ownerName) {
    const posts = getPosts().filter(p => p.owner === ownerName);
    const form = new ActionFormData().title(`§1管理者: ${ownerName}のポスト`).body(`>>> §e管理するポストを選択してください`);

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    posts.forEach(p => {
        form.button(`§1${p.name}\n§0${p.location.x}, ${p.location.y}, ${p.location.z}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showAdminPlayerSelectionUI(player);
        const selectedPost = posts[res.selection - 1];
        showAdminPostManageUI(player, selectedPost);
    });
}

// 管理者：個別ポストの管理画面 (削除・所有者変更)
function showAdminPostManageUI(player, post) {
    const form = new ActionFormData().title(`§1管理者: ポスト管理`).body(`§aポスト名: §b${post.name}\n§a所有者: §e${post.owner}\n§a座標: §r${post.location.x}, ${post.location.y}, ${post.location.z}`).button(`§l戻る`, 'textures/ui/icon_import.png').button('§4ポストを削除する', 'textures/ui/normalicon1').button('§0所有者を変更する', 'textures/ui/normalicon1');

    form.show(player).then(res => {
        if (res.canceled || res.selection === 0) return showAdminPostSelectionUI(player, post.owner);

        if (res.selection === 1) {
            // 削除処理
            const allPosts = getPosts();
            const newPosts = allPosts.filter(p => !(p.name === post.name && p.owner === post.owner));
            savePosts(newPosts);
            player.sendMessage(`§r[§bPost§r] §aポスト「${post.name}」を削除しました`);
            showAdminPlayerSelectionUI(player); // プレイヤー選択に戻る
        } else if (res.selection === 2) {
            // 所有者変更UIへ
            showAdminChangeOwnerUI(player, post);
        }
    });
}

// 管理者：所有者の変更UI
function showAdminChangeOwnerUI(player, post) {
    const onlinePlayers = world.getAllPlayers();
    const form = new ModalFormData()
        .title('§1管理者: 所有者変更')
        .dropdown(
            `§aポスト §r(§e${post.name}§r)§aの新しい所有者を選択`,
            onlinePlayers.map(p => p.name),
            {
                defaultValueIndex: 0,
            },
        )
        .submitButton('§1適用');

    form.show(player).then(res => {
        if (res.canceled) return showAdminPostManageUI(player, post);

        const [playerIndex] = res.formValues;
        const newOwnerName = onlinePlayers[playerIndex].name;

        const allPosts = getPosts();
        const targetPost = allPosts.find(p => p.name === post.name && p.owner === post.owner);

        if (targetPost) {
            targetPost.owner = newOwnerName;
            savePosts(allPosts);
            player.sendMessage(`§r[§bPost§r] §aポスト「${post.name}」の所有者を §e${newOwnerName} §aに変更しました`);
        }
        showAdminPlayerSelectionUI(player);
    });
}

export function startAdvanceDeliveryFlow(player, order, onComplete) {
    const posts = getPosts();
    const targetPost = posts.find(p => p.owner === order.buyerName && p.name === order.deliveryPost);

    if (!targetPost) {
        player.sendMessage('§r[§bPost§r] §c配送先ポストが見つかりません');
        return;
    }
    showItemSelectionUI(player, targetPost);
}

// 初期化実行
system.run(initialize);
