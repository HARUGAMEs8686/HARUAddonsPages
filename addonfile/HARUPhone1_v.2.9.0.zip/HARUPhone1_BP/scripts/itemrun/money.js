import { world, system } from '@minecraft/server';

export function Money(player, ItemID) {
    const MoneyInfo = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
    const MoneyID = ['additem:coina', 'additem:coinb', 'additem:coinc', 'additem:coind', 'additem:coine', 'additem:billa', 'additem:billb', 'additem:billc'];
    const index = MoneyID.indexOf(ItemID);
    if (index !== -1) {
        system.run(() => {
            player.onScreenDisplay.setActionBar(`Money:§b${MoneyInfo[index]}`);
        });
    }
}
