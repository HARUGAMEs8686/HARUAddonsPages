import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { HARUPhone1 } from './haruphone1';
import { Operator_Controller } from '../system/Operator_Controller';
import { startAdvanceDeliveryFlow } from './post';

// --- データ管理 ---
const KEYS = {
    COMPANIES: 'adv_companies', // 会社情報
    PRODUCTS: 'adv_products', // 商品情報
    ORDERS_META: 'adv_orders_meta', // 注文データのチャンク情報
    ORDERS_PREFIX: 'adv_orders_', // 注文データのチャンクのプレフィックス
    MIGRATION_FLAG: 'adv_migration_completed', // データ移行完了フラグ
    PENDING_NOTIFICATIONS: 'adv_pending_notifications', // 保留中の通知
    NOTIFICATIONS_HISTORY: 'adv_notifications_history', // 通知履歴
};
const MAX_HISTORY = 20;
const MAX_CHUNK_SIZE = 30000; // チャンクごとの最大おおよそのサイズ (バイト)

// データを安全に読み込む（JSONパースエラー対策）
function loadData(key, defaultValue = {}) {
    const savedData = world.getDynamicProperty(key);
    if (savedData === undefined) {
        return defaultValue;
    }
    try {
        return JSON.parse(savedData);
    } catch (e) {
        console.error(`[Advance] Failed to parse JSON for key "${key}". Error: ${e}`);
        return defaultValue;
    }
}

// データを保存する
function saveData(key, data) {
    world.setDynamicProperty(key, JSON.stringify(data));
}

// 簡易的なユニークIDを生成する
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

// 通知履歴を追加する関数
function addNotificationHistory(companyName, type, amount, targetName) {
    const allHistory = loadData(KEYS.NOTIFICATIONS_HISTORY, {});
    if (!allHistory[companyName]) allHistory[companyName] = [];

    // 時刻取得 (Time_Settingに基づいた計算)
    const now = new Date();
    const jst = new Date(now.getTime() + (world.getDynamicProperty('Time_Setting') || 9) * 60 * 60 * 1000);

    // 月・日・時・分を2桁固定で取得
    const month = String(jst.getUTCMonth() + 1).padStart(2, '0'); // 月は0から始まるので+1
    const day = String(jst.getUTCDate()).padStart(2, '0');
    const hours = String(jst.getUTCHours()).padStart(2, '0');
    const minutes = String(jst.getUTCMinutes()).padStart(2, '0');

    // ★日付を入れたフォーマットに変更 [月/日 時:分]
    const timeStr = `§8[${month}/${day} ${hours}:${minutes}]§r `;

    // タイプ別のラベル設定
    let label = '';
    if (type === 'SEND') label = `§c[送金]§r -> §e${targetName}§r: §b${amount.toLocaleString()} PAY`;
    if (type === 'RECEIVE') label = `§a[受取]§r <- §e${targetName}§r: §b${amount.toLocaleString()} PAY`;
    if (type === 'SALE') label = `§6[売上]§r <- §e${targetName}§r: §b${amount.toLocaleString()} PAY`;

    allHistory[companyName].unshift(timeStr + label);
    if (allHistory[companyName].length > MAX_HISTORY) {
        allHistory[companyName] = allHistory[companyName].slice(0, MAX_HISTORY);
    }
    saveData(KEYS.NOTIFICATIONS_HISTORY, allHistory);
}

// --- 注文データ（チャンキング対応） ---
function loadAllOrders() {
    const meta = loadData(KEYS.ORDERS_META, { chunkCount: 1 });
    const allOrders = {};
    for (let i = 0; i < meta.chunkCount; i++) {
        const chunkKey = `${KEYS.ORDERS_PREFIX}${i}`;
        const chunkData = loadData(chunkKey, {});
        Object.assign(allOrders, chunkData);
    }
    return allOrders;
}

function saveAllOrders(allOrders) {
    // 1. 古いチャンクを一旦すべて削除する
    const oldMeta = loadData(KEYS.ORDERS_META, { chunkCount: 1 });
    for (let i = 0; i < oldMeta.chunkCount; i++) {
        world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${i}`, undefined);
    }

    // 2. 新しいチャンクを作成して保存する
    const orderEntries = Object.entries(allOrders);
    if (orderEntries.length === 0) {
        // 注文が空の場合はメタ情報だけ更新し、空のチャンクを1つ作成
        saveData(KEYS.ORDERS_META, { chunkCount: 1 });
        world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}0`, '{}');
        return;
    }

    let chunkIndex = 0;
    let currentChunk = {};
    let currentChunkString = '{}';

    for (const [orderId, orderData] of orderEntries) {
        const newChunk = { ...currentChunk, [orderId]: orderData };
        const newChunkString = JSON.stringify(newChunk);

        // 現在のチャンクが一杯になった場合 (ただし、チャンクが空の場合は必ず1つは要素を入れる)
        if (newChunkString.length > MAX_CHUNK_SIZE && Object.keys(currentChunk).length > 0) {
            world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${chunkIndex}`, currentChunkString);
            chunkIndex++;
            currentChunk = { [orderId]: orderData };
            currentChunkString = JSON.stringify(currentChunk);
        } else {
            currentChunk = newChunk;
            currentChunkString = newChunkString;
        }
    }

    // 最後のチャンクを保存
    world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${chunkIndex}`, currentChunkString);

    // 3. 新しいメタ情報を保存
    saveData(KEYS.ORDERS_META, { chunkCount: chunkIndex + 1 });
}

// --- データ移行処理 ---
// 古いデータ構造から新しいデータ構造へ変換
function migrateData() {
    // 既に移行が完了している場合は何もしない
    if (world.getDynamicProperty(KEYS.MIGRATION_FLAG)) {
        return;
    }

    console.log('[Advance] Starting data migration...');

    const oldMembers = world.getDynamicProperty('advance_member');
    const oldShops = world.getDynamicProperty('advance_shop');
    // 古いadv_ordersもチェック
    const oldOrdersDirect = world.getDynamicProperty('adv_orders');

    const newCompanies = {};
    const newProducts = {};
    const newOrders = {};

    // advance_memberの移行
    if (oldMembers) {
        try {
            const members = JSON.parse(oldMembers);
            for (const member of members) {
                // [playerName, companyName, companyDetails, assets, []]
                const companyName = member[1];
                if (companyName) {
                    newCompanies[companyName] = {
                        owner: member[0],
                        details: member[2],
                        assets: member[3] || 0,
                        members: [member[0]],
                    };
                }
            }
        } catch (e) {
            console.error(`[Advance] Failed to migrate 'advance_member': ${e}`);
        }
    }

    // advance_shopの移行
    if (oldShops) {
        try {
            const shops = JSON.parse(oldShops);
            for (const shop of shops) {
                // [companyName, [products...]]
                const companyName = shop[0];
                const productList = shop[1];

                for (const product of productList) {
                    // [productName, price, stock, orders[], ?]
                    const productId = generateId();
                    newProducts[productId] = {
                        companyName: companyName,
                        name: product[0],
                        price: Number(product[1]) || 0,
                        stock: Number(product[2]) || 0,
                    };

                    // 注文履歴の移行
                    const oldOrders = product[3] || [];
                    for (const order of oldOrders) {
                        // [buyerName, quantity, status (0 or 1)]
                        const orderId = generateId();
                        newOrders[orderId] = {
                            productId: productId,
                            productName: product[0], // 履歴表示用に商品名も保存
                            companyName: companyName,
                            buyerName: order[0],
                            quantity: Number(order[1]) || 0,
                            totalPrice: (Number(product[1]) || 0) * (Number(order[1]) || 0),
                            status: order[2] === 1 ? 'completed' : 'delivering', // 0 -> delivering, 1 -> completed
                        };
                    }
                }
            }
        } catch (e) {
            console.error(`[Advance] Failed to migrate 'advance_shop': ${e}`);
        }
    }

    // 新しいデータを保存
    saveData(KEYS.COMPANIES, newCompanies);
    saveData(KEYS.PRODUCTS, newProducts);
    // チャンキング対応の保存関数を呼び出す
    saveAllOrders(newOrders);

    // 移行完了フラグを立てる
    world.setDynamicProperty(KEYS.MIGRATION_FLAG, true);

    // 古いデータを削除
    world.setDynamicProperty('advance_member', undefined);
    world.setDynamicProperty('advance_shop', undefined);
    world.setDynamicProperty('adv_orders', undefined); // 古いordersキーも削除

    console.log('[Advance] Data migration completed successfully.');
}

// --- メイン機能 ---
export function Advance(player) {
    system.run(() => {
        // ★変更点: ここから追加
        // --- 保留中の通知を処理 ---
        const pendingNotifications = loadData(KEYS.PENDING_NOTIFICATIONS, {});
        const notificationsForPlayer = pendingNotifications[player.name];

        if (notificationsForPlayer && notificationsForPlayer.length > 0) {
            player.sendMessage('§r[§bAdvance§r] §eオフライン中の注文通知があります:');
            notificationsForPlayer.forEach(message => {
                player.sendMessage(message);
            });

            // 通知を削除して保存
            delete pendingNotifications[player.name];
            saveData(KEYS.PENDING_NOTIFICATIONS, pendingNotifications);
        }

        // ワールド参加時に一度だけデータ移行を試みる
        migrateData();

        const currentCompany = player.getDynamicProperty('advance_member_data');

        if (!currentCompany || !player.hasTag('advance_member')) {
            showLoginMenu(player);
        } else {
            showCompanyMenu(player, currentCompany);
        }
    });
}

// --- UI関数 ---

// ログイン/アカウント作成メニュー
function showLoginMenu(player) {
    const form = new ActionFormData();
    form.title('§1Advance');
    form.body('>>> §e選択してください');
    form.button('§1会社を作成', 'textures/ui/normalicon1');
    form.button('§5会社にログイン', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            createAccountUI(player);
        } else {
            loginAccountUI(player);
        }
    });
}

// アカウント作成UI
function createAccountUI(player) {
    const form = new ModalFormData();
    form.title('§1Advance');
    form.textField('§a会社名(店名)', '私の会社');
    form.textField('§b会社(店)の詳細', '様々な商品を扱っています');
    form.show(player).then(r => {
        if (r.canceled) {
            showLoginMenu(player);
            return;
        }

        const [companyName, companyDetails] = r.formValues;
        if (!companyName) {
            player.sendMessage('§r[§bAdvance§r] §c会社名を入力してください');
            showLoginMenu(player);
            return;
        }

        const companies = loadData(KEYS.COMPANIES);
        if (companies[companyName]) {
            player.sendMessage('§r[§bAdvance§r] §cこの会社名は既に使われています');
            showLoginMenu(player);
            return;
        }

        companies[companyName] = {
            owner: player.name,
            details: companyDetails,
            assets: 0,
            members: [player.name],
        };
        saveData(KEYS.COMPANIES, companies);

        player.setDynamicProperty('advance_member_data', companyName);
        player.addTag('advance_member');
        player.sendMessage('§r[§bAdvance§r] §aアカウントを作成しました');
    });
}

// ログインUI
function loginAccountUI(player) {
    const companies = loadData(KEYS.COMPANIES);
    const playerCompanies = Object.keys(companies).filter(name => companies[name].owner === player.name || companies[name].members?.includes(player.name));

    if (playerCompanies.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §cログインできるアカウントがありません');
        return;
    }

    const form = new ActionFormData();
    form.title('§1Advance');
    form.body('>>> §eアカウントを選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    playerCompanies.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showLoginMenu(player);
            return;
        }
        const selectedCompany = playerCompanies[r.selection - 1];
        player.setDynamicProperty('advance_member_data', selectedCompany);
        player.addTag('advance_member');
        player.sendMessage('§r[§bAdvance§r] §aログインしました');
        Advance(player);
    });
}

// 会社運営メニュー
function showCompanyMenu(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];

    if (!company) {
        player.sendMessage('§r[§bAdvance§r] §c会社情報が見つかりません.自動的にログアウトします');
        player.removeTag('advance_member');
        player.setDynamicProperty('advance_member_data', undefined);
        Advance(player);
        return;
    }

    // companyデータにmembersプロパティが存在しない場合、オーナーをメンバーとして追加する
    let needsDataSave = false;
    if (!company.members || !Array.isArray(company.members)) {
        company.members = [company.owner]; // オーナーを最初のメンバーとして設定
        needsDataSave = true;
    }
    // もしデータを修正した場合は、ここで保存する
    if (needsDataSave) {
        saveData(KEYS.COMPANIES, companies);
    }

    const form = new ActionFormData();
    form.title('§1Advance');
    form.body(`§rアカウント:§b${companyName}`);
    form.button('§4ログアウト', 'textures/ui/icon_import.png');
    form.button('§0取引履歴 ', 'textures/ui/normalicon1');
    form.button('§1配送管理', 'textures/ui/normalicon1');
    form.button(`§9送金\n§0資産:§3${company.assets.toLocaleString()}`, 'textures/ui/normalicon1');
    form.button('§5商品編集', 'textures/ui/normalicon1');
    form.button('§0アカウントの管理', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0: // ログアウト
                player.removeTag('advance_member');
                player.setDynamicProperty('advance_member_data', undefined);
                player.sendMessage('§r[§bAdvance§r] §aログアウトしました');
                Advance(player);
                break;
            case 1:
                showNotificationHistoryUI(player, companyName);
                break;
            case 2: // 配送管理
                deliveryManagementUI(player, companyName);
                break;
            case 3: // 資産送信
                sendAssetsUI(player, companyName);
                break;
            case 4: // 商品管理
                productManagementUI(player, companyName);
                break;
            case 5: // アカウントの管理
                showAccountManagementUI(player, companyName);
                break;
        }
    });
}

// 通知一覧UI
function showNotificationHistoryUI(player, companyName) {
    const allHistory = loadData(KEYS.NOTIFICATIONS_HISTORY, {});
    const history = allHistory[companyName] || [];

    const form = new ActionFormData();
    form.title('§1取引履歴');
    form.body('>>> §e最新20件');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.label(history.length === 0 ? '通知はありません' : history.join('\n\n'));

    form.show(player).then(r => {
        if (r.selection === 0) showCompanyMenu(player, companyName);
    });
}

// 配送管理UI
function deliveryManagementUI(player, companyName) {
    const allOrders = loadAllOrders();
    const pendingOrders = Object.entries(allOrders)
        .filter(([id, order]) => order.companyName === companyName && order.status === 'delivering')
        .sort(([idA], [idB]) => parseInt(idB, 36) - parseInt(idA, 36)); // 新しい順にソート

    if (pendingOrders.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c配送未完了の商品がありません');
        showCompanyMenu(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§1配送管理');
    form.body('>>> §e詳細を確認・処理したい注文を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    pendingOrders.forEach(([id, order]) => {
        // ボタンのテキストが長くなりすぎないように調整
        const postIndicator = order.deliveryPost ? ' §4(ポスト有)' : '';
        form.button(`§1${order.productName}§r\n§0TO: §9${order.buyerName}${postIndicator}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showCompanyMenu(player, companyName);
            return;
        }
        const [orderIdToShow] = pendingOrders[r.selection - 1];
        showDeliveryConfirmationUI(player, companyName, orderIdToShow);
    });
}

// 特定のアイテムを所持しているかチェックする関数
function hasRequiredPostItem(player) {
    const inventory = player.getComponent('minecraft:inventory').container;
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        // アイテムIDが 'additem:post' かどうかを確認
        if (item && item.typeId === 'additem:post') {
            return true;
        }
    }
    return false;
}

function showDeliveryConfirmationUI(player, companyName, orderId) {
    const allOrders = loadAllOrders();
    const order = allOrders[orderId];

    if (!order || order.status !== 'delivering') {
        player.sendMessage('§r[§bAdvance§r] §cこの注文は既に処理されているか、存在しません');
        deliveryManagementUI(player, companyName); 
        return;
    }

    const postInfo = order.deliveryPost ? `\n§r配送先ポスト: §d${order.deliveryPost}` : '\n§r(ポスト指定なし)';
    const body = `§l§e注文詳細\n\n` + `§r商品名: §a${order.productName}\n` + `§r購入者: §9${order.buyerName}\n` + `§r個数: §a${order.quantity}\n` + `§r合計金額: §b${order.totalPrice.toLocaleString()}` + postInfo;

    const form = new ActionFormData();
    form.title('§5注文内容の確認');
    form.body(body);

    const buttons = [];

    form.button('§1この配送を完了にする', 'textures/ui/normalicon1');
    buttons.push('COMPLETE');

    if (order.deliveryPost) {
        form.button('§0ポストを開く', 'textures/items/post');
        buttons.push('POST');
    }

    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttons.push('BACK');

    form.show(player).then(r => {
        if (r.canceled) return;

        const selectedAction = buttons[r.selection];

        if (selectedAction === 'BACK') {
            deliveryManagementUI(player, companyName); // 戻る処理
            return;
        }

        system.run(() => {
            const latestOrders = loadAllOrders();

            if (selectedAction === 'COMPLETE') {
                if (latestOrders[orderId] && latestOrders[orderId].status === 'delivering') {
                    latestOrders[orderId].status = 'completed';
                    saveAllOrders(latestOrders);
                    player.sendMessage('§r[§bAdvance§r] §a配送を完了しました');
                    deliveryManagementUI(player, companyName);
                }
            } else if (selectedAction === 'POST') {
                if (hasRequiredPostItem(player)) {
                    startAdvanceDeliveryFlow(player, order);
                } else {
                    player.sendMessage('§r[§bAdvance§r] §cこの操作にはポストアイテムが必要です');
                    showDeliveryConfirmationUI(player, companyName, orderId); 
                }
            }
        });
    });
}

// 商品管理UI (追加/編集/削除の選択)
function productManagementUI(player, companyName) {
    const form = new ActionFormData();
    form.title('§1商品管理');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1追加', 'textures/ui/normalicon1');
    form.button('§0編集', 'textures/ui/normalicon1');
    form.button('§5削除', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                showCompanyMenu(player, companyName);
                break;
            case 1:
                addProductUI(player, companyName);
                break;
            case 2:
                editProductListUI(player, companyName);
                break;
            case 3:
                deleteProductListUI(player, companyName);
                break;
        }
    });
}

// 商品追加UI
function addProductUI(player, companyName) {
    const form = new ModalFormData();
    form.title('§1商品の追加');
    form.textField('§a商品名', 'ダイヤモンド');
    form.textField('§e金額', '1000');
    form.textField('§b在庫数', '64');
    form.textField('§dジャンル(任意)', '食料');
    form.show(player).then(r => {
        if (r.canceled) {
            productManagementUI(player, companyName);
            return;
        }

        const [name, priceStr, stockStr, genreInput] = r.formValues;
        const price = parseFloat(priceStr);
        const stock = parseInt(stockStr, 10);
        const genre = genreInput && genreInput.trim() !== '' ? genreInput.trim() : 'その他';

        if (!name || isNaN(price) || isNaN(stock) || price < 0 || stock < 0) {
            player.sendMessage('§r[§bAdvance§r] §c入力内容が正しくありません');
            return;
        }

        const products = loadData(KEYS.PRODUCTS);
        const productId = generateId();
        products[productId] = { companyName, name, price, stock, genre };
        saveData(KEYS.PRODUCTS, products);

        player.sendMessage('§r[§bAdvance§r] §a商品を追加しました');
    });
}

// 編集する商品を選択するUI
function editProductListUI(player, companyName) {
    const allProducts = loadData(KEYS.PRODUCTS);
    const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === companyName);

    if (companyProducts.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c編集可能な商品がありません');
        return;
    }

    const form = new ActionFormData();
    form.title('§0商品の編集');
    form.body('>>> §e編集する商品を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyProducts.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額: §9${product.price} §0在庫: §2${product.stock}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            productManagementUI(player, companyName);
            return;
        }
        const [productId, productToEdit] = companyProducts[r.selection - 1];
        editProductUI(player, productId, productToEdit, companyName);
    });
}

// 商品編集UI
function editProductUI(player, productId, product, companyName) {
    const form = new ModalFormData();
    form.title('§1商品の編集');
    form.textField('§a商品名', '', {
        defaultValue: product.name,
    });
    form.textField('§e金額', '', {
        defaultValue: product.price.toString(),
    });
    form.textField('§b在庫数', '', {
        defaultValue: product.stock.toString(),
    });
    form.textField('§dジャンル(任意)', '', {
        defaultValue: product.genre || 'その他',
    });
    form.show(player).then(r => {
        if (r.canceled) {
            editProductListUI(player, companyName);
            return;
        }

        const [name, priceStr, stockStr, genreInput] = r.formValues;
        const price = parseFloat(priceStr);
        const stock = parseInt(stockStr, 10);
        const genre = genreInput && genreInput.trim() !== '' ? genreInput.trim() : 'その他';

        if (!name || isNaN(price) || isNaN(stock) || price < 0 || stock < 0) {
            player.sendMessage('§r[§bAdvance§r] §c入力内容が正しくありません');
            return;
        }

        // --- 操作直前の再検証 ---
        const latestProducts = loadData(KEYS.PRODUCTS);
        if (latestProducts[productId]) {
            latestProducts[productId] = { ...latestProducts[productId], name, price, stock, genre };
            saveData(KEYS.PRODUCTS, latestProducts);
            player.sendMessage('§r[§bAdvance§r] §a商品を編集しました');
        } else {
            player.sendMessage('§r[§bAdvance§r] §cエラー: 編集しようとした商品は既に削除されています');
        }
        editProductListUI(player, companyName);
    });
}

// 削除する商品を選択するUI
function deleteProductListUI(player, companyName) {
    const allProducts = loadData(KEYS.PRODUCTS);
    const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === companyName);

    if (companyProducts.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c削除可能な商品がありません');
        return;
    }

    const form = new ActionFormData();
    form.title('§4商品の削除');
    form.body('>>> §e削除する商品を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyProducts.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額: §9${product.price}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            productManagementUI(player, companyName);
            return;
        }

        const [productIdToDelete] = companyProducts[r.selection - 1];

        // --- 操作直前の再検証 ---
        const latestProducts = loadData(KEYS.PRODUCTS);
        const latestOrders = loadAllOrders();

        if (!latestProducts[productIdToDelete]) {
            player.sendMessage('§r[§bAdvance§r] §cエラー: この商品は既に削除されています');
            return;
        }

        const hasPendingOrders = Object.values(latestOrders).some(order => order.productId === productIdToDelete && order.status === 'delivering');

        if (hasPendingOrders) {
            player.sendMessage('§r[§bAdvance§r] §c選択した商品の配送がすべて完了していません');
            deleteProductListUI(player, companyName);
            return;
        }

        delete latestProducts[productIdToDelete];
        saveData(KEYS.PRODUCTS, latestProducts);

        player.sendMessage('§r[§bAdvance§r] §a商品を削除しました');
        deleteProductListUI(player, companyName);
    });
}

// 資産をHARUPAY (個人のmoneyスコア) に送信するUI
function sendAssetsUI(player, companyName) {
    // 自分以外の全プレイヤーを取得
    const otherPlayers = world.getAllPlayers();

    if (otherPlayers.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c送金対象となる他のプレイヤーがサーバーにいません');
        return;
    }

    // --- ステップ1: 送金相手の選択 ---
    const form = new ActionFormData();
    form.title('§0資産の送信');
    form.body('>>> §e送り先のプレイヤーを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    otherPlayers.forEach(p => {
        form.button(`§1${p.name}\n§5>>>§0${p.id}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showCompanyMenu(player, companyName);
            return;
        }
        const targetPlayer = otherPlayers[r.selection - 1];

        // --- ステップ2: 送金額の入力 ---
        // 画面表示用に現在の資産を取得
        const companies = loadData(KEYS.COMPANIES);
        // 会社が存在しないケースを考慮
        const currentAssets = companies[companyName]?.assets ?? 0;

        const amountForm = new ModalFormData();
        amountForm.title(`§1${targetPlayer.name} §0への送金`);
        amountForm.textField(`§r§b送金額§r(半角数字)を入力してください\n\n` + `§r現在の会社資産: §a${currentAssets.toLocaleString()}`, '0');

        amountForm.show(player).then(r2 => {
            if (r2.canceled) {
                sendAssetsUI(player, companyName);
                return;
            }

            const amountStr = r2.formValues[0];
            const amount = parseInt(amountStr, 10);

            // --- ステップ3: 入力値のバリデーション ---
            if (isNaN(amount) || amountStr === '') {
                player.sendMessage('§r[§bAdvance§r] §c半角数字で金額を入力してください');
                return;
            }
            if (amount <= 0) {
                player.sendMessage('§r[§bAdvance§r] §c送金額は0より大きい値を設定してください');
                return;
            }
            if (amount > 100000000) {
                // 上限チェック
                player.sendMessage('§r[§bAdvance§r] §c一度に送金できる上限は1億です');
                return;
            }

            // --- ステップ4: 最終確認と送金処理 (※ここが最も重要) ---
            // 処理の直前に最新のデータを読み込み、競合状態を防ぐ
            system.run(() => {
                const latestCompanies = loadData(KEYS.COMPANIES);
                const company = latestCompanies[companyName];

                // 会社データの存在チェック
                if (!company) {
                    player.sendMessage('§r[§bAdvance§r] §cエラー: 会社情報が見つかりませんでした');
                    return;
                }

                // 資産残高の最終チェック
                if (company.assets < amount) {
                    player.sendMessage(`§r[§bAdvance§r] §c会社の資産が不足しています。(現在の資産: ${company.assets.toLocaleString()})`);
                    return;
                }

                // --- 全てのチェックを通過したら処理を実行 ---
                // 会社の資産を減らす
                company.assets -= amount;
                saveData(KEYS.COMPANIES, latestCompanies);
                addNotificationHistory(companyName, 'SEND', amount, targetPlayer.name);

                // 相手の所持金を増やす
                targetPlayer.runCommand(`scoreboard players add @s money ${amount}`);

                // 通知メッセージ
                player.sendMessage(`§r[§bAdvance§r] §b${targetPlayer.name}§a へ §b${amount.toLocaleString()}§a 送信しました`);
                targetPlayer.sendMessage(`§r[§bAdvance§r] §b${companyName}§a(${player.name}) から §b${amount.toLocaleString()}§a 受け取りました`);
            });
        });
    });
}

// -----------------------------------------------------------------
// --- 購入者向け機能 ---
// -----------------------------------------------------------------

export function showAdvanceBuyerMenu(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    const isRecommendEnabled = world.getDynamicProperty('adv_recommend_enabled') !== false;

    const form = new ActionFormData();
    form.title('§1Advance');
    form.body(`§b§l${time}`);
    const actions = [];

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    actions.push(() => HARUPhone1(player));

    form.label('>>> §e商品を見つける');
    form.button('§0キーワードから探す', 'textures/ui/normalicon1');
    actions.push(() => searchByKeywordUI(player));

    form.button('§1会社から探す', 'textures/ui/normalicon1');
    actions.push(() => searchByCompanyUI(player));

    if (isRecommendEnabled) {
        form.button('§5おすすめから探す', 'textures/ui/normalicon1');
        actions.push(() => searchByRecommendUI(player));
    }

    form.label('>>> §b管理');
    form.button('§1注文した商品の配送状況', 'textures/ui/normalicon1');
    actions.push(() => showDeliveryStatusUI(player));

    form.button('§9会社へ送金', 'textures/ui/pay');
    actions.push(() => payToCompanyUI(player));

    form.show(player).then(r => {
        if (r.canceled) return;
        actions[r.selection]();
    });
}

// キーワード検索UI
function searchByKeywordUI(player) {
    const form = new ModalFormData();
    form.title('§0キーワード検索');
    form.textField('§a検索したい商品名を入力', 'ダイヤモンド');
    form.show(player).then(r => {
        if (r.canceled || !r.formValues[0]) {
            showAdvanceBuyerMenu(player);
            return;
        }
        const keyword = r.formValues[0];
        const allProducts = loadData(KEYS.PRODUCTS);

        const searchResults = Object.entries(allProducts).filter(([id, product]) => {
            const matchName = product.name.includes(keyword);
            const matchGenre = (product.genre || '').includes(keyword); // genreが存在しない古いデータ対策
            return (matchName || matchGenre) && product.stock > 0;
        });

        if (searchResults.length === 0) {
            player.sendMessage('§r[§bAdvance§r] §c商品が見つかりませんでした');
            return;
        }

        showProductListUI(player, searchResults, '§0検索結果', true);
    });
}

// おすすめから探すUI
function searchByRecommendUI(player) {
    const allProducts = loadData(KEYS.PRODUCTS);

    // 在庫がある商品だけを抽出
    const availableProducts = Object.entries(allProducts).filter(([id, product]) => product.stock > 0);

    if (availableProducts.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c現在販売中の商品がありません');
        showAdvanceBuyerMenu(player);
        return;
    }

    const shuffled = availableProducts.sort(() => 0.5 - Math.random());
    const recommendProducts = shuffled.slice(0, 10);
    showProductListUI(player, recommendProducts, '§5おすすめの商品', 'recommend');
}

// 会社指定での検索UI
function searchByCompanyUI(player) {
    const companies = loadData(KEYS.COMPANIES);
    const companyNames = Object.keys(companies);

    if (companyNames.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c現在営業中の会社がありません');
        return;
    }

    const form = new ActionFormData();
    form.title('§1会社から探す');
    form.body('>>> §e会社を選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyNames.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showAdvanceBuyerMenu(player);
            return;
        }
        const selectedCompany = companyNames[r.selection - 1];
        const allProducts = loadData(KEYS.PRODUCTS);

        const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === selectedCompany && product.stock > 0);

        if (companyProducts.length === 0) {
            player.sendMessage(`§r[§bAdvance§r] §c${selectedCompany} は現在商品を販売していません`);
            return;
        }

        const genres = [...new Set(companyProducts.map(([id, product]) => product.genre || 'その他'))];

        if (genres.length > 1) {
            selectGenreUI(player, selectedCompany, companyProducts, genres);
        } else {
            showProductListUI(player, companyProducts, `§5${selectedCompany} §0の商品`);
        }
    });
}

// ジャンル選択UI
function selectGenreUI(player, companyName, allCompanyProducts, genres) {
    const form = new ActionFormData();
    form.title(`§5${companyName} §0のジャンル`);
    form.body('>>> §eジャンルを選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    // ジャンル一覧をボタンとして追加
    genres.sort().forEach(genre => {
        form.button(`§1${genre}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            searchByCompanyUI(player); // 会社選択に戻る
            return;
        }

        const selectedGenre = genres[r.selection - 1];

        // 選択されたジャンルのみに絞り込む
        const filteredProducts = allCompanyProducts.filter(([id, product]) => {
            const pGenre = product.genre || 'その他';
            return pGenre === selectedGenre;
        });

        // 絞り込んだリストを表示
        showProductListUI(player, filteredProducts, `§5${companyName} §0> §1${selectedGenre}`, false);
    });
}

// 商品リスト表示UI
function showProductListUI(player, productList, title, search) {
    const form = new ActionFormData();
    form.title(title);
    form.body('>>> §e商品一覧');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    productList.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額:§9${product.price.toLocaleString()} §0在庫:§2${product.stock}`, 'textures/ui/normalicon1');
    });
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            if (search === 'recommend') {
                showAdvanceBuyerMenu(player);
            } else if (search) {
                searchByKeywordUI(player);
            } else {
                searchByCompanyUI(player);
            }
            return;
        }
        const [productId, selectedProduct] = productList[r.selection - 1];
        purchaseQuantityUI(player, productId, selectedProduct, productList, title, search);
    });
}

// 購入個数入力UI
function purchaseQuantityUI(player, productId, product, productList, title, search) {
    const form = new ModalFormData();
    form.title('§1購入個数の入力');
    form.textField(`§a商品名§r: §b${product.name}\n§e価格§r: §b${product.price.toLocaleString()}\n§d在庫§r: §b${product.stock}\n\n>>> §e購入数`, '1');
    form.show(player).then(r => {
        if (r.canceled) {
            showProductListUI(player, productList, title, search);
            return;
        }
        const quantity = parseInt(r.formValues[0], 10);

        if (isNaN(quantity) || quantity <= 0) {
            player.sendMessage('§r[§bAdvance§r] §c正しい個数を入力してください');
            return;
        }
        if (quantity > product.stock) {
            player.sendMessage('§r[§bAdvance§r] §c在庫数をオーバーしています');
            return;
        }

        const totalPrice = Math.round(product.price * quantity);
        const isPostIntegrationEnabled = world.getDynamicProperty('advancepost') === true;

        if (isPostIntegrationEnabled) {
            selectDeliveryPostUI(player, productId, product.companyName, product.name, quantity, totalPrice, product, productList, title, search);
        } else {
            // 従来通り、ポスト指定なしで確認画面へ
            confirmPurchaseUI(player, productId, product.companyName, product.name, quantity, totalPrice, null, product, productList, title, search);
        }
    });
}

// 配送先ポスト選択UI
function selectDeliveryPostUI(player, productId, companyName, productName, quantity, totalPrice, product, productList, title, search) {
    const savedPosts = world.getDynamicProperty('posts_data');
    let allPosts = [];
    try {
        if (savedPosts) allPosts = JSON.parse(savedPosts);
    } catch (e) {}

    const myPosts = allPosts.filter(p => p.owner === player.name);

    if (myPosts.length === 0) {
        confirmPurchaseUI(player, productId, companyName, productName, quantity, totalPrice, null, product, productList, title, search);
        return;
    }

    const form = new ActionFormData();
    form.title('§1配送先のポストを選択');
    form.body('>>> §e商品を届けてほしいポストを選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§5ポストを指定しない', 'textures/ui/normalicon1'); // ポストを指定しない選択肢
    myPosts.forEach(post => {
        form.button(`§1${post.name}`, 'textures/items/post');
    });

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            purchaseQuantityUI(player, productId, product, productList, title, search);
            return;
        }

        let selectedPostName = null;
        if (r.selection > 1) {
            selectedPostName = myPosts[r.selection - 2].name;
        }

        confirmPurchaseUI(player, productId, companyName, productName, quantity, totalPrice, selectedPostName, product, productList, title, search);
    });
}

// 購入確認UI
function confirmPurchaseUI(player, productId, companyName, productName, quantity, totalPrice, deliveryPostName, product, productList, title, search) {
    // 販売会社のメンバーがオンラインか確認する
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    const onlinePlayerNames = world.getAllPlayers().map(p => p.name);
    let offlineWarningMessage = ''; // 警告メッセージ用の変数

    // 会社のメンバー情報を確認し、誰もオンラインでない場合は警告メッセージを作成する
    if (company && company.members) {
        const isAnyMemberOnline = company.members.some(member => onlinePlayerNames.includes(member));
        if (!isAnyMemberOnline) {
            offlineWarningMessage = '\n\n§e【注意】\n§cこの会社のメンバーは現在オフライン\n商品の配送や対応が遅れる可能性があります\n§a(購入はそのまま可能です)§r';
        }
    }

    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;
    const deliveryPostInfo = deliveryPostName ? `§r配送先ポスト: §d${deliveryPostName}\n\n` : '';
    const form = new ActionFormData();
    form.title('§5注文内容の確認');
    form.body(`§l§e注文内容\n\n` + `§r商品名: §a${productName}\n` + `§r個数: §a${quantity}\n` + `§r合計金額: §b${totalPrice.toLocaleString()}\n\n` + `§r販売元: §a${companyName}\n\n` + deliveryPostInfo + `§r現在の所持金: §e${score.toLocaleString()}\n` + `${score < totalPrice ? '§c所持金が不足しています' : ''}` + offlineWarningMessage);
    form.button('§1注文を確定する', 'textures/ui/normalicon1');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        if (r.selection === 1) {
            purchaseQuantityUI(player, productId, product, productList, title, search);
            return;
        }
        system.run(() => {
            const latestProducts = loadData(KEYS.PRODUCTS);
            const latestCompanies = loadData(KEYS.COMPANIES);
            const latestProduct = latestProducts[productId];
            const currentScore = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

            // 1. 商品が存在し、会社も存在するか
            if (!latestProduct || !latestCompanies[companyName]) {
                player.sendMessage('§r[§bAdvance§r] §cエラー: 商品または会社情報が見つかりません');
                return;
            }
            // 2. 所持金は足りているか
            if (currentScore < totalPrice) {
                player.sendMessage('§r[§bAdvance§r] §c所持金が不足しています');
                return;
            }
            // 3. 在庫は足りているか
            if (latestProduct.stock < quantity) {
                player.sendMessage('§r[§bAdvance§r] §c申し訳ありません。他の方が先に購入したため在庫が不足しています');
                return;
            }

            // --- 全ての検証をクリアした場合のみ、処理を実行 ---
            // 在庫を減らす
            latestProducts[productId].stock -= quantity;
            // 会社資産を増やす
            latestCompanies[companyName].assets += totalPrice;
            addNotificationHistory(companyName, 'SALE', totalPrice, `${player.name} (${productName})`);
            // 注文履歴を作成
            const orders = loadAllOrders();
            const orderId = generateId();
            orders[orderId] = {
                productId: productId,
                productName: productName,
                companyName: companyName,
                buyerName: player.name,
                quantity: quantity,
                totalPrice: totalPrice,
                status: 'delivering',
                deliveryPost: deliveryPostName,
            };

            // データを保存
            saveData(KEYS.PRODUCTS, latestProducts);
            saveData(KEYS.COMPANIES, latestCompanies);
            saveAllOrders(orders);

            // プレイヤーの所持金を減らす
            player.runCommand(`scoreboard players remove @s money ${totalPrice}`);

            player.sendMessage('§r[§bAdvance§r] §a商品を注文しました');

            // オーナーへの通知処理
            const companyMembers = latestCompanies[companyName]?.members || [];
            if (companyMembers.length > 0) {
                const notificationMessage = `§r[§bAdvance§r] §b${productName}§r(${quantity}個):§e${companyName}§rが§a${player.name}§rによって注文されました`;
                const allPlayers = world.getAllPlayers();
                const pendingNotifications = loadData(KEYS.PENDING_NOTIFICATIONS, {});

                companyMembers.forEach(memberName => {
                    const memberPlayer = allPlayers.find(p => p.name === memberName);

                    if (memberPlayer) {
                        // メンバーがオンラインの場合
                        memberPlayer.sendMessage(notificationMessage);
                    } else {
                        // メンバーがオフラインの場合
                        if (!pendingNotifications[memberName]) {
                            pendingNotifications[memberName] = [];
                        }
                        pendingNotifications[memberName].push(notificationMessage);
                    }
                });
                // オフライン通知を保存
                saveData(KEYS.PENDING_NOTIFICATIONS, pendingNotifications);
            }
        });
    });
}

// 配送状況確認UI
function showDeliveryStatusUI(player) {
    const allOrders = loadAllOrders();
    const myOrders = Object.entries(allOrders).filter(([id, order]) => order.buyerName === player.name);

    if (myOrders.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c注文履歴がありません');
        return;
    }

    // 新しい順にソート
    myOrders.sort(([idA], [idB]) => parseInt(idB, 36) - parseInt(idA, 36));

    let body = '§l注文履歴\n\n§r';
    myOrders.forEach(([id, order]) => {
        const statusText = order.status === 'completed' ? '§a配送完了' : '§9配送中';
        body += `商品名: §b${order.productName}§r\n個数: §a${order.quantity} §r| ${statusText}§r\n- - - - -\n`;
    });

    const form = new ActionFormData();
    form.title('§0配送状況');
    form.body(body);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4完了済み履歴をクリア', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showAdvanceBuyerMenu(player);
            return;
        }
        if (r.selection === 1) {
            // 完了済み履歴をクリアする処理
            let orders = loadAllOrders();
            let clearedCount = 0;
            for (const id in orders) {
                const order = orders[id];
                if (order.buyerName === player.name && order.status === 'completed') {
                    delete orders[id];
                    clearedCount++;
                }
            }

            if (clearedCount > 0) {
                saveAllOrders(orders);
                player.sendMessage(`§r[§bAdvance§r] §a完了済みの注文履歴を${clearedCount}件削除しました`);
            } else {
                player.sendMessage('§r[§bAdvance§r] §c削除できる完了済みの履歴がありません');
            }
        }
    });
}

// =================================================================
// --- 会社へ送金機能 ---
// =================================================================

// 送金先会社選択UI
function payToCompanyUI(player) {
    const companies = loadData(KEYS.COMPANIES);
    const companyNames = Object.keys(companies);

    if (companyNames.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c現在登録されている会社がありません');
        showAdvanceBuyerMenu(player);
        return;
    }

    const form = new ActionFormData();
    form.title('§1会社へ送金');
    form.body('>>> §e送金先の会社を選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    companyNames.forEach(name => {
        form.button(`§1${name}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showAdvanceBuyerMenu(player);
            return;
        }
        const selectedCompany = companyNames[r.selection - 1];
        payToCompanyAmountUI(player, selectedCompany);
    });
}

// 送金額入力UI
function payToCompanyAmountUI(player, companyName) {
    const currentScore = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

    const form = new ModalFormData();
    form.title(`§1${companyName} §0へ送金`);
    form.textField(`§r現在の所持金: §a${currentScore.toLocaleString()} PAY\n\n§r送金額を入力してください（半角数字）`, '0');
    form.submitButton(`§1確認画面へ`);

    form.show(player).then(r => {
        if (r.canceled) {
            payToCompanyUI(player); // キャンセルで会社選択に戻る
            return;
        }

        const input = r.formValues[0];
        if (input === '' || isNaN(input)) {
            player.sendMessage(`§r[§bAdvance§r] §c半角数字で入力してください`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
            payToCompanyAmountUI(player, companyName); // 再表示
            return;
        }

        const amount = Number(input);
        if (!Number.isInteger(amount)) {
            player.sendMessage(`§r[§bAdvance§r] §c整数で入力してください`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
            payToCompanyAmountUI(player, companyName);
            return;
        }

        if (amount <= 0) {
            player.sendMessage(`§r[§bAdvance§r] §c0以下の金額は設定できません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
            payToCompanyAmountUI(player, companyName);
            return;
        }

        if (amount > 100000000) {
            player.sendMessage(`§r[§bAdvance§r] §c送金額が上限（1億）を超過しています`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
            payToCompanyAmountUI(player, companyName);
            return;
        }

        if (amount > currentScore) {
            player.sendMessage(`§r[§bAdvance§r] §c所持金が不足しています`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
            payToCompanyAmountUI(player, companyName);
            return;
        }

        payToCompanyConfirmUI(player, companyName, amount);
    });
}

// 送金確認および実行UI
function payToCompanyConfirmUI(player, companyName, amount) {
    const currentScore = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

    const form = new ActionFormData();
    form.title('§5送金内容の確認');
    form.body(`§a送金先§r: §b${companyName}\n` + `§e送金額§r: §b${amount.toLocaleString()} PAY\n\n` + `§e================\n` + `§r現在の所持金: §u${currentScore.toLocaleString()} PAY\n` + `§r送金後の所持金: §b${(currentScore - amount).toLocaleString()} PAY\n` + `§e================`);
    form.button(`§1送金を実行`, 'textures/ui/normalicon1');
    form.button(`§lキャンセル`, 'textures/ui/icon_import.png');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 1) {
            payToCompanyUI(player); // キャンセルで会社選択に戻る
            return;
        }

        if (r.selection === 0) {
            system.run(() => {
                const latestBalance = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

                if (latestBalance >= amount) {
                    const latestCompanies = loadData(KEYS.COMPANIES);
                    const company = latestCompanies[companyName];

                    if (!company) {
                        player.sendMessage(`§r[§bAdvance§r] §cエラー: 送金先の会社が存在しません`);
                        return;
                    }

                    // プレイヤーの所持金を減らす
                    player.runCommand(`scoreboard players remove @s money ${amount}`);

                    // 会社の資産を増やす
                    company.assets += amount;
                    saveData(KEYS.COMPANIES, latestCompanies);

                    // プレイヤーへの完了メッセージと音
                    player.sendMessage(`§r[§bAdvance§r] §a${companyName}§r に §b${amount.toLocaleString()} PAY§r を送金しました`);
                    player.playSound('haru.notification1', { pitch: 1.7, volume: 1.0 });

                    // 会社のメンバーへの通知（オンライン/オフライン両対応）
                    const companyMembers = company.members || [];
                    if (companyMembers.length > 0) {
                        const notificationMessage = `§r[§bAdvance§r] §a${player.name}§r から会社(§e${companyName}§r)へ §b${amount.toLocaleString()} PAY§r の送金がありました`;
                        const allPlayers = world.getAllPlayers();
                        const pendingNotifications = loadData(KEYS.PENDING_NOTIFICATIONS, {});

                        companyMembers.forEach(memberName => {
                            const memberPlayer = allPlayers.find(p => p.name === memberName);

                            if (memberPlayer) {
                                memberPlayer.sendMessage(notificationMessage);
                                memberPlayer.playSound('haru.notification1', { pitch: 1.7, volume: 1.0 });
                            } else {
                                if (!pendingNotifications[memberName]) {
                                    pendingNotifications[memberName] = [];
                                }
                                pendingNotifications[memberName].push(notificationMessage);
                            }
                        });
                        // オフライン通知を保存
                        saveData(KEYS.PENDING_NOTIFICATIONS, pendingNotifications);
                        // 通知履歴に追加
                        addNotificationHistory(companyName, 'RECEIVE', amount, player.name);
                    }
                } else {
                    player.sendMessage(`§r[§bAdvance§r] §c残高が不足しています`);
                    player.playSound('haru.notification1', { pitch: 0.8, volume: 1.0 });
                    payToCompanyAmountUI(player, companyName); // 不足時は入力画面に戻す
                }
            });
        }
    });
}

// --- アカウント管理機能 ---

// アカウント管理メニューUI
function showAccountManagementUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    // オーナーのみが特定の操作を行えるようにチェック
    const isOwner = company.owner === player.name;

    const form = new ActionFormData();
    form.title('§0アカウントの管理');
    form.body('>>> §e選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§1アカウント名の編集', 'textures/ui/normalicon1');
    form.button('§4アカウントの削除', 'textures/ui/normalicon1');
    form.button('§2共同メンバーの管理', 'textures/ui/normalicon1');
    if (isOwner) {
        form.button('§0オーナー権限の譲渡', 'textures/ui/normalicon1');
    }

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                showCompanyMenu(player, companyName);
                break;
            case 1:
                editCompanyNameUI(player, companyName);
                break;
            case 2:
                deleteCompanyConfirmUI(player, companyName);
                break;
            case 3:
                manageMembersUI(player, companyName);
                break;
            case 4:
                if (isOwner) {
                    transferOwnershipUI(player, companyName);
                }
                break;
        }
    });
}

// オーナー権限譲渡UI
function transferOwnershipUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];

    // オーナー自身は譲渡先リストから除外
    const potentialNewOwners = (company.members || []).filter(m => m !== player.name);

    if (potentialNewOwners.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c譲渡可能な他のメンバーがいません');
        showAccountManagementUI(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§0オーナー権限の譲渡');
    form.body('>>> §e新しいオーナーを選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    potentialNewOwners.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            showAccountManagementUI(player, companyName);
            return;
        }

        const newOwnerName = potentialNewOwners[r.selection - 1];

        // 確認UI
        const confirmForm = new ActionFormData();
        confirmForm.title('§4最終確認');
        confirmForm.body(`§c本当にオーナー権限を §b${newOwnerName} §cに譲渡しますか？\n§cこの操作は取り消せません`);
        confirmForm.button('§4譲渡を実行する', 'textures/ui/normalicon1');
        confirmForm.button('§lキャンセル', 'textures/ui/icon_import.png');

        confirmForm.show(player).then(r2 => {
            if (r2.canceled || r2.selection === 1) {
                showAccountManagementUI(player, companyName);
                return;
            }

            system.run(() => {
                const latestCompanies = loadData(KEYS.COMPANIES);
                if (latestCompanies[companyName]) {
                    latestCompanies[companyName].owner = newOwnerName;
                    saveData(KEYS.COMPANIES, latestCompanies);
                    player.sendMessage(`§r[§bAdvance§r] §aオーナー権限を ${newOwnerName} に譲渡しました`);

                    // 新しいオーナーに通知
                    const newOwnerPlayer = world.getAllPlayers().find(p => p.name === newOwnerName);
                    if (newOwnerPlayer) {
                        newOwnerPlayer.sendMessage(`§r[§bAdvance§r] §eあなたは ${companyName} の新しいオーナーになりました`);
                    }
                }
            });
        });
    });
}

// アカウント名（会社名）編集UI
function editCompanyNameUI(player, oldCompanyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[oldCompanyName];
    // オーナーのみがメンバー管理可能
    if (company.owner !== player.name) {
        player.sendMessage('§r[§bAdvance§r] §c名変更はアカウントのオーナーのみが行えます');
        showAccountManagementUI(player, oldCompanyName);
        return;
    }

    const form = new ModalFormData();
    form.title('§1アカウント名の編集');
    form.textField('§a新しいアカウント名を入力', oldCompanyName);
    form.show(player).then(r => {
        if (r.canceled) {
            showAccountManagementUI(player, oldCompanyName);
            return;
        }

        const newCompanyName = r.formValues[0];
        if (!newCompanyName || newCompanyName === oldCompanyName) {
            player.sendMessage('§r[§bAdvance§r] §c名前が変更されていないか、無効な名前です');
            return;
        }

        system.run(() => {
            const companies = loadData(KEYS.COMPANIES);
            if (companies[newCompanyName]) {
                player.sendMessage('§r[§bAdvance§r] §cその名前は既に使用されています');
                return;
            }

            // 1. 会社情報の名前を変更
            const companyData = companies[oldCompanyName];
            delete companies[oldCompanyName];
            companies[newCompanyName] = companyData;
            saveData(KEYS.COMPANIES, companies);

            // 2. 商品情報の会社名を更新
            const products = loadData(KEYS.PRODUCTS);
            Object.values(products).forEach(product => {
                if (product.companyName === oldCompanyName) {
                    product.companyName = newCompanyName;
                }
            });
            saveData(KEYS.PRODUCTS, products);

            // 3. 注文情報の会社名を更新
            const orders = loadAllOrders();
            Object.values(orders).forEach(order => {
                if (order.companyName === oldCompanyName) {
                    order.companyName = newCompanyName;
                }
            });
            saveAllOrders(orders);

            // 4. プレイヤーのログイン情報を更新
            player.setDynamicProperty('advance_member_data', newCompanyName);

            player.sendMessage(`§r[§bAdvance§r] §a会社名を「${newCompanyName}」に変更しました`);
            showCompanyMenu(player, newCompanyName); // 新しい名前でメニューを再表示
        });
    });
}

// アカウント削除 確認UI
function deleteCompanyConfirmUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    // オーナーのみがメンバー管理可能
    if (company.owner !== player.name) {
        player.sendMessage('§r[§bAdvance§r] §c削除はアカウントのオーナーのみが行えます');
        showAccountManagementUI(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§4アカウントの削除');
    form.body(`§c本当にアカウント「${companyName}」を削除しますか？\n§cこの操作は取り消せません。関連するすべての商品も削除されます`);
    form.button('§lキャンセル', 'textures/ui/icon_import.png');
    form.button('§4削除を実行する', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            showAccountManagementUI(player, companyName);
            return;
        }

        system.run(() => {
            const products = loadData(KEYS.PRODUCTS);
            const orders = loadAllOrders();

            const companyProductIds = Object.keys(products).filter(id => products[id].companyName === companyName);
            const hasPendingOrders = Object.values(orders).some(order => companyProductIds.includes(order.productId) && order.status === 'delivering');

            if (hasPendingOrders) {
                player.sendMessage('§r[§bAdvance§r] §c未配送の注文があるため、アカウントを削除できません。すべての配送を完了してください');
                return;
            }

            // 1. 会社情報を削除
            const companies = loadData(KEYS.COMPANIES);
            delete companies[companyName];
            saveData(KEYS.COMPANIES, companies);

            // 2. 関連商品を削除
            const updatedProducts = {};
            for (const id in products) {
                if (products[id].companyName !== companyName) {
                    updatedProducts[id] = products[id];
                }
            }
            saveData(KEYS.PRODUCTS, updatedProducts);

            // 3. プレイヤーをログアウトさせる
            player.removeTag('advance_member');
            player.setDynamicProperty('advance_member_data', undefined);

            player.sendMessage('§r[§bAdvance§r] §aアカウントを削除しました');
            Advance(player);
        });
    });
}

// 共同メンバー管理メニューUI
function manageMembersUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    // オーナーのみがメンバー管理可能
    if (company.owner !== player.name) {
        player.sendMessage('§r[§bAdvance§r] §cメンバー管理はアカウントのオーナーのみが行えます');
        showAccountManagementUI(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§2共同メンバーの管理');
    form.body(`§e現在のメンバー: §b${company.members.join(', ')}`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§1メンバーを追加', 'textures/ui/normalicon1');
    form.button('§5メンバーを削除', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                showAccountManagementUI(player, companyName);
                break;
            case 1:
                addMemberUI(player, companyName);
                break;
            case 2:
                removeMemberUI(player, companyName);
                break;
        }
    });
}

// メンバー追加UI
function addMemberUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    const currentMembers = company.members || [];
    const potentialMembers = world.getAllPlayers().filter(p => !currentMembers.includes(p.name));

    if (potentialMembers.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c追加できるプレイヤーがいません');
        manageMembersUI(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§1メンバーを追加');
    form.body('>>> §e追加するプレイヤーを選択');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    potentialMembers.forEach(p => form.button(`§1${p.name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            manageMembersUI(player, companyName);
            return;
        }
        const targetPlayer = potentialMembers[r.selection - 1];
        const latestCompanies = loadData(KEYS.COMPANIES);
        if (latestCompanies[companyName]) {
            latestCompanies[companyName].members.push(targetPlayer.name);
            saveData(KEYS.COMPANIES, latestCompanies);
            player.sendMessage(`§r[§bAdvance§r] §a${targetPlayer.name} をメンバーに追加しました`);
            manageMembersUI(player, companyName);
        }
    });
}

// メンバー削除UI
function removeMemberUI(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];
    // オーナー自身は削除リストに含めない
    const removableMembers = (company.members || []).filter(m => m !== company.owner);

    if (removableMembers.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c削除できるメンバーがいません');
        manageMembersUI(player, companyName);
        return;
    }

    const form = new ActionFormData();
    form.title('§5メンバーを削除');
    form.body('>>> §e削除するメンバーを選択');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    removableMembers.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            manageMembersUI(player, companyName);
            return;
        }
        const memberNameToRemove = removableMembers[r.selection - 1];
        const latestCompanies = loadData(KEYS.COMPANIES);
        if (latestCompanies[companyName]) {
            latestCompanies[companyName].members = latestCompanies[companyName].members.filter(m => m !== memberNameToRemove);
            saveData(KEYS.COMPANIES, latestCompanies);
            player.sendMessage(`§r[§bAdvance§r] §a${memberNameToRemove} をメンバーから削除しました`);
            manageMembersUI(player, companyName);
        }
    });
}

// =================================================================
// --- 管理者用機能 ---
// =================================================================
// 管理者メインメニュー
export function AdvanceshowAdminMenu(player) {
    const form = new ActionFormData();
    form.title('§1Advance 管理者設定');
    form.body('>>> §e操作する項目を選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§0システム設定', 'textures/ui/normalicon1');
    form.button('§1会社管理', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                showAdminSystemSettingsMenu(player);
                break;
            case 2:
                showAdminCompanyListMenu(player);
                break;
        }
    });
}

// システム設定
function showAdminSystemSettingsMenu(player) {
    const isRecommendEnabled = world.getDynamicProperty('adv_recommend_enabled') !== false;

    const form = new ActionFormData();
    form.title('§0システム設定');
    form.body('>>> §e設定を変更する項目を選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button(`§0おすすめ機能\n(${isRecommendEnabled ? '§1有効' : '§4無効'}§0)`, 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            AdvanceshowAdminMenu(player);
            return;
        }
        if (r.selection === 1) {
            const newState = !isRecommendEnabled;
            world.setDynamicProperty('adv_recommend_enabled', newState);

            player.sendMessage(`§r[§bAdvance§r] §aおすすめ機能を ${newState ? '§b有効' : '§c無効'} §aに変更しました`);
            showAdminSystemSettingsMenu(player);
        }
    });
}

// 会社管理メニュー
function showAdminCompanyListMenu(player) {
    const companies = loadData(KEYS.COMPANIES);
    const companyNames = Object.keys(companies);

    const form = new ActionFormData();
    form.title('§1会社管理');
    form.button('§l戻る', 'textures/ui/icon_import.png');

    if (companyNames.length === 0) {
        form.body('>>> §e操作する会社を選択してください\n\n§c現在登録されている会社はありません');
    } else {
        form.body('>>> §e操作する会社を選択してください');
        companyNames.forEach(name => {
            // ボタンに会社名とオーナー名を表示
            form.button(`§1${name}\n§0Owner: ${companies[name].owner}`, 'textures/ui/normalicon1');
        });
    }

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            AdvanceshowAdminMenu(player);
            return;
        }

        if (companyNames.length > 0) {
            const selectedCompany = companyNames[r.selection - 1];
            // ※既存の showAdminCompanyActions へ繋ぎます
            showAdminCompanyActions(player, selectedCompany);
        }
    });
}

// 管理者用：会社に対するアクション選択
function showAdminCompanyActions(player, companyName) {
    const form = new ActionFormData();
    form.title(`§4管理: ${companyName}`);
    form.body(`§r対象会社: §b${companyName}\n\n§r>>> §e操作を選択してください`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§1リーダー(オーナー)の強制変更', 'textures/ui/normalicon1');
    form.button('§4会社の強制削除', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;

        switch (r.selection) {
            case 0:
                showAdminCompanyListMenu(player);
                break;
            case 1:
                adminForceChangeOwnerUI(player, companyName);
                break;
            case 2:
                adminForceDeleteConfirmUI(player, companyName);
                break;
        }
    });
}

// 管理者用：リーダー強制変更UI
function adminForceChangeOwnerUI(player, companyName) {
    const allPlayers = world.getAllPlayers();

    const form = new ActionFormData();
    form.title('§1リーダーの強制変更');
    form.body(`§r会社: §b${companyName}\n\n§r>>> §e新しいオーナーにするプレイヤーを選択してください`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§5[手動入力] 名前を直接入力', 'textures/ui/normalicon1');

    allPlayers.forEach(p => {
        form.button(`§1${p.name}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showAdminCompanyActions(player, companyName);
            return;
        }

        if (r.selection === 1) {
            // 手動入力の場合
            const inputForm = new ModalFormData();
            inputForm.title('§1新しいオーナー名の手動入力');
            inputForm.textField('§rプレイヤー名を入力してください', 'Steve');
            inputForm.show(player).then(res => {
                if (res.canceled || !res.formValues[0]) {
                    adminForceChangeOwnerUI(player, companyName);
                    return;
                }
                executeForceChangeOwner(player, companyName, res.formValues[0]);
            });
            return;
        }

        // リストから選択した場合
        const selectedPlayer = allPlayers[r.selection - 2];
        executeForceChangeOwner(player, companyName, selectedPlayer.name);
    });
}

// リーダー変更実行処理
function executeForceChangeOwner(adminPlayer, companyName, newOwnerName) {
    system.run(() => {
        const companies = loadData(KEYS.COMPANIES);
        if (!companies[companyName]) {
            adminPlayer.sendMessage('§r[§cAdvance§r] §cエラー: 会社が存在しません');
            return;
        }

        const oldOwner = companies[companyName].owner;

        // オーナーを変更
        companies[companyName].owner = newOwnerName;

        // もし新オーナーがメンバーリストにいなければ追加する
        if (!companies[companyName].members.includes(newOwnerName)) {
            companies[companyName].members.push(newOwnerName);
        }

        saveData(KEYS.COMPANIES, companies);

        adminPlayer.sendMessage(`§r[§cAdvance§r] §a${companyName} のオーナーを §b${oldOwner} §aから §b${newOwnerName} §aへ変更しました`);
        showAdminCompanyActions(adminPlayer, companyName);
    });
}

// 管理者用：強制削除確認UI
function adminForceDeleteConfirmUI(player, companyName) {
    const form = new ActionFormData();
    form.title('§4会社の強制削除');
    form.body(`§c【警告】\n本当に「${companyName}」を強制削除しますか？\n\n§r・未配送の注文があっても無視して削除されます。\n・すべての商品データが削除されます。\n・資産データは消失します。\n\n§lこの操作は取り消せません`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§4強制削除を実行する', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            showAdminCompanyActions(player, companyName);
            return;
        }

        if (r.selection === 1) {
            executeForceDeleteCompany(player, companyName);
        }
    });
}

// 強制削除実行処理
function executeForceDeleteCompany(adminPlayer, companyName) {
    system.run(() => {
        // 会社情報を削除
        const companies = loadData(KEYS.COMPANIES);
        if (!companies[companyName]) {
            adminPlayer.sendMessage('§r[§cAdvance§r] §c既に削除されているか存在しません');
            return;
        }
        delete companies[companyName];
        saveData(KEYS.COMPANIES, companies);

        // 関連商品をすべて削除
        const products = loadData(KEYS.PRODUCTS);
        const updatedProducts = {};
        let deletedProductCount = 0;

        for (const id in products) {
            if (products[id].companyName !== companyName) {
                updatedProducts[id] = products[id];
            } else {
                deletedProductCount++;
            }
        }
        saveData(KEYS.PRODUCTS, updatedProducts);

        adminPlayer.sendMessage(`§r[§cAdvance§r] §a会社「${companyName}」とその商品${deletedProductCount}件を強制削除しました`);

        // メニューに戻る
        AdvanceshowAdminMenu(adminPlayer);
    });
}
