import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';
import { Game_system } from '../blockrun/game';

export function setting(player) {
    var form = new ActionFormData();
    form.title(`§1GAME`);
    form.body(`§a設定`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§0UIカスタマイズ`, 'textures/blocks/game');
    form.button(`§1ラッキーレター`, 'textures/ui/operatorcontroller');
    form.button(`§1ハイアンドロー`, 'textures/ui/operatorcontroller');
    form.button('§1スロット', 'textures/ui/operatorcontroller');
    form.button('§1ブラックジャック', 'textures/ui/operatorcontroller');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                Game_system(player);
                break;
            case 1:
                var toggleForm = new ModalFormData();
                toggleForm.title('§0UIカスタマイズ');

                toggleForm.toggle('§eラッキーレター', {
                    defaultValue: world.getDynamicProperty('LUCKY_LETTER_ENABLED') ?? true,
                });
                toggleForm.toggle('§eハイアンドロー', {
                    defaultValue: world.getDynamicProperty('HIGH_AND_LOW_ENABLED') ?? true,
                });
                toggleForm.toggle('§eスロット', {
                    defaultValue: world.getDynamicProperty('SLOT_MACHINE_ENABLED') ?? true,
                });
                toggleForm.toggle('§eブラックジャック', {
                    defaultValue: world.getDynamicProperty('BLACKJACK_ENABLED') ?? true,
                });

                toggleForm.show(player).then(res => {
                    if (res.canceled) {
                        setting(player);
                        return;
                    }

                    // フォームの結果をワールドに保存
                    world.setDynamicProperty('LUCKY_LETTER_ENABLED', res.formValues[0]);
                    world.setDynamicProperty('HIGH_AND_LOW_ENABLED', res.formValues[1]);
                    world.setDynamicProperty('SLOT_MACHINE_ENABLED', res.formValues[2]);
                    world.setDynamicProperty('BLACKJACK_ENABLED', res.formValues[3]);

                    player.sendMessage('§aゲームの有効/無効設定を保存しました。');
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    setting(player);
                });
                break;
            case 2:
                var form = new ModalFormData();
                form.title(`§1GAME`);
                form.textField(`§e報酬倍率`, `${world.getDynamicProperty('MULTIPLIER')}`);
                form.textField(`§a選択肢の数`, `${world.getDynamicProperty('TOTAL_LETTERS')}`);
                form.textField(`§d当たりの数`, `${world.getDynamicProperty('WINNING_COUNT')}`);
                form.textField(`§cベット金額`, `${world.getDynamicProperty('BET_AMOUNTS')}`);
                form.show(player).then(r => {
                    if (r.canceled) {
                        setting(player);
                        return;
                    }
                    if (r.formValues[0] != '') {
                        world.setDynamicProperty('MULTIPLIER', Number(r.formValues[0]));
                    }
                    if (r.formValues[1] != '') {
                        world.setDynamicProperty('TOTAL_LETTERS', Number(r.formValues[1]));
                    }
                    if (r.formValues[2] != '') {
                        world.setDynamicProperty('WINNING_COUNT', Number(r.formValues[2]));
                    }
                    if (r.formValues[3] != '') {
                        world.setDynamicProperty('BET_AMOUNTS', r.formValues[3]);
                    }
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    setting(player);
                });
                break;
            case 3:
                // ハイアンドロー設定
                var form = new ModalFormData();
                form.title(`§1ハイアンドロー設定`);
                form.textField(`§e報酬倍率`, `${world.getDynamicProperty('HL_MULTIPLIER') ?? 2}`);
                form.textField(`§a選択肢の数`, `${world.getDynamicProperty('HL_TOTAL_CHOICES') ?? 5}`);
                form.textField(`§d当たりの数`, `${world.getDynamicProperty('HL_WINNING_CHOICE') ?? 1}`);
                form.textField(`§cベット金額`, `${world.getDynamicProperty('HL_BET_AMOUNTS') ?? '100,500,1000'}`);
                form.textField(`§b最大ラウンド数`, `${world.getDynamicProperty('HL_MAX_ROUNDS') ?? 5}`);
                form.dropdown(`§a難易度上昇`, ['なし', 'カード範囲縮小', '倍率低下'], {
                    defaultValueIndex: world.getDynamicProperty('HL_DIFFICULTY_INCREASE') ?? 0,
                });
                form.show(player).then(r => {
                    if (r.canceled) {
                        setting(player);
                        return;
                    }
                    if (r.formValues[0] != '') {
                        world.setDynamicProperty('HL_MULTIPLIER', Number(r.formValues[0]));
                    }
                    if (r.formValues[1] != '') {
                        world.setDynamicProperty('HL_TOTAL_CHOICES', Number(r.formValues[1]));
                    }
                    if (r.formValues[2] != '') {
                        world.setDynamicProperty('HL_WINNING_CHOICE', Number(r.formValues[2]));
                    }
                    if (r.formValues[3] != '') {
                        world.setDynamicProperty('HL_BET_AMOUNTS', r.formValues[3]);
                    }
                    if (r.formValues[4] != '') {
                        world.setDynamicProperty('HL_MAX_ROUNDS', Number(r.formValues[4]));
                    }
                    world.setDynamicProperty('HL_DIFFICULTY_INCREASE', r.formValues[5]);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    setting(player);
                });
                break;
            case 4:
                // スロット設定
                var form = new ModalFormData();
                form.title('§1スロット設定');

                const symbols = world.getDynamicProperty('SLOT_SYMBOLS') ?? '1,2,3';
                const rewards = world.getDynamicProperty('SLOT_REWARDS') ?? '1:1,2:2,3:3';
                const betAmounts = world.getDynamicProperty('SLOT_BET_AMOUNTS') ?? '100,500,1000';

                form.textField('§a使用シンボル (カンマ区切り)', '例: 1,2,3', {
                    defaultValue: symbols,
                });
                form.textField('§e報酬設定 (シンボル:倍率,...)', '例: 1:1,2:2,3:3', {
                    defaultValue: rewards,
                });
                form.textField('§cベット額 (カンマ区切り)', '例: 100,500,1000', {
                    defaultValue: betAmounts,
                });

                form.show(player).then(r => {
                    if (r.canceled) {
                        setting(player);
                        return;
                    }

                    world.setDynamicProperty('SLOT_SYMBOLS', r.formValues[0]);
                    world.setDynamicProperty('SLOT_REWARDS', r.formValues[1]);
                    world.setDynamicProperty('SLOT_BET_AMOUNTS', r.formValues[2]);

                    player.sendMessage('§aスロットの設定を保存しました');
                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                    setting(player);
                });
                break;
            case 5:
                // ブラックジャック設定
                var form = new ModalFormData();
                form.title('§1ブラックジャック設定');

                form.toggle('§aディーラー対戦 (1人プレイ) を有効', {
                    defaultValue: world.getDynamicProperty('BLACKJACK_SOLO_ENABLED') ?? true,
                });
                form.textField('§eディーラー対戦時の最大掛け金 (0で無制限)', '0', {
                    defaultValue: `${world.getDynamicProperty('BLACKJACK_SOLO_REWARD_CAP') ?? 10000}`,
                });

                form.show(player).then(r => {
                    if (r.canceled) {
                        setting(player);
                        return;
                    }

                    const soloEnabled = r.formValues[0];
                    const rewardCap = Number(r.formValues[1]);

                    world.setDynamicProperty('BLACKJACK_SOLO_ENABLED', soloEnabled);
                    // 0以下は無制限としてnullを保存
                    world.setDynamicProperty('BLACKJACK_SOLO_REWARD_CAP', rewardCap > 0 ? rewardCap : null);

                    player.sendMessage('§aブラックジャックの設定を保存しました');
                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                    setting(player);
                });
                break;
        }
    });
}
