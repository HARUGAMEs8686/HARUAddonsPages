import { system, world } from '@minecraft/server';
import { ActionFormData, ModalFormData, uiManager } from '@minecraft/server-ui';

import { Game_system } from '../blockrun/game';

// === 設定 ===
const SCOREBOARD_MONEY = 'money'; // 通貨として使用するスコアボード名

// === グローバルなゲーム状態管理 ===
const activeRooms = {};

// === メインメニュー ===

/**
 * ゲームのメインメニューを表示
 * @param {import("@minecraft/server").Player} player
 */
export function BlackJack(player) {
    // 既に参加している場合はその部屋の状態へ飛ばす
    const roomCode = getPlayerRoom(player.name);
    if (roomCode && activeRooms[roomCode]) {
        broadcastUIUpdate(roomCode, player); // 特定プレイヤーだけ更新
        return;
    }

    const form = new ActionFormData().title('§1ブラックジャック').body('>>> §eプレイしたいオプションを選んでください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§5部屋を作成', 'textures/ui/normalicon1.png').button('§1部屋に参加', 'textures/ui/normalicon1.png');

    form.show(player).then(result => {
        if (result.canceled) return;
        if (result.selection === 0) {
            Game_system(player);
        } else if (result.selection === 1) {
            showCreateRoomForm(player);
        } else {
            showRoomList(player);
        }
    });
}

function showCreateRoomForm(player) {
    const form = new ModalFormData().title('§5部屋を作成 - ベット額設定');
    form.textField('この部屋の固定ベット額を設定してください\n(※1以上の整数を入力)', '10');

    form.show(player).then(result => {
        if (result.canceled) return;

        // 入力値を整数に変換
        const betAmount = parseInt(result.formValues[0]);

        if (isNaN(betAmount) || betAmount < 1) {
            player.sendMessage('[§bブラックジャック§r] §cベット額は1以上の整数で入力してください。部屋作成を中止しました');
            return;
        }

        createRoom(player, betAmount);
    });
}

function showRoomList(player) {
    const availableRooms = Object.values(activeRooms).filter(room => room.status === 'lobby');

    const form = new ActionFormData().title('§1部屋に参加');

    if (availableRooms.length === 0) {
        form.body('>>> §e現在参加できる部屋はありません');
    } else {
        form.body('>>> §e部屋を選択してください');
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        availableRooms.forEach(room => {
            // ボタンテキストに部屋情報（ホスト、ベット額、人数）を表示
            const buttonText = `§0ホスト: ${room.host}\n§5ベット: ${room.fixedBet}PAY §0| §1参加者: ${room.players.length}/4人`;
            form.button(buttonText, 'textures/ui/normalicon1.png');
        });
    }

    form.show(player).then(result => {
        if (result.canceled || result.selection === undefined) return;
        if (result.selection == 0) {
            BlackJack(player);
            return;
        }
        const selectedRoom = availableRooms[result.selection - 1];
        if (selectedRoom) {
            joinRoom(player, selectedRoom.roomCode);
        }
    });
}

// === ロビー & ベット画面 ===

/**
 * ロビー画面の更新処理
 */
function updateLobbyUI(player, state) {
    const isHost = state.host === player.name;

    // プレイヤーリストの表示文字列作成 (ベット情報削除)
    const playersList = state.players
        .map(pData => {
            const hostLabel = pData.name === state.host ? ' §6(HOST)' : '';
            return `§f- ${pData.name}${hostLabel}`;
        })
        .join('\n');

    let bodyText = `§b部屋コード§r: §e${state.roomCode}§r\n`;
    bodyText += `§6固定ベット額§r: §e${state.fixedBet}§r\n\n`; // 固定ベット額を表示
    bodyText += `§a参加者 (${state.players.length}/4)§r:\n${playersList}\n\n`;

    const form = new ActionFormData().title('§0ブラックジャック §1ロビー');
    form.body(bodyText);

    // ボタンの条件分岐 (シンプル化)
    if (isHost) {
        form.button('§1ゲームを開始する', 'textures/ui/normalicon1.png'); // 0
    } else {
        form.button('§0ホストの開始待ち...', 'textures/ui/normalicon1.png'); // 0
    }

    if (isHost) {
        form.button('§4部屋を解散', 'textures/ui/normalicon1.png'); // 1
    } else {
        form.button('§4退出する', 'textures/ui/normalicon1.png'); // 1
    }

    form.show(player).then(result => {
        if (result.canceled) return;
        const sel = result.selection;

        if (sel === 0 && isHost) {
            if (state.players.length === 1) {
                const soloEnabled = world.getDynamicProperty('BLACKJACK_SOLO_ENABLED') ?? true;
                if (!soloEnabled) {
                    player.sendMessage('[§bブラックジャック§r] §c現在、1人でのプレイは設定で無効になっています');
                    broadcastUIUpdate(state.roomCode, player);
                    return;
                }

                // ソロプレイ時のベット上限チェック
                const rewardCap = world.getDynamicProperty('BLACKJACK_SOLO_REWARD_CAP');
                if (typeof rewardCap === 'number' && Number(state.fixedBet) > rewardCap) {
                    player.sendMessage(`[§bブラックジャック§r] §cディーラー対戦のベット上限は ${rewardCap}PAY です。(現在: ${state.fixedBet}PAY)`);
                    broadcastUIUpdate(state.roomCode, player);
                    return;
                }
            }

            // 所持金チェック
            const brokePlayers = state.players.filter(p => {
                const pInstance = world.getPlayers().find(pl => pl.name === p.name);
                return pInstance && getMoney(pInstance) < state.fixedBet;
            });

            if (brokePlayers.length > 0) {
                player.sendMessage(`[§bブラックジャック§r] §c所持金が足りないプレイヤーがいます: ${brokePlayers.map(p => p.name).join(', ')}`);
                broadcastUIUpdate(state.roomCode, player);
                return;
            }

            if (state.players.length < 1) {
                // 1人プレイも許可
                player.sendMessage('[§bブラックジャック§r] §c最低2人のプレイヤーが必要です');
                broadcastUIUpdate(state.roomCode, player);
            } else {
                startGame(state.roomCode); // 直接ゲーム開始
            }
        } else if (sel === 1) {
            isHost ? deleteRoom(player, state.roomCode) : leaveRoom(player);
        } else {
            broadcastUIUpdate(state.roomCode, player);
        }
    });
}

// === ゲームプレイ画面 ===

/**
 * ゲーム中のUI振り分け (操作ターン or 待機)
 */
function showGameUI(player, state) {
    const isMyTurn = state.players[state.currentPlayerIndex]?.name === player.name;

    if (isMyTurn) {
        showPlayerTurnForm(player, state);
    } else {
        showWaitingForm(player, state);
    }
}

/**
 * 自分のターン
 */
function showPlayerTurnForm(player, state) {
    const myHand = state.playerHands[player.name];
    const myScore = calculateHandValue(myHand);
    const isMultiplayer = state.players.length > 1;

    let text = '';

    // --- 変更点: マルチプレイ時はディーラー表示を隠す ---
    if (!isMultiplayer) {
        const dealerHand = state.dealerHand;
        const dealerVisible = calculateHandValue([dealerHand[0]]); // 1枚目だけ計算
        text += `§eディーラーの手札:§r\n [ ${cardString(dealerHand[0])} ] [ ? ] (合計: ${dealerVisible}+?)\n\n`;
    } else {
        text += `§e=== プレイヤー対戦モード ===§r\n`;
        text += `§7現在のポット総額: §e${state.pot}PAY§r\n\n`;
    }
    // --------------------------------------------------

    text += `§aあなたの手札:§r (合計: §l${myScore}§r)\n`;
    text += myHand.map(c => ` [ ${cardString(c)} ]`).join('') + `\n\n`;
    text += `§7バストしないように21に近づけてください。\n`;

    const form = new ActionFormData().title('§1あなたのターン').body(text).button('§1ヒット (カードを引く)', 'textures/ui/normalicon1.png').button('§4スタンド (勝負する)', 'textures/ui/normalicon1.png');

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            handleHit(player, state.roomCode);
        } else {
            handleStand(player, state.roomCode);
        }
    });
}
/**
 * 待機画面 (他人のターン)
 */
function showWaitingForm(player, state) {
    const currentPName = state.players[state.currentPlayerIndex]?.name;
    const myHand = state.playerHands[player.name];

    let text = `§7現在は §e${currentPName} §7のターンです。\n\n`;
    text += `§aあなたの手札:§r\n`;
    text += myHand.map(c => ` [ ${cardString(c)} ]`).join('') + `\n`;
    text += `(合計: ${calculateHandValue(myHand)})`;

    const form = new ActionFormData().title('§0待機中...').body(text).button('§0更新待機 (押すと更新)', 'textures/ui/normalicon1.png');

    form.show(player).then(res => {
        if (res.canceled) return;
        if (activeRooms[state.roomCode]?.status === 'playing') {
            broadcastUIUpdate(state.roomCode, player);
        }

        // --- 修正点ここまで ---
    });
}

// === 結果画面 ===

function showResultForm(player, state) {
    const myName = player.name;
    const myResult = state.results[myName];
    if (!myResult) return; // エラー回避

    const dealerScore = calculateHandValue(state.dealerHand);
    const myScore = calculateHandValue(state.playerHands[myName]);

    let text = '';
    if (state.players.length === 1) {
        text += `§eディーラー: ${dealerScore} ${dealerScore > 21 ? '§c(バスト)' : ''}§r\n`;
        text += state.dealerHand.map(c => `[${cardString(c)}]`).join(' ') + `\n\n`;
    }

    text += `§aあなた: ${myScore} ${myScore > 21 ? '§c(バスト)' : ''}§r\n`;
    text += state.playerHands[myName].map(c => `[${cardString(c)}]`).join(' ') + `\n`;

    text += `--------------------\n`;
    if (myResult.status === 'WIN') {
        text += `§6WIN! 勝利！§r\n`;
        if (state.players.length > 1) {
            text += `ポット総額 ${state.pot}PAY を獲得！\n`;
        }
        text += `総獲得額: §a+${myResult.profit}PAY§r\n`;
    } else if (myResult.status === 'PUSH') {
        text += `§ePUSH 引き分け (賭け金返金)§r\n`;
        text += `収支: ±0PAY\n`;
    } else {
        text += `§cLOSE 敗北...§r\n`;
        text += `収支: §c${myResult.profit}PAY§r\n`;
    }

    text += `\n§r=== 全プレイヤー結果 ===§r\n`;
    state.players.forEach(pData => {
        const pName = pData.name;
        const res = state.results[pName];
        if (!res) return;

        let icon = '';
        let color = '§f';
        if (res.status === 'WIN') {
            icon = '§6[勝]';
            color = '§a';
        } else if (res.status === 'PUSH') {
            icon = '§e[分]';
            color = '§e';
        } else {
            icon = '§c[負]';
            color = '§c';
        }

        const nameDisplay = pName === myName ? `§l${pName}§r` : pName;
        // profitが0以上の時だけ `+` をつける
        const profitDisplay = res.profit >= 0 ? `+${res.profit}` : `${res.profit}`;
        text += `${icon} ${nameDisplay}: ${color}${profitDisplay}PAY§r\n`;
    });

    text += `\n§7所持金: ${getMoney(player)}PAY`;

    const form = new ActionFormData().title('§1ゲーム結果').body(text).button('§1ロビーに戻る', 'textures/ui/normalicon1.png').button('§4退出する', 'textures/ui/icon_import.png');

    form.show(player).then(res => {
        if (res.canceled) {
            showResultForm(player, state);
            return;
        }
        if (res.selection === 0) {
            handleContinue(player, state.roomCode, true);
        } else {
            handleContinue(player, state.roomCode, false);
        }
    });
}

// === ゲームロジック ===

function createRoom(player, betAmount) {
    // 引数に betAmount を追加
    if (getPlayerRoom(player.name)) return;

    const code = Math.random().toString(36).substring(2, 7).toUpperCase();
    activeRooms[code] = {
        roomCode: code,
        host: player.name,
        players: [{ name: player.name }],
        status: 'lobby', // statusは 'lobby' のみ
        fixedBet: betAmount, // 固定ベット額を保存
        playerHands: {},
        dealerHand: [],
        deck: [],
        currentPlayerIndex: 0,
        pot: 0,
        results: {},
        continueReady: {},
        winnersCount: 0,
        actionBarInterval: null,
    };
    player.sendMessage(`[§bブラックジャック§r] §a部屋を作成しました: ${code} (ベット: ${betAmount}PAY)`);
    broadcastUIUpdate(code);
}

// === ユーティリティ・システム === の中に追加

/**
 * 待機状況をアクションバーに表示し続ける
 * @param {string} code 部屋コード
 */
function startActionBarUpdate(code) {
    const room = activeRooms[code];
    if (!room || room.actionBarInterval) return; // 既に開始されている場合は何もしない

    // 1秒ごとにアクションバーを更新
    room.actionBarInterval = system.runInterval(() => {
        const currentRoom = activeRooms[code];
        // 部屋が存在しないか、ゲーム状態が変わったら停止
        if (!currentRoom || currentRoom.status !== 'finished') {
            stopActionBarUpdate(code);
            return;
        }

        const readyCount = Object.keys(currentRoom.continueReady).length;
        const totalPlayers = currentRoom.players.length;
        const message = `他のプレイヤーを待っています... (§a${readyCount}§r/§e${totalPlayers}§r)`;

        currentRoom.players.forEach(pData => {
            const p = world.getPlayers().find(pl => pl.name === pData.name);
            if (p) {
                p.onScreenDisplay.setActionBar(message);
            }
        });
    }, 20); // 20tick = 1秒
}

/**
 * 部屋内のプレイヤー全員にメッセージを送る
 */
function broadcastMessage(code, message) {
    const room = activeRooms[code];
    if (!room) return;

    room.players.forEach(pData => {
        const player = world.getPlayers().find(p => p.name === pData.name);
        if (player) {
            player.sendMessage(message);
        }
    });
}

/**
 * アクションバーの表示を停止する
 * @param {string} code 部屋コード
 */
function stopActionBarUpdate(code) {
    const room = activeRooms[code];
    if (!room || !room.actionBarInterval) return;

    system.clearRun(room.actionBarInterval);
    room.actionBarInterval = null;

    // アクションバーをクリア
    room.players.forEach(pData => {
        const p = world.getPlayers().find(pl => pl.name === pData.name);
        if (p) {
            p.onScreenDisplay.setActionBar('');
        }
    });
}

function joinRoom(player, code) {
    if (getPlayerRoom(player.name)) {
        player.sendMessage('[§bブラックジャック§r] §c既に部屋に参加しています');
        return;
    }
    const room = activeRooms[code];
    if (!room) {
        player.sendMessage('[§bブラックジャック§r] §c部屋が見つかりません');
        return;
    }
    if (room.status !== 'lobby' && room.status !== 'betting') {
        player.sendMessage('[§bブラックジャック§r] §cゲーム進行中です');
        return;
    }
    if (room.players.length >= 4) {
        player.sendMessage('[§bブラックジャック§r] §c満員です');
        return;
    }

    room.players.push({ name: player.name });
    player.sendMessage(`[§bブラックジャック§r] §a部屋に参加しました`);
    broadcastUIUpdate(code);
}

function startGame(code) {
    const room = activeRooms[code];
    // 既にロビー以外なら実行しない（連打防止）
    if (!room || room.status !== 'lobby') return;

    // 一時的にステータスを変更してロックする
    room.status = 'initializing';

    // お金の徴収前の最終チェック
    const numericBet = Number(room.fixedBet);
    const brokePlayers = room.players.filter(pData => {
        const p = world.getPlayers().find(pl => pl.name === pData.name);
        return !p || getMoney(p) < numericBet;
    });

    if (brokePlayers.length > 0) {
        broadcastMessage(code, `[§cエラー§r] 所持金不足のプレイヤーがいるため開始できません。`);
        room.status = 'lobby'; // ロビーに戻す
        broadcastUIUpdate(code);
        return;
    }

    // お金の徴収とポットへの追加
    let potTotal = 0;
    room.players.forEach(pData => {
        const p = world.getPlayers().find(pl => pl.name === pData.name);
        if (p) {
            const current = getMoney(p);
            setMoney(p, current - numericBet);
        }
        potTotal += numericBet;
    });

    room.pot = potTotal;
    room.deck = createDeck();

    if (room.players.length === 1) {
        room.dealerHand = [room.deck.pop(), room.deck.pop()];
    } else {
        room.dealerHand = [];
    }

    room.playerHands = {};
    room.players.forEach(p => {
        room.playerHands[p.name] = [room.deck.pop(), room.deck.pop()];
    });
    room.currentPlayerIndex = 0;

    // ここで正式にプレイ中ステータスへ
    room.status = 'playing';

    const modeText = room.players.length > 1 ? '§e[PvPモード]' : '§b[ソロモード]';
    broadcastMessage(code, `[§bブラックジャック§r] §a${modeText} ゲーム開始！ ポット総額: §e${potTotal}PAY`);
    broadcastUIUpdate(code);
}

function handleHit(player, code) {
    const room = activeRooms[code];
    if (!room || room.status !== 'playing') return;

    // 自分のターンでなければ無視する
    const currentPlayerName = room.players[room.currentPlayerIndex]?.name;
    if (currentPlayerName !== player.name) return;

    room.playerHands[player.name].push(room.deck.pop());
    const score = calculateHandValue(room.playerHands[player.name]);

    if (score > 21) {
        player.playSound('random.break');
        nextTurn(code);
    } else {
        player.playSound('random.orb');
        broadcastUIUpdate(code);
    }
}

function handleStand(player, code) {
    const room = activeRooms[code];
    if (!room || room.status !== 'playing') return;

    // 自分のターンでなければ無視する
    const currentPlayerName = room.players[room.currentPlayerIndex]?.name;
    if (currentPlayerName !== player.name) return;

    player.playSound('random.click');
    nextTurn(code);
}

function nextTurn(code) {
    const room = activeRooms[code];
    if (!room) return;

    room.currentPlayerIndex++;
    if (room.currentPlayerIndex >= room.players.length) {
        if (room.players.length > 1) {
            calculateResults(code);
        } else {
            runDealerTurn(code);
        }
    } else {
        broadcastUIUpdate(code);
    }
}

function runDealerTurn(code) {
    const room = activeRooms[code];
    // ディーラーは17以上になるまで引く
    let dScore = calculateHandValue(room.dealerHand);
    while (dScore < 17) {
        room.dealerHand.push(room.deck.pop());
        dScore = calculateHandValue(room.dealerHand);
    }
    calculateResults(code);
}

/**
 * 勝敗判定とポット分配（重要）
 */
function calculateResults(code) {
    const room = activeRooms[code];
    if (!room) return;

    // 【重要】既に終了処理が走っていたら即終了（多重払い出し防止）
    if (room.status === 'finished') return;

    room.status = 'finished'; // ここでステータスを確定させる
    room.results = {};

    const bet = Number(room.fixedBet);

    // ... (以下、元の計算ロジックはそのまま利用可能) ...
    // ※元のコードの `room.status = 'finished';` の行は削除してください（重複するため）

    // === ソロプレイ (vs ディーラー) ===
    if (room.players.length === 1) {
        const dScore = calculateHandValue(room.dealerHand);
        const dBusted = dScore > 21;
        const pName = room.players[0].name;
        const pHand = room.playerHands[pName];
        const pScore = calculateHandValue(pHand);
        const pBusted = pScore > 21;

        let status = 'LOSE';
        let payout = 0;
        let profit = -bet;

        if (pBusted) {
            status = 'LOSE';
        } else if (dBusted || pScore > dScore) {
            status = 'WIN';
            const rewardCap = world.getDynamicProperty('BLACKJACK_SOLO_REWARD_CAP');
            const winAmount = typeof rewardCap === 'number' ? Math.min(bet, rewardCap) : bet;
            profit = winAmount;
            payout = bet + profit;
        } else if (pScore === dScore) {
            status = 'PUSH';
            payout = bet;
            profit = 0;
        }

        if (payout > 0) {
            const player = world.getPlayers().find(pl => pl.name === pName);
            // 念のため存在チェック
            if (player) setMoney(player, getMoney(player) + payout);
        }

        room.results[pName] = { status, bet, payout, profit };
    }
    // === マルチプレイ (PvP) ===
    else {
        let bestScore = -1;
        room.players.forEach(pData => {
            const score = calculateHandValue(room.playerHands[pData.name]);
            if (score <= 21 && score > bestScore) {
                bestScore = score;
            }
        });

        let winners = [];
        if (bestScore > 0) {
            winners = room.players.filter(pData => calculateHandValue(room.playerHands[pData.name]) === bestScore).map(p => p.name);
        }

        const isUniqueWinner = winners.length === 1;

        room.players.forEach(pData => {
            const name = pData.name;
            const player = world.getPlayers().find(pl => pl.name === name);

            let status = '';
            let payout = 0;
            let profit = 0;

            if (isUniqueWinner) {
                if (winners.includes(name)) {
                    status = 'WIN';
                    payout = room.pot;
                    profit = room.pot - bet;
                } else {
                    status = 'LOSE';
                    payout = 0;
                    profit = -bet;
                }
            } else {
                status = 'PUSH';
                payout = bet;
                profit = 0;
            }

            if (player && payout > 0) {
                setMoney(player, getMoney(player) + payout);
            }

            room.results[name] = { status, bet, payout, profit };
        });
    }

    broadcastUIUpdate(code);
}

function handleContinue(player, code, wantsContinue) {
    const room = activeRooms[code];
    if (!room) {
        uiManager.closeAllForms(player);
        system.run(() => BlackJack(player));
        return;
    }

    if (!wantsContinue) {
        leaveRoom(player);
        return;
    }

    room.continueReady[player.name] = true;

    // 準備完了したプレイヤーの数を数える
    const readyCount = Object.keys(room.continueReady).length;
    const totalPlayers = room.players.length;

    // 全員が準備完了したかチェック
    if (readyCount >= totalPlayers) {
        if (room.players.length > 0) {
            resetRoom(code); // 全員準備完了ならリセット
        } else {
            // 最後のプレイヤーが抜けた場合
            stopActionBarUpdate(code);
            delete activeRooms[code];
        }
    } else {
        // まだ待っている人がいるならアクションバー更新開始
        startActionBarUpdate(code);
    }
}

function resetRoom(code) {
    stopActionBarUpdate(code);
    const room = activeRooms[code];
    room.status = 'lobby'; // ロビー画面へ
    room.pot = 0;
    room.playerHands = {};
    room.dealerHand = [];
    room.deck = [];
    room.results = {};
    room.continueReady = {};

    // ホスト権限の移譲確認（簡易）
    if (!room.players.find(p => p.name === room.host)) {
        room.host = room.players[0].name;
    }

    broadcastMessage(code, `[§bブラックジャック§r] 次のゲームを開始します`);
    broadcastUIUpdate(code); // これで全員ロビー(ベット)画面へ
}

// === ユーティリティ・システム ===

function broadcastUIUpdate(code, specificPlayer = null) {
    const room = activeRooms[code];
    if (!room) return;

    const targets = specificPlayer ? [{ name: specificPlayer.name }] : room.players;

    targets.forEach(pData => {
        const player = world.getPlayers().find(p => p.name === pData.name);
        if (!player) return;

        uiManager.closeAllForms(player);

        system.run(() => {
            // 部屋の状態が消えている可能性を考慮
            const currRoom = activeRooms[code];
            if (!currRoom) return; // 部屋解散済みなら何もしない（あるいはメニューに戻す）

            switch (currRoom.status) {
                case 'lobby':
                case 'betting':
                    updateLobbyUI(player, currRoom);
                    break;
                case 'playing':
                    showGameUI(player, currRoom);
                    break;
                case 'finished':
                    showResultForm(player, currRoom);
                    break;
            }
        });
    });
}

function leaveRoom(player) {
    const code = getPlayerRoom(player.name);
    if (!code) {
        uiManager.closeAllForms(player);
        system.run(() => BlackJack(player));
        return;
    }
    const room = activeRooms[code];

    // 退出プレイヤーのインデックスを特定
    const leavingPlayerIndex = room.players.findIndex(p => p.name === player.name);

    // プレイヤーリストから削除
    room.players = room.players.filter(p => p.name !== player.name);
    player.sendMessage('[§bブラックジャック§r] §a退出しました');
    uiManager.closeAllForms(player);
    system.run(() => BlackJack(player));

    if (room.players.length === 0) {
        delete activeRooms[code];
        stopActionBarUpdate(code);
        return;
    }

    // ホスト移譲
    if (room.host === player.name) {
        room.host = room.players[0].name;
        broadcastMessage(code, `[§bブラックジャック§r] §7ホストが ${room.host} になりました`);
    }

    // ゲーム中の退出処理
    if (room.status === 'playing') {
        if (leavingPlayerIndex < room.currentPlayerIndex) {
            room.currentPlayerIndex--;
        } else if (leavingPlayerIndex === room.currentPlayerIndex) {
            if (room.currentPlayerIndex >= room.players.length) {
                // 全員のターンが終わったとみなす
                if (room.players.length > 0) {
                    room.players.length > 1 ? calculateResults(code) : runDealerTurn(code);
                    return;
                }
            }
        }

        if (room.players.length < 1) {
            delete activeRooms[code];
            return;
        }
    }

    if (room.status === 'finished') {
        const readyCount = Object.keys(room.continueReady).length;
        const totalPlayers = room.players.length;
        if (totalPlayers > 0 && readyCount >= totalPlayers) {
            resetRoom(code);
            return;
        }
    }

    broadcastUIUpdate(code);
}

function deleteRoom(player, code) {
    stopActionBarUpdate(code);
    const room = activeRooms[code];
    if (!room) return;

    room.players.forEach(pData => {
        const p = world.getPlayers().find(pl => pl.name === pData.name);
        if (p) {
            p.sendMessage('[§bブラックジャック§r] §cホストにより部屋が解散されました');
            uiManager.closeAllForms(p);
            system.run(() => BlackJack(p));
        }
    });
    delete activeRooms[code];
}

function getPlayerRoom(name) {
    for (const code in activeRooms) {
        if (activeRooms[code].players.some(p => p.name === name)) return code;
    }
    return null;
}

// === カード・計算ロジック ===

const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function createDeck() {
    let deck = [];
    for (let i = 0; i < 4; i++) {
        RANKS.forEach(r => deck.push({ rank: r }));
    }
    // シャッフル
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function calculateHandValue(hand) {
    let value = 0;
    let aces = 0;
    hand.forEach(c => {
        if (c.rank === 'A') {
            value += 11;
            aces++;
        } else if (['J', 'Q', 'K'].includes(c.rank)) {
            value += 10;
        } else {
            value += parseInt(c.rank);
        }
    });
    while (value > 21 && aces > 0) {
        value -= 10;
        aces--;
    }
    return value;
}

function cardString(card) {
    return `§f${card.rank}§r`;
}

// === スコアボード ===

function getMoney(player) {
    try {
        const obj = world.scoreboard.getObjective(SCOREBOARD_MONEY);
        if (!obj) return 0;
        // getScoreはundefinedを返すことがあるので0にする
        return obj.getScore(player.scoreboardIdentity) ?? 0;
    } catch {
        return 0;
    }
}

function setMoney(player, val) {
    try {
        let obj = world.scoreboard.getObjective(SCOREBOARD_MONEY);
        if (!obj) obj = world.scoreboard.addObjective(SCOREBOARD_MONEY, 'Money');
        obj.setScore(player.scoreboardIdentity, val);
    } catch (e) {
        player.sendMessage('[§bブラックジャック§r] §cスコアボードエラー');
    }
}

// プレイヤー切断時の処理
world.afterEvents.playerLeave.subscribe(ev => {
    const name = ev.playerName;
    const code = getPlayerRoom(name);

    if (code && activeRooms[code]) {
        const room = activeRooms[code];

        // 抜けた人のインデックスを記録しておく
        const leavingPlayerIndex = room.players.findIndex(p => p.name === name);

        // プレイヤーリストから削除
        room.players = room.players.filter(p => p.name !== name);

        // 部屋が空になったら削除
        if (room.players.length === 0) {
            delete activeRooms[code];
            stopActionBarUpdate(code);
            return;
        }

        // ホストが抜けた場合の継承
        if (room.host === name) {
            room.host = room.players[0].name;
            room.players.forEach(pData => {
                const p = world.getPlayers().find(pl => pl.name === pData.name);
                if (p) p.sendMessage(`[§bブラックジャック§r] §7ホストが ${room.host} になりました（前ホストの切断）`);
            });
        }

        // ゲームプレイ中に抜けた場合の進行補正（ここが重要）
        if (room.status === 'playing') {
            // 手番より前の人が抜けたらインデックスを詰める
            if (leavingPlayerIndex < room.currentPlayerIndex) {
                room.currentPlayerIndex--;
            }
            else if (leavingPlayerIndex === room.currentPlayerIndex) {
                if (room.currentPlayerIndex >= room.players.length) {
                    if (room.players.length > 0) {
                        room.players.length > 1 ? calculateResults(code) : runDealerTurn(code);
                        return;
                    }
                }
            }

            if (room.players.length < 1) {
                delete activeRooms[code];
                return;
            }
        }

        if (room.status === 'finished') {
            const readyCount = Object.keys(room.continueReady).length;
            const totalPlayers = room.players.length;
            if (totalPlayers > 0 && readyCount >= totalPlayers) {
                resetRoom(code);
                return;
            }
        }

        broadcastUIUpdate(code);
    }
});
