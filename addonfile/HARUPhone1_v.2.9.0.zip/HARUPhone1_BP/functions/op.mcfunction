tag @s add HARUPayOP
tag @s add op
tag @s add HARUPhoneOP
give @s additem:haruphone1
scoreboard objectives add money dummy 所持金
scoreboard objectives add account dummy 口座
tellraw @s {"rawtext":[{"text":"§5スマホを開いて初期設定をしましょう"}]}