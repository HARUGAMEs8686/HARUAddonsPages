import { world, system } from '@minecraft/server';

import { showMainMenu, showSettingsMenu } from './camera';

import { First_grant } from './First_grant';

export var playerHARUAppsOpen = {};
export var playerCameraViewOnly = {};

const RACE_EVENT_ID = 'haruapps:camera';
const VIEW_EVENT_ID = 'haruapps:cameraview';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            playerCameraViewOnly[player.id] = false;
            showMainMenu(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        } else if (eventData.id === VIEW_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            playerCameraViewOnly[player.id] = true;
            showMainMenu(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

system.runTimeout(() => {
    const overworld = world.getDimension('overworld');
    overworld.runCommand(`scriptevent haruapps:push §0カメラ scriptevent ${RACE_EVENT_ID}`);
}, 20);

//アイテムでの実行
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === 'additem:camera') {
        const player = eventData.source;
        system.run(() => {
            playerHARUAppsOpen[player.id] = false;
            playerCameraViewOnly[player.id] = false;
            showMainMenu(player);
        });
    }
});

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'camera:s') {
            showSettingsMenu(player);
        }
    });
});

First_grant();
