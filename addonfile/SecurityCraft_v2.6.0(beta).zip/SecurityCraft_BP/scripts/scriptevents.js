import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData,MessageFormData } from "@minecraft/server-ui";
import { SecurityLogB_Data,SecurityLogB_Name,checkModePlayers } from "./main";

export function Itemrun_HARUPhone1(eventData,player){
        var players = world.getPlayers()
        var form = new ActionFormData();
            form.title("§0§lSecureCraft");
            form.body(`§a-ワールド情報-\n§r・§3プレイヤー人数§r: §r§b${players.length}\n\n§c-セキュリティー情報-§r\n§r・§3座標ログ§r: §r§b${world.getDynamicProperty('Log_system')}\n\n§5>>>§7選択してください...`);
            form.button("§1§o座標ログ");
            form.button("§5§oTicket付与");
            form.button("§3§oCheckMode\n§r§9有効化§r・§4無効化","textures/ui/sidebar_icons/star");
            form.button("§3§oSecurityChest\n§r§9追加§r・§4削除","textures/blocks/securitychest");
            form.button("§8§o設定\n§9操作","textures/ui/icon_setting");
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("チェックするログを選択");
                        form.button("§1ログデータA\n§8データ量少 (再起動してもアクセス可)");
                        form.button("§5ログデータB\n§8データ量多 (ワールド終了時に強制削除)");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    function showPlayerListA(player) {
                                        const PlayersNameLog = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionA(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionA(player, targetName) {
                                        const logKey = `Security_LOG_KEY_${targetName}`;
                                        const logData = world.getDynamicProperty(logKey);
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const logs = JSON.parse(logData);
                                        if (logs.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logs.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsA(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsA(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionA(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                        
                                    }

                                    //表示
                                    showPlayerListA(player);
                                break;
                                case 1:
                                    function showPlayerListB(player) {
                                        const PlayersNameLog = SecurityLogB_Name
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionB(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionB(player, targetName) {
                                        const logData = SecurityLogB_Data[targetName];
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        if (logData.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logData.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsB(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsB(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionB(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                    }

                                    //表示
                                    showPlayerListB(player);
                                break;
                            }
                        })
                    break;
                    case 1:
                        var players = world.getAllPlayers()
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("送り先のプレイヤーを選択");
                        for (let i = 0; i < players.length; i++){
                            form.button(`§1${players[i].name}\n§5>>>§s${players[i].getDynamicProperty('Security_chest_ticket')}`);
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                          let response = r.selection;

                          var form = new ModalFormData();
                          form.title("§0§lSecureCraft");
                          form.textField("付与ticket数(半角数字)", "0")
                          form.show(player).then(r => {
                            if (r.canceled) return;
                            if(isNaN(r.formValues[0])){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §4半角数字で入力してください"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            if (r.formValues[0]<0){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §40以下は設定できません"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            if(players[response].getDynamicProperty('Security_chest_ticket')==undefined){
                                players[response].setDynamicProperty('Security_chest_ticket',0)
                            }
                            players[response].setDynamicProperty('Security_chest_ticket',players[response].getDynamicProperty('Security_chest_ticket')+Number(r.formValues[0])) 
                            players[response].runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${Number(r.formValues[0])}§r枚受け取りました"}]}`)
                            players[response].runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${players[response].name}§rに§b${Number(r.formValues[0])}§a枚付与しました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)  
                        })
                        })
                    break;
                    case 2:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("§bCheckMode §9有効化§r/§4無効化");
                        form.button("§9有効化");
                        form.button("§4無効化");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    checkModePlayers.add(player.name);
                                    player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります");
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                break;
                                case 1:
                                    checkModePlayers.delete(player.name);
                                    player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5OFF§rにしました");
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                break;
                            }
                        })
                    break;
                    case 3:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("機能を選択");
                        form.button("§1追加");
                        form.button("§5削除");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    let chest_pattern = [ "ラージチェスト", "樽", "黄緑色シュルカーボックス", "空色シュルカーボックス","桃色シュルカーボックス","黄色のシュルカーボックス","白色シュルカーボックス"]
                                    var form = new ModalFormData();
                                    form.textField("座標x", "0")
                                    form.textField("座標y", "0")
                                    form.textField("座標z", "0")
                                    form.textField("保存ブロック数", "0") 
                                    form.dropdown("種類", chest_pattern)
                                    form.textField("倉庫デザイン", "") 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        var securitychest_List = world.getDynamicProperty('securitychest_List')
                                        if(securitychest_List==undefined){
                                           var securitychest_List_system2=[]
                                        }else{
                                          var securitychest_List_system2 = JSON.parse(securitychest_List);
                                        }
                                        securitychest_List_system2.push([{ x: Number(r.formValues[0]), y: Number(r.formValues[1]), z: Number(r.formValues[2]) },r.formValues[3],chest_pattern[r.formValues[4]],0,r.formValues[5],player.name])
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a追加しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 1:
                                    var securitychest_List = world.getDynamicProperty('securitychest_List')
                                    if(securitychest_List==undefined){
                                       var securitychest_List_system2=[]
                                    }else{
                                      var securitychest_List_system2 = JSON.parse(securitychest_List);
                                    }
                                        if(securitychest_List_system2[0]==undefined){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除できる倉庫販売データがありません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("削除する倉庫販売データを選択");
                                    for (let i = 0; i < securitychest_List_system2.length; i++){
                                        form.button(`§1${securitychest_List_system2[i][0].x},${securitychest_List_system2[i][0].y},${securitychest_List_system2[i][0].z}§r:\n§s${securitychest_List_system2[i][2]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        securitychest_List_system2.splice( response, 1 );
                                        if(securitychest_List_system2==[]){
                                            securitychest_List_system2=undefined
                                        }
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                            }
                        })  
                    break;
                    case 4:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("選択してください.");
                        form.button("§l戻る","textures/ui/back_button_hover");
                        form.button("§o§2座標ログシステム\n§r§9有効化§r・§4無効化");
                        form.button("§o§3座標ログデータ削除\n§r§9A§r・§5B");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    Itemrun_HARUPhone1(eventData,player)
                                break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`現在は${world.getDynamicProperty('Log_system')}\n選択してください.`);
                                    form.button("§l戻る","textures/ui/back_button_hover");
                                    form.button("§o§9有効化");
                                    form.button("§o§4無効化");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                world.setDynamicProperty('Log_system', true)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 2:
                                                world.setDynamicProperty('Log_system', false)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                        }
                                    })
                                break;
                                case 2:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`削除するデータを選択`);
                                    form.button("§lホームへ戻る","textures/ui/back_button_hover");
                                    form.button("§o§5データA");
                                    form.button("§o§1データB");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                var form = new ActionFormData();
                                                form.title("§0§lSecureCraft");
                                                form.body(`§5データA\n\n§5>>>§s本当に削除しますか？`);
                                                form.button("§o§5削除");
                                                form.button("§o§1キャンセル");
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:   
                                                          var playersName = world.getDynamicProperty("PlayersNameLog")
                                                          if (!playersName) {
                                                             playersName = [];
                                                          } else {
                                                              playersName = JSON.parse(playersName); // 文字列からオブジェクトに変換
                                                          }

                                                          for (let i = 0; i < playersName.length ; i++){
                                                            const logKey = `Security_LOG_KEY_${playersName[i]}`;
                                                            world.setDynamicProperty(logKey,undefined);
                                                          }
                                                            world.setDynamicProperty("PlayersNameLog")
                                                            Itemrun_HARUPhone1(eventData,player)
                                                        break;
                                                        case 1:
                                                            
                                                        break;
                                                    }
                                                })
                                            break;
                                            case 2:
                                                var form = new ActionFormData();
                                                form.title("§0§lSecureCraft");
                                                form.body(`§9データB\n\n§5>>>§s本当に削除しますか？`);
                                                form.button("§o§5削除");
                                                form.button("§o§1キャンセル");
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:   
                                                        for (let i = 0; i < SecurityLogB_Name.length ; i++){
                                                            SecurityLogB_Data[SecurityLogB_Name[i]] = []
                                                        }
                                                        Itemrun_HARUPhone1(eventData,player)
                                                        break;
                                                        case 1:
                                                            
                                                        break;
                                                    }
                                                })
                                            break;
                                        }
                                    })
                                break;
                            }
                        }) 
                    break;
                    default: break;
                }
            })
}

