import { world, system } from "@minecraft/server";
import { Itemrun_HARUPhone1 } from "./scriptevents.js"
import { BlockRun } from "./blockrun.js"

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
  const player = eventData.sourceEntity;
  if(eventData.id === "haru:s") {
    Itemrun_HARUPhone1(eventData,player);
  }
  if(eventData.id === "start:s") {
    player.runCommand('tag @s add SecurityOP')
    player.sendMessage("§r[§bSecurity§r] §cSecurityシステムを起動しました");
    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
  }
})

//初期設定
if(world.getDynamicProperty('Log_system')==undefined){
  world.setDynamicProperty('Log_system', true)
}
if(world.getDynamicProperty('pvp_check')==undefined){
  world.setDynamicProperty('pvp_check', true)
}

//logシステム
const MAX_LOGS = 30; // 1人あたりの最大ログ数

//B データ保存あり
function SecurityLogA() {
  if(world.getDynamicProperty('Log_system')==true){
    const players = world.getPlayers();
    const now = new Date();
    const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, "0");
    const day = String(japanTime.getUTCDate()).padStart(2, "0");
    const hours = String(japanTime.getUTCHours()).padStart(2, "0");
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
    const seconds = String(japanTime.getUTCSeconds()).padStart(2, "0");
    var time = `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
    players.forEach(player => {
        //名前を保存
        const logs = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
           // もし名前が登録されていなかったら追加
        if (!logs.includes(player.name)) {
            logs.push(player.name);
        }            
           // 更新したログを保存
        world.setDynamicProperty("PlayersNameLog", JSON.stringify(logs));
        
        const logKey = `Security_LOG_KEY_${player.name}`;
        let logData = world.getDynamicProperty(logKey);

        // もしログデータが存在しなければ初期化
        if (!logData) {
            logData = [];
        } else {
            logData = JSON.parse(logData); // 文字列からオブジェクトに変換
        }

        const pos = player.location;
        const logEntry = {
            x: Math.round(pos.x), 
            y: Math.round(pos.y),
            z: Math.round(pos.z),
            time:time // タイムスタンプ
        };

        // プレイヤーごとのログを管理
        if (!logData[player.name]) {
            logData[player.name] = [];
        }

        logData.push(logEntry); // 新しいデータを追加

        // MAX_LOGSを超えたら古いデータを削除
        if (logData[player.name].length > MAX_LOGS) {
            logData[player.name].shift(); // 配列の先頭を削除
        }
        // 更新したログデータを保存
        world.setDynamicProperty(logKey, JSON.stringify(logData));
    });
  }
    // もう一度3分後に実行
    system.runTimeout(SecurityLogA, 3600);
}


export var SecurityLogB_Data = {}
export var SecurityLogB_Name = []
//B データ保存無し
function SecurityLogB() {
  if(world.getDynamicProperty('Log_system')==true){
  const players = world.getPlayers();
  const now = new Date();
  const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const year = japanTime.getUTCFullYear();
  const month = String(japanTime.getUTCMonth() + 1).padStart(2, "0");
  const day = String(japanTime.getUTCDate()).padStart(2, "0");
  const hours = String(japanTime.getUTCHours()).padStart(2, "0");
  const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
  const seconds = String(japanTime.getUTCSeconds()).padStart(2, "0");
  var time = `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
  players.forEach(player => {
      //名前を保存
      if(!SecurityLogB_Name.includes(player.name)){
        SecurityLogB_Name.push(player.name)     
      }

      const pos = player.location;
      const logEntry = {
          x: Math.round(pos.x), 
          y: Math.round(pos.y),
          z: Math.round(pos.z),
          time:time // タイムスタンプ
      };

      // プレイヤーごとのログを管理
      if(!SecurityLogB_Data[player.name]){
        SecurityLogB_Data[player.name] = []
      }  
      SecurityLogB_Data[player.name].push(logEntry); // 新しいデータを追加

      // MAX_LOGSを超えたら古いデータを削除
      if (SecurityLogB_Data[player.name].length > 1440) {
        SecurityLogB_Data[player.name].shift(); // 配列の先頭を削除
      }
  });
 }

  // もう一度1分後に実行
  system.runTimeout(SecurityLogB, 1200);
}

// セキュリティーログシステム最初の呼び出し
SecurityLogA();
SecurityLogB();

export var SecurityLogC_Data = {}
export var SecurityLogC_Name = []
//破壊検知
world.beforeEvents.playerBreakBlock.subscribe(event => {
  const player = event.source;
  
})



// 設置者情報を保存するオブジェクト（座標キー: プレイヤー名）
const blockOwnerMap = {};

//設置検知
world.beforeEvents.playerPlaceBlock.subscribe(event => {
  const player = event.player;
  const block = event.block;
  const positionKey = block.x + "," + block.y + "," + block.z;

  blockOwnerMap[positionKey] = player.name;
});
  
var playerCashData = {}

//ブロックタッチ検知
world.beforeEvents.playerInteractWithBlock.subscribe((event) =>{
  BlockRun(event)
  system.run(() => {
    const player = event.player;

    if (!checkModePlayers.has(player.name)) return; // 確認モードがONのプレイヤーのみ

    if(!playerCashData[player.id]){
       playerCashData[player.id] = true
    
    const block = event.block;
    const positionKey = block.x + "," + block.y + "," + block.z;
  
    if (blockOwnerMap[positionKey]) {
        const ownerName = blockOwnerMap[positionKey];
        player.sendMessage("§r[§bSecurity§r] §5" + ownerName + "§rによって§e設置");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    } else {
        player.sendMessage("§r[§bSecurity§r] §cこのブロックの設置者情報はありません");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.7 0.7`)
    }
  
    system.runTimeout(() => {
      playerCashData[player.id] = false
    }, 20);
  }
  })
})

// 確認モードのプレイヤーリスト
export const checkModePlayers = new Set();

//メッセージ検知
world.afterEvents.chatSend.subscribe((event) => {
  const player = event.sender;
    const message = event.message.toLowerCase();

    if (message === "!checkmode on"&&player.hasTag('SecurityOP')) {
        checkModePlayers.add(player.name);
        player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    } else if (message === "!checkmode off"&&player.hasTag('SecurityOP')) {
        checkModePlayers.delete(player.name);
        player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5OFF§rにしました");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    }
})

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
  if (eventData.itemStack.typeId === "additem:securecraft"){
    const player = eventData.source;
    system.run(() => {
      if(player.hasTag('SecurityOP')){
       Itemrun_HARUPhone1(eventData,player)
      }
    })
  }
})


