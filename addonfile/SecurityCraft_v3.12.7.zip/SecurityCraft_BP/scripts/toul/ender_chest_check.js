import { world, system, EntityEnderInventoryComponent } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { IDConfig } from '../data/IDConfig.js';
import { PlayerManager } from '../ui.js';

function getItemInfo(typeId) {
    const isJPEnabled = world.getDynamicProperty('JPChange') === true;
    let displayName = typeId.replace('minecraft:', '');
    let iconPath = 'textures/ui/bubble_empty';

    const configData = IDConfig.find(data => data[0] === typeId);
    if (configData) {
        if (isJPEnabled && configData[1]) {
            displayName = configData[1];
        }
        if (configData[2]) {
            iconPath = configData[2];
        }
    }
    return { displayName, iconPath };
}

function getItemDisplayName(typeId) {
    return getItemInfo(typeId).displayName;
}

// 時刻取得ヘルパー
function getFormattedTime() {
    const now = new Date();
    const timeSetting = world.getDynamicProperty('Time_Setting') ?? 9;
    const japanTime = new Date(now.getTime() + timeSetting * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    return `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;
}

// エンダーチェスト一覧表示
export function showEnderChestContents(player, targetPlayer) {
    const enderInventory = targetPlayer.getComponent(EntityEnderInventoryComponent.componentId) ?? targetPlayer.getComponent('minecraft:ender_inventory') ?? targetPlayer.getComponent('ender_inventory');

    if (!enderInventory || !enderInventory.container) {
        player.sendMessage(`§r[§bSecurityCraft§r] §cエンダーチェストのデータを取得できませんでした`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        PlayerManager(player, targetPlayer);
        return;
    }

    const container = enderInventory.container;
    const time = getFormattedTime();

    const form = new ActionFormData();
    form.title(`§4${targetPlayer.name} §0のエンダーチェスト`);
    form.body(`${time}\n>>> §e選択してください`);

    form.button('§l戻る', 'textures/ui/icon_import.png');

    const slotItems = [];

    for (let slot = 0; slot < container.size; slot++) {
        const item = container.getItem(slot);
        if (item) {
            const { displayName, iconPath } = getItemInfo(item.typeId);
            slotItems.push({ slot, item, displayName });
            form.button(`§1${displayName} §r§0個数: §4${item.amount}個`, iconPath);
        }
    }

    if (slotItems.length === 0) {
        form.label('§7エンダーチェストは空です');
    }

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            PlayerManager(player, targetPlayer);
            return;
        }

        const selectedIndex = response.selection - 1;
        const selected = slotItems[selectedIndex];

        if (selected) {
            showItemActionMenu(player, targetPlayer, selected.slot);
        }
    });
}

// アイテム個別操作メニュー
function showItemActionMenu(player, targetPlayer, slot) {
    const enderInventory = targetPlayer.getComponent(EntityEnderInventoryComponent.componentId) ?? targetPlayer.getComponent('minecraft:ender_inventory') ?? targetPlayer.getComponent('ender_inventory');

    if (!enderInventory || !enderInventory.container) {
        player.sendMessage(`§r[§bSecurityCraft§r] §cエンダーチェストのデータを取得できませんでした`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        PlayerManager(player, targetPlayer);
        return;
    }

    const item = enderInventory.container.getItem(slot);
    if (!item) {
        player.sendMessage(`§r[§bSecurityCraft§r] §cアイテムが見つかりませんでした`);
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showEnderChestContents(player, targetPlayer);
        return;
    }

    const displayName = getItemDisplayName(item.typeId);

    const form = new ActionFormData();
    form.title(`§0アイテム操作 [スロット ${slot}]`);
    form.body(`対象プレイヤー: §a${targetPlayer.name}§r\nスロット: §e${slot}§r\nアイテム: §b${displayName}§r\nID: §7${item.typeId}§r\n個数: §d${item.amount}個\n\n§r>>> §e選択してください`);

    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§1手元に取得', 'textures/ui/bubble_empty');
    form.button('§4削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            showEnderChestContents(player, targetPlayer);
            return;
        }

        if (r.selection === 1) {
            getItemToPlayer(player, targetPlayer, slot);
        } else if (r.selection === 2) {
            confirmDeleteItem(player, targetPlayer, slot);
        }
    });
}

// アイテム取得（OPの手元へ）
function getItemToPlayer(player, targetPlayer, slot) {
    const enderInventory = targetPlayer.getComponent(EntityEnderInventoryComponent.componentId) ?? targetPlayer.getComponent('minecraft:ender_inventory') ?? targetPlayer.getComponent('ender_inventory');

    if (!enderInventory || !enderInventory.container) {
        player.sendMessage(`§r[§bSecurityCraft§r] §cエンダーチェストのデータを取得できませんでした`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        PlayerManager(player, targetPlayer);
        return;
    }

    const currentItem = enderInventory.container.getItem(slot);
    if (!currentItem) {
        player.sendMessage('§r[§bSecurityCraft§r] §cアイテムが既に存在しないか、変更されました');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showEnderChestContents(player, targetPlayer);
        return;
    }

    const opInventory = player.getComponent('inventory')?.container;
    if (!opInventory) {
        player.sendMessage('§r[§bSecurityCraft§r] §cあなたのインベントリを取得できませんでした');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showEnderChestContents(player, targetPlayer);
        return;
    }

    const displayName = getItemDisplayName(currentItem.typeId);

    const leftover = opInventory.addItem(currentItem);

    if (leftover) {
        if (leftover.amount === currentItem.amount) {
            player.sendMessage('§r[§bSecurityCraft§r] §cインベントリがいっぱいでアイテムを取得できませんでした');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            showItemActionMenu(player, targetPlayer, slot);
            return;
        } else {
            enderInventory.container.setItem(slot, leftover);
            const count = currentItem.amount - leftover.amount;
            player.sendMessage(`§r[§bSecurityCraft§r] §e${displayName} §aを §b${count}個 §a取得しました (入り切らなかった分は保持されます)`);
            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            showEnderChestContents(player, targetPlayer);
            return;
        }
    } else {
        enderInventory.container.setItem(slot, undefined);
        player.sendMessage(`§r[§bSecurityCraft§r] §e${displayName} §r(§b${currentItem.amount}個§r) §aを手元に取得しました`);
        player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
        showEnderChestContents(player, targetPlayer);
    }
}

// 削除確認画面
function confirmDeleteItem(player, targetPlayer, slot) {
    const enderInventory = targetPlayer.getComponent(EntityEnderInventoryComponent.componentId) ?? targetPlayer.getComponent('minecraft:ender_inventory') ?? targetPlayer.getComponent('ender_inventory');

    if (!enderInventory || !enderInventory.container) {
        player.sendMessage(`§r[§bSecurityCraft§r] §cエンダーチェストのデータを取得できませんでした`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        PlayerManager(player, targetPlayer);
        return;
    }

    const currentItem = enderInventory.container.getItem(slot);
    if (!currentItem) {
        player.sendMessage('§r[§bSecurityCraft§r] §cアイテムが既に存在しないか、変更されました');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showEnderChestContents(player, targetPlayer);
        return;
    }

    const displayName = getItemDisplayName(currentItem.typeId);

    const form = new ActionFormData();
    form.title('§4アイテム削除確認');
    form.body(`§e本当に以下のアイテムをエンダーチェストから削除しますか？\n§cこの操作は元に戻せません\n\n§r・対象プレイヤー: §a${targetPlayer.name}§r\n・スロット: §e${slot}§r\n・アイテム: §b${displayName}§r\n・個数: §d${currentItem.amount}個`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§4削除する', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            showItemActionMenu(player, targetPlayer, slot);
            return;
        }

        if (r.selection === 1) {
            enderInventory.container.setItem(slot, undefined);
            player.sendMessage(`§r[§bSecurityCraft§r] §e${displayName} §r(§b${currentItem.amount}個§r)§c を削除しました`);
            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            showEnderChestContents(player, targetPlayer);
        }
    });
}
