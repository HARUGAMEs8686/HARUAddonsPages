import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

//一時データ
var player_Cash_Data = {};
export function ChatPlus(player) {
    player_Cash_Data[player.id] = {};

    //HOME画面
    var form = new ActionFormData();
    form.title('§1ChatPlus');
    form.body(`>>> §e選択してください`);
    form.button(`§3メール`, 'textures/ui/mail');
    form.button(`§5オープンチャット`, 'textures/ui/openchat');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //メール

                //オンラインプレイヤー取得
                player_Cash_Data[player.id].players = world.getAllPlayers();

                //送信先プレイヤー選択画面
                var form = new ActionFormData();
                form.title('§1ChatPlus');
                form.body(`>>>§e送信先プレイヤーを選択`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    if (r.selection == 0) {
                        ChatPlus(player);
                        return;
                    }
                    if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
                        player.sendMessage(`§r[§bメール§r] §c自分は選択できません`);
                        player.playSound('random.toast', {
                            pitch: 0.4,
                            volume: 1.0,
                        });
                        return;
                    }
                    //選択したプレイヤーを保存
                    player_Cash_Data[player.id].player_select = player_Cash_Data[player.id].players[r.selection - 1];
                    //メッセージ入力画面
                    var form = new ModalFormData();
                    form.title('§1ChatPlus');
                    form.textField(`>>>§r送信先:§a${player_Cash_Data[player.id].player_select.name}`, 'メッセージ入力');
                    form.toggle(`§b座標共有 §r(false/true)`, false);
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        }
                        if (r.formValues[0] == '' && r.formValues[1] == false) {
                            player.sendMessage(`§r[§bメール§r] §4メッセージ未入力です`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        //現在地を取得
                        player_Cash_Data[player.id].player_location = player.location;
                        //メッセージ送信
                        if (r.formValues[0] !== '') {
                            player.sendMessage(`§r[§bメール§r] §a${player_Cash_Data[player.id].player_select.name}§rへ送信§6>>>§r${r.formValues[0]}`);
                            player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §a${player.name}§rから受信§6>>>§r${r.formValues[0]}`);
                        }
                        if (r.formValues[1] == true) {
                            player.sendMessage(`§r[§bメール§r] §c座標送信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                            player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §c座標受信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                        }
                        //通知サウンド
                        player.playSound('random.toast', {
                            pitch: 1.7,
                            volume: 1.0,
                        });
                        player_Cash_Data[player.id].player_select.playSound('random.toast', {
                            pitch: 1.7,
                            volume: 1.0,
                        });
                    });
                });
                break;
            case 1:
                //オープンチャット送信画面
                var form = new ModalFormData();
                form.title('§1ChatPlus');
                form.textField(`チャット`, 'メッセージ');
                form.toggle(`§a座標共有 §r(false/true)`, false);
                form.show(player)
                    .then(r => {
                        if (r.canceled) {
                            ChatPlus(player);
                            return;
                        }

                        if (r.formValues[0] == '' && r.formValues[1] == false) {
                            player.sendMessage(`§r[§bオープンチャット§r] §4メッセージ未入力です`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        //オンラインプレイヤー取得
                        player_Cash_Data[player.id].players = world.getAllPlayers();
                        //現在地を取得
                        player_Cash_Data[player.id].player_location = player.location;

                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                            if (r.formValues[0] !== '') {
                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §a${player.name}§b:§r${r.formValues[0]}`);
                            }
                            if (r.formValues[1] == true) {
                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §c座標§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                            }

                            //通知サウンド
                            player_Cash_Data[player.id].players[i].playSound('random.toast', {
                                pitch: 1.7,
                                volume: 1.0,
                            });
                        }
                    })
                    .catch(e => {
                        console.error(e, e.stack);
                    });
                break;
        }
    });
}
