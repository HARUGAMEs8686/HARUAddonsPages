import { world, system } from '@minecraft/server';
import { ChatPlus } from './ChatPlus.js';

var player_Cash_Data = {};
world.beforeEvents.playerInteractWithBlock.subscribe(eventData => {
    if (eventData.block.typeId === 'addblock:chatplus') {
        const player = eventData.player;
        player_Cash_Data[player.id] = {};
        system.run(() => {
            if (!player_Cash_Data[player.id].RunStop) {
                player_Cash_Data[player.id].RunStop = true;
                ChatPlus(player);
                system.runTimeout(() => {
                    player_Cash_Data[player.id].RunStop = false;
                }, 20);
            }
        });
    }
});

//アイテムでの実行
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === 'additem:chatplus') {
        const player = eventData.source;
        system.run(() => {
            ChatPlus(player);
        });
    }
});
