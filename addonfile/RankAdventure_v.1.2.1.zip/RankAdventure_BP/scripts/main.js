import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

// ==========================================
// 1. 設定 & 定数 (JSONライクにカスタマイズ可能)
// ==========================================

// 販売アイテムの抽選プール (確率、テクスチャ、IDなどを定義)
const DEFAULT_SHOP_POOL = [
    // ==========================================
    // ■ 食料・消耗品 (生活の基盤)
    // ==========================================
    { id: 'minecraft:bread', name: 'パン', minPrice: 30, maxPrice: 40, texture: 'textures/items/bread', weight: 60 },
    { id: 'minecraft:cooked_beef', name: 'ステーキ', minPrice: 90, maxPrice: 120, texture: 'textures/items/beef_cooked', weight: 45 },
    { id: 'minecraft:golden_carrot', name: '金のニンジン', minPrice: 250, maxPrice: 350, texture: 'textures/items/carrot_golden', weight: 20 },
    { id: 'minecraft:golden_apple', name: '金のリンゴ', minPrice: 1500, maxPrice: 2000, texture: 'textures/items/apple_golden', weight: 8 },
    { id: 'minecraft:arrow', name: '矢', minPrice: 5, maxPrice: 10, texture: 'textures/items/arrow', weight: 50 },

    // ==========================================
    // ■ 鉱石・貴重品 (強化・換金)
    // ==========================================
    { id: 'minecraft:coal', name: '石炭', minPrice: 40, maxPrice: 60, texture: 'textures/items/coal', weight: 50 },
    { id: 'minecraft:iron_ingot', name: '鉄インゴット', minPrice: 200, maxPrice: 280, texture: 'textures/items/iron_ingot', weight: 35 },
    { id: 'minecraft:gold_ingot', name: '金インゴット', minPrice: 300, maxPrice: 400, texture: 'textures/items/gold_ingot', weight: 25 },
    { id: 'minecraft:diamond', name: 'ダイヤモンド', minPrice: 1200, maxPrice: 1600, texture: 'textures/items/diamond', weight: 15 },
    { id: 'minecraft:lapis_lazuli', name: 'ラピスラズリ', minPrice: 50, maxPrice: 80, texture: 'textures/items/dye_powder_blue', weight: 30 },
    { id: 'minecraft:netherite_ingot', name: 'ネザライトインゴット', minPrice: 6000, maxPrice: 9000, texture: 'textures/items/netherite_ingot', weight: 3 },

    // ==========================================
    // ■ 建築・装飾ブロック (安全なアイテム)
    // ==========================================
    { id: 'minecraft:cobblestone', name: '丸石', minPrice: 5, maxPrice: 10, texture: 'textures/blocks/cobblestone', weight: 60 },
    { id: 'minecraft:oak_log', name: 'オークの原木', minPrice: 30, maxPrice: 50, texture: 'textures/blocks/log_oak', weight: 50 },
    { id: 'minecraft:glass', name: 'ガラス', minPrice: 20, maxPrice: 30, texture: 'textures/blocks/glass', weight: 40 },
    { id: 'minecraft:wool', name: '羊毛(白)', minPrice: 25, maxPrice: 40, texture: 'textures/blocks/wool_colored_white', weight: 40 },
    { id: 'minecraft:quartz_block', name: 'クォーツブロック', minPrice: 80, maxPrice: 120, texture: 'textures/blocks/quartz_block_side', weight: 25 },
    { id: 'minecraft:bookshelf', name: '本棚', minPrice: 300, maxPrice: 400, texture: 'textures/blocks/bookshelf', weight: 20 },
    { id: 'minecraft:torch', name: '松明', minPrice: 10, maxPrice: 20, texture: 'textures/blocks/torch_on', weight: 55 },
    { id: 'minecraft:lantern', name: 'ランタン', minPrice: 100, maxPrice: 150, texture: 'textures/items/lantern', weight: 30 },

    // ==========================================
    // ■ 便利ツール・その他 (ユーティリティ)
    // ==========================================
    { id: 'minecraft:slime_ball', name: 'スライムボール', minPrice: 150, maxPrice: 250, texture: 'textures/items/slimeball', weight: 20 },
    { id: 'minecraft:ender_pearl', name: 'エンダーパール', minPrice: 600, maxPrice: 900, texture: 'textures/items/ender_pearl', weight: 15 },
    { id: 'minecraft:blaze_rod', name: 'ブレイズロッド', minPrice: 500, maxPrice: 700, texture: 'textures/items/blaze_rod', weight: 10 },
    { id: 'minecraft:name_tag', name: '名札', minPrice: 800, maxPrice: 1200, texture: 'textures/items/name_tag', weight: 10 },
    { id: 'minecraft:saddle', name: 'サドル', minPrice: 800, maxPrice: 1200, texture: 'textures/items/saddle', weight: 10 },
    { id: 'minecraft:book', name: '本', minPrice: 80, maxPrice: 120, texture: 'textures/items/book_normal', weight: 30 },

    // ==========================================
    // ■ レア・超高級品 (目標アイテム)
    // ==========================================
    { id: 'minecraft:experience_bottle', name: 'エンチャントの瓶', minPrice: 2500, maxPrice: 3500, texture: 'textures/items/experience_bottle', weight: 8 },
    { id: 'minecraft:totem_of_undying', name: '不死のトーテム', minPrice: 12000, maxPrice: 18000, texture: 'textures/items/totem', weight: 2 },
    { id: 'minecraft:nether_star', name: 'ネザースター', minPrice: 40000, maxPrice: 60000, texture: 'textures/items/nether_star', weight: 1 },
];

// ランク設定
const DEFAULT_RANK_TIERS = [
    { name: 'ブロンズ', minPoint: 0, color: '§6' },
    { name: 'シルバー', minPoint: 1000, color: '§7' },
    { name: 'ゴールド', minPoint: 3000, color: '§e' },
    { name: 'プラチナ', minPoint: 6000, color: '§b' },
    { name: 'ダイヤ', minPoint: 10000, color: '§b' },
    { name: 'マスター', minPoint: 20000, color: '§d' },
    { name: 'レジェンド', minPoint: 50000, color: '§c' },
];

// 初回導入時のMob報酬デフォルト設定
const DEFAULT_MOB_REWARDS = {
    // --- オーバーワールド (基本) ---
    'minecraft:zombie': { money: 35, xp: 5 },
    'minecraft:zombie_villager_v2': { money: 45, xp: 8 }, // 村人ゾンビ
    'minecraft:husk': { money: 40, xp: 6 }, // ハスク
    'minecraft:drowned': { money: 40, xp: 6 }, // ドラウンド
    'minecraft:skeleton': { money: 40, xp: 8 },
    'minecraft:stray': { money: 45, xp: 9 }, // ストレイ
    'minecraft:creeper': { money: 45, xp: 10 },
    'minecraft:spider': { money: 36, xp: 6 },
    'minecraft:cave_spider': { money: 40, xp: 8 },
    'minecraft:witch': { money: 60, xp: 15 }, // ウィッチ
    'minecraft:enderman': { money: 80, xp: 15 }, // エンダーマン
    'minecraft:phantom': { money: 50, xp: 10 }, // ファントム
    'minecraft:slime': { money: 15, xp: 3 }, // スライム(小)

    // --- 襲撃関連 ---
    'minecraft:pillager': { money: 50, xp: 12 },
    'minecraft:vindicator': { money: 80, xp: 20 },
    'minecraft:ravager': { money: 500, xp: 100 }, // ラヴェジャー

    // --- ネザー ---
    'minecraft:zombified_piglin': { money: 20, xp: 3 }, // 中立なので安め
    'minecraft:piglin': { money: 40, xp: 8 },
    'minecraft:piglin_brute': { money: 150, xp: 40 },
    'minecraft:hoglin': { money: 60, xp: 12 },
    'minecraft:blaze': { money: 60, xp: 15 },
    'minecraft:wither_skeleton': { money: 70, xp: 18 },
    'minecraft:ghast': { money: 100, xp: 25 },
    'minecraft:magma_cube': { money: 20, xp: 4 },

    // --- エンド・深層・ボス ---
    'minecraft:shulker': { money: 80, xp: 20 },
    'minecraft:warden': { money: 8000, xp: 3000 }, // ウォーデン
    'minecraft:wither': { money: 4000, xp: 1200 }, // ウィザー
    'minecraft:ender_dragon': { money: 5000, xp: 1500 },
};

// デフォルトの称号リスト
const DEFAULT_TITLES = [
    { name: '旅人', price: 10000 },
    { name: '先駆者', price: 10000 },
    { name: '開拓者', price: 10000 },
    { name: '熟練者', price: 10000 },
    { name: '守護者', price: 10000 },
    { name: '自由人', price: 10000 },
    { name: '不撓不屈', price: 15000 },
    { name: '疾風迅雷', price: 15000 },
    { name: '一騎当千', price: 15000 },
    { name: '森羅万象', price: 15000 },
    { name: '虚空の影', price: 15000 },
    { name: '暁の騎士', price: 15000 },
    { name: 'お祭り男', price: 15000 },
];

// ターゲットエンティティID
const SELLER_ENTITY_ID = 'haru:seller';

// ==========================================
// 2. データベースシステム (Dynamic Property 分解保存)
// ==========================================

class DataStore {
    static CHUNK_SIZE = 30000; // 制限(32767)より少し小さく設定

    // データを保存 (容量オーバー時に分割)
    static save(key, data) {
        const jsonString = JSON.stringify(data);
        const totalChunks = Math.ceil(jsonString.length / this.CHUNK_SIZE);

        // メタデータ保存 (チャンク数を記録)
        world.setDynamicProperty(`${key}_meta`, totalChunks);

        for (let i = 0; i < totalChunks; i++) {
            const chunk = jsonString.substring(i * this.CHUNK_SIZE, (i + 1) * this.CHUNK_SIZE);
            world.setDynamicProperty(`${key}_${i}`, chunk);
        }
    }

    // データを読み込み (分割されたデータを結合)
    static load(key) {
        const totalChunks = world.getDynamicProperty(`${key}_meta`);
        if (totalChunks === undefined) return null;

        let fullString = '';
        for (let i = 0; i < totalChunks; i++) {
            const chunk = world.getDynamicProperty(`${key}_${i}`);
            if (chunk) fullString += chunk;
        }

        try {
            return JSON.parse(fullString);
        } catch (e) {
            console.warn(`Data corrupted for key: ${key}`);
            return null;
        }
    }
}

// ==========================================
// 3. マネージャー (プレイヤー、設定管理)
// ==========================================

// ==========================================
// 3. マネージャー (プレイヤー、設定管理)
// ==========================================

class PlayerManager {
    static getPlayerData(uuid) {
        // オフラインでも参照できるようWorldプロパティに保存
        let data = DataStore.load(`p_${uuid}`);
        if (!data) {
            data = { rankPoint: 0, titles: [], equippedTitle: '' };
        }
        return data;
    }

    static savePlayerData(uuid, data) {
        DataStore.save(`p_${uuid}`, data);
    }

    static addRankPoint(player, amount) {
        const uuid = player.id;
        const data = this.getPlayerData(uuid);
        data.rankPoint += amount;

        // ランクアップチェック
        const currentRank = this.getRank(data.rankPoint);
        const oldRank = this.getRank(data.rankPoint - amount);

        if (currentRank.name !== oldRank.name) {
            player.sendMessage(`[§bRankAdventure§r] §aおめでとう！ランクが ${currentRank.color}${currentRank.name} §aに上がりました`);
            player.playSound('random.levelup');
        }

        this.savePlayerData(uuid, data);
        this.updateNameTag(player);
    }

    static getRank(points) {
        const tiers = ConfigManager.getRankTiers();
        for (let i = tiers.length - 1; i >= 0; i--) {
            if (points >= tiers[i].minPoint) {
                return tiers[i];
            }
        }
        return tiers[0];
    }

    // スコアボードからMoneyを取得 (修正版)
    static getMoney(player) {
        try {
            const objective = world.scoreboard.getObjective('money');
            if (!objective) return 0;

            const identity = player.scoreboardIdentity;
            if (!identity) return 0; // スコアボード未登録なら0

            return objective.getScore(identity) ?? 0;
        } catch {
            return 0;
        }
    }

    // スコアボードのMoneyを減らす (修正版)
    static removeMoney(player, amount) {
        const objective = world.scoreboard.getObjective('money');
        if (!objective) return false;

        try {
            // 修正: NameTag変更対策
            const identity = player.scoreboardIdentity;
            if (!identity) return false; // IDがない＝所持金データがない

            const current = objective.getScore(identity) ?? 0;
            if (current >= amount) {
                objective.setScore(identity, current - amount);
                return true;
            }
        } catch (e) {
            console.warn(`[RankAdventure] removeMoney Error: ${e}`);
        }
        return false;
    }

    // スコアボードにMoneyを加算する (修正版)
    static addMoney(player, amount) {
        const objective = world.scoreboard.getObjective('money');
        if (!objective) return;

        try {
            // identityがあればAPIで安全に追加
            if (player.scoreboardIdentity) {
                objective.addScore(player.scoreboardIdentity, amount);
            } else {
                player.runCommand(`scoreboard players add @s money ${amount}`);
            }
        } catch (e) {
            console.warn(`[RankAdventure] addMoney Error: ${e}`);
        }
    }

    static updateNameTag(player) {
        try {
            const data = this.getPlayerData(player.id);
            const rank = this.getRank(data.rankPoint);
            const titleStr = data.equippedTitle ? `\n§e<${data.equippedTitle}§e>` : '';

            player.nameTag = `${rank.color}[${rank.name}] §r${player.name}${titleStr}`;
        } catch (e) {}
    }

    // デスペナルティの適用
    static applyDeathPenalty(player) {
        const config = ConfigManager.getDeathPenaltyConfig();

        if (config.mode === 0) return;

        const uuid = player.id;
        const data = this.getPlayerData(uuid);
        const oldPoints = data.rankPoint;
        const oldRank = this.getRank(oldPoints);

        // ポイント計算
        if (config.mode === 2) {
            data.rankPoint = 0;
        } else if (config.mode === 1) {
            data.rankPoint = Math.max(0, data.rankPoint - config.amount);
        }

        if (data.rankPoint === oldPoints) return;

        // 保存と更新
        this.savePlayerData(uuid, data);
        this.updateNameTag(player);

        const newRank = this.getRank(data.rankPoint);
        const lostPoints = oldPoints - data.rankPoint;

        // メッセージ通知
        player.sendMessage(`[§bRankAdventure§r] §c死亡したため、ランクポイントを ${lostPoints} 失いました...`);

        // 降格チェック
        if (newRank.minPoint < oldRank.minPoint) {
            player.sendMessage(`[§bRankAdventure§r] §cランクが ${oldRank.name} から ${newRank.name} に降格しました`);
            player.playSound('random.break');
        }
    }
}

class ConfigManager {
    // --- Mob報酬設定 ---
    static getMobRewards() {
        let data = DataStore.load('cfg_mob_rewards');
        if (!data) {
            data = DEFAULT_MOB_REWARDS;
            DataStore.save('cfg_mob_rewards', data);
        }
        return data;
    }

    static setMobReward(entityId, money, xp) {
        const data = this.getMobRewards();
        if (money === 0 && xp === 0) {
            delete data[entityId];
        } else {
            data[entityId] = { money, xp };
        }
        DataStore.save('cfg_mob_rewards', data);
    }

    // --- 称号設定 ---
    static getTitles() {
        return DataStore.load('cfg_titles') || [];
    }

    static addTitle(name, price) {
        const list = this.getTitles();
        list.push({ name, price });
        DataStore.save('cfg_titles', list);
    }

    static removeTitle(index) {
        const list = this.getTitles();
        if (index >= 0 && index < list.length) {
            list.splice(index, 1);
            DataStore.save('cfg_titles', list);
        }
    }

    // --- ショップアイテム設定 ---
    static getShopPool() {
        let data = DataStore.load('cfg_shop_pool');
        if (!data) {
            data = DEFAULT_SHOP_POOL;
            DataStore.save('cfg_shop_pool', data);
        }
        return data;
    }

    static saveShopPool(poolData) {
        DataStore.save('cfg_shop_pool', poolData);
    }

    // --- ランク設定 ---
    static getRankTiers() {
        if (this._cachedRankTiers) return this._cachedRankTiers;

        let data = DataStore.load('cfg_rank_tiers');
        if (!data) {
            data = DEFAULT_RANK_TIERS;
            DataStore.save('cfg_rank_tiers', data);
        }

        data.sort((a, b) => a.minPoint - b.minPoint);

        this._cachedRankTiers = data;
        return data;
    }

    static saveRankTiers(data) {
        data.sort((a, b) => a.minPoint - b.minPoint);
        DataStore.save('cfg_rank_tiers', data);

        this._cachedRankTiers = data;
    }

    // --- デスペナルティ設定 (新規追加) ---
    static getDeathPenaltyConfig() {
        let data = DataStore.load('cfg_death_penalty');
        if (!data) {
            data = { mode: 0, amount: 100 };
            DataStore.save('cfg_death_penalty', data);
        }
        return data;
    }

    static saveDeathPenaltyConfig(mode, amount) {
        DataStore.save('cfg_death_penalty', { mode, amount });
    }

    // --- 販売者(Seller)設定 ---
    static getSellerConfig() {
        let data = DataStore.load('cfg_seller_settings');
        if (!data) {
            data = { enabled: true, despawnDays: 0 };
            DataStore.save('cfg_seller_settings', data);
        }
        return data;
    }

    static saveSellerConfig(enabled, despawnDays) {
        DataStore.save('cfg_seller_settings', { enabled, despawnDays });
    }

    // --- 称号設定 ---
    static getTitles() {
        let data = DataStore.load('cfg_titles');
        if (!data) {
            data = DEFAULT_TITLES;
            DataStore.save('cfg_titles', data);
        }
        return data;
    }
}

// 進捗バー生成関数 ( |||||||||| )
function getRankProgressBar(currentPoints) {
    const tiers = ConfigManager.getRankTiers();
    const totalBars = 20;
    let currentRankIdx = 0;

    for (let i = tiers.length - 1; i >= 0; i--) {
        if (currentPoints >= tiers[i].minPoint) {
            currentRankIdx = i;
            break;
        }
    }

    const currentRank = tiers[currentRankIdx];
    const nextRank = tiers[currentRankIdx + 1];

    // 最高ランク(プレデター)の場合は常にMAX表示
    if (!nextRank) {
        return `§b${'|'.repeat(totalBars)}`;
    }

    // 進捗率の計算
    const min = currentRank.minPoint;
    const max = nextRank.minPoint;
    const range = max - min;
    const progress = currentPoints - min;

    let percent = progress / range;
    if (percent < 0) percent = 0;
    if (percent > 1) percent = 1;

    const filledCount = Math.floor(totalBars * percent);
    const emptyCount = totalBars - filledCount;

    return `§c${'|'.repeat(filledCount)}§8${'|'.repeat(emptyCount)}`;
}

// ==========================================
// 4. イベント処理
// ==========================================

// A. Sellerスポーン時に商品在庫を生成・保存
world.afterEvents.entitySpawn.subscribe(ev => {
    if (ev.entity.typeId !== SELLER_ENTITY_ID) return;

    const sellerConfig = ConfigManager.getSellerConfig();
    if (!sellerConfig.enabled) {
        // スポーン無効なら即座に消す
        ev.entity.remove();
        return;
    }
    ev.entity.setDynamicProperty('last_interact_tick', system.currentTick);

    const fullPool = ConfigManager.getShopPool();
    const stockCount = Math.floor(Math.random() * 3) + 3;
    const stock = [];

    // プールを複製して抽選用にする
    const tempPool = [...fullPool];
    const maxItems = Math.min(stockCount, tempPool.length);

    for (let i = 0; i < maxItems; i++) {
        const totalWeight = tempPool.reduce((sum, item) => sum + item.weight, 0);
        let random = Math.random() * totalWeight;
        let selectedIndex = 0;

        for (let j = 0; j < tempPool.length; j++) {
            random -= tempPool[j].weight;
            if (random < 0) {
                selectedIndex = j;
                break;
            }
        }

        const selectedItem = tempPool[selectedIndex];

        const finalPrice = Math.floor(Math.random() * (selectedItem.maxPrice - selectedItem.minPrice + 1)) + selectedItem.minPrice;

        stock.push({
            id: selectedItem.id,
            name: selectedItem.name,
            price: finalPrice, // 確定した価格
            texture: selectedItem.texture,
        });

        tempPool.splice(selectedIndex, 1);
    }

    // エンティティ自身のDynamic Propertyに保存
    ev.entity.setDynamicProperty('shop_stock', JSON.stringify(stock));
});

//メニュー付与
world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;

    // 初回スポーンの場合のみ処理
    if (event.initialSpawn) {
        // システムが有効かつプレイヤーがHARUPAY_Memberタグを持っていない場合
        if (!player.hasTag('RankAdventure_Member')) {
            system.runTimeout(() => {
                try {
                    // ネイティブAPIで処理
                    player.getComponent('inventory').container.addItem(new ItemStack('additem:rankadventure', 1));
                    if (player.hasTag('HARUPAY_Member')) {
                        player.addTag('RankAdventure_Member');
                    }
                } catch (error) {
                    console.warn(`自動付与に失敗しました:対象${player.name} 再リクエストします`);
                    system.runTimeout(() => {
                        try {
                            player.getComponent('inventory').container.addItem(new ItemStack('additem:rankadventure', 1));
                            if (player.hasTag('HARUPAY_Member')) {
                                player.addTag('RankAdventure_Member');
                            }
                        } catch (retryError) {
                            console.warn(`リクエスト実行に失敗しました ${player.name}: ${retryError}`);
                        }
                    }, 70);
                }
            }, 20);
        }
    }
});

// B. Sellerインタラクト時にショップUI表示
world.afterEvents.playerInteractWithEntity.subscribe(ev => {
    if (ev.target.typeId !== SELLER_ENTITY_ID) return;

    ev.target.setDynamicProperty('last_interact_tick', system.currentTick);

    const stockJson = ev.target.getDynamicProperty('shop_stock');
    if (!stockJson) {
        ev.player.sendMessage('[§bRankAdventure§r] §cこの商人は商品を売り切らしてしまったようだ...');
        return;
    }

    const stock = JSON.parse(stockJson);
    showShopUI(ev.player, stock);
});

// C. Mobを倒した時の報酬処理
world.afterEvents.entityDie.subscribe(ev => {
    if (ev.deadEntity.typeId === 'minecraft:player') {
        PlayerManager.applyDeathPenalty(ev.deadEntity);
        return;
    }

    const damageSource = ev.damageSource;
    if (damageSource.damagingEntity?.typeId !== 'minecraft:player') return;

    const player = damageSource.damagingEntity;
    const victimId = ev.deadEntity.typeId;

    const rewards = ConfigManager.getMobRewards();
    const reward = rewards[victimId];

    if (reward) {
        if (reward.money > 0) PlayerManager.addMoney(player, reward.money);
        if (reward.xp > 0) PlayerManager.addRankPoint(player, reward.xp);

        const pData = PlayerManager.getPlayerData(player.id);
        const rank = PlayerManager.getRank(pData.rankPoint);

        const bar = getRankProgressBar(pData.rankPoint);
        const moneyText = reward.money > 0 ? `§e+${reward.money}G` : '';
        const rpText = reward.xp > 0 ? ` §b+${reward.xp}RP` : '';

        player.onScreenDisplay.setActionBar(`§r[${rank.color}${rank.name}§r] ${bar}§r ${moneyText}`);
    }
});

export var playerHARUAppsOpen = {};

// D. スクリプトイベントでメニュー呼び出し
system.afterEvents.scriptEventReceive.subscribe(ev => {
    if (ev.id === 'haruapps:rankadventure') {
        const player = ev.sourceEntity;
        playerHARUAppsOpen[player.id] = true;
        showStatusUI(player);
        player.addTag('haruapps');
        system.runTimeout(() => {
            player.removeTag('haruapps');
        }, 2);
    }
});

// アイテム実行
world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    if (eventData.itemStack.typeId === 'additem:rankadventure') {
        system.run(() => {
            playerHARUAppsOpen[player.id] = false;
            showStatusUI(player);
        });
    }
});

// プレイヤーがワールドに参加した時
world.afterEvents.playerSpawn.subscribe(ev => {
    if (ev.initialSpawn) {
        PlayerManager.updateNameTag(ev.player);
    } else {
        PlayerManager.updateNameTag(ev.player);
    }
});

world.afterEvents.worldLoad.subscribe(() => {
    try {
        if (!world.scoreboard.getObjective('money')) {
            world.scoreboard.addObjective('money', 'Money');
            // system.run は不要ですが、念のためログを出したければここで出せます
            console.warn('[RankAdventure] スコアボード "money" を新規作成しました');
        }
    } catch (e) {
        console.warn(`[RankAdventure] スコアボード初期化エラー: ${e}`);
    }
    // world.setDynamicProperty(`cfg_shop_pool_0`, undefined);
    // world.setDynamicProperty(`cfg_mob_rewards_0`, undefined);
});

// ==========================================
// 定期メンテナンス
// ==========================================
system.runInterval(() => {
    const config = ConfigManager.getSellerConfig();

    // 全ディメンションの商人を検索
    const dimensions = ['overworld', 'nether', 'the_end'];

    dimensions.forEach(dimName => {
        const dim = world.getDimension(dimName);
        const sellers = dim.getEntities({ type: SELLER_ENTITY_ID });

        for (const seller of sellers) {
            if (!config.enabled) {
                seller.remove();
                continue;
            }

            if (config.despawnDays > 0) {
                const lastTick = seller.getDynamicProperty('last_interact_tick') ?? system.currentTick;
                const currentTick = system.currentTick;
                const diff = currentTick - lastTick;
                const limitTick = config.despawnDays * 24000;

                if (diff > limitTick) {
                    seller.remove();
                }
            }
        }
    });
}, 1200); // 1分間隔

// ==========================================
// 5. UIシステム
// ==========================================

// ショップ画面
function showShopUI(player, stock) {
    const form = new ActionFormData().title('§0ショップ').body(`所持金: §e${PlayerManager.getMoney(player)} G§r\n欲しいアイテムを選んでください`);

    stock.forEach(item => {
        form.button(`§0${item.name}\n§1${item.price} G`, item.texture);
    });

    form.show(player).then(res => {
        if (res.canceled) return;

        // すぐに購入せず、個数選択画面へ飛ばす
        const selectedItem = stock[res.selection];
        showShopQuantityUI(player, selectedItem);
    });
}

// 個数選択画面
function showShopQuantityUI(player, item) {
    const money = PlayerManager.getMoney(player);
    const maxAffordable = Math.floor(money / item.price);
    let sliderMax = Math.min(64, maxAffordable);
    if (sliderMax < 1) sliderMax = 1;

    const form = new ModalFormData().title('§1個数選択').label(`商品名:§a${item.name}\n§r単価:§e${item.price}`);
    if (money < item.price) {
        // お金が足りない場合
        player.sendMessage('[§bRankAdventure§r] §cお金が足りません');
        player.playSound('note.bass');
        return;
    } else {
        // スライダーを表示
        form.slider(`§b購入個数 (1~${sliderMax})`, 1, sliderMax, {
            defaultValue: 1,
            valueStep: 1,
        });
    }

    form.show(player).then(res => {
        if (res.canceled) return;

        if (money < item.price) return;
        const quantity = res.formValues[1];
        // 確認画面へ
        showShopConfirmationUI(player, item, quantity);
    });
}

// 購入確認画面
function showShopConfirmationUI(player, item, quantity) {
    const totalPrice = item.price * quantity;
    const currentMoney = PlayerManager.getMoney(player);
    const moneyAfter = currentMoney - totalPrice;

    const form = new MessageFormData()
        .title('§0購入確認')
        .body(`以下の内容で購入しますか？\n\n` + `§7商品: §f${item.name}\n` + `§7単価: §f${item.price} G\n` + `§7個数: §a${quantity}個\n` + `----------------\n` + `§7支払総額: §e${totalPrice} G\n` + `§7購入後残高: §e${moneyAfter} G`)
        .button1('§1購入する')
        .button2('§0キャンセル');

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) {
            return;
        }

        // 最終チェック (お金)
        if (currentMoney < totalPrice) {
            player.sendMessage('[§bRankAdventure§r] §cお金が足りません');
            player.playSound('note.bass');
            return;
        }

        // 最終チェック
        const inventory = player.getComponent('inventory').container;
        if (inventory.emptySlotsCount === 0) {
            player.sendMessage('[§bRankAdventure§r] §cインベントリに空きがないため購入できません');
            player.playSound('note.bass');
            return;
        }

        // 支払い処理
        if (PlayerManager.removeMoney(player, totalPrice)) {
            try {
                // アイテム付与
                inventory.addItem(new ItemStack(item.id, quantity));

                player.sendMessage(`[§bRankAdventure§r] §a${item.name}を ${quantity}個 購入しました！ (-${totalPrice}G)`);
                player.playSound('random.orb');
            } catch (e) {
                PlayerManager.addMoney(player, totalPrice);
                player.sendMessage(`[§bRankAdventure§r] §cアイテムIDが無効か、付与に失敗しました。返金しました。`);
                console.warn(e);
            }
        }
    });
}

// ステータス画面 (兼メインメニュー)
function showStatusUI(player) {
    const uuid = player.id;
    const data = PlayerManager.getPlayerData(uuid);
    const rank = PlayerManager.getRank(data.rankPoint);
    const money = PlayerManager.getMoney(player);
    const isAdmin = player.hasTag('AdventureOP');
    const tiers = ConfigManager.getRankTiers();

    // 次のランクの目標ポイントを取得
    let nextRankLimit = 'MAX';

    // 現在のランクが配列のどこにあるか探す
    const currentRankIndex = tiers.findIndex(r => r.name === rank.name);
    if (currentRankIndex >= 0 && currentRankIndex < tiers.length - 1) {
        nextRankLimit = tiers[currentRankIndex + 1].minPoint;
    }

    const form = new ActionFormData()
        .title('§1RankAdventure')
        .body(`§bメニュー\n`)
        .divider()
        .label(`名前: §a${player.name}§r\n` + `ランク: ${rank.color}${rank.name}§r (RP: ${data.rankPoint}/${nextRankLimit})\n` + `所持金: §e${money} G§r\n` + `称号: ${data.equippedTitle || 'なし'}`)
        .divider();
    if (playerHARUAppsOpen[player.id]) {
        form.button('§l戻る', 'textures/ui/icon_import.png');
    } else {
        form.button('§0閉じる', 'textures/ui/icon_import.png');
    }
    form.button('§4称号ショップ', 'textures/ui/ra_icon');
    form.button('§0称号変更', 'textures/ui/ra_icon');

    // 管理者のみ設定ボタン表示
    if (isAdmin) {
        form.button('§0管理者設定', 'textures/ui/ra_settings');
    }

    form.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0 && playerHARUAppsOpen[player.id]) {
            player.runCommand('scriptevent haruphone1:apps');
        }
        if (res.selection === 1) showTitleShopUI(player);
        if (res.selection === 2) showTitleEquipUI(player);
        if (isAdmin && res.selection === 3) showAdminUI(player);
    });
}

// 称号ショップ
function showTitleShopUI(player) {
    const titles = ConfigManager.getTitles();
    const pData = PlayerManager.getPlayerData(player.id);

    const form = new ActionFormData().title('§1称号ショップ').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');

    titles.forEach(t => {
        const hasTitle = pData.titles.includes(t.name);
        const prefix = hasTitle ? '§0[購入済] ' : '§r';
        form.button(`${prefix}§1${t.name} §0- §5${t.price} G`, 'textures/ui/ra_icon');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            showStatusUI(player);
            return;
        }
        const selected = titles[res.selection - 1];

        if (pData.titles.includes(selected.name)) {
            player.sendMessage('[§bRankAdventure§r] §cすでに持っています');
            showTitleShopUI(player);
            return;
        }

        if (PlayerManager.removeMoney(player, selected.price)) {
            pData.titles.push(selected.name);
            PlayerManager.savePlayerData(player.id, pData);
            player.sendMessage(`[§bRankAdventure§r] §a称号「${selected.name}」を購入しました`);
            player.playSound('random.orb');
        } else {
            player.sendMessage('[§bRankAdventure§r] §cお金が足りません');
            showTitleShopUI(player);
        }
    });
}

// 称号装備UI
function showTitleEquipUI(player) {
    const pData = PlayerManager.getPlayerData(player.id);
    if (pData.titles.length === 0) {
        player.sendMessage('[§bRankAdventure§r] §c称号を持っていません');
        return;
    }

    const form = new ModalFormData().title('§0称号装備');
    const currentTitleIndex = pData.titles.indexOf(pData.equippedTitle);
    const defaultIndex = currentTitleIndex !== -1 ? currentTitleIndex + 1 : 0;
    form.dropdown('>>> §e装備する称号を選択', ['(外す)', ...pData.titles], {
        defaultValueIndex: defaultIndex,
    });

    form.show(player).then(res => {
        if (res.canceled) {
            showStatusUI(player);
            return;
        }
        const index = res.formValues[0];

        if (index === 0) {
            pData.equippedTitle = '';
            player.sendMessage('[§bRankAdventure§r] §a称号を外しました');
        } else {
            const title = pData.titles[index - 1];
            pData.equippedTitle = title;
            player.sendMessage(`[§bRankAdventure§r] §a称号「${title}」を装備しました`);
        }
        PlayerManager.savePlayerData(player.id, pData);
        PlayerManager.updateNameTag(player);
    });
}

// ==========================================
// 6. 管理者用UIシステム
// ==========================================

function showAdminUI(player) {
    const form = new ActionFormData().title('§0管理者設定').body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1Mob報酬設定', 'textures/ui/ra_icon')
        .button('§0販売称号の管理', 'textures/ui/ra_icon')
        .button('§5ショップ商品管理', 'textures/ui/ra_icon')
        .button('§4ランク設定', 'textures/ui/ra_icon')
        .button('§0プレイヤーRP管理', 'textures/ui/ra_icon')
        .button('§4デスペナルティ設定', 'textures/ui/ra_icon')
        .button('§1販売NPC設定', 'textures/ui/ra_icon');

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) showStatusUI(player);
        if (res.selection === 1) showAdminMobRewardUI(player);
        if (res.selection === 2) showAdminTitleUI(player);
        if (res.selection === 3) showAdminShopListUI(player);
        if (res.selection === 4) showAdminRankListUI(player);
        if (res.selection === 5) showAdminPlayerListUI(player);
        if (res.selection === 6) showAdminDeathPenaltyUI(player);
        if (res.selection === 7) showAdminSellerConfigUI(player);
    });
}

// 販売NPC設定画面
function showAdminSellerConfigUI(player) {
    const config = ConfigManager.getSellerConfig();

    const form = new ModalFormData()
        .title('§1販売NPC設定')
        .label(`>>> §e選択してください`)
        .divider()
        .toggle('§a販売NPCのスポーンを許可する\n§7(OFFにすると既存のNPCも消えます)', {
            defaultValue: config.enabled,
        })
        .divider()
        .textField('§e自動デスポーン期間 (ゲーム内日数)\n§7(0で無効、触られていない期間で判定)', '数値 (例: 3)', {
            defaultValue: config.despawnDays.toString(),
        })
        .divider()
        .submitButton('§0適用');

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminUI(player);
            return;
        }

        const enabled = res.formValues[2];
        const daysStr = res.formValues[4];
        const days = Number(daysStr);

        if (!daysStr || daysStr.trim() === '') {
            player.sendMessage('[§bRankAdventure§r]§c 日数が入力されていません');
            return;
        }

        if (isNaN(days)) {
            player.sendMessage('[§bRankAdventure§r]§c 日数は半角数字で入力してください');
            return;
        }

        ConfigManager.saveSellerConfig(enabled, days);

        const status = enabled ? '§aON' : '§cOFF';
        const limit = days === 0 ? '§b無期限' : `§e${days}日`;

        player.sendMessage(`[§bRankAdventure§r] §a設定を更新しました: §rスポーン[${status}§r] / 期限§r[${limit}§r]`);
        showAdminUI(player);
    });
}

// デスペナルティ設定画面
function showAdminDeathPenaltyUI(player) {
    const config = ConfigManager.getDeathPenaltyConfig();

    // モード選択肢
    const modes = ['降格なし (ペナルティ無効)', 'ポイント減少 (定数)', '完全リセット (0になる)'];

    const form = new ModalFormData()
        .title('§4デスペナルティ設定')
        .dropdown('死亡時の動作', modes, {
            defaultValueIndex: config.mode,
        })
        .textField('減少ポイント (モードが減少の場合)', '数値', {
            defaultValue: config.amount.toString(),
        });

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminUI(player);
            return;
        }

        const [modeIndex, amountStr] = res.formValues;
        const amount = parseInt(amountStr) || 0;

        ConfigManager.saveDeathPenaltyConfig(modeIndex, amount);

        let msg = `[§bRankAdventure§r] §e設定を更新しました: `;
        if (modeIndex === 0) msg += '§aペナルティなし';
        if (modeIndex === 1) msg += `§c-${amount} RP`;
        if (modeIndex === 2) msg += '§4完全リセット';

        player.sendMessage(msg);
        showAdminUI(player);
    });
}

// プレイヤー一覧表示 (RP管理用)
function showAdminPlayerListUI(player) {
    const players = world.getPlayers();
    const form = new ActionFormData().title('§0プレイヤーRP管理').body('>>> §e対象のプレイヤーを選択してください');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    // プレイヤー一覧ボタンを作成
    players.forEach(p => {
        const pData = PlayerManager.getPlayerData(p.id);
        const pRank = PlayerManager.getRank(pData.rankPoint);
        form.button(`§0${p.name}\n${pRank.color}${pRank.name} §1(RP: ${pData.rankPoint})`, 'textures/ui/ra_icon');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            showAdminUI(player);
            return;
        }

        // 選択されたプレイヤーを取得
        const targetPlayer = players[res.selection - 1];
        if (!targetPlayer) {
            player.sendMessage('[§bRankAdventure§r] §cプレイヤーが見つかりません');
            return;
        }

        showAdminRankPointEditUI(player, targetPlayer);
    });
}

// RP編集画面
function showAdminRankPointEditUI(admin, target) {
    const pData = PlayerManager.getPlayerData(target.id);

    const form = new ModalFormData()
        .title(`§1RP編集: ${target.name}`)
        .dropdown('操作タイプ', ['加算/減算 (現在の値にプラス)', '設定 (指定した値にする)'], {
            defaultValueIndex: 0,
        })
        .textField(`数値 (現在: ${pData.rankPoint})`, 'マイナスで減算', {
            defaultValue: '0',
        });

    form.show(admin).then(res => {
        if (res.canceled) {
            showAdminPlayerListUI(admin);
            return;
        }

        const [mode, amountStr] = res.formValues;
        const amount = parseInt(amountStr);

        if (isNaN(amount)) {
            admin.sendMessage('[§bRankAdventure§r] §c数値を入力してください');
            return;
        }

        let diff = 0;

        if (mode === 0) {
            diff = amount;
        } else {
            const current = pData.rankPoint;
            diff = amount - current;
        }

        if (diff !== 0) {
            PlayerManager.addRankPoint(target, diff);

            const newData = PlayerManager.getPlayerData(target.id);
            admin.sendMessage(`[§bRankAdventure§r] §a${target.name} のRPを更新しました (現在: ${newData.rankPoint})`);
            target.sendMessage(`[§bRankAdventure§r] §e管理者によってランクポイントが変更されました`);
        } else {
            admin.sendMessage(`[§bRankAdventure§r] §e変更はありませんでした`);
        }
    });
}

// ランク一覧画面
function showAdminRankListUI(player) {
    const tiers = ConfigManager.getRankTiers();
    const form = new ActionFormData().title('§4ランク設定').body('>>> §eランク一覧 (昇順)');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1新規追加', 'textures/ui/color_plus');

    tiers.forEach(rank => {
        form.button(`${rank.color}${rank.name}\n§0必要RP: ${rank.minPoint}`, 'textures/ui/ra_icon');
    });

    form.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0) {
            showAdminUI(player);
            return;
        }
        if (res.selection === 1) {
            showAdminRankEditUI(player, -1);
            return;
        }

        // 既存ランク編集
        const index = res.selection - 2;
        showAdminRankEditUI(player, index);
    });
}

// ランク編集画面
function showAdminRankEditUI(player, index) {
    const tiers = ConfigManager.getRankTiers();
    const isNew = index === -1;

    let data = { name: 'New Rank', minPoint: 5000, color: '§f' };
    if (!isNew) {
        data = tiers[index];
    }

    const form = new ModalFormData()
        .title(isNew ? '§1ランク追加' : '§0ランク編集')
        .textField('ランク名', '例: マスター', {
            defaultValue: data.name,
        })
        .textField('必要ポイント (RP)', '数値', {
            defaultValue: data.minPoint.toString(),
        })
        .textField('色コード', '例: §c, §l', {
            defaultValue: data.color,
        });

    if (!isNew) {
        form.toggle('§cこのランクを削除', {
            defaultValue: false,
        });
    }

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminRankListUI(player);
            return;
        }

        let [name, pointStr, color, deleteFlag] = res.formValues;
        const point = parseInt(pointStr) || 0;

        if (!isNew && deleteFlag) {
            if (tiers.length <= 1) {
                player.sendMessage('§c[Error] ランクを全て削除することはできません');
            } else {
                tiers.splice(index, 1);
                ConfigManager.saveRankTiers(tiers);
                player.sendMessage(`[§bRankAdventure§r] §eランクを削除しました`);
            }
            showAdminRankListUI(player);
            return;
        }

        // 追加・更新処理
        const newRank = { name, minPoint: point, color };

        if (isNew) {
            tiers.push(newRank);
            player.sendMessage(`[§bRankAdventure§r] §aランクを追加しました`);
        } else {
            tiers[index] = newRank;
            player.sendMessage(`[§bRankAdventure§r] §aランク情報を更新しました`);
        }

        ConfigManager.saveRankTiers(tiers);

        showAdminRankListUI(player);
    });
}

function showAdminShopListUI(player) {
    const shopPool = ConfigManager.getShopPool();
    const form = new ActionFormData().title('§5ショップ商品管理').body(`登録数: ${shopPool.length}件`);

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1新規追加', 'textures/ui/color_plus');

    shopPool.forEach((item, index) => {
        form.button(`§0${item.name}\n§1${item.minPrice}~${item.maxPrice}G`, item.texture);
    });

    form.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0) {
            showAdminUI(player);
            return;
        }
        if (res.selection === 1) {
            showAdminShopEditUI(player, -1);
            return;
        }

        const itemIndex = res.selection - 2;
        showAdminShopEditUI(player, itemIndex);
    });
}

// ショップ商品編集・追加画面
function showAdminShopEditUI(player, index) {
    const shopPool = ConfigManager.getShopPool();
    const isNew = index === -1;

    // デフォルト値
    let data = {
        id: 'minecraft:',
        name: '',
        minPrice: 100,
        maxPrice: 150,
        texture: 'textures/',
        weight: 10,
    };

    if (!isNew) {
        data = shopPool[index];
    }

    const form = new ModalFormData()
        .title(isNew ? '§1新規商品追加' : '§1商品編集')
        .textField('アイテムID (例: minecraft:diamond)', 'ID', {
            defaultValue: data.id,
        })
        .textField('表示名', '名前', {
            defaultValue: data.name,
        })
        .textField('最低価格', '数値', {
            defaultValue: data.minPrice.toString(),
        })
        .textField('最高価格', '数値', {
            defaultValue: data.maxPrice.toString(),
        })
        .textField('テクスチャパス', 'textures/...', {
            defaultValue: data.texture,
        })
        .slider('出現ウェイト (高いほど出やすい)', 1, 100, {
            defaultValue: data.weight,
            valueStep: 1,
        });

    if (!isNew) {
        form.toggle('§cこの商品を削除する', {
            defaultValue: false,
        });
    }

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminShopListUI(player);
            return;
        }

        let [id, name, minStr, maxStr, texture, weight, deleteFlag] = res.formValues;

        // 削除処理
        if (!isNew && deleteFlag) {
            shopPool.splice(index, 1);
            ConfigManager.saveShopPool(shopPool);
            player.sendMessage(`[§bRankAdventure§r] §e商品を削除しました`);
            showAdminShopListUI(player);
            return;
        }

        // 入力値検証と整形
        const minPrice = parseInt(minStr) || 0;
        const maxPrice = parseInt(maxStr) || minPrice; // maxが無効ならminと同じにする

        const newItem = {
            id: id,
            name: name,
            minPrice: minPrice,
            maxPrice: maxPrice,
            texture: texture,
            weight: weight,
        };

        if (isNew) {
            shopPool.push(newItem);
            player.sendMessage(`[§bRankAdventure§r] §a商品を新規追加しました`);
        } else {
            shopPool[index] = newItem;
            player.sendMessage(`[§bRankAdventure§r] §a商品情報を更新しました`);
        }

        ConfigManager.saveShopPool(shopPool);
        showAdminShopListUI(player);
    });
}

// Mob報酬管理 UI (リスト表示)
function showAdminMobRewardUI(player) {
    const rewards = ConfigManager.getMobRewards();
    // オブジェクトのキー（ID）一覧を取得
    const mobIds = Object.keys(rewards);

    const form = new ActionFormData().title('§1Mob報酬リスト').body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png').button('§1新規追加', 'textures/ui/color_plus');

    mobIds.forEach(id => {
        const val = rewards[id];
        form.button(`§0${id}\n§5${val.money}G §0/ §1${val.xp}RP`, 'textures/ui/ra_icon');
    });

    form.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0) {
            // 戻る
            showAdminUI(player);
            return;
        }

        if (res.selection === 1) {
            showAdminMobRewardEditUI(player);
            return;
        }

        const selectedId = mobIds[res.selection - 2];
        showAdminMobRewardEditUI(player, selectedId);
    });
}

// Mob報酬編集 UI (新規・既存共通)
function showAdminMobRewardEditUI(player, targetId = null) {
    const rewards = ConfigManager.getMobRewards();
    let defaultMoney = '0';
    let defaultXp = '0';

    // 編集モードの場合、既存の値をロード
    if (targetId && rewards[targetId]) {
        defaultMoney = rewards[targetId].money.toString();
        defaultXp = rewards[targetId].xp.toString();
    }

    const form = new ModalFormData();

    if (targetId) {
        form.title(`§1編集§0: ${targetId}`);
    } else {
        form.title('§1新規追加');
        form.textField('エンティティID (例: minecraft:zombie)', 'IDを入力');
    }

    form.textField('§a獲得マネー', '数値', {
        defaultValue: defaultMoney,
    });
    form.textField('§e獲得ランクポイント', '数値', {
        defaultValue: defaultXp,
    });

    // 編集モードのみ削除スイッチを表示
    if (targetId) {
        form.toggle('§cMOBを削除する', {
            defaultValue: false,
        });
    }

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminMobRewardUI(player);
            return;
        }

        let id = targetId;
        let moneyStr, xpStr, deleteFlag;

        if (targetId) {
            [moneyStr, xpStr, deleteFlag] = res.formValues;
        } else {
            [id, moneyStr, xpStr] = res.formValues;
            deleteFlag = false;
        }

        // 削除処理
        if (deleteFlag) {
            ConfigManager.setMobReward(id, 0, 0);
            player.sendMessage(`[§bRankAdventure§r] §e${id} の設定を削除しました`);
        } else {
            // 保存処理
            if (!id) {
                player.sendMessage('[§bRankAdventure§r] §cIDが入力されていません');
            } else {
                const money = parseInt(moneyStr) || 0;
                const xp = parseInt(xpStr) || 0;

                ConfigManager.setMobReward(id, money, xp);
                player.sendMessage(`[§bRankAdventure§r] §a設定を保存しました: ${id} -> ${money}G, ${xp}RP`);
            }
        }
        showAdminMobRewardUI(player);
    });
}

// 称号管理 UI
function showAdminTitleUI(player) {
    const titles = ConfigManager.getTitles();
    const form = new ActionFormData().title('§1称号リスト管理').body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1新規追加', 'textures/ui/color_plus');
    titles.forEach(t => form.button(`§1${t.name} §0(${t.price}G) - §4削除`, 'textures/ui/ra_icon'));

    form.show(player).then(res => {
        if (res.canceled) return;

        if (res.selection === 0) {
            // 戻る
            showAdminUI(player);
            return;
        }
        if (res.selection === 1) {
            // 新規追加
            showAdminTitleAddUI(player);
        } else {
            // 削除確認
            const target = titles[res.selection - 2];
            ConfigManager.removeTitle(res.selection - 2);
            player.sendMessage(`[§bRankAdventure§r] §e称号「${target.name}」を削除しました`);
            showAdminTitleUI(player); // リロード
        }
    });
}

function showAdminTitleAddUI(player) {
    const form = new ModalFormData().title('§5称号追加').textField('§a称号名', '例: ドラゴンスレイヤー').textField('§e価格', '数値', {
        defaultValue: '1000',
    });

    form.show(player).then(res => {
        if (res.canceled) {
            showAdminTitleUI(player);
            return;
        }
        const [name, priceStr] = res.formValues;
        const price = parseInt(priceStr) || 0;

        if (name) {
            ConfigManager.addTitle(name, price);
            player.sendMessage(`[§bRankAdventure§r] §a称号「${name}」を追加しました`);
            showAdminTitleUI(player);
        }
    });
}
