import { world, system } from '@minecraft/server';

//設置
world.afterEvents.playerPlaceBlock.subscribe(event => {
    const player = event.player;
    if (!player) return;
    try {
        player.addTag('PlaceBlock');
        player.addTag(`PlaceBlock_${event.block.typeId}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (player.hasTag('PlaceBlock')) {
                player.removeTag('PlaceBlock');
                player.removeTag(`PlaceBlock_${event.block.typeId}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//破壊
world.afterEvents.playerBreakBlock.subscribe(event => {
    const player = event.player;
    const brokenBlockPermutation = event.brokenBlockPermutation;
    if (!player) return;
    try {
        system.run(() => {
            player.addTag('BreakBlock');
            player.addTag(`BreakBlock_${brokenBlockPermutation.type.id}`);
            // 1ティック後にタグを削除
            system.runTimeout(() => {
                if (player.hasTag('BreakBlock')) {
                    player.removeTag('BreakBlock');
                    player.removeTag(`BreakBlock_${brokenBlockPermutation.type.id}`);
                }
            }, 1);
        });
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//ブロック右クリック
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    if (!player) return;
    try {
        system.run(() => {
            player.addTag('InteractWithBlock');
            player.addTag(`InteractWithBlock_${event.block.typeId}`);
        });
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (player.hasTag('InteractWithBlock')) {
                player.removeTag('InteractWithBlock');
                player.removeTag(`InteractWithBlock_${event.block.typeId}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//ブロック攻撃
world.afterEvents.entityHitBlock.subscribe(event => {
    const damagingEntity = event.damagingEntity;
    if (!damagingEntity) return;
    try {
        damagingEntity.addTag('HitBlock');
        damagingEntity.addTag(`HitBlock_${event.hitBlockPermutation.type.id}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (damagingEntity.hasTag('HitBlock')) {
                damagingEntity.removeTag('HitBlock');
                damagingEntity.removeTag(`HitBlock_${event.hitBlockPermutation.type.id}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//エンティティ右クリック
world.afterEvents.playerInteractWithEntity.subscribe(event => {
    const player = event.player;
    if (!player) return;
    try {
        player.addTag('InteractWithEntity');
        player.addTag(`InteractWithEntity_${event.target.id}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (player.hasTag('InteractWithEntity')) {
                player.removeTag('InteractWithEntity');
                player.removeTag(`InteractWithEntity_${event.target.id}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//アイテム使用
world.afterEvents.itemUse.subscribe(event => {
    const source = event.source;
    if (!source) return;
    try {
        source.addTag('itemUse');
        source.addTag(`itemUse_${event.itemStack.type.id}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (source.hasTag('itemUse')) {
                source.removeTag('itemUse');
                source.removeTag(`itemUse_${event.itemStack.type.id}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//エンティティ死亡
world.afterEvents.entityDie.subscribe(event => {
    const playerA = event.damageSource.damagingEntity;
    const playerB = event.deadEntity;

    if (playerA) {
        try {
            playerA.addTag('entityDieA');
            playerA.addTag(`entityDieA_${playerA.id}`);
            // 1ティック後にタグを削除
            system.runTimeout(() => {
                if (playerA.hasTag('entityDieA')) {
                    playerA.removeTag('entityDieA');
                    playerA.removeTag(`entityDieA_${playerA.id}`);
                }
            }, 1);
        } catch (e) {
            // エラーが発生しても無視します
        }
    }

    if (playerB) {
        try {
            playerB.addTag('entityDieB');
            playerB.addTag(`entityDieB_${playerB.id}`);
            // 1ティック後にタグを削除
            system.runTimeout(() => {
                if (playerB.hasTag('entityDieB')) {
                    playerB.removeTag('entityDieB');
                    playerB.removeTag(`entityDieB_${playerB.id}`);
                }
            }, 1);
        } catch (e) {
            // エラーが発生しても無視します
        }
    }
});

//エンティティがダメージを受けた時
world.afterEvents.entityHurt.subscribe(event => {
    const damagingEntity = event.damageSource.damagingEntity;
    if (!damagingEntity) return;
    try {
        damagingEntity.addTag('entityHurt');
        damagingEntity.addTag(`entityHurt_${damagingEntity.id}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (damagingEntity.hasTag('entityHurt')) {
                damagingEntity.removeTag('entityHurt');
                damagingEntity.removeTag(`entityHurt_${damagingEntity.id}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//エンティティがエンティティを攻撃した時
world.afterEvents.entityHitEntity.subscribe(event => {
    const hitEntity = event.hitEntity;
    if (!hitEntity) return;
    try {
        hitEntity.addTag('entityHitEntity');
        hitEntity.addTag(`entityHitEntity_${hitEntity.id}`);
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (hitEntity.hasTag('entityHitEntity')) {
                hitEntity.removeTag('entityHitEntity');
                hitEntity.removeTag(`entityHitEntity_${hitEntity.id}`);
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

//左クリック
world.afterEvents.playerSwingStart.subscribe(event => {
    const player = event.player;
    const handitem = event.heldItemStack;
    if (!player) return;
    try {
        player.addTag('playerSwingStart');
        if (handitem) {
            player.addTag(`playerSwingStart_${handitem.type.id}`);
        }
        // 1ティック後にタグを削除
        system.runTimeout(() => {
            if (player.hasTag('playerSwingStart')) {
                player.removeTag('playerSwingStart');
                if (handitem) {
                    player.removeTag(`playerSwingStart_${handitem.type.id}`);
                }
            }
        }, 1);
    } catch (e) {
        // エラーが発生しても無視します
    }
});

// ジャンプ
const playerJumpCooldowns = new Map();
system.runInterval(() => {
    for (const [playerId, ticks] of playerJumpCooldowns.entries()) {
        if (ticks <= 1) {
            playerJumpCooldowns.delete(playerId);
        } else {
            playerJumpCooldowns.set(playerId, ticks - 1);
        }
    }

    for (const player of world.getAllPlayers()) {
        const isCooldown = playerJumpCooldowns.has(player.id);

        if (player.isJumping && !isCooldown) {
            player.addTag('playerJump');
            system.runTimeout(() => {
                player.removeTag('playerJump');
            }, 1);
            playerJumpCooldowns.set(player.id, 10);
        }
    }
});

// スニーク
const playerSneakingCooldowns = new Map();
system.runInterval(() => {
    for (const [playerId, ticks] of playerSneakingCooldowns.entries()) {
        if (ticks <= 1) {
            playerSneakingCooldowns.delete(playerId);
        } else {
            playerSneakingCooldowns.set(playerId, ticks - 1);
        }
    }

    for (const player of world.getAllPlayers()) {
        const isCooldown = playerSneakingCooldowns.has(player.id);

        if (player.isSneaking && !isCooldown) {
            player.addTag('playerSneak');
            system.runTimeout(() => {
                player.removeTag('playerSneak');
            }, 1);
            playerSneakingCooldowns.set(player.id, 10);
        }
    }
});
