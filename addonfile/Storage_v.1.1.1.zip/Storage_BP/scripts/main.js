import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { IDConfig } from './IDConfig.js';

// ========================================================
// 設定 & 定数
// ========================================================
const STORAGE_ITEM_IDS = ['additem:storage', 'additem:storage_blue', 'additem:storage_green', 'additem:storage_red', 'additem:storage_white'];
const CHECK_INTERVAL = 20; // 自動回収のチェック間隔 (Tick)
const MAX_RETRIEVE_BATCH = 10000; // 一度に取り出せる最大数 (ラグ対策)

const ACTION_COOLDOWN_TICKS = 50; // 操作クールダウン (10ティック = 0.5秒)
const playerActionHistory = new Map(); // プレイヤーの最終操作時間を記録

// Dynamic Property キー
const PROP_KEY = 'storage_data';

// IDConfigを検索しやすくするためのマップを作成
const ITEM_MAP = new Map();
// IDConfigは [id, name, texture] の配列
for (const entry of IDConfig) {
    if (entry && entry.length >= 2) {
        ITEM_MAP.set(entry[0], {
            name: entry[1],
            texture: entry.length >= 3 ? entry[2] : undefined,
        });
    }
}

// ========================================================
// ユーティリティ
// ========================================================

// ストレージアイテムかどうかを判定する関数
function isStorageItem(typeId) {
    return STORAGE_ITEM_IDS.includes(typeId);
}

function sendSystemMessage(player, message, colorCode) {
    player.sendMessage(`[§bStorage§r] ${colorCode}${message}`);
}

function getItemDisplayName(typeId) {
    if (!typeId) return 'なし';
    if (ITEM_MAP.has(typeId)) {
        return ITEM_MAP.get(typeId).name;
    }
    return typeId.replace('minecraft:', '');
}

function getItemTexture(typeId) {
    if (ITEM_MAP.has(typeId)) {
        return ITEM_MAP.get(typeId).texture;
    }
    return 'textures/ui/bubble_empty';
}

/**
 * ストレージに入れてよいアイテムか判定する
 */
function isAllowedItem(itemStack) {
    const typeId = itemStack.typeId;

    if (isStorageItem(typeId)) return false;
    if (itemStack.maxAmount === 1) return false;
    if (itemStack.getComponent('minecraft:durability')) return false;
    if (typeId.includes('shulker_box')) return false;
    if (typeId.includes('bundle')) return false;
    if (itemStack.nameTag) return false;

    const enchantments = itemStack.getComponent('minecraft:enchantments');
    if (enchantments && enchantments.enchantments && enchantments.enchantments.size > 0) return false;

    return true;
}

// ========================================================
// データ管理 (Item Dynamic Property)
// ========================================================

/**
 * アイテムからデータを読み込む
 * データ構造: { typeId: string | null, amount: number, collectionMode: boolean }
 */
function getStorageData(itemStack) {
    const dataStr = itemStack.getDynamicProperty(PROP_KEY);
    if (!dataStr) {
        return {
            typeId: null,
            amount: 0,
            collectionMode: false,
            replenishMode: false,
        };
    }
    try {
        const data = JSON.parse(dataStr);
        // 旧データにプロパティがない場合の補完
        if (data.replenishMode === undefined) data.replenishMode = false;
        return data;
    } catch (e) {
        return { typeId: null, amount: 0, collectionMode: false, replenishMode: false };
    }
}

/**
 * アイテムにデータを保存し、インベントリを更新する
 * 同時にLore（アイテムの説明文）も更新する
 */
function saveStorageItem(player, slotIndex, data, itemStackOverride = null) {
    const inventory = player.getComponent('inventory').container;

    // itemStackOverrideが渡されていない場合はインベントリから取得
    let itemStack = itemStackOverride;
    if (!itemStack) {
        itemStack = inventory.getItem(slotIndex);
    }

    if (!itemStack || !isStorageItem(itemStack.typeId)) return;

    // データの書き込み
    itemStack.setDynamicProperty(PROP_KEY, JSON.stringify(data));

    // 表示の更新 (Lore)
    updateItemLore(itemStack, data);

    // インベントリに反映
    inventory.setItem(slotIndex, itemStack);
}

/**
 * アイテムのLore（説明文）を更新して中身を表示する
 */
function updateItemLore(itemStack, data) {
    const lore = [];

    if (data.typeId) {
        const name = getItemDisplayName(data.typeId);
        lore.push(`§r§7中身: §f${name}`);
        lore.push(`§r§7個数: §e${data.amount.toLocaleString()}個`);

        if (data.collectionMode) {
            lore.push(`§r§7モード: §a回収ON`);
        } else if (data.replenishMode) {
            lore.push(`§r§7モード: §b補充ON`); // 補充は水色(§b)推奨
        } else {
            lore.push(`§r§7モード: §8OFF`);
        }
    } else {
        lore.push(`§r§7中身: §8未設定`);
        lore.push(`§r§7個数: §80個`);
    }

    itemStack.setLore(lore);
}

// ========================================================
// 自動回収システム
// ========================================================

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        try {
            processAutoCollection(player);
        } catch (e) {
            // エラー抑制
        }
    }
}, CHECK_INTERVAL);

function processAutoCollection(player) {
    const inventory = player.getComponent('inventory').container;
    const inventorySize = inventory.size;

    // 1回のスキャンで分類するためのリスト
    const storageSlots = [];
    const itemSummary = new Map();

    for (let i = 0; i < inventorySize; i++) {
        const item = inventory.getItem(i);
        if (!item) continue;

        if (isStorageItem(item.typeId)) {
            const lore = item.getLore();
            const hasActiveMode = lore.some(line => line.includes('ON'));

            storageSlots.push({
                slot: i,
                item: item,
                isActive: hasActiveMode,
            });
        } else {
            // 一般アイテムを発見
            if (!isAllowedItem(item)) continue;
            if (!itemSummary.has(item.typeId)) {
                itemSummary.set(item.typeId, []);
            }
            itemSummary.get(item.typeId).push(i);
        }
    }

    // ストレージが一つもなければ終了
    if (storageSlots.length === 0) return;

    // --- 見つかったストレージに対してのみ処理を行う ---
    for (const storageObj of storageSlots) {
        if (!storageObj.isActive) continue;

        const data = getStorageData(storageObj.item);
        if (!data.typeId) continue;

        let dataChanged = false;

        // --- 回収モードの処理 ---
        if (data.collectionMode) {
            const targets = itemSummary.get(data.typeId);
            if (!targets) continue;

            let keptOneItem = false;

            for (const targetSlot of targets) {
                const targetItem = inventory.getItem(targetSlot);
                if (!targetItem) continue;

                let amountToAdd = targetItem.amount;
                if (!keptOneItem) {
                    if (amountToAdd > 1) {
                        amountToAdd -= 1;
                        keptOneItem = true;
                    } else {
                        keptOneItem = true;
                        continue;
                    }
                }

                if (amountToAdd > 0) {
                    data.amount += amountToAdd;
                    dataChanged = true;

                    if (amountToAdd === targetItem.amount) {
                        inventory.setItem(targetSlot, undefined);
                    } else {
                        targetItem.amount -= amountToAdd;
                        inventory.setItem(targetSlot, targetItem);
                    }
                }
            }
        }

        // --- 補充モードの処理 ---
        else if (data.replenishMode) {
            const KEEP_AMOUNT = 30;

            // インベントリ内の現在の総数を計算
            let currentCount = 0;
            const targets = itemSummary.get(data.typeId);
            if (targets) {
                for (const tSlot of targets) {
                    const tItem = inventory.getItem(tSlot);
                    // アイテムが存在し、かつIDが一致している場合のみカウントする
                    if (tItem && tItem.typeId === data.typeId) {
                        currentCount += tItem.amount;
                    }
                }
            }

            // 足りない場合：補充する
            if (currentCount < KEEP_AMOUNT && data.amount > 0) {
                const needed = KEEP_AMOUNT - currentCount;
                const toAdd = Math.min(needed, data.amount);

                if (toAdd > 0) {
                    const newItem = new ItemStack(data.typeId, toAdd);
                    const leftOver = inventory.addItem(newItem);
                    const actualAdded = toAdd - (leftOver ? leftOver.amount : 0);

                    if (actualAdded > 0) {
                        data.amount -= actualAdded;
                        dataChanged = true;
                    }
                }
            }
            // 多い場合：回収する
            else if (currentCount > KEEP_AMOUNT) {
                let toRemove = currentCount - KEEP_AMOUNT;

                if (targets) {
                    for (const tSlot of targets) {
                        if (toRemove <= 0) break;

                        const tItem = inventory.getItem(tSlot);
                        if (!tItem) continue;

                        if (tItem.typeId !== data.typeId) continue;

                        // このスロットから回収する量
                        const removeAmount = Math.min(tItem.amount, toRemove);

                        // インベントリから減らす
                        if (removeAmount === tItem.amount) {
                            inventory.setItem(tSlot, undefined);
                        } else {
                            tItem.amount -= removeAmount;
                            inventory.setItem(tSlot, tItem);
                        }

                        // ストレージに増やす
                        data.amount += removeAmount;
                        toRemove -= removeAmount;
                        dataChanged = true;
                    }
                }
            }
        }

        // データに変更があった場合のみ保存
        if (dataChanged) {
            saveStorageItem(player, storageObj.slot, data, storageObj.item);
        }
    }
}

// ========================================================
// UI ロジック
// ========================================================

/**
 * メインメニュー
 * @param {Player} player
 * @param {number} slotIndex インベントリスロット番号
 */
async function openMainMenu(player, slotIndex) {
    const inventory = player.getComponent('inventory').container;
    const itemStack = inventory.getItem(slotIndex);

    if (!itemStack || !isStorageItem(itemStack.typeId)) return;

    const data = getStorageData(itemStack);

    // 紐付け状態の確認
    const isBound = !!data.typeId;
    const storedAmount = data.amount;
    const boundName = isBound ? getItemDisplayName(data.typeId) : '未設定';

    // アイコン取得
    const mainIcon = isBound ? getItemTexture(data.typeId) : 'textures/ui/bubble_empty';

    const form = new ActionFormData();
    form.title('§1ストレージ');
    form.body('>>> §e選択してください');
    let bodyText = `§0中身: §1${boundName}\n`;
    bodyText += `§0個数: §5${storedAmount}個`;
    form.button(`${bodyText}`, mainIcon);
    // ボタン設定
    const buttons = [];
    buttons.push({ text: '§1入れる', icon: 'textures/ui/bubble_empty', action: 'insert' });

    if (isBound && storedAmount > 0) {
        buttons.push({ text: '§5取り出す', icon: 'textures/ui/bubble_empty', action: 'retrieve' });
        const colStatus = data.collectionMode ? '§1ON' : '§4OFF';
        const repStatus = data.replenishMode ? '§1ON' : '§4OFF';
        buttons.push({ text: `§4回収モード\n§0(${colStatus}§0)`, icon: 'textures/ui/refresh', action: 'collection' });
        buttons.push({ text: `§1自動補充\n§0(${repStatus}§0)`, icon: 'textures/ui/refresh', action: 'replenish' });
    } else if (isBound && storedAmount === 0) {
        const colStatus = data.collectionMode ? '§1ON' : '§4OFF';
        const repStatus = data.replenishMode ? '§1ON' : '§4OFF';
        buttons.push({ text: `§4回収モード\n§0(${colStatus}§0)`, icon: 'textures/ui/refresh', action: 'collection' });
        buttons.push({ text: `§1自動補充\n§0(${repStatus}§0)`, icon: 'textures/ui/refresh', action: 'replenish' });
    }

    // ★色変更ボタンを追加
    buttons.push({ text: '§0色を変更', icon: 'textures/ui/color_picker', action: 'color' });

    // 登録したボタンをフォームにセット
    for (const btn of buttons) {
        form.button(btn.text, btn.icon);
    }

    const response = await form.show(player);

    if (response.canceled) return;
    if (response.selection === 0) {
        // メイン情報(一番上)のボタンを押した時
        await openMainMenu(player, slotIndex);
        return;
    }

    // 押したボタンの種類に応じて安全に処理を振り分け
    const selectedAction = buttons[response.selection - 1].action;

    if (selectedAction === 'insert') {
        await openInsertMenu(player, slotIndex, data);
    } else if (selectedAction === 'retrieve') {
        await openQuantityInput(player, slotIndex, data, { item: { typeId: data.typeId, amount: storedAmount } }, false);
    } else if (selectedAction === 'collection') {
        toggleCollectionMode(player, slotIndex, data);
    } else if (selectedAction === 'replenish') {
        toggleReplenishMode(player, slotIndex, data);
    } else if (selectedAction === 'color') {
        await openColorChangeMenu(player, slotIndex, data); // ★追加した処理
    }
}

function toggleCollectionMode(player, slotIndex, _data) {
    const now = system.currentTick;
    const lastAction = playerActionHistory.get(player.id) || 0;

    if (now - lastAction < ACTION_COOLDOWN_TICKS) {
        sendSystemMessage(player, '操作が早すぎます >>>少しお待ちください', '§e');
        // メニューに戻す
        system.run(() => openMainMenu(player, slotIndex));
        return;
    }
    playerActionHistory.set(player.id, now);

    const inventory = player.getComponent('inventory').container;
    const item = inventory.getItem(slotIndex);
    if (!item || !isStorageItem(item.typeId)) return;

    const data = getStorageData(item);

    data.collectionMode = !data.collectionMode;
    if (data.collectionMode) {
        data.replenishMode = false;
    }

    saveStorageItem(player, slotIndex, data);

    const status = data.collectionMode ? '有効' : '無効';
    const color = data.collectionMode ? '§a' : '§c';
    sendSystemMessage(player, `回収モードを ${status} にしました`, color);

    openMainMenu(player, slotIndex);
}

function toggleReplenishMode(player, slotIndex, data) {
    const now = system.currentTick;
    const lastAction = playerActionHistory.get(player.id) || 0;

    if (now - lastAction < ACTION_COOLDOWN_TICKS) {
        sendSystemMessage(player, '操作が早すぎます >>>少しお待ちください', '§e');
        // メニューに戻す
        system.run(() => openMainMenu(player, slotIndex));
        return;
    }
    playerActionHistory.set(player.id, now);

    data.replenishMode = !data.replenishMode;
    if (data.replenishMode) {
        data.collectionMode = false;
    }

    saveStorageItem(player, slotIndex, data);

    const status = data.replenishMode ? '有効' : '無効';
    const color = data.replenishMode ? '§a' : '§c';
    sendSystemMessage(player, `自動補充モードを ${status} にしました`, color);

    openMainMenu(player, slotIndex);
}

/**
 * アイテムを入れるメニュー
 */
async function openInsertMenu(player, slotIndex, data) {
    const inventory = player.getComponent('inventory').container;
    const isBound = !!data.typeId;

    // 紐付け済みなら自動で対象アイテムを集計して遷移
    if (isBound) {
        let totalCount = 0;
        // インベントリ内を走査して合計数を計算
        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (item && item.typeId === data.typeId && isAllowedItem(item)) {
                totalCount += item.amount;
            }
        }

        if (totalCount === 0) {
            sendSystemMessage(player, `インベントリに ${getItemDisplayName(data.typeId)} がありません`, '§c');
            return;
        }

        // 選択画面をスキップして入力画面へ
        const targetEntry = {
            index: -1, // 一括挿入フラグ
            item: { typeId: data.typeId, amount: totalCount },
        };
        await openQuantityInput(player, slotIndex, data, targetEntry, true);
        return;
    }

    // 未設定時: 挿入可能なアイテムをIDごとに集計
    const itemMap = new Map(); // Key: typeId, Value: totalAmount

    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) {
            if (!isAllowedItem(item)) continue;

            // 既存の個数に加算
            const currentAmount = itemMap.get(item.typeId) || 0;
            itemMap.set(item.typeId, currentAmount + item.amount);
        }
    }

    if (itemMap.size === 0) {
        sendSystemMessage(player, '入れることができるアイテムがありません。', '§c');
        return;
    }

    // Mapから配列を生成
    const availableItems = [];
    for (const [typeId, amount] of itemMap) {
        availableItems.push({
            typeId: typeId,
            amount: amount,
        });
    }

    const form = new ActionFormData();
    form.title('§1入れる');
    form.body('>>> §e紐付けたいアイテムを選択してください\n§c※一度決めると変更できません');
    form.button('§l戻る', 'textures/ui/icon_import.png');

    // 集計したリストでボタン生成
    for (const entry of availableItems) {
        const displayName = getItemDisplayName(entry.typeId);
        const icon = getItemTexture(entry.typeId);
        // 合計個数を表示
        form.button(`§0${displayName}\n§1x${entry.amount}`, icon);
    }

    const response = await form.show(player);
    if (response.canceled) return;
    if (response.selection == 0) {
        await openMainMenu(player, slotIndex);
        return;
    }

    // 選択されたアイテム情報を取得
    const selectedItem = availableItems[response.selection - 1];

    // 次の関数(openBindConfirmation)が期待する構造に合わせてオブジェクトを作成
    const selectedEntry = {
        item: {
            typeId: selectedItem.typeId,
            amount: selectedItem.amount,
        },
    };

    // 紐付け確認画面
    await openBindConfirmation(player, slotIndex, data, selectedEntry);
}

/**
 * 紐付け確認画面
 */
async function openBindConfirmation(player, slotIndex, data, selectedEntry) {
    const itemName = getItemDisplayName(selectedEntry.item.typeId);

    const form = new MessageFormData();
    form.title('§0紐付けの確認');
    form.body(`このストレージを §e[ ${itemName} ]§r 専用にします\n\n§c※一度紐付けると、他のアイテムを入れることはできなくなります`);
    form.button1('§4キャンセル');
    form.button2('§1確認');

    const response = await form.show(player);

    if (response.selection === 1) {
        // 紐付け実行（データにtypeIdをセット）
        data.typeId = selectedEntry.item.typeId;
        // データ保存
        saveStorageItem(player, slotIndex, data);
        sendSystemMessage(player, `ストレージを ${itemName} に紐付けました`, '§a');

        // インベントリ内の同種アイテムの総数を計算する
        const inventory = player.getComponent('inventory').container;
        let totalCount = 0;
        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            // 許可されたアイテムかつTypeIDが一致するものをカウント
            if (item && item.typeId === data.typeId && isAllowedItem(item)) {
                totalCount += item.amount;
            }
        }

        const allItemsEntry = {
            index: -1,
            item: { typeId: data.typeId, amount: totalCount },
        };

        // 数量入力へ（一括モードのオブジェクトを渡す）
        await openQuantityInput(player, slotIndex, data, allItemsEntry, true);
    } else {
        await openMainMenu(player, slotIndex);
    }
}

/**
 * 個数入力フォーム
 */
async function openQuantityInput(player, slotIndex, data, targetObj, isInsert) {
    const maxAmount = targetObj.item.amount;
    const typeId = targetObj.item.typeId || data.typeId;
    const displayName = getItemDisplayName(typeId);

    const form = new ModalFormData();
    const actionText = isInsert ? '入れる' : '取り出す';
    form.title(`§0${actionText}: ${displayName}`);

    let placeHolder = `0 = すべて`;
    let defaultVal = '0';

    if (!isInsert) {
        placeHolder += ` (最大: ${MAX_RETRIEVE_BATCH})`;
    }

    form.textField(`>>> §e個数を入力 §c※0で全選択\n§a対象: ${maxAmount}個`, placeHolder, {
        defaultValue: defaultVal,
    });

    const response = await form.show(player);
    if (response.canceled) return;

    let inputStr = response.formValues[0];
    let amount = parseInt(inputStr);

    if (isNaN(amount) || amount < 0) {
        sendSystemMessage(player, '無効な数値です', '§c');
        return;
    }

    if (amount === 0) amount = maxAmount;
    if (amount > maxAmount) amount = maxAmount;

    if (!isInsert && amount > MAX_RETRIEVE_BATCH) {
        amount = MAX_RETRIEVE_BATCH;
        sendSystemMessage(player, `ラグ対策のため、一度に取り出せるのは ${MAX_RETRIEVE_BATCH}個 までです`, '§e');
    }

    if (isInsert) {
        processInsert(player, slotIndex, data, targetObj.index, amount);
    } else {
        processRetrieve(player, slotIndex, data, amount);
    }
}

/**
 * 挿入処理
 */
function processInsert(player, slotIndex, data, sourceSlotIndex, amount) {
    const inventory = player.getComponent('inventory').container;

    const currentItem = inventory.getItem(slotIndex);

    // スロットが空、またはストレージアイテムではない場合はキャンセル
    if (!currentItem || !isStorageItem(currentItem.typeId)) {
        sendSystemMessage(player, 'アイテムの移動を検知したためキャンセルしました', '§c');
        return;
    }
    // 別のストレージアイテムとすり替えられていないかデータで確認
    const currentData = getStorageData(currentItem);
    if (currentData.typeId !== data.typeId || currentData.amount !== data.amount) {
        sendSystemMessage(player, 'アイテムの変更を検知したためキャンセルしました', '§c');
        return;
    }

    // 一括回収 (sourceSlotIndex === -1)
    if (sourceSlotIndex === -1) {
        let remainingToTake = amount;
        let takenCount = 0;

        for (let i = 0; i < inventory.size; i++) {
            if (remainingToTake <= 0) break;
            if (i === slotIndex) continue; // 自分自身はスキップ

            const item = inventory.getItem(i);
            if (!item || item.typeId !== data.typeId || !isAllowedItem(item)) continue;

            const take = Math.min(item.amount, remainingToTake);

            if (take >= item.amount) {
                inventory.setItem(i, undefined);
            } else {
                item.amount -= take;
                inventory.setItem(i, item);
            }

            remainingToTake -= take;
            takenCount += take;
        }

        if (takenCount > 0) {
            data.amount += takenCount;
            saveStorageItem(player, slotIndex, data);
            sendSystemMessage(player, `${getItemDisplayName(data.typeId)} を ${takenCount}個 収納しました`, '§a');
        }
        return;
    }

    // 単一スロット挿入 (紐付け時)
    const itemStack = inventory.getItem(sourceSlotIndex);
    if (!itemStack) return;

    if (data.typeId && itemStack.typeId !== data.typeId) {
        sendSystemMessage(player, 'アイテムの種類が一致しません。', '§c');
        return;
    }

    // 初回紐付け時はここでtypeIdが確定するが、openBindConfirmationですでにセットされている想定
    if (!data.typeId) {
        data.typeId = itemStack.typeId;
    }

    data.amount += amount;

    if (amount >= itemStack.amount) {
        inventory.setItem(sourceSlotIndex, undefined);
    } else {
        itemStack.amount -= amount;
        inventory.setItem(sourceSlotIndex, itemStack);
    }

    saveStorageItem(player, slotIndex, data);
    sendSystemMessage(player, `${getItemDisplayName(itemStack.typeId)} を ${amount}個 収納しました`, '§a');
}

/**
 * 取り出し処理
 */
function processRetrieve(player, slotIndex, data, amount) {
    const inventory = player.getComponent('inventory').container;
    const dimension = player.dimension;

    const currentItem = inventory.getItem(slotIndex);

    // スロットが空、またはストレージアイテムではない場合はキャンセル
    if (!currentItem || !isStorageItem(currentItem.typeId)) {
        sendSystemMessage(player, 'アイテムの移動を検知したためキャンセルしました', '§c');
        return;
    }
    // 別のストレージアイテムとすり替えられていないかデータで確認
    const currentData = getStorageData(currentItem);
    if (currentData.typeId !== data.typeId || currentData.amount !== data.amount) {
        sendSystemMessage(player, 'アイテムの変更を検知したためキャンセルしました', '§c');
        return;
    }

    if (!data.typeId || data.amount < amount) return;

    let remaining = amount;
    let overflowCount = 0;

    // スタック上限取得（デフォルト64）
    let maxStack = 64;
    try {
        const dummy = new ItemStack(data.typeId, 1);
        maxStack = dummy.maxAmount;
    } catch (e) {}

    while (remaining > 0) {
        const stackSize = Math.min(remaining, maxStack);
        const newItem = new ItemStack(data.typeId, stackSize);

        const leftOver = inventory.addItem(newItem);

        if (leftOver) {
            const loc = player.location;
            const spawnLoc = { x: loc.x, y: loc.y + 0.5, z: loc.z };
            dimension.spawnItem(leftOver, spawnLoc);
            overflowCount += leftOver.amount;
        }

        remaining -= stackSize;
    }

    data.amount -= amount;

    // 取り出しても紐付けは解除しない（amountが0になるだけ）

    saveStorageItem(player, slotIndex, data);

    let msg = `${getItemDisplayName(data.typeId)} を ${amount}個 取り出しました`;
    if (overflowCount > 0) {
        msg += `\n§eインベントリに入り切らなかった ${overflowCount}個 を足元に落としました`;
    }
    sendSystemMessage(player, msg, '§d');
}

/**
 * ストレージの色を変更するメニュー
 */
async function openColorChangeMenu(player, slotIndex, data) {
    const COLORS = [
        { id: 'additem:storage', name: 'デフォルト', texture: 'textures/items/storage' },
        { id: 'additem:storage_blue', name: 'ブルー', texture: 'textures/items/storage_blue' },
        { id: 'additem:storage_green', name: 'グリーン', texture: 'textures/items/storage_green' },
        { id: 'additem:storage_red', name: 'レッド', texture: 'textures/items/storage_red' },
        { id: 'additem:storage_white', name: 'ホワイト', texture: 'textures/items/storage_white' },
    ];

    const form = new ActionFormData();
    form.title('§1色の変更');
    form.body('>>> §e変更したい色を選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    for (const color of COLORS) {
        form.button(`§0${color.name}`, color.texture);
    }

    const response = await form.show(player);
    if (response.canceled) return;

    if (response.selection == 0) {
        await openMainMenu(player, slotIndex);
        return;
    }
    const selectedColorId = COLORS[response.selection - 1].id;
    const inventory = player.getComponent('inventory').container;
    const currentItem = inventory.getItem(slotIndex);

    // 安全対策：アイテムが移動・すり替えられていないか再確認
    if (!currentItem || !isStorageItem(currentItem.typeId)) {
        sendSystemMessage(player, 'アイテムの移動を検知したためキャンセルしました', '§c');
        return;
    }
    const currentData = getStorageData(currentItem);
    if (currentData.typeId !== data.typeId || currentData.amount !== data.amount) {
        sendSystemMessage(player, 'アイテムの変更を検知したためキャンセルしました', '§c');
        return;
    }

    if (currentItem.typeId === selectedColorId) {
        sendSystemMessage(player, 'すでにその色です', '§e');
        return;
    }

    // 新しい色のアイテムを作成し、プロパティとLore（見た目）を引き継ぐ
    const newItem = new ItemStack(selectedColorId, 1);
    newItem.setDynamicProperty(PROP_KEY, JSON.stringify(data));
    // 金床でつけたオリジナルネームがある場合は引き継ぐ
    if (currentItem.nameTag) {
        newItem.nameTag = currentItem.nameTag;
    }
    updateItemLore(newItem, data);

    // インベントリのアイテムを上書き
    inventory.setItem(slotIndex, newItem);
    sendSystemMessage(player, 'ストレージの色を変更しました', '§a');
}

// ========================================================
// イベントリスナー
// ========================================================

world.afterEvents.itemUse.subscribe(event => {
    const player = event.source;
    const itemStack = event.itemStack;

    if (isStorageItem(itemStack.typeId)) {
        
        // 視線の先のブロックを取得 (最大7ブロック先)
        const blockRaycast = player.getBlockFromViewDirection({ maxDistance: 7 });
        if (blockRaycast && blockRaycast.block) {
            const blockId = blockRaycast.block.typeId;
            // 額縁、輝く額縁を見ている場合はUI処理をキャンセル
            if (blockId === 'minecraft:frame' || blockId === 'minecraft:glow_frame') {
                return;
            }
        }

        // 視線の先のエンティティを取得 (最大7ブロック先)
        const entityRaycast = player.getEntitiesFromViewDirection({ maxDistance: 7 });
        if (entityRaycast && entityRaycast.length > 0) {
            const entityId = entityRaycast[0].entity.typeId;
            if (entityId === 'minecraft:armor_stand' || entityId === 'minecraft:allay') {
                return;
            }
        }

        // 現在のスロット番号を取得
        const selectedSlot = player.selectedSlotIndex;

        // 既存データの読み込み、なければ初期化して保存
        let data = getStorageData(itemStack);
        // 初回などでLoreが設定されていない場合に備えて一度保存処理を通す
        saveStorageItem(player, selectedSlot, data, itemStack);

        system.run(() => {
            openMainMenu(player, selectedSlot).catch(e => {
                console.warn(e);
            });
        });
    }
});

// ========================================================
// スニーク + 左クリック (1スタック取り出し)
// ========================================================
world.afterEvents.playerSwingStart.subscribe(event => {
    const player = event.player;
    if (!player || !player.isSneaking) return;

    const inventory = player.getComponent('inventory')?.container;
    if (!inventory) return;

    const slotIndex = player.selectedSlotIndex;
    const itemStack = inventory.getItem(slotIndex);

    if (!itemStack || !isStorageItem(itemStack.typeId)) return;

    const data = getStorageData(itemStack);

    if (!data.typeId || data.amount <= 0) return;

    // 1スタックの最大数を取得
    let stackLimit = 64;
    try {
        const dummyItem = new ItemStack(data.typeId, 1);
        stackLimit = dummyItem.maxAmount ?? 64;
    } catch (e) {
        stackLimit = 64;
    }

    const retrieveAmount = Math.min(data.amount, stackLimit);

    if (retrieveAmount > 0) {
        processRetrieve(player, slotIndex, data, retrieveAmount);
    }
});
