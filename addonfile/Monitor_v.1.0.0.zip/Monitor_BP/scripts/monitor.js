import { world, system, GameMode } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

// 監視中の管理者のリスト
const monitoringAdmins = new Map();

export function isMonitoringPlayer(player) {
    return monitoringAdmins.has(player.id);
}

export function stopMonitoringPlayer(player) {
    if (monitoringAdmins.has(player.id)) {
        const state = monitoringAdmins.get(player.id);
        endMonitoring(player, state.runId);
    }
}

// 監視対象プレイヤー選択UIを表示
export function UI(player) {
    const players = world.getPlayers();
    const targets = players.filter(p => p.id !== player.id);

    if (targets.length === 0) {
        player.sendMessage('§r[§bMonitor§r] §c監視対象のプレイヤーがいません');
        return;
    }

    const form = new ActionFormData().title('§0Monitor').body('>>> §e選択してください');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    targets.forEach(target => {
        form.button(`§0${target.name}`, 'textures/ui/permissions_member_star.png');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            UI(player);
            return;
        }

        const targetPlayer = targets[res.selection - 1];
        startMonitoring(player, targetPlayer);
    });
}

// 監視開始
export function startMonitoring(admin, target) {
    if (monitoringAdmins.has(admin.id)) return;

    const originState = {
        location: admin.location,
        dimensionId: admin.dimension.id,
        gamemode: admin.getGameMode(),
    };

    admin.setDynamicProperty('monitor_backup', JSON.stringify(originState));

    const state = {
        runId: undefined,
        origin: originState,
        lastY: undefined,
    };
    monitoringAdmins.set(admin.id, state);

    // スペクテイターに変更してターゲットの次元・位置へTP
    try {
        admin.setGameMode(GameMode.Spectator);
        const firstTpLoc = {
            x: target.location.x,
            y: target.location.y + 30,
            z: target.location.z,
        };
        admin.teleport(firstTpLoc, { dimension: target.dimension });

        // TP直後のY座標を基準として保存
        state.lastY = admin.location.y;
    } catch (e) {
        admin.sendMessage('§c監視の開始に失敗しました');
        monitoringAdmins.delete(admin.id);
        return;
    }

    admin.sendMessage(`§r[§bMonitor§r] §a${target.name}の監視を開始しました。`);
    admin.sendMessage(`§e解除するには「ジャンプ(上昇)」か「スニーク(下降)」して動いてください`);

    const runId = system.runInterval(() => {
        try {
            const health = admin.getComponent('health');
            if (!target.isValid || !admin.isValid || (health && health.currentValue <= 0)) {
                throw new Error('Stop Monitoring');
            }
        } catch (e) {
            endMonitoring(admin, runId);
            return;
        }

        const currentY = admin.location.y;

        // 設定を読み取る (デフォルトは true)
        const allowMoveCancel = admin.getDynamicProperty('monitor_move_cancel') ?? true;

        if (admin.dimension.id !== target.dimension.id) {
            admin.teleport(target.location, { dimension: target.dimension });
            state.lastY = admin.location.y;
            return;
        }

        // 設定が許可されている場合のみ、移動による解除を行う
        if (allowMoveCancel && Math.abs(currentY - state.lastY) > 0.1) {
            endMonitoring(admin, runId);
            return;
        }

        state.lastY = currentY;
        syncCamera(admin, target);

        // アクションバー表示の分岐
        const cancelMsg = allowMoveCancel ? ' §7(上昇/下降で解除)' : '';
        admin.onScreenDisplay.setActionBar(`§c監視中: §f${target.name}${cancelMsg}`);
    }, 1);

    state.runId = runId;
}

function syncCamera(admin, target) {
    const tLoc = target.location;
    const tRot = target.getRotation();

    const radY = tRot.y * (Math.PI / 180); // Yaw (横回転)
    const radX = tRot.x * (Math.PI / 180); // Pitch (縦回転)

    // ダイナミックプロパティから設定を取得
    const viewMode = admin.getDynamicProperty('monitor_view') || 'tps';

    let camLoc;

    if (viewMode === 'fps') {
        // 一人称: ターゲットの目の位置 (スニーク判定付き)
        const eyeHeight = target.isSneaking ? 1.42 : 1.62;

        // カメラ遅延対策：向いている方向へ0.4ブロック分前にずらして頭の映り込みを防ぐ
        const offset = 0.4;
        const hOffset = offset * Math.cos(radX);

        camLoc = {
            x: tLoc.x - Math.sin(radY) * hOffset,
            y: tLoc.y + eyeHeight - Math.sin(radX) * offset,
            z: tLoc.z + Math.cos(radY) * hOffset,
        };
    } else {
        // 三人称: 既存の処理 (後方から見下ろす)
        const dist = 4;
        const hDist = dist * Math.cos(radX);
        camLoc = {
            x: tLoc.x + Math.sin(radY) * hDist,
            y: tLoc.y + 2.5 + Math.sin(radX) * dist,
            z: tLoc.z - Math.cos(radY) * hDist,
        };
    }

    const camRot = { x: tRot.x, y: tRot.y };

    admin.camera.setCamera('minecraft:free', {
        location: camLoc,
        rotation: camRot,
        easeOptions: {
            easeTime: 0.1,
            easeType: 'Linear',
        },
    });
}

// 監視終了処理
function endMonitoring(admin, runId) {
    if (runId !== undefined) system.clearRun(runId);

    const state = monitoringAdmins.get(admin.id);

    admin.setDynamicProperty('monitor_backup', undefined);

    try {
        admin.camera.clear();
        admin.onScreenDisplay.setActionBar('');
    } catch (e) {}

    if (state && state.origin) {
        try {
            const { location, dimension, gamemode } = state.origin;
            // 死亡している場合はテレポートさせない（エラー防止）
            const health = admin.getComponent('health');
            if (health && health.currentValue > 0) {
                admin.teleport(location, { dimension: dimension });
                admin.setGameMode(gamemode);
            }
        } catch (e) {
            try {
                admin.setGameMode(GameMode.survival);
            } catch (err) {}
        }
    }

    system.runTimeout(() => {
        if (admin && admin.isValid) admin.camera.clear();
    }, 5);

    admin.sendMessage('§r[§bMonitor§r] §a監視を終了しました');
    monitoringAdmins.delete(admin.id);
}

// 設定UI (一人称/三人称切り替え)
export function SettingsUI(player) {
    const currentView = player.getDynamicProperty('monitor_view') || 'tps';
    const defaultIndex = currentView === 'fps' ? 0 : 1;
    // デフォルトは true (許可)
    const allowMoveCancel = player.getDynamicProperty('monitor_move_cancel') ?? true;

    const form = new ModalFormData().title('§0Monitor 設定').dropdown('視点モードを選択', ['一人称視点 (FPS)', '三人称視点 (TPS)'], { defaultValueIndex: defaultIndex }).toggle('上昇/下降で監視を解除する', {
        defaultValue: allowMoveCancel,
    }); // トグルを追加

    form.show(player).then(res => {
        if (res.canceled) return;
        const selectedView = res.formValues[0] === 0 ? 'fps' : 'tps';
        const setMoveCancel = res.formValues[1];

        player.setDynamicProperty('monitor_view', selectedView);
        player.setDynamicProperty('monitor_move_cancel', setMoveCancel);

        player.sendMessage(`§r[§bMonitor§r] §a設定を保存しました`);
    });
}

// 再起動後の復旧処理
export function restoreIfMonitoring(player) {
    const backup = player.getDynamicProperty('monitor_backup');
    if (!backup) return;

    try {
        const { location, dimensionId, gamemode } = JSON.parse(backup);
        const dimension = world.getDimension(dimensionId);

        player.teleport(location, { dimension: dimension });
        player.setGameMode(gamemode);
        player.camera.clear();
        player.onScreenDisplay.setActionBar('');

        player.sendMessage('§r[§bMonitor§r] §e再起動が検知されたため、元の場所に戻りました');
    } catch (e) {
        console.warn('Restore failed: ' + e);
    } finally {
        player.setDynamicProperty('monitor_backup', undefined);
        monitoringAdmins.delete(player.id);
    }
}
