import { world, system } from '@minecraft/server';
import { UI, startMonitoring, SettingsUI, isMonitoringPlayer, stopMonitoringPlayer, restoreIfMonitoring } from './monitor';

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === 'additem:monitor') {
        const player = eventData.source;
        system.run(() => {
            UI(player);
        });
    }
});

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'monitor:o') {
            const selector = eventData.message.trim();
            const targetPlayers = parseSelector(selector);
            if (targetPlayers[0] == undefined) {
                player.sendMessage(`§r[§bMonitor§r] §cセレクターが見つかりません`);
                return;
            }
            if (targetPlayers.length > 1) {
                player.sendMessage(`§r[§bMonitor§r] §c複数のプレイヤーをセレクト出来ません`);
                return;
            }
            startMonitoring(player, targetPlayers[0]);
        }
        if (eventData.id === 'monitor:s') {
            SettingsUI(player);
        }
        if (eventData.id === 'monitor:stop') {
            const selector = eventData.message.trim();
            const targetPlayers = parseSelector(selector);
            if (targetPlayers[0] == undefined) {
                player.sendMessage(`§r[§bMonitor§r] §cセレクターが見つかりません`);
                return;
            }
            for (const targetPlayer of targetPlayers) {
                if (isMonitoringPlayer(targetPlayer)) {
                    stopMonitoringPlayer(targetPlayer);
                }
            }
        }
    });
});

// セレクター
function parseSelector(selector) {
    if (!selector) return [];

    var players = [];
    for (const player of world.getPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}

// 管理者がリスポーンした時に監視を解除する
world.afterEvents.playerSpawn.subscribe(eventData => {
    const player = eventData.player;
    const { initialSpawn } = eventData;

    if (initialSpawn) {
        restoreIfMonitoring(player);
    } else {
        if (isMonitoringPlayer(player)) {
            stopMonitoringPlayer(player);
        }
    }
});
