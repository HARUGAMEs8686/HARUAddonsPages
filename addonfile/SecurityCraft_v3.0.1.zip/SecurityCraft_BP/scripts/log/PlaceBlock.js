import { world, system } from '@minecraft/server';
import { checkModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // Default to 7 days if not set
let pendingUpdates = new Map();

// Initialize DAYS_TO_KEEP
export function preload() {
    const storedDays = world.getDynamicProperty('placeblock_delete_speed');
    DAYS_TO_KEEP = storedDays !== undefined ? storedDays : DAYS_TO_KEEP;
}

// Generate compact chunk key
function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `${chunkX}_${chunkZ}_${day}`;
}

// Generate compact position key
function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

// Save chunk data with size optimization
function saveChunkData(chunkKey, chunkData) {
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`Error saving chunk data for ${chunkKey}: ${e}`);
    }
}

// Load chunk data
function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        return storedData ? new Map(JSON.parse(storedData)) : new Map();
    } catch (e) {
        console.warn(`Error loading chunk data for ${chunkKey}: ${e}`);
        return new Map();
    }
}

// Process pending updates
system.runInterval(() => {
    for (const [chunkKey, chunkData] of pendingUpdates) {
        saveChunkData(chunkKey, chunkData);
    }
}, 2); // Reduced interval for faster processing

export function PlaceBlock() {
    // Handle block placement
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        let chunkData = getChunkData(chunkKey);
        chunkData.set(positionKey, {
            p: player.name,
            t: Date.now()
        });

        // Immediate cleanup of old data
        const expirationTime = Date.now() - (DAYS_TO_KEEP * MILLISECONDS_PER_DAY);
        for (const [pos, data] of chunkData) {
            if (data.t < expirationTime) {
                chunkData.delete(pos);
            }
        }

        pendingUpdates.set(chunkKey, chunkData);
    });

    // Handle block breaking
    world.afterEvents.playerBreakBlock.subscribe(event => {
        const block = event.block;
        const { x, y, z } = block;
        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        let chunkData = getChunkData(chunkKey);
        if (chunkData.delete(positionKey)) {
            pendingUpdates.set(chunkKey, chunkData);
        }
    });

    // Handle block interaction
    const playerCache = new Map();
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!checkModePlayers.has(player.name) || playerCache.has(player.id)) return;

            playerCache.set(player.id, true);
            const block = event.block;
            const { x, y, z } = block;
            const chunkKey = getChunkKey(x, z);
            const positionKey = getPositionKey(x, y, z);

            const chunkData = getChunkData(chunkKey);
            const blockData = chunkData.get(positionKey);

            if (blockData) {
                player.sendMessage(`§r[§bSecurity§r] §5${blockData.p}§rによって§e設置`);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurity§r] §cこのブロックの設置者情報はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }

            system.runTimeout(() => {
                playerCache.delete(player.id);
            }, 10); // Reduced timeout for faster cache clearing
        });
    });
}

export function clearAllPlaceData() {
    const allKeys = world.getDynamicPropertyIds();
    for (const key of allKeys) {
        if (key.match(/^-?\d+_-?\d+_\d+$/)) {
            world.setDynamicProperty(key, undefined);
        }
    }
    pendingUpdates.clear();
}