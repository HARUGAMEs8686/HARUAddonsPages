import { world, system } from '@minecraft/server';
import { playerCheckModeStatus } from '../main';

const CHUNK_SIZE = 16;

var DAYS_TO_KEEP = world.getDynamicProperty('breakblock_delete_speed') || 7; // デフォルト7日
export function breload() {
    DAYS_TO_KEEP = world.getDynamicProperty('breakblock_delete_speed') || 7;
}

const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let pendingUpdates = {};

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `break_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`; // シンプルな文字列ベースのキー
}

function cleanOldData() {
    const currentTime = Date.now();
    const dayKey = Math.floor(currentTime / MILLISECONDS_PER_DAY);
    const expirationTime = dayKey - DAYS_TO_KEEP;
    const allKeys = world.getDynamicPropertyIds();
    for (const key of allKeys) {
        if (key.startsWith('break_')) {
            const match = key.match(/break_(-?\d+)_(-?\d+)_(\d+)(?:_part\d+)?/);
            if (match && parseInt(match[3]) < expirationTime) {
                world.setDynamicProperty(key, undefined);
            }
        }
    }
}

function saveChunkData(chunkKey, chunkData) {
    const MAX_SIZE = 256 * 1024; // 256KB
    let part = 1;
    let currentData = {};
    let currentSize = 0;

    // 既存の部分データをクリア
    while (world.getDynamicProperty(`${chunkKey}_part${part}`)) {
        world.setDynamicProperty(`${chunkKey}_part${part}`, undefined);
        part++;
    }
    part = 1;

    for (const [positionKey, data] of Object.entries(chunkData)) {
        const entrySize = JSON.stringify({ [positionKey]: data }).length;
        if (currentSize + entrySize > MAX_SIZE) {
            world.setDynamicProperty(`${chunkKey}_part${part}`, JSON.stringify(currentData));
            part++;
            currentData = {};
            currentSize = 0;
        }
        currentData[positionKey] = data;
        currentSize += entrySize;
    }
    if (Object.keys(currentData).length > 0) {
        world.setDynamicProperty(`${chunkKey}_part${part}`, JSON.stringify(currentData));
    }
    delete pendingUpdates[chunkKey]; // 保存後すぐに削除
}

function getChunkData(chunkKey) {
    let chunkData = {};
    let part = 1;
    while (true) {
        const storedData = world.getDynamicProperty(`${chunkKey}_part${part}`);
        if (!storedData) break;
        try {
            Object.assign(chunkData, JSON.parse(storedData));
        } catch (e) {
            console.warn(`Error parsing chunk data for ${chunkKey}_part${part}: ${e}`);
        }
        part++;
    }
    return chunkData;
}

export function clearAllBreakData() {
    const allKeys = world.getDynamicPropertyIds();
    for (const key of allKeys) {
        if (key.startsWith('break_')) {
            world.setDynamicProperty(key, undefined);
        }
    }
}

system.runInterval(() => {
    for (const chunkKey in pendingUpdates) {
        try {
            saveChunkData(chunkKey, pendingUpdates[chunkKey]);
        } catch (e) {
            console.warn(`Error saving chunk data for ${chunkKey}: ${e}`);
        }
    }
    pendingUpdates = {};
    cleanOldData();
}, 1);

export function BreakBlock() {
    const lastBreakTime = new Map();

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const now = Date.now();
        const lastBreak = lastBreakTime.get(player.name) || 0;

        // 100ms以内の同一プレイヤーのイベントを無視
        if (now - lastBreak < 100) return;
        lastBreakTime.set(player.name, now);

        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        let chunkData = getChunkData(chunkKey);
        chunkData[positionKey] = {
            b: player.name,
            t: now,
            bt: block.typeId,
        };
        pendingUpdates[chunkKey] = chunkData; // pendingUpdatesに追加
    });

    const lastCheckTime = new Map();

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!playerCheckModeStatus[player.name]) return;

            const now = Date.now();
            const lastCheck = lastCheckTime.get(player.name) || 0;
            if (now - lastCheck < 1000) return;
            lastCheckTime.set(player.name, now);

            if (!event.block || !event.block.location) {
                console.error('ブロックの位置情報が無効です。');
                return;
            }

            const nearbyBreaks = getNearbyBreakHistory(event.block.location);

            if (nearbyBreaks.length > 0) {
                displayBreakSummary(player, nearbyBreaks);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurity§r] §eこの周辺に最近の破壊履歴はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }
        });
    });

    function getNearbyBreakHistory(position) {
        const history = [];
        const radius = 7;
        const { x, y, z } = position;

        const minChunkX = Math.floor((x - radius) / CHUNK_SIZE);
        const maxChunkX = Math.floor((x + radius) / CHUNK_SIZE);
        const minChunkZ = Math.floor((z - radius) / CHUNK_SIZE);
        const maxChunkZ = Math.floor((z + radius) / CHUNK_SIZE);

        for (let cx = minChunkX; cx <= maxChunkX; cx++) {
            for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
                const chunkKey = getChunkKey(cx * CHUNK_SIZE, cz * CHUNK_SIZE);
                let chunkData = getChunkData(chunkKey);

                for (let dx = -radius; dx <= radius; dx++) {
                    for (let dy = -radius; dy <= radius; dy++) {
                        for (let dz = -radius; dz <= radius; dz++) {
                            const checkX = x + dx;
                            const checkY = y + dy;
                            const checkZ = z + dz;
                            if (Math.floor(checkX / CHUNK_SIZE) === cx && Math.floor(checkZ / CHUNK_SIZE) === cz) {
                                const checkPos = getPositionKey(checkX, checkY, checkZ);
                                if (chunkData[checkPos]) {
                                    const record = chunkData[checkPos];
                                    history.push({
                                        position: `(${checkX},${checkY},${checkZ})`,
                                        breaker: record.b,
                                        timestamp: new Date(record.t).toLocaleString('ja-JP').split(' ')[1],
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
        return history;
    }

    function displayBreakSummary(player, breaks) {
        const currentTime = new Date().toLocaleString('ja-JP').split(' ')[1];
        player.sendMessage(`§7[§b破壊概要§7 | §f${currentTime}§7]`);

        const breakCount = new Map();
        const latestBreaks = new Map();
        breaks.forEach(record => {
            breakCount.set(record.breaker, (breakCount.get(record.breaker) || 0) + 1);
            latestBreaks.set(record.breaker, {
                timestamp: record.timestamp,
                position: record.position,
            });
        });

        const sortedBreakers = Array.from(breakCount.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3);

        sortedBreakers.forEach(([breaker, count], index) => {
            const latest = latestBreaks.get(breaker);
            player.sendMessage(`§a#${index + 1} §c${breaker} §e${latest.timestamp} §6${latest.position} §b${count}個`);
        });

        player.sendMessage(`§7合計: §f${breaks.length}件 (§f${breakCount.size}人)`);
    }
}