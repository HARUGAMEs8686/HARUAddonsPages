import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

// グローバルな初期化済みプロパティを保持
let dynamicProperties = {};

// グローバル変数でTPSを保持
export var currentTPS = 0;

// 確認モードのプレイヤーリスト
export const checkModePlayers = new Set();

//破壊記録
export const playerCheckModeStatus = {};

// 初期化用の非同期関数
function initializeDynamicProperties() {
    return new Promise((resolve, reject) => {
        system.runTimeout(() => {
            try {
                // X_RAY_LEVEL
                if (world.getDynamicProperty('X_RAY_LEVEL') == undefined) {
                    world.setDynamicProperty('X_RAY_LEVEL', 2);
                }
                dynamicProperties['X_RAY_LEVEL'] = world.getDynamicProperty('X_RAY_LEVEL');

                // CHAT_LEVEL
                if (world.getDynamicProperty('CHAT_LEVEL') == undefined) {
                    world.setDynamicProperty('CHAT_LEVEL', 1);
                }
                dynamicProperties['CHAT_LEVEL'] = world.getDynamicProperty('CHAT_LEVEL');

                // bannedBlocks
                if (world.getDynamicProperty('bannedBlocks') == undefined) {
                    const bannedBlocks = [
                        'minecraft:tnt',
                        'minecraft:lit_tnt',
                        'minecraft:respawn_anchor',
                        'minecraft:lava',
                        'minecraft:lava_bucket',
                        'minecraft:fire',
                        'minecraft:end_crystal',
                        'minecraft:structure_block',
                        'minecraft:structure_void',
                        'minecraft:jigsaw',
                        'minecraft:command_block',
                        'minecraft:repeating_command_block',
                        'minecraft:chain_command_block',
                        'minecraft:barrier',
                        'minecraft:deny',
                        'minecraft:allow',
                        'minecraft:light_block',
                        'minecraft:web',
                        'minecraft:sweet_berry_bush',
                        'minecraft:wither_skeleton_skull',
                        'minecraft:sculk_shrieker',
                        'minecraft:bedrock',
                        'minecraft:nether_portal',
                        'minecraft:flint_and_steel',
                        'minecraft:fire_charge',
                    ];
                    world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
                }
                dynamicProperties['bannedBlocks'] = world.getDynamicProperty('bannedBlocks');

                // itemUseOn_system
                if (world.getDynamicProperty('itemUseOn_system') == undefined) {
                    world.setDynamicProperty('itemUseOn_system', true);
                }
                dynamicProperties['itemUseOn_system'] = world.getDynamicProperty('itemUseOn_system');

                // Log_system
                if (world.getDynamicProperty('Log_system') == undefined) {
                    world.setDynamicProperty('Log_system', true);
                }
                dynamicProperties['Log_system'] = world.getDynamicProperty('Log_system');

                // pvp_check
                if (world.getDynamicProperty('pvp_check') == undefined) {
                    world.setDynamicProperty('pvp_check', true);
                }
                dynamicProperties['pvp_check'] = world.getDynamicProperty('pvp_check');

                // 削除期間
                if (world.getDynamicProperty('placeblock_delete_speed') == undefined) {
                    world.setDynamicProperty('placeblock_delete_speed', 7);
                }
                dynamicProperties['placeblock_delete_speed'] = world.getDynamicProperty('placeblock_delete_speed');

                if (world.getDynamicProperty('breakblock_delete_speed') == undefined) {
                    world.setDynamicProperty('breakblock_delete_speed', 7);
                }
                dynamicProperties['breakblock_delete_speed'] = world.getDynamicProperty('breakblock_delete_speed');

                if (world.getDynamicProperty('location_delete_speed') == undefined) {
                    world.setDynamicProperty('location_delete_speed', 7);
                }
                dynamicProperties['location_delete_speed'] = world.getDynamicProperty('location_delete_speed');

                // 初期化完了ログ
                console.log('Dynamic properties initialized successfully.');
                resolve(dynamicProperties);
            } catch (error) {
                console.error(`Error initializing dynamic properties: ${error}`);
                reject(error);
            }
        }, 20); // 20ティック遅延
    });
}

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    if (eventData.id === 'haru:s') {
        UI(eventData, player);
    }
    if (eventData.id === 'start:s') {
        player.runCommand('tag @s add SecurityOP');
        player.runCommand('tag @s add SecurityMember');
        player.sendMessage('§r[§bSecurity§r] §cSecurityシステムを起動しました');
        player.runCommand(`give @s additem:securecraft`);
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
    }
});

// メイン処理
async function main() {
    // 初期化を待つ
    dynamicProperties = await initializeDynamicProperties();

    // 動的インポートでモジュールをロード
    const [{ UI }] = await Promise.all([import('./ui.js')]);
    const [{ Xray }] = await Promise.all([import('./detection/x-ray.js')]);
    const [{ Chat }] = await Promise.all([import('./detection/chat.js')]);
    const [{ BreakBlock }] = await Promise.all([import('./log/BreakBlock.js')]);
    const [{ PlaceBlock }] = await Promise.all([import('./log/PlaceBlock.js')]);
    const [{ LocationLog }] = await Promise.all([import('./log/Location.js')]);

    const cooldowns = new Map();
    const cooldownTime = 1000;

    // 禁止アイテムリストの取得
    function getBannedItems() {
        return JSON.parse(world.getDynamicProperty('bannedBlocks') || '[]');
    }

    // 1. ブロックとのインタラクション（例：マグマバケツで大釜やブロックに使用）
    world.beforeEvents.playerInteractWithBlock.subscribe(eventGDP => {
        if (world.getDynamicProperty('itemUseOn_system') === false) return;

        const player = eventGDP.player;
        if (!player || !player.id) return;

        // SecurityMemberタグがない場合
        if (!player.getTags().includes('SecurityMember')) {
            const item = eventGDP.itemStack;
            const bannedItems = getBannedItems();

            // 禁止アイテムかチェック（マグマバケツやブロックなど）
            if (item && bannedItems.includes(item.typeId)) {
                eventGDP.cancel = true; // インタラクションをキャンセル

                // クールダウンチェック
                const lastMessageTime = cooldowns.get(player.id) || 0;
                const now = Date.now();
                if (now - lastMessageTime >= cooldownTime) {
                    player.sendMessage(`§r[§bSecurity§r] §c${item.typeId}§rを使用する§e権限§rがありません`);
                    system.run(() => {
                        player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
                    });
                    cooldowns.set(player.id, now);
                }
            }
        }
    });

    // 2. ブロック以外でのアイテム使用（例：マグマバケツで空間に溶岩を置く）
    world.afterEvents.itemUse.subscribe(eventGDP => {
        if (world.getDynamicProperty('itemUseOn_system') === false) return;

        const player = eventGDP.source;
        if (!player || !player.id) return;

        // SecurityMemberタグがない場合
        if (!player.getTags().includes('SecurityMember')) {
            const item = eventGDP.itemStack;
            const bannedItems = getBannedItems();

            // 禁止アイテムかチェック（マグマバケツやその他）
            if (item && bannedItems.includes(item.typeId)) {
                // itemUseはキャンセル不可なので、結果を元に戻す
                system.run(() => {
                    // 視線先のブロックをチェック（例：マグマバケツが置いた溶岩）
                    const block = player.dimension.getBlock(player.getBlockFromViewDirection()?.block);
                    if (block && (block.typeId === 'minecraft:lava' || block.typeId === 'minecraft:water')) {
                        block.setType('minecraft:air'); // 溶岩や水を削除
                    }
                });

                // クールダウンチェック
                const lastMessageTime = cooldowns.get(player.id) || 0;
                const now = Date.now();
                if (now - lastMessageTime >= cooldownTime) {
                    player.sendMessage(`§r[§bSecurity§r] §c${item.typeId}§rを使用する§e権限§rがありません`);
                    system.run(() => {
                        player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
                    });
                    cooldowns.set(player.id, now);
                }
            }
        }
    });

    //アイテム
    world.beforeEvents.itemUse.subscribe(eventData => {
        if (eventData.itemStack.typeId === 'additem:securecraft') {
            const player = eventData.source;
            system.run(() => {
                if (player.hasTag('SecurityOP')) {
                    UI(eventData, player);
                }
            });
        }
    });

    function measureTPS() {
        let tickTimes = [];

        system.runInterval(() => {
            const now = Date.now();
            tickTimes.push(now);

            // 十分なサンプルが集まったらTPSを計算
            if (tickTimes.length > 1) {
                const timeDiff = tickTimes[tickTimes.length - 1] - tickTimes[0];
                if (timeDiff >= 1000) {
                    // 1秒以上のデータが集まったら
                    const ticksPerSecond = (tickTimes.length - 1) / (timeDiff / 1000);
                    currentTPS = Math.round(ticksPerSecond * 100) / 100; // 小数点2桁に丸める
                    tickTimes = [tickTimes[tickTimes.length - 1]]; // 最新のデータのみ保持
                }
            }
        }, 1); // 毎ティック実行
    }

    // TPS測定を開始
    measureTPS();

    //スクリプトロード
    Xray();
    Chat();
    BreakBlock();
    PlaceBlock();
    LocationLog();
}

// スクリプトの実行
main();
