import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UI } from '../ui';

// メモリ保持用
let entityTargets = [];

// 初期化とイベント登録
export function EntityLog() {
    ereload();

    system.runInterval(() => {
        deleteOldEntityLogs();
    }, 72000);

    // 通常の死亡イベント
    world.afterEvents.entityDie.subscribe(event => {
        if (world.getDynamicProperty('EntityLog_system') === false) return;

        const { deadEntity, damageSource } = event;
        const killer = damageSource.damagingEntity;
        const cause = damageSource.cause; // ダメージの原因を取得

        if (!entityTargets.includes(deadEntity.typeId)) return;

        // 判定フラグ
        const isPlayerKill = killer && killer.typeId === 'minecraft:player';
        const isLava = cause === 'lava';
        const isExplosion = cause === 'explosion';

        if (isPlayerKill || isLava || isExplosion) {
            let actionType = '死亡';

            if (isPlayerKill) actionType = 'プレイヤーによる殺害';
            else if (isLava) actionType = '溶岩による死亡';
            else if (isExplosion) actionType = '爆発による死亡';

            processEntityEvent(deadEntity, killer, actionType);
        }
    });
}

// 記録用共通関数
function processEntityEvent(victimEntity, killerEntity, actionType) {
    const now = new Date();
    const jstTime = new Date(now.getTime() + (world.getDynamicProperty('Time_Setting') || 9) * 60 * 60 * 1000);
    const timeStr = `${jstTime.getUTCHours().toString().padStart(2, '0')}:${jstTime.getUTCMinutes().toString().padStart(2, '0')}`;
    const dateStr = `${jstTime.getUTCFullYear()}${(jstTime.getUTCMonth() + 1).toString().padStart(2, '0')}${jstTime.getUTCDate().toString().padStart(2, '0')}`;

    const location = victimEntity.location;
    const killerName = killerEntity ? (killerEntity.name ?? killerEntity.typeId) : '不明(環境ダメージ等)';

    const logEntry = {
        time: timeStr,
        killer: killerName,
        victim: victimEntity.typeId.replace('minecraft:', ''),
        pos: `x:${Math.floor(location.x)} y:${Math.floor(location.y)} z:${Math.floor(location.z)}`,
        dim: victimEntity.dimension.id.replace('minecraft:', ''),
        extra: `[${actionType}]`,
    };

    saveEntityLog(dateStr, logEntry);
}

// 設定の再読み込み
export function ereload() {
    try {
        entityTargets = JSON.parse(world.getDynamicProperty('EntityLog_targets') || '[]');
        entityTargets = entityTargets.filter(id => id !== 'minecraft:armor_stand');
    } catch (e) {
        entityTargets = [];
    }

    deleteOldEntityLogs();
}

// データの保存
function saveEntityLog(dateStr, entry) {
    const prefix = `entitylog_${dateStr}`;
    const allProps = world.getDynamicPropertyIds().filter(p => p.startsWith(prefix));

    let propId = prefix;
    let currentIndex = 0;

    if (allProps.length > 0) {
        allProps.sort((a, b) => {
            const getSuffix = str => {
                if (str === prefix) return 0;
                return parseInt(str.replace(prefix + '_', '')) || 0;
            };
            return getSuffix(a) - getSuffix(b);
        });

        propId = allProps[allProps.length - 1];
        if (propId !== prefix) {
            currentIndex = parseInt(propId.replace(prefix + '_', '')) || 0;
        }
    }

    let logs = [];
    try {
        logs = JSON.parse(world.getDynamicProperty(propId) || '[]');
    } catch (e) {
        logs = [];
    }

    logs.push(entry);
    let jsonStr = JSON.stringify(logs);

    if (jsonStr.length > 15000) {
        logs.pop();

        // インデックスを増やして新しいプロパティを作成
        currentIndex++;
        propId = `${prefix}_${currentIndex}`;

        logs = [entry];
        jsonStr = JSON.stringify(logs);
    }

    world.setDynamicProperty(propId, jsonStr);
}

// ログ全削除
export function clearAllEntityLogData() {
    const props = world.getDynamicPropertyIds();
    props.forEach(p => {
        if (p.startsWith('entitylog_')) {
            world.setDynamicProperty(p, undefined);
        }
    });
}

export function showMainMenu_EntityLog(player) {
    const loc = player.location;
    const form = new ModalFormData()
        .title('§0エンティティログ - 座標検索')
        .textField('§a中心のX座標', '例: 100', { defaultValue: `${Math.floor(loc.x)}` })
        .textField('§a中心のY座標', '例: 60', { defaultValue: `${Math.floor(loc.y)}` })
        .textField('§a中心のZ座標', '例: -200', { defaultValue: `${Math.floor(loc.z)}` })
        .textField('§e検索半径 (ブロック)', '1～100', { defaultValue: '10' })
        .submitButton('§1検索開始');

    form.show(player).then(response => {
        if (response.canceled) {
            UI(player);
            return;
        }
        const [x, y, z, radius] = response.formValues.map(v => Number(v));
        if (isNaN(x) || isNaN(y) || isNaN(z) || isNaN(radius)) {
            player.sendMessage('§r[§bSecurityCraft§r] §c有効な数値を入力してください');
            return;
        }
        performSearch(player, { x, y, z, radius });
    });
}

function performSearch(player, criteria) {
    const allProps = world.getDynamicPropertyIds().filter(p => p.startsWith('entitylog_') && !p.endsWith('_delete_speed'));
    let results = [];
    for (const propId of allProps) {
        try {
            const dateStrWithSuffix = propId.replace('entitylog_', '');
            const dateStr = dateStrWithSuffix.split('_')[0];

            if (dateStr.length < 8) continue;

            const formattedDate = `${dateStr.substring(0, 4)}/${dateStr.substring(4, 6)}/${dateStr.substring(6, 8)}`;
            const logs = JSON.parse(world.getDynamicProperty(propId) || '[]');
            for (const log of logs) {
                const posMatch = log.pos.match(/x:(-?\d+) y:(-?\d+) z:(-?\d+)/);
                if (!posMatch) continue;
                const lx = parseInt(posMatch[1]);
                const ly = parseInt(posMatch[2]);
                const lz = parseInt(posMatch[3]);
                const distance = Math.sqrt(Math.pow(lx - criteria.x, 2) + Math.pow(ly - criteria.y, 2) + Math.pow(lz - criteria.z, 2));
                if (distance <= criteria.radius) {
                    results.push({ ...log, date: formattedDate, fullDateRaw: dateStr });
                }
            }
        } catch (e) {
            console.warn(e);
        }
    }

    results.sort((a, b) => {
        if (a.fullDateRaw !== b.fullDateRaw) return b.fullDateRaw.localeCompare(a.fullDateRaw);
        return b.time.localeCompare(a.time);
    });
    showSearchResults(player, results, criteria);
}

function showSearchResults(player, results, criteria) {
    if (results.length === 0) {
        player.sendMessage(`§r[§bSecurityCraft§r] §c指定した範囲内にログは見つかりませんでした`);
        return;
    }
    const form = new ActionFormData().title('§0検索結果').body(`§e中心: ${criteria.x}, ${criteria.y}, ${criteria.z} (半径:${criteria.radius}b)\n§fヒット数: ${results.length} 件`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    for (const res of results) {
        form.button(`§0[${res.date}] ${res.time}\n§4${res.victim} §0<- ${res.killer}`);
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showMainMenu_EntityLog(player);
            return;
        }
        const selectedLog = results[r.selection - 1];
        showLogDetail(player, selectedLog, results, criteria);
    });
}

function showLogDetail(player, log, results, criteria) {
    const now = new Date();
    const japanTime = new Date(now.getTime() + (world.getDynamicProperty('Time_Setting') || 9) * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;
    const form = new ActionFormData()
        .title('§0ログ詳細')
        .body(`${time}`)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .divider()
        .label(`§7日付: §f${log.date}\n` + `§7時刻: §f${log.time}\n` + `§7被害: §a${log.victim}\n` + `§7加害: §c${log.killer}\n` + `§7座標: §e${log.pos}\n` + `§7次元: §f${log.dim}\n` + `${log.extra ? `§7タイプ: ${log.extra}` : ''}`)
        .divider();
    form.show(player).then(r => {
        if (r.canceled) return;
        showSearchResults(player, results, criteria);
    });
}

function deleteOldEntityLogs() {
    const deleteSpeed = world.getDynamicProperty('entitylog_delete_speed');
    const maxDays = deleteSpeed !== undefined ? Number(deleteSpeed) : 7;

    const now = new Date();
    const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
    const jstTime = new Date(now.getTime() + timeSetting * 60 * 60 * 1000);
    jstTime.setUTCHours(0, 0, 0, 0);

    // 全ての保存データを確認
    const props = world.getDynamicPropertyIds();
    props.forEach(p => {
        const match = p.match(/^entitylog_(\d{8})/);
        if (match) {
            const dateStr = match[1];
            const year = parseInt(dateStr.substring(0, 4));
            const month = parseInt(dateStr.substring(4, 6)) - 1;
            const day = parseInt(dateStr.substring(6, 8));
            const logDate = new Date(Date.UTC(year, month, day));

            const diffTime = jstTime.getTime() - logDate.getTime();
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

            if (diffDays > maxDays) {
                world.setDynamicProperty(p, undefined);
            }
        }
    });
}

export function showPlayerEntityLogs(player, targetName, backCallback) {
    player.sendMessage('§r[§bSecurityCraft§r] §eエンティティ記録を検索中...');
    system.runTimeout(() => {
        let results = [];
        const allProps = world.getDynamicPropertyIds().filter(p => p.startsWith('entitylog_') && !p.endsWith('_delete_speed'));

        for (const propId of allProps) {
            try {
                const dateStr = propId.replace('entitylog_', '').split('_')[0];
                if (dateStr.length < 8) continue;
                const formattedDate = `${dateStr.substring(0, 4)}/${dateStr.substring(4, 6)}/${dateStr.substring(6, 8)}`;

                const logs = JSON.parse(world.getDynamicProperty(propId) || '[]');
                for (const log of logs) {
                    if (log.killer === targetName || log.victim === targetName) {
                        results.push({ ...log, date: formattedDate, fullDateRaw: dateStr });
                    }
                }
            } catch (e) {}
        }

        results.sort((a, b) => {
            if (a.fullDateRaw !== b.fullDateRaw) return b.fullDateRaw.localeCompare(a.fullDateRaw);
            return b.time.localeCompare(a.time);
        });

        showEntityLogResults(player, results, 1, targetName, backCallback);
    }, 1);
}

function showEntityLogResults(player, results, page, targetName, backCallback) {
    if (results.length === 0) {
        player.sendMessage(`§r[§bSecurityCraft§r] §a${targetName}のエンティティ記録はありません`);
        backCallback();
        return;
    }

    const LOGS_PER_PAGE = 40;
    const totalPages = Math.ceil(results.length / LOGS_PER_PAGE);
    const startIndex = (page - 1) * LOGS_PER_PAGE;
    const logsToShow = results.slice(startIndex, startIndex + LOGS_PER_PAGE);

    const form = new ActionFormData().title(`§0エンティティ記録: ${targetName}`).body(`§eページ §b${page} §r/ §b${totalPages} §r| §d総件数§r: §b${results.length}§r件`);

    const buttonActions = [];
    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttonActions.push(() => backCallback());

    if (page > 1) {
        form.button('§1前のページへ', 'textures/ui/arrow_left.png');
        buttonActions.push(() => showEntityLogResults(player, results, page - 1, targetName));
    }
    if (page < totalPages) {
        form.button('§1次のページへ', 'textures/ui/arrow_right.png');
        buttonActions.push(() => showEntityLogResults(player, results, page + 1, targetName));
    }

    logsToShow.forEach(res => {
        form.button(`§0[${res.date}] ${res.time}\n§4${res.victim} §0<- ${res.killer}`);
        buttonActions.push(() => {
            new ActionFormData()
                .title('§0ログ詳細')
                .body(`§7日付: §f${res.date}\n§7時刻: §f${res.time}\n§7被害: §a${res.victim}\n§7加害: §c${res.killer}\n§7座標: §e${res.pos}\n§7次元: §f${res.dim}\n${res.extra ? `§7タイプ: ${res.extra}` : ''}`)
                .button('§l戻る', 'textures/ui/icon_import.png')
                .button(`§0記録座標にテレポート`, 'textures/items/ender_pearl.png')
                .show(player)
                .then(r => {
                    if (r.canceled) return;
                    if (r.selection === 0) showEntityLogResults(player, results, page, targetName, backCallback);
                    if (r.selection === 1) {
                        try {
                            const match = res.pos.match(/x:(-?\d+) y:(-?\d+) z:(-?\d+)/);
                            if (match) player.teleport({ x: Number(match[1]), y: Number(match[2]), z: Number(match[3]) }, { dimension: player.dimension });
                        } catch (e) {}
                    }
                });
        });
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        buttonActions[res.selection]();
    });
}
