import { world, system, ItemStack, SignSide } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData, uiManager } from '@minecraft/server-ui';
import { chestCheckModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7;
let pendingUpdates = new Map();

// プレイヤーごとの現在開いているチェストセッションを管理
const activeSessions = new Map();

const chestViewers = new Map();

// UIのクールダウン管理
const lastUITick = new Map();
const uiCooldownTicks = 10;

//記録対象ID

const INVENTORY_BLOCK_IDS = [
    'minecraft:chest',
    'minecraft:barrel',
    'minecraft:trapped_chest',
    'minecraft:furnace',
    'minecraft:smoker',
    'minecraft:blast_furnace',
    'minecraft:undyed_shulker_box',
    'minecraft:white_shulker_box',
    'minecraft:orange_shulker_box',
    'minecraft:magenta_shulker_box',
    'minecraft:light_blue_shulker_box',
    'minecraft:yellow_shulker_box',
    'minecraft:lime_shulker_box',
    'minecraft:pink_shulker_box',
    'minecraft:gray_shulker_box',
    'minecraft:silver_shulker_box',
    'minecraft:cyan_shulker_box',
    'minecraft:purple_shulker_box',
    'minecraft:blue_shulker_box',
    'minecraft:brown_shulker_box',
    'minecraft:green_shulker_box',
    'minecraft:red_shulker_box',
    'minecraft:black_shulker_box',
    'minecraft:copper_chest',
    'minecraft:exposed_copper_chest',
    'minecraft:weathered_copper_chest',
    'minecraft:oxidized_copper_chest',
    'minecraft:waxed_copper_chest',
    'minecraft:waxed_exposed_copper_chest',
    'minecraft:waxed_weathered_copper_chest',
    'minecraft:waxed_oxidized_copper_chest',
];

function isLoggableBlock(typeId) {
    // インベントリ系ブロックに含まれるか、もしくは看板("sign"を含むID)か
    return INVENTORY_BLOCK_IDS.includes(typeId) || typeId.includes('sign');
}

// ---------------------------------------------------
// 設定ロード関連
// ---------------------------------------------------

export function creload() {
    try {
        const storedDays = world.getDynamicProperty('chestlog_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[SecurityCraft] ロードエラー: ${e}`);
    }
}

world.afterEvents.worldLoad.subscribe(() => {
    creload();
});
creload();

// ---------------------------------------------------
// データ保存・取得関連
// ---------------------------------------------------

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `chest_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`[SecurityCraft] 保存エラー: ${e}`);
    }
}

function getSignContents(block) {
    const sign = block?.getComponent('minecraft:sign');
    if (!sign) return null;

    try {
        const front = sign.getText ? sign.getText(SignSide.Front) : sign.text || '';
        const back = sign.getText ? sign.getText(SignSide.Back) : '';
        return { front, back };
    } catch (e) {
        return { front: '', back: '' };
    }
}

function compareSignContents(before, after) {
    const changes = [];
    if (!before || !after) return changes;

    if (before.front !== after.front) {
        changes.push(`§d[表] §a"${before.front}" >>> "${after.front}"§r`);
    }
    if (before.back !== after.back) {
        changes.push(`§d[裏] §a"${before.back}" >>> "${after.back}"§r`);
    }
    return changes;
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        const parsedData = storedData ? JSON.parse(storedData) : [];
        return new Map(parsedData);
    } catch (e) {
        return new Map();
    }
}

function cleanOldData() {
    try {
        const currentTime = Date.now();
        const expirationDay = Math.floor(currentTime / MILLISECONDS_PER_DAY) - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                const match = key.match(/chest_(-?\d+)_(-?\d+)_(\d+)/);
                if (match && parseInt(match[3]) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] クリーンアップエラー: ${e}`);
    }
}

// データ保存30秒
system.runInterval(() => {
    if (pendingUpdates.size > 0) {
        const updatesToProcess = new Map(pendingUpdates);
        for (const [chunkKey, chunkData] of updatesToProcess) {
            saveChunkData(chunkKey, chunkData);
        }
    }
}, 600);

system.runInterval(() => {
    cleanOldData();
}, 6000);

// ---------------------------------------------------
// チェスト操作ログロジック
// ---------------------------------------------------

export function addChestLog(block, player, changes = [], isConcurrent = false) {
    if (world.getDynamicProperty('ChestLog_system') !== true) return;

    const blockLocation = block.location;
    const chunkKey = getChunkKey(blockLocation.x, blockLocation.z);
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);

    // データの取得
    let chunkData = pendingUpdates.has(chunkKey) ? pendingUpdates.get(chunkKey) : getChunkData(chunkKey);

    const logEntry = {
        n: player.name,
        t: Date.now(),
        id: block.typeId,
        diff: changes,
        warn: isConcurrent ? 1 : 0,
    };

    let logsForPosition = chunkData.has(positionKey) ? chunkData.get(positionKey) : [];
    logsForPosition.push(logEntry);

    const MAX_LOGS_PER_CHEST = 100;
    if (logsForPosition.length > MAX_LOGS_PER_CHEST) {
        logsForPosition = logsForPosition.slice(-MAX_LOGS_PER_CHEST);
    }
    chunkData.set(positionKey, logsForPosition);
    const MAX_BYTES = 30000;

    // 現在のデータサイズを計算
    let serialized = JSON.stringify([...chunkData]);

    while (serialized.length > MAX_BYTES) {
        let oldestTime = Infinity;
        let targetPosKey = null;

        for (const [pos, logs] of chunkData) {
            if (logs.length > 0) {
                if (logs[0].t < oldestTime) {
                    oldestTime = logs[0].t;
                    targetPosKey = pos;
                }
            }
        }

        if (!targetPosKey) break;

        // 一番古いログを削除
        let targetLogs = chunkData.get(targetPosKey);
        targetLogs.shift(); // 先頭（最古）を削除

        if (targetLogs.length === 0) {
            chunkData.delete(targetPosKey);
        } else {
            chunkData.set(targetPosKey, targetLogs);
        }
        serialized = JSON.stringify([...chunkData]);
    }

    pendingUpdates.set(chunkKey, chunkData);
}

export function getChestLog(blockLocation) {
    let allLogs = [];
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);
    const currentTime = Date.now();

    for (let i = 0; i < DAYS_TO_KEEP; i++) {
        const pastTimestamp = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(blockLocation.x, blockLocation.z, pastTimestamp);
        let chunkData;
        if (pendingUpdates.has(chunkKey)) {
            chunkData = pendingUpdates.get(chunkKey);
        } else {
            chunkData = getChunkData(chunkKey);
        }

        if (chunkData.has(positionKey)) {
            allLogs.push(...chunkData.get(positionKey));
        }
    }

    allLogs.sort((a, b) => b.t - a.t);

    if (allLogs.length > 100) {
        allLogs = allLogs.slice(0, 100);
    }

    return allLogs;
}

export function clearAllChestData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 全削除エラー: ${e}`);
    }
}

// ---------------------------------------------------
// インベントリ監視ロジック
// ---------------------------------------------------

function getContainerContents(container) {
    const contents = new Map();
    if (!container) return contents;
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (item) {
            const currentCount = contents.get(item.typeId) || 0;
            contents.set(item.typeId, currentCount + item.amount);
        }
    }
    return contents;
}

function compareContents(before, after) {
    const changes = [];
    const allKeys = new Set([...before.keys(), ...after.keys()]);
    for (const typeId of allKeys) {
        const countBefore = before.get(typeId) || 0;
        const countAfter = after.get(typeId) || 0;
        const diff = countAfter - countBefore;
        if (diff !== 0) {
            const shortName = typeId.replace('minecraft:', '');
            const sign = diff > 0 ? '+' : '-';
            const color = diff > 0 ? '§a' : '§c'; // 緑:追加, 赤:取出
            changes.push(`${color}${sign} ${shortName} x${Math.abs(diff)}§r`);
        }
    }
    return changes;
}

function addViewer(positionKey, playerName) {
    if (!chestViewers.has(positionKey)) {
        chestViewers.set(positionKey, new Set());
    }
    const viewers = chestViewers.get(positionKey);
    viewers.add(playerName);

    if (viewers.size > 1) {
        for (const pName of viewers) {
            if (activeSessions.has(pName)) {
                const s = activeSessions.get(pName);
                s.isConcurrent = true;
                activeSessions.set(pName, s);
            }
        }
    }
}

function removeViewer(positionKey, playerName) {
    if (chestViewers.has(positionKey)) {
        const viewers = chestViewers.get(positionKey);
        viewers.delete(playerName);
        if (viewers.size === 0) {
            chestViewers.delete(positionKey);
        }
    }
}

// --- 指定座標のログ削除関数 ---

function deleteChestLog(blockLocation) {
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);
    const currentTime = Date.now();

    for (let i = 0; i < DAYS_TO_KEEP; i++) {
        const pastTimestamp = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(blockLocation.x, blockLocation.z, pastTimestamp);

        let chunkData = pendingUpdates.has(chunkKey) ? pendingUpdates.get(chunkKey) : getChunkData(chunkKey);

        if (chunkData.has(positionKey)) {
            chunkData.delete(positionKey); // データを削除
            pendingUpdates.set(chunkKey, chunkData);
        }
    }
}

function processCloseSession(player, session) {
    try {
        const { blockLocation, dimensionId, initialContents, positionKey, isConcurrent } = session;
        // 閲覧者リストから削除
        removeViewer(positionKey, player.name);

        const dimension = world.getDimension(dimensionId);
        let changes = [];
        try {
            const block = dimension.getBlock(blockLocation);

            if (block) {
                const inventoryComp = block.getComponent('inventory');
                const signComp = block.getComponent('minecraft:sign');

                if (inventoryComp && inventoryComp.container) {
                    const finalContents = getContainerContents(inventoryComp.container);
                    changes = compareContents(initialContents, finalContents);
                } else if (signComp) {
                    const finalContents = getSignContents(block);
                    changes = compareSignContents(initialContents, finalContents);
                }

                // 変更があった場合のみログ保存
                if (changes.length > 0 || inventoryComp) {
                    addChestLog(block, player, changes, isConcurrent);
                }
            }
        } catch (e) {}
    } catch (e) {
        console.warn(`Error processing session close: ${e}`);
    }
}

// ---------------------------------------------------
// イベントハンドラ
// ---------------------------------------------------

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    const blockType = block.typeId;
    if (!isLoggableBlock(blockType)) return;

    const isInventory = INVENTORY_BLOCK_IDS.includes(blockType);
    const isSign = blockType.includes('sign');

    if (activeSessions.has(player.name)) {
        const session = activeSessions.get(player.name);
        activeSessions.delete(player.name); // 二重処理防止
        system.run(() => {
            processCloseSession(player, session);
        });
    }

    const currentTick = system.currentTick;
    const lastTick = lastUITick.get(player.name);
    if (lastTick !== undefined && currentTick - lastTick < uiCooldownTicks) {
        return;
    }
    lastUITick.set(player.name, currentTick);

    // --- 対象ブロックへのアクセス処理 ---
    if (isInventory || isSign) {
        if (chestCheckModePlayers.has(player.name)) {
            event.cancel = true;

            system.runTimeout(() => {
                uiManager.closeAllForms(player);
                const logs = getChestLog(block.location);
                const form = new ActionFormData().title('§0アクセス履歴');

                if (logs.length > 0) {
                    const blockName = translateBlockName(block.typeId);
                    let body = `§a座標§r: §b${Math.floor(block.location.x)}, ${Math.floor(block.location.y)}, ${Math.floor(block.location.z)}\n§aブロック§r: §b${blockName}\n§r`;
                    logs.forEach(log => {
                        const japanTime = new Date(log.t + (world.getDynamicProperty('Time_Setting') || 0) * 60 * 60 * 1000);
                        const timeString = `${String(japanTime.getUTCMonth() + 1).padStart(2, '0')}/${String(japanTime.getUTCDate()).padStart(2, '0')} ${String(japanTime.getUTCHours()).padStart(2, '0')}:${String(japanTime.getUTCMinutes()).padStart(2, '0')}:${String(japanTime.getUTCSeconds()).padStart(2, '0')}`;

                        body += `\n§e${log.n} §7(${timeString})§r`;

                        // 同時アクセスの警告
                        if (log.warn) {
                            body += ` §cデータ不適切 (同時アクセス)§r`;
                        }

                        if (log.diff && log.diff.length > 0) {
                            body += `\n  ${log.diff.join(' ')}`;
                        } else {
                            body += `\n  §7(操作なし)`;
                        }
                        body += `\n§8----------------§r`;
                    });
                    form.body(body);
                } else {
                    form.body(`§cアクセス履歴がありません`);
                }

                form.button('§l閉じる');
                form.show(player);
            }, 4);
            return;
        }

        if (world.getDynamicProperty('ChestLog_system') === true) {
            system.run(() => {
                const currentBlock = block.dimension.getBlock(block.location);
                const container = currentBlock?.getComponent('inventory')?.container;
                const signComp = currentBlock?.getComponent('minecraft:sign');

                if (container || signComp) {
                    const positionKey = getPositionKey(block.location.x, block.location.y, block.location.z);

                    // 初期状態の取得
                    let initialContents;
                    if (container) {
                        initialContents = getContainerContents(container);
                    } else if (signComp) {
                        initialContents = getSignContents(currentBlock);
                    }

                    addViewer(positionKey, player.name);
                    const isConcurrent = chestViewers.get(positionKey)?.size > 1;

                    activeSessions.set(player.name, {
                        blockLocation: { x: block.location.x, y: block.location.y, z: block.location.z },
                        dimensionId: block.dimension.id,
                        initialContents: initialContents,
                        timestamp: Date.now(),
                        positionKey: positionKey,
                        isConcurrent: isConcurrent,
                    });
                }
            });
        }
    }
});

world.afterEvents.playerBreakBlock.subscribe(event => {
    const { block, brokenBlockPermutation } = event;
    const typeId = brokenBlockPermutation.type.id;

    if (isLoggableBlock(typeId)) {
        deleteChestLog(block.location);
    }
});

// ---------------------------------------------------
// 監視ループ (距離判定による閉じる処理)
// ---------------------------------------------------

system.runInterval(() => {
    if (activeSessions.size === 0) return;

    for (const [playerName, session] of activeSessions) {
        const player = world.getAllPlayers().find(p => p.name === playerName);

        if (!player) {
            activeSessions.delete(playerName);
            removeViewer(session.positionKey, playerName);
            continue;
        }

        // 距離判定 (6ブロック以上離れたら閉じたとみなす)
        const pLoc = player.location;
        const bLoc = session.blockLocation;
        let distanceSquared = 999;

        if (player.dimension.id === session.dimensionId) {
            distanceSquared = (pLoc.x - bLoc.x) ** 2 + (pLoc.y - bLoc.y) ** 2 + (pLoc.z - bLoc.z) ** 2;
        }

        if (distanceSquared > 36) {
            activeSessions.delete(playerName);
            processCloseSession(player, session);
        }
    }
}, 5);

export function showPlayerAccessLogs(player, targetName, backCallback) {
    player.sendMessage('§r[§bSecurityCraft§r] §eアクセス記録を検索中...');

    if (activeSessions.has(targetName)) {
        const session = activeSessions.get(targetName);
        activeSessions.delete(targetName);
        const targetPlayer = world.getAllPlayers().find(p => p.name === targetName);
        if (targetPlayer) processCloseSession(targetPlayer, session);
    }
    system.runTimeout(() => {
        const results = [];
        const processedChunks = new Set();

        for (const [chunkKey, chunkData] of pendingUpdates) {
            processedChunks.add(chunkKey);
            for (const [posKey, logs] of chunkData) {
                for (const log of logs) {
                    if (log.n === targetName) {
                        results.push({ posKey, log });
                    }
                }
            }
        }

        const allKeys = world.getDynamicPropertyIds().filter(k => k.startsWith('chest_'));
        for (const key of allKeys) {
            if (processedChunks.has(key)) continue; // すでに最新を取得済みのチャンクはスキップ
            try {
                const dataStr = world.getDynamicProperty(key);
                if (!dataStr) continue;
                const chunkDataArray = JSON.parse(dataStr);

                for (const [posKey, logs] of chunkDataArray) {
                    for (const log of logs) {
                        if (log.n === targetName) {
                            results.push({ posKey, log });
                        }
                    }
                }
            } catch (e) {}
        }

        results.sort((a, b) => b.log.t - a.log.t);
        showAccessLogResults(player, results, 1, targetName, backCallback);
    }, 1);
}

function showAccessLogResults(player, results, page, targetName, backCallback) {
    if (results.length === 0) {
        player.sendMessage(`§r[§bSecurityCraft§r] §a${targetName}のアクセス記録はありません`);
        backCallback();
        return;
    }

    const LOGS_PER_PAGE = 40;
    const totalPages = Math.ceil(results.length / LOGS_PER_PAGE);
    const startIndex = (page - 1) * LOGS_PER_PAGE;
    const logsToShow = results.slice(startIndex, startIndex + LOGS_PER_PAGE);

    const form = new ActionFormData().title(`§0アクセス記録: ${targetName}`).body(`§eページ §b${page} §r/ §b${totalPages} §r| §d総件数§r: §b${results.length}§r件`);

    const buttonActions = [];
    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttonActions.push(() => backCallback());

    if (page > 1) {
        form.button('§1前のページへ', 'textures/ui/arrow_left.png');
        buttonActions.push(() => showAccessLogResults(player, results, page - 1, targetName, backCallback));
    }
    if (page < totalPages) {
        form.button('§1次のページへ', 'textures/ui/arrow_right.png');
        buttonActions.push(() => showAccessLogResults(player, results, page + 1, targetName, backCallback));
    }

    logsToShow.forEach(({ posKey, log }) => {
        const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
        const date = new Date(log.t + timeSetting * 60 * 60 * 1000);

        // 時間フォーマット
        const timeStrList = `${date.getUTCFullYear()}/${String(date.getUTCMonth() + 1).padStart(2, '0')}/${String(date.getUTCDate()).padStart(2, '0')} ${String(date.getUTCHours()).padStart(2, '0')}:${String(date.getUTCMinutes()).padStart(2, '0')}`;
        const timeString = `${String(date.getUTCMonth() + 1).padStart(2, '0')}/${String(date.getUTCDate()).padStart(2, '0')} ${String(date.getUTCHours()).padStart(2, '0')}:${String(date.getUTCMinutes()).padStart(2, '0')}:${String(date.getUTCSeconds()).padStart(2, '0')}`;

        const hasDiff = log.diff && log.diff.length > 0;
        const actionLabel = hasDiff ? '§4[変更あり]' : '§0[閲覧のみ]';

        const blockName = translateBlockName(log.id);

        form.button(`§0${timeStrList}\n§1${blockName} ${actionLabel}`);

        buttonActions.push(() => {
            const [x, y, z] = posKey.split(',').map(Number);

            let bodyText = `§a座標§r: §b${x}, ${y}, ${z}\n§aブロック§r: §b${log.id.replace('minecraft:', '')}\n§r`;
            bodyText += `\n§e${log.n} §7(${timeString})§r`;

            if (log.warn) {
                bodyText += ` §cデータ不適切 (同時アクセス)§r`;
            }
            if (hasDiff) {
                bodyText += `\n  ${log.diff.join(' ')}`;
            } else {
                bodyText += `\n  §7(操作なし)`;
            }
            bodyText += `\n§8----------------§r`;

            new ActionFormData()
                .title('§0ログ詳細')
                .body(bodyText)
                .button('§l戻る', 'textures/ui/icon_import.png')
                .button(`§0記録座標にテレポート`, 'textures/items/ender_pearl.png')
                .show(player)
                .then(res => {
                    if (res.canceled) return;
                    if (res.selection === 0) showAccessLogResults(player, results, page, targetName, backCallback);
                    if (res.selection === 1) {
                        try {
                            player.teleport({ x, y, z }, { dimension: player.dimension });
                        } catch (e) {}
                    }
                });
        });
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        buttonActions[res.selection]();
    });
}

function translateBlockName(id) {
    const rawId = id.replace('minecraft:', '');
    if (rawId === 'chest') return 'チェスト';
    if (rawId === 'barrel') return '樽';
    if (rawId === 'trapped_chest') return 'トラップチェスト';
    if (rawId === 'furnace') return 'かまど';
    if (rawId === 'smoker') return '燻製器';
    if (rawId === 'blast_furnace') return '溶鉱炉';
    if (rawId.includes('shulker_box')) return 'シュルカーボックス';
    if (rawId.includes('sign')) return '看板';
    if (rawId.includes('copper_chest')) return '銅のチェスト';
    return rawId;
}
