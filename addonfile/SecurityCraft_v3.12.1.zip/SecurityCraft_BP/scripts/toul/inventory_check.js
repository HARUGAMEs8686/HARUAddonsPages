import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { IDConfig } from '../data/IDConfig.js';

import { PlayerManager } from '../ui.js';

export function showInventoryContents(player, targetPlayer) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;
    const inventory = targetPlayer.getComponent('inventory').container;
    const form = new ActionFormData().title(`§4${targetPlayer.name} §0のインベントリ`);

    let bodyText = '';
    let itemCount = 0;

    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) {
            const isJPEnabled = world.getDynamicProperty('JPChange') === true;
            let displayName = item.typeId.replace('minecraft:', '');

            if (isJPEnabled) {
                const configData = IDConfig.find(data => data[0] === item.typeId);
                if (configData) {
                    displayName = configData[1];
                }
            }

            bodyText += `§r- §e${displayName} §r(§b${item.amount}§r個)\n`;
            itemCount++;
        }
    }

    if (itemCount === 0) {
        bodyText = '§7インベントリは空です';
    }

    form.body(`${time}`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.label(bodyText);

    form.show(player).then(() => {
        PlayerManager(player, targetPlayer);
    });
}
