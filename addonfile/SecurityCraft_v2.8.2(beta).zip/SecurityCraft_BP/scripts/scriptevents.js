import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData,MessageFormData } from "@minecraft/server-ui";
import { SecurityLogB_Data,SecurityLogB_Name,checkModePlayers,showCheckModeForm} from "./main";

export function Itemrun_HARUPhone1(eventData,player){
        var players = world.getPlayers()
        var form = new ActionFormData();
            form.title("§0§lSecureCraft");
            form.body(`§a-ワールド情報-\n§r・§3プレイヤー人数§r: §r§b${players.length}\n\n§c-セキュリティー情報-§r\n§r・§3座標ログ§r: §r§b${world.getDynamicProperty('Log_system')}\n§r・§2禁止アイテム設置検知§r:§b${world.getDynamicProperty('itemUseOn_system')}\n§r・§eX-ray検知Level§r:§b${world.getDynamicProperty("X_RAY_LEVEL")}\n§r・§dチャット検知Level§r:§bERROR\n\n§5>>>§7選択してください...`);
            form.button("§1§o座標ログ");
            form.button("§5§o信頼メンバー\n§1追加§0/§4解除");
            form.button("§0§oブロック§4解除");
            form.button("§3§oCheckMode","textures/ui/sidebar_icons/star");
            form.button("§2§oSecurityChest\n§8今後削除予定","textures/blocks/securitychest");
            form.button("§8§o設定\n§9操作","textures/ui/icon_setting");
            form.button("§5<<<§0HARUAddonsの公式サイト\n§8QRコードからアクセス出来ます","textures/ui/qr");
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("チェックするログを選択");
                        form.button("§l戻る","textures/ui/back_button_hover");
                        form.button("§1ログデータA\n§8データ量少 (再起動してもアクセス可)");
                        form.button("§5ログデータB\n§8データ量多 (ワールド終了時に強制削除)");
                        form.button("§3座標検索\n§8指定座標周辺のプレイヤーを検索");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    Itemrun_HARUPhone1(eventData,player)
                                break;
                                case 1:
                                    function showPlayerListA(player) {
                                        const PlayersNameLog = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionA(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionA(player, targetName) {
                                        const logKey = `Security_LOG_KEY_${targetName}`;
                                        const logData = world.getDynamicProperty(logKey);
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const logs = JSON.parse(logData);
                                        if (logs.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logs.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsA(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsA(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionA(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                        
                                    }

                                    //表示
                                    showPlayerListA(player);
                                break;
                                case 2:
                                    function showPlayerListB(player) {
                                        const PlayersNameLog = SecurityLogB_Name
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionB(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionB(player, targetName) {
                                        const logData = SecurityLogB_Data[targetName];
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        if (logData.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logData.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsB(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsB(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionB(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                    }

                                    //表示
                                    showPlayerListB(player);
                                break;
                                case 3:
                                    // 新しい座標検索機能
                                    function showCoordinateSearch(player) {
                                        const form = new ModalFormData()
                                            .title("座標検索")
                                            .textField("X座標を入力", "例: 100")
                                            .textField("Y座標を入力", "例: 64")
                                            .textField("Z座標を入力", "例: 200")
                                            .textField("検索範囲(ブロック)", "例: 50")
                                            .dropdown("検索対象ログ", ["ログデータA", "ログデータB"], 0);
                        
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                        
                                            const [xInput, yInput, zInput, rangeInput, logType] = response.formValues;
                                            const x = parseFloat(xInput);
                                            const y = parseFloat(yInput);
                                            const z = parseFloat(zInput);
                                            const range = parseFloat(rangeInput) || 50;
                        
                                            if (isNaN(x) || isNaN(y) || isNaN(z) || isNaN(range)) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §c有効な数値を入力してください"}]}`);
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                return;
                                            }
                        
                                            searchPlayersByCoordinates(player, x, y, z, range, logType);
                                        });
                                    }
                        
                                    function searchPlayersByCoordinates(player, targetX, targetY, targetZ, range, logType) {
                                        let allLogs = {};
                                        let playerNames = [];
                                      
                                        if (logType === 0) {
                                          const PlayersNameLog = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
                                          playerNames = PlayersNameLog;
                                          for (let name of PlayersNameLog) {
                                            const logKey = `Security_LOG_KEY_${name}`;
                                            const logData = world.getDynamicProperty(logKey);
                                            if (logData) allLogs[name] = JSON.parse(logData);
                                          }
                                        } else {
                                          playerNames = SecurityLogB_Name;
                                          allLogs = SecurityLogB_Data;
                                        }
                                      
                                        const nearbyPlayers = [];
                                        for (let name of playerNames) {
                                          const logs = allLogs[name] || [];
                                          for (let log of logs) {
                                            const distance = Math.sqrt(
                                              Math.pow(log.x - targetX, 2) +
                                              Math.pow(log.y - targetY, 2) +
                                              Math.pow(log.z - targetZ, 2)
                                            );
                                            if (distance <= range) {
                                              nearbyPlayers.push({
                                                name: name,
                                                time: log.time,
                                                x: log.x,
                                                y: log.y,
                                                z: log.z,
                                                distance: distance
                                              });
                                              break;
                                            }
                                          }
                                        }
                                      
                                      
                                        if (nearbyPlayers.length === 0) {
                                          player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §a指定範囲内にプレイヤーは見つかりませんでした"}]}`);
                                          player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                          return;
                                        }
                                      
                                        const form = new ActionFormData()
                                          .title(`§0§lSecureCraft`)
                                          .body(`§f-§6検索情報§f-\n§eX§r:§b${targetX} §eY§r:§b${targetY} §eZ§r:§b${targetZ}\n§a範囲§r:§b${range}\n\n§c検索結果§5>>>`);
                                      
                                        nearbyPlayers.sort((a, b) => a.distance - b.distance);
                                        nearbyPlayers.forEach((p, index) => {
                                          form.button(`§1${p.name}\n§5距離§r:§1${Math.round(p.distance)}b §5時間§r:§0${p.time}`);
                                        });
                                      
                                        form.show(player).then(response => {
                                          if (response.canceled) return;
                                          const selectedPlayer = nearbyPlayers[response.selection];
                                          if (selectedPlayer) {
                                            showPlayerDetails(player, selectedPlayer, logType, targetX, targetY, targetZ, range);
                                          }
                                        });
                                      }
                        
                                    function showPlayerDetails(player, playerData, logType, targetX, targetY, targetZ, range) {
                                        const logText = `§a${playerData.name} §rの詳細\n` +
                                            `§aX§r:§b ${Math.round(playerData.x)}\n` +
                                            `§aY§r:§b ${Math.round(playerData.y)}\n` +
                                            `§aZ§r:§b ${Math.round(playerData.z)}\n` +
                                            `§a時間§r: §e${playerData.time}\n` +
                                            `§a距離§r: §c${Math.round(playerData.distance)}ブロック`;
                        
                                        const form = new ActionFormData()
                                            .title("§0§lSecureCraft")
                                            .body(logText)
                                            .button(`§l戻る`, 'textures/ui/icon_import.png');
                        
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            if (r.selection === 0) {
                                                searchPlayersByCoordinates(player, targetX, targetY, targetZ, range, logType);
                                            }
                                        });
                                    }
                        
                                    // 座標検索画面を表示
                                    showCoordinateSearch(player);
                                break;
                            }
                        })
                    break;
                    case 1:
                    // 特定のアイテムを使用したときにフォームを表示する関数
                    function showPlayerSelector(player) {
                        // すべてのプレイヤーを取得
                        const allPlayers = world.getAllPlayers();
                        const playerNames = allPlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                        playerNames.unshift("全プレイヤー"); // ドロップダウンの先頭に「全プレイヤー」を追加
                    
                        // フォームを作成
                        const form = new ModalFormData()
                            .title("§0§lSecureCraft")
                            .dropdown("プレイヤーを選択してください", playerNames, 0) // デフォルトは「全プレイヤー」
                            .toggle("§cオフ§r:§aオン§r=§c解除§r:§a追加", true); // タグを付与するか削除するかを選択
                    
                        // フォームを表示
                        form.show(player).then(response => {
                            if (response.canceled) return; // フォームがキャンセルされた場合は終了
                    
                            const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス
                            const addTag = response.formValues[1]; // タグを付与するか削除するか（true/false）
                    
                            if (selectedIndex === 0) {
                                // 「全プレイヤー」が選択された場合
                                for (const targetPlayer of allPlayers) {
                                    if (addTag) {
                                        targetPlayer.addTag("SecurityMember");
                                        player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rに§a追加しました`);
                                    } else {
                                        targetPlayer.removeTag("SecurityMember");
                                        player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rから§c解除しました`);
                                    }
                                }
                            } else {
                                // 個別のプレイヤーが選択された場合
                                const selectedPlayer = allPlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                                if (addTag) {
                                    selectedPlayer.addTag("SecurityMember");
                                    player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rに§a追加しました`);
                                } else {
                                    selectedPlayer.removeTag("SecurityMember");
                                    player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rから§c解除しました`);
                                }
                            }
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                        });
                    }
                    showPlayerSelector(player);
                    break;
                    case 2:
                        // プレイヤーを取得
                        const adventurePlayers = Array.from(players).filter(player => player.getGameMode() === "adventure");
                        if(adventurePlayers.length == 0){
                            player.sendMessage("[§bSecurity§r] §a解除可能なプレイヤーが見つかりませんでした");
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.6 0.7`)
                            return;
                        }
                        const playerNames = adventurePlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                        playerNames.unshift("全員解除"); // ドロップダウンの先頭に「全プレイヤー」を追加
                    
                        // フォームを作成
                        var form = new ModalFormData()
                            .title("§0§lSecureCraft")
                            .dropdown("プレイヤーを選択してください", playerNames, 0) // デフォルトは「全プレイヤー」
                    
                        // フォームを表示
                        form.show(player).then(response => {
                            if (response.canceled) return; // フォームがキャンセルされた場合は終了
                    
                            const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス
                    
                            if (selectedIndex === 0) {
                                // 「全プレイヤー」が選択された場合
                                for (const targetPlayer of adventurePlayers) {
                                    targetPlayer.runCommand('gamemode default @s')
                                    player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§e解除しました`);
                                }
                            } else {
                                // 個別のプレイヤーが選択された場合
                                const selectedPlayer = adventurePlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                                    selectedPlayer.runCommand('gamemode default @s')
                                    player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§e解除しました`);
                            }
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                        });
                    break;
                    case 3:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("§bCheckMode §9有効化§r/§4無効化");
                        form.button("§l戻る","textures/ui/back_button_hover");
                        form.button("§9設置チェック");
                        form.button("§4破壊チェック");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    Itemrun_HARUPhone1(eventData,player)
                                break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("§bCheckMode §9有効化§r/§4無効化");
                                    form.button("§9有効化");
                                    form.button("§4無効化");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                checkModePlayers.add(player.name);
                                                player.sendMessage("§r[§a通知§7(Security)§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります");
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                            break;
                                            case 1:
                                                checkModePlayers.delete(player.name);
                                                player.sendMessage("§r[§a通知§7(Security)§r] §a設置確認モード§rを§5OFF§rにしました");
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                            break;
                                        }
                                    })
                                break;
                                case 2:
                                    showCheckModeForm(player);
                                break;
                            }
                        })
                    break;
                    case 4:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("機能を選択");
                        form.button("§l戻る","textures/ui/back_button_hover");
                        form.button("§1追加");
                        form.button("§5削除");
                        form.button("§2Ticket付与");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    Itemrun_HARUPhone1(eventData,player)
                                break;
                                case 1:
                                    let chest_pattern = [ "ラージチェスト", "樽", "黄緑色シュルカーボックス", "空色シュルカーボックス","桃色シュルカーボックス","黄色のシュルカーボックス","白色シュルカーボックス"]
                                    var form = new ModalFormData();
                                    form.textField("座標x", "0")
                                    form.textField("座標y", "0")
                                    form.textField("座標z", "0")
                                    form.textField("保存ブロック数", "0") 
                                    form.dropdown("種類", chest_pattern)
                                    form.textField("倉庫デザイン", "") 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        var securitychest_List = world.getDynamicProperty('securitychest_List')
                                        if(securitychest_List==undefined){
                                           var securitychest_List_system2=[]
                                        }else{
                                          var securitychest_List_system2 = JSON.parse(securitychest_List);
                                        }
                                        securitychest_List_system2.push([{ x: Number(r.formValues[0]), y: Number(r.formValues[1]), z: Number(r.formValues[2]) },r.formValues[3],chest_pattern[r.formValues[4]],0,r.formValues[5],player.name])
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a追加しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 2:
                                    var securitychest_List = world.getDynamicProperty('securitychest_List')
                                    if(securitychest_List==undefined){
                                       var securitychest_List_system2=[]
                                    }else{
                                      var securitychest_List_system2 = JSON.parse(securitychest_List);
                                    }
                                        if(securitychest_List_system2[0]==undefined){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除できる倉庫販売データがありません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("削除する倉庫販売データを選択");
                                    for (let i = 0; i < securitychest_List_system2.length; i++){
                                        form.button(`§1${securitychest_List_system2[i][0].x},${securitychest_List_system2[i][0].y},${securitychest_List_system2[i][0].z}§r:\n§s${securitychest_List_system2[i][2]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        securitychest_List_system2.splice( response, 1 );
                                        if(securitychest_List_system2==[]){
                                            securitychest_List_system2=undefined
                                        }
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 3:
                                    var players = world.getAllPlayers()
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("送り先のプレイヤーを選択");
                                    for (let i = 0; i < players.length; i++){
                                        form.button(`§1${players[i].name}\n§5>>>§s${players[i].getDynamicProperty('Security_chest_ticket')}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                      let response = r.selection;
            
                                      var form = new ModalFormData();
                                      form.title("§0§lSecureCraft");
                                      form.textField("付与ticket数(半角数字)", "0")
                                      form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if(isNaN(r.formValues[0])){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §4半角数字で入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (r.formValues[0]<0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §40以下は設定できません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if(players[response].getDynamicProperty('Security_chest_ticket')==undefined){
                                            players[response].setDynamicProperty('Security_chest_ticket',0)
                                        }
                                        players[response].setDynamicProperty('Security_chest_ticket',players[response].getDynamicProperty('Security_chest_ticket')+Number(r.formValues[0])) 
                                        players[response].runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${Number(r.formValues[0])}§r枚受け取りました"}]}`)
                                        players[response].runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${players[response].name}§rに§b${Number(r.formValues[0])}§a枚付与しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)  
                                    })
                                    })
                                break;
                            }
                        })  
                    break;
                    case 5:
                    // メインメニュー
                    var form = new ActionFormData();
                    form.title("§0§lSecureCraft");
                    form.body("選択してください。");
                    form.button("§l戻る", "textures/ui/back_button_hover"); // 順番1
                    form.button("§o§4検知システム\n§r§1X-ray§r・§5チャット"); // カテゴリー1 (元2, 3)
                    form.button("§o§2座標ログ\n§r§9システム・データ削除"); // カテゴリー2 (元4, 7)
                    form.button("§o§c禁止アイテム\n§r§9システム・アイテム設定"); // カテゴリー3 (元5, 6)
                    
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                Itemrun_HARUPhone1(eventData, player);
                                break;
                            case 1: // 検知システム
                                openDetectionMenu(eventData, player);
                                break;
                            case 2: // 座標ログ
                                openLogMenu(eventData, player);
                                break;
                            case 3: // 禁止アイテム
                                openBanItemMenu(eventData, player);
                                break;
                        }
                    });
                    
                    // 検知システムメニュー
                    function openDetectionMenu(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("選択してください。");
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§o§4X-ray検知\n§r§9Level選択§r/§5無効化");
                        form.button("§o§1不正チャット検知\n§r§9Level選択§r/§5無効化");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // X-ray検知
                                    openXraySettings(eventData, player);
                                    break;
                                case 2: // 不正チャット検知
                                    openChatSettings(eventData, player);
                                    break;
                            }
                        });
                    }
                    
                    // X-ray検知設定
                    function openXraySettings(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`X-ray検知レベル§r:§b${world.getDynamicProperty('X_RAY_LEVEL') || "無効"}\n選択してください。`);
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§1無効化 \n§8検知システムが実行されません");
                        form.button("§1Level-1 \n§8誤検知を最小限に抑える");
                        form.button("§1Level-2 \n§8バランスの取れた検知レベル");
                        form.button("§1Level-3 \n§8標準より少し厳しい検知");
                        form.button("§1Level-4 \n§8高速検知");
                        form.button("§1Level-5 \n§8即時検知");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            if (response === 0) {
                                Itemrun_HARUPhone1(eventData, player);
                                return;
                            }
                            world.setDynamicProperty('X_RAY_LEVEL', response - 1);
                            Itemrun_HARUPhone1(eventData, player);
                        });
                    }
                    
                    // 不正チャット検知設定
                    function openChatSettings(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`不正チャット検知レベル§r:§b${world.getDynamicProperty("CHAT_LEVEL") || "無効"}\n選択してください。`);
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§1無効化 \n§8検知システムが実行されません");
                        form.button("§1Level-1 \n§8弱い検知レベル - 最小限の対応");
                        form.button("§1Level-2 \n§8バランス検知レベル - 中程度の対応");
                        form.button("§1Level-3 \n§8強い検知レベル - 厳密な対応");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            if (response === 0) {
                                Itemrun_HARUPhone1(eventData, player);
                                return;
                            }
                            world.setDynamicProperty('CHAT_LEVEL', response - 1);
                            Itemrun_HARUPhone1(eventData, player);
                        });
                    }
                    
                    // 座標ログメニュー
                    function openLogMenu(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("選択してください。");
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§o§2座標ログシステム\n§r§9有効化§r・§5無効化");
                        form.button("§o§3座標ログデータ削除\n§r§9A§r・§5B");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // 座標ログシステム
                                    toggleLogSystem(eventData, player);
                                    break;
                                case 2: // 座標ログデータ削除
                                    openLogDeleteMenu(eventData, player);
                                    break;
                            }
                        });
                    }
                    
                    // 座標ログシステム設定
                    function toggleLogSystem(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`現在は${world.getDynamicProperty('Log_system') ? "有効" : "無効"}\n選択してください。`);
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§o§9有効化");
                        form.button("§o§4無効化");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // 有効化
                                    world.setDynamicProperty('Log_system', true);
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 2: // 無効化
                                    world.setDynamicProperty('Log_system', false);
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                            }
                        });
                    }
                    
                    // ログデータ削除メニュー
                    function openLogDeleteMenu(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`削除するデータを選択`);
                        form.button("§lホームへ戻る", "textures/ui/back_button_hover");
                        form.button("§o§5データA");
                        form.button("§o§1データB");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // データA
                                    confirmDeleteDataA(eventData, player);
                                    break;
                                case 2: // データB
                                    confirmDeleteDataB(eventData, player);
                                    break;
                            }
                        });
                    }
                    
                    // データA削除確認
                    function confirmDeleteDataA(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`§5データA\n\n§5>>>§s本当に削除しますか？`);
                        form.button("§o§5削除");
                        form.button("§o§1キャンセル");
                    
                        form.show(player).then(r => {
                            if (r.canceled || r.selection === 1) return;
                            let playersName = world.getDynamicProperty("PlayersNameLog");
                            if (!playersName) {
                                playersName = [];
                            } else {
                                playersName = JSON.parse(playersName);
                            }
                            for (let i = 0; i < playersName.length; i++) {
                                const logKey = `Security_LOG_KEY_${playersName[i]}`;
                                world.setDynamicProperty(logKey, undefined);
                            }
                            world.setDynamicProperty("PlayersNameLog", undefined);
                            Itemrun_HARUPhone1(eventData, player);
                        });
                    }
                    
                    // データB削除確認
                    function confirmDeleteDataB(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`§9データB\n\n§5>>>§s本当に削除しますか？`);
                        form.button("§o§5削除");
                        form.button("§o§1キャンセル");
                    
                        form.show(player).then(r => {
                            if (r.canceled || r.selection === 1) return;
                            for (let i = 0; i < SecurityLogB_Name.length; i++) {
                                SecurityLogB_Data[SecurityLogB_Name[i]] = [];
                            }
                            Itemrun_HARUPhone1(eventData, player);
                        });
                    }
                    
                    // 禁止アイテムメニュー
                    function openBanItemMenu(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("選択してください。");
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§o§c禁止設置アイテムシステム\n§r§9有効化§r・§5無効化");
                        form.button("§o§c禁止設置アイテム\n§r§9追加§r・§5削除");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // 禁止設置アイテムシステム
                                    toggleItemSystem(eventData, player);
                                    break;
                                case 2: // 禁止設置アイテム
                                    openBanMenu(player);
                                    break;
                            }
                        });
                    }
                    
                    // 禁止アイテムシステム設定
                    function toggleItemSystem(eventData, player) {
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body(`現在は${world.getDynamicProperty('itemUseOn_system') ? "有効" : "無効"}\n選択してください。`);
                        form.button("§l戻る", "textures/ui/back_button_hover");
                        form.button("§o§9有効化");
                        form.button("§o§4無効化");
                    
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0: // 戻る
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 1: // 有効化
                                    world.setDynamicProperty('itemUseOn_system', true);
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                                case 2: // 無効化
                                    world.setDynamicProperty('itemUseOn_system', false);
                                    Itemrun_HARUPhone1(eventData, player);
                                    break;
                            }
                        });
                    }
                    
                    // 禁止アイテム編集メニュー
                    function openBanMenu(player) {
                        const form = new ActionFormData()
                            .title("§0§lSecureCraft")
                            .body(`§c禁止アイテム§e操作§5>>>`)
                            .button("§l戻る", "textures/ui/back_button_hover")
                            .button("§1追加")
                            .button("§4削除");
                    
                        form.show(player).then((response) => {
                            if (response.canceled || response.selection === 0) {
                                Itemrun_HARUPhone1(eventData, player);
                                return;
                            }
                            if (response.selection === 1) {
                                addBannedBlock(player);
                            } else if (response.selection === 2) {
                                removeBannedBlock(player);
                            }
                        });
                    }
                    
                    // アイテム追加
                    function addBannedBlock(player) {
                        const form = new ModalFormData()
                            .title("§0§lSecureCraft")
                            .textField("§a追加する§eアイテムID§aを入力:", "例:minecraft:tnt");
                    
                        form.show(player).then((response) => {
                            if (response.canceled) return;
                            const newBlock = response.formValues[0].trim();
                            if (!newBlock) return;
                    
                            let bannedBlocks = world.getDynamicProperty("bannedBlocks") ? JSON.parse(world.getDynamicProperty("bannedBlocks")) : [];
                            if (!bannedBlocks.includes(newBlock)) {
                                bannedBlocks.push(newBlock);
                                world.setDynamicProperty("bannedBlocks", JSON.stringify(bannedBlocks));
                                player.sendMessage(`[§bSecurity§r] §b${newBlock}§rを禁止アイテムに§e追加しました`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                            } else {
                                player.sendMessage(`[§bSecurity§r] §b${newBlock}§rは既に§c禁止されています`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                            }
                        });
                    }
                    
                    // アイテム削除
                    function removeBannedBlock(player) {
                        let bannedBlocks = world.getDynamicProperty("bannedBlocks") ? JSON.parse(world.getDynamicProperty("bannedBlocks")) : [];
                        if (bannedBlocks.length === 0) {
                            player.sendMessage("[§bSecurity§r] §c削除できる禁止アイテムはありません");
                            return;
                        }
                    
                        const form = new ModalFormData()
                            .title("§0§lSecureCraft")
                            .dropdown("削除するアイテムを選択:", bannedBlocks);
                    
                        form.show(player).then((response) => {
                            if (response.canceled) return;
                            const selectedBlock = bannedBlocks[response.formValues[0]];
                            confirmRemove(player, selectedBlock);
                        });
                    }
                    
                    // 削除確認
                    function confirmRemove(player, block) {
                        const form = new ActionFormData()
                            .title("§0§lSecureCraft")
                            .body(`本当に ${block} を削除しますか？`)
                            .button("§4削除する")
                            .button("§1キャンセル");
                    
                        form.show(player).then((response) => {
                            if (response.canceled || response.selection !== 0) {
                                openBanMenu(player);
                                return;
                            }
                    
                            let bannedBlocks = JSON.parse(world.getDynamicProperty("bannedBlocks"));
                            bannedBlocks = bannedBlocks.filter((item) => item !== block);
                            world.setDynamicProperty("bannedBlocks", JSON.stringify(bannedBlocks));
                            player.sendMessage(`[§bSecurity§r] §b${block}§rを禁止アイテムから§e削除しました`);
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                        });
                    }
                    break;
                    default: break;
                }
            })
}

