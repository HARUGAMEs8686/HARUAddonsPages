import { world, system, BlockTypes, ItemStack } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';

// ポストデータの保存（ワールドカスタムプロパティを使用）
const POSTS_KEY = 'posts_data';
const SETTINGS_KEY = 'settings_data';

// デフォルト設定
let settings = {
    sendCost: 10, // アイテム送信時のコスト
    maxPosts: 5, // 1人あたりの最大ポスト数
};

// ポスト登録モードの管理
let registerMode = new Map(); // プレイヤーID -> モード状態
let uiCooldown = new Map(); // プレイヤーID -> クールタイム終了時刻

// クールタイム（ミリ秒）
const UI_COOLDOWN_MS = 1000;

// 初期化：スコアボードとワールドプロパティの設定
function initialize() {
    if (!world.getDynamicProperty(POSTS_KEY)) {
        world.setDynamicProperty(POSTS_KEY, JSON.stringify([]));
    }
    if (!world.getDynamicProperty(SETTINGS_KEY)) {
        world.setDynamicProperty(SETTINGS_KEY, JSON.stringify(settings));
    } else {
        settings = JSON.parse(world.getDynamicProperty(SETTINGS_KEY));
    }
}

// ポストデータの取得/保存
function getPosts() {
    return JSON.parse(world.getDynamicProperty(POSTS_KEY) || '[]');
}
function savePosts(posts) {
    world.setDynamicProperty(POSTS_KEY, JSON.stringify(posts));
}
function saveSettings() {
    world.setDynamicProperty(SETTINGS_KEY, JSON.stringify(settings));
}

// エンチャント情報の取得
function getEnchantmentDisplay(item) {
    if (!item) return '';
    const enchantments = item.getComponent('minecraft:enchantable')?.getEnchantments();
    if (!enchantments || !enchantments[Symbol.iterator]) return '';
    let display = '';
    try {
        for (const enchantment of enchantments) {
            if (enchantment && enchantment.type && enchantment.type.id && typeof enchantment.level === 'number') {
                display += `${enchantment.type.id}:${enchantment.level}, `;
            }
        }
    } catch (e) {
        // エンチャント取得エラーを無視
    }
    return display ? ` [${display.slice(0, -2)}]` : '';
}

// メインUI
export function Post(player) {
    if (registerMode.has(player.id)) {
        system.runTimeout(() => {
            registerMode.delete(player.id);
        }, 1);
        return;
    }
    system.run(() => {
        if (player.dimension.id !== 'minecraft:overworld') {
            player.sendMessage('§r[§bPost§r] §cこの機能はオーバーワールドでのみ使用できます。');
            return;
        }
        const form = new ActionFormData().title('§1Post').body('§a操作を選択してください').button(`§1ポストへ送信\n§0コスト§0>§4${settings.sendCost}`, 'textures/ui/normalicon1').button('§5MYポスト登録/編集', 'textures/ui/normalicon1');
        if (player.hasTag('HARUPhoneOP')) {
            form.button('§0管理者設定', 'textures/ui/operatorcontroller');
        }
        form.show(player).then(response => {
            if (response.canceled) return;
            switch (response.selection) {
                case 0:
                    showSendPostSelectionUI(player);
                    break;
                case 1:
                    showMyPostsUI(player);
                    break;
                case 2:
                    if (player.hasTag('HARUPhoneOP')) showAdminSelectionUI(player);
                    else player.sendMessage('§r[§bPost§r] §c管理者権限が必要です。');
                    break;
            }
        });
    });
}

// ポスト送信方法選択UI
function showSendPostSelectionUI(player) {
    const form = new ActionFormData().title('§1Post').body('§aポストの選択方法を選んでください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1オンラインのプレイヤーから選択', 'textures/ui/normalicon1').button('§5ポスト名で選択', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return Post(player);
        if (response.selection === 1) {
            showOnlinePlayerSelectionUI(player);
        } else {
            showSendPostByNameUI(player);
        }
    });
}

// オンラインプレイヤー選択UI
function showOnlinePlayerSelectionUI(player) {
    const players = world.getAllPlayers();
    const form = new ActionFormData().title('§1Post').body('§a送信先のプレイヤーを選んでください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    players.forEach(p => form.button(`§1${p.name}`, 'textures/ui/normalicon1'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return showSendPostSelectionUI(player);
        const targetPlayer = players[response.selection - 1];
        showSendPostOnlineUI(player, targetPlayer);
    });
}

// プレイヤーのポスト選択UI
function showSendPostOnlineUI(player, targetPlayer) {
    const posts = getPosts().filter(p => p.owner === targetPlayer.name || p.shared.includes(player.name));
    if (posts.length === 0) return player.sendMessage('§r[§bPost§r] §cこのプレイヤーのポストは利用できません。');

    const form = new ActionFormData().title(`§1Post`).body(`§a送信するポストを選んでください\n§5>>>§e${targetPlayer.name}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    posts.forEach(p => form.button(`§1${p.name}`, 'textures/ui/normalicon1'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return showOnlinePlayerSelectionUI(player);
        const targetPost = posts[response.selection - 1];
        showItemSelectionUI(player, targetPost);
    });
}

// ポスト名で選択
function showSendPostByNameUI(player) {
    const form = new ModalFormData().title('§1Post').textField('ポスト名', 'ポスト名を入力');

    form.show(player).then(response => {
        if (response.canceled) return showSendPostSelectionUI(player);
        const [postName] = response.formValues;
        if (!postName) return player.sendMessage('§r[§bPost§r] §cポスト名を入力してください。');
        const posts = getPosts();
        const targetPost = posts.find(p => p.name === postName);
        if (!targetPost) return player.sendMessage('§r[§bPost§r] §c指定されたポストが見つかりません。');
        showItemSelectionUI(player, targetPost);
    });
}

// アイテム選択UI
function showItemSelectionUI(player, targetPost) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const items = [];
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) items.push({ slot: i, typeId: item.typeId, amount: item.amount });
    }
    if (items.length === 0) {
        const dimension = world.getDimension(targetPost.dimension);
        removeTickingArea(dimension, targetPost.name);
        return player.sendMessage('§r[§bPost§r] §c所持しているアイテムがありません。');
    }

    const form = new ActionFormData().title('§1Post').body('送信するアイテムを選んでください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    items.forEach(item => {
        const enchantDisplay = getEnchantmentDisplay(inventory.getItem(item.slot));
        form.button(`§1${item.typeId.replace('minecraft:', '')} (${item.amount})${enchantDisplay}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            const dimension = world.getDimension(targetPost.dimension);
            removeTickingArea(dimension, targetPost.name);
            showOnlinePlayerSelectionUI(player);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showItemAmountUI(player, targetPost, selectedItem);
    });
}

// 送信アイテム個数入力UI
function showItemAmountUI(player, targetPost, selectedItem) {
    const form = new ModalFormData().title('§1Post').textField('送信する個数', `1-${selectedItem.amount}`);

    form.show(player).then(response => {
        if (response.canceled) {
            return showItemSelectionUI(player, targetPost);
        }
        const [amountStr] = response.formValues;
        const amount = parseInt(amountStr);
        if (isNaN(amount) || amount < 1 || amount > selectedItem.amount) {
            // エラー時もtickingareaを保持して再表示
            return player.sendMessage(`§r[§bPost§r] §c1から${selectedItem.amount}の間で入力してください。`);
        }
        showSendConfirmUI(player, targetPost, selectedItem, amount);
    });
}

// Tickingarea管理
function addTickingArea(dimension, location, postName) {
    const { x, y, z } = location;
    const command = `tickingarea add ${x} ${y} ${z} ${x} ${y} ${z} "post_${postName}" true`;
    try {
        dimension.runCommand(command);
    } catch (e) {
        // 既存のtickingareaがある場合など、エラーは無視
    }
}

function removeTickingArea(dimension, postName) {
    const command = `tickingarea remove "post_${postName}"`;
    try {
        dimension.runCommand(command);
    } catch (e) {
        // tickingareaが存在しない場合など、エラーは無視
    }
}

// 送信確認UI
function showSendConfirmUI(player, targetPost, selectedItem, amount) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const item = inventory.getItem(selectedItem.slot);
    const enchantDisplay = getEnchantmentDisplay(item);
    const form = new MessageFormData()
        .title('§1Post')
        .body(`§aポスト§r:§b${targetPost.name}\n§b${selectedItem.typeId.replace('minecraft:', '')}${enchantDisplay}§r:§e${amount}個§a送信します\n§cコスト§r: §b${settings.sendCost}Money`)
        .button1('§0キャンセル')
        .button2('§1送信');

    form.show(player).then(response => {
        const dimension = world.getDimension(targetPost.dimension);
        if (response.canceled || response.selection === 0) {
            return Post(player);
        }

        // 送信前にtickingareaを追加
        addTickingArea(dimension, targetPost.location, targetPost.name);

        system.runTimeout(() => {
            const money = world.scoreboard.getObjective('money').getScore(player) || 0;
            if (money < settings.sendCost) {
                player.sendMessage(`§r[§bPost§r] §c送信には§b${settings.sendCost}Money§cが必要です §e所持§r：§a${money}`);
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            if (!item || item.amount < amount) {
                player.sendMessage('§r[§bPost§r] §cアイテムが不足しています。');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            const block = dimension.getBlock(targetPost.location);
            if (block.typeId !== 'minecraft:chest' && block.typeId !== 'minecraft:barrel') {
                player.sendMessage('§r[§bPost§r] §cポストが破壊されています。');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            const container = block.getComponent('minecraft:inventory').container;
            const newItem = item.clone();
            newItem.amount = amount;

            // インベントリが満杯かチェック
            let emptySlots = 0;
            for (let i = 0; i < container.size; i++) {
                if (!container.getItem(i)) emptySlots++;
            }
            if (emptySlots === 0) {
                let canAdd = false;
                for (let i = 0; i < container.size; i++) {
                    const slotItem = container.getItem(i);
                    if (slotItem && slotItem.typeId === newItem.typeId && slotItem.amount < slotItem.maxAmount) {
                        canAdd = true;
                        break;
                    }
                }
                if (!canAdd) {
                    player.sendMessage('§r[§bPost§r] §cポストのインベントリが満杯です。');
                    removeTickingArea(dimension, targetPost.name);
                    return;
                }
            }

            try {
                container.addItem(newItem);
            } catch (e) {
                player.sendMessage('§r[§bPost§r] §cポストのインベントリに追加できませんでした。');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            if (item.amount === amount) {
                inventory.setItem(selectedItem.slot, null);
            } else {
                item.amount -= amount;
                inventory.setItem(selectedItem.slot, item);
            }

            try {
                player.runCommand(`scoreboard players add @s money -${settings.sendCost}`);
                let harupay_settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                if (harupay_settings.post != undefined && harupay_settings.post) {
                    world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(settings.sendCost));
                }
            } catch (e) {
                player.sendMessage('§r[§bPost§r] §cマネーの減算に失敗しました。');
                removeTickingArea(dimension, targetPost.name);
                return;
            }

            player.sendMessage(`§r[§bPost§r] §a${targetPost.name}§5<<<§b${selectedItem.typeId.replace('minecraft:', '')}${enchantDisplay}§r:§e${amount}個§a送信しました§r（§b-${settings.sendCost}Money§r）`);
            removeTickingArea(dimension, targetPost.name);
        }, 1);
    });
}

// MYポスト登録/編集UI
function showMyPostsUI(player) {
    const form = new ActionFormData().title('§1Post').body('§a操作を選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1ポスト登録モード', 'textures/ui/normalicon1').button('§0所持ポストの管理', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return Post(player);
        switch (response.selection) {
            case 1:
                registerMode.set(player.id, true);
                player.sendMessage('§r[§bPost§r] §aポスト登録モードを有効にしました。チェストまたは樽をクリックしてください。');
                break;
            case 2:
                showPostManagementUI(player);
                break;
        }
    });
}

// ポスト登録モード時の処理
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    system.run(() => {
        const { player, block } = event;
        if (!registerMode.has(player.id)) return;
        if (block.typeId !== 'minecraft:chest' && block.typeId !== 'minecraft:barrel') {
            player.sendMessage('§r[§bPost§r] §cチェストまたは樽を選択してください。');
            return;
        }

        // クールタイムチェック
        const currentTime = Date.now();
        if (uiCooldown.has(player.id) && currentTime < uiCooldown.get(player.id)) {
            return;
        }
        uiCooldown.set(player.id, currentTime + UI_COOLDOWN_MS);

        const posts = getPosts();
        // 既存ポストの位置重複チェック
        const existingPost = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
        if (existingPost) {
            player.sendMessage('§r[§bPost§r] §cこの位置には既にポストが登録されています。');
            return;
        }

        if (posts.filter(p => p.owner === player.name).length >= settings.maxPosts) {
            player.sendMessage(`§r[§bPost§r] §cポスト登録上限（${settings.maxPosts}）に達しています。`);
            return;
        }

        event.cancel = true; // デフォルトのチェスト開く動作をキャンセル
        const form = new ModalFormData().title('§1Post').textField('ポスト名', '例: マイポスト1');

        form.show(player).then(response => {
            if (response.canceled) return showMyPostsUI(player);
            const [postName] = response.formValues;
            if (!postName) return player.sendMessage('§r[§bPost§r] §cポスト名を入力してください。');

            // ポスト名の一意性チェック（大文字小文字を無視）
            if (posts.some(p => p.name.toLowerCase() === postName.toLowerCase())) {
                player.sendMessage('§r[§bPost§r] §cこのポスト名は既に使用されています。別の名前を試してください。');
                return;
            }

            posts.push({
                name: postName,
                owner: player.name,
                location: block.location,
                dimension: block.dimension.id,
                shared: [],
            });
            savePosts(posts);
            player.sendMessage(`§r[§bPost§r] §aポスト「${postName}」を登録しました！`);
            registerMode.delete(player.id);
        });
    });
});

// ポスト保護および破壊時のデータ削除
world.beforeEvents.playerBreakBlock.subscribe(event => {
    const { player, block } = event;
    const posts = getPosts();
    const post = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
    if (post) {
        if (post.owner !== player.name && !post.shared.includes(player.name) && !player.hasTag('HARUPhoneOP')) {
            event.cancel = true;
            player.sendMessage('§r[§bPost§r] §cこのポストはあなたが操作できません。');
        } else {
            // ポスト破壊時にデータ削除
            const newPosts = posts.filter(p => p !== post);
            savePosts(newPosts);
            player.sendMessage(`§r[§bPost§r] §aポスト「§b${post.name}§a」§c登録を解除しました`);
        }
    }
});

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;
    const posts = getPosts();
    const post = posts.find(p => p.location.x === block.location.x && p.location.y === block.location.y && p.location.z === block.location.z && p.dimension === block.dimension.id);
    if (post && post.owner !== player.name && !post.shared.includes(player.name) && !player.hasTag('HARUPhoneOP')) {
        event.cancel = true;
        player.sendMessage('§r[§bPost§r] §cこのポストはあなたが操作できません。');
    }
});

world.beforeEvents.explosion.subscribe(event => {
    const posts = getPosts();
    if (!posts || posts.length === 0) {
        return;
    }

    const impactedBlocks = event.getImpactedBlocks();
    const dimensionId = event.dimension.id;

    // 爆発で影響を受けるブロックのリストから、ポストとして登録されているブロックを除外する
    const newImpactedBlocks = impactedBlocks.filter(blockLocation => {
        return !posts.some(post => post.dimension === dimensionId && post.location.x === blockLocation.x && post.location.y === blockLocation.y && post.location.z === blockLocation.z);
    });
    event.setImpactedBlocks(newImpactedBlocks);
});

// 所持ポスト管理UI
function showPostManagementUI(player) {
    const posts = getPosts().filter(p => p.owner === player.name);
    const form = new ModalFormData()
        .title('§1Post')
        .dropdown(
            'ポスト選択',
            posts.map(p => p.name),
            0
        )
        .dropdown('操作', ['削除', '共有プレイヤー追加', '共有プレイヤー削除'], 0);

    form.show(player).then(response => {
        if (response.canceled) return showMyPostsUI(player);
        const [postIndex, operation] = response.formValues;
        const post = posts[postIndex];

        switch (operation) {
            case 0: // 削除
                const confirmForm = new MessageFormData().title('§1Post').body(`ポスト「${post.name}」を削除しますか？`).button1('§0いいえ').button2('§1はい');
                confirmForm.show(player).then(res => {
                    if (res.canceled || res.selection === 0) return showPostManagementUI(player);
                    if (res.selection === 1) {
                        const allPosts = getPosts();
                        const newPosts = allPosts.filter(p => p.name !== post.name || p.owner !== player.name);
                        savePosts(newPosts);
                        const dimension = world.getDimension(post.dimension);
                        removeTickingArea(dimension, post.name);
                        player.sendMessage(`§r[§bPost§r] §aポスト「§b${post.name}§a」を削除しました。`);
                    }
                });
                break;
            case 1: // 共有プレイヤー追加
                showAddSharedPlayerUI(player, post);
                break;
            case 2: // 共有プレイヤー削除
                showRemoveSharedPlayerUI(player, post);
                break;
        }
    });
}

// 共有プレイヤー追加UI
function showAddSharedPlayerUI(player, post) {
    const players = world.getAllPlayers().filter(p => p.name !== player.name && !post.shared.includes(p.name));
    const form = new ModalFormData().title('§1Post').dropdown(
        'プレイヤー選択',
        players.map(p => p.name),
        0
    );

    form.show(player).then(response => {
        if (response.canceled) return showPostManagementUI(player);
        const [playerIndex] = response.formValues;
        const targetPlayer = players[playerIndex];
        const posts = getPosts();
        const targetPost = posts.find(p => p.name === post.name && p.owner === player.name);
        targetPost.shared.push(targetPlayer.name);
        savePosts(posts);
        player.sendMessage(`§r[§bPost§r] §a${targetPlayer.name}をポスト「${post.name}」の共有者に追加しました。`);
    });
}

// 共有プレイヤー削除UI
function showRemoveSharedPlayerUI(player, post) {
    const form = new ModalFormData().title('§1Post').dropdown('プレイヤー選択', post.shared, 0);

    form.show(player).then(response => {
        if (response.canceled) return showPostManagementUI(player);
        const [playerIndex] = response.formValues;
        const targetPlayer = post.shared[playerIndex];
        const posts = getPosts();
        const targetPost = posts.find(p => p.name === post.name && p.owner === player.name);
        targetPost.shared = targetPost.shared.filter(name => name !== targetPlayer);
        savePosts(posts);
        player.sendMessage(`§r[§bPost§r] §a${targetPlayer}をポスト「${post.name}」の共有者から削除しました。`);
    });
}

// 管理者設定選択UI
function showAdminSelectionUI(player) {
    const form = new ActionFormData().title('§1Post').body('設定項目を選んでください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1アイテム送信コスト設定', 'textures/ui/normalicon1').button('§5最大ポスト数設定', 'textures/ui/normalicon1').button('§4ポスト操作（削除/編集）', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return Post(player);
        switch (response.selection) {
            case 1:
                showSendCostUI(player);
                break;
            case 2:
                showMaxPostsUI(player);
                break;
            case 3:
                showPostOperationUI(player);
                break;
        }
    });
}

// 送信コスト設定UI
function showSendCostUI(player) {
    const form = new ModalFormData().title('§1Post').textField('アイテム送信コスト', settings.sendCost.toString());

    form.show(player).then(response => {
        if (response.canceled) return showAdminSelectionUI(player);
        const [sendCost] = response.formValues;
        settings.sendCost = parseInt(sendCost) || settings.sendCost;
        saveSettings();
        player.sendMessage(`§r[§bPost§r] §a送信コストを${settings.sendCost}に更新しました。`);
    });
}

// 最大ポスト数設定UI
function showMaxPostsUI(player) {
    const form = new ModalFormData().title('§1Post').textField('1人あたりの最大ポスト数', settings.maxPosts.toString());

    form.show(player).then(response => {
        if (response.canceled) return showAdminSelectionUI(player);
        const [maxPosts] = response.formValues;
        settings.maxPosts = parseInt(maxPosts) || settings.maxPosts;
        saveSettings();
        player.sendMessage(`§r[§bPost§r] §a最大ポスト数を${settings.maxPosts}に更新しました。`);
    });
}

// ポスト操作選択UI
function showPostOperationUI(player) {
    const form = new ActionFormData().title('§1Post').body('操作を選んでください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1ポスト削除', 'textures/ui/normalicon1').button('§1ポスト編集', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return showAdminSelectionUI(player);
        if (response.selection === 1) {
            showDeletePostUI(player);
        } else {
            showEditPostUI(player);
        }
    });
}

// 不正ポスト削除UI
function showDeletePostUI(player) {
    const posts = getPosts();
    const form = new ModalFormData().title('§1Post').dropdown(
        'ポスト選択',
        posts.map(p => p.name),
        0
    );

    form.show(player).then(response => {
        if (response.canceled) return showPostOperationUI(player);
        const [postIndex] = response.formValues;
        const post = posts[postIndex];
        const newPosts = posts.filter(p => p !== post);
        savePosts(newPosts);
        player.sendMessage(`§r[§bPost§r] §aポスト「${post.name}」を削除しました。`);
    });
}

// 不正ポスト編集UI（例: 所有者変更）
function showEditPostUI(player) {
    const posts = getPosts();
    const players = world.getAllPlayers();
    const form = new ModalFormData()
        .title('§1Post')
        .dropdown(
            'ポスト選択',
            posts.map(p => `${p.name} (${p.owner})`),
            0
        )
        .dropdown(
            '新しい所有者',
            players.map(p => p.name),
            0
        );

    form.show(player).then(response => {
        if (response.canceled) return showPostOperationUI(player);
        const [postIndex, newOwnerIndex] = response.formValues;
        const post = posts[postIndex];
        const newOwner = players[newOwnerIndex].name;
        post.owner = newOwner;
        savePosts(posts);
        player.sendMessage(`§r[§bPost§r] §aポスト「${post.name}」の所有者を${newOwner}に変更しました。`);
    });
}

// 初期化実行
system.run(initialize);
