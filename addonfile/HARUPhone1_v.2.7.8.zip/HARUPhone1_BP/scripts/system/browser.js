import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

export function Browser(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('サービスを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1ページ検索', 'textures/ui/normalicon1');
    form.button('§5おすすめページ一覧', 'textures/ui/normalicon1');
    form.button('§9ページ作成§0/§5編集§0/§s広告', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                HARUPhone1(player);
                break;
            case 1:
                searchPage(player);
                break;
            case 2:
                recommendPage(player);
                break;
            case 3:
                managePage(player);
                break;
        }
    });
}

function searchPage(player) {
    var browser = world.getDynamicProperty('browser');
    if (browser == undefined) {
        var browser_system2 = [];
    } else {
        var browser_system2 = JSON.parse(browser);
    }
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField('キーワードを入力', 'キーワード検索');
    form.show(player).then(r => {
        if (r.canceled) {
            Browser(player);
            return;
        }
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body('検索結果');
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        var browser_cashdata1 = [];
        for (let i = 0; i < browser_system2.length; i++) {
            var domain_keyword_system1 = browser_system2[i][2].indexOf(`${r.formValues[0]}`);
            if (domain_keyword_system1 !== -1) {
                form.button(`§l§0${browser_system2[i][2]}\n§r§0投稿者:§5${browser_system2[i][0]}`, 'textures/ui/normalicon1');
                browser_cashdata1[browser_cashdata1.length] = i;
            }
        }
        if (browser_cashdata1[0] == undefined) {
            player.sendMessage(`§r[§bブラウザ§r] §aページが見つかりませんでした`);
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            searchPage(player);
            return;
        }
        form.show(player).then(r => {
            if (r.canceled) return;
            if (r.selection == 0) {
                searchPage(player);
                return;
            }
            let response = r.selection - 1;
            browser_system2[browser_cashdata1[response]][1] = browser_system2[browser_cashdata1[response]][1] + 1;
            const browsersystem1 = JSON.stringify(browser_system2);
            world.setDynamicProperty('browser', browsersystem1);
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body(`§l${browser_system2[browser_cashdata1[response]][3]}\n§e------------\n§r投稿者:§a${browser_system2[browser_cashdata1[response]][0]}\n§e§l------------\n§r${browser_system2[browser_cashdata1[response]][4]}\n\n${browser_system2[browser_cashdata1[response]][5]}\n\n${browser_system2[browser_cashdata1[response]][6]}\n\n${browser_system2[browser_cashdata1[response]][7]}`);
            form.button(`§l戻る`, 'textures/ui/icon_import.png');
            form.show(player).then(r => {
                if (r.canceled) return;
                searchPage(player);
            });
        });
    });
}

function recommendPage(player) {
    var browser = world.getDynamicProperty('browser');
    if (browser == undefined) {
        var browser_system2 = [];
    } else {
        var browser_system2 = JSON.parse(browser);
    }
    if (browser_system2[0] == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §aページが見つかりませんでした`);
        player.playSound('random.toast', {
            pitch: 0.4,
            volume: 1.0,
        });
        Browser(player);
        return;
    }
    browser_system2.sort((a, b) => (a[1] > b[1] ? -1 : 1));
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('おすすめページ');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_system2.length; i++) {
        if (i <= 7) {
            form.button(`§l§0${browser_system2[i][2]}\n§r§0投稿者:§5${browser_system2[i][0]}`, 'textures/ui/normalicon1');
        }
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            Browser(player);
            return;
        }
        let response = r.selection - 1;
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l${browser_system2[response][3]}\n§e------------\n§r投稿者:§a${browser_system2[response][0]}\n§e§l------------\n§r${browser_system2[response][4]}\n\n${browser_system2[response][5]}\n\n${browser_system2[response][6]}\n\n${browser_system2[response][7]}`);
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        form.show(player).then(r => {
            if (r.canceled) return;
            recommendPage(player);
        });
    });
}

function createPage(player) {
    if (world.getDynamicProperty('browser_newpage_money') == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
        player.playSound('random.toast', {
            pitch: 0.4,
            volume: 1.0,
        });
        Browser(player);
        return;
    }
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField('検索表示タイトル', 'ここは検索されやすいワード推奨');
    form.textField('ページタイトル', 'ここは太字になります');
    form.textField('文章1', 'タイトルの下に追加されます');
    form.textField('文章2', '文章1の下に追加されます');
    form.textField('文章3', '文章2の下に追加されます');
    form.textField('文章4', '文章3の下に追加されます');
    form.show(player).then(r => {
        if (r.canceled) {
            managePage(player);
            return;
        }
        const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
        if (score >= world.getDynamicProperty('browser_newpage_money')) {
            var browser = world.getDynamicProperty('browser');
            if (browser == undefined) {
                var browser_system2 = [];
            } else {
                var browser_system2 = JSON.parse(browser);
            }
            browser_system2.push([player.name, 0, r.formValues[0], r.formValues[1], r.formValues[2], r.formValues[3], r.formValues[4], r.formValues[5]]);
            const browser_system3 = JSON.stringify(browser_system2);
            world.setDynamicProperty('browser', browser_system3);
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r §e${world.getDynamicProperty('browser_newpage_money')}PAY支払いました"}]}`);
            player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_newpage_money')}`);
            player.sendMessage(`§r[§bブラウザ§r] §a新規作成しました`);
            let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
            if (settings.browser) {
                world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_newpage_money')));
            }
            player.playSound('random.toast', {
                pitch: 1.7,
                volume: 1.0,
            });
            managePage(player);
        } else {
            player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            managePage(player);
        }
    });
}

function editPage(player) {
    var browser = world.getDynamicProperty('browser');
    if (browser == undefined) {
        var browser_system2 = [];
    } else {
        var browser_system2 = JSON.parse(browser);
    }
    var browser_cash = [];
    for (let i = 0; i < browser_system2.length; i++) {
        if (browser_system2[i][0] == player.name) {
            browser_cash.push([[i], browser_system2[i]]);
        }
    }
    if (browser_cash[0] == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §a編集できるページがありません`);
        player.playSound('random.toast', {
            pitch: 0.4,
            volume: 1.0,
        });
        managePage(player);
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('編集するページを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_cash.length; i++) {
        form.button(`§0§l${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            managePage(player);
            return;
        }
        player_Cash_Data[player.id].browser_select = r.selection - 1;
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField('検索表示タイトル', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][2]}`);
        form.textField('ページタイトル', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][3]}`);
        form.textField('文章1', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][4]}`);
        form.textField('文章2', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][5]}`);
        form.textField('文章3', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][6]}`);
        form.textField('文章4', '', `${browser_cash[player_Cash_Data[player.id].browser_select][1][7]}`);
        form.show(player).then(r => {
            if (r.canceled) {
                managePage(player);
                return;
            }
            if (r.formValues[0] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][2] = r.formValues[0];
            }
            if (r.formValues[1] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][3] = r.formValues[1];
            }
            if (r.formValues[2] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][4] = r.formValues[2];
            }
            if (r.formValues[3] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][5] = r.formValues[3];
            }
            if (r.formValues[4] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][6] = r.formValues[4];
            }
            if (r.formValues[5] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][7] = r.formValues[5];
            }
            browser_system2[browser_cash[player_Cash_Data[player.id].browser_select][0][0]] = browser_cash[player_Cash_Data[player.id].browser_select][1];
            const browser_system3 = JSON.stringify(browser_system2);
            world.setDynamicProperty('browser', browser_system3);
            player.sendMessage(`§r[§bブラウザ§r] §aページを編集しました`);
            player.playSound('random.toast', {
                pitch: 1.7,
                volume: 1.0,
            });
            managePage(player);
        });
    });
}

function deletePage(player) {
    var browser = world.getDynamicProperty('browser');
    if (browser == undefined) {
        var browser_system2 = [];
    } else {
        var browser_system2 = JSON.parse(browser);
    }
    var browser_cash = [];
    for (let i = 0; i < browser_system2.length; i++) {
        if (browser_system2[i][0] == player.name) {
            browser_cash.push([[i], browser_system2[i]]);
        }
    }
    if (browser_cash[0] == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §a削除できるページがありません`);
        player.playSound('random.toast', {
            pitch: 0.4,
            volume: 1.0,
        });
        managePage(player);
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('削除するページを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_cash.length; i++) {
        form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            managePage(player);
            return;
        }
        let response = r.selection - 1;
        browser_system2.splice(browser_cash[response][0][0], 1);
        const browser_system3 = JSON.stringify(browser_system2);
        world.setDynamicProperty('browser', browser_system3);
        player.sendMessage(`§r[§bブラウザ§r] §aページを削除しました`);
        player.playSound('random.toast', {
            pitch: 1.7,
            volume: 1.0,
        });
        managePage(player);
    });
}

function Ad(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('サービスを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§1広告化 \n§5ページ広告化費用§r:§s${world.getDynamicProperty('browser_performance_money')}§rPAY`, 'textures/ui/normalicon1');
    form.button('§4広告削除', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                managePage(player);
                break;
            case 1:
                if (world.getDynamicProperty('browser_performance_money') == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    Ad(player);
                    return;
                }
                var browser = world.getDynamicProperty('browser');
                if (browser == undefined) {
                    var browser_system2 = [];
                } else {
                    var browser_system2 = JSON.parse(browser);
                }
                var browser_cash = [];
                for (let i = 0; i < browser_system2.length; i++) {
                    if (browser_system2[i][0] == player.name) {
                        browser_cash.push([[i], browser_system2[i]]);
                    }
                }
                if (browser_cash[0] == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §a広告化できるページがありません`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    Ad(player);
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('広告化するページを選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < browser_cash.length; i++) {
                    form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Ad(player);
                        return;
                    }
                    let response = r.selection - 1;
                    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                    if (score >= world.getDynamicProperty('browser_performance_money')) {
                        var performance = world.getDynamicProperty('performance');
                        if (performance == undefined) {
                            var performance_system2 = [];
                        } else {
                            var performance_system2 = JSON.parse(performance);
                        }
                        var performance_cash_system2 = 0;
                        for (let i = 0; i < performance_system2.length; i++) {
                            if (performance_system2[i][2] == browser_cash[response][1][2] && performance_system2[i][0] == browser_cash[response][1][0] && performance_system2[i][3] == browser_cash[response][1][3] && performance_system2[i][4] == browser_cash[response][1][4] && performance_system2[i][5] == browser_cash[response][1][5]) {
                                performance_cash_system2 = 1;
                            }
                        }
                        if (performance_cash_system2 == 1) {
                            player.sendMessage(`§r[§bブラウザ§r] §4選択したページは既に広告化済みです`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            Ad(player);
                            return;
                        }
                        performance_system2.push(browser_cash[response][1]);
                        const performance_system3 = JSON.stringify(performance_system2);
                        world.setDynamicProperty('performance', performance_system3);
                        player.sendMessage(`§r[§bブラウザ§r] §e${world.getDynamicProperty('browser_performance_money')}PAY支払いました`);
                        player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_performance_money')}`);
                        player.sendMessage(`§r[§bブラウザ§r] §aページを広告化しました`);
                        let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                        if (settings.browser) {
                            world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_performance_money')));
                        }
                        player.playSound('random.toast', {
                            pitch: 1.7,
                            volume: 1.0,
                        });
                        Ad(player);
                    } else {
                        player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
                        player.playSound('random.toast', {
                            pitch: 0.4,
                            volume: 1.0,
                        });
                        Ad(player);
                    }
                });
                break;
            case 2:
                var browser = world.getDynamicProperty('performance');
                if (browser == undefined) {
                    var browser_system2 = [];
                } else {
                    var browser_system2 = JSON.parse(browser);
                }
                var browser_cash = [];
                for (let i = 0; i < browser_system2.length; i++) {
                    if (browser_system2[i][0] == player.name) {
                        browser_cash.push([[i], browser_system2[i]]);
                    }
                }
                if (browser_cash[0] == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §a削除できる広告がありません`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    Ad(player);
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('削除する広告を選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < browser_cash.length; i++) {
                    form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Ad(player);
                        return;
                    }
                    let response = r.selection - 1;
                    browser_system2.splice(browser_cash[response][0][0], 1);
                    const browser_system3 = JSON.stringify(browser_system2);
                    world.setDynamicProperty('performance', browser_system3);
                    player.sendMessage(`§r[§bブラウザ§r] §a広告を削除しました`);
                    player.playSound('random.toast', {
                        pitch: 1.7,
                        volume: 1.0,
                    });
                    Ad(player);
                });
                break;
        }
    });
}

function managePage(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('機能を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§1新規作成 \n§5ページ投稿費用§r:§s${world.getDynamicProperty('browser_newpage_money')}`, 'textures/ui/normalicon1');
    form.button('§1既存のページ編集', 'textures/ui/normalicon1');
    form.button('§4ページの削除', 'textures/ui/normalicon1');
    form.button(`§s広告\n§r§8こちらで作成したページを広告化できます`, 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Browser(player);
                break;
            case 1:
                createPage(player);
                break;
            case 2:
                editPage(player);
                break;
            case 3:
                deletePage(player);
                break;
            case 4:
                Ad(player);
                break;
        }
    });
}
