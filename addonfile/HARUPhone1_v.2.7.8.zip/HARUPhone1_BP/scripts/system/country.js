import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';

import { Operator_Controller } from '../system/Operator_Controller';
import { HARUPhone1 } from '../itemrun/haruphone1';

// スコアボードと動的プロパティの初期化
const MONEY_OBJECTIVE = 'money';
const CHUNK_PRICE_PROPERTY = 'chunk_price';
const NATION_DB = 'nation_data';

// オーバーワールド用の既存のチャンクデータ/公共土地データキー
const CHUNK_DB = 'chunk_data';
const PUBLIC_LAND_DB = 'public_land_data';

// ディメンションごとにチャンクデータを管理するためのプレフィックス（ネザー、エンド用）
const CHUNK_DB_PREFIX = 'chunk_data_';
// ディメンションごとに公共土地データを管理するためのプレフィックス（ネザー、エンド用）
const PUBLIC_LAND_DB_PREFIX = 'public_land_data_';

// 各ディメンションの社会システム有効化プロパティ
const SYSTEM_ENABLED_OVERWORLD = 'nation_system_enabled_overworld';
const SYSTEM_ENABLED_NETHER = 'nation_system_enabled_nether';
const SYSTEM_ENABLED_END = 'nation_system_enabled_end';

const NATION_CREATION_COST_PROPERTY = 'nation_creation_cost';
const ALLOW_MULTIPLE_NATIONS_PROPERTY = 'allow_multiple_nations';
const UNOWNED_LAND_INTERACTION = 'unowned_land_interaction';
const MAX_PURCHASE_CHUNKS_PROPERTY = 'max_purchase_chunks';
const CHUNK_SELL_PRICE_PROPERTY = 'chunk_sell_price';
const UNOWNED_LAND_INTERACT = 'unowned_land_interact';

const BOUNDARY_PARTICLE_DENSITY = 2; // パーティクルの間隔（ブロック単位）
const BOUNDARY_VIEW_DISTANCE = 5; // 表示範囲（チャンク単位）
const BOUNDARY_HEIGHT = 3; // 壁の高さ（ブロック数）

const placedBoundaryChunks = new Map();

// システムが有効か確認 (現在のディメンションに基づいて)
function isSystemEnabledForDimension(dimensionId) {
    switch (dimensionId) {
        case 'minecraft:overworld':
            return world.getDynamicProperty(SYSTEM_ENABLED_OVERWORLD) === true;
        case 'minecraft:nether':
            return world.getDynamicProperty(SYSTEM_ENABLED_NETHER) === true;
        case 'minecraft:the_end':
            return world.getDynamicProperty(SYSTEM_ENABLED_END) === true;
        default:
            return false;
    }
}

// 複数国所属が許可されているか確認
function isMultipleNationsAllowed() {
    return world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === true;
}

// チャンク座標の取得
function getChunkCoords(location) {
    return {
        x: Math.floor(location.x / 16),
        z: Math.floor(location.z / 16),
    };
}

// データベースを分割するためのキー生成
function generateSplitKey(dbName, index) {
    return `${dbName}_${index}`;
}

// 分割されたデータを取得
function getSplitData(dbName) {
    const data = {};
    let index = 0;
    while (true) {
        const key = generateSplitKey(dbName, index);
        const rawData = world.getDynamicProperty(key);
        if (!rawData) break;
        try {
            const parsed = JSON.parse(rawData);
            Object.assign(data, parsed);
        } catch (e) {
            console.warn(`Failed to parse split data for ${key}:`, e);
        }
        index++;
    }
    return data;
}

// 分割されたデータを保存
function setSplitData(dbName, data) {
    const entries = Object.entries(data);
    const chunkSize = 100; // 1つのプロパティに保存するエントリ数（調整可能）
    let index = 0;
    let currentData = {};

    // データをチャンクに分割
    for (let i = 0; i < entries.length; i++) {
        const [key, value] = entries[i];
        currentData[key] = value;

        if (Object.keys(currentData).length >= chunkSize || i === entries.length - 1) {
            try {
                world.setDynamicProperty(generateSplitKey(dbName, index), JSON.stringify(currentData));
            } catch (e) {
                console.warn(`Failed to set split data for ${dbName}_${index}:`, e);
            }
            currentData = {};
            index++;
        }
    }

    // 不要になった古いプロパティを削除
    while (true) {
        const key = generateSplitKey(dbName, index);
        if (!world.getDynamicProperty(key)) break;
        world.setDynamicProperty(key, undefined);
        index++;
    }
}

// 既存データを新しい分割形式に移行（単一プロパティから分割プロパティへ）
function migrateData(dbName) {
    const oldData = world.getDynamicProperty(dbName);
    if (oldData) {
        try {
            const parsed = JSON.parse(oldData);
            if (typeof parsed === 'object' && parsed !== null) {
                setSplitData(dbName, parsed);
                world.setDynamicProperty(dbName, undefined); // 古い単一プロパティを削除
                console.log(`[社会システム] ${dbName} のデータを新しい分割形式に移行しました。`);
            }
        } catch (e) {
            console.warn(`Failed to migrate data for ${dbName}:`, e);
        }
    }
}

// 国のデータの管理
function getNationData() {
    // 初回実行時に古いデータを移行 (NATION_DBは常に単一のキー)
    if (world.getDynamicProperty(NATION_DB) && !world.getDynamicProperty(`${NATION_DB}_0`)) {
        migrateData(NATION_DB);
    }
    return getSplitData(NATION_DB);
}

function setNationData(data) {
    try {
        if (typeof data !== 'object' || data === null) {
            console.warn('Invalid nation data provided. Skipping save.');
            return;
        }
        // データの検証（例: 必須フィールドのチェック）
        for (const nationId in data) {
            if (!data[nationId].members || !Array.isArray(data[nationId].members)) {
                console.warn(`Invalid members data for nation ${nationId}. Skipping save.`);
                return;
            }
        }
        setSplitData(NATION_DB, data);
    } catch (e) {
        console.warn('Failed to set nation data:', e);
    }
}

// チャンクデータの管理 (ディメンションIDを引数に追加)
function getChunkData(dimensionId) {
    let dbName;
    if (dimensionId === 'minecraft:overworld') {
        dbName = CHUNK_DB;
        // 古い単一プロパティが存在し、かつ分割プロパティが存在しない場合のみ移行
        if (world.getDynamicProperty(dbName) && !world.getDynamicProperty(`${dbName}_0`)) {
            migrateData(dbName);
        }
    } else {
        dbName = `${CHUNK_DB_PREFIX}${dimensionId}`;
        // 新しいディメンションのデータも、もし単一プロパティで誤って保存されていたら移行
        if (world.getDynamicProperty(dbName) && !world.getDynamicProperty(`${dbName}_0`)) {
            migrateData(dbName);
        }
    }
    return getSplitData(dbName);
}

function setChunkData(dimensionId, data) {
    try {
        let dbName;
        if (dimensionId === 'minecraft:overworld') {
            dbName = CHUNK_DB;
        } else {
            dbName = `${CHUNK_DB_PREFIX}${dimensionId}`;
        }
        setSplitData(dbName, data);
    } catch (e) {
        console.warn('Failed to set chunk data:', e);
    }
}

// プレイヤーの所属国を取得
function getPlayerNations(player) {
    const nationData = getNationData();
    return Object.entries(nationData).filter(([_, nation]) => nation.members.includes(player.name));
}

// 公共土地データの管理 (ディメンションIDを引数に追加)
function getPublicLandData(dimensionId) {
    let dbName;
    if (dimensionId === 'minecraft:overworld') {
        dbName = PUBLIC_LAND_DB;
        // 古い単一プロパティが存在し、かつ分割プロパティが存在しない場合のみ移行
        if (world.getDynamicProperty(dbName) && !world.getDynamicProperty(`${dbName}_0`)) {
            migrateData(dbName);
        }
    } else {
        dbName = `${PUBLIC_LAND_DB_PREFIX}${dimensionId}`;
        // 新しいディメンションのデータも、もし単一プロパティで誤って保存されていたら移行
        if (world.getDynamicProperty(dbName) && !world.getDynamicProperty(`${dbName}_0`)) {
            migrateData(dbName);
        }
    }
    return getSplitData(dbName);
}

function setPublicLandData(dimensionId, data) {
    try {
        let dbName;
        if (dimensionId === 'minecraft:overworld') {
            dbName = PUBLIC_LAND_DB;
        } else {
            dbName = `${PUBLIC_LAND_DB_PREFIX}${dimensionId}`;
        }
        setSplitData(dbName, data);
    } catch (e) {
        console.warn('Failed to set public land data:', e);
    }
}

function getCurrentLocationName(player) {
    const chunk = getChunkCoords(player.location);
    const dimensionId = player.dimension.id;
    const chunkData = getChunkData(dimensionId);
    const nationData = getNationData();
    const publicLandData = getPublicLandData(dimensionId);

    let nowChunkName = world.getDynamicProperty('WorldspaceNAME');
    if (publicLandData[chunk.x + ':' + chunk.z]) {
        nowChunkName = publicLandData[chunk.x + ':' + chunk.z].name;
    } else if (chunkData[chunk.x + ':' + chunk.z]?.nation) {
        const nation = nationData[chunkData[chunk.x + ':' + chunk.z].nation];
        if (nation) {
            nowChunkName = nation.name;
        }
    }
    return nowChunkName;
}

// メインUIを表示
export function showMainUI(player) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const chunk = getChunkCoords(player.location);
    const playerNations = getPlayerNations(player);
    const hasNation = playerNations.length > 0;
    const nowChunkName = getCurrentLocationName(player);

    const form = new ActionFormData().title('§1HARUPhone1').body(`§c-現在地-\n §a>§e${nowChunkName}\n §a>§b${chunk.x}§r,§b${chunk.z}`);

    const buttons = [];
    buttons.push({ text: '§l戻る', action: 'back', icon: 'textures/ui/icon_import.png' });
    if (hasNation) {
        buttons.push({ text: `§4土地を購入\n§5>>>§1コスト§r:§s${world.getDynamicProperty(CHUNK_PRICE_PROPERTY)}`, action: 'buyLand', icon: 'textures/ui/normalicon1.png' });
        buttons.push({ text: `§4土地を売却\n§5>>>§1価格§r:§s${world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY)}`, action: 'sellLand', icon: 'textures/ui/normalicon1.png' });
        buttons.push(playerNations.some(([_, nation]) => nation.leader === player.name) ? { text: `§1${world.getDynamicProperty('WorldgroupName')}を管理`, action: 'manageNation', icon: 'textures/ui/normalicon1.png' } : { text: `§4${world.getDynamicProperty('WorldgroupName')}を退出`, action: 'leaveNation', icon: 'textures/ui/normalicon1.png' });
        if (playerNations.some(([nationId, nation]) => nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            buttons.push({ text: '§4メンバーを招待', action: 'inviteMember', icon: 'textures/ui/normalicon1.png' });
        }
    } else {
        buttons.push({ text: `§1${world.getDynamicProperty('WorldgroupName')}を作成\n§5>>>§1コスト§r:§s${world.getDynamicProperty(NATION_CREATION_COST_PROPERTY)}`, action: 'createNation', icon: 'textures/ui/normalicon1.png' });
    }
    buttons.push({ text: '§0マイ情報', action: 'showMyInfo', icon: 'textures/ui/normalicon1.png' });
    buttons.push({ text: '§9招待を確認', action: 'checkInvites', icon: 'textures/ui/normalicon1.png' });

    buttons.forEach(button => form.button(button.text, button.icon));

    form.show(player).then(response => {
        if (response.canceled) return;
        const selectedAction = buttons[response.selection].action;

        if (hasNation) {
            if (selectedAction === 'back') {
                HARUPhone1(player);
            } else if (selectedAction === 'buyLand' || selectedAction === 'sellLand' || selectedAction === 'manageNation' || selectedAction === 'leaveNation' || selectedAction === 'inviteMember') {
                selectNationForAction(player, selectedAction);
            } else if (selectedAction === 'showMyInfo') {
                showMyInfo(player);
            } else if (selectedAction === 'checkInvites') {
                checkInvites(player);
            } else if (selectedAction === 'togglePlayerBoundary') {
                // 新しいアクション
                togglePlayerBoundary(player);
            }
        } else {
            if (selectedAction === 'back') {
                HARUPhone1(player);
            } else if (selectedAction === 'createNation') {
                createNation(player);
            } else if (selectedAction === 'showMyInfo') {
                showMyInfo(player);
            } else if (selectedAction === 'checkInvites') {
                checkInvites(player);
            } else if (selectedAction === 'togglePlayerBoundary') {
                // 新しいアクション
                togglePlayerBoundary(player);
            }
        }
    });
}

// 複数国所属時の国選択UI
function selectNationForAction(player, action) {
    const playerNations = getPlayerNations(player);
    if (playerNations.length === 1) {
        const [nationId, nation] = playerNations[0];
        if (action === 'buyLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === 'sellLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            sellLand(player, nationId);
        } else if (action === 'manageNation' && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === 'leaveNation') {
            leaveNation(player, nationId);
        } else if (action === 'inviteMember' && (nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            inviteMember(player, nationId);
        } else {
            player.sendMessage('§r[§b社会システム§r] §cこの操作の権限がありません。');
        }
        return;
    }

    const form = new ActionFormData().title(`§5${world.getDynamicProperty('WorldgroupName')}を選択`).body(`§fどの${world.getDynamicProperty('WorldgroupName')}を操作しますか？`);
    playerNations.forEach(([nationId, nation]) => {
        form.button(`§1${nation.name}`);
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        const [nationId, nation] = playerNations[response.selection];
        if (action === 'buyLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === 'sellLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            sellLand(player, nationId);
        } else if (action === 'manageNation' && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === 'leaveNation') {
            leaveNation(player, nationId);
        } else if (action === 'inviteMember' && (nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            inviteMember(player, nationId);
        } else {
            player.sendMessage('§r[§b社会システム§r] §cこの操作の権限がありません。');
        }
    });
}

function sellLand(player, nationId) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const hasPurchasePermission = nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand;
    if (!hasPurchasePermission) {
        player.sendMessage('§r[§b社会システム§r] §c土地売却の権限がありません。');
        return;
    }

    const form = new ActionFormData().title('§1土地売却方法').body('§f売却方法を選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1現在地のチャンクを売却').button('§4範囲を選択して売却');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMainUI(player);
            return;
        }
        if (response.selection === 1) {
            sellSingleChunk(player, nationId);
        } else if (response.selection === 2) {
            sellMultipleChunks(player, nationId);
        }
    });
}

function sellSingleChunk(player, nationId) {
    const dimensionId = player.dimension.id;
    const chunk = getChunkCoords(player.location);
    const chunkData = getChunkData(dimensionId);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const sellPrice = world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY);

    if (!chunkData[chunkKey] || chunkData[chunkKey].nation !== nationId) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはあなたの国が所有していません。');
        return;
    }

    const form = new MessageFormData().title('§1HARUPhone1').body(`§fこのチャンクを§a${sellPrice}§fで売却しますか？\n§b座標: (§e${chunk.x}, ${chunk.z}§b)`).button1('§4キャンセル').button2('§1売却');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, sellPrice);
            delete chunkData[chunkKey];
            setChunkData(dimensionId, chunkData);
            player.sendMessage('§r[§b社会システム§r] §aチャンクを売却しました！');
        }
    });
}

function sellMultipleChunks(player, nationId) {
    const dimensionId = player.dimension.id;
    const maxChunks = world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) || 10;
    const sellPrice = world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY);
    const currentChunk = getChunkCoords(player.location);

    const form = new ModalFormData().title('§1範囲選択で売却').textField('§f開始X座標', currentChunk.x.toString()).textField('§f開始Z座標', currentChunk.z.toString()).textField('§f終了X座標', '', currentChunk.x.toString()).textField('§f終了Z座標', '', currentChunk.z.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            sellLand(player, nationId);
            return;
        }

        const [startX, startZ, endX, endZ] = response.formValues.map(v => parseInt(v));
        if (isNaN(startX) || isNaN(startZ) || isNaN(endX) || isNaN(endZ)) {
            player.sendMessage('§r[§b社会システム§r] §c有効な座標を入力してください。');
            return;
        }

        const minX = Math.min(startX, endX);
        const maxX = Math.max(startX, endX);
        const minZ = Math.min(startZ, endZ);
        const maxZ = Math.max(startZ, endZ);

        const chunkCount = (maxX - minX + 1) * (maxZ - minZ + 1);
        if (chunkCount > maxChunks) {
            player.sendMessage(`§r[§b社会システム§r] §c一度に売却できるチャンク数は${maxChunks}までです。`);
            return;
        }

        const chunkData = getChunkData(dimensionId);
        let totalPrice = 0;
        const chunksToSell = [];

        for (let x = minX; x <= maxX; x++) {
            for (let z = minZ; z <= maxZ; z++) {
                const chunkKey = `${x}:${z}`;
                if (!chunkData[chunkKey] || chunkData[chunkKey].nation !== nationId) {
                    player.sendMessage(`§r[§b社会システム§r] §cチャンク(${x}, ${z})はあなたの国が所有していません。`);
                    return;
                }
                chunksToSell.push({ x, z });
                totalPrice += sellPrice;
            }
        }

        const form = new MessageFormData().title('§1複数チャンク売却確認').body(`§f${chunkCount}チャンクを§a${totalPrice}§fで売却しますか？\n§b範囲: (§e${minX}, ${minZ}§b) から (§e${maxX}, ${maxZ}§b)`).button1('§4キャンセル').button2('§1売却');

        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) return;
            if (response.selection === 1) {
                world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, totalPrice);
                chunksToSell.forEach(chunk => {
                    delete chunkData[`${chunk.x}:${chunk.z}`];
                });
                setChunkData(dimensionId, chunkData);
                player.sendMessage(`§r[§b社会システム§r] §a${chunkCount}チャンクを売却しました！`);
            }
        });
    });
}

function setChunkSellPrice(player) {
    const currentPrice = world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY) || 0;
    const form = new ModalFormData().title('§1チャンク売却価格設定').textField('§f新しいチャンク売却価格', currentPrice.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [sellPrice] = response.formValues;
        const parsedSellPrice = parseInt(sellPrice);

        if (isNaN(parsedSellPrice) || parsedSellPrice < 0) {
            player.sendMessage('§r[§b社会システム§r] §c有効な売却価格を入力してください。');
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(CHUNK_SELL_PRICE_PROPERTY, parsedSellPrice);
        player.sendMessage(`§r[§b社会システム§r] §aチャンク売却価格を§e${parsedSellPrice}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// マイ情報表示
function showMyInfo(player) {
    const playerNations = getPlayerNations(player);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;

    let body = `§a所持金: §e${score}\n\n§b所属${world.getDynamicProperty('WorldgroupName')}:\n`;
    if (playerNations.length === 0) {
        body += '§7なし\n';
    } else {
        playerNations.forEach(([_, nation]) => {
            const isLeader = nation.leader === player.name;
            const canBuyLand = nation.permissions?.[player.name]?.canBuyLand || false;
            const canInvite = nation.permissions?.[player.name]?.canInvite || false;
            body += `- §6${nation.name} (§c${isLeader ? 'リーダー' : 'メンバー'})\n`;
            body += `  §a土地購入権限: §e${canBuyLand ? 'あり' : 'なし'}\n`;
            body += `  §aメンバー招待権限: §e${canInvite ? 'あり' : 'なし'}\n`;
        });
    }

    const form = new ActionFormData().title('§1HARUPhone1').body(body).button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMainUI(player);
            return;
        }
    });
}

// 土地購入
function buyLand(player, nationId) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const hasPurchasePermission = nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand;
    if (!hasPurchasePermission) {
        player.sendMessage('§r[§b社会システム§r] §c土地購入の権限がありません。');
        return;
    }

    const form = new ActionFormData().title('§1土地購入方法').body('§f購入方法を選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1現在地のチャンクを購入').button('§4範囲を選択して購入');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMainUI(player);
            return;
        }
        if (response.selection === 1) {
            buySingleChunk(player, nationId);
        } else if (response.selection === 2) {
            buyMultipleChunks(player, nationId);
        }
    });
}

function buySingleChunk(player, nationId) {
    const dimensionId = player.dimension.id;
    const chunk = getChunkCoords(player.location);
    const chunkData = getChunkData(dimensionId);
    const publicLandData = getPublicLandData(dimensionId);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);

    if (chunkData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに購入されています。');
        return;
    }
    if (publicLandData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクは公共土地です。');
        return;
    }

    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < chunkPrice) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${chunkPrice}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new MessageFormData().title('§1HARUPhone1').body(`§fこのチャンクを§a${chunkPrice}§fで購入しますか？\n§b座標: (§e${chunk.x}, ${chunk.z}§b)`).button1('§4キャンセル').button2('§1購入');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -chunkPrice);
            let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
            if (settings.socialSystem) {
                world.setDynamicProperty('harupay_op_money', (world.getDynamicProperty('harupay_op_money') || 0) + Number(chunkPrice));
            }
            chunkData[chunkKey] = { nation: nationId };
            setChunkData(dimensionId, chunkData);
            player.sendMessage('§r[§b社会システム§r] §aチャンクを購入しました！');
        }
    });
}

function buyMultipleChunks(player, nationId) {
    const dimensionId = player.dimension.id;
    const maxChunks = world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) || 10;
    const chunkPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);
    const currentChunk = getChunkCoords(player.location);

    const form = new ModalFormData().title('§1範囲選択で購入').textField('§f開始X座標', currentChunk.x.toString()).textField('§f開始Z座標', currentChunk.z.toString()).textField('§f終了X座標', '', currentChunk.x.toString()).textField('§f終了Z座標', '', currentChunk.z.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            buyLand(player, nationId);
            return;
        }

        const [startX, startZ, endX, endZ] = response.formValues.map(v => parseInt(v));
        if (isNaN(startX) || isNaN(startZ) || isNaN(endX) || isNaN(endZ)) {
            player.sendMessage('§r[§b社会システム§r] §c有効な座標を入力してください。');
            return;
        }

        const minX = Math.min(startX, endX);
        const maxX = Math.max(startX, endX);
        const minZ = Math.min(startZ, endZ);
        const maxZ = Math.max(startZ, endZ);

        const chunkCount = (maxX - minX + 1) * (maxZ - minZ + 1);
        if (chunkCount > maxChunks) {
            player.sendMessage(`§r[§b社会システム§r] §c一度に購入できるチャンク数は${maxChunks}までです。`);
            return;
        }

        const chunkData = getChunkData(dimensionId);
        const publicLandData = getPublicLandData(dimensionId);
        let totalCost = 0;
        const chunksToBuy = [];

        for (let x = minX; x <= maxX; x++) {
            for (let z = minZ; z <= maxZ; z++) {
                const chunkKey = `${x}:${z}`;
                if (chunkData[chunkKey]) {
                    player.sendMessage(`§r[§b社会システム§r] §cチャンク(${x}, ${z})はすでに購入されています。`);
                    return;
                }
                if (publicLandData[chunkKey]) {
                    player.sendMessage(`§r[§b社会システム§r] §cチャンク(${x}, ${z})は公共土地です。`);
                    return;
                }
                chunksToBuy.push({ x, z });
                totalCost += chunkPrice;
            }
        }

        const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
        if (score < totalCost) {
            player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${totalCost}§c、所持: §e${score}§c）。`);
            return;
        }

        const form = new MessageFormData().title('§1複数チャンク購入確認').body(`§f${chunkCount}チャンクを§a${totalCost}§fで購入しますか？\n§b範囲: (§e${minX}, ${minZ}§b) から (§e${maxX}, ${maxZ}§b)`).button1('§4キャンセル').button2('§1購入');

        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) return;
            if (response.selection === 1) {
                world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -totalCost);
                let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                if (settings.socialSystem) {
                    world.setDynamicProperty('harupay_op_money', (world.getDynamicProperty('harupay_op_money') || 0) + Number(totalCost));
                }
                chunksToBuy.forEach(chunk => {
                    chunkData[`${chunk.x}:${chunk.z}`] = { nation: nationId };
                });
                setChunkData(dimensionId, chunkData);
                player.sendMessage(`§r[§b社会システム§r] §a${chunkCount}チャンクを購入しました！`);
            }
        });
    });
}

// 国作成
function createNation(player) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const playerNations = getPlayerNations(player);
    if (playerNations.length > 0 && !isMultipleNationsAllowed()) {
        player.sendMessage(`§r[§b社会システム§r] §cすでに${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
        return;
    }

    const creationCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < creationCost) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${creationCost}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new ModalFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}を作成`)
        .textField(`§f${world.getDynamicProperty('WorldgroupName')}の名前`, '例: MyNation')
        .dropdown('§fメンバーシップ', ['オープン', '招待制'], 0);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) return;
        const [nationName, membershipType] = response.formValues;
        if (!nationName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}の名前を入力してください。`);
            return;
        }
        const nationId = nationName.toLowerCase().replace(/\s/g, '_');
        if (nationData[nationId]) {
            player.sendMessage(`§r[§b社会システム§r] §cこの名前の${world.getDynamicProperty('WorldgroupName')}はすでに存在します。`);
            return;
        }

        world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -creationCost);
        //opmoney
        let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
        if (settings.socialSystem) {
            world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(creationCost));
        }
        nationData[nationId] = {
            name: nationName,
            leader: player.name,
            members: [player.name],
            membership: membershipType === 0 ? 'open' : 'invite',
            invites: [],
            permissions: {},
        };
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nationName}§a」を作成しました！`);
    });
}

// 国管理
function manageNation(player, nationId) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const isLeader = nation.leader === player.name;
    if (!isLeader) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}のリーダーではありません。`);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}管理§r: §1${nation.name}`)
        .body('§4>>>')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§4メンバーを招待', 'textures/ui/normalicon1.png')
        .button(`§0${world.getDynamicProperty('WorldgroupName')}の情報`, 'textures/ui/normalicon1.png')
        .button('§1メンバー権限設定', 'textures/ui/normalicon1.png')
        .button(`§2${world.getDynamicProperty('WorldgroupName')}名を変更`, 'textures/ui/normalicon1.png')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を解散`, 'textures/ui/normalicon1.png')
        .button('§3メンバーシップ設定', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showMainUI(player);
                break;
            case 1:
                inviteMember(player, nationId);
                break;
            case 2:
                showNationInfo(player, nationId);
                break;
            case 3:
                setMemberPermissions(player, nationId);
                break;
            case 4:
                changeNationName(player, nationId);
                break;
            case 5:
                confirmDissolveNation(player, nationId);
                break;
            case 6:
                setMembershipType(player, nationId); // 新しいアクション
                break;
        }
    });
}

// メンバーシップ設定関数
function setMembershipType(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        return;
    }

    const form = new ModalFormData().title(`§1${world.getDynamicProperty('WorldgroupName')}メンバーシップ設定`).dropdown('§fメンバーシップ', ['オープン', '招待制'], nation.membership === 'open' ? 0 : 1);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            manageNation(player, nationId);
            return;
        }
        const [membershipType] = response.formValues;
        const newMembership = membershipType === 0 ? 'open' : 'invite';
        if (nation.membership === newMembership) {
            player.sendMessage(`§r[§b社会システム§r] §cメンバーシップはすでに${newMembership === 'open' ? 'オープン' : '招待制'}です。`);
            manageNation(player, nationId);
            return;
        }

        nation.membership = newMembership;
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}のメンバーシップを${newMembership === 'open' ? '§eオープン' : '§e招待制'}に設定しました。`);
        manageNation(player, nationId);
    });
}

// 国の情報表示
function showNationInfo(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const memberCount = nation.members.length;
    const memberList = nation.members.join(', ');

    // 全ディメンションのチャンク数を合算
    let totalChunkCount = 0;
    const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
    dimensions.forEach(dimId => {
        const chunkData = getChunkData(dimId);
        totalChunkCount += Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;
    });

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` + `§aリーダー: §c${nation.leader}\n` + `§aメンバー数: §e${memberCount}\n` + `§aメンバー: §f${memberList}\n` + `§aメンバーシップ: §e${nation.membership === 'open' ? 'オープン' : '招待制'}\n` + `§a所有チャンク数: §e${totalChunkCount}`;

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の情報§r: §1${nation.name}`)
        .body(body)
        .button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            manageNation(player, nationId);
            return;
        }
    });
}

// 国名変更
function changeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new ModalFormData().title(`§5${world.getDynamicProperty('WorldgroupName')}名を変更`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            manageNation(player, nationId);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, '_');
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        // 全ディメンションのチャンクデータを更新
        const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
        dimensions.forEach(dimId => {
            const chunkData = getChunkData(dimId);
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    chunkData[chunkKey].nation = newNationId;
                }
            }
            setChunkData(dimId, chunkData);
        });

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
    });
}

// メンバー招待
function inviteMember(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const hasInvitePermission = nation.leader === player.name || nation.permissions?.[player.name]?.canInvite || nation.membership === 'open';
    if (!hasInvitePermission) {
        player.sendMessage('§r[§b社会システム§r] §c招待権限がありません。');
        return;
    }

    const form = new ModalFormData().title('§1メンバーを招待').textField('§fプレイヤー名', '例: Steve');

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            manageNation(player, nationId);
            return;
        }
        const [targetName] = response.formValues;
        const targetPlayer = world.getPlayers().find(p => p.name === targetName);
        if (!targetPlayer) {
            player.sendMessage('§r[§b社会システム§r] §cプレイヤーが見つかりません。');
            return;
        }
        if (targetPlayer.name === player.name) {
            player.sendMessage('§r[§b社会システム§r] §c自分自身を招待できません。');
            return;
        }

        if (nation.members.includes(targetName)) {
            player.sendMessage('§r[§b社会システム§r] §cこのプレイヤーはすでにメンバーです。');
            return;
        }

        nation.invites.push(targetName);
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${targetName}を招待しました。`);
        targetPlayer.sendMessage(`§r[§b社会システム§r] §a${nation.name}から招待されました。`);
    });
}

// 招待確認
function checkInvites(player) {
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        player.sendMessage('§r[§b社会システム§r] §cこのディメンションでは社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const invites = [];
    for (const nationId in nationData) {
        if (nationData[nationId].invites.includes(player.name) || nationData[nationId].membership === 'open') {
            invites.push(nationId);
        }
    }

    if (invites.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c招待がありません。');
        return;
    }

    const form = new ActionFormData().title('§5招待リスト').body(`§fどの${world.getDynamicProperty('WorldgroupName')}に参加しますか？`);
    invites.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        const selectedNation = invites[response.selection];
        const nation = nationData[selectedNation];
        if (!nation) return;

        if (nation.members.includes(player.name)) {
            player.sendMessage(`§r[§b社会システム§r] §cすでにこの${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
            return;
        }

        if (!isMultipleNationsAllowed()) {
            const playerNations = getPlayerNations(player);
            if (playerNations.length > 0) {
                player.sendMessage(`§r[§b社会システム§r] §c複数の${world.getDynamicProperty('WorldgroupName')}に所属することはできません。`);
                return;
            }
        }

        nation.members.push(player.name);
        if (nation.invites.includes(player.name)) {
            nation.invites = nation.invites.filter(name => name !== player.name);
        }
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${nation.name}に参加しました！`);
    });
}

// 国を退出
function leaveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    if (nation.leader === player.name) {
        player.sendMessage(`§r[§b社会システム§r] §cリーダーは${world.getDynamicProperty('WorldgroupName')}を退出できません。解散してください。`);
        return;
    }

    nation.members = nation.members.filter(name => name !== player.name);
    if (nation.members.length === 0) {
        delete nationData[nationId];
    }
    setNationData(nationData);
    player.sendMessage(`§r[§b社会システム§r] §a${nation.name}を退出しました。`);
}

// 国解散確認
function confirmDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}解散の確認`)
        .body(`§c本当に「§e${nation.name}§c」を解散しますか？\n§7この操作は元に戻せません。`)
        .button1('§1キャンセル')
        .button2('§4解散');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            manageNation(player, nationId);
            return;
        }
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            // 全ディメンションのチャンクデータを更新
            const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
            dimensions.forEach(dimId => {
                const chunkData = getChunkData(dimId);
                for (const chunkKey in chunkData) {
                    if (chunkData[chunkKey].nation === nationId) {
                        delete chunkData[chunkKey];
                    }
                }
                setChunkData(dimId, chunkData);
            });

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}を解散しました。`);
        }
    });
}

// メンバー権限設定
function setMemberPermissions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const members = nation.members.filter(name => name !== player.name);

    if (members.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c権限を設定できるメンバーがいません。');
        return;
    }

    const form = new ModalFormData().title('§1メンバー権限設定').dropdown('§fメンバー', members, 0).toggle('§a土地購入権限', false).toggle('§aメンバー招待権限', false);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            manageNation(player, nationId);
            return;
        }
        const [memberIndex, canBuyLand, canInvite] = response.formValues;
        const selectedMember = members[memberIndex];

        if (!nation.permissions) {
            nation.permissions = {};
        }
        if (!nation.permissions[selectedMember]) {
            nation.permissions[selectedMember] = {};
        }
        nation.permissions[selectedMember].canBuyLand = canBuyLand;
        nation.permissions[selectedMember].canInvite = canInvite;

        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${selectedMember}の権限を設定しました。\n§a土地購入: §e${canBuyLand ? '有効' : '無効'}\n§aメンバー招待: §e${canInvite ? '有効' : '無効'}`);
    });
}

// 管理者設定
export function adminSettings(player) {
    const form = new ActionFormData()
        .title('§5管理者設定')
        .body('設定を選択してください')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1システム設定', 'textures/ui/normalicon1.png')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}の管理`, 'textures/ui/normalicon1.png')
        .button('§5公共土地の管理', 'textures/ui/normalicon1.png')
        .button(`§1境界表示管理`, 'textures/ui/normalicon1.png');
    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                showSystemSettingsMenu(player);
                break;
            case 2:
                manageNations(player);
                break;
            case 3:
                managePublicLands(player);
                break;
            case 4:
                manageBoundaryDisplay(player);
                break;
        }
    });
}

function manageBoundaryDisplay(admin) {
    const form = new ActionFormData().title('§1境界表示管理').body('§f表示を切り替えるプレイヤーを選択してください。');

    const onlinePlayers = world.getPlayers();

    // 戻るボタン
    form.button('§l戻る', 'textures/ui/icon_import.png');

    onlinePlayers.forEach(p => {
        const isEnabled = p.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') === true;
        form.button(`§0${p.name}\n§r${isEnabled ? '§1有効' : '§4無効'}`);
    });

    form.show(admin).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(admin);
            return;
        }

        const targetPlayer = onlinePlayers[response.selection - 1];
        if (targetPlayer) {
            toggleSpecificPlayerBoundary(admin, targetPlayer);
        }
    });
}

function toggleSpecificPlayerBoundary(admin, targetPlayer) {
    const isEnabled = targetPlayer.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') === true;

    const form = new MessageFormData()
        .title(`§1${targetPlayer.name} の境界表示`)
        .body(`§f${targetPlayer.name} の境界表示を${isEnabled ? '§c無効' : '§a有効'}にしますか？`)
        .button2(isEnabled ? '§4無効にする' : '§1有効にする')
        .button1('§1キャンセル');

    form.show(admin).then(response => {
        if (response.canceled || response.selection === 0) {
            manageBoundaryDisplay(admin); // キャンセル時はリストに戻る
            return;
        }

        if (response.selection === 1) {
            const newState = !isEnabled;
            targetPlayer.setDynamicProperty('PLAYER_BOUNDARY_ENABLED', newState);
            admin.sendMessage(`§r[§b社会システム§r] §a${targetPlayer.name}の境界表示を${newState ? '有効' : '無効'}にしました。`);
        }
        // 操作後、再度リスト表示に戻る
        manageBoundaryDisplay(admin);
    });
}

// システム設定メニュー
function showSystemSettingsMenu(player) {
    const isOverworldEnabled = isSystemEnabledForDimension('minecraft:overworld');
    const isNetherEnabled = isSystemEnabledForDimension('minecraft:nether');
    const isEndEnabled = isSystemEnabledForDimension('minecraft:the_end');

    const form = new ActionFormData()
        .title('§1社会システム設定')
        .body('§fどの設定を変更しますか？')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§4チャンク価格設定', 'textures/ui/normalicon1.png')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}作成コスト設定`, 'textures/ui/normalicon1.png')
        .button(`§9オーバーワールド社会システム\n §r(${isOverworldEnabled ? '§1有効' : '§4無効'}§r)`, 'textures/ui/normalicon1.png')
        .button(`§9ネザー社会システム\n §r(${isNetherEnabled ? '§1有効' : '§4無効'}§r)`, 'textures/ui/normalicon1.png')
        .button(`§9エンド社会システム\n §r(${isEndEnabled ? '§1有効' : '§4無効'}§r)`, 'textures/ui/normalicon1.png')
        .button(`§2複数${world.getDynamicProperty('WorldgroupName')}所属の許可`, 'textures/ui/normalicon1.png')
        .button('§1アイテム/ブロック\n§8未所持の土地での利用を許可/禁止設定', 'textures/ui/normalicon1.png')
        .button('§9未購入の土地の表示名', 'textures/ui/normalicon1.png')
        .button('§5未購入の土地での操作\n§1許可§r/§4禁止', 'textures/ui/normalicon1.png')
        .button('§2拠点種別の名称変更', 'textures/ui/normalicon1.png')
        .button(`§1${world.getDynamicProperty('WorldgroupName')}名タイトル\n§5表示§r/§1非表示`, 'textures/ui/normalicon1.png')
        .button('§4最大選択チャンク数設定', 'textures/ui/normalicon1.png')
        .button('§5チャンク売却価格設定', 'textures/ui/normalicon1.png')
        .button('§5未購入の土地でのインタラクト\n§1許可§r/§4禁止', 'textures/ui/normalicon1.png')
        .button('§5OP操作\n§1許可§r/§4禁止', 'textures/ui/normalicon1.png');
    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                setChunkPrice(player);
                break;
            case 2:
                setNationCreationCost(player);
                break;
            case 3:
                toggleDimensionSystemEnabled(player, 'minecraft:overworld', SYSTEM_ENABLED_OVERWORLD);
                break;
            case 4:
                toggleDimensionSystemEnabled(player, 'minecraft:nether', SYSTEM_ENABLED_NETHER);
                break;
            case 5:
                toggleDimensionSystemEnabled(player, 'minecraft:the_end', SYSTEM_ENABLED_END);
                break;
            case 6:
                toggleMultipleNations(player);
                break;
            case 7:
                AllowedItemBlockMenu(player);
                break;
            case 8:
                var form = new ModalFormData().title('§1未購入土地の表示名').textField('§5>>>表示名', `${world.getDynamicProperty('WorldspaceNAME')}`);

                form.show(player).then(response => {
                    if (response.canceled) return;

                    if (!response.formValues[0]) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。表示名を入力してください');
                        return;
                    }

                    world.setDynamicProperty('WorldspaceNAME', response.formValues[0]);
                    player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を表示名として設定しました`);
                    showSystemSettingsMenu(player);
                });
                break;
            case 9:
                toggleUnownedLandInteraction(player);
                break;
            case 10:
                var form = new ModalFormData().title('§1拠点種別の名称').textField('§5>>>名称', `${world.getDynamicProperty('WorldgroupName')}`);

                form.show(player).then(response => {
                    if (response.canceled) return;

                    if (!response.formValues[0]) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。名称を入力してください');
                        return;
                    }

                    world.setDynamicProperty('WorldgroupName', response.formValues[0]);
                    player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を拠点種別の名称として設定しました`);
                    showSystemSettingsMenu(player);
                });
                break;
            case 11:
                var form = new MessageFormData()
                    .title('§1タイトル表示/非表示')
                    .body(`§c${world.getDynamicProperty('WorldgroupName')}名タイトル ${world.getDynamicProperty('WorldTitle') ? '§c非表示' : '§a表示'}にしますか？`)
                    .button1('§1キャンセル')
                    .button2(world.getDynamicProperty('WorldTitle') ? '§4非表示にする' : '§1表示にする');

                form.show(player).then(response => {
                    if (response.canceled || response.selection === 0) {
                        showSystemSettingsMenu(player);
                        return;
                    }
                    if (response.selection === 1) {
                        world.setDynamicProperty('WorldTitle', !world.getDynamicProperty('WorldTitle'));
                        player.sendMessage(`§r[§b社会システム§r] §aタイトルを§e${!world.getDynamicProperty('WorldTitle') ? '非表示' : '表示'}§aにしました。`);
                    }
                    showSystemSettingsMenu(player);
                });
                break;
            case 12:
                setMaxPurchaseChunks(player);
                break;
            case 13:
                setChunkSellPrice(player);
                break;
            case 14:
                toggleUnownedLandTouchInteract(player);
                break;
            case 15:
                toggleOpInteraction(player);
                break;
        }
    });
}

// 各ディメンションの社会システム有効/無効切り替え関数
function toggleDimensionSystemEnabled(player, dimensionName, propertyKey) {
    const isEnabled = world.getDynamicProperty(propertyKey) === true;
    const displayName = dimensionName.replace('minecraft:', '').replace('_', ' ').toUpperCase(); // 表示名を整形

    const form = new MessageFormData()
        .title(`§1${displayName} 社会システムの有効/無効`)
        .body(`§f${displayName} の社会システムを${isEnabled ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(isEnabled ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(propertyKey, !isEnabled);
            player.sendMessage(`§r[§b社会システム§r] §a${displayName} の社会システムを§e${!isEnabled ? '有効' : '無効'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

function toggleOpInteraction(player) {
    const isOpInteractionAllowed = world.getDynamicProperty('OP_INTERACTION_ALLOWED') === true;
    const form = new MessageFormData()
        .title('§1OP操作の許可/禁止')
        .body(`§fOPの無制限操作を${isOpInteractionAllowed ? '§c禁止' : '§a許可'}しますか？\n§eすべてのインタラクト、破壊、設置、アイテム使用が対象です。`)
        .button1('§1キャンセル')
        .button2(isOpInteractionAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty('OP_INTERACTION_ALLOWED', !isOpInteractionAllowed);
            player.sendMessage(`§r[§b社会システム§r] §aOP操作を§e${!isOpInteractionAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

function AllowedItemBlockMenu(player) {
    var form = new ActionFormData().title('§1社会システム設定').body('§fどの設定を変更しますか？').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1アイテム').button('§4ブロックインタラクト');
    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                AllowedItem(player);
                break;
            case 2:
                AllowedBlock(player);
                break;
        }
    });
}

function AllowedBlock(player) {
    var form = new ActionFormData().title('§1社会システム設定').body('§fどの設定を変更しますか？').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1禁止ブロックを追加').button('§4禁止ブロックを削除');
    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            AllowedItemBlockMenu(player);
            return;
        }
        switch (response.selection) {
            case 1:
                var form = new ModalFormData().title('§1禁止ブロックを追加').textField('§5>>>追加するブロックID\n§r(例: addblock:atm)', '');

                form.show(player).then(response => {
                    if (response.canceled) {
                        AllowedBlock(player);
                        return;
                    }

                    const blockid = response.formValues[0].trim();
                    if (!blockid) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。ブロックIDを入力してください');
                        AllowedBlock(player);
                        return;
                    }

                    let DANGEROUS_Block = JSON.parse(world.getDynamicProperty('DANGEROUS_Block') ?? '[]');

                    if (DANGEROUS_Block.includes(blockid)) {
                        player.sendMessage(`§r[§b社会システム§r] §e${blockid} はすでに登録されています`);
                        AllowedBlock(player);
                        return;
                    }

                    DANGEROUS_Block.push(blockid);
                    world.setDynamicProperty('DANGEROUS_Block', JSON.stringify(DANGEROUS_Block));
                    player.sendMessage(`§r[§b社会システム§r] §a${blockid} を禁止ブロックとして追加しました`);
                    AllowedBlock(player);
                });
                break;
            case 2:
                const DANGEROUS_Block = JSON.parse(world.getDynamicProperty('DANGEROUS_Block') ?? '[]');

                if (DANGEROUS_Block.length === 0) {
                    player.sendMessage('§r[§b社会システム§r] §c現在、削除できるブロックはありません');
                    break;
                }

                var form = new ActionFormData().title('§4禁止ブロックを削除').body('§5>>>削除したいブロックを選んでください');

                // ボタンをブロックIDごとに追加
                for (const id of DANGEROUS_Block) {
                    form.button(id);
                }

                form.show(player).then(response => {
                    if (response.canceled) {
                        AllowedBlock(player);
                        return;
                    }
                    const selectedIndex = response.selection;
                    const removedBlock = DANGEROUS_Block[selectedIndex];
                    DANGEROUS_Block.splice(selectedIndex, 1);

                    world.setDynamicProperty('DANGEROUS_Block', JSON.stringify(DANGEROUS_Block));
                    player.sendMessage(`§r[§b社会システム§r] §a${removedBlock} をリストから削除しました`);
                    AllowedBlock(player);
                });
                break;
        }
    });
}

function AllowedItem(player) {
    var form = new ActionFormData().title('§1社会システム設定').body('§fどの設定を変更しますか？').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1許可アイテムを追加').button('§4許可アイテムを削除');
    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            AllowedItemBlockMenu(player);
            return;
        }
        switch (response.selection) {
            case 1:
                var form = new ModalFormData().title('§1許可アイテムを追加').textField('§5>>>追加するアイテムID\n§r(例: additem:haruphone1)', '');

                form.show(player).then(response => {
                    if (response.canceled) {
                        AllowedItem(player);
                        return;
                    }

                    const itemId = response.formValues[0].trim();
                    if (!itemId) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。アイテムIDを入力してください');
                        AllowedItem(player);
                        return;
                    }

                    let DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                    if (DANGEROUS_ITEMS.includes(itemId)) {
                        player.sendMessage(`§r[§b社会システム§r] §e${itemId} はすでに登録されています`);
                        AllowedItem(player);
                        return;
                    }

                    DANGEROUS_ITEMS.push(itemId);
                    world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                    player.sendMessage(`§r[§b社会システム§r] §a${itemId} を許可アイテムとして追加しました`);
                    AllowedItem(player);
                });
                break;
            case 2:
                const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                if (DANGEROUS_ITEMS.length === 0) {
                    player.sendMessage('§r[§b社会システム§r] §c現在、削除できるアイテムはありません');
                    break;
                }

                var form = new ActionFormData().title('§4許可アイテムを削除').body('§5>>>削除したいアイテムを選んでください');

                // ボタンをアイテムIDごとに追加
                for (const id of DANGEROUS_ITEMS) {
                    form.button(id);
                }

                form.show(player).then(response => {
                    if (response.canceled) {
                        AllowedItem(player);
                        return;
                    }
                    const selectedIndex = response.selection;
                    const removedItem = DANGEROUS_ITEMS[selectedIndex];
                    DANGEROUS_ITEMS.splice(selectedIndex, 1);

                    world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                    player.sendMessage(`§r[§b社会システム§r] §a${removedItem} をリストから削除しました`);
                    AllowedItem(player);
                });
                break;
        }
    });
}

function toggleUnownedLandTouchInteract(player) {
    const isAllowed = world.getDynamicProperty(UNOWNED_LAND_INTERACT) === true;
    const form = new MessageFormData()
        .title('§1未購入の土地でのブロックインタラクト')
        .body(`§f未購入の土地でのブロックインタラクトを${isAllowed ? '§c禁止' : '§a許可'}しますか？\n§e禁止ブロックを追加する必要があります`)
        .button1('§1キャンセル')
        .button2(isAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(UNOWNED_LAND_INTERACT, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a未購入の土地でのブロックインタラクトを§e${!isAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 個人境界表示トグル
function togglePlayerBoundary(player) {
    const isEnabled = player.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') === true;
    player.setDynamicProperty('PLAYER_BOUNDARY_ENABLED', !isEnabled);
    player.sendMessage(`§r[§b社会システム§r] §a個人境界表示を§e${!isEnabled ? '有効' : '無効'}§aにしました。`);
    if (!isEnabled) {
        updatePlayerBoundaries(player);
    }
}

// プレイヤーごとの境界更新
function updatePlayerBoundaries(player) {
    if (player.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') !== true) return;
    const currentChunk = getChunkCoords(player.location);
    const dimensionId = player.dimension.id;
    const chunkData = getChunkData(dimensionId);
    const publicLandData = getPublicLandData(dimensionId);

    // 指定された座標の土地情報を取得するヘルパー関数
    function getLandInfo(x, z) {
        const key = `${x}:${z}`;
        if (publicLandData[key]) {
            return { type: 'public', id: publicLandData[key].name };
        }
        if (chunkData[key]?.nation) {
            return { type: 'nation', id: chunkData[key].nation };
        }
        return { type: 'unowned', id: null };
    }

    // 表示範囲（BOUNDARY_VIEW_DISTANCE）内のチャンクをループ
    for (let x = currentChunk.x - BOUNDARY_VIEW_DISTANCE; x <= currentChunk.x + BOUNDARY_VIEW_DISTANCE; x++) {
        for (let z = currentChunk.z - BOUNDARY_VIEW_DISTANCE; z <= currentChunk.z + BOUNDARY_VIEW_DISTANCE; z++) {
            const currentLand = getLandInfo(x, z);

            // 現在のチャンクが未所有地なら境界は描画しない
            if (currentLand.type === 'unowned') continue;

            // 隣接する4方向のチャンク情報を取得
            const neighborNorth = getLandInfo(x, z - 1);
            const neighborSouth = getLandInfo(x, z + 1);
            const neighborWest = getLandInfo(x - 1, z);
            const neighborEast = getLandInfo(x + 1, z);

            // 隣接チャンクが同じ種類でなければ、その辺に境界を描画する
            const boundaries = {
                north: currentLand.type !== neighborNorth.type || currentLand.id !== neighborNorth.id,
                south: currentLand.type !== neighborSouth.type || currentLand.id !== neighborSouth.id,
                west: currentLand.type !== neighborWest.type || currentLand.id !== neighborWest.id,
                east: currentLand.type !== neighborEast.type || currentLand.id !== neighborEast.id,
            };

            // 描画すべき境界が1つでもあればパーティクル配置関数を呼び出す
            if (boundaries.north || boundaries.south || boundaries.west || boundaries.east) {
                const particle = currentLand.type === 'nation' ? 'minecraft:balloon_gas_particle' : 'minecraft:villager_happy';
                placeBoundaryParticles(player, x, z, particle, boundaries);
            }
        }
    }
}

// パーティクルでモヤモヤした壁を配置
function placeBoundaryParticles(player, chunkX, chunkZ, particle, boundaries) {
    const dimension = player.dimension;
    const chunkMinX = chunkX * 16;
    const chunkMaxX = chunkMinX + 15;
    const chunkMinZ = chunkZ * 16;
    const chunkMaxZ = chunkMinZ + 15;
    const yBase = Math.floor(player.location.y) - 1;

    // チャンクがロードされているか簡易チェック
    let isChunkLoaded = true;
    try {
        dimension.getBlock({ x: chunkMinX + 8, y: yBase, z: chunkMinZ + 8 });
    } catch (e) {
        isChunkLoaded = false;
    }

    if (!isChunkLoaded) {
        // ロードされていない場合はログを残してスキップ
        return;
    }

    const commands = [];

    // 指定された辺に沿ってパーティクル生成コマンドを作成
    for (let y = yBase; y < yBase + BOUNDARY_HEIGHT; y += BOUNDARY_PARTICLE_DENSITY) {
        if (boundaries.north) {
            for (let x = chunkMinX; x <= chunkMaxX; x += BOUNDARY_PARTICLE_DENSITY) {
                commands.push(`particle ${particle} ${x} ${y} ${chunkMinZ}`);
            }
        }
        if (boundaries.south) {
            for (let x = chunkMinX; x <= chunkMaxX; x += BOUNDARY_PARTICLE_DENSITY) {
                commands.push(`particle ${particle} ${x} ${y} ${chunkMaxZ + 1}`);
            }
        }
        if (boundaries.west) {
            for (let z = chunkMinZ; z <= chunkMaxZ; z += BOUNDARY_PARTICLE_DENSITY) {
                commands.push(`particle ${particle} ${chunkMinX} ${y} ${z}`);
            }
        }
        if (boundaries.east) {
            for (let z = chunkMinZ; z <= chunkMaxZ; z += BOUNDARY_PARTICLE_DENSITY) {
                commands.push(`particle ${particle} ${chunkMaxX + 1} ${y} ${z}`);
            }
        }
    }

    if (commands.length === 0) return;

    // コマンドを非同期で実行
    system.runTimeout(() => {
        for (const command of commands) {
            try {
                dimension.runCommand(command);
            } catch (e) {}
        }
    }, 1);
}

// 定期的な境界更新
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const dimensionId = player.dimension.id;
        if (!isSystemEnabledForDimension(dimensionId)) return; // ディメンションのシステムが有効でない場合はスキップ

        if (player.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') === true) {
            updatePlayerBoundaries(player);
        }
    }
}, 8);

// プレイヤー参加時の初期化
world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    // チャンクロードを確実にするため、遅延を長めに設定（例: 20ティック）
    system.runTimeout(() => {
        try {
            const chunk = getChunkCoords(player.location);
            const dimensionId = player.dimension.id;
            const chunkKey = `${chunk.x}:${chunk.z}`;
            const chunkData = getChunkData(dimensionId);
            const publicLandData = getPublicLandData(dimensionId);

            let locationId = null;
            if (publicLandData[chunkKey]) {
                const landName = publicLandData[chunkKey].name.trim();
                locationId = `public:${landName}`;
            } else if (chunkData[chunkKey]?.nation) {
                locationId = `nation:${chunkData[chunkKey].nation}`;
            }
            lastPlayerNation.set(player.id, locationId);

            // スポーン時にPLAYER_BOUNDARY_ENABLEDを無効に設定
            player.setDynamicProperty('PLAYER_BOUNDARY_ENABLED', false);
        } catch (e) {
            console.warn(`Failed to initialize nation data for player ${player.name}:`, e);
        }
    }, 20); // 遅延を20ティックに増やす
});

// プレイヤー退出時のクリーンアップ（任意）
world.afterEvents.playerLeave.subscribe(event => {
    placedBoundaryChunks.clear(); // 必要に応じてクリア
});

export function setupBoundaryDisplay() {
    system.runTimeout(() => {
        for (const player of world.getPlayers()) {
            if (player.getDynamicProperty('PLAYER_BOUNDARY_ENABLED') === undefined) {
                player.setDynamicProperty('PLAYER_BOUNDARY_ENABLED', false);
            }
        }
    }, 20); // サーバー起動後の遅延（チャンクロードを待つ）
}

function setMaxPurchaseChunks(player) {
    const currentMax = world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) || 10;
    const form = new ModalFormData().title('§1最大選択チャンク数設定').textField('§f最大選択チャンク数', currentMax.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [maxChunks] = response.formValues;
        const parsedMaxChunks = parseInt(maxChunks);

        if (isNaN(parsedMaxChunks) || parsedMaxChunks < 1) {
            player.sendMessage('§r[§b社会システム§r] §c有効なチャンク数を入力してください（1以上）。');
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY, parsedMaxChunks);
        player.sendMessage(`§r[§b社会システム§r] §a最大選択チャンク数を§e${parsedMaxChunks}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 未購入の土地での操作許可/禁止切り替え（新しい関数）
function toggleUnownedLandInteraction(player) {
    const isAllowed = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
    const form = new MessageFormData()
        .title('§1未購入の土地での操作')
        .body(`§f未購入の土地でのブロック破壊/設置を${isAllowed ? '§c禁止' : '§a許可'}しますか？`)
        .button1('§1キャンセル')
        .button2(isAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(UNOWNED_LAND_INTERACTION, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a未購入の土地でのブロック破壊/設置を§e${!isAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// チャンク価格設定
function setChunkPrice(player) {
    const currentPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);
    const form = new ModalFormData().title('§1チャンク価格設定').textField('§f新しいチャンク価格', currentPrice.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [chunkPrice] = response.formValues;
        const parsedChunkPrice = parseInt(chunkPrice);

        if (isNaN(parsedChunkPrice) || parsedChunkPrice < 0) {
            player.sendMessage('§r[§b社会システム§r] §c有効なチャンク価格を入力してください。');
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, parsedChunkPrice);
        player.sendMessage(`§r[§b社会システム§r] §aチャンク価格を§e${parsedChunkPrice}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 国作成コスト設定
function setNationCreationCost(player) {
    const currentCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const form = new ModalFormData().title(`§1${world.getDynamicProperty('WorldgroupName')}作成コスト設定`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}作成コスト`, currentCost.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [creationCost] = response.formValues;
        const parsedCreationCost = parseInt(creationCost);

        if (isNaN(parsedCreationCost) || parsedCreationCost < 0) {
            player.sendMessage(`§r[§b社会システム§r] §c有効な${world.getDynamicProperty('WorldgroupName')}作成コストを入力してください。`);
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, parsedCreationCost);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}作成コストを§e${parsedCreationCost}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 複数国所属の許可/禁止切り替え
function toggleMultipleNations(player) {
    const isAllowed = isMultipleNationsAllowed();
    const form = new MessageFormData()
        .title(`§1複数${world.getDynamicProperty('WorldgroupName')}所属の許可`)
        .body(`§f複数${world.getDynamicProperty('WorldgroupName')}所属を${isAllowed ? '§c禁止' : '§a許可'}しますか？`)
        .button1('§1キャンセル')
        .button2(isAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a複数${world.getDynamicProperty('WorldgroupName')}所属を§e${!isAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 国の管理（管理者用）
function manageNations(player) {
    const nationData = getNationData();
    const nationIds = Object.keys(nationData);

    if (nationIds.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §c現在、存在する${world.getDynamicProperty('WorldgroupName')}はありません。`);
        adminSettings(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の管理`)
        .body(`§f管理する${world.getDynamicProperty('WorldgroupName')}を選択してください。`)
        .button(`§l戻る`, 'textures/ui/icon_import.png');

    nationIds.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        const selectedNationId = nationIds[response.selection - 1];
        showNationAdminOptions(player, selectedNationId);
    });
}

// 国の管理オプション（管理者用）
function showNationAdminOptions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const memberCount = nation.members.length;
    // 全ディメンションのチャンク数を合算
    let totalChunkCount = 0;
    const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
    dimensions.forEach(dimId => {
        const chunkData = getChunkData(dimId);
        totalChunkCount += Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;
    });

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` + `§aリーダー: §c${nation.leader}\n` + `§aメンバー数: §e${memberCount}\n` + `§aメンバー: §f${nation.members.join(', ')}\n` + `§aメンバーシップ: §e${nation.membership === 'open' ? 'オープン' : '招待制'}\n` + `§a所有チャンク数: §e${totalChunkCount}`;

    const form = new ActionFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}の管理: ${nation.name}`)
        .body(body)
        .button('§1メンバー管理')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}名変更`)
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を強制削除`)
        .button('§3メンバーシップ設定') // 新しいボタン
        .button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 4) {
            manageNations(player);
            return;
        }
        switch (response.selection) {
            case 0:
                manageNationMembers(player, nationId);
                break;
            case 1:
                adminChangeNationName(player, nationId);
                break;
            case 2:
                confirmForceDissolveNation(player, nationId);
                break;
            case 3:
                adminSetMembershipType(player, nationId);
                break;
        }
    });
}

// メンバーシップ設定（管理者用）
function adminSetMembershipType(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ModalFormData().title(`§1${world.getDynamicProperty('WorldgroupName')}メンバーシップ設定`).dropdown('§fメンバーシップ', ['オープン', '招待制'], nation.membership === 'open' ? 0 : 1);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const [membershipType] = response.formValues;
        const newMembership = membershipType === 0 ? 'open' : 'invite';
        if (nation.membership === newMembership) {
            player.sendMessage(`§r[§b社会システム§r] §cメンバーシップはすでに${newMembership === 'open' ? 'オープン' : '招待制'}です。`);
            showNationAdminOptions(player, nationId);
            return;
        }

        nation.membership = newMembership;
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}のメンバーシップを${newMembership === 'open' ? '§eオープン' : '§e招待制'}に設定しました。`);
        showNationAdminOptions(player, nationId);
    });
}

// 国のメンバー管理
function manageNationMembers(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }
    const members = nation.members;

    if (members.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}にメンバーがいません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ActionFormData().title(`§5メンバー管理§r: §1${nation.name}`).body('§fどのメンバーを管理しますか？').button(`§l戻る`, 'textures/ui/icon_import.png');

    members.forEach(member => {
        form.button(`§1${member}${member === nation.leader ? ' (§cリーダー§1)' : ''}`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const selectedMember = members[response.selection - 1];
        showMemberOptions(player, nationId, selectedMember);
    });
}

// メンバーオプション
function showMemberOptions(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNationMembers(player, nationId);
        return;
    }
    const isLeader = nation.leader === memberName;

    const form = new ActionFormData().title(`§1メンバー管理: ${memberName}`);
    if (isLeader) {
        form.body(`§f${memberName}の操作を選択してください。`);
    } else {
        form.body(`§f${memberName}の操作を選択してください。\n§a土地購入権限: §e${nation.permissions?.[memberName]?.canBuyLand ? 'あり' : 'なし'}\n§aメンバー招待権限: §e${nation.permissions?.[memberName]?.canInvite ? 'あり' : 'なし'}`);
    }

    if (!isLeader) form.button('§4リーダーに設定');
    form.button('§4土地購入権限切り替え');
    form.button('§4メンバー招待権限切り替え');
    form.button('§4メンバー除外');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) {
            manageNationMembers(player, nationId);
            return;
        }

        const backButtonIndex = isLeader ? 3 : 4;
        if (response.selection === backButtonIndex) {
            manageNationMembers(player, nationId);
            return;
        }

        if (isLeader) {
            switch (response.selection) {
                case 0:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 1:
                    toggleInvitePermission(player, nationId, memberName);
                    break;
                case 2:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        } else {
            switch (response.selection) {
                case 0:
                    setNationLeader(player, nationId, memberName);
                    break;
                case 1:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 2:
                    toggleInvitePermission(player, nationId, memberName);
                    break;
                case 3:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        }
    });
}

function toggleInvitePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canInvite || false;

    const form = new MessageFormData()
        .title('§1メンバー招待権限')
        .body(`§f${memberName}のメンバー招待権限を${currentPermission ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(currentPermission ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canInvite = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}のメンバー招待権限を${!currentPermission ? '§e有効' : '§e無効'}にしました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// リーダー設定
function setNationLeader(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData().title('§4リーダー設定').body(`§f${memberName}を${nation.name}のリーダーに設定しますか？`).button1('§1キャンセル').button2('§4設定');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.leader = memberName;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}のリーダーに設定しました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// 土地購入権限切り替え
function toggleLandPurchasePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canBuyLand || false;

    const form = new MessageFormData()
        .title('§1土地購入権限')
        .body(`§f${memberName}の土地購入権限を${currentPermission ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(currentPermission ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canBuyLand = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}の土地購入権限を${!currentPermission ? '§e有効' : '§e無効'}にしました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// メンバー除外確認
function confirmRemoveMember(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    if (nation.leader === memberName) {
        player.sendMessage(`§r[§b社会システム§r] §cリーダーは${world.getDynamicProperty('WorldgroupName')}から除外できません。解散してください。`);
        showMemberOptions(player, nationId, memberName);
        return;
    }

    const form = new MessageFormData().title('§4メンバー除外').body(`§c${memberName}を${nation.name}から除外しますか？`).button1('§1キャンセル').button2('§4除外');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.members = nation.members.filter(name => name !== memberName);
            if (nation.members.length === 0) {
                delete nationData[nationId];
            }
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}から除外しました。`);
            showNationAdminOptions(player, nationId);
        }
    });
}

// 国名変更（管理者用）
function adminChangeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ModalFormData().title(`§4${world.getDynamicProperty('WorldgroupName')}名変更`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            showNationAdminOptions(player, nationId);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, '_');
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            showNationAdminOptions(player, nationId);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        // 全ディメンションのチャンクデータを更新
        const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
        dimensions.forEach(dimId => {
            const chunkData = getChunkData(dimId);
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    chunkData[chunkKey].nation = newNationId;
                }
            }
            setChunkData(dimId, chunkData);
        });

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
        showNationAdminOptions(player, nationId);
    });
}

// 国強制削除確認
function confirmForceDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}強制削除`)
        .body(`§c本当に「§e${nation.name}§c」を強制削除しますか？\n§7この操作は元に戻せません。`)
        .button1('§1キャンセル')
        .button2('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            // 全ディメンションのチャンクデータを更新
            const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
            dimensions.forEach(dimId => {
                const chunkData = getChunkData(dimId);
                for (const chunkKey in chunkData) {
                    if (chunkData[chunkKey].nation === nationId) {
                        delete chunkData[chunkKey];
                    }
                }
                setChunkData(dimId, chunkData);
            });

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nation.name}§a」を強制削除しました。`);
            manageNations(player);
        }
    });
}

//公共土地関連>>>
// 公共土地管理メニュー
function managePublicLands(player) {
    const form = new ActionFormData().title('§1公共土地の管理').body('§f操作を選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1公共土地を追加/拡大').button('§4公共土地を管理');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                addPublicLand(player);
                break;
            case 2:
                // 全ディメンションの公共土地データを合算してチェック
                let totalPublicLandKeys = 0;
                const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];
                dimensions.forEach(dimId => {
                    const publicLandData = getPublicLandData(dimId);
                    totalPublicLandKeys += Object.keys(publicLandData).length;
                });

                if (totalPublicLandKeys === 0) {
                    player.sendMessage('§r[§b社会システム§r] §c現在、公共土地はありません。');
                    managePublicLands(player);
                    return;
                }
                showPublicLandList(player);
                break;
        }
    });
}

// 公共土地追加
// 公共土地追加（addPublicLand関数を全面改修）
// 公共土地追加（addPublicLand関数を修正）
function addPublicLand(player) {
    const form = new ActionFormData().title('§1公共土地追加方法').body('§f追加方法を選択してください。').button('§4現在地のチャンクを追加').button('§4範囲を選択して追加').button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 2) {
            managePublicLands(player);
            return;
        }
        if (response.selection === 0) {
            addSinglePublicLand(player);
        } else if (response.selection === 1) {
            addMultiplePublicLand(player);
        }
    });
}

function addSinglePublicLand(player) {
    const chunk = getChunkCoords(player.location);
    const dimensionId = player.dimension.id;
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const publicLandData = getPublicLandData(dimensionId);
    const chunkData = getChunkData(dimensionId);

    if (publicLandData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに公共土地です。');
        return;
    }
    if (chunkData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに別の国が所有しています。');
        return;
    }

    const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];
    if (publicLandNames.length === 0) {
        const form = new ModalFormData().title('§1公共土地を追加').textField('§f新しい公共土地の名前', `公共土地 (${chunk.x}, ${chunk.z})`);

        form.show(player).then(response => {
            if (response.canceled || !response.formValues) {
                managePublicLands(player);
                return;
            }
            const [landName] = response.formValues;
            if (!landName) {
                player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                managePublicLands(player);
                return;
            }

            publicLandData[chunkKey] = { name: landName };
            setPublicLandData(dimensionId, publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」を追加しました。`);
            managePublicLands(player);
        });
    } else {
        const form = new ActionFormData().title('§1公共土地を追加').body(`§fチャンク (§e${chunk.x}, ${chunk.z}§f)\nどの公共土地に追加しますか？\n§7または新しい公共土地を作成します。`).button(`§l戻る`, 'textures/ui/icon_import.png');

        publicLandNames.forEach(name => {
            form.button(`§5${name}`);
        });
        form.button('§1新しい公共土地を作成');

        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) {
                managePublicLands(player);
                return;
            }

            if (response.selection === publicLandNames.length + 1) {
                const newForm = new ModalFormData().title('§1新しい公共土地').textField('§f公共土地の名前', `公共土地 (${chunk.x}, ${chunk.z})`);

                newForm.show(player).then(newResponse => {
                    if (newResponse.canceled || !newResponse.formValues) {
                        managePublicLands(player);
                        return;
                    }
                    const [landName] = newResponse.formValues;
                    if (!landName) {
                        player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                        managePublicLands(player);
                        return;
                    }

                    publicLandData[chunkKey] = { name: landName };
                    setPublicLandData(dimensionId, publicLandData);
                    player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」を追加しました。`);
                    managePublicLands(player);
                });
            } else {
                const selectedName = publicLandNames[response.selection - 1];
                const confirmForm = new MessageFormData().title('§1公共土地の追加確認').body(`§fチャンク (§e${chunk.x}, ${chunk.z}§f)\n公共土地「§e${selectedName}§f」に追加しますか？`).button1('§1キャンセル').button2('§1追加');

                confirmForm.show(player).then(confirmResponse => {
                    if (confirmResponse.canceled || confirmResponse.selection === 0) {
                        managePublicLands(player);
                        return;
                    }
                    if (confirmResponse.selection === 1) {
                        publicLandData[chunkKey] = { name: selectedName };
                        setPublicLandData(dimensionId, publicLandData);
                        player.sendMessage(`§r[§b社会システム§r] §aチャンクを公共土地「§e${selectedName}§a」に追加しました。`);
                        managePublicLands(player);
                    }
                });
            }
        });
    }
}

function addMultiplePublicLand(player) {
    const dimensionId = player.dimension.id;
    const maxChunks = world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) || 10;
    const currentChunk = getChunkCoords(player.location);

    const form = new ModalFormData().title('§1範囲選択で公共土地追加').textField('§f開始X座標', currentChunk.x.toString()).textField('§f開始Z座標', currentChunk.z.toString()).textField('§f終了X座標', currentChunk.x.toString()).textField('§f終了Z座標', currentChunk.z.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            managePublicLands(player);
            return;
        }

        const [startX, startZ, endX, endZ] = response.formValues;
        const parsedStartX = parseInt(startX);
        const parsedStartZ = parseInt(startZ);
        const parsedEndX = parseInt(endX);
        const parsedEndZ = parseInt(endZ);

        if (isNaN(parsedStartX) || isNaN(parsedStartZ) || isNaN(parsedEndX) || isNaN(parsedEndZ)) {
            player.sendMessage('§r[§b社会システム§r] §c有効な座標を入力してください。');
            managePublicLands(player);
            return;
        }

        const minX = Math.min(parsedStartX, parsedEndX);
        const maxX = Math.max(parsedStartX, parsedEndX);
        const minZ = Math.min(parsedStartZ, parsedEndZ);
        const maxZ = Math.max(parsedStartZ, parsedEndZ);

        const chunkCount = (maxX - minX + 1) * (maxZ - minZ + 1);
        if (chunkCount > maxChunks) {
            player.sendMessage(`§r[§b社会システム§r] §c一度に追加できるチャンク数は${maxChunks}までです。`);
            managePublicLands(player);
            return;
        }

        const chunkData = getChunkData(dimensionId);
        const publicLandData = getPublicLandData(dimensionId);
        const chunksToAdd = [];

        for (let x = minX; x <= maxX; x++) {
            for (let z = minZ; z <= maxZ; z++) {
                const chunkKey = `${x}:${z}`;
                if (chunkData[chunkKey]) {
                    player.sendMessage(`§r[§b社会システム§r] §cチャンク(${x}, ${z})はすでに購入されています。`);
                    managePublicLands(player);
                    return;
                }
                if (publicLandData[chunkKey]) {
                    player.sendMessage(`§r[§b社会システム§r] §cチャンク(${x}, ${z})はすでに公共土地です。`);
                    managePublicLands(player);
                    return;
                }
                chunksToAdd.push({ x, z });
            }
        }

        // 既存の公共土地名を取得
        const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];

        if (publicLandNames.length === 0) {
            // 既存の公共土地がない場合、直接新しい名前を入力
            const newForm = new ModalFormData().title('§1新しい公共土地').textField('§f公共土地の名前', `公共土地 (${minX}, ${minZ})`);

            newForm.show(player).then(newResponse => {
                if (newResponse.canceled || !newResponse.formValues) {
                    managePublicLands(player);
                    return;
                }
                const [landName] = newResponse.formValues;
                if (!landName) {
                    player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                    managePublicLands(player);
                    return;
                }

                confirmAddPublicLand(player, chunksToAdd, chunkCount, minX, minZ, maxX, maxZ, landName, publicLandData, dimensionId);
            });
        } else {
            // 既存の公共土地がある場合、選択または新規作成
            const selectForm = new ActionFormData().title('§1公共土地を選択').body(`§f${chunkCount}チャンクを追加\n§b範囲: (§e${minX}, ${minZ}§b) から (§e${maxX}, ${maxZ}§b)\n§eどの公共土地に追加しますか？\n§7または新しい公共土地を作成します。`).button(`§l戻る`, 'textures/ui/icon_import.png');

            publicLandNames.forEach(name => {
                selectForm.button(`§5${name}`);
            });
            selectForm.button('§1新しい公共土地を作成');

            selectForm.show(player).then(selectResponse => {
                if (selectResponse.canceled || selectResponse.selection === 0) {
                    managePublicLands(player);
                    return;
                }

                if (selectResponse.selection === publicLandNames.length + 1) {
                    // 新しい公共土地を作成
                    const newForm = new ModalFormData().title('§1新しい公共土地').textField('§f公共土地の名前', `公共土地 (${minX}, ${minZ})`);

                    newForm.show(player).then(newResponse => {
                        if (newResponse.canceled || !newResponse.formValues) {
                            managePublicLands(player);
                            return;
                        }
                        const [landName] = newResponse.formValues;
                        if (!landName) {
                            player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                            managePublicLands(player);
                            return;
                        }

                        confirmAddPublicLand(player, chunksToAdd, chunkCount, minX, minZ, maxX, maxZ, landName, publicLandData, dimensionId);
                    });
                } else {
                    // 既存の公共土地を選択
                    const selectedName = publicLandNames[selectResponse.selection - 1];
                    confirmAddPublicLand(player, chunksToAdd, chunkCount, minX, minZ, maxX, maxZ, selectedName, publicLandData, dimensionId);
                }
            });
        }
    });
}

function confirmAddPublicLand(player, chunksToAdd, chunkCount, minX, minZ, maxX, maxZ, landName, publicLandData, dimensionId) {
    const form = new MessageFormData().title('§1複数チャンク追加確認').body(`§f${chunkCount}チャンクを公共土地「§e${landName}§f」として追加しますか？\n§b範囲: (§e${minX}, ${minZ}§b) から (§e${maxX}, ${maxZ}§b)`).button1('§1キャンセル').button2('§1追加');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLands(player);
            return;
        }
        if (response.selection === 1) {
            chunksToAdd.forEach(chunk => {
                publicLandData[`${chunk.x}:${chunk.z}`] = { name: landName };
            });
            setPublicLandData(dimensionId, publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a${chunkCount}チャンクを公共土地「§e${landName}§a」として追加しました。`);
            managePublicLands(player);
        }
    });
}

// 公共土地リスト表示
function showPublicLandList(player) {
    const allPublicLandData = {};
    const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];

    dimensions.forEach(dimId => {
        Object.assign(allPublicLandData, getPublicLandData(dimId));
    });

    // 公共土地の名前を一意に取得（重複を排除）
    const publicLandNames = [...new Set(Object.values(allPublicLandData).map(land => land.name))];

    if (publicLandNames.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c現在、公共土地はありません。');
        managePublicLands(player);
        return;
    }

    const form = new ActionFormData().title('§1公共土地の管理').body('§f管理する公共土地を選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png');

    publicLandNames.forEach(name => {
        // 同じ名前のチャンク数を取得 (全ディメンションで合算)
        let chunkCount = 0;
        dimensions.forEach(dimId => {
            const dimPublicLandData = getPublicLandData(dimId);
            chunkCount += Object.values(dimPublicLandData).filter(land => land.name === name).length;
        });
        form.button(`§5${name}\n§0(${chunkCount}チャンク)`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLands(player);
            return;
        }
        const selectedName = publicLandNames[response.selection - 1];
        managePublicLandByName(player, selectedName);
    });
}

// 名前ベースの公共土地管理（新関数）
function managePublicLandByName(player, landName) {
    const allRelatedChunks = [];
    const dimensions = ['minecraft:overworld', 'minecraft:nether', 'minecraft:the_end'];

    dimensions.forEach(dimId => {
        const publicLandData = getPublicLandData(dimId);
        Object.keys(publicLandData)
            .filter(key => publicLandData[key].name === landName)
            .forEach(key => {
                allRelatedChunks.push({ key: key, dimensionId: dimId });
            });
    });

    const form = new ActionFormData().title(`§1公共土地: ${landName}`).body(`§f名前: §e${landName}\n§fチャンク数: §e${allRelatedChunks.length}\n§f管理する操作を選択してください。`).button('§4名前を変更').button('§4チャンクを削除').button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 2) {
            showPublicLandList(player);
            return;
        }
        switch (response.selection) {
            case 0:
                renamePublicLandByName(player, landName);
                break;
            case 1:
                selectChunkToRemove(player, landName);
                break;
        }
    });
}

// 名前ベースの公共土地名前変更（managePublicLandのrenamePublicLandを改変）
function renamePublicLandByName(player, landName) {
    const publicLandDataByDimension = {
        'minecraft:overworld': getPublicLandData('minecraft:overworld'),
        'minecraft:nether': getPublicLandData('minecraft:nether'),
        'minecraft:the_end': getPublicLandData('minecraft:the_end'),
    };

    let totalRelatedChunks = 0;
    for (const dimId in publicLandDataByDimension) {
        totalRelatedChunks += Object.keys(publicLandDataByDimension[dimId]).filter(key => publicLandDataByDimension[dimId][key].name === landName).length;
    }

    if (totalRelatedChunks === 0) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        return;
    }

    const form = new ModalFormData().title('§1公共土地の名前変更').textField('§f新しい名前', landName);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            managePublicLandByName(player, landName);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage('§r[§b社会システム§r] §c名前を入力してください。');
            managePublicLandByName(player, landName);
            return;
        }

        for (const dimId in publicLandDataByDimension) {
            const dimData = publicLandDataByDimension[dimId];
            for (const key in dimData) {
                if (dimData[key].name === landName) {
                    dimData[key].name = newName;
                }
            }
            setPublicLandData(dimId, dimData);
        }
        player.sendMessage(`§r[§b社会システム§r] §a公共土地の名前を「§e${newName}§a」に変更しました。`);
        managePublicLandByName(player, newName);
    });
}

// チャンク削除選択（新関数）
function selectChunkToRemove(player, landName) {
    const form = new ActionFormData().title(`§1${landName}: チャンク削除`).body(`§f削除方法を選択してください。\n§e${landName}`).button(`§l戻る`, 'textures/ui/icon_import.png').button(`§4現在地のチャンクを削除`).button(`§4範囲を選択して削除`);

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            removeSinglePublicLand(player, landName);
        } else if (response.selection === 2) {
            removeMultiplePublicLand(player, landName);
        }
    });
}

// 単一チャンクの公共土地削除
function removeSinglePublicLand(player, landName) {
    const chunk = getChunkCoords(player.location);
    const dimensionId = player.dimension.id;
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const publicLandData = getPublicLandData(dimensionId);

    if (!publicLandData[chunkKey] || publicLandData[chunkKey].name !== landName) {
        player.sendMessage(`§r[§b社会システム§r] §cこのチャンクは公共土地「§e${landName}§c」に属していません。`);
        managePublicLandByName(player, landName);
        return;
    }

    const form = new MessageFormData().title('§4公共土地の削除').body(`§c公共土地「§e${landName}§c」のチャンク (§e${chunk.x}, ${chunk.z}§c)を削除しますか？\n§7この操作は元に戻せません。`).button1('§1キャンセル').button2('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            delete publicLandData[chunkKey];
            setPublicLandData(dimensionId, publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」からチャンク (§e${chunk.x}, ${chunk.z}§a)を削除しました。`);
            showPublicLandList(player);
        }
    });
}

// 複数チャンクの公共土地削除
function removeMultiplePublicLand(player, landName) {
    const dimensionId = player.dimension.id;
    const maxChunks = world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) || 10;
    const currentChunk = getChunkCoords(player.location);

    const form = new ModalFormData().title(`§1${landName}: 範囲選択で削除`).textField('§f開始X座標', currentChunk.x.toString()).textField('§f開始Z座標', currentChunk.z.toString()).textField('§f終了X座標', currentChunk.x.toString()).textField('§f終了Z座標', currentChunk.z.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            managePublicLandByName(player, landName);
            return;
        }

        const [startX, startZ, endX, endZ] = response.formValues.map(v => parseInt(v));
        if (isNaN(startX) || isNaN(startZ) || isNaN(endX) || isNaN(endZ)) {
            player.sendMessage('§r[§b社会システム§r] §c有効な座標を入力してください。');
            managePublicLandByName(player, landName);
            return;
        }

        const minX = Math.min(startX, endX);
        const maxX = Math.max(startX, endX);
        const minZ = Math.min(startZ, endZ);
        const maxZ = Math.max(startZ, endZ);

        const chunkCount = (maxX - minX + 1) * (maxZ - minZ + 1);
        if (chunkCount > maxChunks) {
            player.sendMessage(`§r[§b社会システム§r] §c一度に削除できるチャンク数は${maxChunks}までです。`);
            managePublicLandByName(player, landName);
            return;
        }

        const publicLandData = getPublicLandData(dimensionId);
        const chunksToRemove = [];

        for (let x = minX; x <= maxX; x++) {
            for (let z = minZ; z <= maxZ; z++) {
                const chunkKey = `${x}:${z}`;
                if (publicLandData[chunkKey] && publicLandData[chunkKey].name === landName) {
                    chunksToRemove.push({ key: chunkKey, x, z });
                }
            }
        }

        if (chunksToRemove.length === 0) {
            player.sendMessage(`§r[§b社会システム§r] §c指定した範囲内に公共土地「§e${landName}§c」のチャンクはありません。`);
            managePublicLandByName(player, landName);
            return;
        }

        const form = new MessageFormData().title('§4複数チャンク削除確認').body(`§c公共土地「§e${landName}§c」の${chunksToRemove.length}チャンクを削除しますか？\n§b範囲: (§e${minX}, ${minZ}§b) から (§e${maxX}, ${maxZ}§b)\n§7この操作は元に戻せません。`).button1('§1キャンセル').button2('§4削除');

        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) {
                managePublicLandByName(player, landName);
                return;
            }
            if (response.selection === 1) {
                chunksToRemove.forEach(chunk => {
                    delete publicLandData[chunk.key];
                });
                setPublicLandData(dimensionId, publicLandData);
                player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」から${chunksToRemove.length}チャンクを削除しました。`);
                showPublicLandList(player);
            }
        });
    });
}

world.beforeEvents.playerBreakBlock.subscribe(event => {
    const player = event.player;
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        return;
    }

    // HARUPhoneOPタグがあり、OP操作が許可されている場合は制限をスキップ
    if (player.hasTag('HARUPhoneOP') && world.getDynamicProperty('OP_INTERACTION_ALLOWED') === true) {
        return;
    }

    const chunk = getChunkCoords(event.block.location);
    const chunkData = getChunkData(dimensionId);
    const publicLandData = getPublicLandData(dimensionId);
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = '';

    if (publicLandData[chunkKey]) {
        return; // 公共土地では破壊を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを破壊できません。';
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        event.cancel = true;
        const now = Date.now();
        const last = lastWarnTime.get(player.id) ?? 0;
        if (now - last >= 3000) {
            player.sendMessage(message);
            lastWarnTime.set(player.id, now);
        }
    }
});

world.afterEvents.playerPlaceBlock.subscribe(event => {
    const player = event.player;
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        return;
    }

    // HARUPhoneOPタグがあり、OP操作が許可されている場合は制限をスキップ
    if (player.hasTag('HARUPhoneOP') && world.getDynamicProperty('OP_INTERACTION_ALLOWED') === true) {
        return;
    }

    const block = event.block;
    const chunk = getChunkCoords(block.location);
    const chunkData = getChunkData(dimensionId);
    const publicLandData = getPublicLandData(dimensionId);
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = '';

    if (publicLandData[chunkKey]) {
        return; // 公共土地では設置を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを設置できません。';
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        try {
            block.dimension.runCommandAsync(`setblock ${block.x} ${block.y} ${block.z} air`);
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        } catch (e) {
            console.warn('設置されたブロックの削除に失敗:', e);
        }
    }
});

// 危険なアイテムの使用制限
const lastWarnTime = new Map(); // プレイヤーごとの警告タイムスタンプ

world.beforeEvents.itemUseOn.subscribe(event => {
    const player = event.source;
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        return;
    }
    const item = event.itemStack;
    if (player.typeId !== 'minecraft:player') return;

    // HARUPhoneOPタグがあり、OP操作が許可されている場合は制限をスキップ
    if (player.hasTag('HARUPhoneOP') && world.getDynamicProperty('OP_INTERACTION_ALLOWED') === true) {
        return;
    }

    const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
    if (!DANGEROUS_ITEMS.includes(item?.typeId)) {
        const chunk = getChunkCoords(player.location);
        const chunkData = getChunkData(dimensionId);
        const publicLandData = getPublicLandData(dimensionId);
        const chunkKey = `${chunk.x}:${chunk.z}`;

        let shouldCancel = false;
        let message = '';

        if (publicLandData[chunkKey]) {
            return; // 公共土地ではアイテム使用を許可
        }
        if (!chunkData[chunkKey]) {
            const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
            if (!allowInteraction) {
                shouldCancel = true;
                message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。このアイテムを使用できません。';
            }
        } else {
            const nationData = getNationData();
            const nation = nationData[chunkData[chunkKey].nation];
            if (!nation || !nation.members.includes(player.name)) {
                shouldCancel = true;
                message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。このアイテムは使用できません。`;
            }
        }

        if (shouldCancel) {
            event.cancel = true;
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        }
    }
});

// プレイヤーの最後の国IDを保持するマップ（チャンクキーではなく国IDを追跡）
const lastPlayerNation = new Map();

// 定期的にプレイヤーの国移動を監視
system.runInterval(() => {
    for (const player of world.getPlayers()) {
        const dimensionId = player.dimension.id;
        if (!isSystemEnabledForDimension(dimensionId)) {
            // ディメンションのシステムが有効でない場合はスキップ
            continue;
        }

        const chunk = getChunkCoords(player.location);
        const chunkKey = `${chunk.x}:${chunk.z}`;
        const chunkData = getChunkData(dimensionId);
        const nationData = getNationData();
        const publicLandData = getPublicLandData(dimensionId);

        // 現在の場所のIDと名前を取得（公共土地、国、未所属の順）
        let currentLocationId = null;
        let currentLocationName = `§r${world.getDynamicProperty('WorldspaceNAME')}`;

        if (publicLandData[chunkKey]) {
            const landName = publicLandData[chunkKey].name.trim(); // 空白をトリムして正規化
            currentLocationId = `public:${landName}`;
            currentLocationName = `§e${landName}`;
        } else if (chunkData[chunkKey]?.nation) {
            const nationId = chunkData[chunkKey].nation;
            currentLocationId = `nation:${nationId}`;
            const nation = nationData[nationId];
            if (nation) {
                currentLocationName = `§a${nation.name}`;
            }
        }

        const lastLocationId = lastPlayerNation.get(player.id);

        // 場所が変更された場合のみタイトルを表示
        if (lastLocationId !== currentLocationId && world.getDynamicProperty('WorldTitle')) {
            try {
                player.runCommandAsync(`title ${player.name} title §a${currentLocationName}§r`);
                lastPlayerNation.set(player.id, currentLocationId);
            } catch (e) {
                console.warn(`Failed to display title for ${player.name}:`, e);
            }
        }
    }
}, 20); // 20ティック（1秒）ごとにチェック

// プレイヤー参加時の初期位置設定修正（playerSpawnイベント全体を置き換え）
world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    // データ読み込みの安定性を高めるため、1ティックの遅延を追加
    system.runTimeout(() => {
        try {
            const chunk = getChunkCoords(player.location);
            const dimensionId = player.dimension.id;
            const chunkKey = `${chunk.x}:${chunk.z}`;
            const chunkData = getChunkData(dimensionId);
            const publicLandData = getPublicLandData(dimensionId);

            let locationId = null;
            if (publicLandData[chunkKey]) {
                const landName = publicLandData[chunkKey].name.trim();
                locationId = `public:${landName}`;
            } else if (chunkData[chunkKey]?.nation) {
                locationId = `nation:${chunkData[chunkKey].nation}`;
            }
            lastPlayerNation.set(player.id, locationId);
        } catch (e) {
            console.warn(`Failed to initialize nation data for player ${player.name}:`, e);
        }
    }, 1);
});

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id !== 'country:c') return;

    // メッセージをパース（nationId とセレクター/プレイヤー名を分割）
    const args = event.message.trim().split(/\s+/);
    const inputNationId = args[0];
    if (!inputNationId) {
        console.log(`[社会システム] エラー: /scriptevent country:c <nationId> <selector|playerName> の形式で指定してください。入力: ${event.message}`);
        return;
    }
    const nationId = inputNationId.toLowerCase().replace(/\s/g, '_');
    const nationData = getNationData();

    const nation = nationData[nationId];
    if (!nation) {
        console.log(`[社会システム] エラー: 指定された国「${inputNationId}」（ID: ${nationId}）が見つかりません。`);
        // セレクターがプレイヤーを含む場合に備えてエラーメッセージを送信
        const players = parseSelector(args[1]);
        players.forEach(player => {
            player.sendMessage(`§r[§b社会システム§r] §c指定された国「§e${inputNationId}§c」（ID: §e${nationId}§c）が見つかりません。`);
        });
        return;
    }

    // セレクターまたはプレイヤー名を解析
    const targetPlayers = parseSelector(args[1]);
    if (targetPlayers.length === 0) {
        console.log(`[社会システム] エラー: セレクター/プレイヤー「${args[1]}」に一致するプレイヤーが見つかりません。`);
        return;
    }

    // 各プレイヤーに対して所属チェック
    targetPlayers.forEach(player => {
        const isMember = nation.members.includes(player.name);
        const isLeader = nation.leader === player.name;

        if (isMember || isLeader) {
            player.addTag('my_country');
            system.runTimeout(() => {
                try {
                    if (player.isValid()) {
                        player.removeTag('my_country');
                    }
                } catch (e) {
                    console.warn(`タグ削除エラー: ${e}`);
                }
            }, 1);
        } else {
            player.addTag('not_country');
            system.runTimeout(() => {
                try {
                    if (player.isValid()) {
                        player.removeTag('not_country');
                    }
                } catch (e) {
                    console.warn(`タグ削除エラー: ${e}`);
                }
            }, 1);
        }
    });
});

// セレクターを解析してプレイヤーリストを返す補助関数
function parseSelector(selector) {
    if (!selector) return [];

    // 単一プレイヤー名の場合はそのまま検索
    if (!selector.startsWith('@')) {
        const player = world.getPlayers({ name: selector })[0];
        return player ? [player] : [];
    }

    // セレクターの解析（例: @a[x=0,y=0,z=0,r=2]）
    const match = selector.match(/^@([aep])(?:\[(.+)\])?$/);
    if (!match) {
        console.log(`[社会システム] エラー: 無効なセレクター: ${selector}`);
        return [];
    }

    const [, type, args] = match;
    const params = {};

    // 引数をパース（例: x=0,y=0,z=0,r=2）
    if (args) {
        const argList = args.split(',').map(arg => arg.trim());
        argList.forEach(arg => {
            const [key, value] = arg.split('=').map(s => s.trim());
            if (key && value) {
                params[key] = value;
            }
        });
    }

    // セレクタータイプに応じてプレイヤーを取得
    let players = [];
    if (type === 'a') {
        // @a: 全プレイヤー（座標や範囲でフィルタ）
        players = world.getPlayers({
            location: params.x && params.y && params.z ? { x: parseFloat(params.x), y: parseFloat(params.y), z: parseFloat(params.z) } : undefined,
            maxDistance: params.r ? parseFloat(params.r) : undefined,
        });
    } else if (type === 'p') {
        // @p: 最も近いプレイヤー（座標基準）
        if (params.x && params.y && params.z) {
            const location = { x: parseFloat(params.x), y: parseFloat(params.y), z: parseFloat(params.z) };
            const closestPlayer = world.getPlayers({
                location,
                maxDistance: params.r ? parseFloat(params.r) : undefined,
                closest: 1,
            })[0];
            players = closestPlayer ? [closestPlayer] : [];
        } else {
            // 座標指定なしなら実行者に近いプレイヤー（コマンドブロックでは機能しないので空）
            players = [];
        }
    } else {
        console.log(`[社会システム] エラー: 非対応セレクター: ${selector}`);
        return [];
    }

    return players;
}

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const dimensionId = player.dimension.id;
    if (!isSystemEnabledForDimension(dimensionId)) {
        return;
    }

    if (world.getDynamicProperty(UNOWNED_LAND_INTERACT) === true) {
        return;
    }
    if (world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true) {
        return;
    }
    const block = event.block;
    const DANGEROUS_Block = JSON.parse(world.getDynamicProperty('DANGEROUS_Block') ?? '[]');
    if (DANGEROUS_Block.includes(block?.typeId)) {
        // HARUPhoneOPタグがあり、OP操作が許可されている場合は制限をスキップ
        if (player.hasTag('HARUPhoneOP') && world.getDynamicProperty('OP_INTERACTION_ALLOWED') === true) {
            return;
        }

        const chunk = getChunkCoords(event.block.location);
        const chunkData = getChunkData(dimensionId);
        const publicLandData = getPublicLandData(dimensionId);
        const chunkKey = `${chunk.x}:${chunk.z}`;

        let shouldCancel = false;
        let message = '';

        // 公共土地ではインタラクトを許可
        if (publicLandData[chunkKey]) {
            return;
        }

        // 未購入の土地でのインタラクト制限
        if (!chunkData[chunkKey]) {
            shouldCancel = true;
            message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。ブロックとのインタラクトはできません。';
        } else {
            // 他の国のチャンクでのインタラクト制限
            const nationData = getNationData();
            const nation = nationData[chunkData[chunkKey].nation];
            if (!nation || !nation.members.includes(player.name)) {
                shouldCancel = true;
                message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。ブロックとのインタラクトはできません。`;
            }
        }

        if (shouldCancel) {
            event.cancel = true;
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        }
    }
});

// 初期設定の確認と設定
system.runTimeout(() => {
    // ディメンションごとのシステム有効化プロパティの初期設定
    if (world.getDynamicProperty(SYSTEM_ENABLED_OVERWORLD) === undefined) {
        if (world.getDynamicProperty('nation_system_enabled')) {
            world.setDynamicProperty(SYSTEM_ENABLED_OVERWORLD, true); // オーバーワールドはデフォルトで有効
        } else {
            world.setDynamicProperty(SYSTEM_ENABLED_OVERWORLD, false);
        }
    }
    if (world.getDynamicProperty(SYSTEM_ENABLED_NETHER) === undefined) {
        world.setDynamicProperty(SYSTEM_ENABLED_NETHER, false); // ネザーはデフォルトで無効
    }
    if (world.getDynamicProperty(SYSTEM_ENABLED_END) === undefined) {
        world.setDynamicProperty(SYSTEM_ENABLED_END, false); // エンドはデフォルトで無効
    }

    if (world.getDynamicProperty('DANGEROUS_Block') === undefined) {
        const DANGEROUS_Block = [
            // --- コンテナ系 ---
            'minecraft:chest',
            'minecraft:barrel',
            'minecraft:dispenser',
            'minecraft:dropper',
            'minecraft:hopper',

            // --- ドア系 ---
            'minecraft:wooden_door',
            'minecraft:spruce_door',
            'minecraft:iron_door',
            'minecraft:birch_door',
            'minecraft:jungle_door',
            'minecraft:acacia_door',
            'minecraft:dark_oak_door',
            'minecraft:mangrove_door',
            'minecraft:cherry_door',
            'minecraft:bamboo_door',
            'minecraft:crimson_door',
            'minecraft:warped_door',
            'minecraft:crimson_door',
            'minecraft:iron_door',

            // --- トラップドア系 ---
            'minecraft:trapdoor',
            'minecraft:spruce_trapdoor',
            'minecraft:birch_trapdoor',
            'minecraft:jungle_trapdoor',
            'minecraft:acacia_trapdoor',
            'minecraft:dark_oak_trapdoor',
            'minecraft:mangrove_trapdoor',
            'minecraft:cherry_trapdoor',
            'minecraft:bamboo_trapdoor',
            'minecraft:crimson_trapdoor',
            'minecraft:warped_trapdoor',
            'minecraft:iron_trapdoor',

            // --- フェンスゲート系 ---
            'minecraft:fence_gate',
            'minecraft:spruce_fence_gate',
            'minecraft:birch_fence_gate',
            'minecraft:jungle_fence_gate',
            'minecraft:acacia_fence_gate',
            'minecraft:dark_oak_fence_gate',
            'minecraft:mangrove_fence_gate',
            'minecraft:cherry_fence_gate',
            'minecraft:bamboo_fence_gate',
            'minecraft:crimson_fence_gate',
            'minecraft:warped_fence_gate',
            'minecraft:crimson_fence_gate',

            // --- ボタン系 ---
            'minecraft:oak_button',
            'minecraft:spruce_button',
            'minecraft:birch_button',
            'minecraft:jungle_button',
            'minecraft:acacia_button',
            'minecraft:dark_oak_button',
            'minecraft:mangrove_button',
            'minecraft:cherry_button',
            'minecraft:bamboo_button',
            'minecraft:crimson_button',
            'minecraft:warped_button',
            'minecraft:stone_button',
            'minecraft:polished_blackstone_button',
        ];
        world.setDynamicProperty('DANGEROUS_Block', JSON.stringify(DANGEROUS_Block));
    }
}, 10); // サーバー起動時に一度だけ実行
