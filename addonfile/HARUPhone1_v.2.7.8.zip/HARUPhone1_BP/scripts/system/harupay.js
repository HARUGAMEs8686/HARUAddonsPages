import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';
import { logs } from '../itemrun/haruphone1';

export function HARUPAY(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    //money取得
    var score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
    //HARUPAY画面
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${score}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§9送る', 'textures/ui/normalicon1');
    form.button('§5チャージ', 'textures/ui/normalicon1');
    if ((!player.hasTag('HARUPhoneOP') && world.getDynamicProperty('MoneyList_allow') == true) || player.hasTag('HARUPhoneOP')) {
        form.button('§4残高リスト', 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                HARUPhone1(player);
                break;
            case 1:
                sendMoney(player, time);
                break;
            case 2:
                chargeAmountUI(player);
                break;
            case 3:
                showRankingSelector(player);
                break;
            default:
        }
    });
}

function showPlayerSelection(player, time) {
    // プレイヤー選択画面を表示
    const players = world.getAllPlayers();
    player_Cash_Data[player.id].players = players;

    const form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}\n\n§r§5>>> §r送金先のプレイヤーを選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < players.length; i++) {
        form.button(`§1${players[i].name}\n§4>>>§8${players[i].id}`, 'textures/ui/normalicon1');
    }

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            HARUPAY(player); // 戻るボタンでメインメニューへ
            return;
        }

        const selectedPlayer = players[r.selection - 1];
        if (player.id === selectedPlayer.id) {
            player.sendMessage(`§r[§bHARUPAY§r] §c自分自身に送金はできません`);
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            showPlayerSelection(player, time); // 再びプレイヤー選択画面を表示
            return;
        }

        player_Cash_Data[player.id].select_player = selectedPlayer;
        showAmountInput(player, time);
    });
}

function showAmountInput(player, time) {
    // 送金額入力画面を表示
    const form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField(`§b§l${time}\n\n§r送金額を入力してください（半角数字）`, '0');

    form.show(player).then(r => {
        if (r.canceled) {
            showPlayerSelection(player, time); // キャンセルでプレイヤー選択に戻る
            return;
        }

        const input = r.formValues[0];
        if (input === '' || isNaN(input)) {
            player.sendMessage(`§r[§bHARUPAY§r] §c半角数字で入力してください`);
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            showAmountInput(player, time); // 再び金額入力画面を表示
            return;
        }

        const amount = Number(input);
        if (!Number.isInteger(amount)) {
            player.sendMessage(`§r[§bHARUPAY§r] §c整数で入力してください`);
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            showAmountInput(player, time);
            return;
        }

        if (amount <= 0) {
            player.sendMessage(`§r[§bHARUPAY§r] §c0以下の金額は設定できません`);
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            showAmountInput(player, time);
            return;
        }

        if (amount > 100000000) {
            player.sendMessage(`§-highlightRed[§bHARUPAY§r] §c送金額が上限（1億）を超過しています`);
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            showAmountInput(player, time);
            return;
        }

        player_Cash_Data[player.id].select_money = amount;
        showConfirmation(player, time);
    });
}

function showConfirmation(player, time) {
    // 送金確認画面を表示
    const currentBalance = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
    player_Cash_Data[player.id].money = currentBalance;

    const form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}§r\n\n` + `§a送金先§r: §b${player_Cash_Data[player.id].select_player.name}\n` + `§e送金額§r: §b${player_Cash_Data[player.id].select_money} PAY\n\n` + `§e================\n` + `§r現在の残高: §u${currentBalance} PAY\n` + `§r送金後の残高: §b${currentBalance - player_Cash_Data[player.id].select_money} PAY\n` + `§e================`);
    form.button(`§1送金`, 'textures/ui/normalicon1.png');
    form.button(`§0キャンセル`, 'textures/ui/normalicon1.png');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 1) {
            showPlayerSelection(player, time); // キャンセルでプレイヤー選択に戻る
            return;
        }

        if (r.selection === 0) {
            const latestBalance = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
            if (latestBalance >= player_Cash_Data[player.id].select_money) {
                // 送金処理
                player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_money}`);
                player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`);

                // メッセージ
                player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§r に §b${player_Cash_Data[player.id].select_money} PAY§r を送金しました`);
                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a${player.name}§r から §b${player_Cash_Data[player.id].select_money} PAY§r を受け取りました`);

                // 通知音
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
                player_Cash_Data[player.id].select_player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });

                // ログ
                logs['harupay'].push([time, player.name, player_Cash_Data[player.id].select_player.name, player_Cash_Data[player.id].select_money]);
            } else {
                player.sendMessage(`§r[§bHARUPAY§r] §c残高が不足しています`);
                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                showPlayerSelection(player, time); // 不足でプレイヤー選択に戻る
            }
        }
    });
}

function sendMoney(player, time) {
    // 送金処理のエントリーポイント
    showPlayerSelection(player, time);
}

function chargeAmountUI(player) {
    const MoneyItems_score = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
    const coinTypes = [
        { id: 'additem:coina', value: MoneyItems_score[0] },
        { id: 'additem:coinb', value: MoneyItems_score[1] },
        { id: 'additem:coinc', value: MoneyItems_score[2] },
        { id: 'additem:coind', value: MoneyItems_score[3] },
        { id: 'additem:coine', value: MoneyItems_score[4] },
        { id: 'additem:billa', value: MoneyItems_score[5] },
        { id: 'additem:billb', value: MoneyItems_score[6] },
        { id: 'additem:billc', value: MoneyItems_score[7] },
    ];
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField(`§5>>>§cチャージ金額(半角数字)`, '0');
    form.show(player).then(async r => {
        if (r.canceled) {
            HARUPAY(player);
            return;
        }

        const input = r.formValues[0];
        const chargeAmount = parseInt(input);

        if (isNaN(chargeAmount) || !Number.isInteger(Number(input))) {
            player.sendMessage('§r[§bHARUPAY§r] §4半角整数で入力してください');
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            return;
        }
        if (chargeAmount <= 0) {
            player.sendMessage('§r[§bHARUPAY§r] §41以上の値を設定してください');
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            return;
        }

        const inventory = player.getComponent('minecraft:inventory').container;
        const coinCount = {};
        let totalAvailable = 0;

        // インベントリ内のコイン数をカウント
        for (let { id, value } of coinTypes) {
            let count = 0;
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (item?.typeId === id) count += item.amount;
            }
            coinCount[id] = count;
            totalAvailable += count * value;
        }

        // コイン不足のチェック
        if (totalAvailable < chargeAmount) {
            player.sendMessage('§r[§bHARUPAY§r] §4Moneyが不足しています');
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            chargeAmountUI(player);
            return;
        }

        // 必要なコインの枚数を事前計算
        let remaining = chargeAmount;
        const requiredCoins = {};

        for (let { id, value } of coinTypes.reverse()) {
            // 大きいコインから優先的に使う
            if (remaining <= 0) break;
            const needed = Math.min(Math.floor(remaining / value), coinCount[id]);
            if (needed > 0) {
                requiredCoins[id] = needed;
                remaining -= needed * value;
            }
        }

        if (remaining > 0) {
            player.sendMessage('§r[§bHARUPAY§r] §4必要なMoneyの組み合わせが不足しています');
            player.playSound('random.toast', {
                pitch: 0.4,
                volume: 1.0,
            });
            chargeAmountUI(player);
            return;
        }

        try {
            // アイテムを削除
            for (const [id, needed] of Object.entries(requiredCoins)) {
                const removed = removeItemsFromInventory(player, id, needed);
                if (removed < needed) {
                    // 万が一削除に失敗した場合はエラーとして処理
                    throw new Error('アイテムの削除に失敗しました');
                }
            }

            // スコアボード更新
            await player.runCommandAsync(`scoreboard players add @s money ${chargeAmount}`);
            player.sendMessage(`§r[§bHARUPAY§r] §b${chargeAmount}PAY§eチャージしました`);
            player.playSound('random.toast', {
                pitch: 1.7,
                volume: 1.0,
            });
            HARUPAY(player);
        } catch (error) {
            player.sendMessage(`§r[§bHARUPAY§r] §cチャージ処理中にエラーが発生しました: ${error.message}`);
        }
    });
}

// メインの選択フォーム（money / account）
function showRankingSelector(player) {
    new ActionFormData()
        .title(`${config['main'][0]}`)
        .body('表示したいスコアボードを選んでください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1HARUPAY')
        .button('§4口座')
        .show(player)
        .then(res => {
            if (res.canceled) return;

            switch (res.selection) {
                case 0:
                    HARUPAY(player);
                    break;
                case 1:
                    showRanking('money', player);
                    break;
                case 2:
                    showRanking('account', player);
                    break;
            }
        });
}

// ランキング表示（スコアボードID・プレイヤー）
function showRanking(objectiveId, player) {
    const obj = world.scoreboard.getObjective(objectiveId);
    if (!obj) {
        player.sendMessage(`§cスコアボード '${objectiveId}' が見つかりません。`);
        return;
    }

    const onlineNames = [...world.getPlayers()].map(p => p.name);

    const scores = obj
        .getScores()
        .filter(e => e.participant?.displayName)
        .map(e => {
            const name = e.participant.displayName;
            const isOnline = onlineNames.includes(name);
            return {
                name: isOnline ? name : '§7(オフライン)',
                score: e.score,
            };
        })
        .sort((a, b) => b.score - a.score);

    const text = scores.length === 0 ? '§7（データなし）' : scores.map((e, i) => `§f${i + 1}. ${e.name}：§a${e.score}`).join('\n');

    new ActionFormData()
        .title(`${config['main'][0]}`)
        .body(text)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .show(player)
        .then(res => {
            if (!res.canceled && res.selection === 0) {
                showRankingSelector(player);
            }
        });
}

//HARUPAYチャージ関連
function removeItemsFromInventory(player, itemId, count) {
    const inv = player.getComponent('minecraft:inventory').container;
    let removed = 0;

    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (!item || item.typeId !== itemId) continue;

        const remove = Math.min(item.amount, count - removed);
        if (remove <= 0) continue;

        if (item.amount - remove > 0) {
            item.amount -= remove;
            inv.setItem(i, item);
        } else {
            inv.setItem(i, null);
        }
        removed += remove;
        if (removed >= count) break;
    }
    return removed;
}
