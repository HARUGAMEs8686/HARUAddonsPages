import { world, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
// 外部モジュールのインポート（応答のバリエーションが重要になります）
import { detectTopic, getTopicResponse, topicData } from './topics.js';
import { detectCasualPattern, getCasualResponse } from './casualConversations.js';

// --- グローバル設定 ---
const MAX_HISTORY = 7; // 表示する履歴件数

// --- データ管理 ---
// プレイヤーごとのセッションデータ（学習データは削除）
var playerSessionData = {};

// プレイヤーデータの初期化 (セッション開始時、学習データなし)
function initializePlayerData(player) {
    if (!playerSessionData) {
        playerSessionData = {};
    }
    const playerId = player.id;

    if (!playerSessionData[playerId]) {
        playerSessionData[playerId] = {};

        // 初回メッセージ
        const initialHistory = [`§b[HARUassistant] §rこんにちは、§l${player.name}§rさん！ §a何かお話ししましょう！`];
        player.playSound("random.orb", { pitch: 1.5, volume: 1.0 });

        playerSessionData[playerId].assistantHistory = initialHistory;
        // 保持するデータは履歴、直前コンテキスト、最近のトピックのみ
        playerSessionData[playerId].contextData = {
            lastContext: null,      // 直前の会話コンテキスト { timestamp, topic, message, response }
            recentTopics: [],     // 最近話したトピック [topic1, topic2]
            interactionCount: 0   // 対話回数 (セッション内)
        };
    }
    return playerSessionData[playerId];
}

// --- 応答生成関数 (学習機能なし、会話継続重視) ---
function generateResponse(message, player, contextData) {
    let response = `§b[HARUassistant] §r`; // 基本応答
    const playerName = player.name;
    const currentTopic = detectTopic(message); // トピック検出は維持
    const casualPattern = detectCasualPattern(message); // 日常会話検出も維持

    // 1. 特定のトピックが検出された場合
    if (currentTopic) {
        // getTopicResponse は多様な応答を返せると良い
        const topicResponse = getTopicResponse(currentTopic, playerName, false); // 詳細設定は削除
        response += topicResponse;

        // 会話継続のための質問
        const followUpOptions = [
            `\n§e他に §b${currentTopic}§r について聞きたいことはありますか？`,
            `\n§e§b${currentTopic}§r の話、続けますか？ それとも別の話題が良いですか？`,
            `\n§eなるほど！ §b${currentTopic}§r について、他にはどんなことが気になりますか？`
        ];
        response += followUpOptions[Math.floor(Math.random() * followUpOptions.length)]; // ランダムに選択

        // 最近のトピックリストを更新
        contextData.recentTopics = [currentTopic, ...contextData.recentTopics.filter(t => t !== currentTopic)].slice(0, 3);
    }
    // 2. 日常会話パターンが検出された場合
    else if (casualPattern) {
        // getCasualResponse も多様な応答を返せると良い
        const casualResponse = getCasualResponse(casualPattern, playerName, message);
        response += casualResponse;

        // 日常会話の後にも話題を繋げる試み
        if (contextData.recentTopics.length > 0 && Math.random() < 0.5) { // 50%の確率で
            const recentTopic = contextData.recentTopics[0];
            const followUpOptions = [
                `\n§eそういえば、前に §b${recentTopic}§r の話をしましたね。そちらの話もしますか？`,
                `\n§eところで、§b${recentTopic}§r については、もう解決しましたか？`,
                `\n§e話は変わりますが、§b${recentTopic}§r について何か新しい情報はありましたか？`
            ];
            response += followUpOptions[Math.floor(Math.random() * followUpOptions.length)];
        } else if (contextData.lastContext?.topic && contextData.lastContext.topic !== currentTopic) {
             const lastTopic = contextData.lastContext.topic;
             response += `\n§e少し前の §b${lastTopic}§r の話に戻りますか？ それとも、何か新しい話題はありますか？`;
        } else {
            response += `\n§e他に何か話したいことはありますか？`;
        }
    }
    // 3. トピックにも日常会話にも当てはまらない場合 (理解不能 or 一般的な発言)
    else {
        const fallbackOptions = [
            `ふむふむ、§l${playerName}§rさんの言うこと、もう少し詳しく教えてもらえますか？`,
            `なるほど...。それについて、もっと聞かせてください！`,
            `§l${playerName}§rさん、興味深いですね。それで、どうなりましたか？`,
            `そうなんですね！ 他に何か気になることはありますか？`
        ];
        response += fallbackOptions[Math.floor(Math.random() * fallbackOptions.length)];

        // コンテキストからヒントを探し、話題を提案
        if (contextData.recentTopics.length > 0) {
            const recentTopic = contextData.recentTopics[0];
            response += `\n§eあるいは、最近よく話している §b${recentTopic}§r の話題はどうでしょう？`;
        } else if (contextData.lastContext?.topic) {
            const lastTopic = contextData.lastContext.topic;
             response += `\n§e少し前の §b${lastTopic}§r の話に戻ってみるのも良いかもしれませんね。`;
        } else {
            // 提案できるトピックがない場合は、一般的な質問を促す
            const genericPrompts = [
                `\n§e何か私に手伝えることや、知りたい情報はありますか？`,
                `\n§eどんなことでも良いので、気軽に話しかけてくださいね！`,
                `\n§eマイクラの事でも、全然違う話でも大丈夫ですよ！`
            ];
             response += genericPrompts[Math.floor(Math.random() * genericPrompts.length)];
        }
        player.playSound("random.pop", {pitch: 1.2, volume: 0.8}); // 少し考える音
    }

    return response;
}

// --- メイン処理 (チャットUIループ) ---
function chatLoop4(player) {
    if (!player || typeof player !== "object" || !player.isValid()) {
        console.warn("[HARUassistant] chatLoop4 called with invalid player object.");
        return;
    }

    const playerData = initializePlayerData(player); // プレイヤーデータ取得/初期化
    const contextData = playerData.contextData; // learningData -> contextData
    const chatHistory = playerData.assistantHistory;

    let chatForm = new ModalFormData();
    chatForm.title("§1HARU Assistant §r§s(insight-4)"); // タイトル変更

    // チャット履歴の表示 (装飾改善)
    let displayHistory = chatHistory.slice(-MAX_HISTORY).map(line => {
        if (line.startsWith("§7")) { // プレイヤーの発言
            return `§7>> ${line.substring(line.indexOf(']') + 2)}§r`; // 名前省略
        } else { // アシスタントの発言
            // §コードによる基本的な装飾
            return line.replace("§b[HARUassistant] §r", "§b[HARUassistant] §r") // 名前短縮＆色変更
                       .replace(/嬉しい/g, "§a嬉しい§r")
                       .replace(/申し訳|すみません/g, "§c$&&§r") // $& はマッチした文字列全体
                       .replace(/ありがとう/g, "§d$&&§r")
                       .replace(/§b([^\s§]+)§r/g, "§b§l$1§r"); // §bで囲まれた単語を太字に
        }
    }).join("\n§r\n");

    const historyLabel = `§l§b--- Support Chat ---§r\n${displayHistory || "§7(まだ会話がありません)"}\n§l§b--------------------`;
    const placeholder = `[ ${player.name} ] さん、話しかけてみてください (exitで終了)`;

    chatForm.textField(historyLabel, placeholder);

    // --- UI表示と応答処理 ---
    chatForm.show(player).then(r => {
        if (r.canceled || r.formValues[0]?.trim().toLowerCase() === "exit") {
            const exitMessage = `§b[HARUassistant] §r分かりました、§l${player.name}§rさん。またお話ししましょう！ §aいつでもどうぞ！`;
            chatHistory.push(exitMessage);
            player.playSound("random.levelu", { pitch: 0.9, volume: 0.8 });
            // delete playerSessionData[player.id]; // 必要ならセッションデータ削除

             // 外部関数呼び出し
            if (typeof HARUPhone1 === "function") {
                try { HARUPhone1(player); } catch(e) { console.warn("Error calling HARUPhone1 on exit:", e); }
            }
            return;
        }

        const message = r.formValues[0]?.trim() || "";
        if (!message) {
            chatLoop4(player);
            return;
        }

        // ユーザーメッセージ履歴追加
        chatHistory.push(`§7[${player.name}] ${message}`);

        // --- メッセージ処理 (学習なし) ---
        const messageLower = message.toLowerCase();
        let response = "";
        try {
            // 応答生成 (学習データは渡さない)
            response = generateResponse(messageLower, player, contextData);

        } catch (e) {
            console.error(`[HARUassistant] Error during message processing: ${e.stack || e}`);
            response = `§b[HARUassistant] §r§c大変申し訳ありません、§l${player.name}§rさん！ 内部エラーが発生しました...。 もう一度試してみてください。`;
            player.playSound("note.bass", { pitch: 0.5, volume: 1.0 });
        }

        // アシスタント応答履歴追加
        chatHistory.push(response);
        contextData.interactionCount++;

        // 直前コンテキスト保存 (トピック検出結果も含む)
        const currentTopic = detectTopic(messageLower); // 応答生成後にもう一度呼ぶのは非効率だが、ここでは簡単のため
        contextData.lastContext = {
            timestamp: Date.now(),
            topic: currentTopic, // 検出されたトピックを記録
            message: messageLower,
            response: response.replace(/§[a-z0-9lronmk]/g, '').replace('§b[HARUassistant] §r', '').trim()
        };

        // プレイヤーセッションデータ更新
        playerSessionData[player.id].assistantHistory = chatHistory;
        playerSessionData[player.id].contextData = contextData;

        // 効果音
        if (!response.includes("エラーが発生しました")) {
            player.playSound("random.toast", { pitch: 1.8, volume: 0.9 });
        }

        // 次のチャットループへ
        system.run(() => {
            chatLoop4(player);
        });

    }).catch(e => {
        console.error(`[HARUassistant] ModalForm error for player ${player?.name} (${player?.id}): ${e.stack || e}`);
        const errorMessage = `§b[HARUassistant] §r§cUI表示で問題が発生しました... 再度試してください。`;
        // エラー時でも履歴は残す（ただし、次のループは呼ばない方が安全か）
         if (playerSessionData[playerId]?.assistantHistory) {
             playerSessionData[playerId].assistantHistory.push(errorMessage);
         } else {
             // 履歴がない場合はプレイヤーに直接送信することも検討
             try { player.sendMessage(errorMessage); } catch {}
         }

        // 外部関数呼び出し
        if (typeof HARUPhone1 === "function") {
            try { HARUPhone1(player); } catch(err) { console.warn("Error calling HARUPhone1 on UI error:", err); }
        }
    });
}

// --- エクスポート ---
export { chatLoop4 };