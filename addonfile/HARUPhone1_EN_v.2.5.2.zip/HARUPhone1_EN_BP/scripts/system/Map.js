import { world, system } from "@minecraft/server";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";

import { HARUPhone1 } from "../itemrun/haruphone1";
import { others } from "./Operator_Controller";

let waypoints = JSON.parse(world.getDynamicProperty("waypoints") || "[]");
let activeNavigations = new Map();

// Admin form (coordinate registration, editing, deletion)
export function openNavigationForm(player) {
  if (!player.hasTag("HARUPhoneOP")) {
    player.sendMessage("§r[§bMap§r] §cAdministrator privileges required! Please assign the HARUPhoneOP tag.");
    return;
  }

  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§5>§aMap§5>§aCustomize")
    .button(`§lBack`, 'textures/ui/icon_import.png')
    .button("§1Register Coordinate")
    .button("§5Edit Coordinate")
    .button("§4Delete Coordinate");

  form.show(player).then((response) => {
    if (response.canceled) return;
    if(response.selection === 0){
      others(player);
    }
    else if (response.selection === 1) {
      showRegisterForm(player);
    } else if (response.selection === 2) {
      showEditForm(player);
    } else if (response.selection === 3) {
      showDeleteForm(player);
    }
  });
}

// Non-admin form (genre selection or coordinate list, stop navigation)
export function openUserNavigationForm(player) {
  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§cNavigation System")
    .button(`§lBack`, 'textures/ui/icon_import.png')
    .button("§1Navigation");

  if (activeNavigations.has(player.id)) {
    form.button("§5Stop Navigation");
  }

  form.show(player).then((response) => {
    if (response.canceled) return;
    if(response.selection === 0){
      HARUPhone1(player);
    }
    else if (response.selection === 1) {
      const genres = [...new Set(waypoints.map(wp => wp.genre || "Other"))];
      if (genres.length === 1 && genres[0] === "Other") {
        showWaypointList(player, "Other");
      } else {
        showGenreList(player);
      }
    } else if (response.selection === 2 && activeNavigations.has(player.id)) {
      stopNavigation(player);
    }
  });
}

function showGenreList(player) {
  const genres = [...new Set(waypoints.map(wp => wp.genre || "Other"))];
  if (waypoints.length === 0) {
    player.sendMessage("§r[§bMap§r] §cNo registered coordinates.");
    player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
    return;
  }

  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§aSelect Genre");
    form.button(`§lBack`, 'textures/ui/icon_import.png')
  genres.forEach(genre => {
    form.button(`§5${genre}`, "textures/ui/normalicon1");
  });

  form.show(player).then((response) => {
    if (response.canceled) return;
    if(response.selection === 0){
      openUserNavigationForm(player)
      return;
    }
    const selectedGenre = genres[response.selection-1];
    showWaypointList(player, selectedGenre);
  });
}

function showRegisterForm(player) {
  const form = new ModalFormData()
    .title("§1HARUPhone1")
    .textField("Place Name", "e.g., Base")
    .textField("Genre (Optional)", "e.g., Base, Resources")
    .textField("X Coordinate", `${Math.floor(player.location.x)}`)
    .textField("Y Coordinate", `${Math.floor(player.location.y)}`)
    .textField("Z Coordinate", `${Math.floor(player.location.z)}`)
    .textField("Arrival Detection Distance (Blocks)", "10");

  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return;
    const [name, genre, x, y, z, arrivalDistance] = response.formValues;
    if (!name || isNaN(x) || isNaN(y) || isNaN(z) || isNaN(arrivalDistance) || parseInt(arrivalDistance) < 1) {
      player.sendMessage("§r[§bMap§r] §cInvalid input.");
      player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
      return;
    }
    // Re-fetch waypoints before updating
    waypoints = JSON.parse(world.getDynamicProperty("waypoints") || "[]");
    waypoints.push({
      name,
      genre: genre || "Other",
      x: parseInt(x),
      y: parseInt(y),
      z: parseInt(z),
      arrivalDistance: parseInt(arrivalDistance),
    });
    world.setDynamicProperty("waypoints", JSON.stringify(waypoints));
    player.sendMessage(`§r[§bMap§r] §b${name} (${x}, ${y}, ${z}) §ahas been registered`);
    player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
  });
}

function showEditForm(player) {
  if (waypoints.length === 0) {
    player.sendMessage("§r[§bMap§r] §cNo coordinates to edit.");
    player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
    return;
  }

  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§eSelect Coordinate to Edit");

  waypoints.forEach((wp, index) => {
    form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z}) §0[§5${wp.genre || "Other"}§0]`);
  });

  form.show(player).then((response) => {
    if (response.canceled) return;
    const index = response.selection;
    const wp = waypoints[index];

    const editForm = new ModalFormData()
      .title("§1HARUPhone1")
      .textField("Place Name", wp.name, wp.name)
      .textField("Genre (Optional)", wp.genre || "e.g., Base, Resources", wp.genre)
      .textField("X Coordinate", `${wp.x}`, `${wp.x}`)
      .textField("Y Coordinate", `${wp.y}`, `${wp.y}`)
      .textField("Z Coordinate", `${wp.z}`, `${wp.z}`)
      .textField("Arrival Detection Distance (Blocks)", `${wp.arrivalDistance}`, `${wp.arrivalDistance}`);

    editForm.show(player).then((editResponse) => {
      if (editResponse.canceled || !editResponse.formValues) return;
      const [name, genre, x, y, z, arrivalDistance] = editResponse.formValues;
      if (!name || isNaN(x) || isNaN(y) || isNaN(z) || isNaN(arrivalDistance) || parseInt(arrivalDistance) < 1) {
        player.sendMessage("§r[§bMap§r] §cInvalid input.");
        player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
        return;
      }
      // Re-fetch waypoints before updating
      waypoints = JSON.parse(world.getDynamicProperty("waypoints") || "[]");
      waypoints[index] = {
        name,
        genre: genre || "Other",
        x: parseInt(x),
        y: parseInt(y),
        z: parseInt(z),
        arrivalDistance: parseInt(arrivalDistance),
      };
      world.setDynamicProperty("waypoints", JSON.stringify(waypoints));
      player.sendMessage(`§r[§bMap§r] §b${name} (${x}, ${y}, ${z}) §ahas been edited`);
      player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
    });
  });
}

function showDeleteForm(player) {
  if (waypoints.length === 0) {
    player.sendMessage("§r[§bMap§r] §cNo coordinates to delete.");
    player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
    return;
  }

  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§cSelect Coordinate to Delete");

  waypoints.forEach((wp, index) => {
    form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z}) §0[§5${wp.genre || "Other"}§0]`);
  });

  form.show(player).then((response) => {
    if (response.canceled) return;
    const index = response.selection;
    // Re-fetch waypoints before updating
    waypoints = JSON.parse(world.getDynamicProperty("waypoints") || "[]");
    const deleted = waypoints.splice(index, 1)[0];
    world.setDynamicProperty("waypoints", JSON.stringify(waypoints));
    player.sendMessage(`§r[§bMap§r] §b${deleted.name} (${deleted.x}, ${deleted.y}, ${deleted.z}) §ahas been deleted`);
    player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
  });
}

export function showWaypointList(player, genreFilter = null) {
  const filteredWaypoints = genreFilter === null
    ? waypoints
    : waypoints.filter(wp => wp.genre === genreFilter);

  if (filteredWaypoints.length === 0) {
    player.sendMessage(`§r[§bMap§r] §cNo ${genreFilter || "registered"} coordinates.`);
    player.playSound("random.toast", { pitch: 0.5, volume: 1.0 });
    return;
  }

  const form = new ActionFormData()
    .title("§1HARUPhone1")
    .body("§aSelect Place");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
  filteredWaypoints.forEach(wp => {
    form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z})`, "textures/ui/normalicon1");
  });

  form.show(player).then((response) => {
    if (response.canceled) return;
    if(response.selection === 0){
      showGenreList(player);
      return;
    }
    const selected = filteredWaypoints[response.selection-1];
    startNavigation(player, selected);
  });
}

function startNavigation(player, waypoint) {
  if (activeNavigations.has(player.id)) {
    stopNavigation(player);
  }

  player.sendMessage(`§r[§bMap§r] §b${waypoint.name} §aNavigation started`);
  player.playSound("random.toast", { pitch: 1.9, volume: 1.0 });

  let animationTick = 0;

  const intervalId = system.runInterval(() => {
    if (!player.isValid()) {
      stopNavigation(player);
      return;
    }

    const playerPos = player.location;
    const dx = waypoint.x - playerPos.x;
    const dz = waypoint.z - playerPos.z;
    const distance = Math.sqrt(dx * dx + dz * dz);

    // Calculate direction
    const yaw = player.getRotation().y;
    const targetAngle = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
    const angleDiff = ((yaw - targetAngle + 180) % 360) - 180;
    const relativeDirection = getRelativeDirection(angleDiff);

    // Display distance and relative direction in action bar (no arrows)
    player.onScreenDisplay.setActionBar(
      `§6${waypoint.name} Distance: §e${Math.floor(distance)} blocks §b[${relativeDirection}§b]`
    );

    // Arrival detection
    if (distance < waypoint.arrivalDistance) {
      player.sendMessage(`§r[§bMap§r] §aArrived at ${waypoint.name}`);
      player.onScreenDisplay.setActionBar("");
      stopNavigation(player);
      return;
    }
  }, 10);

  activeNavigations.set(player.id, intervalId);
}

function stopNavigation(player) {
  const intervalId = activeNavigations.get(player.id);
  if (intervalId) {
    system.clearRun(intervalId);
    activeNavigations.delete(player.id);
    player.sendMessage("§r[§bMap§r] §cNavigation stopped.");
    player.onScreenDisplay.setActionBar("");
    player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
  }
}

function getRelativeDirection(angleDiff) {
  if (Math.abs(angleDiff) < 45) return "§cForward";
  if (angleDiff >= 45 && angleDiff < 135) return "§dLeft";
  if (angleDiff <= -45 && angleDiff > -135) return "§aRight";
  return "§9Backward";
}