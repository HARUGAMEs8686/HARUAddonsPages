import { world, system } from "@minecraft/server";
import { ModalFormData, ActionFormData, MessageFormData } from "@minecraft/server-ui";

import { Operator_Controller } from '../system/Operator_Controller';
import { HARUPhone1 } from '../itemrun/haruphone1';

// Scoreboard and dynamic property initialization
const MONEY_OBJECTIVE = "money";
const CHUNK_PRICE_PROPERTY = "chunk_price";
const NATION_DB = "nation_data";
const CHUNK_DB = "chunk_data";
const SYSTEM_ENABLED_PROPERTY = "nation_system_enabled";
const NATION_CREATION_COST_PROPERTY = "nation_creation_cost";
const ALLOW_MULTIPLE_NATIONS_PROPERTY = "allow_multiple_nations";
const UNOWNED_LAND_INTERACTION = "unowned_land_interaction";
// 公共土地データの定義
const PUBLIC_LAND_DB = "public_land_data";

// 公共土地データの管理
function getPublicLandData() {
    try {
        const data = world.getDynamicProperty(PUBLIC_LAND_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn("Failed to parse public land data:", e);
        return {};
    }
}

function setPublicLandData(data) {
    try {
        world.setDynamicProperty(PUBLIC_LAND_DB, JSON.stringify(data));
    } catch (e) {
        console.warn("Failed to set public land data:", e);
    }
}

// Check if system is enabled
function isSystemEnabled() {
    return world.getDynamicProperty(SYSTEM_ENABLED_PROPERTY) === true;
}

// Check if multiple nation membership is allowed
function isMultipleNationsAllowed() {
    return world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === true;
}

// Get chunk coordinates
function getChunkCoords(location) {
    return {
        x: Math.floor(location.x / 16),
        z: Math.floor(location.z / 16)
    };
}

// Nation data management
function getNationData() {
    try {
        const data = world.getDynamicProperty(NATION_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn("Failed to parse nation data:", e);
        return {};
    }
}

function setNationData(data) {
    try {
        world.setDynamicProperty(NATION_DB, JSON.stringify(data));
    } catch (e) {
        console.warn("Failed to set nation data:", e);
    }
}

// Chunk data management
function getChunkData() {
    try {
        const data = world.getDynamicProperty(CHUNK_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn("Failed to parse chunk data:", e);
        return {};
    }
}

function setChunkData(data) {
    try {
        world.setDynamicProperty(CHUNK_DB, JSON.stringify(data));
    } catch (e) {
        console.warn("Failed to set chunk data:", e);
    }
}

// Get player's nations
function getPlayerNations(player) {
    const nationData = getNationData();
    return Object.entries(nationData).filter(([_, nation]) => nation.members.includes(player.name));
}

// Show main UI
export function showMainUI(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§bSocial System§r] §cSocial system is currently disabled.");
        return;
    }

    const playerNations = getPlayerNations(player);
    const hasNation = playerNations.length > 0;
    const nowChunkName = getCurrentLocationName(player);

    const form = new ActionFormData()
        .title("§1HARUPhone1")
        .body(`§c-Current Location-\n §a>§e${nowChunkName}`);

    // Dynamically add buttons
    const buttons = [];
    buttons.push({ text: "§lBack", action: "back", icon: "textures/ui/icon_import.png" });
    if (hasNation) {
        buttons.push({ text: `§4Buy Land\n§5>>>§1Cost§r:§s${world.getDynamicProperty(CHUNK_PRICE_PROPERTY)}`, action: "buyLand" });
        buttons.push(
            playerNations.some(([_, nation]) => nation.leader === player.name)
                ? { text: `§1Manage ${world.getDynamicProperty('WorldgroupName')}`, action: "manageNation" }
                : { text: `§4Leave ${world.getDynamicProperty('WorldgroupName')}`, action: "leaveNation" }
        );
    } else {
        buttons.push({ text: `§1Create ${world.getDynamicProperty('WorldgroupName')}\n§5>>>§1Cost§r:§s${world.getDynamicProperty(NATION_CREATION_COST_PROPERTY)}`, action: "createNation" });
    }
    buttons.push({ text: "§0My Info", action: "showMyInfo" });
    buttons.push({ text: "§9Check Invites", action: "checkInvites" });

    buttons.forEach(button => form.button(button.text, button.icon));

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedAction = buttons[response.selection].action;

        if (hasNation) {
            if (selectedAction === "back") {
                HARUPhone1(player);
            } else if (selectedAction === "buyLand" || selectedAction === "manageNation" || selectedAction === "leaveNation") {
                selectNationForAction(player, selectedAction);
            } else if (selectedAction === "showMyInfo") {
                showMyInfo(player);
            } else if (selectedAction === "checkInvites") {
                checkInvites(player);
            }
        } else {
            if (selectedAction === "back") {
                HARUPhone1(player);
            } else if (selectedAction === "createNation") {
                createNation(player);
            } else if (selectedAction === "showMyInfo") {
                showMyInfo(player);
            } else if (selectedAction === "checkInvites") {
                checkInvites(player);
            }
        }
    });
}

// Nation selection UI for multiple nations
function selectNationForAction(player, action) {
    const playerNations = getPlayerNations(player);
    if (playerNations.length === 1) {
        const [nationId, nation] = playerNations[0];
        if (action === "buyLand" && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === "manageNation" && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === "leaveNation") {
            leaveNation(player, nationId);
        } else {
            player.sendMessage("§r[§bSocial System§r] §cYou do not have permission for this action.");
        }
        return;
    }

    const form = new ActionFormData()
        .title(`§5Select ${world.getDynamicProperty('WorldgroupName')}`)
        .body(`§fWhich ${world.getDynamicProperty('WorldgroupName')} do you want to manage?`);
    playerNations.forEach(([nationId, nation]) => {
        form.button(`§e${nation.name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled) return;
        const [nationId, nation] = playerNations[response.selection];
        if (action === "buyLand" && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === "manageNation" && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === "leaveNation") {
            leaveNation(player, nationId);
        } else {
            player.sendMessage("§r[§bSocial System§r] §cYou do not have permission for this action.");
        }
    });
}

// Show my info
function showMyInfo(player) {
    const playerNations = getPlayerNations(player);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;

    let body = `§aBalance: §e${score}\n\n§bAffiliated ${world.getDynamicProperty('WorldgroupName')}:\n`;
    if (playerNations.length === 0) {
        body += "§7None\n";
    } else {
        playerNations.forEach(([_, nation]) => {
            const isLeader = nation.leader === player.name;
            const canBuyLand = nation.permissions?.[player.name]?.canBuyLand || false;
            body += `- §6${nation.name} (§c${isLeader ? "Leader" : "Member"})\n`;
            body += `  §aLand Purchase Permission: §e${canBuyLand ? "Yes" : "No"}\n`;
        });
    }

    const form = new ActionFormData()
        .title("§1HARUPhone1")
        .body(body)
        .button("§1OK");

    form.show(player);
}

// Buy land
function buyLand(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§bSocial System§r] §cSocial system is currently disabled.");
        return;
    }

    const chunk = getChunkCoords(player.location);
    const chunkData = getChunkData();
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);

    if (chunkData[chunkKey]) {
        player.sendMessage("§r[§bSocial System§r] §cThis chunk is already purchased.");
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §cYou are not affiliated with a ${world.getDynamicProperty('WorldgroupName')}.`);
        return;
    }

    const hasPurchasePermission = nation.leader === player.name || (nation.permissions?.[player.name]?.canBuyLand);
    if (!hasPurchasePermission) {
        player.sendMessage("§r[§bSocial System§r] §cYou do not have permission to purchase land.");
        return;
    }

    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < chunkPrice) {
        player.sendMessage(`§r[§bSocial System§r] §cInsufficient funds (Required: §e${chunkPrice}§c, Balance: §e${score}§c).`);
        return;
    }

    const form = new MessageFormData()
        .title("§1HARUPhone1")
        .body(`§fPurchase this chunk for §a${chunkPrice}§f?\n§bCoordinates: (§e${chunk.x}, ${chunk.z}§b)`)
        .button1("§4Cancel")
        .button2("§1Purchase");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -chunkPrice);
            chunkData[chunkKey] = { nation: nationId };
            setChunkData(chunkData);
            player.sendMessage("§r[§bSocial System§r] §aChunk purchased!");
        }
    });
}

// Create nation
function createNation(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§bSocial System§r] §cSocial system is currently disabled.");
        return;
    }

    const nationData = getNationData();
    const playerNations = getPlayerNations(player);
    if (playerNations.length > 0 && !isMultipleNationsAllowed()) {
        player.sendMessage(`§r[§bSocial System§r] §cYou are already affiliated with a ${world.getDynamicProperty('WorldgroupName')}.`);
        return;
    }

    const creationCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < creationCost) {
        player.sendMessage(`§r[§bSocial System§r] §cInsufficient funds (Required: §e${creationCost}§c, Balance: §e${score}§c).`);
        return;
    }

    const form = new ModalFormData()
        .title(`§1Create ${world.getDynamicProperty('WorldgroupName')}`)
        .textField(`§f${world.getDynamicProperty('WorldgroupName')} Name`, "e.g., MyNation")
        .dropdown("§fMembership", ["Open", "Invite Only"], 0);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [nationName, membershipType] = response.formValues;
        if (!nationName) {
            player.sendMessage(`§r[§bSocial System§r] §cPlease enter a ${world.getDynamicProperty('WorldgroupName')} name.`);
            return;
        }
        const nationId = nationName.toLowerCase().replace(/\s/g, "_");
        if (nationData[nationId]) {
            player.sendMessage(`§r[§bSocial System§r] §cThis ${world.getDynamicProperty('WorldgroupName')} name is already taken.`);
            return;
        }

        world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -creationCost);
        nationData[nationId] = {
            name: nationName,
            leader: player.name,
            members: [player.name],
            membership: membershipType === 0 ? "open" : "invite",
            invites: [],
            permissions: {}
        };
        setNationData(nationData);
        player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} "§e${nationName}§a" created!`);
    });
}

// Manage nation
function manageNation(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§bSocial System§r] §cSocial system is currently disabled.");
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §cYou are not affiliated with a ${world.getDynamicProperty('WorldgroupName')}.`);
        return;
    }

    const isLeader = nation.leader === player.name;
    if (!isLeader) {
        player.sendMessage(`§r[§bSocial System§r] §cYou are not the leader of this ${world.getDynamicProperty('WorldgroupName')}.`);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')} Management§r: §1${nation.name}`)
        .body("§4>>>")
        .button(`§lBack`, 'textures/ui/icon_import.png')
        .button("§4Invite Members")
        .button(`§0${world.getDynamicProperty('WorldgroupName')} Info`)
        .button("§1Set Member Permissions")
        .button(`§2Change ${world.getDynamicProperty('WorldgroupName')} Name`)
        .button(`§4Dissolve ${world.getDynamicProperty('WorldgroupName')}`);

    form.show(player).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showMainUI(player);
                break;
            case 1:
                inviteMember(player, nationId);
                break;
            case 2:
                showNationInfo(player, nationId);
                break;
            case 3:
                setMemberPermissions(player, nationId);
                break;
            case 4:
                changeNationName(player, nationId);
                break;
            case 5:
                confirmDissolveNation(player, nationId);
                break;
        }
    });
}

// Show nation info
function showNationInfo(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const memberCount = nation.members.length;
    const memberList = nation.members.join(", ");
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')} Name: §e${nation.name}\n` +
                 `§aLeader: §c${nation.leader}\n` +
                 `§aMember Count: §e${memberCount}\n` +
                 `§aMembers: §f${memberList}\n` +
                 `§aMembership: §e${nation.membership === "open" ? "Open" : "Invite Only"}\n` +
                 `§aOwned Chunks: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')} Info§r: §1${nation.name}`)
        .body(body)
        .button("§1Close");

    form.show(player);
}

// Change nation name
function changeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new ModalFormData()
        .title(`§5Change ${world.getDynamicProperty('WorldgroupName')} Name`)
        .textField(`§fNew ${world.getDynamicProperty('WorldgroupName')} Name`, nation.name);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§bSocial System§r] §cPlease enter a ${world.getDynamicProperty('WorldgroupName')} name.`);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, "_");
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§bSocial System§r] §cThis ${world.getDynamicProperty('WorldgroupName')} name is already in use.`);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} name changed to "§e${newName}§a".`);
    });
}

// Invite member
function inviteMember(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    if (nation.leader !== player.name && nation.membership !== "open") {
        player.sendMessage("§r[§bSocial System§r] §cYou do not have permission to invite.");
        return;
    }

    const form = new ModalFormData()
        .title("§aInvite Member")
        .textField("§fPlayer Name", "e.g., Steve");

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [targetName] = response.formValues;
        const targetPlayer = world.getPlayers().find(p => p.name === targetName);
        if (!targetPlayer) {
            player.sendMessage("§r[§bSocial System§r] §cPlayer not found.");
            return;
        }
        if (targetPlayer.name === player.name) {
            player.sendMessage("§r[§bSocial System§r] §cYou cannot invite yourself.");
            return;
        }

        if (nation.members.includes(targetName)) {
            player.sendMessage("§r[§bSocial System§r] §cThis player is already a member.");
            return;
        }

        nation.invites.push(targetName);
        setNationData(nationData);
        player.sendMessage(`§r[§bSocial System§r] §a${targetName} invited.`);
        targetPlayer.sendMessage(`§r[§bSocial System§r] §aYou have been invited to ${nation.name}.`);
    });
}

// Check invites
function checkInvites(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§bSocial System§r] §cSocial system is currently disabled.");
        return;
    }

    const nationData = getNationData();
    const invites = [];
    for (const nationId in nationData) {
        if (nationData[nationId].invites.includes(player.name) || nationData[nationId].membership === "open") {
            invites.push(nationId);
        }
    }

    if (invites.length === 0) {
        player.sendMessage("§r[§bSocial System§r] §cNo invites available.");
        return;
    }

    const form = new ActionFormData()
        .title("§5Invite List")
        .body(`§fWhich ${world.getDynamicProperty('WorldgroupName')} would you like to join?`);
    invites.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedNation = invites[response.selection];
        const nation = nationData[selectedNation];
        if (!nation) return;

        if (nation.members.includes(player.name)) {
            player.sendMessage(`§r[§bSocial System§r] §cYou are already a member of this ${world.getDynamicProperty('WorldgroupName')}.`);
            return;
        }

        if (!isMultipleNationsAllowed()) {
            const playerNations = getPlayerNations(player);
            if (playerNations.length > 0) {
                player.sendMessage(`§r[§bSocial System§r] §cYou cannot join multiple ${world.getDynamicProperty('WorldgroupName')}s.`);
                return;
            }
        }

        nation.members.push(player.name);
        if (nation.invites.includes(player.name)) {
            nation.invites = nation.invites.filter(name => name !== player.name);
        }
        setNationData(nationData);
        player.sendMessage(`§r[§bSocial System§r] §aJoined ${nation.name}!`);
    });
}

// Leave nation
function leaveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    nation.members = nation.members.filter(name => name !== player.name);
    if (nation.leader === player.name && nation.members.length > 0) {
        nation.leader = nation.members[0];
    }
    if (nation.members.length === 0) {
        delete nationData[nationId];
    }
    setNationData(nationData);
    player.sendMessage(`§r[§bSocial System§r] §aLeft ${nation.name}.`);
}

// Confirm nation dissolution
function confirmDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title(`§4Confirm ${world.getDynamicProperty('WorldgroupName')} Dissolution`)
        .body(`§cReally dissolve "§e${nation.name}§c"?\n§7This action cannot be undone.`)
        .button1("§1Cancel")
        .button2("§4Dissolve");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} dissolved.`);
        }
    });
}

// Set member permissions
function setMemberPermissions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const members = nation.members.filter(name => name !== player.name);

    if (members.length === 0) {
        player.sendMessage("§r[§bSocial System§r] §cNo members available to set permissions for.");
        return;
    }

    const form = new ModalFormData()
        .title("§1Set Member Permissions")
        .dropdown("§fMember", members, 0)
        .toggle("§aLand Purchase Permission", false);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [memberIndex, canBuyLand] = response.formValues;
        const selectedMember = members[memberIndex];

        if (!nation.permissions) {
            nation.permissions = {};
        }
        if (!nation.permissions[selectedMember]) {
            nation.permissions[selectedMember] = {};
        }
        nation.permissions[selectedMember].canBuyLand = canBuyLand;

        setNationData(nationData);
        player.sendMessage(`§r[§bSocial System§r] §a${selectedMember}'s land purchase permission set to ${canBuyLand ? "§eEnabled" : "§eDisabled"}.`);
    });
}

// Admin settings
export function adminSettings(player) {
    const form = new ActionFormData()
        .title("§5Admin Settings")
        .body("Select a setting")
        .button(`§lBack`, 'textures/ui/icon_import.png')
        .button("§1System Settings")
        .button(`§4Manage ${world.getDynamicProperty('WorldgroupName')}`);

    form.show(player).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                showSystemSettingsMenu(player);
                break;
            case 2:
                manageNations(player);
                break;
        }
    });
}

// System settings menu
function showSystemSettingsMenu(player) {
    const form = new ActionFormData()
        .title("§1Social System Settings")
        .body("§fWhich setting would you like to change?")
        .button(`§lBack`, 'textures/ui/icon_import.png')
        .button("§4Set Chunk Price")
        .button(`§4Set ${world.getDynamicProperty('WorldgroupName')} Creation Cost`)
        .button("§9Social System\n§1Enable§r/§4Disable")
        .button(`§2Allow Multiple ${world.getDynamicProperty('WorldgroupName')} Membership`)
        .button("§1Allowed Items\n§8Items usable in unowned land")
        .button("§9Unpurchased Land Display Name")
        .button("§5Unpurchased Land Interaction\n§1Allow§r/§4Deny")
        .button("§2Change Base Type Name")
        .button(`§1${world.getDynamicProperty('WorldgroupName')} Name Title\n§5Show§r/§1Hide`)
        .button("§5Manage Public Lands");
    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                setChunkPrice(player);
                break;
            case 2:
                setNationCreationCost(player);
                break;
            case 3:
                toggleSystemEnabled(player);
                break;
            case 4:
                toggleMultipleNations(player);
                break;
            case 5:
                var form = new ActionFormData()
                    .title("§1Social System Settings")
                    .body("§fWhich setting would you like to change?")
                    .button(`§lBack`, 'textures/ui/icon_import.png')
                    .button("§1Add Item")
                    .button("§4Remove Item")
                form.show(player).then((response) => {
                    if (response.canceled || response.selection === 0) {
                        adminSettings(player);
                        return;
                    }
                    switch (response.selection) {
                        case 1:
                            var form = new ModalFormData()
                                .title("§1Add Allowed Item")
                                .textField("§5>>>Add Item ID\n§r(e.g., additem:haruphone1)", "");
                        
                            form.show(player).then((response) => {
                                if (response.canceled) return;
                        
                                const itemId = response.formValues[0].trim();
                                if (!itemId) {
                                    player.sendMessage("§r[§bSocial System§r] §cInput is empty. Please enter an item ID.");
                                    return;
                                }
                        
                                let DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
                        
                                if (DANGEROUS_ITEMS.includes(itemId)) {
                                    player.sendMessage(`§r[§bSocial System§r] §e${itemId} is already registered.`);
                                    return;
                                }
                        
                                DANGEROUS_ITEMS.push(itemId);
                                world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                                player.sendMessage(`§r[§bSocial System§r] §a${itemId} added as an allowed item.`);
                                showSystemSettingsMenu(player)
                            });                    
                            break;
                        case 2:
                            const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                            if (DANGEROUS_ITEMS.length === 0) {
                                player.sendMessage("§r[§bSocial System§r] §cNo items available to remove.");
                                break;
                            }
                        
                            var form = new ActionFormData()
                                .title("§4Remove Allowed Item")
                                .body("§5>>>Select the item to remove");
                        
                            // Add buttons for each item ID
                            for (const id of DANGEROUS_ITEMS) {
                                form.button(id);
                            }
                        
                            form.show(player).then((response) => {
                                if (response.canceled) {
                                    return;
                                }
                                    const selectedIndex = response.selection;
                                    const removedItem = DANGEROUS_ITEMS[selectedIndex];
                                    DANGEROUS_ITEMS.splice(selectedIndex, 1);
                        
                                    world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                                    player.sendMessage(`§r[§bSocial System§r] §a${removedItem} removed from the list.`);
                                showSystemSettingsMenu(player)
                            });
                        break;
                    }
                })
                break;
            case 6:
                var form = new ModalFormData()
                    .title("§1Unpurchased Land Display Name")
                    .textField("§5>>>Display Name", `${world.getDynamicProperty('WorldspaceNAME')}`);
                
                form.show(player).then((response) => {
                    if (response.canceled) return;
                
                    if (!response.formValues[0]) {
                        player.sendMessage("§r[§bSocial System§r] §cInput is empty. Please enter a display name.");
                        return;
                    }
                
                    world.setDynamicProperty('WorldspaceNAME', response.formValues[0])
                    player.sendMessage(`§r[§bSocial System§r] §a${response.formValues[0]} set as display name.`);
                    showSystemSettingsMenu(player)
                });             
                break;
            case 7:
                toggleUnownedLandInteraction(player);
                break;
            case 8:
                var form = new ModalFormData()
                    .title("§1Base Type Name")
                    .textField("§5>>>Name", `${world.getDynamicProperty('WorldgroupName')}`);
                
                form.show(player).then((response) => {
                    if (response.canceled) return;
                
                    if (!response.formValues[0]) {
                        player.sendMessage("§r[§bSocial System§r] §cInput is empty. Please enter a name.");
                        return;
                    }
                
                    world.setDynamicProperty('WorldgroupName', response.formValues[0])
                    player.sendMessage(`§r[§bSocial System§r] §a${response.formValues[0]} set as base type name.`);
                    showSystemSettingsMenu(player)
                });             
                break;
            case 9:
                var form = new MessageFormData()
                    .title("§1Title Show/Hide")
                    .body(`§c${world.getDynamicProperty('WorldgroupName')} Name Title ${world.getDynamicProperty('WorldTitle') ? "§cHide" : "§aShow"}?`)
                    .button1("§1Cancel")
                    .button2(world.getDynamicProperty('WorldTitle') ? "§4Hide" : "§1Show");
            
                form.show(player).then((response) => {
                    if (response.canceled || response.selection === 0) {
                        showSystemSettingsMenu(player);
                        return;
                    }
                    if (response.selection === 1) {
                        world.setDynamicProperty('WorldTitle', !world.getDynamicProperty('WorldTitle'));
                        player.sendMessage(`§r[§bSocial System§r] §aTitle set to §e${!world.getDynamicProperty('WorldTitle') ? "Hidden" : "Shown"}§a.`);
                    }
                    showSystemSettingsMenu(player);
                });
                break;
                case 10: 
                    managePublicLands(player); 
                break;
        }
    });
}

// Toggle unowned land interaction
function toggleUnownedLandInteraction(player) {
    const isAllowed = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
    const form = new MessageFormData()
        .title("§1Unowned Land Interaction")
        .body(`§fAllow block breaking/placing on unpurchased land? ${isAllowed ? "§cDeny" : "§aAllow"}?`)
        .button1("§1Cancel")
        .button2(isAllowed ? "§4Deny" : "§1Allow");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(UNOWNED_LAND_INTERACTION, !isAllowed);
            player.sendMessage(`§r[§bSocial System§r] §aBlock breaking/placing on unpurchased land set to §e${!isAllowed ? "Allowed" : "Denied"}§a.`);
        }
        showSystemSettingsMenu(player);
    });
}

// Set chunk price
function setChunkPrice(player) {
    const currentPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);
    const form = new ModalFormData()
        .title("§1Set Chunk Price")
        .textField("§fNew Chunk Price", currentPrice.toString());

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [chunkPrice] = response.formValues;
        const parsedChunkPrice = parseInt(chunkPrice);

        if (isNaN(parsedChunkPrice) || parsedChunkPrice < 0) {
            player.sendMessage("§r[§bSocial System§r] §cPlease enter a valid chunk price.");
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, parsedChunkPrice);
        player.sendMessage(`§r[§bSocial System§r] §aChunk price set to §e${parsedChunkPrice}§a.`);
        showSystemSettingsMenu(player);
    });
}

// Set nation creation cost
function setNationCreationCost(player) {
    const currentCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const form = new ModalFormData()
        .title(`§1Set ${world.getDynamicProperty('WorldgroupName')} Creation Cost`)
        .textField(`§fNew ${world.getDynamicProperty('WorldgroupName')} Creation Cost`, currentCost.toString());

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [creationCost] = response.formValues;
        const parsedCreationCost = parseInt(creationCost);

        if (isNaN(parsedCreationCost) || parsedCreationCost < 0) {
            player.sendMessage(`§r[§bSocial System§r] §cPlease enter a valid ${world.getDynamicProperty('WorldgroupName')} creation cost.`);
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, parsedCreationCost);
        player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} creation cost set to §e${parsedCreationCost}§a.`);
        showSystemSettingsMenu(player);
    });
}

// Toggle system enabled
function toggleSystemEnabled(player) {
    const isEnabled = isSystemEnabled();
    const form = new MessageFormData()
        .title("§1Social System Enable/Disable")
        .body(`§fEnable/Disable social system? ${isEnabled ? "§cDisable" : "§aEnable"}?`)
        .button1("§1Cancel")
        .button2(isEnabled ? "§4Disable" : "§1Enable");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(SYSTEM_ENABLED_PROPERTY, !isEnabled);
            player.sendMessage(`§r[§bSocial System§r] §aSocial system set to §e${!isEnabled ? "Enabled" : "Disabled"}§a.`);
        }
        showSystemSettingsMenu(player);
    });
}

// Toggle multiple nations
function toggleMultipleNations(player) {
    const isAllowed = isMultipleNationsAllowed();
    const form = new MessageFormData()
        .title(`§1Allow Multiple ${world.getDynamicProperty('WorldgroupName')} Membership`)
        .body(`§fAllow multiple ${world.getDynamicProperty('WorldgroupName')} membership? ${isAllowed ? "§cDeny" : "§aAllow"}?`)
        .button1("§1Cancel")
        .button2(isAllowed ? "§4Deny" : "§1Allow");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, !isAllowed);
            player.sendMessage(`§r[§bSocial System§r] §aMultiple ${world.getDynamicProperty('WorldgroupName')} membership set to §e${!isAllowed ? "Allowed" : "Denied"}§a.`);
        }
        showSystemSettingsMenu(player);
    });
}

// Manage nations (admin)
function manageNations(player) {
    const nationData = getNationData();
    const nationIds = Object.keys(nationData);

    if (nationIds.length === 0) {
        player.sendMessage(`§r[§bSocial System§r] §cNo ${world.getDynamicProperty('WorldgroupName')}s currently exist.`);
        adminSettings(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§5Manage ${world.getDynamicProperty('WorldgroupName')}`)
        .body(`§fSelect a ${world.getDynamicProperty('WorldgroupName')} to manage.`)
        .button(`§lBack`, 'textures/ui/icon_import.png');

    nationIds.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        const selectedNationId = nationIds[response.selection - 1];
        showNationAdminOptions(player, selectedNationId);
    });
}

// Nation admin options
function showNationAdminOptions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §c${world.getDynamicProperty('WorldgroupName')} does not exist.`);
        manageNations(player);
        return;
    }

    const memberCount = nation.members.length;
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')} Name: §e${nation.name}\n` +
                 `§aLeader: §c${nation.leader}\n` +
                 `§aMember Count: §e${memberCount}\n` +
                 `§aMembers: §f${nation.members.join(", ")}\n` +
                 `§aMembership: §e${nation.membership === "open" ? "Open" : "Invite Only"}\n` +
                 `§aOwned Chunks: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§eManage ${world.getDynamicProperty('WorldgroupName')}: ${nation.name}`)
        .body(body)
        .button("§1Manage Members")
        .button(`§4Change ${world.getDynamicProperty('WorldgroupName')} Name`)
        .button(`§4Force Delete ${world.getDynamicProperty('WorldgroupName')}`)
        .button(`§lBack`, 'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 3) {
            manageNations(player);
            return;
        }
        switch (response.selection) {
            case 0:
                manageNationMembers(player, nationId);
                break;
            case 1:
                adminChangeNationName(player, nationId);
                break;
            case 2:
                confirmForceDissolveNation(player, nationId);
                break;
        }
    });
}

// Manage nation members
function manageNationMembers(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §c${world.getDynamicProperty('WorldgroupName')} does not exist.`);
        showNationAdminOptions(player, nationId);
        return;
    }
    const members = nation.members;

    if (members.length === 0) {
        player.sendMessage(`§r[§bSocial System§r] §cThis ${world.getDynamicProperty('WorldgroupName')} has no members.`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ActionFormData()
        .title(`§5Manage Members§r: §1${nation.name}`)
        .body("§fWhich member would you like to manage?")
        .button(`§lBack`, 'textures/ui/icon_import.png');

    members.forEach(member => {
        form.button(`§1${member}${member === nation.leader ? " (§cLeader§1)" : ""}`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const selectedMember = members[response.selection - 1];
        showMemberOptions(player, nationId, selectedMember);
    });
}

// Member options
function showMemberOptions(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §c${world.getDynamicProperty('WorldgroupName')} does not exist.`);
        manageNationMembers(player, nationId);
        return;
    }
    const isLeader = nation.leader === memberName;

    const form = new ActionFormData()
        .title(`§aManage Member: ${memberName}`)
        .body(`§fSelect an action for ${memberName}.\n§aLand Purchase Permission: §e${nation.permissions?.[memberName]?.canBuyLand ? "Yes" : "No"}`);

    if (!isLeader) form.button("§4Set as Leader");
    form.button("§4Toggle Land Purchase Permission");
    form.button("§4Remove Member");
    form.button(`§lBack`, 'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled) {
            manageNationMembers(player, nationId);
            return;
        }

        const backButtonIndex = isLeader ? 2 : 3;
        if (response.selection === backButtonIndex) {
            manageNationMembers(player, nationId);
            return;
        }

        if (isLeader) {
            switch (response.selection) {
                case 0:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 1:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        } else {
            switch (response.selection) {
                case 0:
                    setNationLeader(player, nationId, memberName);
                    break;
                case 1:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 2:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        }
    });
}

// Set nation leader
function setNationLeader(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title("§4Set Leader")
        .body(`§fSet ${memberName} as the leader of ${nation.name}?`)
        .button1("§1Cancel")
        .button2("§4Set");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.leader = memberName;
            setNationData(nationData);
            player.sendMessage(`§r[§bSocial System§r] §a${memberName} set as the leader of ${nation.name}.`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// Toggle land purchase permission
function toggleLandPurchasePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canBuyLand || false;

    const form = new MessageFormData()
        .title("§aLand Purchase Permission")
        .body(`§fSet ${memberName}'s land purchase permission to ${currentPermission ? "§cDisabled" : "§aEnabled"}?`)
        .button1("§1Cancel")
        .button2(currentPermission ? "§4Disable" : "§1Enable");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canBuyLand = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§bSocial System§r] §a${memberName}'s land purchase permission set to ${!currentPermission ? "§eEnabled" : "§eDisabled"}.`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// Confirm remove member
function confirmRemoveMember(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title("§4Remove Member")
        .body(`§cRemove ${memberName} from ${nation.name}?`)
        .button1("§1Cancel")
        .button2("§4Remove");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.members = nation.members.filter(name => name !== memberName);
            if (nation.leader === memberName && nation.members.length > 0) {
                nation.leader = nation.members[0];
            }
            if (nation.members.length === 0) {
                delete nationData[nationId];
            }
            setNationData(nationData);
            player.sendMessage(`§r[§bSocial System§r] §a${memberName} removed from ${nation.name}.`);
            showNationAdminOptions(player, nationId);
        }
    });
}

// Admin change nation name
function adminChangeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §c${world.getDynamicProperty('WorldgroupName')} does not exist.`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ModalFormData()
        .title(`§4Change ${world.getDynamicProperty('WorldgroupName')} Name`)
        .textField(`§fNew ${world.getDynamicProperty('WorldgroupName')} Name`, nation.name);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§bSocial System§r] §cPlease enter a ${world.getDynamicProperty('WorldgroupName')} name.`);
            showNationAdminOptions(player, nationId);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, "_");
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§bSocial System§r] §cThis ${world.getDynamicProperty('WorldgroupName')} name is already in use.`);
            showNationAdminOptions(player, nationId);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} name changed to "§e${newName}§a".`);
        showNationAdminOptions(player, nationId);
    });
}

// Confirm force dissolve nation
function confirmForceDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§bSocial System§r] §c${world.getDynamicProperty('WorldgroupName')} does not exist.`);
        manageNations(player);
        return;
    }

    const form = new MessageFormData()
        .title(`§4Force Delete ${world.getDynamicProperty('WorldgroupName')}`)
        .body(`§cReally force delete "§e${nation.name}§c"?\n§7This action cannot be undone.`)
        .button1("§1Cancel")
        .button2("§4Delete");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§bSocial System§r] §a${world.getDynamicProperty('WorldgroupName')} "§e${nation.name}§a" forcibly deleted.`);
            manageNations(player);
        }
    });
}

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const chunk = getChunkCoords(event.block.location);
    const chunkData = getChunkData();
    const publicLandData = getPublicLandData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = "";

    if (publicLandData[chunkKey]) {
        return; // 公共土地では破壊を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = "§r[§bSocial System§r] §cThis chunk is not purchased. You cannot break blocks while the social system is enabled.";
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§bSocial System§r] §cThis chunk is owned by another ${world.getDynamicProperty('WorldgroupName')}.`;
        }
    }

    if (shouldCancel) {
        event.cancel = true;
        const now = Date.now();
        const last = lastWarnTime.get(player.id) ?? 0;
        if (now - last >= 3000) {
            player.sendMessage(message);
            lastWarnTime.set(player.id, now);
        }
    }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const block = event.block;
    const chunk = getChunkCoords(block.location);
    const chunkData = getChunkData();
    const publicLandData = getPublicLandData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = "";

    if (publicLandData[chunkKey]) {
        return; // 公共土地では設置を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = "§r[§bSocial System§r] §cThis chunk is not purchased. You cannot place blocks while the social system is enabled.";
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§bSocial System§r] §cThis chunk is owned by another ${world.getDynamicProperty('WorldgroupName')}.`;
        }
    }

    if (shouldCancel) {
        try {
            block.dimension.runCommandAsync(`setblock ${block.x} ${block.y} ${block.z} air`);
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        } catch (e) {
            console.warn("Failed to remove placed block:", e);
        }
    }
});

// Restrict dangerous item usage
const lastWarnTime = new Map(); // Player warning timestamps

world.beforeEvents.itemUseOn.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.source;
    const item = event.itemStack;
    if (player.typeId !== "minecraft:player") return;

    const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
    if (!DANGEROUS_ITEMS.includes(item?.typeId)) {
        const chunk = getChunkCoords(player.location);
        const chunkData = getChunkData();
        const publicLandData = getPublicLandData();
        const chunkKey = `${chunk.x}:${chunk.z}`;

        let shouldCancel = false;
        let message = "";

        if (publicLandData[chunkKey]) {
            return; // 公共土地ではアイテム使用を許可
        }
        if (!chunkData[chunkKey]) {
            const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
            if (!allowInteraction) {
                shouldCancel = true;
                message = "§r[§bSocial System§r] §cThis chunk is not purchased. You cannot use this item.";
            }
        } else {
            const nationData = getNationData();
            const nation = nationData[chunkData[chunkKey].nation];
            if (!nation || !nation.members.includes(player.name)) {
                shouldCancel = true;
                message = `§r[§bSocial System§r] §cThis chunk is owned by another ${world.getDynamicProperty('WorldgroupName')}. You cannot use this item.`;
            }
        }

        if (shouldCancel) {
            event.cancel = true;
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        }
    }
});

// Map to track player's last nation ID (tracking nation ID instead of chunk key)
const lastPlayerNation = new Map();

// 定期的にプレイヤーの国移動を監視
system.runInterval(() => {
    if (!isSystemEnabled()) return;

    for (const player of world.getPlayers()) {
        const chunk = getChunkCoords(player.location);
        const chunkKey = `${chunk.x}:${chunk.z}`;
        const chunkData = getChunkData();
        const nationData = getNationData();
        const publicLandData = getPublicLandData();

        // 現在の場所のIDと名前を取得（公共土地、国、未所属の順）
        let currentLocationId = null;
        let currentLocationName = `§r${world.getDynamicProperty('WorldspaceNAME')}`;

        if (publicLandData[chunkKey]) {
            const landName = publicLandData[chunkKey].name.trim(); // 空白をトリムして正規化
            currentLocationId = `public:${landName}`;
            currentLocationName = `§e${landName}`;
        } else if (chunkData[chunkKey]?.nation) {
            const nationId = chunkData[chunkKey].nation;
            currentLocationId = `nation:${nationId}`;
            const nation = nationData[nationId];
            if (nation) {
                currentLocationName = `§a${nation.name}`;
            }
        }

        const lastLocationId = lastPlayerNation.get(player.id);

        // 場所が変更された場合のみタイトルを表示
        if (lastLocationId !== currentLocationId && world.getDynamicProperty('WorldTitle')) {
            try {
                player.runCommandAsync(`title ${player.name} title §a${currentLocationName}§r`);
                lastPlayerNation.set(player.id, currentLocationId);
            } catch (e) {
                console.warn(`Failed to display title for ${player.name}:`, e);
            }
        }
    }
}, 35); // 20ティック（1秒）ごとにチェック

// Set initial nation on player spawn
world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkData = getChunkData();
    const nationId = chunkData[chunkKey]?.nation || null;
    lastPlayerNation.set(player.id, nationId);
});

function getCurrentLocationName(player) {
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkData = getChunkData();
    const nationData = getNationData();
    const publicLandData = getPublicLandData();

    let nowChunkName = world.getDynamicProperty('WorldspaceNAME');
    if (publicLandData[chunkKey]) {
        nowChunkName = publicLandData[chunkKey].name;
    } else if (chunkData[chunkKey]?.nation) {
        const nation = nationData[chunkData[chunkKey].nation];
        if (nation) {
            nowChunkName = nation.name;
        }
    }
    return nowChunkName;
}


// 公共土地管理メニュー
function managePublicLands(player) {
    const publicLandData = getPublicLandData();
    const publicLandKeys = Object.keys(publicLandData);

    const form = new ActionFormData()
        .title("§1Manage Public Lands")
        .body("§fSelect an action")
        .button(`§lBack`, 'textures/ui/icon_import.png')
        .button("§1Add/Expand Public Land")
        .button("§4Manage Public Lands");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        switch (response.selection) {
            case 1: addPublicLand(player); break;
            case 2:
                if (publicLandKeys.length === 0) {
                    player.sendMessage("§r[§bSocial System§r] §cNo public lands currently exist.");
                    showSystemSettingsMenu(player);
                    return;
                }
                showPublicLandList(player);
                break;
        }
    });
}

// 公共土地追加
function addPublicLand(player) {
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const publicLandData = getPublicLandData();
    const chunkData = getChunkData();

    if (publicLandData[chunkKey]) {
        player.sendMessage("§r[§bSocial System§r] §cThis chunk is already a public land.");
        return;
    }
    if (chunkData[chunkKey]) {
        player.sendMessage("§r[§bSocial System§r] §cThis chunk is already owned by another nation.");
        return;
    }

    // 公共土地の名前を一意に取得（重複を排除）
    const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];
    
    if (publicLandNames.length === 0) {
        // 公共土地がない場合、新規作成のみ
        const form = new ModalFormData()
            .title("§1Add Public Land")
            .textField("§fNew Public Land Name", `Public Land (${chunk.x}, ${chunk.z})`);

        form.show(player).then((response) => {
            if (response.canceled || !response.formValues) {
                managePublicLands(player);
                return;
            }
            const [landName] = response.formValues;
            if (!landName) {
                player.sendMessage("§r[§bSocial System§r] §cPlease enter a public land name.");
                managePublicLands(player);
                return;
            }

            publicLandData[chunkKey] = { name: landName };
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§bSocial System§r] §aPublic land "§e${landName}§a" added.`);
            managePublicLands(player);
        });
    } else {
        // 既存の公共土地がある場合、選択または新規作成
        const form = new ActionFormData()
            .title("§1Add Public Land")
            .body(`§fChunk (§e${chunk.x}, ${chunk.z}§f)\nWhich public land would you like to add to?\n§7Or create a new public land.`)
            .button(`§lBack`, 'textures/ui/icon_import.png');

        publicLandNames.forEach(name => {
            form.button(`§5${name}`);
        });
        form.button("§1Create New Public Land");

        form.show(player).then((response) => {
            if (response.canceled || response.selection === 0) {
                managePublicLands(player);
                return;
            }

            if (response.selection === publicLandNames.length + 1) {
                // 新しい公共土地を作成
                const newForm = new ModalFormData()
                    .title("§1New Public Land")
                    .textField("§fPublic Land Name", `Public Land (${chunk.x}, ${chunk.z})`);

                newForm.show(player).then((newResponse) => {
                    if (newResponse.canceled || !newResponse.formValues) {
                        managePublicLands(player);
                        return;
                    }
                    const [landName] = newResponse.formValues;
                    if (!landName) {
                        player.sendMessage("§r[§bSocial System§r] §cPlease enter a public land name.");
                        managePublicLands(player);
                        return;
                    }

                    publicLandData[chunkKey] = { name: landName };
                    setPublicLandData(publicLandData);
                    player.sendMessage(`§r[§bSocial System§r] §aPublic land "§e${landName}§a" added.`);
                    managePublicLands(player);
                });
            } else {
                // 既存の公共土地に追加
                const selectedName = publicLandNames[response.selection - 1];

                const confirmForm = new MessageFormData()
                    .title("§1Confirm Public Land Addition")
                    .body(`§fChunk (§e${chunk.x}, ${chunk.z}§f)\nAdd to public land "§e${selectedName}§f"?`)
                    .button1("§1Cancel")
                    .button2("§1Add");

                confirmForm.show(player).then((confirmResponse) => {
                    if (confirmResponse.canceled || confirmResponse.selection === 0) {
                        managePublicLands(player);
                        return;
                    }
                    if (confirmResponse.selection === 1) {
                        publicLandData[chunkKey] = { name: selectedName };
                        setPublicLandData(publicLandData);
                        player.sendMessage(`§r[§bSocial System§r] §aChunk added to public land "§e${selectedName}§a".`);
                        managePublicLands(player);
                    }
                });
            }
        });
    }
}

// 公共土地リスト表示
function showPublicLandList(player) {
    const publicLandData = getPublicLandData();
    
    // 公共土地の名前を一意に取得（重複を排除）
    const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];

    if (publicLandNames.length === 0) {
        player.sendMessage("§r[§bSocial System§r] §cNo public lands currently exist.");
        managePublicLands(player);
        return;
    }

    const form = new ActionFormData()
        .title("§1Manage Public Lands")
        .body("§fSelect a public land to manage.")
        .button(`§lBack`, 'textures/ui/icon_import.png');

    publicLandNames.forEach(name => {
        // 同じ名前のチャンク数を取得
        const chunkCount = Object.values(publicLandData).filter(land => land.name === name).length;
        form.button(`§5${name}\n§0(${chunkCount} chunks)`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            managePublicLands(player);
            return;
        }
        const selectedName = publicLandNames[response.selection - 1];
        managePublicLandByName(player, selectedName);
    });
}

// 名前ベースの公共土地管理
function managePublicLandByName(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    const form = new ActionFormData()
        .title(`§1Public Land: ${landName}`)
        .body(`§fName: §e${landName}\n§fChunk Count: §e${relatedChunks.length}\n§fSelect an action to manage.`)
        .button("§4Rename")
        .button("§4Remove Chunks")
        .button(`§lBack`, 'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 2) {
            showPublicLandList(player);
            return;
        }
        switch (response.selection) {
            case 0: renamePublicLandByName(player, landName); break;
            case 1: selectChunkToRemove(player, landName); break;
        }
    });
}

// 名前ベースの公共土地名前変更
function renamePublicLandByName(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    if (relatedChunks.length === 0) {
        player.sendMessage("§r[§bSocial System§r] §cThis public land does not exist.");
        showPublicLandList(player);
        return;
    }

    const form = new ModalFormData()
        .title("§1Rename Public Land")
        .textField("§fNew Name", landName);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            managePublicLandByName(player, landName);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage("§r[§bSocial System§r] §cPlease enter a name.");
            managePublicLandByName(player, landName);
            return;
        }

        relatedChunks.forEach(key => {
            publicLandData[key].name = newName;
        });
        setPublicLandData(publicLandData);
        player.sendMessage(`§r[§bSocial System§r] §aPublic land name changed to "§e${newName}§a".`);
        managePublicLandByName(player, newName);
    });
}

// チャンク削除選択
function selectChunkToRemove(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    if (relatedChunks.length === 0) {
        player.sendMessage("§r[§bSocial System§r] §cThis public land does not exist.");
        showPublicLandList(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§1${landName}: Remove Chunks`)
        .body(`§fSelect a chunk to remove.\n§e${landName} (§7${relatedChunks.length} chunks§e)`)
        .button(`§lBack`, 'textures/ui/icon_import.png')
        .button(`§4Remove All (${relatedChunks.length} chunks)`);

    relatedChunks.forEach(key => {
        form.button(`§e${key}`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            // すべて削除
            confirmRemovePublicLandByName(player, landName, relatedChunks);
        } else {
            // 個別チャンク削除
            const selectedKey = relatedChunks[response.selection - 2];
            confirmRemovePublicLandByName(player, landName, [selectedKey]);
        }
    });
}

// 名前ベースの公共土地削除確認
function confirmRemovePublicLandByName(player, landName, chunkKeys) {
    const publicLandData = getPublicLandData();
    const chunkCount = chunkKeys.length;

    const form = new MessageFormData()
        .title("§4Remove Public Land")
        .body(`§cRemove ${chunkCount} chunks from public land "§e${landName}§c"?\n§7This action cannot be undone.`)
        .button1("§1Cancel")
        .button2("§4Remove");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            chunkKeys.forEach(key => {
                delete publicLandData[key];
            });
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§bSocial System§r] §aRemoved ${chunkCount} chunks from public land "§e${landName}§a".`);
            showPublicLandList(player);
        }
    });
}

// 個別公共土地管理
function managePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage("§r[§bSocial System§r] §cThis public land does not exist.");
        showPublicLandList(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§aPublic Land: ${land.name}`)
        .body(`§fCoordinates: §e${chunkKey}\n§fName: §e${land.name}`)
        .button("§4Rename")
        .button("§4Remove Public Land")
        .button(`§lBack`, 'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 2) {
            showPublicLandList(player);
            return;
        }
        switch (response.selection) {
            case 0: renamePublicLand(player, chunkKey); break;
            case 1: confirmRemovePublicLand(player, chunkKey); break;
        }
    });
}

// 公共土地の名前変更
function renamePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage("§r[§bSocial System§r] §cThis public land does not exist.");
        showPublicLandList(player);
        return;
    }

    const form = new ModalFormData()
        .title("§1Rename Public Land")
        .textField("§fNew Name", land.name);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            managePublicLand(player, chunkKey);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage("§r[§bSocial System§r] §cPlease enter a name.");
            managePublicLand(player, chunkKey);
            return;
        }

        publicLandData[chunkKey].name = newName;
        setPublicLandData(publicLandData);
        player.sendMessage(`§r[§bSocial System§r] §aPublic land name changed to "§e${newName}§a".`);
        managePublicLand(player, chunkKey);
    });
}

// 公共土地削除確認
function confirmRemovePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage("§r[§bSocial System§r] §cThis public land does not exist.");
        showPublicLandList(player);
        managePublicLand(player, chunkKey);
    }

    const form = new MessageFormData()
        .title("§4Remove Public Land")
        .body(`§cRemove public land "§e${land.name}§c"?\n§7This action cannot be undone.`)
        .button1("§1Cancel")
        .button2("§4Remove");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            managePublicLand(player, chunkKey);
            return;
        }
        if (response.selection === 1) {
            delete publicLandData[chunkKey];
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§bSocial System§r] §aPublic land "§e${land.name}§a" removed.`);
            showPublicLandList(player);
        }
    });
}