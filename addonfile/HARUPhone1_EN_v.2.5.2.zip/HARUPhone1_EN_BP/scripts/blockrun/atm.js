import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {};

export function Atm(eventData) {
    const player = eventData.player;
    player_Cash_Data[player.id] = {};
    system.run(() => {
        if (!player_Cash_Data[player.id].AtmStop) {
            player_Cash_Data[player.id].AtmStop = true;

            // Get balance
            player_Cash_Data[player.id].Myscore_A = world.scoreboard.getObjective("account").getScore(eventData.player.scoreboardIdentity);
            if (player_Cash_Data[player.id].Myscore_A == undefined) {
                player_Cash_Data[player.id].Myscore_A = 0;
            }
            player_Cash_Data[player.id].Myscore_B = world.scoreboard.getObjective("money").getScore(eventData.player.scoreboardIdentity);

            // Get current time
            const now = new Date();
            const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, "0");
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
            var time = `${hours}:${minutes}`;

            var form = new ActionFormData();
            form.title("ATM");
            form.body(`§l§b${time}\n§r§s\n§6>>>§eAccount Balance§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY Balance§r:§s${player_Cash_Data[player.id].Myscore_B}`);
            form.button("§5Deposit");
            form.button("§1Withdraw");
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ModalFormData();
                        form.title("ATM");
                        form.textField(
                            `§l§b${time}\n§r§s\n§6>>>§eAccount Balance§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY Balance§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§rDeposit Amount (Enter numbers only)`,
                            "0"
                        );
                        form.show(eventData.player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (isNaN(r.formValues[0])) {
                                player.sendMessage(`§r[§bATM§r] §4Please enter numbers only.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            // Store deposit amount
                            player_Cash_Data[player.id].selection_money = 0;
                            if (r.formValues[0] == '') {
                                player_Cash_Data[player.id].selection_money = 0;
                            } else {
                                player_Cash_Data[player.id].selection_money = Number(r.formValues[0]);
                            }

                            if (player_Cash_Data[player.id].selection_money > 100000000) {
                                player.sendMessage(`§r[§bATM§r] §4Please set below 100 million.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            if (player_Cash_Data[player.id].selection_money < 0) {
                                player.sendMessage(`§r[§bATM§r] §4Cannot set below 0.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            // Process deposit
                            if (player_Cash_Data[player.id].Myscore_B >= player_Cash_Data[player.id].selection_money) {
                                eventData.player.runCommand(`scoreboard players add @s account ${player_Cash_Data[player.id].selection_money}`);
                                eventData.player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].selection_money}`);
                                player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}§a deposited.`);
                                player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });
                            } else {
                                player.sendMessage(`§r[§bATM§r] §4Insufficient HARUPAY balance.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                            }
                        });
                        break;
                    case 1:
                        var form = new ModalFormData();
                        form.title("ATM");
                        form.textField(
                            `§l§b${time}\n§r§s\n§6>>>§eAccount Balance§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY Balance§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§rWithdrawal Amount (Enter numbers only)`,
                            "0"
                        );
                        form.show(eventData.player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (isNaN(r.formValues[0])) {
                                player.sendMessage(`§r[§bATM§r] §4Please enter numbers only.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            // Store withdrawal amount
                            player_Cash_Data[player.id].selection_money = 0;
                            if (r.formValues[0] == '') {
                                player_Cash_Data[player.id].selection_money = 0;
                            } else {
                                player_Cash_Data[player.id].selection_money = Number(r.formValues[0]);
                            }

                            if (player_Cash_Data[player.id].selection_money > 100000000) {
                                player.sendMessage(`§r[§bATM§r] §4Please set below 100 million.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            if (player_Cash_Data[player.id].selection_money < 0) {
                                player.sendMessage(`§r[§bATM§r] §4Cannot set below 0.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            // Process withdrawal
                            if (player_Cash_Data[player.id].Myscore_A >= player_Cash_Data[player.id].selection_money) {
                                eventData.player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].selection_money}`);
                                eventData.player.runCommand(`scoreboard players remove @s account ${player_Cash_Data[player.id].selection_money}`);
                                player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}§a withdrawn.`);
                                player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });
                            } else {
                                player.sendMessage(`§r[§bATM§r] §4Insufficient account balance.`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                            }
                        });
                        break;
                }
            });
            // End of execution
            system.runTimeout(() => {
                player_Cash_Data[player.id].AtmStop = false;
            }, 20);
        }
    });
}