import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// Player data management object
const player_Cash_Data = {};
// Payment logs
const harupay_logs = [];

export function Register(eventData) {
    const player = eventData.player;
    const playerId = player.id;

    // Initialize player data
    if (!player_Cash_Data[playerId]) {
        player_Cash_Data[playerId] = {
            cash: 0,
            isRegistering: false,
            RegisterStop: false,
            lastTransaction: null
        };
    }

    // Exit if on cooldown
    if (player_Cash_Data[playerId].RegisterStop) {
        return;
    }

    // Start cooldown (1 second = 20 ticks)
    player_Cash_Data[playerId].RegisterStop = true;
    system.runTimeout(() => {
        player_Cash_Data[playerId].RegisterStop = false;
    }, 20);

    system.run(() => {
        try {
            // Show payment method selection UI first
            const paymentForm = new ActionFormData()
                .title("Register")
                .body("Select a payment method...")
                .button("§sHARUPAY");

            paymentForm.show(player).then((response) => {
                if (response.canceled) {
                    return;
                }

                if (response.selection === 0) {
                    // Get player coordinates
                    const { x: playerX, y: playerY, z: playerZ } = player.location;

                    // Get all players and manually calculate distance
                    const allPlayers = world.getPlayers();
                    const nearbyPlayers = [];
                    const maxDistance = 4; // Within 4 blocks

                    for (const target of allPlayers) {
                        if (target.name === player.name) continue; // Exclude self
                        const { x: targetX, y: targetY, z: targetZ } = target.location;
                        const distance = Math.sqrt(
                            Math.pow(targetX - playerX, 2) +
                            Math.pow(targetY - playerY, 2) +
                            Math.pow(targetZ - playerZ, 2)
                        );
                        if (distance <= maxDistance) {
                            nearbyPlayers.push(target);
                        }
                    }

                    if (nearbyPlayers.length === 0) {
                        player.sendMessage("§r[§bRegister§r] §cNo players available for transaction");
                        player.playSound("random.toast", {
                            pitch: 0.4,
                            volume: 1.0
                        });
                        return;
                    }

                    // Recipient selection UI
                    const targetForm = new ActionFormData()
                        .title("Register")
                        .body("Select the player to receive payment");
                    nearbyPlayers.forEach((target, index) => {
                        targetForm.button(target.name);
                    });

                    targetForm.show(player).then((targetResponse) => {
                        if (targetResponse.canceled) {
                            return;
                        }

                        const targetPlayer = nearbyPlayers[targetResponse.selection];
                        player.sendMessage("§r[§bRegister§r] §eThe manager is reviewing. Please wait...");

                        // Amount input UI for manager (recipient)
                        const amountForm = new ModalFormData()
                            .title("Register")
                            .textField("Total Amount (Numbers Only)", "0");

                        amountForm.show(targetPlayer).then((amountResponse) => {
                            if (amountResponse.canceled) {
                                player.sendMessage("§r[§bRegister§r] §4Payment canceled by manager");
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            const amount = amountResponse.formValues[0];
                            if (!amount || isNaN(amount)) {
                                targetPlayer.sendMessage("§4Please enter numbers only");
                                player.sendMessage("§r[§bRegister§r] §4Payment failed. Please try again");
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            const cashAmount = parseInt(amount);
                            if (cashAmount > 100000000) {
                                targetPlayer.sendMessage("§4The amount exceeds the limit (100 million or less)");
                                player.sendMessage("§r[§bRegister§r] §4Payment failed. Please try again");
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            if (cashAmount < 0) {
                                targetPlayer.sendMessage("§4Cannot set below 0");
                                player.sendMessage("§r[§bRegister§r] §4Payment failed. Please try again");
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            // Payment confirmation UI
                            const confirmForm = new ActionFormData()
                                .title("Register")
                                .body(`Payment amount: §b${cashAmount}\n\n§6Recipient§r:§c${targetPlayer.name}`)
                                .button("§sPay with HARUPAY")
                                .button("§1Cancel");

                            confirmForm.show(player).then((confirmResponse) => {
                                if (confirmResponse.canceled || confirmResponse.selection === 1) {
                                    return;
                                }

                                if (confirmResponse.selection === 0) {
                                    const playerScore = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                    if (playerScore >= cashAmount) {
                                        // Process payment
                                        targetPlayer.runCommand(`scoreboard players add @s account ${cashAmount}`);
                                        player.runCommand(`scoreboard players remove @s money ${cashAmount}`);
                                        player.sendMessage("§r[§bRegister§r] §ePayment completed successfully");
                                        targetPlayer.sendMessage("§r[§bRegister§r] §ePayment received successfully");
                                        player.playSound("random.toast", {
                                            pitch: 1.7,
                                            volume: 1.0
                                        });
                                        targetPlayer.playSound("random.toast", {
                                            pitch: 1.7,
                                            volume: 1.0
                                        });
                                        // Log transaction
                                        const timer = new Date();
                                        harupay_logs.push(`[${timer.getHours()}:${timer.getMinutes()}] ${player.name} sent ${cashAmount} PAY to ${targetPlayer.name} (Register)`);
                                    } else {
                                        player.sendMessage("§r[§bRegister§r] §eInsufficient HARUPAY balance");
                                        player.sendMessage("§r[§bRegister§r] §ePayment canceled due to insufficient balance");
                                        player.playSound("random.toast", {
                                            pitch: 0.4,
                                            volume: 1.0
                                        });
                                        targetPlayer.playSound("random.toast", {
                                            pitch: 0.4,
                                            volume: 1.0
                                        });
                                    }
                                }
                            });
                        }).catch((error) => {
                            console.error("Manager UI Error:", error);
                            player.sendMessage("§4An error occurred");
                        });
                    }).catch((error) => {
                        console.error("Recipient Selection UI Error:", error);
                        player.sendMessage("§4An error occurred");
                    });
                }
            }).catch((error) => {
                console.error("Payment Method Selection UI Error:", error);
                player.sendMessage("§4An error occurred");
            });
        } catch (error) {
            console.error("Register Processing Error:", error);
            player.sendMessage("§4An unexpected error occurred");
        }
    });
}