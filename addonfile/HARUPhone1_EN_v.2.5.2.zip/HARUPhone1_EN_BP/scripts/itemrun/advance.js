import { world, system } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}
export function Advance(player) {
    system.run(() => {
        if (!player.hasTag('advance_member')) {
            var form = new ActionFormData();
            form.title("Advance");
            form.body(`Please select a service`);
            form.button(`§9Create Advance Account`);
            form.button(`§2Log in to Advance Account`);
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ModalFormData();
                        form.title("Advance");
                        form.textField("Company Name (Store Name)", ``)
                        form.textField("Company (Store) Details", ``)
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            if (r.formValues[0] == '') {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4There are unfilled fields"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            var advance_member = world.getDynamicProperty('advance_member')
                            if (advance_member == undefined) {
                                var advance_member_system2 = []
                            } else {
                                var advance_member_system2 = JSON.parse(advance_member);
                            }
                            for (let i = 0; i < advance_member_system2.length; i++) {
                                if (advance_member_system2[i][1] == r.formValues[0]) {
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4This company name is already in use"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                            }
                            advance_member_system2.push([player.name, r.formValues[0], r.formValues[1], 0, []])
                            const advance_member_system3 = JSON.stringify(advance_member_system2);
                            world.setDynamicProperty('advance_member', advance_member_system3)
                            player.setDynamicProperty('advance_member_data', r.formValues[0])
                            player.runCommand('tag @s add advance_member')
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §aAccount created"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        })
                        break;
                    case 1:
                        var advance_member = world.getDynamicProperty('advance_member')
                        if (advance_member == undefined) {
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No accounts available to log in"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        } else {
                            var advance_member_system2 = JSON.parse(advance_member);
                        }
                        var advance_member_system3 = []
                        var advance_member_cash1 = 0
                        var form = new ActionFormData();
                        form.title("Advance");
                        form.body(`Please select an account`);
                        for (let i = 0; i < advance_member_system2.length; i++) {
                            if (advance_member_system2[i][0] == player.name) {
                                form.button(`${advance_member_system2[i][1]}`);
                                advance_member_system3.push(i)
                                advance_member_cash1 = 1
                            }
                        }
                        if (advance_member_cash1 == 0) {
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No accounts available to log in"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            player.setDynamicProperty('advance_member_data', advance_member_system2[advance_member_system3[response]][1])
                            player.runCommand('tag @s add advance_member')
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §aLogged in"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        })
                        break;
                }
            })
        } else {
            var advance_member_data = player.getDynamicProperty('advance_member_data')
            var advance_member = world.getDynamicProperty('advance_member')
            var advance_member_system2 = JSON.parse(advance_member);
            for (let i = 0; i < advance_member_system2.length; i++) {
                if (advance_member_system2[i][1] == advance_member_data) {
                    var advance_id = i
                }
            }
            var form = new ActionFormData();
            form.title("Advance");
            form.body(`§rCompany Name (Store Name):§b${advance_member_system2[advance_id][1]}\n§rAssets:§a${advance_member_system2[advance_id][3]}\n§e-------------\n§b[App List]`);
            form.button(`§4Log Out`);
            form.button(`§9Set Delivery Completion`);
            form.button(`§2Send from Assets to HARUPAY`);
            form.button(`§3Add/Edit/Delete Products`);
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        player.runCommand('tag @s remove advance_member')
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §aLogged out"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        break;
                    case 1:
                        var advance_member_data = player.getDynamicProperty('advance_member_data')
                        var advance_shop = world.getDynamicProperty('advance_shop')
                        var advance_id = -1;
                        if (advance_shop == undefined) {
                            var advance_shop_system2 = []
                        } else {
                            var advance_shop_system2 = JSON.parse(advance_shop);
                        }
                        for (let i = 0; i < advance_shop_system2.length; i++) {
                            if (advance_shop_system2[i][0] == advance_member_data) {
                                advance_id = i
                            }
                        }
                        if (advance_id == -1) {
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No undelivered products"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        }
                        var advance_id_cash = [];
                        var advance_id_cash1 = [];
                        var advance_id_cash2 = [];
                        var advance_id_cash3 = 0;

                        var form = new ActionFormData();
                        form.title("Advance");
                        form.body(`Select delivered products`);
                        for (let i = 0; i < advance_shop_system2[advance_id][1].length; i++) {
                            for (let i1 = 0; i1 < advance_shop_system2[advance_id][1][i][3].length; i1++) {
                                if (advance_shop_system2[advance_id][1][i][3][i1][2] != 1 && advance_id_cash2.includes(advance_shop_system2[advance_id][1][i][0]) == false) {
                                    form.button(`§l${advance_shop_system2[advance_id][1][i][0]}`);
                                    advance_id_cash.push(i)
                                    advance_id_cash2.push(advance_shop_system2[advance_id][1][i][0])
                                }
                            }
                        }
                        if (advance_id_cash[0] == undefined) {
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No undelivered products"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                            return;
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            var form = new ActionFormData();
                            form.title("Advance");
                            form.body(`§b${advance_shop_system2[advance_id][1][advance_id_cash[response]][0]}§r Select delivered products`);
                            for (let i = 0; i < advance_shop_system2[advance_id][1][advance_id_cash[response]][3].length; i++) {
                                if (advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][2] == 0) {
                                    form.button(`§rQuantity:§2${advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][1]}  §rDestination:§9${advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][0]}`);
                                    advance_id_cash1.push(i)
                                }
                            }
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response1 = r.selection;
                                advance_shop_system2[advance_id][1][advance_id_cash[response]][3][advance_id_cash1[response1]][2] = 1
                                const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                world.setDynamicProperty('advance_shop', advance_shop_system3)
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §aDelivery completed"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                            })
                        })
                        break;
                    case 2:
                        var advance_member_data = player.getDynamicProperty('advance_member_data')
                        var advance_member = world.getDynamicProperty('advance_member')
                        var advance_member_system2 = JSON.parse(advance_member);
                        for (let i = 0; i < advance_member_system2.length; i++) {
                            if (advance_member_system2[i][1] == advance_member_data) {
                                var advance_id = i
                            }
                        }

                        player_Cash_Data[player.name] = {}

                        // Get all players
                        player_Cash_Data[player.name].players = world.getAllPlayers()
                        // HARUPAY sending screen
                        var form = new ActionFormData();
                        form.body(`§r§5 >>>§rSelect the recipient player`);
                        for (let i = 0; i < player_Cash_Data[player.name].players.length; i++) {
                            form.button(`§1${player_Cash_Data[player.name].players[i].name}\n§4>>>§8${player_Cash_Data[player.name].players[i].id}`);
                        }
                        form.show(player).then(r => {
                            if (r.canceled) {
                                return;
                            };
                            // Set recipient player
                            player_Cash_Data[player.name].select_player = player_Cash_Data[player.name].players[r.selection]
                            // Amount setting screen
                            var form = new ModalFormData();
                            form.textField(`§r§bTransfer Amount§r (Numeric)`, "0")
                            form.show(player).then(r => {
                                if (r.canceled) {
                                    return;
                                };
                                if (isNaN(r.formValues[0])) {
                                    player.sendMessage(`§r[§bHARUPAY§r] §4Please enter in numeric format`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                                if (r.formValues[0] > 100000000) {
                                    player.sendMessage(`§r[§bHARUPAY§r] §4The set amount exceeds the limit. Please set below 100 million`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                                if (r.formValues[0] < 0) {
                                    player.sendMessage(`§r[§bHARUPAY§r] §4Cannot set below 0`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                                // Save transfer amount
                                if (r.formValues[0] == '') {
                                    player_Cash_Data[player.name].select_money = 0
                                } else {
                                    player_Cash_Data[player.name].select_money = Number(r.formValues[0])
                                }
                                // Execute only if balance is sufficient
                                if (advance_member_system2[advance_id][3] >= player_Cash_Data[player.name].select_money) {
                                    player_Cash_Data[player.name].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.name].select_money}`)
                                    advance_member_system2[advance_id][3] = advance_member_system2[advance_id][3] - player_Cash_Data[player.name].select_money
                                    const advance_member_system3 = JSON.stringify(advance_member_system2);
                                    world.setDynamicProperty('advance_member', advance_member_system3)

                                    player.sendMessage(`§r[§bAdvance§r] §b${player_Cash_Data[player.name].select_player.name}§a received §b${player_Cash_Data[player.name].select_money}§a`)
                                    player_Cash_Data[player.name].select_player.sendMessage(`§r[§bAdvance§r] §b${player.name}§a sent you §b${player_Cash_Data[player.name].select_money}§a`)

                                    player_Cash_Data[player.name].select_player.playSound("random.toast", {
                                        pitch: 1.7,
                                        volume: 1.0
                                    });
                                    player.playSound("random.toast", {
                                        pitch: 1.7,
                                        volume: 1.0
                                    });

                                } else {
                                    // Insufficient balance message
                                    player.sendMessage(`§r[§bAdvance§r] §4Insufficient Money`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                            })
                        })
                        break;
                    case 3:
                        var form = new ActionFormData();
                        form.title("Advance");
                        form.body("Please select");
                        form.button("§1Add");
                        form.button("§0Edit");
                        form.button("§5Delete");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    var form = new ModalFormData();
                                    form.title("Advance");
                                    form.textField("Product Name", "Diamond")
                                    form.textField("Price", "0")
                                    form.textField("Stock Quantity", "0")
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if (Number(r.formValues[1]) < 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Cannot set below 0"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (isNaN(r.formValues[1])) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter in numeric format"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (Number(r.formValues[2]) < 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Cannot set below 0"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (isNaN(r.formValues[2])) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter in numeric format"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }

                                        var advance_shop = world.getDynamicProperty('advance_shop')
                                        if (advance_shop == undefined) {
                                            var advance_shop_system2 = []
                                        } else {
                                            var advance_shop_system2 = JSON.parse(advance_shop);
                                        }
                                        var advance_shop_cash = 0
                                        for (let i = 0; i < advance_shop_system2.length; i++) {
                                            if (advance_shop_system2[i][0] == player.getDynamicProperty('advance_member_data')) {
                                                advance_shop_cash = 1
                                                advance_shop_system2[i][1].push([r.formValues[0], r.formValues[1], r.formValues[2], []])
                                            }
                                        }
                                        if (advance_shop_cash == 0) {
                                            advance_shop_system2.push([player.getDynamicProperty('advance_member_data'), [[r.formValues[0], r.formValues[1], r.formValues[2], [], 0]]])
                                        }
                                        const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                        world.setDynamicProperty('advance_shop', advance_shop_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aAdded"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                    break;
                                case 1:
                                    var advance_shop = world.getDynamicProperty('advance_shop')
                                    if (advance_shop == undefined) {
                                        var advance_shop_system2 = []
                                    } else {
                                        var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[], []]
                                    var form = new ActionFormData();
                                    form.title("Advance");
                                    form.body("Select item/block to edit");
                                    for (let i = 0; i < advance_shop_system2.length; i++) {
                                        for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                                            if (advance_shop_system2[i][0] == player.getDynamicProperty('advance_member_data')) {
                                                form.button(`${advance_shop_system2[i][1][i1][0]}\nPrice:§b${advance_shop_system2[i][1][i1][1]}§r`);
                                                advance_shop_cash[0].push(i)
                                                advance_shop_cash[1].push(i1)
                                            }
                                        }
                                    }
                                    if (advance_shop_cash[0][0] == undefined) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No editable products"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        var form = new ModalFormData();
                                        form.textField("Product Name", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][0]}`)
                                        form.textField("Price", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][1]}`)
                                        form.textField("Stock Quantity", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][2]}`)
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            if (Number(r.formValues[1]) < 0) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Cannot set below 0"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if (isNaN(r.formValues[1])) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter in numeric format"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if (Number(r.formValues[2]) < 0) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Cannot set below 0"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if (isNaN(r.formValues[2])) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter in numeric format"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                            if (r.formValues[0] != '') { advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][0] = r.formValues[0] }
                                            if (r.formValues[1] != '') { advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][1] = r.formValues[1] }
                                            if (r.formValues[2] != '') { advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][2] = r.formValues[2] }
                                            const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                            world.setDynamicProperty('advance_shop', advance_shop_system3)
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aEdited"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                        })
                                    })
                                    break;
                                case 2:
                                    var advance_shop = world.getDynamicProperty('advance_shop')
                                    if (advance_shop == undefined) {
                                        var advance_shop_system2 = []
                                    } else {
                                        var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[], []]
                                    var form = new ActionFormData();
                                    form.title("Advance");
                                    form.body("Select product to delete");
                                    for (let i = 0; i < advance_shop_system2.length; i++) {
                                        if (advance_shop_system2[i][0] == player.getDynamicProperty('advance_member_data')) {
                                            for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                                                form.button(`${advance_shop_system2[i][1][i1][0]}\nPrice:§b${advance_shop_system2[i][1][i1][1]}§r`);
                                                advance_shop_cash[0].push(i)
                                                advance_shop_cash[1].push(i1)
                                            }
                                        }
                                    }
                                    if (advance_shop_cash[0][0] == undefined) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4No products available to delete"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        for (let i = 0; i < advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][3].length; i++) {
                                            if (advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][3][i][2] != 1) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(Advance)§r] §4Not all deliveries for the selected product are completed"}]}`)
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                return;
                                            }
                                        }
                                        advance_shop_system2[advance_shop_cash[0][response]][1].splice(advance_shop_cash[1][response], 1);
                                        if (advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][0]] == undefined) {
                                            advance_shop_system2.splice(advance_shop_cash[0][response], 1)
                                        }
                                        const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                        world.setDynamicProperty('advance_shop', advance_shop_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aDeleted"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                    break;
                            }
                        })

                        break;
                }
            })
        }
    })
}