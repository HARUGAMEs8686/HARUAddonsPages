import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";

import { config } from "../config"

import { chatLoop4 } from '../HaruAssistant/Insight-4/assistantMain';
import { chatLoop3 } from '../HaruAssistant/Insight-3/assistantMain';

import { App } from '../App/AppMenu';
import { Operator_Controller } from '../system/Operator_Controller';

import { showMainUI } from "../system/country";

import { openUserNavigationForm } from "../system/Map";

//一時データ
export var player_Cash_Data = {}
//請求データ
export var Claim = {}
//仕事募集データ 
export var quest = [[],[]]

//Quick関連
// 初期化時に保存済みデータを読み込む
export function loadShopMenu() {
    const savedData = world.getDynamicProperty("shop_menu");
    if (savedData) {
        return JSON.parse(savedData);
    }
    return [[], []]; // デフォルト値（初回起動時用）
}

//HARUPAYチャージ関連
function removeItemsFromInventory(player, itemId, count) {
    const inv = player.getComponent("minecraft:inventory").container;
    let removed = 0;

    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (!item || item.typeId !== itemId) continue;

        const remove = Math.min(item.amount, count - removed);
        if (remove <= 0) continue;

        if (item.amount - remove > 0) {
            item.amount -= remove;
            inv.setItem(i, item);
        } else {
            inv.setItem(i, null);
        }
        removed += remove;
        if (removed >= count) break;
    }
    return removed;
}
  
  

// データを保存する関数
export function saveShopMenu(shopMenu) {
    world.setDynamicProperty("shop_menu", JSON.stringify(shopMenu));
}
//logデータ
export var logs = {}
 logs['harupay'] = []
 logs['quick'] = []
 logs['quest'] = []

export function HARUPhone1(player){
    system.run(() => {
        //実行アイテム=additem:haruphone1
        if(player.hasTag('op')&&world.getDynamicProperty('op_fast')===undefined){
            var form = new ModalFormData();
            form.title(`${config['main'][0]}`);
            form.textField("§e§oInitial Distribution Amount\n§5>>>§cThis can be changed later, but it may affect economic balance.\n\n§r-§aGuideline§r-\n§r・§bIf you want a player-to-player trade-based economy\n§5>>>§a100000 §r~§a 1000000\n§r・§bIf you want an economy focused on an exchange system\n§5>>>§a0 §r~§a 100000\n§r・§bIf you're unsure\n§5>>>§a5000 §r~§a 10000", "Half-width numbers only")
            form.show(player).then(r => {
                if (r.canceled) {
                    return;
                };
                if(isNaN(r.formValues[0])){
                    player.sendMessage(`§r[§bSystem§r] §4 Enter in single-byte numbers`)
                    player.playSound("random.toast", {
                        pitch: 0.4, 
                        volume: 1.0
                    });  
                    return;
                }
                if (r.formValues[0]>100000000){
                    player.sendMessage(`§r[§bSystem§r] §4The amount set is over the limit.Please set it under 100 million.`)
                    player.playSound("random.toast", {
                        pitch: 0.4, 
                        volume: 1.0
                    });  
                    return;
                }
                if (r.formValues[0]<0){
                    player.sendMessage(`§r[§bSystem§r] §4Cannot set less than 0`)
                    player.playSound("random.toast", {
                        pitch: 0.4, 
                        volume: 1.0
                    });  
                    return;
                }
                if(r.formValues[0]==''){
                    player.sendMessage(`§r[§bSystem§r] §eComplete the initial setup.`)
                    player.playSound("random.toast", {
                        pitch: 0.4, 
                        volume: 1.0
                    });  
                    return;
                }
                //初期設定実行
                    world.setDynamicProperty('start_money',r.formValues[0])
                    world.setDynamicProperty('op_fast',1)
                    world.setDynamicProperty('money_start_system1', 1);
                    player.sendMessage(`§r[§bSystem§r] §aInitial setup is complete.`)
                    player.playSound("random.toast", {
                        pitch: 1.7, 
                        volume: 1.0
                    });  
                    HARUPhone1(player);
            })
        }else{
            //未設定時の実行ストップ
            if(world.getDynamicProperty('money_start_system1') !== 1){
                player.sendMessage(`§r[§bHARUPhone1§r] §cInitial setup has not been completed.`)
                player.sendMessage(`§5>>> §aPlease check the distribution page for details.`)
                player.playSound("random.toast", {
                    pitch: 0.4, 
                    volume: 1.0
                });  
                return;
            }
            //money取得
            const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

            //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, "0");
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
            var time = `${hours}:${minutes}`

            //広告取得 (修正必須)
            var performance = world.getDynamicProperty('performance')
            if(performance==undefined){
                var performance_system2=[]
            }else{
            var performance_system2 = JSON.parse(performance);
            }
            const random_performance = Math.floor(Math.random() * performance_system2.length)

            //playerの一時ファイルを作成(リセット)
            player_Cash_Data[player.id] = {}
            const HARUPhone1_Cash_AppNumber = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'))
        //HOME画面
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}`);
        for (let i = 0; i < HARUPhone1_Cash_AppNumber.length; i++){
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Advertisement'){
                if(performance_system2[0]==undefined){
                    form.button(`§l${config['AppName'][0]}\n§r§0-`,'textures/ui/browser');
                }else{
                    form.button(`§l${config['AppName'][0]}§r\n${performance_system2[random_performance][2]}`,'textures/ui/browser');
                }
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='External Applications'){ 
                form.button(`§1>>>§0${config['AppName'][15]}§4<<<\n§4Japanese only`,'textures/ui/haruapp');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='HARUPAY'){ 
                form.button(`§9${config['AppName'][1]}\n§0Balance:§s${score}`,'textures/ui/pay');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Quick'){ 
                form.button(`§1${config['AppName'][2]}`,'textures/ui/quick');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Mail'){ 
                form.button(`§3${config['AppName'][3]}`,'textures/ui/mail');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Open Chat'){ 
                form.button(`§5${config['AppName'][4]}`,'textures/ui/openchat');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Job Request & Search'){ 
                form.button(`§2${config['AppName'][5]}`,'textures/ui/work');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Advance'){ 
                form.button(`§3${config['AppName'][6]}`,'textures/ui/haruapp');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Exchange'){ 
                form.button(`§5${config['AppName'][7]}`,'textures/ui/redeem');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Purchase'){ 
                form.button(`§9${config['AppName'][8]}`,'textures/ui/purchase');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Information'){ 
                form.button(`§4${config['AppName'][9]}`,'textures/ui/haruaddons');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Browser'){ 
                form.button(`§2${config['AppName'][10]}`,'textures/ui/browser');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='World system'){ 
                form.button(`§9${config['AppName'][11]}`,'textures/ui/country');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Claim'){ 
                form.button(`§s${config['AppName'][12]}`,'textures/ui/claim');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='HARUAssistant'){ 
                form.button(`§1${config['AppName'][14]}\n§4Japanese only`,'textures/ui/haruapp');
            }
            if(config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Map'){ 
                form.button(`§5${config['AppName'][17]}`,'textures/ui/map');
            }
            if (config['AppData'][HARUPhone1_Cash_AppNumber[i]]=='Operator Controller'&player.hasTag('HARUPhoneOP')) {
                form.button(`§5${config['AppName'][13]}`,'textures/ui/operatorcontroller');
            }
        }
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = config['AppData'][HARUPhone1_Cash_AppNumber[r.selection]];
            switch (response) {
                case 'Advertisement':
                    if(performance_system2[0]==undefined){
                        player.sendMessage(`§r[§bbrowser§r] §aAd data not found`)
                        player.playSound("random.toast", {
                            pitch: 0.4, 
                            volume: 1.0
                        });  
                        return;
                    }
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§l${performance_system2[random_performance][3]}\n§e------------\n§rContributor:§a${performance_system2[random_performance][0]}\n§e§l------------\n§r${performance_system2[random_performance][4]}\n\n${performance_system2[random_performance][5]}\n\n${performance_system2[random_performance][6]}\n\n${performance_system2[random_performance][7]}`);
                    form.button(`close`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                    })
                break;
                case 'External Applications':
                    App(player)
                break;
                case 'HARUPAY':
                    //money取得
                     var score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                    //HARUPAY画面
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§b§l${time}\n\n§r§6 >>>§aBalance§r:§s${score}`);
                    form.button(`§lBack`,'textures/ui/icon_import.png');
                    form.button("§9Send");
                    form.button("§5Charge");
                    if((!player.hasTag('HARUPhoneOP')&&world.getDynamicProperty('MoneyList_allow')==true)||(player.hasTag('HARUPhoneOP'))){
                       form.button("§4Balance List");
                    }
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                //Back
                                HARUPhone1(player)
                            break;
                            case 1:
                                //全プレイヤー取得
                                player_Cash_Data[player.id].players = world.getAllPlayers()
                                //HARIPAY送信画面
                                form = new ActionFormData();
                                form.title(`${config['main'][0]}`);
                                form.body(`§b§l${time}\n\n§r§5 >>>§rSelect destination player`);
                                form.button(`§lBack`,'textures/ui/icon_import.png');
                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++){
                                    form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                                }
                                form.show(player).then(r => {
                                    if (r.canceled) {
                                        return;
                                    };

                                    if(r.selection==0){
                                        //Back
                                        HARUPhone1(player)
                                        return;
                                    }
                                    //送信先プレイヤーの設定
                                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection-1]

                                    if(player.id===player_Cash_Data[player.id].players[r.selection-1].id){
                                        player.sendMessage(`§r[§bHARUPAY§r] §cI have no choice.`)
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        return;
                                    }

                                    //送金額設定画面
                                    form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField(`§b§l${time}\n\n§r§bamount of remittance§r(half-width digit)`, "0")
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        };
                                        if(isNaN(r.formValues[0])){
                                            player.sendMessage(`§r[§bHARUPAY§r] §4Please use single-byte numbers.`)
                                            player.playSound("random.toast", {
                                                pitch: 0.4, 
                                                volume: 1.0
                                            });  
                                            return;
                                        }
                                        if (r.formValues[0]>100000000){
                                            player.sendMessage(`§r[§bHARUPAY§r] §4The amount you have set is over the limit. Please set it below 100 million.`)
                                            player.playSound("random.toast", {
                                                pitch: 0.4, 
                                                volume: 1.0
                                            });  
                                            return;
                                        }
                                        if (r.formValues[0]<0){
                                            player.sendMessage(`§r[§bHARUPAY§r] §4Cannot set less than 0`)
                                            player.playSound("random.toast", {
                                                pitch: 0.4, 
                                                volume: 1.0
                                            });  
                                            return;
                                        }
                                        //送金額を保存
                                        if(r.formValues[0]=='') {
                                            player_Cash_Data[player.id].select_money = 0
                                        }else{
                                            player_Cash_Data[player.id].select_money = Number(r.formValues[0])
                                        }
                                        //playerの残高の取得
                                        player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`§b§l${time}§r\n\n§aDestination Player§r:§b${player_Cash_Data[player.id].select_player.name} \n§eamount of remittance§r:§b${player_Cash_Data[player.id].select_money}\n\n§1///////////////////\n§rBalance after processing\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${player_Cash_Data[player.id].money-player_Cash_Data[player.id].select_money}\n§1///////////////////`);
                                        form.button(`§sRemittance`);
                                        form.button(`cancel`);
                                        form.show(player).then(r => {
                                           if (r.canceled) return;
                                           switch (r.selection) {
                                               case 0:
                                                //playerの残高の取得
                                                player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                                if(player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_money){
                                                    //マネー操作
                                                    player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_money}`)
                                                    player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`)
                                                    
                                                    //メッセージ
                                                    player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§r to §b${player_Cash_Data[player.id].select_money}§rPAY sent`)
                                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a${player.name}§r to §b${player_Cash_Data[player.id].select_money}§rPAY received`)
                                                    
                                                    //通知音
                                                    player.playSound("random.toast", {
                                                        pitch: 1.7, 
                                                        volume: 1.0
                                                    });
                                                    player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                                        pitch: 1.7, 
                                                        volume: 1.0
                                                    });

                                                    //ログ関連
                                                    logs['harupay'].push([time,player.name,player_Cash_Data[player.id].select_player.name,player_Cash_Data[player.id].select_money])
                                                }else{
                                                    player.sendMessage(`§r[§bHARUPAY§r] §4Money is missing`)
                                                    player.playSound("random.toast", {
                                                        pitch: 0.4, 
                                                        volume: 1.0
                                                    });  
                                                }
                                               break;
                                           }
                                        })
                                    })
                                })
                            break;
                            case 2:
                                const MoneyItems_score = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
                                const coinTypes = [
                                    { id: "additem:coina", value: MoneyItems_score[0] },
                                    { id: "additem:coinb", value: MoneyItems_score[1]},
                                    { id: "additem:coinc", value: MoneyItems_score[2] },
                                    { id: "additem:coind", value: MoneyItems_score[3] },
                                    { id: "additem:coine", value: MoneyItems_score[4] },
                                    { id: "additem:billa", value: MoneyItems_score[5] },
                                    { id: "additem:billb", value: MoneyItems_score[6] },
                                    { id: "additem:billc", value: MoneyItems_score[7] },
                                ];
                                var form = new ModalFormData();
                                form.title(`${config['main'][0]}`);
                                form.textField(`§5>>>§cCharge amount(half-width digit)`, "0");
                                form.show(player).then(async r => {
                                    if (r.canceled) return;
                                
                                    const input = r.formValues[0];
                                    const chargeAmount = parseInt(input);
                                
                                    if (isNaN(chargeAmount) || !Number.isInteger(Number(input))) {
                                        player.sendMessage("§r[§bHARUPAY§r] §4Please enter a half-width integer.");
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        return;
                                    }
                                    if (chargeAmount <= 0) {
                                        player.sendMessage("§r[§bHARUPAY§r] §4Must be greater than or equal to 1");
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        return;
                                    }
                                
                                    const inventory = player.getComponent("minecraft:inventory").container;
                                    const coinCount = {};
                                    let totalAvailable = 0;
                                
                                    // インベントリ内のコイン数をカウント
                                    for (let { id, value } of coinTypes) {
                                        let count = 0;
                                        for (let i = 0; i < inventory.size; i++) {
                                            const item = inventory.getItem(i);
                                            if (item?.typeId === id) count += item.amount;
                                        }
                                        coinCount[id] = count;
                                        totalAvailable += count * value;
                                    }
                                
                                    // コイン不足のチェック
                                    if (totalAvailable < chargeAmount) {
                                        player.sendMessage("§r[§bHARUPAY§r] §4Money is missing");
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        return;
                                    }
                                
                                    // 必要なコインの枚数を事前計算
                                    let remaining = chargeAmount;
                                    const requiredCoins = {};
                                
                                    for (let { id, value } of coinTypes.reverse()) { // 大きいコインから優先的に使う
                                        if (remaining <= 0) break;
                                        const needed = Math.min(Math.floor(remaining / value), coinCount[id]);
                                        if (needed > 0) {
                                            requiredCoins[id] = needed;
                                            remaining -= needed * value;
                                        }
                                    }
                                
                                    if (remaining > 0) {
                                        player.sendMessage("§r[§bHARUPAY§r] §4Lack of required Money combination");
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        return;
                                    }
                                
                                    try {
                                        // アイテムを削除
                                        for (const [id, needed] of Object.entries(requiredCoins)) {
                                            const removed = removeItemsFromInventory(player, id, needed);
                                            if (removed < needed) {
                                                // 万が一削除に失敗した場合はエラーとして処理
                                                throw new Error("Failed to delete item");
                                            }
                                        }
                                
                                        // スコアボード更新
                                        await player.runCommandAsync(`scoreboard players add @s money ${chargeAmount}`);
                                        player.sendMessage(`§r[§bHARUPAY§r] §b${chargeAmount}§ePAY Charged.`);
                                        player.playSound("random.toast", {
                                            pitch: 1.7, 
                                            volume: 1.0
                                        });  
                                    } catch (error) {
                                        player.sendMessage(`§r[§bHARUPAY§r] §cAn error occurred during the charge process.: ${error.message}`);
                                    }
                                });
                            break;
                            case 3:
                                const TITLE = config['main'][0] ?? "Ranking";

                                // ランキング表示（スコアボードID・プレイヤー）
                                function showRanking(objectiveId, player) {
                                    const obj = world.scoreboard.getObjective(objectiveId);
                                    if (!obj) {
                                        player.sendMessage(`§cCannot find scoreboard '${objectiveId}'.`);
                                        return;
                                    }
                                
                                    const onlineNames = [...world.getPlayers()].map(p => p.name);
                                
                                    const scores = obj.getScores()
                                        .filter(e => e.participant?.displayName)
                                        .map(e => {
                                            const name = e.participant.displayName;
                                            const isOnline = onlineNames.includes(name);
                                            return {
                                                name: isOnline ? name : "§7(offline)",
                                                score: e.score
                                            };
                                        })
                                        .sort((a, b) => b.score - a.score);
                                
                                    const text = scores.length === 0
                                        ? "§7（No data）"
                                        : scores.map((e, i) => `§f${i + 1}. ${e.name}：§a${e.score}`).join("\n");
                                
                                    new ActionFormData()
                                        .title(`${TITLE}`)
                                        .body(text)
                                        .button("§lBack", 'textures/ui/icon_import.png')
                                        .show(player)
                                        .then(res => {
                                            if (!res.canceled && res.selection === 0) {
                                                HARUPhone1(player);
                                            }
                                        });
                                }
                                
                                // メインの選択フォーム（money / account）
                                function showRankingSelector(player) {
                                    new ActionFormData()
                                        .title(`${TITLE}`)
                                        .body("Select the scoreboard you wish to view")
                                        .button("§lBack", 'textures/ui/icon_import.png')
                                        .button("§1HARUPAY")
                                        .button("§4Account")
                                        .show(player)
                                        .then(res => {
                                            if (res.canceled) return;
                                
                                            switch (res.selection) {
                                                case 0:
                                                    HARUPhone1(player);
                                                    break;
                                                case 1:
                                                    showRanking("money", player);
                                                    break;
                                                case 2:
                                                    showRanking("account", player);
                                                    break;
                                            }
                                        });
                                }
                                showRankingSelector(player);
                            break;
                            default:
                        }
                    })
                break;
case 'Quick':  
// shop_menu をグローバル変数として初期化
var shop_menu = loadShopMenu();

// 永続化処理を追加
player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

var form = new ActionFormData();
form.title(`${config['main'][0]}`);
form.body(`§b§l${time}\n\n§r§6 >>>§aMoney possessed§r:§s${player_Cash_Data[player.id].money}`);
form.button(`§lBack`, 'textures/ui/icon_import.png');
form.button(`§1Buy`);
form.button(`§5Exhibit`);
form.button(`§r§4Remove Item`);
form.show(player).then(r => {
    if (r.canceled) return;
    let response = r.selection;
    switch (response) {
        case 0:
            // Back
            HARUPhone1(player);
            break;
        case 1:
            if (shop_menu[0].length == 0) {
                player.sendMessage(`§r[§bQuick§r] §aNo items found`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body("Item List");
            for (let i = 0; i < shop_menu[0].length; i++) {
                form.button(`§0${shop_menu[0][i][0]}\n§rPrice:§s${shop_menu[0][i][2]}§rPAY  Seller:§2${shop_menu[0][i][1]}`);
            }
            form.show(player).then(r => {
                if (r.canceled) {
                    return;
                }
                // 選択した商品を保存
                player_Cash_Data[player.id].select_shop = shop_menu[0][r.selection];
                // money取得
                player_Cash_Data[player.id].money = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body(`Item:§a${player_Cash_Data[player.id].select_shop[0]}\n§rDetails:§c${player_Cash_Data[player.id].select_shop[3]}\n§rPrice:§b${player_Cash_Data[player.id].select_shop[2]}  §rSeller:§2${player_Cash_Data[player.id].select_shop[1]}\n\n§ePayment will be made automatically after purchase\n\n§1///////////////////\n§rBalance after transaction\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_shop[2]}\n§r=§b${player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_shop[2]}\n§1///////////////////`);
                form.button("§5Buy this item");
                form.button("§1Cancel");
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    switch (r.selection) {
                        case 0:
                            player_Cash_Data[player.id].shop_stop = false;
                            // オンラインプレイヤー取得
                            player_Cash_Data[player.id].players = world.getAllPlayers();
                            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                if (player_Cash_Data[player.id].select_shop[4] == player_Cash_Data[player.id].players[i].id) {
                                    player_Cash_Data[player.id].shop_stop = true;
                                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                }
                            }
                            if (player_Cash_Data[player.id].shop_stop == false) {
                                player.sendMessage(`§r[§bQuick§r] §4The seller is currently offline, so the sale is canceled`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }

                            if (shop_menu[1][0] != undefined) {
                                for (let i = 0; i < shop_menu[1].length; i++) {
                                    if (player_Cash_Data[player.id].select_shop[5] == shop_menu[1][i]) {
                                        player_Cash_Data[player.id].shop_stop = false;
                                    }
                                }
                            }

                            if (player_Cash_Data[player.id].shop_stop == false) {
                                player.sendMessage(`§r[§bQuick§r] §4The selected item is no longer available for sale`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            // 残高が設定金額以上の場合のみ実行
                            if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_shop[2]) {
                                // マネー操作
                                player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_shop[2]}`);
                                player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_shop[2]}`);

                                // メッセージ関連
                                player.sendMessage(`§r[§bQuick§r] §bPaid ${player_Cash_Data[player.id].select_shop[2]}PAY to ${player_Cash_Data[player.id].select_shop[1]}`);
                                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §b${player.name}§r ordered §b${player_Cash_Data[player.id].select_shop[0]}§r`);
                                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §eReceived ${player_Cash_Data[player.id].select_shop[2]}PAY from ${player.name}`);

                                // 通知音
                                player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });
                                player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });

                                // log関連
                                logs['quick'].push([time, player.name, player_Cash_Data[player.id].select_shop[1], player_Cash_Data[player.id].select_shop[2]]);

                                // 商品の削除/販売済み商品に追加
                                shop_menu[1].push(player_Cash_Data[player.id].select_shop[5]);
                                for (let i = 0; i < shop_menu[0].length; i++) {
                                    if (shop_menu[0][i][5] === player_Cash_Data[player.id].select_shop[5]) {
                                        shop_menu[0].splice(i, 1);
                                    }
                                }
                                saveShopMenu(shop_menu); // 更新後に保存
                            } else {
                                player.sendMessage(`§r[§bQuick§r] §cInsufficient HARUPAY balance`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                            }
                            break;
                    }
                }).catch(e => {
                    console.error(e, e.stack);
                });
            }).catch(e => {
                console.error(e, e.stack);
            });
            break;
        case 2:
            var form = new ModalFormData();
            form.title(`${config['main'][0]}`);
            form.textField("Item Name", "Cobblestone");
            form.textField("Details", "Enchantments, etc.");
            form.textField("Sale Price (Numbers only)", "0");
            form.show(player).then(r => {
                if (r.canceled) return;
                if (isNaN(r.formValues[2])) {
                    player.sendMessage(`§r[§bQuick§r] §4Please enter numbers only`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                if (r.formValues[2] > 100000000) {
                    player.sendMessage(`§r[§bQuick§r] §4Please set below 100 million`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                if (r.formValues[2] < 0) {
                    player.sendMessage(`§r[§bQuick§r] §4Cannot set below 0`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                if (r.formValues[0] == '') {
                    player.sendMessage(`§r[§bQuick§r] §4Item name is not entered`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }

                if (r.formValues[2] == '') {
                    var selection_score_quick = 0;
                } else {
                    var selection_score_quick = Number(r.formValues[2]);
                }

                // Code生成
                let number = '';
                for (let i = 0; i < 8; i++) {
                    number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                }
                shop_menu[0].push([r.formValues[0], player.name, selection_score_quick, r.formValues[1], player.id, number]);

                // オンラインプレイヤー取得
                player_Cash_Data[player.id].players = world.getAllPlayers();

                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    player_Cash_Data[player.id].players[i].sendMessage(`§r[§bQuick§r] §a${r.formValues[0]}§r:§b${selection_score_quick}§rPAY is now on sale`);
                    // 通知サウンド
                    player_Cash_Data[player.id].players[i].playSound("random.toast", {
                        pitch: 1.7,
                        volume: 1.0
                    });
                }
                saveShopMenu(shop_menu); // 出品後に保存
            }).catch(e => {
                console.error(e, e.stack);
            });
            break;
        case 3:
            if (shop_menu[0].length == 0) {
                player.sendMessage(`§r[§bQuick§r] §aNo items found to remove`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            player_Cash_Data[player.id].my_shop = [];
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body("Select an item to remove");
            for (let i = 0; i < shop_menu[0].length; i++) {
                if (player.id == shop_menu[0][i][4]) {
                    form.button(`§l${shop_menu[0][i][0]}\n§rPrice:§b${shop_menu[0][i][2]}§rPAY  Seller:§2${shop_menu[0][i][1]}`);
                    player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
                }
            }
            if (player_Cash_Data[player.id].my_shop.length == 0) {
                player.sendMessage(`§r[§bQuick§r] §aNo items found to remove`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            form.show(player).then(r => {
                if (r.canceled) {
                    return;
                }
                for (let i = 0; i < shop_menu[0].length; i++) {
                    if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection][5]) {
                        shop_menu[0].splice(i, 1);
                    }
                }
                player.sendMessage(`§r[§bQuick§r] §aItem removed`);
                player.playSound("random.toast", {
                    pitch: 1.7,
                    volume: 1.0
                });
                saveShopMenu(shop_menu); // 削除後に保存
                return;
            }).catch(e => {
                console.error(e, e.stack);
            });
            break;
    }
}).catch(e => {
    console.error(e, e.stack);
});
break;
case 'Mail':
    //メール

    //オンラインプレイヤー取得
    player_Cash_Data[player.id].players = world.getAllPlayers()

    //送信先プレイヤー選択画面
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}§r\n\n§6 >>>§sSelect recipient player`);
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
        form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        //Back
        if (r.selection == 0) {
            //Back
            HARUPhone1(player);
            return;
        }

        //↓プレイヤー選択
        if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
            player.sendMessage(`§r[§bMail§r] §cYou cannot select yourself`);
            player.playSound("random.toast", {
                pitch: 0.4,
                volume: 1.0
            });
            return;
        }
        //選択したプレイヤーを保存
        player_Cash_Data[player.id].player_select = player_Cash_Data[player.id].players[r.selection - 1];
        //メッセージ入力画面
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField(`§l§b${time}§r\n\n§6>>>§rRecipient:§a${player_Cash_Data[player.id].player_select.name}`, "Enter message");
        form.toggle(`§bShare Coordinates §r(false/true)`, false);
        form.show(player).then(r => {
            if (r.canceled) {
                return;
            }
            if (r.formValues[0] == '' && r.formValues[1] == false) {
                player.sendMessage(`§r[§bMail§r] §4Message is empty`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            //現在地を取得
            player_Cash_Data[player.id].player_location = player.location;
            //メッセージ送信
            if (r.formValues[0] !== '') {
                player.sendMessage(`§r[§bMail§r] §aSent to ${player_Cash_Data[player.id].player_select.name}§r§6>>>§r${r.formValues[0]}`);
                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bMail§r] §aReceived from ${player.name}§r§6>>>§r${r.formValues[0]}`);
            }
            if (r.formValues[1] == true) {
                player.sendMessage(`§r[§bMail§r] §cCoordinates sent (§r${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bMail§r] §cCoordinates received §r(§r${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
            }
            //通知サウンド
            player.playSound("random.toast", {
                pitch: 1.7,
                volume: 1.0
            });
            player_Cash_Data[player.id].player_select.playSound("random.toast", {
                pitch: 1.7,
                volume: 1.0
            });
        });
    });
break;
case 'Open Chat':
    //オープンチャット送信画面
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField(`§l§b${time}§r\n\nChat`, "Enter message");
    form.toggle(`§aShare Coordinates §r(false/true)`, false);
    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.formValues[0] == '' && r.formValues[1] == false) {
            player.sendMessage(`§r[§bOpen Chat§r] §4Message is empty`);
            player.playSound("random.toast", {
                pitch: 0.4,
                volume: 1.0
            });
            return;
        }
        //オンラインプレイヤー取得
        player_Cash_Data[player.id].players = world.getAllPlayers();
        //現在地を取得
        player_Cash_Data[player.id].player_location = player.location;

        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
            if (r.formValues[0] !== '') {
                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bChat§r] §a${player.name}§b:§r${r.formValues[0]}`);
            }
            if (r.formValues[1] == true) {
                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bChat§r] §cCoordinates §r(§r${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
            }

            //通知サウンド
            player_Cash_Data[player.id].players[i].playSound("random.toast", {
                pitch: 1.7,
                volume: 1.0
            });
        }
    }).catch(e => {
        console.error(e, e.stack);
    });
break;
case 'Job Request & Search':
    //仕事依頼設定画面
    form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}§r\n\n§5 >>>§rSelect a service`);
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button("§1Post Job");
    form.button("§5Search Jobs");
    form.button("§4Remove Job");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.textField("Job Category", "e.g., Landscaping");
                form.textField("Job Details", "e.g., Leveling a 30-block radius");
                form.textField("Reward Amount (Numbers only)", "0");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.formValues[2] > 100000000) {
                        player.sendMessage(`§r[§bJob Request§r] §4The set amount exceeds the limit. Please set below 100 million`);
                        player.playSound("random.toast", {
                            pitch: 0.4,
                            volume: 1.0
                        });
                        return;
                    }
                    if ((r.formValues[0] == '' || r.formValues[2] == '')) {
                        player.sendMessage(`§r[§bJob Request§r] §4Some fields are not set, so the job could not be posted`);
                        player.playSound("random.toast", {
                            pitch: 0.4,
                            volume: 1.0
                        });
                        return;
                    }
                    if (r.formValues[2] < 0) {
                        player.sendMessage(`§r[§bJob Request§r] §4Cannot set below 0`);
                        player.playSound("random.toast", {
                            pitch: 0.4,
                            volume: 1.0
                        });
                        return;
                    }
                    player_Cash_Data[player.id].players = world.getAllPlayers();
                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                        player_Cash_Data[player.id].players[i].sendMessage(`§r[§bJob Request§r] §b${player.name}§a posted a job: §b${r.formValues[1]}`);
                        player_Cash_Data[player.id].players[i].sendMessage(`§5>>>§aReward Amount§r:§b${r.formValues[2]}`);
                        player_Cash_Data[player.id].players[i].playSound("random.toast", {
                            pitch: 1.7,
                            volume: 1.0
                        });
                    }
                    //Code生成
                    let number = '';
                    for (let i = 0; i < 8; i++) {
                        number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                    }
                    quest[0].push([r.formValues[0], player.name, r.formValues[2], r.formValues[1], player.id, number]);
                }).catch(e => {
                    console.error(e, e.stack);
                });
                break;
            case 2:
                if (quest[0].length == 0) {
                    player.sendMessage(`§r[§bJob Request§r] §aNo jobs found`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Job List");
                for (let i = 0; i < quest[0].length; i++) {
                    form.button(`§0${quest[0][i][0]}\n§rReward:§s${quest[0][i][2]}§rPAY  Client:§2${quest[0][i][1]}`);
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    //選択した商品を保存
                    player_Cash_Data[player.id].select_quest = quest[0][r.selection];

                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`Job:§a${player_Cash_Data[player.id].select_quest[0]}\n§rDetails:§c${player_Cash_Data[player.id].select_quest[3]}\n§rReward:§b${player_Cash_Data[player.id].select_quest[2]}  §rClient:§2${player_Cash_Data[player.id].select_quest[1]}`);
                    form.button("§5Accept Job");
                    form.button("§1Cancel");
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        }
                        switch (r.selection) {
                            case 0:
                                player_Cash_Data[player.id].quest_stop = false;
                                //オンラインプレイヤー取得
                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                    if (player_Cash_Data[player.id].select_quest[4] == player_Cash_Data[player.id].players[i].id) {
                                        player_Cash_Data[player.id].quest_stop = true;
                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                    }
                                }
                                if (player_Cash_Data[player.id].quest_stop == false) {
                                    player.sendMessage(`§r[§bJob Request§r] §4The client is currently offline, so the process is canceled`);
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }

                                if (quest[1][0] != undefined) {
                                    for (let i = 0; i < quest[1].length; i++) {
                                        if (player_Cash_Data[player.id].select_quest[5] == quest[1][i]) {
                                            player_Cash_Data[player.id].quest_stop = false;
                                        }
                                    }
                                }

                                if (player_Cash_Data[player.id].quest_stop == false) {
                                    player.sendMessage(`§r[§bJob Request§r] §4The selected job is no longer available`);
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                                //メッセージ関連
                                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bJob Request§r] §e${player.name}§b accepted the job: ${player_Cash_Data[player.id].select_quest[0]}`);
                                player.sendMessage(`§r[§bJob Request§r] §b${player_Cash_Data[player.id].select_quest[0]}§a job accepted §cClient§r:§e${player_Cash_Data[player.id].select_quest[1]}`);

                                //通知音
                                player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });
                                player_Cash_Data[player.id].select_player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });

                                //log関連
                                logs['quest'].push([time, player.name, player_Cash_Data[player.id].select_quest[1], player_Cash_Data[player.id].select_quest[0]]);

                                quest[1].push(player_Cash_Data[player.id].select_quest[5]);
                                for (let i = 0; i < quest[0].length; i++) {
                                    if (quest[0][i][5] === player_Cash_Data[player.id].select_quest[5]) {
                                        quest[0].splice(i, 1);
                                    }
                                }
                                break;
                        }
                    });
                }).catch(e => {
                    console.error(e, e.stack);
                });
                break;
            case 3:
                if (quest[0].length == 0) {
                    player.sendMessage(`§r[§bJob Request§r] §aNo jobs found to remove`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                player_Cash_Data[player.id].my_quest = [];
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Select a job to remove");
                for (let i = 0; i < quest[0].length; i++) {
                    if (player.id == quest[0][i][4]) {
                        form.button(`§l${quest[0][i][0]}\n§rReward:§b${quest[0][i][2]}§rPAY  Client:§2${quest[0][i][1]}`);
                        player_Cash_Data[player.id].my_quest.push(quest[0][i]);
                    }
                }
                if (player_Cash_Data[player.id].my_quest.length == 0) { // Fixed condition from -1 to 0
                    player.sendMessage(`§r[§bJob Request§r] §aNo jobs found to remove`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    for (let i = 0; i < quest[0].length; i++) {
                        if (quest[0][i][5] === player_Cash_Data[player.id].my_quest[r.selection][5]) {
                            quest[0].splice(i, 1);
                        }
                    }
                    player.sendMessage(`§r[§bJob Request§r] §aJob removed`);
                    player.playSound("random.toast", {
                        pitch: 1.7,
                        volume: 1.0
                    });
                    return;
                }).catch(e => {
                    console.error(e, e.stack);
                });
                break;
            default:
        }
    });
break;
case 'Advance':
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}§r\n\n §5>>>§aFind products`);
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button(`§9Keyword Search`);
    form.button(`§2Company Filter`);
    form.button(`§1Order Delivery Status`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                var advance_shop = world.getDynamicProperty('advance_shop');
                if (advance_shop == undefined) {
                    var advance_shop_system2 = [];
                } else {
                    var advance_shop_system2 = JSON.parse(advance_shop);
                }
                var advance_shop_cash = [[], []];
                var advance_shop_cash1 = 0;
                var advance_shop_cash2 = [];
                var advance_shop_cash3 = [];
                if (advance_shop == undefined || advance_shop_system2[0] == undefined) {
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aNo products found"}]}`);
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                    return;
                }
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.textField("Search Product", "Diamond");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.formValues[0] == '') {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter a search keyword"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                        return;
                    }
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body("Search Product List");
                    for (let i = 0; i < advance_shop_system2.length; i++) {
                        advance_shop_cash[0].push(i);
                        for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                            if (advance_shop_system2[i][1][i1][0].indexOf(r.formValues[0]) != -1) {
                                form.button(`§l${advance_shop_system2[i][1][i1][0]}\n§rPrice:§9${advance_shop_system2[i][1][i1][1]} §rStock:§2${advance_shop_system2[i][1][i1][2]}`);
                                advance_shop_cash1 = 1;
                                advance_shop_cash2.push(i);
                                advance_shop_cash3.push(i1);
                            }
                        }
                    }
                    if (advance_shop_cash1 == 0) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aNo products found"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                        return;
                    }
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        advance_shop_cash[1].push(advance_shop_cash2[response]);
                        advance_shop_cash[1].push(response);
                        advance_shop_cash[1].push(advance_shop_cash3[response]);
                        var form = new ModalFormData();
                        form.title(`${config['main'][0]}`);
                        form.textField("Quantity (Numbers only)", "0");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            advance_shop_cash[1].push(Number(r.formValues[0]));
                            if (r.formValues[0] <= 0) {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Cannot set below 0"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            if (r.formValues[0] == '') {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter a quantity"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            if (Number(r.formValues[0]) > advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2]) {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Exceeds available stock"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body(`§lOrder Details\n\n§rProduct:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][0]}\n§rQuantity:§a${advance_shop_cash[1][3]}§rTotal Price:§b${advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}\n\n§rSeller:§a${advance_shop_system2[advance_shop_cash[1][0]][0]}`);
                            form.button(`Order`);
                            form.button(`Close`);
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0:
                                        const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                        if (score >= advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]) {
                                            var advance_partner = '';
                                            var advance_member = world.getDynamicProperty('advance_member');
                                            if (advance_member == undefined) {
                                                var advance_member_system2 = [];
                                            } else {
                                                var advance_member_system2 = JSON.parse(advance_member);
                                            }
                                            for (let i = 0; i < advance_member_system2.length; i++) {
                                                if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                    advance_partner = `${advance_member_system2[i][0]}`;
                                                }
                                            }
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2] - advance_shop_cash[1][2];
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][3].push([player.name, advance_shop_cash[1][3], 0]);
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4] + 1;
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aOrder placed"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                            player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §b${player.name}§a ordered §b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]"}]}`);
                                            player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`);
                                            var advance_member = world.getDynamicProperty('advance_member');
                                            var advance_member_system2 = JSON.parse(advance_member);
                                            for (let i = 0; i < advance_member_system2.length; i++) {
                                                if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                    advance_member_system2[i][3] = advance_member_system2[i][3] + advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1];
                                                }
                                            }
                                            const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                            world.setDynamicProperty('advance_shop', advance_shop_system3);
                                            const advance_member_system3 = JSON.stringify(advance_member_system2);
                                            world.setDynamicProperty('advance_member', advance_member_system3);
                                            player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}`);
                                        } else {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Insufficient funds"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                        }
                                        break;
                                }
                            });
                        });
                    });
                });
                break;
            case 2:
                var advance_shop = world.getDynamicProperty('advance_shop');
                if (advance_shop == undefined) {
                    var advance_shop_system2 = [];
                } else {
                    var advance_shop_system2 = JSON.parse(advance_shop);
                }
                var advance_shop_cash = [[], []];
                if (advance_shop == undefined || advance_shop_system2[0] == undefined) {
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aNo products found"}]}`);
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Search products by company");
                for (let i = 0; i < advance_shop_system2.length; i++) {
                    form.button(`${advance_shop_system2[i][0]}§r`);
                    advance_shop_cash[0].push(i);
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    advance_shop_cash[1].push(response);
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`Product list for ${advance_shop_system2[advance_shop_cash[0][response]][0]}`);
                    for (let i = 0; i < advance_shop_system2[advance_shop_cash[0][response]][1].length; i++) {
                        form.button(`§l${advance_shop_system2[advance_shop_cash[0][response]][1][i][0]}\n§rPrice:§9${advance_shop_system2[advance_shop_cash[0][response]][1][i][1]} §rStock:§2${advance_shop_system2[advance_shop_cash[0][response]][1][i][2]}`);
                    }
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        advance_shop_cash[1].push(response);
                        var form = new ModalFormData();
                        form.title(`${config['main'][0]}`);
                        form.textField("Quantity (Numbers only)", "0");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            advance_shop_cash[1].push(r.formValues[0]);
                            if (r.formValues[0] <= 0) {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §40以下は設定できません"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            if (r.formValues[0] == '') {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Please enter a quantity"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            if (Number(r.formValues[0]) > advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2]) {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Exceeds available stock"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                return;
                            }
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body(`§lOrder Details\n\n§rProduct:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]}\n§rQuantity:§a${advance_shop_cash[1][2]}§rTotal Price:§b${advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}\n\n§rSeller:§a${advance_shop_system2[advance_shop_cash[1][0]][0]}`);
                            form.button(`Order`);
                            form.button(`Close`);
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0:
                                        const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                        if (score >= advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]) {
                                            var advance_partner = '';
                                            var advance_member = world.getDynamicProperty('advance_member');
                                            if (advance_member == undefined) {
                                                var advance_member_system2 = [];
                                            } else {
                                                var advance_member_system2 = JSON.parse(advance_member);
                                            }
                                            for (let i = 0; i < advance_member_system2.length; i++) {
                                                if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[1][0]][0]) {
                                                    advance_partner = `${advance_member_system2[i][0]}`;
                                                }
                                            }
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2] - advance_shop_cash[1][2];
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][3].push([player.name, advance_shop_cash[1][2], 0]);
                                            advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4] + 1;
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §aOrder placed"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                            player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §b${player.name}§a ordered §b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]"}]}`);
                                            player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`);
                                            var advance_member = world.getDynamicProperty('advance_member');
                                            var advance_member_system2 = JSON.parse(advance_member);
                                            for (let i = 0; i < advance_member_system2.length; i++) {
                                                if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                    advance_member_system2[i][3] = advance_member_system2[i][3] + advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1];
                                                }
                                            }
                                            const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                            world.setDynamicProperty('advance_shop', advance_shop_system3);
                                            const advance_member_system3 = JSON.stringify(advance_member_system2);
                                            world.setDynamicProperty('advance_member', advance_member_system3);
                                            player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}`);
                                        } else {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(advance)§r] §4Insufficient funds"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                        }
                                        break;
                                }
                            });
                        });
                    });
                });
                break;
            case 3:
                var advance_shop_pattern = [];
                var advance_shop = world.getDynamicProperty('advance_shop');
                if (advance_shop == undefined) {
                    var advance_shop_system2 = [];
                } else {
                    var advance_shop_system2 = JSON.parse(advance_shop);
                }
                for (let i = 0; i < advance_shop_system2.length; i++) {
                    for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                        for (let i2 = 0; i2 < advance_shop_system2[i][1][i1][3].length; i2++) {
                            if (advance_shop_system2[i][1][i1][3][i2][0] == player.name) {
                                advance_shop_pattern.push([advance_shop_system2[i][1][i1][0], advance_shop_system2[i][1][i1][3][i2]]);
                            }
                        }
                    }
                }
                var advance_shop_pattern_text = '';
                for (let i = 0; i < advance_shop_pattern.length; i++) {
                    if (advance_shop_pattern[i][1][2] == 0) {
                        var advance_shop_pattern_text_cash = '§9Currently being shipped';
                    } else {
                        var advance_shop_pattern_text_cash = '§9Delivery completed';
                    }
                    advance_shop_pattern_text = advance_shop_pattern_text + `Product:§b${advance_shop_pattern[i][0]}§r Quantity:§a${advance_shop_pattern[i][1][1]}\n${advance_shop_pattern_text_cash}§r\n`;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body(`${advance_shop_pattern_text}`);
                form.button(`Close`);
                form.show(player).then(r => {
                    if (r.canceled) return;
                });
                break;
        }
    });
break;
case 'Exchange':
    var kannkin_information = world.getDynamicProperty('kannkin_information');
    if (kannkin_information == undefined) {
        var kannkin_information_system2 = [];
    } else {
        var kannkin_information_system2 = JSON.parse(kannkin_information);
    }
    if (kannkin_information_system2[0] == undefined) {
        player.sendMessage(`§r[§bExchange§r] §aNo items available for exchange`);
        player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
        });
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§5>>>§aSelect an item to exchange");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    for (let i = 0; i < kannkin_information_system2.length; i++) {
        if ((kannkin_information_system2[i][3] == undefined) || (kannkin_information_system2[i][3] == '') || (kannkin_information_system2[i][3] == 'delete')) {
            form.button(`§1${kannkin_information_system2[i][0]} §51 item§0:§s${kannkin_information_system2[i][1]}§r`, `textures/ui/normalicon1`);
        } else {
            form.button(`§1${kannkin_information_system2[i][0]} §51 item§0:§s${kannkin_information_system2[i][1]}§r`, `textures/${kannkin_information_system2[i][3]}`);
        }
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        if (r.selection == 0) {
            HARUPhone1(player);
            return;
        }
        player_Cash_Data[player.id].select_item = r.selection - 1;
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField(`§eItem§5>>>§c${kannkin_information_system2[player_Cash_Data[player.id].select_item][0]}\n\n§aExchange Quantity§s (Numbers only)`, "0");
        form.show(player).then(r => {
            if (r.canceled) {
                return;
            }
            if (r.formValues[0] < 0) {
                player.sendMessage(`§r[§bExchange§r] §4Cannot set below 0`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            if (r.formValues[0] == '') {
                player.sendMessage(`§r[§bExchange§r] §4Please set the exchange quantity`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            if (isNaN(r.formValues[0])) {
                player.sendMessage(`§r[§bExchange§r] §4Please enter numbers only`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            player.runCommand(`tellraw @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=..${r.formValues[0] - 1}}] {"rawtext":[{"text":"§r[§bExchange§r] §4Not enough items"}]}`);
            player.runCommand(`playsound random.toast @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=..${r.formValues[0] - 1}}] ~ ~ ~ 1.0 0.4 0.7`);
            player.runCommand(`tellraw @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] {"rawtext":[{"text":"§r[§bExchange§r] §eExchanged and received ${kannkin_information_system2[player_Cash_Data[player.id].select_item][1] * r.formValues[0]} PAY"}]}`);
            player.runCommand(`playsound random.toast @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] ~ ~ ~ 1.0 1.7 0.5`);
            player.runCommand(`scoreboard players add @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] money ${kannkin_information_system2[player_Cash_Data[player.id].select_item][1] * r.formValues[0]}`);
            player.runCommand(`clear @s[hasitem={item=${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]},quantity=${r.formValues[0]}..}] ${kannkin_information_system2[player_Cash_Data[player.id].select_item][2]} 0 ${r.formValues[0]}`);
        }).catch(e => {
            console.error(e, e.stack);
        });
    }).catch(e => {
        console.error(e, e.stack);
    });
break;
case 'Purchase':
    const kounyuu_list = world.getDynamicProperty('kounyuu_list');
    if (kounyuu_list == undefined) {
        player.sendMessage(`§r[§bPurchase§r] §aNo items available for purchase`);
        player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
        });
        return;
    } else {
        var kounyuu_list_system1 = JSON.parse(kounyuu_list);
    }
    if (kounyuu_list_system1[0] == undefined) {
        player.sendMessage(`§r[§bPurchase§r] §aNo items available for purchase`);
        player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
        });
        return;
    }
    //購入
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§5>>>§aSelect an item to purchase");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    for (let i = 0; i < kounyuu_list_system1.length; i++) {
        if ((kounyuu_list_system1[i][3] == undefined) || (kounyuu_list_system1[i][3] == '') || (kounyuu_list_system1[i][3] == 'delete')) {
            form.button(`§1${kounyuu_list_system1[i][0]} §51 item§0/§s${kounyuu_list_system1[i][1]}§r`, `textures/ui/normalicon1`);
        } else {
            form.button(`§1${kounyuu_list_system1[i][0]} §51 item§0/§s${kounyuu_list_system1[i][1]}§r`, `textures/${kounyuu_list_system1[i][3]}`);
        }
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            HARUPhone1(player);
            return;
        }
        player_Cash_Data[player.id].select_item = r.selection - 1;
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField(`§eItem§5>>>§c${kounyuu_list_system1[player_Cash_Data[player.id].select_item][0]}\n\n§aPurchase Quantity§s (Numbers only)`, "0");
        form.show(player).then(r => {
            if (r.canceled) return;
            if (r.formValues[0] < 0) {
                player.sendMessage(`§r[§bPurchase§r] §4Cannot set below 0`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            if (r.formValues[0] == '') {
                player.sendMessage(`§r[§bPurchase§r] §4Please set the purchase quantity`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            if (isNaN(r.formValues[0])) {
                player.sendMessage(`§r[§bPurchase§r] §4Please enter numbers only`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
                return;
            }
            const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
            if (score >= kounyuu_list_system1[player_Cash_Data[player.id].select_item][1] * r.formValues[0]) {
                player.sendMessage(`§r[§bPurchase§r] §ePurchased ${r.formValues[0]} item(s)`);
                player.sendMessage(`§r[§bPurchase§r] §ePaid ${kounyuu_list_system1[player_Cash_Data[player.id].select_item][1] * r.formValues[0]} PAY`);
                player.playSound("random.toast", {
                    pitch: 1.7,
                    volume: 1.0
                });
                player.runCommand(`give @s ${kounyuu_list_system1[player_Cash_Data[player.id].select_item][2]} ${r.formValues[0]}`);
                player.runCommand(`scoreboard players remove @s money ${kounyuu_list_system1[player_Cash_Data[player.id].select_item][1] * r.formValues[0]}`);
            } else {
                player.sendMessage(`§r[§bPurchase§r] §4Insufficient money`);
                player.playSound("random.toast", {
                    pitch: 0.4,
                    volume: 1.0
                });
            }
        });
    });
break;
case 'Information':
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("Select an information service");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button("§0Addon Information\n§8Version", 'textures/items/haruphone1');
    form.button("§1HARUAddons§5 Official Website\n§5<<<§0Accessible via QR code", 'textures/ui/qr.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body(`§aAddon Name§r:§bHARUPhone1-EN\n§eVersion§r:§b2.5.2\n§cRelease Date§r:§b2025/05/12`);
                form.button(`§lBack`, 'textures/ui/icon_import.png');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //Back
                            HARUPhone1(player);
                            break;
                    }
                });
                break;
            case 2:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body(`§aHARUAddons§c Official Links\n§e-------------\n§l§eWebsite\n§r§aHomepage§5>>>\n§bhttps://harugames8686.github.io/HARUAddons/\n§r§aX§5>>>\n§bhttps://x.com/haru_addons`);
                form.button(`§lBack`, 'textures/ui/icon_import.png');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //Back
                            HARUPhone1(player);
                            break;
                    }
                });
                break;
        }
    });
break;
case 'Browser':
       var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("Select a service");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button("§1Page Search");
    form.button("§5Recommended Pages");
    form.button("§9Create Page§0/§5Edit§0/§sAdvertise");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                var browser = world.getDynamicProperty('browser');
                if (browser == undefined) {
                    var browser_system2 = [];
                } else {
                    var browser_system2 = JSON.parse(browser);
                }
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.textField("Enter Keyword", "Keyword Search");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body("Search Results");
                    var browser_cashdata1 = [];
                    for (let i = 0; i < browser_system2.length; i++) {
                        var domain_keyword_system1 = browser_system2[i][2].indexOf(`${r.formValues[0]}`);
                        if (domain_keyword_system1 !== -1) {
                            form.button(`§l${browser_system2[i][2]}\nAuthor:§r§5${browser_system2[i][0]}`);
                            browser_cashdata1[browser_cashdata1.length] = i;
                        }
                    }
                    if (browser_cashdata1[0] == undefined) {
                        player.sendMessage(`§r[§bBrowser§r] §aNo pages found`);
                        player.playSound("random.toast", {
                            pitch: 0.4,
                            volume: 1.0
                        });
                        return;
                    }
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        browser_system2[browser_cashdata1[response]][1] = browser_system2[browser_cashdata1[response]][1] + 1;
                        const browsersystem1 = JSON.stringify(browser_system2);
                        world.setDynamicProperty('browser', browsersystem1);
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l${browser_system2[browser_cashdata1[response]][3]}\n§e------------\n§rAuthor:§a${browser_system2[browser_cashdata1[response]][0]}\n§e§l------------\n§r${browser_system2[browser_cashdata1[response]][4]}\n\n${browser_system2[browser_cashdata1[response]][5]}\n\n${browser_system2[browser_cashdata1[response]][6]}\n\n${browser_system2[browser_cashdata1[response]][7]}`);
                        form.button(`Close`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                        });
                    });
                });
                break;
            case 2:
                var browser = world.getDynamicProperty('browser');
                if (browser == undefined) {
                    var browser_system2 = [];
                } else {
                    var browser_system2 = JSON.parse(browser);
                }
                if (browser_system2[0] == undefined) {
                    player.sendMessage(`§r[§bBrowser§r] §aNo pages found`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                browser_system2.sort((a, b) => (a[1] > b[1] ? -1 : 1));
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Recommended Pages");
                for (let i = 0; i < browser_system2.length; i++) {
                    if (i <= 7) {
                        form.button(`§l${browser_system2[i][2]}\n§rAuthor:§5${browser_system2[i][0]}`);
                    }
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§l${browser_system2[response][3]}\n§e------------\n§rAuthor:§a${browser_system2[response][0]}\n§e§l------------\n§r${browser_system2[response][4]}\n\n${browser_system2[response][5]}\n\n${browser_system2[response][6]}\n\n${browser_system2[response][7]}`);
                    form.button(`Close`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                    });
                });
                break;
            case 3:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Select a function");
                form.button(`§1Create New Page \n§5Page Posting Fee§r:§s${world.getDynamicProperty('browser_newpage_money')}`);
                form.button("§1Edit Existing Page");
                form.button("§4Delete Page");
                form.button(`§sAdvertise\n§r§8Pages created here can be advertised`);
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            if (world.getDynamicProperty('browser_newpage_money') == undefined) {
                                player.sendMessage(`§r[§bBrowser§r] §4Cannot create a new page because the admin has not completed the initial setup`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            var form = new ModalFormData();
                            form.title(`${config['main'][0]}`);
                            form.textField("Search Display Title", "Recommended to use easily searchable words");
                            form.textField("Page Title", "This will be in bold");
                            form.textField("Text 1", "Added below the title");
                            form.textField("Text 2", "Added below Text 1");
                            form.textField("Text 3", "Added below Text 2");
                            form.textField("Text 4", "Added below Text 3");
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                if (score >= world.getDynamicProperty('browser_newpage_money')) {
                                    var browser = world.getDynamicProperty('browser');
                                    if (browser == undefined) {
                                        var browser_system2 = [];
                                    } else {
                                        var browser_system2 = JSON.parse(browser);
                                    }
                                    browser_system2.push([player.name, 0, r.formValues[0], r.formValues[1], r.formValues[2], r.formValues[3], r.formValues[4], r.formValues[5]]);
                                    const browser_system3 = JSON.stringify(browser_system2);
                                    world.setDynamicProperty('browser', browser_system3);
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§aNotice§7(browser)§r] §ePaid ${world.getDynamicProperty('browser_newpage_money')} PAY"}]}`);
                                    player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_newpage_money')}`);
                                    player.sendMessage(`§r[§bBrowser§r] §aPage created successfully`);
                                    player.playSound("random.toast", {
                                        pitch: 1.7,
                                        volume: 1.0
                                    });
                                } else {
                                    player.sendMessage(`§r[§bBrowser§r] §4Insufficient money`);
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                }
                            });
                            break;
                        case 1:
                            var browser = world.getDynamicProperty('browser');
                            if (browser == undefined) {
                                var browser_system2 = [];
                            } else {
                                var browser_system2 = JSON.parse(browser);
                            }
                            var browser_cash = [];
                            for (let i = 0; i < browser_system2.length; i++) {
                                if (browser_system2[i][0] == player.name) {
                                    browser_cash.push([[i], browser_system2[i]]);
                                }
                            }
                            if (browser_cash[0] == undefined) {
                                player.sendMessage(`§r[§bBrowser§r] §aNo pages available to edit`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body("Select a page to edit");
                            for (let i = 0; i < browser_cash.length; i++) {
                                form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                            }
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                player_Cash_Data[player.id].browser_select = r.selection;
                                var form = new ModalFormData();
                                form.title(`${config['main'][0]}`);
                                form.textField("Search Display Title", `${browser_cash[player_Cash_Data[player.id].browser_select][1][2]}`);
                                form.textField("Page Title", `${browser_cash[player_Cash_Data[player.id].browser_select][1][3]}`);
                                form.textField("Text 1", `${browser_cash[player_Cash_Data[player.id].browser_select][1][4]}`);
                                form.textField("Text 2", `${browser_cash[player_Cash_Data[player.id].browser_select][1][5]}`);
                                form.textField("Text 3", `${browser_cash[player_Cash_Data[player.id].browser_select][1][6]}`);
                                form.textField("Text 4", `${browser_cash[player_Cash_Data[player.id].browser_select][1][7]}`);
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                    if (r.formValues[0] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][2] = r.formValues[0]; }
                                    if (r.formValues[1] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][3] = r.formValues[1]; }
                                    if (r.formValues[2] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][4] = r.formValues[2]; }
                                    if (r.formValues[3] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][5] = r.formValues[3]; }
                                    if (r.formValues[4] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][6] = r.formValues[4]; }
                                    if (r.formValues[5] != '') { browser_cash[player_Cash_Data[player.id].browser_select][1][7] = r.formValues[5]; }
                                    browser_system2[browser_cash[player_Cash_Data[player.id].browser_select][0][0]] = browser_cash[player_Cash_Data[player.id].browser_select][1];
                                    const browser_system3 = JSON.stringify(browser_system2);
                                    world.setDynamicProperty('browser', browser_system3);
                                    player.sendMessage(`§r[§bBrowser§r] §aPage edited successfully`);
                                    player.playSound("random.toast", {
                                        pitch: 1.7,
                                        volume: 1.0
                                    });
                                });
                            });
                            break;
                        case 2:
                            var browser = world.getDynamicProperty('browser');
                            if (browser == undefined) {
                                var browser_system2 = [];
                            } else {
                                var browser_system2 = JSON.parse(browser);
                            }
                            var browser_cash = [];
                            for (let i = 0; i < browser_system2.length; i++) {
                                if (browser_system2[i][0] == player.name) {
                                    browser_cash.push([[i], browser_system2[i]]);
                                }
                            }
                            if (browser_cash[0] == undefined) {
                                player.sendMessage(`§r[§bBrowser§r] §aNo pages available to delete`);
                                player.playSound("random.toast", {
                                    pitch: 0.4,
                                    volume: 1.0
                                });
                                return;
                            }
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body("Select a page to delete");
                            for (let i = 0; i < browser_cash.length; i++) {
                                form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                            }
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                browser_system2.splice(browser_cash[response][0][0], 1);
                                const browser_system3 = JSON.stringify(browser_system2);
                                world.setDynamicProperty('browser', browser_system3);
                                player.sendMessage(`§r[§bBrowser§r] §aPage deleted successfully`);
                                player.playSound("random.toast", {
                                    pitch: 1.7,
                                    volume: 1.0
                                });
                            });
                            break;
                        case 3:
                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body("Select a service");
                            form.button(`§1Advertise Page \n§5Advertising Fee§r:§s${world.getDynamicProperty('browser_performance_money')}§rPAY`);
                            form.button("§4Remove Advertisement");
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0:
                                        if (world.getDynamicProperty('browser_performance_money') == undefined) {
                                            player.sendMessage(`§r[§bBrowser§r] §4Cannot advertise because the admin has not completed the initial setup`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        var browser = world.getDynamicProperty('browser');
                                        if (browser == undefined) {
                                            var browser_system2 = [];
                                        } else {
                                            var browser_system2 = JSON.parse(browser);
                                        }
                                        var browser_cash = [];
                                        for (let i = 0; i < browser_system2.length; i++) {
                                            if (browser_system2[i][0] == player.name) {
                                                browser_cash.push([[i], browser_system2[i]]);
                                            }
                                        }
                                        if (browser_cash[0] == undefined) {
                                            player.sendMessage(`§r[§bBrowser§r] §aNo pages available to advertise`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("Select a page to advertise");
                                        for (let i = 0; i < browser_cash.length; i++) {
                                            form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                            if (score >= world.getDynamicProperty('browser_performance_money')) {
                                                var performance = world.getDynamicProperty('performance');
                                                if (performance == undefined) {
                                                    var performance_system2 = [];
                                                } else {
                                                    var performance_system2 = JSON.parse(performance);
                                                }
                                                var performance_cash_system2 = 0;
                                                for (let i = 0; i < performance_system2.length; i++) {
                                                    if (performance_system2[i][2] == browser_cash[response][1][2] && performance_system2[i][0] == browser_cash[response][1][0] && performance_system2[i][3] == browser_cash[response][1][3] && performance_system2[i][4] == browser_cash[response][1][4] && performance_system2[i][5] == browser_cash[response][1][5]) {
                                                        performance_cash_system2 = 1;
                                                    }
                                                }
                                                if (performance_cash_system2 == 1) {
                                                    player.sendMessage(`§r[§bBrowser§r] §4The selected page is already advertised`);
                                                    player.playSound("random.toast", {
                                                        pitch: 0.4,
                                                        volume: 1.0
                                                    });
                                                    return;
                                                }
                                                performance_system2.push(browser_cash[response][1]);
                                                const performance_system3 = JSON.stringify(performance_system2);
                                                world.setDynamicProperty('performance', performance_system3);
                                                player.sendMessage(`§r[§bBrowser§r] §ePaid ${world.getDynamicProperty('browser_performance_money')} PAY`);
                                                player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_performance_money')}`);
                                                player.sendMessage(`§r[§bBrowser§r] §aPage advertised successfully`);
                                                player.playSound("random.toast", {
                                                    pitch: 1.7,
                                                    volume: 1.0
                                                });
                                            } else {
                                                player.sendMessage(`§r[§bBrowser§r] §4Insufficient money`);
                                                player.playSound("random.toast", {
                                                    pitch: 0.4,
                                                    volume: 1.0
                                                });
                                            }
                                        });
                                        break;
                                    case 1:
                                        var browser = world.getDynamicProperty('performance');
                                        if (browser == undefined) {
                                            var browser_system2 = [];
                                        } else {
                                            var browser_system2 = JSON.parse(browser);
                                        }
                                        var browser_cash = [];
                                        for (let i = 0; i < browser_system2.length; i++) {
                                            if (browser_system2[i][0] == player.name) {
                                                browser_cash.push([[i], browser_system2[i]]);
                                            }
                                        }
                                        if (browser_cash[0] == undefined) {
                                            player.sendMessage(`§r[§bBrowser§r] §aNo advertisements available to delete`);
                                            player.playSound("random.toast", {
                                                pitch: 0.4,
                                                volume: 1.0
                                            });
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body("Select an advertisement to delete");
                                        for (let i = 0; i < browser_cash.length; i++) {
                                            form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            browser_system2.splice(browser_cash[response][0][0], 1);
                                            const browser_system3 = JSON.stringify(browser_system2);
                                            world.setDynamicProperty('performance', browser_system3);
                                            player.sendMessage(`§r[§bBrowser§r] §aAdvertisement deleted successfully`);
                                            player.playSound("random.toast", {
                                                pitch: 1.7,
                                                volume: 1.0
                                            });
                                        });
                                        break;
                                }
                            });
                            break;
                    }
                });
            break;
        };
    });     
break;
                case 'World system':
                    showMainUI(player);
                break;
case 'Claim':
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("Select an option");
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button("§9Send a Claim");
    form.button("§5View Received Claims");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                player_Cash_Data[player.id] = {};
                player_Cash_Data[player.id].players = world.getAllPlayers();
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Select a player to send the claim to");
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§5>>>§8${player_Cash_Data[player.id].players[i].id}`);
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection];
                    var form = new ModalFormData();
                    form.title(`${config['main'][0]}`);
                    form.textField("§eClaim Amount §r[Numbers only]", `0`);
                    form.textField("§aClaim Reason", `Reason`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        if (r.formValues[0] == '') {
                            player.sendMessage(`§r[§bClaim§r] §4Please set the claim amount`);
                            player.playSound("random.toast", {
                                pitch: 0.4,
                                volume: 1.0
                            });
                            return;
                        }
                        if (isNaN(r.formValues[0])) {
                            player.sendMessage(`§r[§bClaim§r] §4Please enter numbers only`);
                            player.playSound("random.toast", {
                                pitch: 0.4,
                                volume: 1.0
                            });
                            return;
                        }
                        if (r.formValues[0] < 0) {
                            player.sendMessage(`§r[§bClaim§r] §4Cannot set below 0`);
                            player.playSound("random.toast", {
                                pitch: 0.4,
                                volume: 1.0
                            });
                            return;
                        }
                        if (Claim[player_Cash_Data[player.id].select_player.name] == undefined) {
                            Claim[player_Cash_Data[player.id].select_player.name] = [];
                        }
                        Claim[player_Cash_Data[player.id].select_player.name].push([player.name, Number(r.formValues[0]), r.formValues[1]]);

                        //Messages
                        player.sendMessage(`§r[§bClaim§r] §aClaim sent to §a${player_Cash_Data[player.id].select_player.name}`);
                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§bClaim§r] §aReceived a claim from §a${player.name} §rfor §2${r.formValues[1]}`);
                        player.playSound("random.toast", {
                            pitch: 1.5,
                            volume: 1.0
                        });
                        player_Cash_Data[player.id].select_player.playSound("random.toast", {
                            pitch: 1.5,
                            volume: 1.0
                        });
                    });
                });
                break;
            case 2:
                if (Claim[player.name] == undefined) {
                    player.sendMessage(`§r[§bClaim§r] §aNo received claims found`);
                    player.playSound("random.toast", {
                        pitch: 0.4,
                        volume: 1.0
                    });
                    return;
                }
                player_Cash_Data[player.id] = {};
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("Select a claim to process");
                for (let i = 0; i < Claim[player.name].length; i++) {
                    form.button(`§9${Claim[player.name][i][2]}\n§0Sender:§s${Claim[player.name][i][0]}`);
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    player_Cash_Data[player.id].select = r.selection;
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§lClaim Details\n§rReason:§a${Claim[player.name][player_Cash_Data[player.id].select][2]}\n§rAmount:§a${Claim[player.name][player_Cash_Data[player.id].select][1]}\n§rSender:§a${Claim[player.name][player_Cash_Data[player.id].select][0]}`);
                    form.button("§1Approve");
                    form.button("§5Deny");
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                player_Cash_Data[player.id].claim_stop = false;
                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                    if (Claim[player.name][player_Cash_Data[player.id].select][0] === player_Cash_Data[player.id].players[i].name) {
                                        player_Cash_Data[player.id].claim_stop = true;
                                    }
                                }
                                if (player_Cash_Data[player.id].claim_stop == false) {
                                    player.sendMessage(`§r[§bClaim§r] §4Processing stopped because the other player is offline`);
                                    player.playSound("random.toast", {
                                        pitch: 0.4,
                                        volume: 1.0
                                    });
                                    return;
                                }
                                const score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                //Execute only if balance is sufficient
                                if (score >= Claim[player.name][player_Cash_Data[player.id].select][1]) {
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bClaim§r] §aClaim approved, §e${Claim[player.name][player_Cash_Data[player.id].select][1]} PAY sent"}]}`);
                                    player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§bClaim§r] §a${player.name} approved the claim for ${Claim[player.name][player_Cash_Data[player.id].select][2]}, §e${Claim[player.name][player_Cash_Data[player.id].select][1]} PAY received"}]}`);
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`);
                                    player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`);
                                    player.runCommand(`scoreboard players add @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                    player.runCommand(`scoreboard players remove @a[name="${player.name}", scores={money=${Claim[player.name][player_Cash_Data[player.id].select][1]}..}] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                    Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                }
                                break;
                            case 1:
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bClaim§r] §aClaim §4denied"}]}`);
                                player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§bClaim§r] §a${player.name} §4denied the claim for ${Claim[player.name][player_Cash_Data[player.id].select][2]}"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`);
                                player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`);
                                Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                break;
                        }
                    });
                });
                break;
        }
    });
break;
case 'HARUAssistant':
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§aSelect a Chatbot`);
    form.button(`§lBack`, 'textures/ui/icon_import.png');
    form.button("§1Insight-4\n§8Most Intelligent");
    form.button("§1Insight-3");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //Back
                HARUPhone1(player);
                break;
            case 1:
                chatLoop4(player);
                break;
            case 2:
                chatLoop3(player);
                break;
        }
    });
break;
                case 'Map':
                    openUserNavigationForm(player)
                break;
                case 'Operator Controller':
                    Operator_Controller(player);
                break;
                default:
            }
        })
    }
  })
}
