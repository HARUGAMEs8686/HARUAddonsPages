export const config = {
    "main" : [
        //スマホ名
        '§1HARUPhone1'
    ],
    "AppName" : [
        //アプリ表示名
        'Advertisement',
        'HARUPAY',
        'Quick',
        'Mail',
        'Open Chat',
        'Job Request & Search',
        'Advance',
        'Exchange',
        'Purchase',
        'Information',
        'Browser',
        'World system',
        'Claim',
        'Operator Controller',
        'HARUAssistant',
        'External Applications',
        'HARU-X Editor\n§0BETA',
        'Map'
    ],
    "AppData" : [
        'Unset',
        'Advertisement',
        'External Applications',
        'HARUPAY',
        'Quick',
        'Mail',
        'Open Chat',
        'Job Request & Search',
        'Advance',
        'Exchange',
        'Purchase',
        'Information',
        'Browser',
        'World system',
        'Claim',
        'HARUAssistant',
        'Map',
        'Operator Controller'
    ]
}