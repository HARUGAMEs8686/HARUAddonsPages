import { world, system, ItemStack } from '@minecraft/server';

export function First_grant() {
    world.afterEvents.playerSpawn.subscribe(event => {
        const player = event.player;

        if (event.initialSpawn) {
            if (!player.hasTag('Camera_Member')) {
                system.runTimeout(() => {
                    try {
                        // ネイティブAPIで処理
                        player.getComponent('inventory').container.addItem(new ItemStack('additem:camera', 1));
                        player.addTag('Camera_Member');
                    } catch (error) {
                        console.warn(`自動付与に失敗しました:対象${player.name} 再リクエストします`);
                        system.runTimeout(() => {
                            try {
                                player.getComponent('inventory').container.addItem(new ItemStack('additem:camera', 1));
                                player.addTag('Camera_Member');
                            } catch (retryError) {
                                console.warn(`リクエスト実行に失敗しました ${player.name}: ${retryError}`);
                            }
                        }, 70);
                    }
                }, 10);
            }
        }
    });
}
