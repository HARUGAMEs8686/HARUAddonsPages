import { world, system, Player, GameMode } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

import { playerHARUAppsOpen } from './main';

// ==========================================
// 設定
// ==========================================
const DB_KEY_ALL = 'cam_sys_v2_all_'; // 全員の個人保存用（表示は自分のみ）
const DB_KEY_PUBLIC = 'cam_sys_v2_pub_'; // 共有ギャラリー用（最大15件）

const CHUNK_SIZE = 30000;
const SHARED_MAX_COUNT = 20; // 共有ギャラリーの最大数
const MOVE_THRESHOLD = 0.5; // 解除に必要な高さの移動量（ブロック数）

// 視点移動中のプレイヤーの状態を保存するマップ
const viewingPlayers = new Map();

function getCoordinateString(loc) {
    // 設定を確認 (trueなら隠す)
    const isHidden = world.getDynamicProperty('cam_setting_hide_coords') ?? false;

    if (isHidden) {
        return '§7???, ???, ??? (非表示)§r';
    } else {
        return `§e${Math.round(loc.x)}, ${Math.round(loc.y)}, ${Math.round(loc.z)}§r`;
    }
}

// ==========================================
// データベース管理 (キー指定対応版)
// ==========================================
class LargeStorage {
    static save(data, prefix) {
        try {
            const jsonString = JSON.stringify(data);
            const totalChunks = Math.ceil(jsonString.length / CHUNK_SIZE);
            world.setDynamicProperty(`${prefix}meta`, totalChunks);
            for (let i = 0; i < totalChunks; i++) {
                const chunk = jsonString.substring(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
                world.setDynamicProperty(`${prefix}data_${i}`, chunk);
            }
            // 古いチャンクの削除
            let cleanupIndex = totalChunks;
            while (world.getDynamicProperty(`${prefix}data_${cleanupIndex}`) !== undefined) {
                world.setDynamicProperty(`${prefix}data_${cleanupIndex}`, undefined);
                cleanupIndex++;
            }
        } catch (e) {
            console.warn('Save Error:', e);
        }
    }

    static load(prefix) {
        try {
            const totalChunks = world.getDynamicProperty(`${prefix}meta`);
            if (typeof totalChunks !== 'number') return [];
            let jsonString = '';
            for (let i = 0; i < totalChunks; i++) {
                const chunk = world.getDynamicProperty(`${prefix}data_${i}`);
                if (chunk) jsonString += chunk;
            }
            return jsonString ? JSON.parse(jsonString) : [];
        } catch (e) {
            return [];
        }
    }
}

// ゲームモード取得ヘルパー
function getPlayerGamemode(player) {
    const modes = [GameMode.survival, GameMode.creative, GameMode.adventure, GameMode.spectator];
    for (const mode of modes) {
        const players = world.getPlayers({ name: player.name, gameMode: mode });
        if (players.length > 0) return mode;
    }
    return GameMode.survival;
}

// ==========================================
// 日付フォーマット用ヘルパー (JST変換)
// ==========================================
function getJSTDateString(timestamp) {
    if (!timestamp) return '---';

    // 保存されたタイムスタンプ(UTC想定)に9時間(ミリ秒)を足す
    const jstOffset = 9 * 60 * 60 * 1000;
    const date = new Date(timestamp + jstOffset);

    // UTCメソッドを使って取得することで、サーバーのローカルタイムゾーン設定を無視して
    // 純粋に「元の時間 + 9時間」の日時文字列を作成する
    const Y = date.getUTCFullYear();
    const M = (date.getUTCMonth() + 1).toString().padStart(2, '0');
    const D = date.getUTCDate().toString().padStart(2, '0');
    const h = date.getUTCHours().toString().padStart(2, '0');
    const m = date.getUTCMinutes().toString().padStart(2, '0');

    return `${Y}/${M}/${D} ${h}:${m}`;
}

// ==========================================
// メインUIロジック
// ==========================================

export function showMainMenu(player) {
    const form = new ActionFormData().title('§1カメラ').body('>>> §e選択してください');
    if (playerHARUAppsOpen[player.id]) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§0写真を記録', 'textures/ui/camera-yo');
    form.button('§1マイギャラリー', 'textures/ui/bubble_empty');
    form.button('§4共有ギャラリー', 'textures/ui/bubble_empty');

    form.show(player).then(res => {
        if (res.canceled) return;
        switch (res.selection) {
            case 0:
                // 戻る処理
                if (playerHARUAppsOpen[player.id]) {
                    player.runCommand('scriptevent haruphone1:apps');
                }
                break;
            case 1:
                takePhotoUI(player);
                break;
            case 2:
                showMyGallery(player);
                break;
            case 3:
                showPublicGallery(player);
                break;
        }
    });
}

function takePhotoUI(player) {
    const modal = new ModalFormData()
        .title('§0保存')
        .textField('§a保存すると現在見ている方向の視点がカメラとして保存されます\n\n§e写真の名前', '例: 絶景スポット', `写真 #${Math.floor(Math.random() * 999)}`)
        .submitButton(`§0保存`);

    modal.show(player).then(res => {
        if (res.canceled) {
            showMainMenu(player);
            return;
        }
        savePhoto(player, res.formValues[0]);
    });
}

function savePhoto(player, name) {
    const photos = LargeStorage.load(DB_KEY_ALL);
    const loc = player.location;
    const rot = player.getRotation();

    const newPhoto = {
        id: Date.now().toString() + Math.random().toString().slice(2, 5), // 一意のID
        name: name,
        owner: player.name,
        location: { x: loc.x, y: loc.y, z: loc.z, dimensionId: player.dimension.id },
        rotation: { x: rot.x, y: rot.y },
        timestamp: Date.now(), // 生のタイムスタンプを保存
    };

    // 全データリストの先頭に追加
    photos.unshift(newPhoto);
    LargeStorage.save(photos, DB_KEY_ALL);

    player.sendMessage(`[§bカメラ§r] §aマイギャラリーに記録しました: ${name}`);
    player.playSound('random.screenshot');
}

// ==========================================
// マイギャラリー (自分の写真だけ表示)
// ==========================================
function showMyGallery(player) {
    const allPhotos = LargeStorage.load(DB_KEY_ALL);
    // 自分の名前と一致するものだけを抽出
    const myPhotos = allPhotos.filter(p => p.owner === player.name);

    if (myPhotos.length === 0) {
        player.sendMessage('[§bカメラ§r] §cあなたの写真はまだありません');
        return;
    }

    const form = new ActionFormData().title('§1マイギャラリー').body(`所有数: ${myPhotos.length}枚\n>>> §e選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    // ボタン表示に日付を追加
    myPhotos.forEach(p => {
        const dateStr = getJSTDateString(p.timestamp);
        form.button(`§0${p.name}\n§8${dateStr}`, 'textures/ui/bubble_empty');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection == 0) {
            showMainMenu(player);
            return;
        }
        // 選択した自分の写真の詳細へ
        showMyPhotoOptions(player, myPhotos[res.selection - 1]);
    });
}

function showMyPhotoOptions(player, photo) {
    const dateStr = getJSTDateString(photo.timestamp);
    const coordStr = getCoordinateString(photo.location);
    const form = new ActionFormData()
        .title(`§0${photo.name}`)
        .body(`§r撮影場所: ${coordStr}\n` + `§r撮影日時: §b${dateStr}`)
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§5見る', 'textures/ui/bubble_empty')
        .button('§4投稿', 'textures/ui/bubble_empty')
        .button('§0削除', 'textures/ui/bubble_empty');

    form.show(player).then(res => {
        if (res.canceled) return;
        switch (res.selection) {
            case 0:
                showMyGallery(player);
                break;
            case 1:
                viewPhoto(player, photo);
                break;
            case 2:
                confirmShareToPublic(player, photo);
                break;
            case 3:
                deleteMyPhoto(player, photo.id);
                break;
        }
    });
}

// ==========================================
// 共有ギャラリー (最大15件・全員閲覧可)
// ==========================================
function showPublicGallery(player) {
    const publicPhotos = LargeStorage.load(DB_KEY_PUBLIC);

    if (publicPhotos.length === 0) {
        player.sendMessage('[§bカメラ§r] §c共有された写真はまだありません');
        return;
    }

    const form = new ActionFormData().title('§4共有ギャラリー').body(`最新の${SHARED_MAX_COUNT}件を表示中\n>>> §e選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    // ボタン表示に日付を追加
    publicPhotos.forEach(p => {
        const dateStr = getJSTDateString(p.timestamp);
        form.button(`§0${p.name}\n§1${p.owner} §r| §8${dateStr}`, 'textures/ui/bubble_empty');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection == 0) {
            showMainMenu(player);
            return;
        }
        showPublicPhotoOptions(player, publicPhotos[res.selection - 1]);
    });
}

function showPublicPhotoOptions(player, photo) {
    const dateStr = getJSTDateString(photo.timestamp);
    const coordStr = getCoordinateString(photo.location);

    const form = new ActionFormData()
        .title(`§4${photo.name}`)
        .body(`投稿者: §a${photo.owner}\n` + `§r座標: ${coordStr}\n` + `§r撮影日時: §b${dateStr}`)
        .button(`§l戻る`, 'textures/ui/icon_import.png') 
        .button('§5見る', 'textures/ui/bubble_empty'); 

    form.show(player).then(res => {
        if (res.canceled) return;
        
        // ボタンの選択に応じて処理を分岐
        switch (res.selection) {
            case 0:
                showPublicGallery(player);
                break;
            case 1:
                viewPhoto(player, photo);
                break;
        }
    });
}

// ==========================================
// 共有処理 (投稿ロジック)
// ==========================================
function confirmShareToPublic(player, photo) {
    const form = new ActionFormData().title('§4共有の確認').body(`§e"${photo.name}"§r を共有ギャラリーに投稿しますか？\n\n§7※共有ギャラリーは最大${SHARED_MAX_COUNT}件まで保存され、新しいものが追加されると古いものは消えていきます。`).button('§1投稿', 'textures/ui/bubble_empty').button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) {
            showMyPhotoOptions(player, photo);
            return;
        }
        if (res.selection === 0) {
            executeShareToPublic(player, photo);
        }
    });
}

function executeShareToPublic(player, photo) {
    const publicPhotos = LargeStorage.load(DB_KEY_PUBLIC);

    const isAlreadyShared = publicPhotos.some(p => p.id === photo.id);

    if (isAlreadyShared) {
        player.sendMessage(`[§bカメラ§r] §cこの写真は既に共有ギャラリーに投稿されています`);
        showMyPhotoOptions(player, photo);
        return;
    }

    const sharedPhoto = { ...photo, sharedAt: Date.now() };

    // 先頭に追加
    publicPhotos.unshift(sharedPhoto);

    // 最大数を超えたら後ろから削除
    if (publicPhotos.length > SHARED_MAX_COUNT) {
        publicPhotos.length = SHARED_MAX_COUNT; // 配列を切り詰める
    }

    LargeStorage.save(publicPhotos, DB_KEY_PUBLIC);

    player.sendMessage(`[§bカメラ§r] §a共有ギャラリーに投稿しました`);
    player.playSound('random.levelup');
    showPublicGallery(player);
}

// ==========================================
// 閲覧モード (共通)
// ==========================================
function viewPhoto(player, photo) {
    const DP_KEY_VIEWING = `cam_viewing_${player.id}`;
    const targetLoc = { x: photo.location.x, y: photo.location.y + 2, z: photo.location.z };
    const targetRot = { x: photo.rotation.x, y: photo.rotation.y };

    const originalState = {
        location: player.location, // 戻る場所
        dimension: player.dimension,
        gamemode: getPlayerGamemode(player),
        startTick: system.currentTick,
        viewingY: targetLoc.y, // 閲覧中の基準の高さ
    };

    // ワールドを閉じても復元できるよう、DynamicPropertyに状態を保存
    const persistentState = {
        location: { x: originalState.location.x, y: originalState.location.y, z: originalState.location.z },
        dimensionId: originalState.dimension.id,
        gamemode: originalState.gamemode,
    };
    world.setDynamicProperty(DP_KEY_VIEWING, JSON.stringify(persistentState));

    viewingPlayers.set(player.id, originalState);

    // スペクテイターへ変更
    player.setGameMode(GameMode.spectator);

    const targetDimension = world.getDimension(photo.location.dimensionId);
    if (!targetDimension) {
        player.sendMessage('[§bカメラ§r] §cディメンションが見つかりません');
        // 保存したプロパティとMapを削除し、元の状態に戻す
        world.setDynamicProperty(DP_KEY_VIEWING, undefined);
        viewingPlayers.delete(player.id);
        player.setGameMode(originalState.gamemode);
        return;
    }

    player.teleport(targetLoc, { dimension: targetDimension, rotation: targetRot });

    player.camera.setCamera('minecraft:free', {
        location: targetLoc,
        rotation: targetRot,
        easeOptions: { easeTime: 0, easeType: 'Linear' },
    });

    player.sendMessage('[§bカメラ§r] §e上昇または下降(ジャンプ/スニーク)で戻ります');
    player.playSound('random.orb');

    const runId = system.runInterval(() => {
        if (!player.isValid()) {
            system.clearRun(runId);
            viewingPlayers.delete(player.id);
            return;
        }

        const state = viewingPlayers.get(player.id);
        if (!state || system.currentTick - state.startTick < 30) return;

        const currentY = player.location.y;
        const diffY = Math.abs(currentY - state.viewingY); // 高さのズレを計算

        if (diffY > MOVE_THRESHOLD) {
            exitPhotoView(player, runId);
        } else {
            // アクションバーの表示も変更
            player.onScreenDisplay.setActionBar('§e上昇/下降して終了');
        }
    }, 2);
}

function exitPhotoView(player, runId) {
    system.clearRun(runId);
    player.camera.clear();
    player.onScreenDisplay.setActionBar('');

    const state = viewingPlayers.get(player.id);
    if (state) {
        player.teleport(state.location, { dimension: state.dimension });
        player.setGameMode(state.gamemode);
        viewingPlayers.delete(player.id);
    } else {
        player.setGameMode(GameMode.survival);
    }

    // 正常に終了したのでDynamicPropertyを削除
    const DP_KEY_VIEWING = `cam_viewing_${player.id}`;
    world.setDynamicProperty(DP_KEY_VIEWING, undefined);
}

// ==========================================
// 削除機能 (マイギャラリー用)
// ==========================================
function deleteMyPhoto(player, photoId) {
    let photos = LargeStorage.load(DB_KEY_ALL);
    // IDが一致しないものだけ残す
    const newPhotos = photos.filter(p => p.id !== photoId);

    // 写真が見つかったか確認（念の為）
    if (photos.length === newPhotos.length) {
        player.sendMessage('[§bカメラ§r] §c削除対象が見つかりませんでした');
        return;
    }

    LargeStorage.save(newPhotos, DB_KEY_ALL);
    player.sendMessage('[§bカメラ§r] §c写真を削除しました');
    showMyGallery(player);
}

//設定UI
export function showSettingsMenu(player) {
    const isHidden = world.getDynamicProperty('cam_setting_hide_coords') ?? false;

    const modal = new ModalFormData().title('§1カメラ設定').toggle('§a座標を表示', !isHidden).submitButton('§0決定');

    modal.show(player).then(res => {
        if (res.canceled) return;

        const showCoords = res.formValues[0];
        const newHideSetting = !showCoords;

        world.setDynamicProperty('cam_setting_hide_coords', newHideSetting);

        if (newHideSetting) {
            player.sendMessage('§r[§bカメラ§r] §c設定を更新: 座標を「非表示」にしました');
        } else {
            player.sendMessage('§r[§bカメラ§r] §a設定を更新: 座標を「表示」にしました');
        }
    });
}

// ==========================================
// 退出・再参加時の不具合対策
// ==========================================
world.afterEvents.playerSpawn.subscribe(event => {
    const { player } = event;
    const DP_KEY_VIEWING = `cam_viewing_${player.id}`;

    system.runTimeout(() => {
        const stateJSON = world.getDynamicProperty(DP_KEY_VIEWING);

        if (typeof stateJSON === 'string') {
            try {
                const state = JSON.parse(stateJSON);
                const dimension = world.getDimension(state.dimensionId);

                if (dimension) {
                    player.teleport(state.location, { dimension: dimension });
                } else {
                    console.warn(`[CameraSystem] Failed to restore ${player.name}: Dimension "${state.dimensionId}" not found.`);
                }
                player.setGameMode(state.gamemode);

                player.camera.clear();
                player.onScreenDisplay.setActionBar('');
                viewingPlayers.delete(player.id);

                world.setDynamicProperty(DP_KEY_VIEWING, undefined);

                player.sendMessage('[§bカメラ§r] §e閲覧状態が正常にリセットされました');
            } catch (e) {
                world.setDynamicProperty(DP_KEY_VIEWING, undefined);
            }
        }
    }, 20); 
});
