import { world, system } from '@minecraft/server';

import { showMainMenu, showSettingsMenu } from './camera';

import { First_grant } from './First_grant';

export var playerHARUAppsOpen = {};

const RACE_EVENT_ID = 'haruapps:camera';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            showMainMenu(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

//アイテムでの実行
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === 'additem:camera') {
        const player = eventData.source;
        system.run(() => {
            playerHARUAppsOpen[player.id] = false;
            showMainMenu(player);
        });
    }
});

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'camera:s') {
            showSettingsMenu(player);
        }
    });
});

First_grant();
