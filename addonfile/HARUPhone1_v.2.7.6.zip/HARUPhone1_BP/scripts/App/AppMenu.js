import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';
import { HARUPhone1 } from '../itemrun/haruphone1';
import { LiteFrameA } from './LiteFrame_engine/LiteFrameA';

var player_Cash_Data = {};
export function App(player) {
    system.run(() => {
        player_Cash_Data[player.id] = {};
        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        //AppDataを取得
        player_Cash_Data[player.id].AppData = world.getDynamicProperty(`AppData`);
        if (player_Cash_Data[player.id].AppData == undefined) {
            player_Cash_Data[player.id].AppData = [];
        } else {
            player_Cash_Data[player.id].AppData = JSON.parse(player_Cash_Data[player.id].AppData);
        }
        player_Cash_Data[player.id].AppDataList = [];
        for (let i = 0; i < player_Cash_Data[player.id].AppData.length; i++) {
            var AppDataName = JSON.parse(world.getDynamicProperty(player_Cash_Data[player.id].AppData[i][0])).ApplicationName;
            player_Cash_Data[player.id].AppDataList.push([AppDataName, player_Cash_Data[player.id].AppData[i][1]]);
        }
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}`);
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        for (let i = 0; i < player_Cash_Data[player.id].AppDataList.length; i++) {
            form.button(`${player_Cash_Data[player.id].AppDataList[i][0]}`, `textures/ui/haruapp2`);
        }
        form.show(player).then(r => {
            if (r.canceled) return;
            if (r.selection == 0) {
                HARUPhone1(player);
                return;
            }
            if (player_Cash_Data[player.id].AppDataList[r.selection - 1][1] == 'LiteFrameA') {
                LiteFrameA(JSON.parse(world.getDynamicProperty(player_Cash_Data[player.id].AppData[r.selection - 1][0])), player);
            }
        });
    });
}
