import { world, system, ItemStack } from '@minecraft/server';

export function First_grant() {
    world.afterEvents.playerSpawn.subscribe(event => {
        const player = event.player;

        // 初回スポーンの場合のみ処理
        if (event.initialSpawn) {
            // システムが有効かつプレイヤーがHARUPAY_Memberタグを持っていない場合
            if (world.getDynamicProperty('money_start_system1') === 1 && !player.hasTag('HARUPAY_Member')) {
                if (world.getDynamicProperty('money_start_system2') == 0 || world.getDynamicProperty('money_start_system2') == undefined) {
                    system.runTimeout(() => {
                        try {
                            // 必要なプロパティをキャッシュ
                            const startMoney = world.getDynamicProperty('start_money') || 0;

                            // ネイティブAPIで処理
                            player.getComponent('inventory').container.addItem(new ItemStack('additem:haruphone1', 1));
                            player.runCommand(`scoreboard players set @s money ${startMoney}`);

                            player.sendMessage(`§r[§bHARUPhone1§r] §aようこそ！§eHARUPhone1を開いてみましょう！`);
                            player.playSound('random.toast', {
                                pitch: 1.7,
                                volume: 1.0,
                            });
                            player.addTag('HARUPAY_Member');
                        } catch (error) {
                            console.warn(`自動付与に失敗しました:対象${player.name} 再リクエストします`);
                            system.runTimeout(() => {
                                try {
                                    const startMoney = world.getDynamicProperty('start_money') || 0;
                                    player.getComponent('inventory').container.addItem(new ItemStack('additem:haruphone1', 1));
                                    player.runCommand(`scoreboard players set @s money ${startMoney}`);
                                    player.sendMessage(`§r[§bHARUPhone1§r] §aようこそ！§eHARUPhone1を開いてみましょう！`);
                                    player.playSound('random.toast', {
                                        pitch: 1.7,
                                        volume: 1.0,
                                    });
                                    player.addTag('HARUPAY_Member');
                                } catch (retryError) {
                                    console.warn(`リクエスト実行に失敗しました ${player.name}: ${retryError}`);
                                }
                            }, 70);
                        }
                    }, 10);
                }
            }
        }
    });
}