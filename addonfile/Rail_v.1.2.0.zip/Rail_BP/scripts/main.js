import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

// 運転状態と設定を保存するMap
const trainData = new Map();

// --- 設定値 ---
const FUEL_PER_COAL = 600; // 石炭1個あたりの燃焼時間

world.beforeEvents.itemUse.subscribe(event => {
    const player = event.source;
    const item = event.itemStack;

    if (item.typeId === 'haruaddons:rail') {
        const ownerId = item.getDynamicProperty('rail:licenseOwnerId');
        const expiryTimestamp = item.getDynamicProperty('rail:licenseExpiry');

        const licenseEnabled = world.getDynamicProperty('rail:license_enabled') ?? false;

        if (licenseEnabled) {
            if (expiryTimestamp) {
                const now = Date.now();
                if (now > expiryTimestamp) {
                    system.run(() => {
                        player.playSound('note.bass');
                        player.sendMessage('[§bRail§r] §7この免許は有効期限が切れています');
                    });
                    event.cancel = true;
                    return;
                }
            }

            if (!ownerId || ownerId !== player.id) {
                system.run(() => {
                    player.playSound('note.bass');
                    player.sendMessage('[§bRail§r] §7この免許(Rail Panel)はあなたのものではありません');
                });
                event.cancel = true;
                return;
            }
        }

        event.cancel = true;
        system.run(() => {
            showTrainPanel(player, ownerId, expiryTimestamp);
        });
    }
});

function showTrainPanel(player, ownerId, expiryTimestamp) {
    const data = trainData.get(player.id);
    const isDriving = !!data;

    let dateStr = '§7無期限';
    if (expiryTimestamp) {
        const d = new Date(expiryTimestamp);
        dateStr = `§e${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;
    }

    const form = new ActionFormData();
    form.title('§1トロッコ免許');
    form.body(`§rID: §b${ownerId || player.id}\n§r期限: ${dateStr}`);

    if (isDriving) {
        form.button('§4運転モードを終了する', 'textures/ui/Fpowerbutton');
        form.button('§0周辺のトロッコを連結/解除', 'textures/ui/Fchain');
    } else {
        form.button('§1運転モードを開始する', 'textures/ui/Fpowerbutton');
    }
    form.button('§0操作アイテム一式を受け取る', 'textures/items/powera');

    form.show(player)
        .then(res => {
            if (res.canceled) return;
            const sel = res.selection;

            if (isDriving) {
                if (sel === 0) {
                    trainData.delete(player.id);
                    player.sendMessage('§c運転モードを終了しました');
                    player.onScreenDisplay.setActionBar('');
                } else if (sel === 1) {
                    if (data.linkedCarts && data.linkedCarts.length > 0) {
                        data.linkedCarts = [];
                        player.sendMessage('§eトロッコの連結を解除しました');
                    } else {
                        linkNearbyCarts(player, data);
                    }
                } else if (sel === 2) {
                    giveControlItems(player);
                }
            } else {
                if (sel === 0) {
                    const allowNether = world.getDynamicProperty('rail:allow_nether') ?? true;
                    if (player.dimension.id === 'minecraft:nether' && !allowNether) {
                        player.sendMessage('[§bRail§r] §cこの次元での運転は出来ません');
                        return;
                    }
                    const cart = getRidingCart(player);
                    if (!cart) {
                        player.sendMessage('[§bRail§r] トロッコに乗ってから開始してください');
                        return;
                    }
                    const newData = {
                        player: player,
                        cart: cart,
                        linkedCarts: [],
                        posHistory: [],
                        fuelTime: 0,
                        lastPos: cart.location,
                        lastDir: null,
                        displaySpeed: 0,
                        currentPower: 0, // 滑らかな加減速用
                        currentBoost: 0, // 滑らかな加減速用
                    };
                    trainData.set(player.id, newData);
                    player.sendMessage('[§bRail§r] §e運転モードを開始しました');
                    linkNearbyCarts(player, newData);
                } else if (sel === 1) {
                    giveControlItems(player);
                }
            }
        })
        .catch(e => {});
}

function getRidingCart(player, previousCart) {
    if (previousCart && previousCart.isValid()) {
        const riders = previousCart.getComponent('minecraft:rideable')?.getRiders();
        if (riders && riders.some(r => r.id === player.id)) {
            return previousCart;
        }
    }

    const nearby = player.dimension.getEntities({ location: player.location, maxDistance: 10 });
    for (const ent of nearby) {
        if (ent.typeId === 'minecraft:minecart' || ent.typeId === 'minecraft:chest_minecart') {
            const riders = ent.getComponent('minecraft:rideable')?.getRiders();
            if (riders && riders.length > 0 && riders[0].id === player.id) {
                return ent;
            }
        }
    }
    return null;
}

function linkNearbyCarts(player, data) {
    const searchRange = world.getDynamicProperty('rail:link_distance') ?? 10.0;

    // トロッコだけを確実に狙って検索（取りこぼし防止）
    const normalCarts = player.dimension.getEntities({ location: player.location, maxDistance: searchRange, type: 'minecraft:minecart' });
    const chestCarts = player.dimension.getEntities({ location: player.location, maxDistance: searchRange, type: 'minecraft:chest_minecart' });

    const nearby = [...normalCarts, ...chestCarts];
    const cartsWithDist = [];

    for (const ent of nearby) {
        if (ent.id !== data.cart.id) {
            const dx = ent.location.x - player.location.x;
            const dy = ent.location.y - player.location.y;
            const dz = ent.location.z - player.location.z;
            const d = Math.hypot(dx, dy, dz);
            cartsWithDist.push({ id: ent.id, dist: d });
        }
    }

    cartsWithDist.sort((a, b) => a.dist - b.dist);
    const cartsToLink = cartsWithDist.map(item => item.id);

    if (cartsToLink.length > 0) {
        data.linkedCarts = cartsToLink;
        player.sendMessage(`>>> §b${cartsToLink.length}両§aのトロッコを連結しました §r(範囲: §b${searchRange}§rブロック)`);
    } else {
        player.sendMessage('>>> §e周囲に連結できるトロッコがありません');
    }
}

function giveControlItems(player) {
    const inv = player.getComponent('inventory')?.container;
    if (!inv) return;

    const requiredItems = ['haruaddons:powera', 'haruaddons:powerb', 'haruaddons:powerc', 'haruaddons:brake'];
    const ownedItems = new Set();

    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (item) {
            ownedItems.add(item.typeId);
        }
    }

    let givenCount = 0;

    for (const id of requiredItems) {
        if (!ownedItems.has(id)) {
            if (inv.emptySlotsCount === 0) {
                player.sendMessage('[§bRail§r] §cインベントリに空きがない為アイテムを受け取れません');
                break;
            }
            inv.addItem(new ItemStack(id, 1));
            givenCount++;
        }
    }

    if (givenCount > 0) {
        player.sendMessage(`§a不足していた操作アイテムを ${givenCount}個 受け取りました`);
    } else {
        player.sendMessage('§eすでに全ての操作アイテムを持っています');
    }
}

// --- メインループ (毎Tick処理) ---
system.runInterval(() => {
    const SPEED_MULTIPLIER = world.getDynamicProperty('rail:speed_multiplier') ?? 1.0;

    for (const [playerId, data] of trainData.entries()) {
        if (data.tickCount === undefined) data.tickCount = 0;
        data.tickCount++;
        const player = data.player;

        if (!player || !player.isValid()) {
            trainData.delete(playerId);
            continue;
        }

        // ネザー制限のリアルタイムチェック
        const allowNether = world.getDynamicProperty('rail:allow_nether') ?? true;
        if (player.dimension.id === 'minecraft:the_nether' && !allowNether) {
            trainData.delete(playerId);
            player.sendMessage('§cネザーでの運転が禁止されているため、モードを終了しました');
            player.onScreenDisplay.setActionBar('');
            continue;
        }

        const cart = getRidingCart(player, data.cart);

        if (!cart) {
            data.loseTick = (data.loseTick || 0) + 1;
            if (data.loseTick > 5) {
                trainData.delete(playerId);
                player.sendMessage('§eトロッコから降りたため、運転モードを終了しました');
                player.onScreenDisplay.setActionBar('');
            }
            continue;
        }
        data.loseTick = 0;
        data.cart = cart;

        const loc = cart.location;

        // ==========================================
        // 1. スピード調整アイテムの取得
        // ==========================================
        const inv = player.getComponent('inventory')?.container;
        if (!inv) continue;
        const handItem = inv.getItem(player.selectedSlotIndex);

        let targetPower = 0;
        let targetBoost = 0;
        let powerName = '§7N (惰性)';
        let currentAccelRate = 0.03 / Math.sqrt(Math.max(1, SPEED_MULTIPLIER));

        if (handItem) {
            switch (handItem.typeId) {
                case 'haruaddons:powera':
                    targetPower = 0.3 * SPEED_MULTIPLIER;
                    targetBoost = 0.8 * SPEED_MULTIPLIER;
                    powerName = '§c高速';
                    break;
                case 'haruaddons:powerb':
                    targetPower = 0.3 * SPEED_MULTIPLIER;
                    targetBoost = 0.4 * SPEED_MULTIPLIER;
                    powerName = '§6中速';
                    break;
                case 'haruaddons:powerc':
                    targetPower = 0.1 * SPEED_MULTIPLIER;
                    targetBoost = 0.3 * SPEED_MULTIPLIER;
                    powerName = '§e低速';
                    break;
                case 'haruaddons:brake':
                    targetPower = 0;
                    targetBoost = 0;
                    currentAccelRate = 0.08;
                    powerName = '§cブレーキ';
                    break;
            }
        }

        // ==========================================
        // 2. 移動距離と進行方向の計算
        // ==========================================
        const smartTurnEnabled = world.getDynamicProperty('rail:smart_turn') ?? true;

        let dx = 0,
            dy = 0,
            dz = 0,
            actualDist = 0;
        if (data.lastPos) {
            dx = loc.x - data.lastPos.x;
            dy = loc.y - data.lastPos.y;
            dz = loc.z - data.lastPos.z;
            actualDist = Math.hypot(dx, dz);
        }
        data.lastPos = { x: loc.x, y: loc.y, z: loc.z };

        let dirX = 0,
            dirY = 0,
            dirZ = 0;

        if (smartTurnEnabled) {
            const yaw = (player.getRotation().y * Math.PI) / 180;
            const lookX = -Math.sin(yaw);
            const lookZ = Math.cos(yaw);

            let isReversing = false;

            if (actualDist > 0.05) {
                dirX = dx / actualDist;
                dirY = Math.max(-1.0, Math.min(1.0, dy / actualDist));
                dirZ = dz / actualDist;

                const dot = dirX * lookX + dirZ * lookZ;
                if (dot < -0.5 && targetPower > 0) {
                    isReversing = true;
                }
            } else {
                if (data.lastDir) {
                    const dot = data.lastDir.x * lookX + data.lastDir.z * lookZ;
                    if (dot < -0.5 && targetPower > 0) {
                        isReversing = true;
                    }
                }
            }

            if (isReversing) {
                dirX = lookX;
                dirY = 0;
                dirZ = lookZ;
                data.lastDir = { x: dirX, y: dirY, z: dirZ };

                data.posHistory = [];
                data.posHistory.unshift({ x: loc.x, y: loc.y, z: loc.z });

                for (let i = 1; i <= 60; i++) {
                    data.posHistory.push({
                        x: loc.x - dirX * (i * 0.5),
                        y: loc.y,
                        z: loc.z - dirZ * (i * 0.5),
                    });
                }

                data.currentPower = 0;
                data.currentBoost = 0;
                try {
                    cart.clearVelocity();
                } catch (e) {}
                actualDist = 0;

                try {
                    player.playSound('ui.button.click', { pitch: 1.5, volume: 0.5 });
                } catch (e) {}
            } else if (actualDist > 0.05) {
                data.lastDir = { x: dirX, y: dirY, z: dirZ };
            } else if (data.lastDir && (data.currentPower || 0) > 0.01) {
                dirX = data.lastDir.x;
                dirY = data.lastDir.y;
                dirZ = data.lastDir.z;
            } else {
                dirX = lookX;
                dirY = 0;
                dirZ = lookZ;
                data.lastDir = { x: dirX, y: dirY, z: dirZ };
            }
        } else {
            // --- OFFの場合 (前の状態) ---
            if (actualDist > 0.05) {
                dirX = dx / actualDist;
                dirY = Math.max(-1.0, Math.min(1.0, dy / actualDist));
                dirZ = dz / actualDist;
                data.lastDir = { x: dirX, y: dirY, z: dirZ };
            } else if (data.lastDir && (data.currentPower || 0) > 0.01) {
                dirX = data.lastDir.x;
                dirY = data.lastDir.y;
                dirZ = data.lastDir.z;
            } else {
                const yaw = (player.getRotation().y * Math.PI) / 180;
                dirX = -Math.sin(yaw);
                dirY = 0;
                dirZ = Math.cos(yaw);
                data.lastDir = { x: dirX, y: dirY, z: dirZ };
            }
        }

        // ==========================================
        // 3. 軌跡の保存
        // ==========================================
        const history = data.posHistory;
        if (history.length === 0) {
            history.unshift({ x: loc.x, y: loc.y, z: loc.z });
        } else {
            const last = history[0];
            const dist = Math.hypot(loc.x - last.x, loc.y - last.y, loc.z - last.z);
            if (dist > 0.05) {
                history.unshift({ x: loc.x, y: loc.y, z: loc.z });
            }
        }
        if (history.length > 350) history.pop();

        // ==========================================
        // 段階的減速
        // ==========================================
        const SCAN_DIST = 35;
        if ((targetPower > 0 || data.currentPower > 0.05) && actualDist > 0.05) {
            if (data.tickCount % 3 === 0) {
                let snapX = 0,
                    snapZ = 0;
                if (Math.abs(dirX) > Math.abs(dirZ)) {
                    snapX = Math.sign(dirX);
                } else {
                    snapZ = Math.sign(dirZ);
                }

                let straightDist = 0;
                const sideX = Math.abs(snapZ);
                const sideZ = Math.abs(snapX);

                for (let i = 1; i <= SCAN_DIST; i++) {
                    const checkX = Math.floor(loc.x) + snapX * i;
                    const checkZ = Math.floor(loc.z) + snapZ * i;
                    let foundRail = false;
                    let isBranch = false;

                    for (let dyCheck = -2; dyCheck <= 2; dyCheck++) {
                        try {
                            const blockY = Math.floor(loc.y) + dyCheck;
                            const block = cart.dimension.getBlock({ x: checkX, y: blockY, z: checkZ });

                            if (block && block.typeId.includes('rail')) {
                                foundRail = true;
                                const sideBlock1 = cart.dimension.getBlock({ x: checkX + sideX, y: blockY, z: checkZ + sideZ });
                                const sideBlock2 = cart.dimension.getBlock({ x: checkX - sideX, y: blockY, z: checkZ - sideZ });

                                if ((sideBlock1 && sideBlock1.typeId.includes('rail')) || (sideBlock2 && sideBlock2.typeId.includes('rail'))) {
                                    isBranch = true;
                                }
                                break;
                            }
                        } catch (e) {}
                    }

                    if (foundRail) {
                        if (isBranch) {
                            break;
                        }
                        straightDist++;
                    } else {
                        break;
                    }
                }
                data.cachedStraightDist = straightDist;
            }

            const straightDist = data.cachedStraightDist ?? SCAN_DIST;

            if (straightDist < SCAN_DIST) {
                let maxTickSpeed = straightDist * 0.05;
                maxTickSpeed = Math.max(0.4, maxTickSpeed);
                const checkSpeed = Math.max(targetPower + targetBoost, data.currentPower + data.currentBoost);

                if (checkSpeed > maxTickSpeed) {
                    const MIN_SPEED = 0.4;
                    const targetLimit = Math.max(MIN_SPEED, maxTickSpeed);

                    if (targetPower + targetBoost > 0) {
                        const ratio = maxTickSpeed / (targetPower + targetBoost);
                        targetPower *= ratio;
                        targetBoost *= ratio;
                    } else {
                        targetPower = maxTickSpeed;
                    }

                    if (data.currentPower + data.currentBoost > targetLimit) {
                        currentAccelRate = 0.06;
                    } else if (targetPower === 0 && data.currentPower < MIN_SPEED && data.currentPower > 0.01) {
                        data.currentPower = MIN_SPEED;
                    }

                    if (data.currentPower + data.currentBoost > targetPower + targetBoost) {
                        currentAccelRate = Math.min(0.8, 0.12 * Math.sqrt(Math.max(1, SPEED_MULTIPLIER)));
                    }

                    if (straightDist < 20) {
                        powerName += ' §c(急減速)';
                    } else {
                        powerName += ' §e(注意減速)';
                    }
                } else {
                    if (straightDist < 15) {
                        powerName += ' §6(前方注意)';
                    } else {
                        powerName += ' §a(前方注意)';
                    }
                }

                if (straightDist <= 4) {
                    targetPower += targetBoost;
                    targetBoost = 0;
                } else if (straightDist <= 8) {
                    const shift = targetBoost * 0.5;
                    targetPower += shift;
                    targetBoost -= shift;
                }

                if (targetPower > 0.35 * Math.max(1, SPEED_MULTIPLIER)) {
                    targetPower = 0.35 * Math.max(1, SPEED_MULTIPLIER);
                }
            }
        }
        // ==========================================

        // --- 完全修正版: 燃料(石炭)システム ---
        let isRefueled = false;
        if (data.tickCount % 20 === 0 || data.totalCoal === undefined) {
            let count = 0;
            for (const cId of data.linkedCarts) {
                const cEnt = world.getEntity(cId);
                if (cEnt && cEnt.typeId === 'minecraft:chest_minecart') {
                    const cInv = cEnt.getComponent('inventory')?.container;
                    if (cInv) {
                        for (let i = 0; i < cInv.size; i++) {
                            const item = cInv.getItem(i);
                            if (item && item.typeId === 'minecraft:coal') {
                                count += item.amount;
                            }
                        }
                    }
                }
            }
            data.totalCoal = count;
        }
        let totalCoal = data.totalCoal ?? 0;
        if (targetPower > 0) {
            if (data.fuelTime > 0) {
                let fuelMult = 1.0;
                if (player.dimension.id === 'minecraft:nether') {
                    fuelMult = world.getDynamicProperty('rail:fuel_mult_nether') ?? 1.0;
                } else {
                    fuelMult = world.getDynamicProperty('rail:fuel_mult_ow') ?? 1.0;
                }

                const drain = (1 + data.linkedCarts.length * 0.1) * fuelMult;
                data.fuelTime -= drain;
                isRefueled = true;
            } else if (totalCoal > 0) {
                for (const cId of data.linkedCarts) {
                    let coalConsumed = false;
                    const cEnt = world.getEntity(cId);
                    if (cEnt && cEnt.typeId === 'minecraft:chest_minecart') {
                        const cInv = cEnt.getComponent('inventory')?.container;
                        if (cInv) {
                            for (let i = 0; i < cInv.size; i++) {
                                const item = cInv.getItem(i);
                                if (item && item.typeId === 'minecraft:coal') {
                                    if (item.amount > 1) {
                                        const newItem = item.clone();
                                        newItem.amount -= 1;
                                        cInv.setItem(i, newItem);
                                    } else {
                                        cInv.setItem(i, undefined);
                                    }
                                    coalConsumed = true;
                                    totalCoal--;
                                    break;
                                }
                            }
                        }
                    }
                    if (coalConsumed) {
                        data.fuelTime = FUEL_PER_COAL;
                        player.playSound('fire.ignite');
                        isRefueled = true;
                        data.totalCoal--;
                        break; // 1個消費したら探すのをやめる
                    }
                }
            }

            if (!isRefueled) {
                targetPower = 0;
                targetBoost = 0;
            }
        }

        if (data.currentPower === undefined) data.currentPower = 0;
        if (data.currentBoost === undefined) data.currentBoost = 0;

        data.currentPower += (targetPower - data.currentPower) * currentAccelRate;
        data.currentBoost += (targetBoost - data.currentBoost) * currentAccelRate;

        if (targetPower === 0 && data.currentPower < 0.001) {
            data.currentPower = 0;
            data.currentBoost = 0;
            try {
                cart.clearVelocity();
            } catch (e) {}
        }

        if (handItem && handItem.typeId === 'haruaddons:brake') {
            try {
                const vel = cart.getVelocity();
                cart.applyImpulse({ x: -vel.x * 0.15, y: -vel.y * 0.1, z: -vel.z * 0.15 });
            } catch (e) {}
        }

        // --- 安定化させた限界突破ブースト ---
        if (data.currentPower > 0.001) {
            let isGrounded = false;
            try {
                const bOn = cart.dimension.getBlock({ x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) });
                const bBelow = cart.dimension.getBlock({ x: Math.floor(loc.x), y: Math.floor(loc.y - 0.5), z: Math.floor(loc.z) });

                if ((bOn && bOn.typeId.includes('rail')) || (bBelow && !bBelow.isAir && !bBelow.isLiquid)) {
                    isGrounded = true;
                }
            } catch (e) {}

            if (!isGrounded) {
                const impulsePower = Math.max(data.currentPower, 0.08);
                cart.applyImpulse({ x: dirX * impulsePower * 0.3, y: 0, z: dirZ * impulsePower * 0.3 });
            } else {
                const totalSpeed = data.currentPower + data.currentBoost;
                try {
                    cart.clearVelocity();
                } catch (e) {}

                const teleportSpeed = data.currentBoost;
                const nextX = loc.x + dirX * teleportSpeed;
                let targetDy = dirY * teleportSpeed;
                if (targetDy < -0.4) targetDy = -0.4;
                const nextY = loc.y + targetDy;
                const nextZ = loc.z + dirZ * teleportSpeed;
                let isWallAhead = false;
                let isTargetOnRail = false;

                try {
                    const checkY = Math.floor(nextY + 0.5);
                    const block = cart.dimension.getBlock({ x: Math.floor(nextX), y: checkY, z: Math.floor(nextZ) });
                    if (block && !block.isAir && !block.isLiquid && !block.typeId.includes('rail')) {
                        isWallAhead = true;
                    }

                    for (let dyCheck = -2; dyCheck <= 2; dyCheck++) {
                        const railBlock = cart.dimension.getBlock({ x: Math.floor(nextX), y: Math.floor(nextY) + dyCheck, z: Math.floor(nextZ) });
                        if (railBlock && railBlock.typeId.includes('rail')) {
                            isTargetOnRail = true;
                            break;
                        }
                    }
                } catch (e) {}

                if (isWallAhead) {
                    data.currentPower = 0;
                    data.currentBoost = 0;
                } else {
                    if (totalSpeed > 0.15 && isTargetOnRail) {
                        cart.tryTeleport({ x: nextX, y: nextY, z: nextZ }, { checkForBlocks: true });
                    }

                    const impulsePower = Math.max(data.currentPower, 0.08);
                    cart.applyImpulse({ x: dirX * impulsePower, y: 0, z: dirZ * impulsePower });
                }
            }
        }

        // --- 連結トロッコの追従 ---
        if (data.linkedCarts.length > 0) {
            const linkDistance = 2.5;

            const validCarts = [];
            for (let i = 0; i < data.linkedCarts.length; i++) {
                const cEnt = world.getEntity(data.linkedCarts[i]);
                if (cEnt && cEnt.isValid()) {
                    validCarts.push(cEnt.id);

                    // ONの時だけ慣性を消す
                    if (smartTurnEnabled) {
                        try {
                            cEnt.clearVelocity();
                        } catch (e) {}
                    }

                    const targetDist = linkDistance * (i + 1);
                    let currentDist = 0;
                    let placed = false;

                    // 通常の追従（軌跡をたどる）
                    if (history.length > 1) {
                        for (let j = 1; j < history.length; j++) {
                            const p1 = history[j - 1];
                            const p2 = history[j];
                            const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y, p1.z - p2.z);
                            currentDist += dist;

                            if (currentDist >= targetDist) {
                                const excess = currentDist - targetDist;
                                const ratio = 1 - excess / dist;
                                const tx = p1.x + (p2.x - p1.x) * ratio;
                                const ty = p1.y + (p2.y - p1.y) * ratio;
                                const tz = p1.z + (p2.z - p1.z) * ratio;

                                const vx = p1.x - p2.x;
                                const vz = p1.z - p2.z;
                                const yaw = Math.atan2(-vx, vz) * (180 / Math.PI);

                                cEnt.tryTeleport({ x: tx, y: ty, z: tz }, { checkForBlocks: false, rotation: { x: 0, y: yaw } });
                                placed = true;
                                break;
                            }
                        }
                    }

                    // ONの時だけ、強制再整列を実行（OFFの時は履歴が足りなければ何もしない＝以前の状態）
                    // if (smartTurnEnabled && !placed) {

                    // }
                }
            }
            data.linkedCarts = validCarts;
        }

        // --- HUD アクションバーの表示 ---
        const targetSpeedBps = actualDist * 20;

        data.displaySpeed = data.displaySpeed * 0.9 + targetSpeedBps * 0.1;

        const speedBpsStr = data.displaySpeed.toFixed(1);
        const fuelSec = Math.ceil(data.fuelTime / 20);
        const fuelColor = data.fuelTime > 0 ? '§6' : '§c';
        const fuelStr = `${fuelColor}Fuel: ${fuelSec}s / ${totalCoal}`;

        player.onScreenDisplay.setActionBar(`§bPower§r: ${powerName}§r | §aSpeed§r: §b${speedBpsStr}§r b/s | §r${fuelStr} §r| §dLinked§r: §b${data.linkedCarts.length}`);
    }
}, 1);

// ==========================================
// --- 管理者向け 設定UI ---
// ==========================================

// 管理者UIを開くコマンド /scriptevent rail:ui
system.afterEvents.scriptEventReceive.subscribe(event => {
    const { id, sourceEntity } = event;
    if (id === 'rail:ui' && sourceEntity?.typeId === 'minecraft:player') {
        const form = new ActionFormData();
        form.title('§1管理者設定');
        form.body('>>> §e選択してください');
        form.button('§0免許を発行する', 'textures/ui/bubble_empty');
        form.button('§0システム設定', 'textures/ui/icon_setting');

        form.show(sourceEntity).then(res => {
            if (res.canceled) return;
            if (res.selection === 0) showLicenseIssuerUI(sourceEntity);
            if (res.selection === 1) showAdminSettingsPanel(sourceEntity);
        });
    }
});

// 免許発行専用UI
function showLicenseIssuerUI(player) {
    const players = [...world.getAllPlayers()];
    const playerNames = players.map(p => p.name);

    const form = new ModalFormData();
    form.title('§1トロッコ免許発行');
    form.dropdown('§e発行先プレイヤー', playerNames);
    form.slider('§e有効期限 (日)', 1, 180, 1, 30);

    form.show(player).then(res => {
        if (res.canceled) return;

        const targetPlayer = players[res.formValues[0]];
        const days = res.formValues[1];

        if (!targetPlayer) return;

        const licenseItem = new ItemStack('haruaddons:rail', 1);
        const now = new Date();
        const expiryDate = new Date(now);
        expiryDate.setDate(now.getDate() + days);

        // プロパティ設定
        licenseItem.setDynamicProperty('rail:licenseOwnerId', targetPlayer.id);
        licenseItem.setDynamicProperty('rail:licenseExpiry', expiryDate.getTime());

        const dateString = `${expiryDate.getFullYear()}/${expiryDate.getMonth() + 1}/${expiryDate.getDate()}`;

        // 見た目(Lore)の設定
        licenseItem.setLore([`§r§7----------------`, `§r§bOwner: §f${targetPlayer.name}`, `§r§eType: §fMinecart License`, `§r§cExp: ${dateString}`, `§r§7----------------`]);

        const inv = player.getComponent('inventory')?.container;
        if (inv && inv.emptySlotsCount > 0) {
            inv.addItem(licenseItem);
            player.sendMessage(`§a${targetPlayer.name} 用の免許を発行しました（期限: ${dateString}）`);
        }
    });
}

function showAdminSettingsPanel(player, customDefaults = {}) {
    const currentDist = customDefaults.dist ?? world.getDynamicProperty('rail:link_distance') ?? 10.0;
    const currentSpeed = customDefaults.speed !== undefined ? customDefaults.speed : `${world.getDynamicProperty('rail:speed_multiplier') ?? 1.0}`;
    const fuelOW = customDefaults.fuelOW ?? world.getDynamicProperty('rail:fuel_mult_ow') ?? 1.0;
    const fuelNether = customDefaults.fuelNether ?? world.getDynamicProperty('rail:fuel_mult_nether') ?? 1.0;
    const allowNether = customDefaults.allowNether ?? world.getDynamicProperty('rail:allow_nether') ?? true;
    const licenseEnabled = customDefaults.licenseEnabled ?? world.getDynamicProperty('rail:license_enabled') ?? false;
    const smartTurnEnabled = customDefaults.smartTurn ?? world.getDynamicProperty('rail:smart_turn') ?? true;

    const form = new ModalFormData();
    form.title('§1システム設定');
    form.textField('§e連結距離 (ブロック)', '例: 10.0', `${currentDist}`);
    form.textField('§bスピード倍率 (最大30)', '例: 3.0 (最大30)', `${currentSpeed}`);
    form.textField('§a標準燃費 (地上/エンド)', '例: 1.0', `${fuelOW}`);
    form.textField('§cネザー燃費', '例: 2.0', `${fuelNether}`);
    form.toggle('§cネザーでの運転を許可', allowNether);
    form.toggle('§b免許制度を有効にする', licenseEnabled);
    form.toggle('§eスマートターン&スタック防止', smartTurnEnabled);

    form.show(player).then(res => {
        if (res.canceled) return;

        const newDist = parseFloat(res.formValues[0]);
        const newSpeedRaw = res.formValues[1];
        const newSpeed = parseFloat(newSpeedRaw);
        const newFuelOW = parseFloat(res.formValues[2]);
        const newFuelNether = parseFloat(res.formValues[3]);
        const newAllowNether = res.formValues[4];
        const newLicenseEnabled = res.formValues[5];
        const newSmartTurn = res.formValues[6];

        if (isNaN(newDist) || isNaN(newFuelOW) || isNaN(newFuelNether)) return;

        if (isNaN(newSpeed) || newSpeed > 30 || newSpeed <= 0) {
            player.sendMessage('[§bRail§r] §cスピード倍率は30以下で設定してください');

            showAdminSettingsPanel(player, {
                dist: newDist,
                speed: '1',
                fuelOW: newFuelOW,
                fuelNether: newFuelNether,
                allowNether: newAllowNether,
                licenseEnabled: newLicenseEnabled,
                smartTurn: newSmartTurn,
            });
            return;
        }

        world.setDynamicProperty('rail:link_distance', newDist);
        world.setDynamicProperty('rail:speed_multiplier', newSpeed);
        world.setDynamicProperty('rail:fuel_mult_ow', newFuelOW);
        world.setDynamicProperty('rail:fuel_mult_nether', newFuelNether);
        world.setDynamicProperty('rail:allow_nether', newAllowNether);
        world.setDynamicProperty('rail:license_enabled', newLicenseEnabled);
        world.setDynamicProperty('rail:smart_turn', newSmartTurn);

        player.sendMessage(`[§bRail§r] §a設定を保存しました`);
    });
}

world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    const player = event.player;
    const target = event.target;

    if (target.typeId === 'minecraft:minecart') {
        const myTrain = trainData.get(player.id);

        if (myTrain) {
            if (myTrain.cart && myTrain.cart.id !== target.id) {
                event.cancel = true;
                system.run(() => {
                    if (myTrain.linkedCarts.includes(target.id)) {
                        player.sendMessage('[§bRail§r] §c自分が連結しているトロッコには乗車できません');
                    } else {
                        player.sendMessage('[§bRail§r] §c運転中は他のトロッコに乗り移れません');
                    }
                });
                return;
            }
        }
    }
});
