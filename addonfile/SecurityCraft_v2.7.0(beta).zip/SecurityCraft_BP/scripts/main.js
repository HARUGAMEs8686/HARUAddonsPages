import { world, system } from "@minecraft/server";
import { Itemrun_HARUPhone1 } from "./scriptevents.js"
import { BlockRun } from "./blockrun.js"

//初期設定
if(world.getDynamicProperty("X_RAY_LEVEL")==undefined){
   world.setDynamicProperty("X_RAY_LEVEL",3)
}
if(world.getDynamicProperty("CHAT_LEVEL")==undefined){
    world.setDynamicProperty("CHAT_LEVEL",1) 
}


//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
  const player = eventData.sourceEntity;
  if(eventData.id === "haru:s") {
    Itemrun_HARUPhone1(eventData,player);
  }
  if(eventData.id === "start:s") {
    player.runCommand('tag @s add SecurityOP')
    player.sendMessage("§r[§bSecurity§r] §cSecurityシステムを起動しました");
    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
  }
})

//初期設定
if(world.getDynamicProperty('Log_system')==undefined){
  world.setDynamicProperty('Log_system', true)
}
if(world.getDynamicProperty('pvp_check')==undefined){
  world.setDynamicProperty('pvp_check', true)
}

//logシステム
const MAX_LOGS = 30; // 1人あたりの最大ログ数

//B データ保存あり
function SecurityLogA() {
  if(world.getDynamicProperty('Log_system')==true){
    const players = world.getPlayers();
    const now = new Date();
    const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, "0");
    const day = String(japanTime.getUTCDate()).padStart(2, "0");
    const hours = String(japanTime.getUTCHours()).padStart(2, "0");
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
    const seconds = String(japanTime.getUTCSeconds()).padStart(2, "0");
    var time = `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
    players.forEach(player => {
        //名前を保存
        const logs = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
           // もし名前が登録されていなかったら追加
        if (!logs.includes(player.name)) {
            logs.push(player.name);
        }            
           // 更新したログを保存
        world.setDynamicProperty("PlayersNameLog", JSON.stringify(logs));
        
        const logKey = `Security_LOG_KEY_${player.name}`;
        let logData = world.getDynamicProperty(logKey);

        // もしログデータが存在しなければ初期化
        if (!logData) {
            logData = [];
        } else {
            logData = JSON.parse(logData); // 文字列からオブジェクトに変換
        }

        const pos = player.location;
        const logEntry = {
            x: Math.round(pos.x), 
            y: Math.round(pos.y),
            z: Math.round(pos.z),
            time:time // タイムスタンプ
        };

        // プレイヤーごとのログを管理
        if (!logData[player.name]) {
            logData[player.name] = [];
        }

        logData.push(logEntry); // 新しいデータを追加

        // MAX_LOGSを超えたら古いデータを削除
        if (logData[player.name].length > MAX_LOGS) {
            logData[player.name].shift(); // 配列の先頭を削除
        }
        // 更新したログデータを保存
        world.setDynamicProperty(logKey, JSON.stringify(logData));
    });
  }
    // もう一度3分後に実行
    system.runTimeout(SecurityLogA, 3600);
}


export var SecurityLogB_Data = {}
export var SecurityLogB_Name = []
//B データ保存無し
function SecurityLogB() {
  if(world.getDynamicProperty('Log_system')==true){
  const players = world.getPlayers();
  const now = new Date();
  const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const year = japanTime.getUTCFullYear();
  const month = String(japanTime.getUTCMonth() + 1).padStart(2, "0");
  const day = String(japanTime.getUTCDate()).padStart(2, "0");
  const hours = String(japanTime.getUTCHours()).padStart(2, "0");
  const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
  const seconds = String(japanTime.getUTCSeconds()).padStart(2, "0");
  var time = `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
  players.forEach(player => {
      //名前を保存
      if(!SecurityLogB_Name.includes(player.name)){
        SecurityLogB_Name.push(player.name)     
      }

      const pos = player.location;
      const logEntry = {
          x: Math.round(pos.x), 
          y: Math.round(pos.y),
          z: Math.round(pos.z),
          time:time // タイムスタンプ
      };

      // プレイヤーごとのログを管理
      if(!SecurityLogB_Data[player.name]){
        SecurityLogB_Data[player.name] = []
      }  
      SecurityLogB_Data[player.name].push(logEntry); // 新しいデータを追加

      // MAX_LOGSを超えたら古いデータを削除
      if (SecurityLogB_Data[player.name].length > 1440) {
        SecurityLogB_Data[player.name].shift(); // 配列の先頭を削除
      }
  });
 }

  // もう一度1分後に実行
  system.runTimeout(SecurityLogB, 1200);
}

// セキュリティーログシステム最初の呼び出し
SecurityLogA();
SecurityLogB();

export var SecurityLogC_Data = {}
export var SecurityLogC_Name = []
//破壊検知
world.beforeEvents.playerBreakBlock.subscribe(event => {
  const player = event.source;
  
})



// 設置者情報を保存するオブジェクト（座標キー: プレイヤー名）
const blockOwnerMap = {};

//設置検知
world.beforeEvents.playerPlaceBlock.subscribe(event => {
  const player = event.player;
  const block = event.block;
  const positionKey = block.x + "," + block.y + "," + block.z;

  blockOwnerMap[positionKey] = player.name;
});
  
var playerCashData = {}

//ブロックタッチ検知
world.beforeEvents.playerInteractWithBlock.subscribe((event) =>{
  BlockRun(event)
  system.run(() => {
    const player = event.player;

    if (!checkModePlayers.has(player.name)) return; // 確認モードがONのプレイヤーのみ

    if(!playerCashData[player.id]){
       playerCashData[player.id] = true
    
    const block = event.block;
    const positionKey = block.x + "," + block.y + "," + block.z;
  
    if (blockOwnerMap[positionKey]) {
        const ownerName = blockOwnerMap[positionKey];
        player.sendMessage("§r[§bSecurity§r] §5" + ownerName + "§rによって§e設置");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    } else {
        player.sendMessage("§r[§bSecurity§r] §cこのブロックの設置者情報はありません");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.7 0.7`)
    }
  
    system.runTimeout(() => {
      playerCashData[player.id] = false
    }, 20);
  }
  })
})

// 確認モードのプレイヤーリスト
export const checkModePlayers = new Set();

//メッセージ検知
world.afterEvents.chatSend.subscribe((event) => {
  const player = event.sender;
    const message = event.message.toLowerCase();

    if (message === "!checkmode on"&&player.hasTag('SecurityOP')) {
        checkModePlayers.add(player.name);
        player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    } else if (message === "!checkmode off"&&player.hasTag('SecurityOP')) {
        checkModePlayers.delete(player.name);
        player.sendMessage("§r[§a通知§7(Security)§r] §a確認モード§rを§5OFF§rにしました");
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
    }
})

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
  if (eventData.itemStack.typeId === "additem:securecraft"){
    const player = eventData.source;
    system.run(() => {
      if(player.hasTag('SecurityOP')){
       Itemrun_HARUPhone1(eventData,player)
      }
    })
  }
})


//X-rayを検知
const trackedPlayers = loadTrackedPlayers();
const globalStats = loadGlobalStats();
const ORE_LIMITS = {
  "minecraft:diamond_ore": 10,
  "minecraft:deepslate_diamond_ore": 10,
  "minecraft:ancient_debris": 8,
  "minecraft:emerald_ore": 15,
  "minecraft:deepslate_emerald_ore": 15,
};

const SUSPICION_RESET_TIME = 420000; // 7分（ミリ秒）
const PLACED_BLOCK_EXPIRY = 24 * 60 * 60 * 1000; // 24時間（ミリ秒）

const X_RAY_LEVEL = world.getDynamicProperty("X_RAY_LEVEL");

const LEVEL_CONFIGS = {
  1: { TIME_WINDOW: 120, MIN_BREAK_INTERVAL: 300, SUSPICIOUS_THRESHOLD: 8, WARN_LIMIT: 5, DETECTION_RADIUS: 6, NEARBY_RADIUS: 5 },
  2: { TIME_WINDOW: 90, MIN_BREAK_INTERVAL: 250, SUSPICIOUS_THRESHOLD: 7, WARN_LIMIT: 4, DETECTION_RADIUS: 5, NEARBY_RADIUS: 4 },
  3: { TIME_WINDOW: 60, MIN_BREAK_INTERVAL: 200, SUSPICIOUS_THRESHOLD: 6, WARN_LIMIT: 4, DETECTION_RADIUS: 5, NEARBY_RADIUS: 4 },
  4: { TIME_WINDOW: 45, MIN_BREAK_INTERVAL: 150, SUSPICIOUS_THRESHOLD: 5, WARN_LIMIT: 3, DETECTION_RADIUS: 4, NEARBY_RADIUS: 3 },
  5: { TIME_WINDOW: 30, MIN_BREAK_INTERVAL: 100, SUSPICIOUS_THRESHOLD: 4, WARN_LIMIT: 2, DETECTION_RADIUS: 3, NEARBY_RADIUS: 2 },
};

let TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS;

if (X_RAY_LEVEL != 0) {
  ({ TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL]);
}

function loadTrackedPlayers() {
  const data = world.getDynamicProperty("trackedPlayers");
  return data ? JSON.parse(data) : {};
}

function saveTrackedPlayers() {
  world.setDynamicProperty("trackedPlayers", JSON.stringify(trackedPlayers));
}

function loadGlobalStats() {
  const data = world.getDynamicProperty("globalStats");
  return data ? JSON.parse(data) : {
    totalMined: 0,
    "minecraft:diamond_ore": 0,
    "minecraft:deepslate_diamond_ore": 0,
    "minecraft:emerald_ore": 0,
    "minecraft:deepslate_emerald_ore": 0,
    "minecraft:ancient_debris": 0
  };
}

function saveGlobalStats() {
  world.setDynamicProperty("globalStats", JSON.stringify(globalStats));
}

function loadPlacedBlocks() {
  const data = world.getDynamicProperty("placedBlocks");
  return data ? new Map(JSON.parse(data)) : new Map();
}

function savePlacedBlocks() {
  const now = Date.now();
  // 期限切れ（24時間以上経過）のエントリを削除
  for (const [key, timestamp] of placedBlocks) {
    if (now - timestamp > PLACED_BLOCK_EXPIRY) {
      placedBlocks.delete(key);
    }
  }
  // 保存（JSON文字列に変換）
  const serialized = JSON.stringify([...placedBlocks]);
  if (serialized.length > 30000) { // 約30KBを目安に制限
    trimPlacedBlocks();
  }
  world.setDynamicProperty("placedBlocks", JSON.stringify([...placedBlocks]));
}

function trimPlacedBlocks() {
  // 容量が大きすぎる場合、古いエントリを半分に削減
  const entries = [...placedBlocks.entries()];
  const halfLength = Math.floor(entries.length / 2);
  placedBlocks = new Map(entries.slice(halfLength)); // 古い半分を削除
}

function isNearbyOre(block, oreType) {
  const { x, y, z } = block.location;
  const MIN_Y = -64, MAX_Y = 320;
  const MIN_XZ = -30000000, MAX_XZ = 30000000;

  const offsets = [];
  for (let dx = -NEARBY_RADIUS; dx <= NEARBY_RADIUS; dx++) {
    for (let dy = -NEARBY_RADIUS; dy <= NEARBY_RADIUS; dy++) {
      for (let dz = -NEARBY_RADIUS; dz <= NEARBY_RADIUS; dz++) {
        const newX = x + dx, newY = y + dy, newZ = z + dz;
        if (newX < MIN_XZ || newX > MAX_XZ || newY < MIN_Y || newY > MAX_Y || newZ < MIN_XZ || newZ > MAX_XZ) {
          continue;
        }
        offsets.push({ x: dx, y: dy, z: dz });
      }
    }
  }

  for (const offset of offsets) {
    const neighbor = block.dimension.getBlock({
      x: block.location.x + offset.x,
      y: block.location.y + offset.y,
      z: block.location.z + offset.z
    });
    if (neighbor && neighbor.type.id === oreType) {
      return true;
    }
  }
  return false;
}

// 設置されたブロックを記録（永続化対応）
const placedBlocks = loadPlacedBlocks();
world.beforeEvents.playerPlaceBlock.subscribe((event) => {
 system.run(() => {
  const block = event.block;
  const oreType = block.type.id;
  if (oreType in ORE_LIMITS) {
    const key = `${block.location.x},${block.location.y},${block.location.z}`;
    placedBlocks.set(key, Date.now());
    savePlacedBlocks(); // 設置時に永続化
  }
  })
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
  if (world.getDynamicProperty('X_RAY_LEVEL') == 0) return;

  const player = event.player;
  const block = event.block;
  if (!block) return;

  const playerId = player.name;
  const blockPos = block.location;
  if (!blockPos) return;

  const { x, y, z } = blockPos;
  const oreType = block.type.id;

  if (!(oreType in ORE_LIMITS)) return;

  const blockKey = `${x},${y},${z}`;
  const isPlacedBlock = placedBlocks.has(blockKey);
  if (isPlacedBlock) {
    placedBlocks.delete(blockKey);
    savePlacedBlocks(); // 破壊時に永続化
    return; // 設置された鉱石ブロックの破壊は監視対象外
  }

  if (!trackedPlayers[playerId]) {
    trackedPlayers[playerId] = {
      ores: {},
      timestamp: Date.now(),
      lastBreakTime: 0,
      suspiciousCount: 0,
      warnCount: 0,
      lastBreakPos: null,
      totalBlocksMined: 0,
      reasons: {},
      straightMiningCount: 0,
      nearbyOreStreak: 0
    };
  }

  let playerData = trackedPlayers[playerId];
  const now = Date.now();

  if (playerData.lastBreakTime > 0 && now - playerData.lastBreakTime < MIN_BREAK_INTERVAL) {
    playerData.suspiciousCount++;
    playerData.reasons["短時間で掘りすぎた回数"] = (playerData.reasons["短時間で掘りすぎた回数"] || 0) + 1;
  }
  playerData.lastBreakTime = now;

  if (playerData.lastBreakPos) {
    const { x: lastX, y: lastY, z: lastZ } = playerData.lastBreakPos;
    const dx = Math.abs(x - lastX);
    const dy = Math.abs(y - lastY);
    const dz = Math.abs(z - lastZ);
    if ((dx <= DETECTION_RADIUS && dy === 0 && dz === 0) ||
        (dx === 0 && dy <= DETECTION_RADIUS && dz === 0) ||
        (dx === 0 && dy === 0 && dz <= DETECTION_RADIUS)) {
      playerData.straightMiningCount = (playerData.straightMiningCount || 0) + 1;
      if (playerData.straightMiningCount >= 2) {
        playerData.suspiciousCount++;
        playerData.reasons["直線掘りの回数"] = (playerData.reasons["直線掘りの回数"] || 0) + 1;
      }
    } else {
      playerData.straightMiningCount = 0;
    }
  }
  playerData.lastBreakPos = { x, y, z };

  if (now - playerData.timestamp > TIME_WINDOW * 1000) {
    playerData.ores = {};
    playerData.timestamp = now;
    playerData.totalBlocksMined = 0;
    playerData.reasons = {};
    playerData.straightMiningCount = 0;
    playerData.nearbyOreStreak = 0;
  }

  playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
  playerData.totalBlocksMined++;
  globalStats.totalMined++;
  globalStats[oreType] = (globalStats[oreType] || 0) + 1;
  saveGlobalStats();

  if (isNearbyOre(block, oreType)) {
    playerData.nearbyOreStreak = (playerData.nearbyOreStreak || 0) + 1;
    if (playerData.nearbyOreStreak >= 2) {
      playerData.suspiciousCount++;
      playerData.reasons["近くの鉱石を連続で掘った回数"] = (playerData.reasons["近くの鉱石を連続で掘った回数"] || 0) + 1;
    }
  } else {
    playerData.nearbyOreStreak = 0;
  }

  if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
    playerData.suspiciousCount++;
    playerData.reasons["異常に多く掘った鉱石数"] = (playerData.reasons["異常に多く掘った鉱石数"] || 0) + 1;
  }

  const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
  const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
  if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
    playerData.suspiciousCount++;
    playerData.reasons["異常に高い鉱石発見率"] = (playerData.reasons["異常に高い鉱石発見率"] || 0) + 1;
  }

  if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
    playerData.warnCount++;
    playerData.suspiciousCount = 0;

    const WARNING_COOLDOWN = 60000; // 60秒
    if (playerData.warnCount >= WARN_LIMIT) {
      const now = Date.now();
      if (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN) {
        playerData.lastWarningTime = now;

        let oreStatsMessage = "";
        let suspiciousOre = null;
        for (const ore in ORE_LIMITS) {
          const playerOreCount = playerData.ores[ore] || 0;
          const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
          const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
          if (playerOreCount > 0) {
            oreStatsMessage += `\n  - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(通常: §c${worldOreRate.toFixed(2)}%§r)`;
          }
          if (playerOreRate > worldOreRate * 2) {
            suspiciousOre = ore;
          }
        }

        let reasonMessage = "";
        for (const [reason, count] of Object.entries(playerData.reasons)) {
          reasonMessage += `\n  - ${reason}: ${count}回`;
        }

        const detectedOre = suspiciousOre || oreType;
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId} §rが§cX-ray§4の可能性。対象: §b${detectedOre}`);
        world.sendMessage(`§e詳細§r: 発見率${oreStatsMessage}\n§a理由§c${reasonMessage}`);

        system.run(() => {
          world.getAllPlayers().forEach(player => {
            player.playSound("random.toast", { pitch: 0.6, volume: 1.0 });
          });
        });
      }
    }
  }

  saveTrackedPlayers();
});

system.runInterval(() => {
  for (const player in trackedPlayers) {
    trackedPlayers[player].suspiciousCount = Math.floor(trackedPlayers[player].suspiciousCount / 2);
    trackedPlayers[player].straightMiningCount = 0;
    trackedPlayers[player].nearbyOreStreak = 0;
  }
  savePlacedBlocks(); // 定期的に永続化（期限切れデータも削除）
}, SUSPICION_RESET_TIME / 50);


//チャット検知
const CHAT_LEVEL = world.getDynamicProperty("CHAT_LEVEL"); 
const chatLogs = {};
const CHAT_LEVEL_CONFIGS = {
    1: { MUTE_TIME: 30 * 1000, SPAM_LIMIT: 3, LONG_MESSAGE_LIMIT: 100, SIMILARITY_THRESHOLD: 0.8, FAST_SPAM_LIMIT: 3 },
    2: { MUTE_TIME: 60 * 1000, SPAM_LIMIT: 5, LONG_MESSAGE_LIMIT: 150, SIMILARITY_THRESHOLD: 0.85, FAST_SPAM_LIMIT: 4 },
    3: { MUTE_TIME: 120 * 1000, SPAM_LIMIT: 7, LONG_MESSAGE_LIMIT: 200, SIMILARITY_THRESHOLD: 0.95, FAST_SPAM_LIMIT: 6 },
};

// プレイヤーのレベルに基づく設定を取得
let MUTE_TIME, SPAM_LIMIT, LONG_MESSAGE_LIMIT, SIMILARITY_THRESHOLD, FAST_SPAM_LIMIT;

// CHAT_LEVEL に応じた設定を取得
if (CHAT_LEVEL != 0) {
    ({ MUTE_TIME, SPAM_LIMIT, LONG_MESSAGE_LIMIT, SIMILARITY_THRESHOLD, FAST_SPAM_LIMIT } = CHAT_LEVEL_CONFIGS[X_RAY_LEVEL]);
}

function isSimilarMessage(msg1, msg2) {
    if (!msg1 || !msg2) return false;
    let minLen = Math.min(msg1.length, msg2.length);
    let common = 0;
    for (let i = 0; i < minLen; i++) {
        if (msg1[i] === msg2[i]) common++;
    }
    return (common / minLen) >= SIMILARITY_THRESHOLD;
}

world.beforeEvents.chatSend.subscribe((event) => {
    if(world.getDynamicProperty("CHAT_LEVEL")==0){
        return;
    }
    const player = event.sender;
    const message = event.message;
    const playerId = player.name;

    // **SecurityOP / SecurityMember は検知しない**
    if (player.hasTag("SecurityOP") || player.hasTag("SecurityMember")) return;

    if (!chatLogs[playerId]) {
        chatLogs[playerId] = { messages: [], warnings: 0, mutedUntil: 0 };
    }

    let playerData = chatLogs[playerId];
    let now = Date.now();

    // **ミュート中ならチャットをブロック**
    if (playerData.mutedUntil > now) {
        event.cancel = true;
        player.sendMessage("§r[§bSecurity§r] §c現在チャットはご利用いただけません");
        return;
    }

    let violation = false;

    // **長文スパムチェック**
    if (message.length > LONG_MESSAGE_LIMIT) {
        playerData.warnings++;
        player.sendMessage(`§r[§bSecurity§r] §cメッセージが長すぎます（${playerData.warnings}/${SPAM_LIMIT}）`);
        event.cancel = true;
        violation = true;
    }

    // **連投・コピペチェック**
    for (let pastMessage of playerData.messages) {
        if (isSimilarMessage(message, pastMessage)) {
            playerData.warnings++;
            player.sendMessage(`§r[§bSecurity§r] §c同じ内容の連続送信は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
            event.cancel = true;
            violation = true;
            break;
        }
    }

    // **URL禁止（宣伝対策）**
    if (message.match(/http:\/\/|https:\/\//)) {
        playerData.warnings++;
        player.sendMessage(`§r[§bSecurity§r] §cURLの送信は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
        event.cancel = true;
        violation = true;
    }

    // **高速連投スパム検知**
    if (now - playerData.lastMessageTime < 1000) {
        playerData.fastSpamCount++;
        if (playerData.fastSpamCount >= FAST_SPAM_LIMIT) {
            playerData.warnings++;
            player.sendMessage(`§r[§bSecurity§r] §c短時間での連投は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
            event.cancel = true;
            violation = true;
        }
    } else {
        playerData.fastSpamCount = 0; // リセット
    }
    playerData.lastMessageTime = now;
    

    // **過去のメッセージを記録**
    if (!violation) {
        playerData.messages.push(message);
        if (playerData.messages.length > 5) playerData.messages.shift(); // 最新5件だけ保存
    }

    // **警告の処理**
    if (playerData.warnings >= SPAM_LIMIT) {
        player.sendMessage("§r[§bSecurity§r] §cスパム行為が検出されました 一定時間チャットをご利用頂けません");
        playerData.mutedUntil = now + MUTE_TIME;
        playerData.warnings = 0; // リセット
    }
});

//破壊記録
import { ActionFormData, ModalFormData,MessageFormData } from "@minecraft/server-ui";

const playerCheckModeStatus = {};
const blockBreakHistory = new Map();
const lastCheckTime = new Map();

export function showCheckModeForm(player) {
    const form = new ActionFormData();
    form.title("§0§lSecureCraft");
    form.body("§b破壊CheckMode §9有効化§r/§4無効化");
    form.button("§9有効化");
    form.button("§4無効化");
    
    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                playerCheckModeStatus[player.name] = true;
                player.sendMessage("§r[§a通知§7(Security)§r] §a破壊確認モード§rを§5ON§rにしました.§eブロック周辺をタッチで破壊履歴を確認");
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                break;
            case 1:
                playerCheckModeStatus[player.name] = false;
                player.sendMessage("§r[§a通知§7(Security)§r] §a破壊確認モード§rを§5OFF§rにしました");
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                break;
        }
    });
}

world.afterEvents.playerBreakBlock.subscribe((event) => {
    const player = event.player;
    const block = event.block;
    const timestamp = new Date().toLocaleString();
    
    const positionKey = `${block.x},${block.y},${block.z}`;
    blockBreakHistory.set(positionKey, {
        breaker: player.name,
        timestamp: timestamp,
        blockType: block.typeId
    });
});

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const player = event.player;
    const block = event.block;
    
    system.run(() => {
        if (!playerCheckModeStatus[player.name]) return;
        
        const now = Date.now();
        const lastCheck = lastCheckTime.get(player.name) || 0;
        if (now - lastCheck < 1000) return;
        lastCheckTime.set(player.name, now);

        if (!block || !block.location) {
            console.error("ブロックの位置情報が無効です。");
            return;
        }

        const nearbyBreaks = getNearbyBreakHistory(block.location);
        
        if (nearbyBreaks.length > 0) {
            displayBreakSummary(player, nearbyBreaks);
            player.runCommand(`playsound random.click @s ~ ~ ~ 1.0 1.0 1.0`);
        } else {
            player.sendMessage("§eこの周辺に最近の破壊履歴はありません");
        }
    });
});

function getNearbyBreakHistory(position) {
    const history = [];
    const radius = 5;
    const x = position.x;
    const y = position.y;
    const z = position.z;

    for (let dx = -radius; dx <= radius; dx++) {
        for (let dy = -radius; dy <= radius; dy++) {
            for (let dz = -radius; dz <= radius; dz++) {
                const checkPos = `${x + dx},${y + dy},${z + dz}`;
                if (blockBreakHistory.has(checkPos)) {
                    const record = blockBreakHistory.get(checkPos);
                    history.push({
                        position: `(${x + dx},${y + dy},${z + dz})`,
                        breaker: record.breaker,
                        timestamp: record.timestamp
                    });
                }
            }
        }
    }

    return history;
}

function displayBreakSummary(player, breaks) {
    const currentTime = new Date().toLocaleString().split(" ")[1];
    player.sendMessage(`§7[§b破壊概要§7 | §f${currentTime}§7]`);

    // プレイヤーごとの破壊数を集計
    const breakCount = new Map();
    const latestBreaks = new Map();
    breaks.forEach(record => {
        breakCount.set(record.breaker, (breakCount.get(record.breaker) || 0) + 1);
        latestBreaks.set(record.breaker, {
            timestamp: record.timestamp.split(" ")[1],
            position: record.position
        });
    });

    // 破壊数の多い順にソート
    const sortedBreakers = Array.from(breakCount.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3); // 上位3人まで表示（必要に応じて調整可）

    sortedBreakers.forEach(([breaker, count], index) => {
        const latest = latestBreaks.get(breaker);
        player.sendMessage(
            `§a#${index + 1} §c${breaker} §e${latest.timestamp} §6${latest.position} §b${count}個`
        );
    });

    player.sendMessage(`§7合計: §f${breaks.length}件 (§f${breakCount.size}人)`);
}