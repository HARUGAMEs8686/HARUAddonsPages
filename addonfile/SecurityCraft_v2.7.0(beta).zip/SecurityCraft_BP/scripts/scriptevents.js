import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData,MessageFormData } from "@minecraft/server-ui";
import { SecurityLogB_Data,SecurityLogB_Name,checkModePlayers,showCheckModeForm} from "./main";

export function Itemrun_HARUPhone1(eventData,player){
        var players = world.getPlayers()
        var form = new ActionFormData();
            form.title("§0§lSecureCraft");
            form.body(`§a-ワールド情報-\n§r・§3プレイヤー人数§r: §r§b${players.length}\n\n§c-セキュリティー情報-§r\n§r・§3座標ログ§r: §r§b${world.getDynamicProperty('Log_system')}\n§r・§eX-ray検知Level§r:§b${world.getDynamicProperty("X_RAY_LEVEL")}\n§r・§dチャット検知Level§r:§b${world.getDynamicProperty("CHAT_LEVEL")}\n\n§5>>>§7選択してください...`);
            form.button("§1§o座標ログ");
            form.button("§3§oCheckMode","textures/ui/sidebar_icons/star");
            form.button("§2§oSecurityChest","textures/blocks/securitychest");
            form.button("§8§o設定\n§9操作","textures/ui/icon_setting");
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("チェックするログを選択");
                        form.button("§1ログデータA\n§8データ量少 (再起動してもアクセス可)");
                        form.button("§5ログデータB\n§8データ量多 (ワールド終了時に強制削除)");
                        form.button("§3座標検索\n§8指定座標周辺のプレイヤーを検索");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    function showPlayerListA(player) {
                                        const PlayersNameLog = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionA(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionA(player, targetName) {
                                        const logKey = `Security_LOG_KEY_${targetName}`;
                                        const logData = world.getDynamicProperty(logKey);
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const logs = JSON.parse(logData);
                                        if (logs.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logs.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsA(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsA(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionA(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                        
                                    }

                                    //表示
                                    showPlayerListA(player);
                                break;
                                case 1:
                                    function showPlayerListB(player) {
                                        const PlayersNameLog = SecurityLogB_Name
                                        const form = new ActionFormData()
                                            .title("プレイヤーログ")
                                            .body("確認したいプレイヤーを選んでください");
                                            for (let i = 0; i < PlayersNameLog.length; i++){
                                                form.button(`${PlayersNameLog[i]}`);
                                            }
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedPlayer = PlayersNameLog[response.selection];
                                            if (selectedPlayer) {
                                                showTimeSelectionB(player, selectedPlayer);
                                            }
                                        })
                                     }
                                    // 時間選択画面を表示
                                    function showTimeSelectionB(player, targetName) {
                                        const logData = SecurityLogB_Data[targetName];
                                    
                                        if (!logData) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        if (logData.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §aログデータがありません"}]}`) 
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    
                                        const form = new ActionFormData()
                                            .title(`${targetName} のログ時間選択`)
                                            .body("確認したい時間を選んでください");
                                    
                                        const LogList = logData.reverse();
                                    
                                        LogList.forEach(log => {
                                            form.button(log.time);
                                        });
                                    
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                    
                                            const selectedLog = LogList[response.selection];
                                            if (selectedLog) {
                                                showLogDetailsB(player, targetName, selectedLog);
                                            }
                                        });
                                    }

                                    function showLogDetailsB(player, targetName, log) {
                                        const logText = `§a${targetName} §rの§6座標ログ\n§aX§r:§b ${Math.round(log.x)}\n§aY§r:§b ${Math.round(log.y)}\n§aZ§r:§b ${Math.round(log.z)}\n§a時間§r: §b${log.time}`;
                                    
                                        const form = new ActionFormData()
                                            .title("ログ詳細")
                                            .body(logText)
                                            .button(`§l戻る`,'textures/ui/icon_import.png');
                                    
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                let response = r.selection;
                                                switch (response) {
                                                    case 0:
                                                        showTimeSelectionB(player, targetName);
                                                    break;
                                                    case 1:
                                                    break;
                                                }
                                            })
                                    }

                                    //表示
                                    showPlayerListB(player);
                                break;
                                case 2:
                                    // 新しい座標検索機能
                                    function showCoordinateSearch(player) {
                                        const form = new ModalFormData()
                                            .title("座標検索")
                                            .textField("X座標を入力", "例: 100")
                                            .textField("Y座標を入力", "例: 64")
                                            .textField("Z座標を入力", "例: 200")
                                            .textField("検索範囲(ブロック)", "例: 50")
                                            .dropdown("検索対象ログ", ["ログデータA", "ログデータB"], 0);
                        
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                        
                                            const [xInput, yInput, zInput, rangeInput, logType] = response.formValues;
                                            const x = parseFloat(xInput);
                                            const y = parseFloat(yInput);
                                            const z = parseFloat(zInput);
                                            const range = parseFloat(rangeInput) || 50;
                        
                                            if (isNaN(x) || isNaN(y) || isNaN(z) || isNaN(range)) {
                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §c有効な数値を入力してください"}]}`);
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                return;
                                            }
                        
                                            searchPlayersByCoordinates(player, x, y, z, range, logType);
                                        });
                                    }
                        
                                    function searchPlayersByCoordinates(player, targetX, targetY, targetZ, range, logType) {
                                        let allLogs = {};
                                        let playerNames = [];
                        
                                        // ログタイプに応じてデータを取得
                                        if (logType === 0) { // ログデータA
                                            const PlayersNameLog = JSON.parse(world.getDynamicProperty("PlayersNameLog") || "[]");
                                            playerNames = PlayersNameLog;
                                            for (let name of PlayersNameLog) {
                                                const logKey = `Security_LOG_KEY_${name}`;
                                                const logData = world.getDynamicProperty(logKey);
                                                if (logData) allLogs[name] = JSON.parse(logData);
                                            }
                                        } else { // ログデータB
                                            playerNames = SecurityLogB_Name;
                                            allLogs = SecurityLogB_Data;
                                        }
                        
                                        // 座標範囲内にいたプレイヤーを検索
                                        const nearbyPlayers = [];
                                        for (let name of playerNames) {
                                            const logs = allLogs[name] || [];
                                            for (let log of logs) {
                                                const distance = Math.sqrt(
                                                    Math.pow(log.x - targetX, 2) +
                                                    Math.pow(log.y - targetY, 2) +
                                                    Math.pow(log.z - targetZ, 2)
                                                );
                                                if (distance <= range) {
                                                    nearbyPlayers.push({
                                                        name: name,
                                                        time: log.time,
                                                        x: log.x,
                                                        y: log.y,
                                                        z: log.z,
                                                        distance: distance
                                                    });
                                                    break; // 1人につき1回だけ記録
                                                }
                                            }
                                        }
                        
                                        // 結果表示
                                        if (nearbyPlayers.length === 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityLog)§r] §a指定範囲内にプレイヤーは見つかりませんでした"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                            return;
                                        }
                        
                                        const form = new ActionFormData()
                                            .title(`座標検索結果 (範囲: ${range}ブロック)`)
                                            .body(`X:${targetX} Y:${targetY} Z:${targetZ} 周辺にいたプレイヤー:`);
                                        
                                        nearbyPlayers.sort((a, b) => a.distance - b.distance); // 距離順にソート
                                        nearbyPlayers.forEach(p => {
                                            form.button(`${p.name}\n§8距離:${Math.round(p.distance)}b 時間:${p.time}`);
                                        });
                        
                                        form.show(player).then(response => {
                                            if (response.canceled) return;
                                            const selectedPlayer = nearbyPlayers[response.selection];
                                            if (selectedPlayer) {
                                                showPlayerDetails(player, selectedPlayer, logType, targetX, targetY, targetZ, range);
                                            }
                                        });
                                    }
                        
                                    function showPlayerDetails(player, playerData, logType, targetX, targetY, targetZ, range) {
                                        const logText = `§a${playerData.name} §rの詳細\n` +
                                            `§aX§r:§b ${Math.round(playerData.x)}\n` +
                                            `§aY§r:§b ${Math.round(playerData.y)}\n` +
                                            `§aZ§r:§b ${Math.round(playerData.z)}\n` +
                                            `§a時間§r: §b${playerData.time}\n` +
                                            `§a距離§r: §b${Math.round(playerData.distance)}ブロック`;
                        
                                        const form = new ActionFormData()
                                            .title("プレイヤー詳細")
                                            .body(logText)
                                            .button(`§l戻る`, 'textures/ui/icon_import.png');
                        
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            if (r.selection === 0) {
                                                searchPlayersByCoordinates(player, targetX, targetY, targetZ, range, logType);
                                            }
                                        });
                                    }
                        
                                    // 座標検索画面を表示
                                    showCoordinateSearch(player);
                                break;
                            }
                        })
                    break;
                    case 1:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("§bCheckMode §9有効化§r/§4無効化");
                        form.button("§9設置チェック");
                        form.button("§4破壊チェック");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("§bCheckMode §9有効化§r/§4無効化");
                                    form.button("§9有効化");
                                    form.button("§4無効化");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                checkModePlayers.add(player.name);
                                                player.sendMessage("§r[§a通知§7(Security)§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります");
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                            break;
                                            case 1:
                                                checkModePlayers.delete(player.name);
                                                player.sendMessage("§r[§a通知§7(Security)§r] §a設置確認モード§rを§5OFF§rにしました");
                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`)
                                            break;
                                        }
                                    })
                                break;
                                case 1:
                                    showCheckModeForm(player);
                                break;
                            }
                        })
                    break;
                    case 2:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("機能を選択");
                        form.button("§1追加");
                        form.button("§5削除");
                        form.button("§2Ticket付与");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    let chest_pattern = [ "ラージチェスト", "樽", "黄緑色シュルカーボックス", "空色シュルカーボックス","桃色シュルカーボックス","黄色のシュルカーボックス","白色シュルカーボックス"]
                                    var form = new ModalFormData();
                                    form.textField("座標x", "0")
                                    form.textField("座標y", "0")
                                    form.textField("座標z", "0")
                                    form.textField("保存ブロック数", "0") 
                                    form.dropdown("種類", chest_pattern)
                                    form.textField("倉庫デザイン", "") 
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        var securitychest_List = world.getDynamicProperty('securitychest_List')
                                        if(securitychest_List==undefined){
                                           var securitychest_List_system2=[]
                                        }else{
                                          var securitychest_List_system2 = JSON.parse(securitychest_List);
                                        }
                                        securitychest_List_system2.push([{ x: Number(r.formValues[0]), y: Number(r.formValues[1]), z: Number(r.formValues[2]) },r.formValues[3],chest_pattern[r.formValues[4]],0,r.formValues[5],player.name])
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a追加しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 1:
                                    var securitychest_List = world.getDynamicProperty('securitychest_List')
                                    if(securitychest_List==undefined){
                                       var securitychest_List_system2=[]
                                    }else{
                                      var securitychest_List_system2 = JSON.parse(securitychest_List);
                                    }
                                        if(securitychest_List_system2[0]==undefined){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除できる倉庫販売データがありません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("削除する倉庫販売データを選択");
                                    for (let i = 0; i < securitychest_List_system2.length; i++){
                                        form.button(`§1${securitychest_List_system2[i][0].x},${securitychest_List_system2[i][0].y},${securitychest_List_system2[i][0].z}§r:\n§s${securitychest_List_system2[i][2]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        securitychest_List_system2.splice( response, 1 );
                                        if(securitychest_List_system2==[]){
                                            securitychest_List_system2=undefined
                                        }
                                        const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                        world.setDynamicProperty('securitychest_List',securitychest_List_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a削除しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                break;
                                case 2:
                                    var players = world.getAllPlayers()
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body("送り先のプレイヤーを選択");
                                    for (let i = 0; i < players.length; i++){
                                        form.button(`§1${players[i].name}\n§5>>>§s${players[i].getDynamicProperty('Security_chest_ticket')}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                      let response = r.selection;
            
                                      var form = new ModalFormData();
                                      form.title("§0§lSecureCraft");
                                      form.textField("付与ticket数(半角数字)", "0")
                                      form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if(isNaN(r.formValues[0])){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §4半角数字で入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (r.formValues[0]<0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §40以下は設定できません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if(players[response].getDynamicProperty('Security_chest_ticket')==undefined){
                                            players[response].setDynamicProperty('Security_chest_ticket',0)
                                        }
                                        players[response].setDynamicProperty('Security_chest_ticket',players[response].getDynamicProperty('Security_chest_ticket')+Number(r.formValues[0])) 
                                        players[response].runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${Number(r.formValues[0])}§r枚受け取りました"}]}`)
                                        players[response].runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§bSecurity] §aTicket§b${players[response].name}§rに§b${Number(r.formValues[0])}§a枚付与しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.7`)  
                                    })
                                    })
                                break;
                            }
                        })  
                    break;
                    case 3:
                        var form = new ActionFormData();
                        form.title("§0§lSecureCraft");
                        form.body("選択してください.");
                        form.button("§l戻る","textures/ui/back_button_hover");
                        form.button("§o§2X-ray検知\n§r§9Level選択");
                        form.button("§o§2不正チャット検知\n§r§9Level選択");
                        form.button("§o§2座標ログシステム\n§r§9有効化§r・§4無効化");
                        form.button("§o§3座標ログデータ削除\n§r§9A§r・§5B");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    Itemrun_HARUPhone1(eventData,player)
                                break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`X-ray検知レベル§r:§b${world.getDynamicProperty('X_RAY_LEVEL')}\n選択してください.`);
                                    form.button("§l戻る","textures/ui/back_button_hover");
                                    form.button("§1無効化 \n§8検知システムが実行されません");
                                    form.button("§1Level-1 \n§8誤検知を最小限に抑える");
                                    form.button("§1Level-2 \n§8バランスの取れた検知レベル");
                                    form.button("§1Level-3 \n§8標準より少し厳しい検知");
                                    form.button("§1Level-4 \n§8高速検知");
                                    form.button("§1Level-5 \n§8即時検知");                                    
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                world.setDynamicProperty('X_RAY_LEVEL',0)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 2:
                                                world.setDynamicProperty('X_RAY_LEVEL',1)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 3:
                                                world.setDynamicProperty('X_RAY_LEVEL',2)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 4:
                                                world.setDynamicProperty('X_RAY_LEVEL',3)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 5:
                                                world.setDynamicProperty('X_RAY_LEVEL',4)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 6:
                                                world.setDynamicProperty('X_RAY_LEVEL',5)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                        }
                                    })
                                break;
                                case 2:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`不正チャット検知レベル§r:§b${world.getDynamicProperty("CHAT_LEVEL")}\n選択してください.`);
                                    form.button("§l戻る","textures/ui/back_button_hover");
                                    form.button("§1無効化 \n§8検知システムが実行されません");
                                    form.button("§1Level-1 \n§8弱い検知レベル - 最小限の対応");
                                    form.button("§1Level-2 \n§8バランス検知レベル - 中程度の対応");
                                    form.button("§1Level-3 \n§8強い検知レベル - 厳密な対応");                                                                      
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                world.setDynamicProperty('CHAT_LEVEL',0)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 2:
                                                world.setDynamicProperty('CHAT_LEVEL',1)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 3:
                                                world.setDynamicProperty('CHAT_LEVEL',2)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 4:
                                                world.setDynamicProperty('CHAT_LEVEL',3)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                        }
                                    })
                                break;
                                case 3:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`現在は${world.getDynamicProperty('Log_system')}\n選択してください.`);
                                    form.button("§l戻る","textures/ui/back_button_hover");
                                    form.button("§o§9有効化");
                                    form.button("§o§4無効化");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                world.setDynamicProperty('Log_system', true)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 2:
                                                world.setDynamicProperty('Log_system', false)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                        }
                                    })
                                break;
                                case 4:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`現在は${world.getDynamicProperty('Log_system')}\n選択してください.`);
                                    form.button("§l戻る","textures/ui/back_button_hover");
                                    form.button("§o§9有効化");
                                    form.button("§o§4無効化");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                world.setDynamicProperty('Log_system', true)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 2:
                                                world.setDynamicProperty('Log_system', false)
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                        }
                                    })
                                break;
                                case 5:
                                    var form = new ActionFormData();
                                    form.title("§0§lSecureCraft");
                                    form.body(`削除するデータを選択`);
                                    form.button("§lホームへ戻る","textures/ui/back_button_hover");
                                    form.button("§o§5データA");
                                    form.button("§o§1データB");
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                Itemrun_HARUPhone1(eventData,player)
                                            break;
                                            case 1:
                                                var form = new ActionFormData();
                                                form.title("§0§lSecureCraft");
                                                form.body(`§5データA\n\n§5>>>§s本当に削除しますか？`);
                                                form.button("§o§5削除");
                                                form.button("§o§1キャンセル");
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:   
                                                          var playersName = world.getDynamicProperty("PlayersNameLog")
                                                          if (!playersName) {
                                                             playersName = [];
                                                          } else {
                                                              playersName = JSON.parse(playersName); // 文字列からオブジェクトに変換
                                                          }

                                                          for (let i = 0; i < playersName.length ; i++){
                                                            const logKey = `Security_LOG_KEY_${playersName[i]}`;
                                                            world.setDynamicProperty(logKey,undefined);
                                                          }
                                                            world.setDynamicProperty("PlayersNameLog")
                                                            Itemrun_HARUPhone1(eventData,player)
                                                        break;
                                                        case 1:
                                                            
                                                        break;
                                                    }
                                                })
                                            break;
                                            case 2:
                                                var form = new ActionFormData();
                                                form.title("§0§lSecureCraft");
                                                form.body(`§9データB\n\n§5>>>§s本当に削除しますか？`);
                                                form.button("§o§5削除");
                                                form.button("§o§1キャンセル");
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:   
                                                        for (let i = 0; i < SecurityLogB_Name.length ; i++){
                                                            SecurityLogB_Data[SecurityLogB_Name[i]] = []
                                                        }
                                                        Itemrun_HARUPhone1(eventData,player)
                                                        break;
                                                        case 1:
                                                            
                                                        break;
                                                    }
                                                })
                                            break;
                                        }
                                    })
                                break;
                            }
                        }) 
                    break;
                    default: break;
                }
            })
}

