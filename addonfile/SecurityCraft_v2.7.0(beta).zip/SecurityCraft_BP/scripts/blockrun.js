import { world,system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}
export function BlockRun(eventData){
    if(eventData.block.typeId === "addblock:securitychest") {
        const player = eventData.player
        const block = eventData.block
        player_Cash_Data[player.name] = {}
        system.run(() => {
            if (!player_Cash_Data[player.name].securitychest_Server_Stop) {
                player_Cash_Data[player.name].securitychest_Server_Stop = true
                //ここから実行
               var form = new ActionFormData();
                        form.title("SecurityChest");
                        form.body(`サービスを選択してください`);
                        form.button("§5Security倉庫にアクセス");
                        form.button("§2新しい倉庫を検索");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    var my_Security_chest = player.getDynamicProperty('my_Security_chest')
                                    if(my_Security_chest==undefined){
                                        var my_Security_chest_system2=[]
                                    }else{
                                        var my_Security_chest_system2 = JSON.parse(my_Security_chest);
                                    }
                                    if(my_Security_chest_system2[0]==undefined){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §4所持している倉庫がありません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    var form = new ActionFormData();
                                    form.title("SecurityChest");
                                    form.body(`サービスを選択してください`);
                                    for (let i = 0; i < my_Security_chest_system2.length; i++){
                                        form.button(`§l倉庫${i+1}\n§r§a座標§r:§5${my_Security_chest_system2[i][0][0].x} ${my_Security_chest_system2[i][0][0].y} ${my_Security_chest_system2[i][0][0].z}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        let dimension = player.dimension.id;
                                        let location = player.location;
                                        if(dimension==	"minecraft:overworld"){
                                        player.setDynamicProperty('my_Security_chest_back2',{ x: location.x, y: location.y, z: location.z })
                                        let targetLocation = { x: my_Security_chest_system2[response][0][0].x, y: my_Security_chest_system2[response][0][0].y, z: my_Security_chest_system2[response][0][0].z };
                                        player.teleport(targetLocation);
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a倉庫§b${response+1}§rにアクセスしました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                        }else{
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §4通常世界からのみアクセスできます"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        }
                                    })
                                break;
                                case 1:
                                    var securitychest_List = world.getDynamicProperty('securitychest_List')
                                        if(securitychest_List==undefined){
                                            var securitychest_List_system2=[]
                                        }else{
                                            var securitychest_List_system2 = JSON.parse(securitychest_List);
                                        }
                                        if(securitychest_List_system2[0]==undefined){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a倉庫が見つかりませんでした"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title("SecurityChest");
                                        form.body("倉庫を選択");
                                        for (let i = 0; i < securitychest_List_system2.length; i++){
                                            form.button(`§rBox数:§b${securitychest_List_system2[i][1]}個 §r種類:§n${securitychest_List_system2[i][2]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            player.setDynamicProperty('cash2',r.selection)
                                                    var form = new ActionFormData();
                                                    form.title("SecurityChest");
                                                    form.body(`§rBox数:§b${securitychest_List_system2[player.getDynamicProperty('cash2')][1]}§r個 種類:§n${securitychest_List_system2[player.getDynamicProperty('cash2')][2]}\n§r倉庫座標:§b${securitychest_List_system2[player.getDynamicProperty('cash2')][0].x} ${securitychest_List_system2[player.getDynamicProperty('cash2')][0].y} ${securitychest_List_system2[player.getDynamicProperty('cash2')][0].z}\n§rデザイン:§b${securitychest_List_system2[player.getDynamicProperty('cash2')][4]}\n§r管理者:§a${securitychest_List_system2[player.getDynamicProperty('cash2')][5]}`);
                                                    form.button("§1購入");
                                                    form.button("§5キャンセル");
                                                    form.show(player).then(r => {
                                                        let response = r.selection;
                                                        switch (response) {
                                                            case 0:
                                                            if(player.getDynamicProperty('Security_chest_ticket')>=1){
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r §eSecurityチケットを1枚消費しました"}]}`)
                                                                player.setDynamicProperty('Security_chest_ticket',player.getDynamicProperty('Security_chest_ticket')-1) 
                                                                var my_Security_chest = player.getDynamicProperty('my_Security_chest')
                                                                if(my_Security_chest==undefined){
                                                                    var my_Security_chest_system2=[]
                                                                }else{
                                                                    var my_Security_chest_system2 = JSON.parse(my_Security_chest);
                                                                }
                                                                my_Security_chest_system2.push([securitychest_List_system2[player.getDynamicProperty('cash2')]])
                                                                const my_Security_chest_system3 = JSON.stringify(my_Security_chest_system2);
                                                                player.setDynamicProperty('my_Security_chest',my_Security_chest_system3) 
                                                                securitychest_List_system2.splice(player.getDynamicProperty('cash2'), 1)
                                                                const securitychest_List_system3 = JSON.stringify(securitychest_List_system2);
                                                                world.setDynamicProperty('securitychest_List',securitychest_List_system3) 
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a倉庫を入手しました"}]}`)
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                                            }else{
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §4チケットが足りません"}]}`)
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                                            }
                                                            break;
                                                        }
                                                    })  
                                        })       
                                break;
                            }
                        })
                
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.name].securitychest_Server_Stop = false
                }, 20); 
        }
        })
    }


    if(eventData.block.typeId === "addblock:securitychest_back") {
        const player = eventData.player
        player_Cash_Data[player.name] = {}
        system.run(() => {
            if (!player_Cash_Data[player.name].securityshest_back_Server_Stop) {
                player_Cash_Data[player.name].securityshest_back_Server_Stop = true
                //ここから実行
                let targetLocation = { x: player.getDynamicProperty('my_Security_chest_back2').x, y: player.getDynamicProperty('my_Security_chest_back2').y, z: player.getDynamicProperty('my_Security_chest_back2').z };
                player.teleport(targetLocation);
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(SecurityChest)§r] §a倉庫を退出しました"}]}`)
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                player.setDynamicProperty('my_Security_chest_back2',undefined)
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.name].securityshest_back_Server_Stop = true
                }, 20); 
        }
        })
    }
}