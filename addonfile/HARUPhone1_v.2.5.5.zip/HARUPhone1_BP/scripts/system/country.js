import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';

import { Operator_Controller } from '../system/Operator_Controller';
import { HARUPhone1 } from '../itemrun/haruphone1';

// スコアボードと動的プロパティの初期化
const MONEY_OBJECTIVE = 'money';
const CHUNK_PRICE_PROPERTY = 'chunk_price';
const NATION_DB = 'nation_data';
const CHUNK_DB = 'chunk_data';
const SYSTEM_ENABLED_PROPERTY = 'nation_system_enabled';
const NATION_CREATION_COST_PROPERTY = 'nation_creation_cost';
const ALLOW_MULTIPLE_NATIONS_PROPERTY = 'allow_multiple_nations';
const UNOWNED_LAND_INTERACTION = 'unowned_land_interaction';
// 公共土地データの定義
const PUBLIC_LAND_DB = 'public_land_data';

// システムが有効か確認
function isSystemEnabled() {
    return world.getDynamicProperty(SYSTEM_ENABLED_PROPERTY) === true;
}

// 複数国所属が許可されているか確認
function isMultipleNationsAllowed() {
    return world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === true;
}

// チャンク座標の取得
function getChunkCoords(location) {
    return {
        x: Math.floor(location.x / 16),
        z: Math.floor(location.z / 16),
    };
}

// 国のデータの管理
function getNationData() {
    try {
        const data = world.getDynamicProperty(NATION_DB);
        if (!data) {
            return {}; // データが存在しない場合は空オブジェクトを返す
        }
        const parsedData = JSON.parse(data);
        if (typeof parsedData !== 'object' || parsedData === null) {
            console.warn('Nation data is corrupted or invalid. Resetting to empty object.');
            return {};
        }
        return parsedData;
    } catch (e) {
        console.warn('Failed to parse nation data:', e);
        return {};
    }
}

function setNationData(data) {
    try {
        if (typeof data !== 'object' || data === null) {
            console.warn('Invalid nation data provided. Skipping save.');
            return;
        }
        // データの検証（例: 必須フィールドのチェック）
        for (const nationId in data) {
            if (!data[nationId].members || !Array.isArray(data[nationId].members)) {
                console.warn(`Invalid members data for nation ${nationId}. Skipping save.`);
                return;
            }
        }
        world.setDynamicProperty(NATION_DB, JSON.stringify(data));
    } catch (e) {
        console.warn('Failed to set nation data:', e);
    }
}

// チャンクデータの管理
function getChunkData() {
    try {
        const data = world.getDynamicProperty(CHUNK_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn('Failed to parse chunk data:', e);
        return {};
    }
}

function setChunkData(data) {
    try {
        world.setDynamicProperty(CHUNK_DB, JSON.stringify(data));
    } catch (e) {
        console.warn('Failed to set chunk data:', e);
    }
}

// プレイヤーの所属国を取得
function getPlayerNations(player) {
    const nationData = getNationData();
    return Object.entries(nationData).filter(([_, nation]) => nation.members.includes(player.name));
}

// 公共土地データの管理
function getPublicLandData() {
    try {
        const data = world.getDynamicProperty(PUBLIC_LAND_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn('公共土地データの解析に失敗:', e);
        return {};
    }
}

function setPublicLandData(data) {
    try {
        world.setDynamicProperty(PUBLIC_LAND_DB, JSON.stringify(data));
    } catch (e) {
        console.warn('公共土地データの設定に失敗:', e);
    }
}

function getCurrentLocationName(player) {
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkData = getChunkData();
    const nationData = getNationData();
    const publicLandData = getPublicLandData();

    let nowChunkName = world.getDynamicProperty('WorldspaceNAME');
    if (publicLandData[chunkKey]) {
        nowChunkName = publicLandData[chunkKey].name;
    } else if (chunkData[chunkKey]?.nation) {
        const nation = nationData[chunkData[chunkKey].nation];
        if (nation) {
            nowChunkName = nation.name;
        }
    }
    return nowChunkName;
}

// メインUIを表示
export function showMainUI(player) {
    if (!isSystemEnabled()) {
        player.sendMessage('§r[§b社会システム§r] §c社会システムは現在無効です。');
        return;
    }

    const playerNations = getPlayerNations(player);
    const hasNation = playerNations.length > 0;
    const nowChunkName = getCurrentLocationName(player);

    const form = new ActionFormData().title('§1HARUPhone1').body(`§c-現在地-\n §a>§e${nowChunkName}`);

    // ボタンを動的に追加
    const buttons = [];
    buttons.push({ text: '§l戻る', action: 'back', icon: 'textures/ui/icon_import.png' });
    if (hasNation) {
        buttons.push({ text: `§4土地を購入\n§5>>>§1コスト§r:§s${world.getDynamicProperty(CHUNK_PRICE_PROPERTY)}`, action: 'buyLand' });
        buttons.push(playerNations.some(([_, nation]) => nation.leader === player.name) ? { text: `§1${world.getDynamicProperty('WorldgroupName')}を管理`, action: 'manageNation' } : { text: `§4${world.getDynamicProperty('WorldgroupName')}を退出`, action: 'leaveNation' });
        // Add invite member button for players with canInvite permission or leaders
        if (playerNations.some(([nationId, nation]) => nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            buttons.push({ text: '§4メンバーを招待', action: 'inviteMember' });
        }
    } else {
        buttons.push({ text: `§1${world.getDynamicProperty('WorldgroupName')}を作成\n§5>>>§1コスト§r:§s${world.getDynamicProperty(NATION_CREATION_COST_PROPERTY)}`, action: 'createNation' });
    }
    buttons.push({ text: '§0マイ情報', action: 'showMyInfo' });
    buttons.push({ text: '§9招待を確認', action: 'checkInvites' });

    buttons.forEach(button => form.button(button.text, button.icon));

    form.show(player).then(response => {
        if (response.canceled) return;
        const selectedAction = buttons[response.selection].action;

        if (hasNation) {
            if (selectedAction === 'back') {
                HARUPhone1(player);
            } else if (selectedAction === 'buyLand' || selectedAction === 'manageNation' || selectedAction === 'leaveNation' || selectedAction === 'inviteMember') {
                selectNationForAction(player, selectedAction);
            } else if (selectedAction === 'showMyInfo') {
                showMyInfo(player);
            } else if (selectedAction === 'checkInvites') {
                checkInvites(player);
            }
        } else {
            if (selectedAction === 'back') {
                HARUPhone1(player);
            } else if (selectedAction === 'createNation') {
                createNation(player);
            } else if (selectedAction === 'showMyInfo') {
                showMyInfo(player);
            } else if (selectedAction === 'checkInvites') {
                checkInvites(player);
            }
        }
    });
}

// 複数国所属時の国選択UI
function selectNationForAction(player, action) {
    const playerNations = getPlayerNations(player);
    if (playerNations.length === 1) {
        const [nationId, nation] = playerNations[0];
        if (action === 'buyLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === 'manageNation' && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === 'leaveNation') {
            leaveNation(player, nationId);
        } else if (action === 'inviteMember' && (nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            inviteMember(player, nationId);
        } else {
            player.sendMessage('§r[§b社会システム§r] §cこの操作の権限がありません。');
        }
        return;
    }

    const form = new ActionFormData().title(`§5${world.getDynamicProperty('WorldgroupName')}を選択`).body(`§fどの${world.getDynamicProperty('WorldgroupName')}を操作しますか？`);
    playerNations.forEach(([nationId, nation]) => {
        form.button(`§e${nation.name}`);
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        const [nationId, nation] = playerNations[response.selection];
        if (action === 'buyLand' && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === 'manageNation' && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === 'leaveNation') {
            leaveNation(player, nationId);
        } else if (action === 'inviteMember' && (nation.leader === player.name || nation.permissions?.[player.name]?.canInvite)) {
            inviteMember(player, nationId);
        } else {
            player.sendMessage('§r[§b社会システム§r] §cこの操作の権限がありません。');
        }
    });
}

// マイ情報表示
function showMyInfo(player) {
    const playerNations = getPlayerNations(player);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;

    let body = `§a所持金: §e${score}\n\n§b所属${world.getDynamicProperty('WorldgroupName')}:\n`;
    if (playerNations.length === 0) {
        body += '§7なし\n';
    } else {
        playerNations.forEach(([_, nation]) => {
            const isLeader = nation.leader === player.name;
            const canBuyLand = nation.permissions?.[player.name]?.canBuyLand || false;
            const canInvite = nation.permissions?.[player.name]?.canInvite || false;
            body += `- §6${nation.name} (§c${isLeader ? 'リーダー' : 'メンバー'})\n`;
            body += `  §a土地購入権限: §e${canBuyLand ? 'あり' : 'なし'}\n`;
            body += `  §aメンバー招待権限: §e${canInvite ? 'あり' : 'なし'}\n`;
        });
    }

    const form = new ActionFormData().title('§1HARUPhone1').body(body).button('§1OK');

    form.show(player);
}

// 土地購入
function buyLand(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage('§r[§b社会システム§r] §c社会システムは現在無効です。');
        return;
    }

    const chunk = getChunkCoords(player.location);
    const chunkData = getChunkData();
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);

    if (chunkData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに購入されています。');
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const hasPurchasePermission = nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand;
    if (!hasPurchasePermission) {
        player.sendMessage('§r[§b社会システム§r] §c土地購入の権限がありません。');
        return;
    }

    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < chunkPrice) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${chunkPrice}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new MessageFormData().title('§1HARUPhone1').body(`§fこのチャンクを§a${chunkPrice}§fで購入しますか？\n§b座標: (§e${chunk.x}, ${chunk.z}§b)`).button1('§4キャンセル').button2('§1購入');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -chunkPrice);
            //opmoney
            let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
            if (settings.socialSystem) {
                world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(chunkPrice));
            }
            chunkData[chunkKey] = { nation: nationId };
            setChunkData(chunkData);
            player.sendMessage('§r[§b社会システム§r] §aチャンクを購入しました！');
        }
    });
}

// 国作成
function createNation(player) {
    if (!isSystemEnabled()) {
        player.sendMessage('§r[§b社会システム§r] §c社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const playerNations = getPlayerNations(player);
    if (playerNations.length > 0 && !isMultipleNationsAllowed()) {
        player.sendMessage(`§r[§b社会システム§r] §cすでに${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
        return;
    }

    const creationCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < creationCost) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${creationCost}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new ModalFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}を作成`)
        .textField(`§f${world.getDynamicProperty('WorldgroupName')}の名前`, '例: MyNation')
        .dropdown('§fメンバーシップ', ['オープン', '招待制'], 0);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) return;
        const [nationName, membershipType] = response.formValues;
        if (!nationName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}の名前を入力してください。`);
            return;
        }
        const nationId = nationName.toLowerCase().replace(/\s/g, '_');
        if (nationData[nationId]) {
            player.sendMessage(`§r[§b社会システム§r] §cこの名前の${world.getDynamicProperty('WorldgroupName')}はすでに存在します。`);
            return;
        }

        world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -creationCost);
        //opmoney
        let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
        if (settings.socialSystem) {
            world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(creationCost));
        }
        nationData[nationId] = {
            name: nationName,
            leader: player.name,
            members: [player.name],
            membership: membershipType === 0 ? 'open' : 'invite',
            invites: [],
            permissions: {},
        };
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nationName}§a」を作成しました！`);
    });
}

// 国管理
function manageNation(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage('§r[§b社会システム§r] §c社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const isLeader = nation.leader === player.name;
    if (!isLeader) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}のリーダーではありません。`);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}管理§r: §1${nation.name}`)
        .body('§4>>>')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§4メンバーを招待')
        .button(`§0${world.getDynamicProperty('WorldgroupName')}の情報`)
        .button('§1メンバー権限設定')
        .button(`§2${world.getDynamicProperty('WorldgroupName')}名を変更`)
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を解散`);

    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showMainUI(player);
                break;
            case 1:
                inviteMember(player, nationId);
                break;
            case 2:
                showNationInfo(player, nationId);
                break;
            case 3:
                setMemberPermissions(player, nationId);
                break;
            case 4:
                changeNationName(player, nationId);
                break;
            case 5:
                confirmDissolveNation(player, nationId);
                break;
        }
    });
}

// 国の情報表示
function showNationInfo(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const memberCount = nation.members.length;
    const memberList = nation.members.join(', ');
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` + `§aリーダー: §c${nation.leader}\n` + `§aメンバー数: §e${memberCount}\n` + `§aメンバー: §f${memberList}\n` + `§aメンバーシップ: §e${nation.membership === 'open' ? 'オープン' : '招待制'}\n` + `§a所有チャンク数: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の情報§r: §1${nation.name}`)
        .body(body)
        .button('§1閉じる');

    form.show(player);
}

// 国名変更
function changeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new ModalFormData().title(`§5${world.getDynamicProperty('WorldgroupName')}名を変更`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) return;
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, '_');
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
    });
}

// メンバー招待
function inviteMember(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const hasInvitePermission = nation.leader === player.name || nation.permissions?.[player.name]?.canInvite || nation.membership === 'open';
    if (!hasInvitePermission) {
        player.sendMessage('§r[§b社会システム§r] §c招待権限がありません。');
        return;
    }

    const form = new ModalFormData().title('§1メンバーを招待').textField('§fプレイヤー名', '例: Steve');

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) return;
        const [targetName] = response.formValues;
        const targetPlayer = world.getPlayers().find(p => p.name === targetName);
        if (!targetPlayer) {
            player.sendMessage('§r[§b社会システム§r] §cプレイヤーが見つかりません。');
            return;
        }
        if (targetPlayer.name === player.name) {
            player.sendMessage('§r[§b社会システム§r] §c自分自身を招待できません。');
            return;
        }

        if (nation.members.includes(targetName)) {
            player.sendMessage('§r[§b社会システム§r] §cこのプレイヤーはすでにメンバーです。');
            return;
        }

        nation.invites.push(targetName);
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${targetName}を招待しました。`);
        targetPlayer.sendMessage(`§r[§b社会システム§r] §a${nation.name}から招待されました。`);
    });
}

// 招待確認
function checkInvites(player) {
    if (!isSystemEnabled()) {
        player.sendMessage('§r[§b社会システム§r] §c社会システムは現在無効です。');
        return;
    }

    const nationData = getNationData();
    const invites = [];
    for (const nationId in nationData) {
        if (nationData[nationId].invites.includes(player.name) || nationData[nationId].membership === 'open') {
            invites.push(nationId);
        }
    }

    if (invites.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c招待がありません。');
        return;
    }

    const form = new ActionFormData().title('§5招待リスト').body(`§fどの${world.getDynamicProperty('WorldgroupName')}に参加しますか？`);
    invites.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        const selectedNation = invites[response.selection];
        const nation = nationData[selectedNation];
        if (!nation) return;

        if (nation.members.includes(player.name)) {
            player.sendMessage(`§r[§b社会システム§r] §cすでにこの${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
            return;
        }

        if (!isMultipleNationsAllowed()) {
            const playerNations = getPlayerNations(player);
            if (playerNations.length > 0) {
                player.sendMessage(`§r[§b社会システム§r] §c複数の${world.getDynamicProperty('WorldgroupName')}に所属することはできません。`);
                return;
            }
        }

        nation.members.push(player.name);
        if (nation.invites.includes(player.name)) {
            nation.invites = nation.invites.filter(name => name !== player.name);
        }
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${nation.name}に参加しました！`);
    });
}

// 国を退出
function leaveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    if (nation.leader === player.name) {
        player.sendMessage(`§r[§b社会システム§r] §cリーダーは${world.getDynamicProperty('WorldgroupName')}を退出できません。解散してください。`);
        return;
    }

    nation.members = nation.members.filter(name => name !== player.name);
    if (nation.members.length === 0) {
        delete nationData[nationId];
    }
    setNationData(nationData);
    player.sendMessage(`§r[§b社会システム§r] §a${nation.name}を退出しました。`);
}

// 国解散確認
function confirmDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}解散の確認`)
        .body(`§c本当に「§e${nation.name}§c」を解散しますか？\n§7この操作は元に戻せません。`)
        .button1('§1キャンセル')
        .button2('§4解散');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}を解散しました。`);
        }
    });
}

// メンバー権限設定
function setMemberPermissions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const members = nation.members.filter(name => name !== player.name);

    if (members.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c権限を設定できるメンバーがいません。');
        return;
    }

    const form = new ModalFormData().title('§1メンバー権限設定').dropdown('§fメンバー', members, 0).toggle('§a土地購入権限', false).toggle('§aメンバー招待権限', false);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) return;
        const [memberIndex, canBuyLand, canInvite] = response.formValues;
        const selectedMember = members[memberIndex];

        if (!nation.permissions) {
            nation.permissions = {};
        }
        if (!nation.permissions[selectedMember]) {
            nation.permissions[selectedMember] = {};
        }
        nation.permissions[selectedMember].canBuyLand = canBuyLand;
        nation.permissions[selectedMember].canInvite = canInvite;

        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${selectedMember}の権限を設定しました。\n§a土地購入: §e${canBuyLand ? '有効' : '無効'}\n§aメンバー招待: §e${canInvite ? '有効' : '無効'}`);
    });
}

// 管理者設定
export function adminSettings(player) {
    const form = new ActionFormData()
        .title('§5管理者設定')
        .body('設定を選択してください')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1システム設定')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}の管理`)
        .button('§5公共土地の管理');
    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                showSystemSettingsMenu(player);
                break;
            case 2:
                manageNations(player);
                break;
            case 3:
                managePublicLands(player);
                break;
        }
    });
}

// システム設定メニュー
function showSystemSettingsMenu(player) {
    const form = new ActionFormData()
        .title('§1社会システム設定')
        .body('§fどの設定を変更しますか？')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§4チャンク価格設定')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}作成コスト設定`)
        .button('§9社会システム\n§1有効§r/§4無効')
        .button(`§2複数${world.getDynamicProperty('WorldgroupName')}所属の許可`)
        .button('§1許可アイテム\n§8未所持の土地で利用できるアイテム')
        .button('§9未購入の土地の表示名')
        .button('§5未購入の土地での操作\n§1許可§r/§4禁止')
        .button('§2拠点種別の名称変更')
        .button(`§1${world.getDynamicProperty('WorldgroupName')}名タイトル\n§5表示§r/§1非表示`);
    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                setChunkPrice(player);
                break;
            case 2:
                setNationCreationCost(player);
                break;
            case 3:
                toggleSystemEnabled(player);
                break;
            case 4:
                toggleMultipleNations(player);
                break;
            case 5:
                var form = new ActionFormData().title('§1社会システム設定').body('§fどの設定を変更しますか？').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1アイテムを追加').button('§4アイテムを削除');
                form.show(player).then(response => {
                    if (response.canceled || response.selection === 0) {
                        adminSettings(player);
                        return;
                    }
                    switch (response.selection) {
                        case 1:
                            var form = new ModalFormData().title('§1許可アイテムを追加').textField('§5>>>追加するアイテムID\n§r(例: additem:haruphone1)', '');

                            form.show(player).then(response => {
                                if (response.canceled) return;

                                const itemId = response.formValues[0].trim();
                                if (!itemId) {
                                    player.sendMessage('§r[§b社会システム§r] §c入力が空です。アイテムIDを入力してください');
                                    return;
                                }

                                let DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                                if (DANGEROUS_ITEMS.includes(itemId)) {
                                    player.sendMessage(`§r[§b社会システム§r] §r[§b社会システム§r] §e${itemId} はすでに登録されています`);
                                    return;
                                }

                                DANGEROUS_ITEMS.push(itemId);
                                world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                                player.sendMessage(`§r[§b社会システム§r] §a${itemId} を許可アイテムとして追加しました`);
                                showSystemSettingsMenu(player);
                            });
                            break;
                        case 2:
                            const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                            if (DANGEROUS_ITEMS.length === 0) {
                                player.sendMessage('§r[§b社会システム§r] §c現在、削除できるアイテムはありません');
                                break;
                            }

                            var form = new ActionFormData().title('§4許可アイテムを削除').body('§5>>>削除したいアイテムを選んでください');

                            // ボタンをアイテムIDごとに追加
                            for (const id of DANGEROUS_ITEMS) {
                                form.button(id);
                            }

                            form.show(player).then(response => {
                                if (response.canceled) {
                                    return;
                                }
                                const selectedIndex = response.selection;
                                const removedItem = DANGEROUS_ITEMS[selectedIndex];
                                DANGEROUS_ITEMS.splice(selectedIndex, 1);

                                world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                                player.sendMessage(`§r[§b社会システム§r] §a${removedItem} をリストから削除しました`);
                                showSystemSettingsMenu(player);
                            });
                            break;
                    }
                });
                break;
            case 6:
                var form = new ModalFormData().title('§1未購入土地の表示名').textField('§5>>>表示名', `${world.getDynamicProperty('WorldspaceNAME')}`);

                form.show(player).then(response => {
                    if (response.canceled) return;

                    if (!response.formValues[0]) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。表示名を入力してください');
                        return;
                    }

                    world.setDynamicProperty('WorldspaceNAME', response.formValues[0]);
                    player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を表示名として設定しました`);
                    showSystemSettingsMenu(player);
                });
                break;
            case 7:
                toggleUnownedLandInteraction(player);
                break;
            case 8:
                var form = new ModalFormData().title('§1拠点種別の名称').textField('§5>>>名称', `${world.getDynamicProperty('WorldgroupName')}`);

                form.show(player).then(response => {
                    if (response.canceled) return;

                    if (!response.formValues[0]) {
                        player.sendMessage('§r[§b社会システム§r] §c入力が空です。名称を入力してください');
                        return;
                    }

                    world.setDynamicProperty('WorldgroupName', response.formValues[0]);
                    player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を拠点種別の名称として設定しました`);
                    showSystemSettingsMenu(player);
                });
                break;
            case 9:
                var form = new MessageFormData()
                    .title('§1タイトル表示/非表示')
                    .body(`§c${world.getDynamicProperty('WorldgroupName')}名タイトル ${world.getDynamicProperty('WorldTitle') ? '§c非表示' : '§a表示'}にしますか？`)
                    .button1('§1キャンセル')
                    .button2(world.getDynamicProperty('WorldTitle') ? '§4非表示にする' : '§1表示にする');

                form.show(player).then(response => {
                    if (response.canceled || response.selection === 0) {
                        showSystemSettingsMenu(player);
                        return;
                    }
                    if (response.selection === 1) {
                        world.setDynamicProperty('WorldTitle', !world.getDynamicProperty('WorldTitle'));
                        player.sendMessage(`§r[§b社会システム§r] §aタイトルを§e${!world.getDynamicProperty('WorldTitle') ? '非表示' : '表示'}§aにしました。`);
                    }
                    showSystemSettingsMenu(player);
                });
                break;
        }
    });
}

// 未購入の土地での操作許可/禁止切り替え（新しい関数）
function toggleUnownedLandInteraction(player) {
    const isAllowed = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
    const form = new MessageFormData()
        .title('§1未購入の土地での操作')
        .body(`§f未購入の土地でのブロック破壊/設置を${isAllowed ? '§c禁止' : '§a許可'}しますか？`)
        .button1('§1キャンセル')
        .button2(isAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(UNOWNED_LAND_INTERACTION, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a未購入の土地でのブロック破壊/設置を§e${!isAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// チャンク価格設定
function setChunkPrice(player) {
    const currentPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);
    const form = new ModalFormData().title('§1チャンク価格設定').textField('§f新しいチャンク価格', currentPrice.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [chunkPrice] = response.formValues;
        const parsedChunkPrice = parseInt(chunkPrice);

        if (isNaN(parsedChunkPrice) || parsedChunkPrice < 0) {
            player.sendMessage('§r[§b社会システム§r] §c有効なチャンク価格を入力してください。');
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, parsedChunkPrice);
        player.sendMessage(`§r[§b社会システム§r] §aチャンク価格を§e${parsedChunkPrice}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 国作成コスト設定
function setNationCreationCost(player) {
    const currentCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const form = new ModalFormData().title(`§1${world.getDynamicProperty('WorldgroupName')}作成コスト設定`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}作成コスト`, currentCost.toString());

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [creationCost] = response.formValues;
        const parsedCreationCost = parseInt(creationCost);

        if (isNaN(parsedCreationCost) || parsedCreationCost < 0) {
            player.sendMessage(`§r[§b社会システム§r] §c有効な${world.getDynamicProperty('WorldgroupName')}作成コストを入力してください。`);
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, parsedCreationCost);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}作成コストを§e${parsedCreationCost}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 社会システムの有効/無効切り替え
function toggleSystemEnabled(player) {
    const isEnabled = isSystemEnabled();
    const form = new MessageFormData()
        .title('§1社会システムの有効/無効')
        .body(`§f社会システムを${isEnabled ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(isEnabled ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(SYSTEM_ENABLED_PROPERTY, !isEnabled);
            player.sendMessage(`§r[§b社会システム§r] §a社会システムを§e${!isEnabled ? '有効' : '無効'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 複数国所属の許可/禁止切り替え
function toggleMultipleNations(player) {
    const isAllowed = isMultipleNationsAllowed();
    const form = new MessageFormData()
        .title(`§1複数${world.getDynamicProperty('WorldgroupName')}所属の許可`)
        .body(`§f複数${world.getDynamicProperty('WorldgroupName')}所属を${isAllowed ? '§c禁止' : '§a許可'}しますか？`)
        .button1('§1キャンセル')
        .button2(isAllowed ? '§4禁止する' : '§1許可する');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a複数${world.getDynamicProperty('WorldgroupName')}所属を§e${!isAllowed ? '許可' : '禁止'}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 国の管理（管理者用）
function manageNations(player) {
    const nationData = getNationData();
    const nationIds = Object.keys(nationData);

    if (nationIds.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §c現在、存在する${world.getDynamicProperty('WorldgroupName')}はありません。`);
        adminSettings(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の管理`)
        .body(`§f管理する${world.getDynamicProperty('WorldgroupName')}を選択してください。`)
        .button(`§l戻る`, 'textures/ui/icon_import.png');

    nationIds.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        const selectedNationId = nationIds[response.selection - 1];
        showNationAdminOptions(player, selectedNationId);
    });
}

// 国の管理オプション（管理者用）
function showNationAdminOptions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const memberCount = nation.members.length;
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` + `§aリーダー: §c${nation.leader}\n` + `§aメンバー数: §e${memberCount}\n` + `§aメンバー: §f${nation.members.join(', ')}\n` + `§aメンバーシップ: §e${nation.membership === 'open' ? 'オープン' : '招待制'}\n` + `§a所有チャンク数: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}の管理: ${nation.name}`)
        .body(body)
        .button('§1メンバー管理')
        .button(`§4${world.getDynamicProperty('WorldgroupName')}名変更`)
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を強制削除`)
        .button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 3) {
            manageNations(player);
            return;
        }
        switch (response.selection) {
            case 0:
                manageNationMembers(player, nationId);
                break;
            case 1:
                adminChangeNationName(player, nationId);
                break;
            case 2:
                confirmForceDissolveNation(player, nationId);
                break;
        }
    });
}

// 国のメンバー管理
function manageNationMembers(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }
    const members = nation.members;

    if (members.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}にメンバーがいません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ActionFormData().title(`§5メンバー管理§r: §1${nation.name}`).body('§fどのメンバーを管理しますか？').button(`§l戻る`, 'textures/ui/icon_import.png');

    members.forEach(member => {
        form.button(`§1${member}${member === nation.leader ? ' (§cリーダー§1)' : ''}`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const selectedMember = members[response.selection - 1];
        showMemberOptions(player, nationId, selectedMember);
    });
}

// メンバーオプション
function showMemberOptions(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNationMembers(player, nationId);
        return;
    }
    const isLeader = nation.leader === memberName;

    const form = new ActionFormData().title(`§1メンバー管理: ${memberName}`);
    if (isLeader) {
        form.body(`§f${memberName}の操作を選択してください。`);
    } else {
        form.body(`§f${memberName}の操作を選択してください。\n§a土地購入権限: §e${nation.permissions?.[memberName]?.canBuyLand ? 'あり' : 'なし'}\n§aメンバー招待権限: §e${nation.permissions?.[memberName]?.canInvite ? 'あり' : 'なし'}`);
    }

    if (!isLeader) form.button('§4リーダーに設定');
    form.button('§4土地購入権限切り替え');
    form.button('§4メンバー招待権限切り替え');
    form.button('§4メンバー除外');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) {
            manageNationMembers(player, nationId);
            return;
        }

        const backButtonIndex = isLeader ? 3 : 4;
        if (response.selection === backButtonIndex) {
            manageNationMembers(player, nationId);
            return;
        }

        if (isLeader) {
            switch (response.selection) {
                case 0:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 1:
                    toggleInvitePermission(player, nationId, memberName);
                    break;
                case 2:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        } else {
            switch (response.selection) {
                case 0:
                    setNationLeader(player, nationId, memberName);
                    break;
                case 1:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 2:
                    toggleInvitePermission(player, nationId, memberName);
                    break;
                case 3:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        }
    });
}

function toggleInvitePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canInvite || false;

    const form = new MessageFormData()
        .title('§1メンバー招待権限')
        .body(`§f${memberName}のメンバー招待権限を${currentPermission ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(currentPermission ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canInvite = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}のメンバー招待権限を${!currentPermission ? '§e有効' : '§e無効'}にしました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// リーダー設定
function setNationLeader(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData().title('§4リーダー設定').body(`§f${memberName}を${nation.name}のリーダーに設定しますか？`).button1('§1キャンセル').button2('§4設定');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.leader = memberName;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}のリーダーに設定しました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// 土地購入権限切り替え
function toggleLandPurchasePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canBuyLand || false;

    const form = new MessageFormData()
        .title('§1土地購入権限')
        .body(`§f${memberName}の土地購入権限を${currentPermission ? '§c無効' : '§a有効'}にしますか？`)
        .button1('§1キャンセル')
        .button2(currentPermission ? '§4無効にする' : '§1有効にする');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canBuyLand = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}の土地購入権限を${!currentPermission ? '§e有効' : '§e無効'}にしました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// メンバー除外確認
function confirmRemoveMember(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    if (nation.leader === memberName) {
        player.sendMessage(`§r[§b社会システム§r] §cリーダーは${world.getDynamicProperty('WorldgroupName')}から除外できません。解散してください。`);
        showMemberOptions(player, nationId, memberName);
        return;
    }

    const form = new MessageFormData().title('§4メンバー除外').body(`§c${memberName}を${nation.name}から除外しますか？`).button1('§1キャンセル').button2('§4除外');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.members = nation.members.filter(name => name !== memberName);
            if (nation.members.length === 0) {
                delete nationData[nationId];
            }
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}から除外しました。`);
            showNationAdminOptions(player, nationId);
        }
    });
}

// 国名変更（管理者用）
function adminChangeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ModalFormData().title(`§4${world.getDynamicProperty('WorldgroupName')}名変更`).textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            showNationAdminOptions(player, nationId);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, '_');
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            showNationAdminOptions(player, nationId);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
        showNationAdminOptions(player, nationId);
    });
}

// 国強制削除確認
function confirmForceDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}強制削除`)
        .body(`§c本当に「§e${nation.name}§c」を強制削除しますか？\n§7この操作は元に戻せません。`)
        .button1('§1キャンセル')
        .button2('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nation.name}§a」を強制削除しました。`);
            manageNations(player);
        }
    });
}

//公共土地関連>>>
// 公共土地管理メニュー
function managePublicLands(player) {
    const publicLandData = getPublicLandData();
    const publicLandKeys = Object.keys(publicLandData);

    const form = new ActionFormData().title('§1公共土地の管理').body('§f操作を選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1公共土地を追加/拡大').button('§4公共土地を管理');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                addPublicLand(player);
                break;
            case 2:
                if (publicLandKeys.length === 0) {
                    player.sendMessage('§r[§b社会システム§r] §c現在、公共土地はありません。');
                    managePublicLands(player);
                    return;
                }
                showPublicLandList(player);
                break;
        }
    });
}

// 公共土地追加
// 公共土地追加（addPublicLand関数を全面改修）
// 公共土地追加（addPublicLand関数を修正）
function addPublicLand(player) {
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const publicLandData = getPublicLandData();
    const chunkData = getChunkData();

    if (publicLandData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに公共土地です。');
        return;
    }
    if (chunkData[chunkKey]) {
        player.sendMessage('§r[§b社会システム§r] §cこのチャンクはすでに別の国が所有しています。');
        return;
    }

    // 公共土地の名前を一意に取得（重複を排除）
    const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];

    if (publicLandNames.length === 0) {
        // 公共土地がない場合、新規作成のみ
        const form = new ModalFormData().title('§1公共土地を追加').textField('§f新しい公共土地の名前', `公共土地 (${chunk.x}, ${chunk.z})`);

        form.show(player).then(response => {
            if (response.canceled || !response.formValues) {
                managePublicLands(player);
                return;
            }
            const [landName] = response.formValues;
            if (!landName) {
                player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                managePublicLands(player);
                return;
            }

            publicLandData[chunkKey] = { name: landName };
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」を追加しました。`);
            managePublicLands(player);
        });
    } else {
        // 既存の公共土地がある場合、選択または新規作成
        const form = new ActionFormData().title('§1公共土地を追加').body(`§fチャンク (§e${chunk.x}, ${chunk.z}§f)\nどの公共土地に追加しますか？\n§7または新しい公共土地を作成します。`).button(`§l戻る`, 'textures/ui/icon_import.png');

        publicLandNames.forEach(name => {
            form.button(`§5${name}`);
        });
        form.button('§1新しい公共土地を作成');

        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) {
                managePublicLands(player);
                return;
            }

            if (response.selection === publicLandNames.length + 1) {
                // 新しい公共土地を作成
                const newForm = new ModalFormData().title('§1新しい公共土地').textField('§f公共土地の名前', `公共土地 (${chunk.x}, ${chunk.z})`);

                newForm.show(player).then(newResponse => {
                    if (newResponse.canceled || !newResponse.formValues) {
                        managePublicLands(player);
                        return;
                    }
                    const [landName] = newResponse.formValues;
                    if (!landName) {
                        player.sendMessage('§r[§b社会システム§r] §c公共土地の名前を入力してください。');
                        managePublicLands(player);
                        return;
                    }

                    publicLandData[chunkKey] = { name: landName };
                    setPublicLandData(publicLandData);
                    player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」を追加しました。`);
                    managePublicLands(player);
                });
            } else {
                // 既存の公共土地に追加
                const selectedName = publicLandNames[response.selection - 1];

                const confirmForm = new MessageFormData().title('§1公共土地の追加確認').body(`§fチャンク (§e${chunk.x}, ${chunk.z}§f)\n公共土地「§e${selectedName}§f」に追加しますか？`).button1('§1キャンセル').button2('§1追加');

                confirmForm.show(player).then(confirmResponse => {
                    if (confirmResponse.canceled || confirmResponse.selection === 0) {
                        managePublicLands(player);
                        return;
                    }
                    if (confirmResponse.selection === 1) {
                        publicLandData[chunkKey] = { name: selectedName };
                        setPublicLandData(publicLandData);
                        player.sendMessage(`§r[§b社会システム§r] §aチャンクを公共土地「§e${selectedName}§a」に追加しました。`);
                        managePublicLands(player);
                    }
                });
            }
        });
    }
}

// 公共土地リスト表示
// 公共土地リスト表示（showPublicLandList関数を修正）
function showPublicLandList(player) {
    const publicLandData = getPublicLandData();

    // 公共土地の名前を一意に取得（重複を排除）
    const publicLandNames = [...new Set(Object.values(publicLandData).map(land => land.name))];

    if (publicLandNames.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §c現在、公共土地はありません。');
        managePublicLands(player);
        return;
    }

    const form = new ActionFormData().title('§1公共土地の管理').body('§f管理する公共土地を選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png');

    publicLandNames.forEach(name => {
        // 同じ名前のチャンク数を取得
        const chunkCount = Object.values(publicLandData).filter(land => land.name === name).length;
        form.button(`§5${name}\n§0(${chunkCount}チャンク)`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLands(player);
            return;
        }
        const selectedName = publicLandNames[response.selection - 1];
        managePublicLandByName(player, selectedName);
    });
}

// 名前ベースの公共土地管理（新関数）
function managePublicLandByName(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    const form = new ActionFormData().title(`§1公共土地: ${landName}`).body(`§f名前: §e${landName}\n§fチャンク数: §e${relatedChunks.length}\n§f管理する操作を選択してください。`).button('§4名前を変更').button('§4チャンクを削除').button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 2) {
            showPublicLandList(player);
            return;
        }
        switch (response.selection) {
            case 0:
                renamePublicLandByName(player, landName);
                break;
            case 1:
                selectChunkToRemove(player, landName);
                break;
        }
    });
}

// 名前ベースの公共土地名前変更（managePublicLandのrenamePublicLandを改変）
function renamePublicLandByName(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    if (relatedChunks.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        return;
    }

    const form = new ModalFormData().title('§1公共土地の名前変更').textField('§f新しい名前', landName);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            managePublicLandByName(player, landName);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage('§r[§b社会システム§r] §c名前を入力してください。');
            managePublicLandByName(player, landName);
            return;
        }

        relatedChunks.forEach(key => {
            publicLandData[key].name = newName;
        });
        setPublicLandData(publicLandData);
        player.sendMessage(`§r[§b社会システム§r] §a公共土地の名前を「§e${newName}§a」に変更しました。`);
        managePublicLandByName(player, newName);
    });
}

// チャンク削除選択（新関数）
function selectChunkToRemove(player, landName) {
    const publicLandData = getPublicLandData();
    const relatedChunks = Object.keys(publicLandData).filter(key => publicLandData[key].name === landName);

    if (relatedChunks.length === 0) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        return;
    }

    const form = new ActionFormData().title(`§1${landName}: チャンク削除`).body(`§f削除するチャンクを選択してください。\n§e${landName} (§7${relatedChunks.length}チャンク§e）`).button(`§l戻る`, 'textures/ui/icon_import.png').button(`§4すべて削除 (${relatedChunks.length}チャンク)`);

    relatedChunks.forEach(key => {
        form.button(`§5${key}`);
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            // すべて削除
            confirmRemovePublicLandByName(player, landName, relatedChunks);
        } else {
            // 個別チャンク削除
            const selectedKey = relatedChunks[response.selection - 2];
            confirmRemovePublicLandByName(player, landName, [selectedKey]);
        }
    });
}

// 名前ベースの公共土地削除確認（confirmRemovePublicLandを改変）
function confirmRemovePublicLandByName(player, landName, chunkKeys) {
    const publicLandData = getPublicLandData();
    const chunkCount = chunkKeys.length;

    const form = new MessageFormData().title('§4公共土地の削除').body(`§c公共土地「§e${landName}§c」の${chunkCount}チャンクを削除しますか？\n§7この操作は元に戻せません。`).button1('§1キャンセル').button2('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLandByName(player, landName);
            return;
        }
        if (response.selection === 1) {
            chunkKeys.forEach(key => {
                delete publicLandData[key];
            });
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${landName}§a」から${chunkCount}チャンクを削除しました。`);
            showPublicLandList(player);
        }
    });
}

// 個別公共土地管理
function managePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        return;
    }

    const form = new ActionFormData().title(`§a公共土地: ${land.name}`).body(`§f座標: §e${chunkKey}\n§f名前: §e${land.name}`).button('§4名前を変更').button('§4公共土地を削除').button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 2) {
            showPublicLandList(player);
            return;
        }
        switch (response.selection) {
            case 0:
                renamePublicLand(player, chunkKey);
                break;
            case 1:
                confirmRemovePublicLand(player, chunkKey);
                break;
        }
    });
}

// 公共土地の名前変更
function renamePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        return;
    }

    const form = new ModalFormData().title('§1公共土地の名前変更').textField('§f新しい名前', land.name);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            managePublicLand(player, chunkKey);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage('§r[§b社会システム§r] §c名前を入力してください。');
            managePublicLand(player, chunkKey);
            return;
        }

        publicLandData[chunkKey].name = newName;
        setPublicLandData(publicLandData);
        player.sendMessage(`§r[§b社会システム§r] §a公共土地の名前を「§e${newName}§a」に変更しました。`);
        managePublicLand(player, chunkKey);
    });
}

// 公共土地削除確認
function confirmRemovePublicLand(player, chunkKey) {
    const publicLandData = getPublicLandData();
    const land = publicLandData[chunkKey];
    if (!land) {
        player.sendMessage('§r[§b社会システム§r] §cこの公共土地は存在しません。');
        showPublicLandList(player);
        managePublicLand(player, chunkKey);
    }

    const form = new MessageFormData().title('§4公共土地の削除').body(`§c公共土地「§e${land.name}§c」を削除しますか？\n§7この操作は元に戻せません。`).button1('§1キャンセル').button2('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            managePublicLand(player, chunkKey);
            return;
        }
        if (response.selection === 1) {
            delete publicLandData[chunkKey];
            setPublicLandData(publicLandData);
            player.sendMessage(`§r[§b社会システム§r] §a公共土地「§e${land.name}§a」を削除しました。`);
            showPublicLandList(player);
        }
    });
}

world.beforeEvents.playerBreakBlock.subscribe(event => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const chunk = getChunkCoords(event.block.location);
    const chunkData = getChunkData();
    const publicLandData = getPublicLandData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = '';

    if (publicLandData[chunkKey]) {
        return; // 公共土地では破壊を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを破壊できません。';
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        event.cancel = true;
        const now = Date.now();
        const last = lastWarnTime.get(player.id) ?? 0;
        if (now - last >= 3000) {
            player.sendMessage(message);
            lastWarnTime.set(player.id, now);
        }
    }
});

world.afterEvents.playerPlaceBlock.subscribe(event => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const block = event.block;
    const chunk = getChunkCoords(block.location);
    const chunkData = getChunkData();
    const publicLandData = getPublicLandData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = '';

    if (publicLandData[chunkKey]) {
        return; // 公共土地では設置を許可
    }
    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを設置できません。';
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        try {
            block.dimension.runCommandAsync(`setblock ${block.x} ${block.y} ${block.z} air`);
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        } catch (e) {
            console.warn('設置されたブロックの削除に失敗:', e);
        }
    }
});

// 危険なアイテムの使用制限
const lastWarnTime = new Map(); // プレイヤーごとの警告タイムスタンプ

world.beforeEvents.itemUseOn.subscribe(event => {
    if (!isSystemEnabled()) return;

    const player = event.source;
    const item = event.itemStack;
    if (player.typeId !== 'minecraft:player') return;

    const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
    if (!DANGEROUS_ITEMS.includes(item?.typeId)) {
        const chunk = getChunkCoords(player.location);
        const chunkData = getChunkData();
        const publicLandData = getPublicLandData();
        const chunkKey = `${chunk.x}:${chunk.z}`;

        let shouldCancel = false;
        let message = '';

        if (publicLandData[chunkKey]) {
            return; // 公共土地ではアイテム使用を許可
        }
        if (!chunkData[chunkKey]) {
            const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
            if (!allowInteraction) {
                shouldCancel = true;
                message = '§r[§b社会システム§r] §cこのチャンクは購入されていません。このアイテムを使用できません。';
            }
        } else {
            const nationData = getNationData();
            const nation = nationData[chunkData[chunkKey].nation];
            if (!nation || !nation.members.includes(player.name)) {
                shouldCancel = true;
                message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。このアイテムは使用できません。`;
            }
        }

        if (shouldCancel) {
            event.cancel = true;
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) {
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        }
    }
});

// プレイヤーの最後の国IDを保持するマップ（チャンクキーではなく国IDを追跡）
const lastPlayerNation = new Map();

// 定期的にプレイヤーの国移動を監視
// 国移動時のタイトル表示修正（system.runInterval全体を置き換え）
// 国移動時のタイトル表示修正（system.runInterval全体を置き換え）
system.runInterval(() => {
    if (!isSystemEnabled()) return;

    for (const player of world.getPlayers()) {
        const chunk = getChunkCoords(player.location);
        const chunkKey = `${chunk.x}:${chunk.z}`;
        const chunkData = getChunkData();
        const nationData = getNationData();
        const publicLandData = getPublicLandData();

        // 現在の場所のIDと名前を取得（公共土地、国、未所属の順）
        let currentLocationId = null;
        let currentLocationName = `§r${world.getDynamicProperty('WorldspaceNAME')}`;

        if (publicLandData[chunkKey]) {
            const landName = publicLandData[chunkKey].name.trim(); // 空白をトリムして正規化
            currentLocationId = `public:${landName}`;
            currentLocationName = `§e${landName}`;
        } else if (chunkData[chunkKey]?.nation) {
            const nationId = chunkData[chunkKey].nation;
            currentLocationId = `nation:${nationId}`;
            const nation = nationData[nationId];
            if (nation) {
                currentLocationName = `§a${nation.name}`;
            }
        }

        const lastLocationId = lastPlayerNation.get(player.id);

        // 場所が変更された場合のみタイトルを表示
        if (lastLocationId !== currentLocationId && world.getDynamicProperty('WorldTitle')) {
            try {
                player.runCommandAsync(`title ${player.name} title §a${currentLocationName}§r`);
                lastPlayerNation.set(player.id, currentLocationId);
            } catch (e) {
                console.warn(`Failed to display title for ${player.name}:`, e);
            }
        }
    }
}, 20); // 20ティック（1秒）ごとにチェック

// プレイヤー参加時の初期位置設定修正（playerSpawnイベント全体を置き換え）
world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    // データ読み込みの安定性を高めるため、1ティックの遅延を追加
    system.runTimeout(() => {
        try {
            const chunk = getChunkCoords(player.location);
            const chunkKey = `${chunk.x}:${chunk.z}`;
            const chunkData = getChunkData();
            const publicLandData = getPublicLandData();

            let locationId = null;
            if (publicLandData[chunkKey]) {
                const landName = publicLandData[chunkKey].name.trim();
                locationId = `public:${landName}`;
            } else if (chunkData[chunkKey]?.nation) {
                locationId = `nation:${chunkData[chunkKey].nation}`;
            }
            lastPlayerNation.set(player.id, locationId);
        } catch (e) {
            console.warn(`Failed to initialize nation data for player ${player.name}:`, e);
        }
    }, 1);
});
