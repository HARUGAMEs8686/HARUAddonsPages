import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

var player_Cash_Data = {};

export function Game(eventData) {
    const player = eventData.player;
    player_Cash_Data[player.id] = {};
    system.run(() => {
        if (!player_Cash_Data[player.id].TitaniumStop) {
            player_Cash_Data[player.id].TitaniumStop = true;
            //ここから実行
            Game_system(player);
            //ここまで
            system.runTimeout(() => {
                player_Cash_Data[player.id].TitaniumStop = false;
            }, 20);
        }
    });
}

function Game_system(player) {
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    var form = new ActionFormData();
    form.title('§1GAME');
    form.body(`§l§b${time}`);
    form.button('§1ラッキーレター', 'textures/ui/haruapp');
    form.button('§1ハイアンドロー', 'textures/ui/haruapp');
    if (player.hasTag('HARUPhoneOP')) {
        form.button('§0設定', 'textures/ui/haruapp');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                const activePlayers = new Set();
                const playerTimers = new Map();

                // プレイヤーのタイマーをクリア
                function clearPlayerTimers(playerId) {
                    if (playerTimers.has(playerId)) {
                        playerTimers.get(playerId).forEach(timerId => system.clearRun(timerId));
                        playerTimers.delete(playerId);
                    }
                }

                // スコアボード操作
                async function getMoney(player) {
                    return new Promise(resolve => {
                        system.run(() => {
                            const score = world.scoreboard.getObjective('money')?.getScore(player.scoreboardIdentity) ?? 0;
                            resolve(score);
                        });
                    });
                }

                function setMoney(player, amount) {
                    system.run(() => {
                        let objective = world.scoreboard.getObjective('money');
                        if (!objective) {
                            world.scoreboard.addObjective('money', 'Money');
                            objective = world.scoreboard.getObjective('money');
                        }
                        objective.setScore(player.scoreboardIdentity, amount);
                    });
                }

                // 選択肢の生成（A〜Zまで対応）
                function generateLetters(count) {
                    if (count < 1 || count > 26) throw new Error('選択肢の数は1〜26で設定してください');
                    return Array.from({ length: count }, (_, i) => String.fromCharCode(65 + i)); // A=65
                }

                // ベット金額選択フォーム
                async function openBetForm(player) {
                    if (activePlayers.has(player.id)) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§c現在ゲーム中です！"}]}`);
                        return;
                    }
                    activePlayers.add(player.id);

                    try {
                        // グローバル設定をローカルにコピー
                        const MULTIPLIER = world.getDynamicProperty('MULTIPLIER') ?? 3;
                        const TOTAL_LETTERS = world.getDynamicProperty('TOTAL_LETTERS') ?? 10;
                        const WINNING_COUNT = world.getDynamicProperty('WINNING_COUNT') ?? 1;
                        const text = world.getDynamicProperty('BET_AMOUNTS') ?? '100,500,1000';
                        const BET_AMOUNTS = text.split(',').map(Number);

                        // ベット金額のバリデーション
                        if (BET_AMOUNTS.length === 0 || BET_AMOUNTS.some(amount => amount <= 0)) {
                            throw new Error('ベット金額が無効です');
                        }

                        const current = await getMoney(player);
                        const form = new ActionFormData().title('§0賭け金を選択').body(`§aHARUPAY残高§r: §b${current}`);

                        // 動的にベット金額ボタンを追加
                        BET_AMOUNTS.forEach((amount, index) => {
                            form.button(`§${(index % 5) + 1}${amount}`);
                        });
                        form.button('§5>>>やめる§5<<<');

                        form.show(player)
                            .then(async res => {
                                try {
                                    if (res.canceled || res.selection === BET_AMOUNTS.length) {
                                        Game_system(player);
                                        return;
                                    }

                                    const bet = BET_AMOUNTS[res.selection];
                                    const currentMoney = await getMoney(player);

                                    if (currentMoney < bet) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                                        return;
                                    }

                                    await openLetterForm(player, bet, MULTIPLIER, TOTAL_LETTERS, WINNING_COUNT);
                                } finally {
                                    activePlayers.delete(player.id);
                                }
                            })
                            .catch(() => {
                                activePlayers.delete(player.id);
                            });
                    } catch (e) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        activePlayers.delete(player.id);
                    }
                }

                // A〜?の選択フォーム
                async function openLetterForm(player, bet, MULTIPLIER, TOTAL_LETTERS, WINNING_COUNT) {
                    try {
                        // 設定のバリデーション
                        if (WINNING_COUNT > TOTAL_LETTERS) {
                            throw new Error('当たり数が選択肢数を超えています');
                        }

                        const letters = generateLetters(TOTAL_LETTERS);
                        const winProbability = ((WINNING_COUNT / TOTAL_LETTERS) * 100).toFixed(1);

                        const form = new ActionFormData().title('§0ギャンブルチャレンジ！').body(`§a賭け金§r: §b${bet}\n` + `§5>>>§c${letters.length}個中${WINNING_COUNT}つ§rの当たりで§e${bet * MULTIPLIER}§rゲット！\n` + `§d当たり確率: ${winProbability}%`);

                        letters.forEach(letter => form.button(`§1${letter}§r`));
                        form.button('§cやめる§r');

                        // ランダムに当たりインデックスを選択
                        const correctIndices = [];
                        while (correctIndices.length < WINNING_COUNT) {
                            const index = Math.floor(Math.random() * TOTAL_LETTERS);
                            if (!correctIndices.includes(index)) correctIndices.push(index);
                        }

                        clearPlayerTimers(player.id); // 既存のタイマーをクリア
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);

                        form.show(player)
                            .then(async res => {
                                try {
                                    if (res.canceled || res.selection === letters.length) {
                                        activePlayers.delete(player.id);
                                        return;
                                    }

                                    player.runCommandAsync(`playsound random.click @s`);
                                    const current = await getMoney(player);
                                    if (current < bet) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                                        return;
                                    }

                                    setMoney(player, current - bet);

                                    // カウントダウン演出
                                    const timers = [];
                                    await player.runCommandAsync(`title @s title §e3`);
                                    const timer1 = system.runTimeout(async () => {
                                        await player.runCommandAsync(`title @s title §e2`);
                                        const timer2 = system.runTimeout(async () => {
                                            await player.runCommandAsync(`title @s title §e1`);
                                            const timer3 = system.runTimeout(async () => {
                                                if (correctIndices.includes(res.selection)) {
                                                    const reward = bet * MULTIPLIER;
                                                    setMoney(player, (await getMoney(player)) + reward);
                                                    await player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a当たり!!!§b${letters[res.selection]}§cが正解！§a+§e${reward}"}]}`);
                                                    await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                                    system.runTimeout(async () => {
                                                        await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 2.5 0.5`);
                                                    }, 2);
                                                } else {
                                                    await player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§9ハズレ...§c正解は §b${correctIndices.map(i => letters[i]).join('と')} §cでした…"}]}`);
                                                    await player.runCommandAsync(`particle minecraft:smoke_particle ~ ~1 ~`);
                                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 0.3 0.5`);
                                                }
                                                system.runTimeout(async () => {
                                                    clearPlayerTimers(player.id);
                                                    await openBetForm(player);
                                                }, 20);
                                            }, 20);
                                            timers.push(timer3);
                                        }, 20);
                                        timers.push(timer2);
                                    }, 20);
                                    timers.push(timer1);
                                    playerTimers.set(player.id, timers);
                                } catch (e) {
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                                } finally {
                                    if (!playerTimers.has(player.id)) {
                                        activePlayers.delete(player.id);
                                    }
                                }
                            })
                            .catch(() => {
                                clearPlayerTimers(player.id);
                                activePlayers.delete(player.id);
                            });
                    } catch (e) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        activePlayers.delete(player.id);
                    }
                }

                // ゲーム開始
                openBetForm(player);
                break;
            case 1:
                // ハイアンドローゲーム開始
                openHighAndLowGame(player);
                break;
            case 2:
                var form = new ActionFormData();
                form.title(`§1GAME`);
                form.body(`§a設定`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.button(`§5ラッキーレター`);
                form.button(`§5ハイアンドロー`);
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //戻る
                            Game_system(player);
                            break;
                        case 1:
                            form = new ModalFormData();
                            form.title(`§1GAME`);
                            form.textField(`§e報酬倍率`, `${world.getDynamicProperty('MULTIPLIER')}`);
                            form.textField(`§a選択肢の数`, `${world.getDynamicProperty('TOTAL_LETTERS')}`);
                            form.textField(`§d当たりの数`, `${world.getDynamicProperty('WINNING_COUNT')}`);
                            form.textField(`§cベット金額`, `${world.getDynamicProperty('BET_AMOUNTS')}`);
                            form.show(player).then(r => {
                                if (r.canceled) {
                                    return;
                                }
                                if (r.formValues[0] != '') {
                                    world.setDynamicProperty('MULTIPLIER', Number(r.formValues[0]));
                                }
                                if (r.formValues[1] != '') {
                                    world.setDynamicProperty('TOTAL_LETTERS', Number(r.formValues[1]));
                                }
                                if (r.formValues[2] != '') {
                                    world.setDynamicProperty('WINNING_COUNT', Number(r.formValues[2]));
                                }
                                if (r.formValues[3] != '') {
                                    world.setDynamicProperty('BET_AMOUNTS', r.formValues[3]);
                                }
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                Game_system(player);
                            });
                            break;
                        case 2:
                            // ハイアンドロー設定
                            form = new ModalFormData();
                            form.title(`§1ハイアンドロー設定`);
                            form.textField(`§e報酬倍率`, `${world.getDynamicProperty('HL_MULTIPLIER') ?? 2}`);
                            form.textField(`§a選択肢の数`, `${world.getDynamicProperty('HL_TOTAL_CHOICES') ?? 5}`);
                            form.textField(`§d当たりの数`, `${world.getDynamicProperty('HL_WINNING_CHOICE') ?? 1}`);
                            form.textField(`§cベット金額`, `${world.getDynamicProperty('HL_BET_AMOUNTS') ?? '100,500,1000'}`);
                            form.textField(`§b最大ラウンド数`, `${world.getDynamicProperty('HL_MAX_ROUNDS') ?? 5}`);
                            form.dropdown(`§a難易度上昇`, ['なし', 'カード範囲縮小', '倍率低下'], world.getDynamicProperty('HL_DIFFICULTY_INCREASE') ?? 0);
                            form.show(player).then(r => {
                                if (r.canceled) {
                                    return;
                                }
                                if (r.formValues[0] != '') {
                                    world.setDynamicProperty('HL_MULTIPLIER', Number(r.formValues[0]));
                                }
                                if (r.formValues[1] != '') {
                                    world.setDynamicProperty('HL_TOTAL_CHOICES', Number(r.formValues[1]));
                                }
                                if (r.formValues[2] != '') {
                                    world.setDynamicProperty('HL_WINNING_CHOICE', Number(r.formValues[2]));
                                }
                                if (r.formValues[3] != '') {
                                    world.setDynamicProperty('HL_BET_AMOUNTS', r.formValues[3]);
                                }
                                if (r.formValues[4] != '') {
                                    world.setDynamicProperty('HL_MAX_ROUNDS', Number(r.formValues[4]));
                                }
                                world.setDynamicProperty('HL_DIFFICULTY_INCREASE', r.formValues[5]);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                Game_system(player);
                            });
                            break;
                    }
                });
                break;
        }
    });
}

async function openHighAndLowGame(player) {
    const activePlayers = new Set();
    const playerTimers = new Map();

    // プレイヤーのタイマーをクリア
    function clearPlayerTimers(playerId) {
        if (playerTimers.has(playerId)) {
            playerTimers.get(playerId).forEach(timerId => system.clearRun(timerId));
            playerTimers.delete(playerId);
        }
    }

    // スコアボード操作
    async function getMoney(player) {
        return new Promise((resolve) => {
            system.run(() => {
                const score = world.scoreboard.getObjective("money")?.getScore(player.scoreboardIdentity) ?? 0;
                resolve(score);
            });
        });
    }

    function setMoney(player, amount) {
        system.run(() => {
            let objective = world.scoreboard.getObjective("money");
            if (!objective) {
                world.scoreboard.addObjective("money", "Money");
                objective = world.scoreboard.getObjective("money");
            }
            objective.setScore(player.scoreboardIdentity, amount);
        });
    }

    // 初期選択フォーム（5つの選択肢）
    async function openInitialSelectionForm(player) {
        if (activePlayers.has(player.id)) {
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§c現在ゲーム中です！"}]}`);
            return;
        }
        activePlayers.add(player.id);

        try {
            const TOTAL_CHOICES = world.getDynamicProperty('HL_TOTAL_CHOICES') ?? 5;
            const WINNING_CHOICE = world.getDynamicProperty('HL_WINNING_CHOICE') ?? 1;
            const text = world.getDynamicProperty('HL_BET_AMOUNTS') ?? "100,500,1000";
            const BET_AMOUNTS = text.split(',').map(Number);

            if (BET_AMOUNTS.length === 0 || BET_AMOUNTS.some(amount => amount <= 0)) {
                throw new Error("ベット金額が無効です");
            }

            const current = await getMoney(player);
            const form = new ActionFormData()
                .title("§0ハイアンドロー - 賭け金選択")
                .body(`§aHARUPAY残高§r: §b${current}`);

            BET_AMOUNTS.forEach((amount, index) => {
                form.button(`§${index % 5 + 1}${amount}`);
            });
            form.button("§5>>>やめる§5<<<");

            form.show(player).then(async res => {
                try {
                    if (res.canceled || res.selection === BET_AMOUNTS.length) {
                        activePlayers.delete(player.id);
                        return;
                    }

                    const bet = BET_AMOUNTS[res.selection];
                    const currentMoney = await getMoney(player);

                    if (currentMoney < bet) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        return;
                    }

                    await openChoiceForm(player, bet, TOTAL_CHOICES, WINNING_CHOICE);
                } finally {
                    activePlayers.delete(player.id);
                }
            }).catch(() => {
                activePlayers.delete(player.id);
            });
        } catch (e) {
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
            activePlayers.delete(player.id);
        }
    }

    // 5つの選択肢から当たりを選ぶフォーム
    async function openChoiceForm(player, bet, TOTAL_CHOICES, WINNING_CHOICE) {
        try {
            if (WINNING_CHOICE > TOTAL_CHOICES) {
                throw new Error("当たり数が選択肢数を超えています");
            }

            // 選択肢をアルファベットに変更（A=65）
            const choices = Array.from({ length: TOTAL_CHOICES }, (_, i) => String.fromCharCode(65 + i));
            const winProbability = ((WINNING_CHOICE / TOTAL_CHOICES) * 100).toFixed(1);

            const form = new ActionFormData()
                .title("§0ハイアンドロー - チャレンジ！")
                .body(
                    `§a賭け金§r: §b${bet}\n` +
                    `§5>>>§c${choices.length}個中${WINNING_CHOICE}つ§rの当たり！\n` +
                    `§d当たり確率: ${winProbability}%`
                );

            choices.forEach(choice => form.button(`§1${choice}§r`));
            form.button("§5>>>やめる§5<<<");

            const correctIndices = [];
            while (correctIndices.length < WINNING_CHOICE) {
                const index = Math.floor(Math.random() * TOTAL_CHOICES);
                if (!correctIndices.includes(index)) correctIndices.push(index);
            }

            clearPlayerTimers(player.id);
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);

            form.show(player).then(async res => {
                try {
                    if (res.canceled || res.selection === choices.length) {
                        activePlayers.delete(player.id);
                        return;
                    }

                    player.runCommandAsync(`playsound random.click @s`);
                    const current = await getMoney(player);
                    if (current < bet) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        return;
                    }

                    setMoney(player, current - bet);

                    await player.runCommandAsync(`title @s title §e3`);
                    const timers = [];
                    const timer1 = system.runTimeout(async () => {
                        await player.runCommandAsync(`title @s title §e2`);
                        const timer2 = system.runTimeout(async () => {
                            await player.runCommandAsync(`title @s title §e1`);
                            const timer3 = system.runTimeout(async () => {
                                if (correctIndices.includes(res.selection)) {
                                    await player.runCommandAsync(
                                        `tellraw @s {"rawtext":[{"text":"§a当たり!!!§b${choices[res.selection]}§cが正解！ハイアンドロー開始！"}]}`
                                    );
                                    await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                    system.runTimeout(async () => {
                                        await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 2.5 0.5`);
                                        await openHighLowRound(player, bet, bet, 1);
                                    }, 2);
                                } else {
                                    await player.runCommandAsync(
                                        `tellraw @s {"rawtext":[{"text":"§9ハズレ...§c正解は §b${correctIndices
                                            .map(i => choices[i])
                                            .join("と")} §cでした…"}]}`
                                    );
                                    await player.runCommandAsync(`particle minecraft:smoke_particle ~ ~1 ~`);
                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 0.3 0.5`);
                                    system.runTimeout(async () => {
                                        clearPlayerTimers(player.id);
                                        await openInitialSelectionForm(player);
                                    }, 20);
                                }
                            }, 20);
                            timers.push(timer3);
                        }, 20);
                        timers.push(timer2);
                    }, 20);
                    timers.push(timer1);
                    playerTimers.set(player.id, timers);
                } catch (e) {
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                    activePlayers.delete(player.id);
                }
            }).catch(() => {
                clearPlayerTimers(player.id);
                activePlayers.delete(player.id);
            });
        } catch (e) {
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
            activePlayers.delete(player.id);
        }
    }

    // ハイアンドローゲームのラウンド
    async function openHighLowRound(player, initialBet, currentBet, round = 1) {
        try {
            const MULTIPLIER = world.getDynamicProperty('HL_MULTIPLIER') ?? 2;
            const MAX_ROUNDS = world.getDynamicProperty('HL_MAX_ROUNDS') ?? 5;
            const DIFFICULTY_INCREASE = world.getDynamicProperty('HL_DIFFICULTY_INCREASE') ?? 0;

            // 最大ラウンド数に達したら終了
            if (round > MAX_ROUNDS) {
                setMoney(player, await getMoney(player) + currentBet);
                await player.runCommandAsync(
                    `tellraw @s {"rawtext":[{"text":"§a最大ラウンド到達！報酬§b${currentBet}§aを受け取りました！"}]}`
                );
                await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                system.runTimeout(async () => {
                    clearPlayerTimers(player.id);
                    await openInitialSelectionForm(player);
                }, 20);
                return;
            }

            // カード範囲の調整（難易度上昇：カード範囲縮小）
            let cardRange = 13; // デフォルト1～13
            if (DIFFICULTY_INCREASE === 1) { // カード範囲縮小
                cardRange = Math.max(5, 13 - Math.floor(round / 2)); // ラウンドが進むと範囲が狭まる
            }
            const cards = Array.from({ length: cardRange }, (_, i) => i + 1);
            const currentCard = cards[Math.floor(Math.random() * cards.length)];
            const remainingCards = cards.filter(card => card !== currentCard);
            const hiddenCard = remainingCards[Math.floor(Math.random() * remainingCards.length)];

            // 倍率の調整（難易度上昇：倍率低下）
            let roundMultiplier = MULTIPLIER;
            if (DIFFICULTY_INCREASE === 2) { // 倍率低下
                roundMultiplier = Math.max(1.1, MULTIPLIER - (round - 1) * 0.2); // ラウンドごとに倍率低下
            }

            // カード範囲をフォームに表示
            const rangeText = DIFFICULTY_INCREASE === 1 ? `§aカード範囲§r: §b1～${cardRange}\n` : '';

            const form = new ActionFormData()
                .title(`§0ハイアンドロー - ラウンド${round}/${MAX_ROUNDS}`)
                .body(
                    `§a現在のカード§r: §b${currentCard}\n` +
                    rangeText + // カード範囲をここで表示
                    `§a現在の賭け金§r: §b${currentBet}\n` +
                    `§a現在の倍率§r: §b${roundMultiplier.toFixed(2)}倍\n` +
                    `§5>>>§c次のカードは${currentCard}より高い？低い？`
                );

            form.button("§1ハイ§r");
            form.button("§1ロー§r");
            form.button("§5報酬を受け取る§r");
            form.button("§5>>>やめる§5<<<");

            form.show(player).then(async res => {
                try {
                    if (res.canceled || res.selection === 3) {
                        activePlayers.delete(player.id);
                        return;
                    }

                    if (res.selection === 2) {
                        setMoney(player, await getMoney(player) + currentBet);
                        await player.runCommandAsync(
                            `tellraw @s {"rawtext":[{"text":"§a報酬§b${currentBet}§aを受け取りました！"}]}`
                        );
                        await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                        await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                        system.runTimeout(async () => {
                            clearPlayerTimers(player.id);
                            await openInitialSelectionForm(player);
                        }, 20);
                        return;
                    }

                    const isHigh = res.selection === 0;
                    const isCorrect = (isHigh && hiddenCard > currentCard) || (!isHigh && hiddenCard < currentCard);

                    await player.runCommandAsync(`title @s title §e3`);
                    const timers = [];
                    const timer1 = system.runTimeout(async () => {
                        await player.runCommandAsync(`title @s title §e2`);
                        const timer2 = system.runTimeout(async () => {
                            await player.runCommandAsync(`title @s title §e1`);
                            const timer3 = system.runTimeout(async () => {
                                if (isCorrect) {
                                    const newBet = Math.floor(currentBet * roundMultiplier);
                                    await player.runCommandAsync(
                                        `tellraw @s {"rawtext":[{"text":"§a当たり!!!§b${hiddenCard}§cが正解！次の賭け金: §e${newBet}"}]}`
                                    );
                                    await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                    system.runTimeout(async () => {
                                        await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 2.5 0.5`);
                                        await openHighLowRound(player, initialBet, newBet, round + 1);
                                    }, 2);
                                } else {
                                    await player.runCommandAsync(
                                        `tellraw @s {"rawtext":[{"text":"§9ハズレ...§c正解は§b${hiddenCard}§cでした…"}]}`
                                    );
                                    await player.runCommandAsync(`particle minecraft:smoke_particle ~ ~1 ~`);
                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 0.3 0.5`);
                                    system.runTimeout(async () => {
                                        clearPlayerTimers(player.id);
                                        await openInitialSelectionForm(player);
                                    }, 20);
                                }
                            }, 20);
                            timers.push(timer3);
                        }, 20);
                        timers.push(timer2);
                    }, 20);
                    timers.push(timer1);
                    playerTimers.set(player.id, timers);
                } catch (e) {
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                    activePlayers.delete(player.id);
                }
            }).catch(() => {
                clearPlayerTimers(player.id);
                activePlayers.delete(player.id);
            });
        } catch (e) {
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
            activePlayers.delete(player.id);
        }
    }

    // ゲーム開始
    await openInitialSelectionForm(player);
}