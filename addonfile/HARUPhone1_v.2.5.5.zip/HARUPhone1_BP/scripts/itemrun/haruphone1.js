import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

import { config } from '../config';

import { chatLoop4 } from '../HaruAssistant/Insight-4/assistantMain';
import { chatLoop3 } from '../HaruAssistant/Insight-3/assistantMain';

import { App } from '../App/AppMenu';
import { Operator_Controller } from '../system/Operator_Controller';

import { showMainUI } from '../system/country';

import { openUserNavigationForm } from '../system/Map';

//一時データ
export var player_Cash_Data = {};
//請求データ
export var Claim = {};
//仕事募集データ
export var quest = [[], []];

//Quick関連
// 初期化時に保存済みデータを読み込む
export function loadShopMenu() {
    const savedData = world.getDynamicProperty('shop_menu');
    if (savedData) {
        return JSON.parse(savedData);
    }
    return [[], []]; // デフォルト値（初回起動時用）
}

//HARUPAYチャージ関連
function removeItemsFromInventory(player, itemId, count) {
    const inv = player.getComponent('minecraft:inventory').container;
    let removed = 0;

    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (!item || item.typeId !== itemId) continue;

        const remove = Math.min(item.amount, count - removed);
        if (remove <= 0) continue;

        if (item.amount - remove > 0) {
            item.amount -= remove;
            inv.setItem(i, item);
        } else {
            inv.setItem(i, null);
        }
        removed += remove;
        if (removed >= count) break;
    }
    return removed;
}

// データを保存する関数
export function saveShopMenu(shopMenu) {
    world.setDynamicProperty('shop_menu', JSON.stringify(shopMenu));
}
//logデータ
export var logs = {};
logs['harupay'] = [];
logs['quick'] = [];
logs['quest'] = [];

export function HARUPhone1(player) {
    system.run(() => {
        //実行アイテム=additem:haruphone1
        if (player.hasTag('op') && world.getDynamicProperty('op_fast') === undefined) {
            var form = new ModalFormData();
            form.title(`${config['main'][0]}`);
            form.textField('§e§o初期配布金額\n§5>>>§c後から変更可能ですが、経済バランスに影響する可能性があります。\n\n§r-§a目安§r-\n§r・§bPlayer間の取引を中心に経済を回したい\n§5>>>§a100000 §r~§a 1000000\n§r・§b換金システムを中心に経済を回したい\n§5>>>§a0 §r~§a 100000\n§r・§b迷って決めれない方へ\n§5>>>§a5000 §r~§a 10000', '半角数字');
            form.show(player).then(r => {
                if (r.canceled) {
                    return;
                }
                if (isNaN(r.formValues[0])) {
                    player.sendMessage(`§r[§bシステム§r] §4半角数字で入力してください`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    return;
                }
                if (r.formValues[0] > 100000000) {
                    player.sendMessage(`§r[§bシステム§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    return;
                }
                if (r.formValues[0] < 0) {
                    player.sendMessage(`§r[§bシステム§r] §40以下は設定できません`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    return;
                }
                if (r.formValues[0] == '') {
                    player.sendMessage(`§r[§bシステム§r] §e初期設定を完了して下さい`);
                    player.playSound('random.toast', {
                        pitch: 0.4,
                        volume: 1.0,
                    });
                    return;
                }
                //初期設定実行
                world.setDynamicProperty('start_money', r.formValues[0]);
                world.setDynamicProperty('op_fast', 1);
                world.setDynamicProperty('money_start_system1', 1);
                player.sendMessage(`§r[§bシステム§r] §a初期設定が完了しました`);
                player.playSound('random.toast', {
                    pitch: 1.7,
                    volume: 1.0,
                });
                HARUPhone1(player);
            });
        } else {
            //未設定時の実行ストップ
            if (world.getDynamicProperty('money_start_system1') !== 1) {
                player.sendMessage(`§r[§bHARUPhone1§r] §c初期設定が完了していません`);
                player.sendMessage(`§5>>> §a詳細は配布ページをご確認ください`);
                player.playSound('random.toast', {
                    pitch: 0.4,
                    volume: 1.0,
                });
                return;
            }
            //money取得
            const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

            //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, '0');
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
            var time = `${hours}:${minutes}`;

            //広告取得 (修正必須)
            var performance = world.getDynamicProperty('performance');
            if (performance == undefined) {
                var performance_system2 = [];
            } else {
                var performance_system2 = JSON.parse(performance);
            }
            const random_performance = Math.floor(Math.random() * performance_system2.length);

            //playerの一時ファイルを作成(リセット)
            player_Cash_Data[player.id] = {};
            const HARUPhone1_Cash_AppNumber = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'));
            //HOME画面
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body(`§l§b${time}`);
            for (let i = 0; i < HARUPhone1_Cash_AppNumber.length; i++) {
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '広告') {
                    if (performance_system2[0] == undefined) {
                        form.button(`§l${config['AppName'][0]}\n§r§0-`, 'textures/ui/browser');
                    } else {
                        form.button(`§l${config['AppName'][0]}§r\n${performance_system2[random_performance][2]}`, 'textures/ui/browser');
                    }
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '外部アプリケーション') {
                    form.button(`§1>>>§0${config['AppName'][15]}§4<<<\n`, 'textures/ui/haruapp');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'HARUPAY') {
                    form.button(`§9${config['AppName'][1]}\n§0残高:§s${score}`, 'textures/ui/pay');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Quick') {
                    form.button(`§1${config['AppName'][2]}`, 'textures/ui/quick');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'メール') {
                    form.button(`§3${config['AppName'][3]}`, 'textures/ui/mail');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'オープンチャット') {
                    form.button(`§5${config['AppName'][4]}`, 'textures/ui/openchat');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '仕事依頼・探す') {
                    form.button(`§2${config['AppName'][5]}`, 'textures/ui/work');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Advance') {
                    form.button(`§3${config['AppName'][6]}`, 'textures/ui/haruapp');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '換金') {
                    form.button(`§5${config['AppName'][7]}`, 'textures/ui/redeem');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '購入') {
                    form.button(`§9${config['AppName'][8]}`, 'textures/ui/purchase');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '情報') {
                    form.button(`§4${config['AppName'][9]}`, 'textures/ui/haruaddons');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'ブラウザ') {
                    form.button(`§2${config['AppName'][10]}`, 'textures/ui/browser');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '社会システム') {
                    form.button(`§9${config['AppName'][11]}`, 'textures/ui/country');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '請求') {
                    form.button(`§s${config['AppName'][12]}`, 'textures/ui/claim');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'HARUAssistant') {
                    form.button(`§1${config['AppName'][14]}`, 'textures/ui/haruapp');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Map') {
                    form.button(`§5${config['AppName'][17]}`, 'textures/ui/map');
                }
                if ((config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Operator Controller') & player.hasTag('HARUPhoneOP')) {
                    form.button(`§5${config['AppName'][13]}`, 'textures/ui/operatorcontroller');
                }
            }
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = config['AppData'][HARUPhone1_Cash_AppNumber[r.selection]];
                switch (response) {
                    case '広告':
                        if (performance_system2[0] == undefined) {
                            player.sendMessage(`§r[§bbrowser§r] §a広告データが見つかりません`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l${performance_system2[random_performance][3]}\n§e------------\n§r投稿者:§a${performance_system2[random_performance][0]}\n§e§l------------\n§r${performance_system2[random_performance][4]}\n\n${performance_system2[random_performance][5]}\n\n${performance_system2[random_performance][6]}\n\n${performance_system2[random_performance][7]}`);
                        form.button(`閉じる`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                        });
                        break;
                    case '外部アプリケーション':
                        App(player);
                        break;
                    case 'HARUPAY':
                        //money取得
                        var score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                        //HARUPAY画面
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${score}`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§9送る');
                        form.button('§5チャージ');
                        if ((!player.hasTag('HARUPhoneOP') && world.getDynamicProperty('MoneyList_allow') == true) || player.hasTag('HARUPhoneOP')) {
                            form.button('§4残高リスト');
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    //全プレイヤー取得
                                    player_Cash_Data[player.id].players = world.getAllPlayers();
                                    //HARIPAY送信画面
                                    form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§b§l${time}\n\n§r§5 >>>§r送り先のプレイヤーを選択`);
                                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                        form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                            return;
                                        }

                                        if (r.selection == 0) {
                                            //戻る
                                            HARUPhone1(player);
                                            return;
                                        }
                                        //送信先プレイヤーの設定
                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection - 1];

                                        if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
                                            player.sendMessage(`§r[§bHARUPAY§r] §c自分は選択できません`);
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }

                                        //送金額設定画面
                                        form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField(`§b§l${time}\n\n§r§b送金額§r(半角数字)`, '0');
                                        form.show(player).then(r => {
                                            if (r.canceled) {
                                                return;
                                            }
                                            if (isNaN(r.formValues[0])) {
                                                player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (r.formValues[0] > 100000000) {
                                                player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (r.formValues[0] < 0) {
                                                player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            //送金額を保存
                                            if (r.formValues[0] == '') {
                                                player_Cash_Data[player.id].select_money = 0;
                                            } else {
                                                player_Cash_Data[player.id].select_money = Number(r.formValues[0]);
                                            }
                                            //playerの残高の取得
                                            player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(
                                                `§b§l${time}§r\n\n§a送信先プレイヤー§r:§b${player_Cash_Data[player.id].select_player.name} \n§e送金額§r:§b${player_Cash_Data[player.id].select_money}\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${
                                                    player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_money
                                                }\n§1///////////////////`
                                            );
                                            form.button(`§s送金`);
                                            form.button(`キャンセル`);
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                switch (r.selection) {
                                                    case 0:
                                                        //playerの残高の取得
                                                        player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                        if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_money) {
                                                            //マネー操作
                                                            player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_money}`);
                                                            player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`);

                                                            //メッセージ
                                                            player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§rへ§b${player_Cash_Data[player.id].select_money}§rPAY送信されました`);
                                                            player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a${player.name}§rから§b${player_Cash_Data[player.id].select_money}§rPAY受け取りました`);

                                                            //通知音
                                                            player.playSound('random.toast', {
                                                                pitch: 1.7,
                                                                volume: 1.0,
                                                            });
                                                            player_Cash_Data[player.id].select_player.playSound('random.toast', {
                                                                pitch: 1.7,
                                                                volume: 1.0,
                                                            });

                                                            //ログ関連
                                                            logs['harupay'].push([time, player.name, player_Cash_Data[player.id].select_player.name, player_Cash_Data[player.id].select_money]);
                                                        } else {
                                                            player.sendMessage(`§r[§bHARUPAY§r] §4Moneyが不足しています`);
                                                            player.playSound('random.toast', {
                                                                pitch: 0.4,
                                                                volume: 1.0,
                                                            });
                                                        }
                                                        break;
                                                }
                                            });
                                        });
                                    });
                                    break;
                                case 2:
                                    const MoneyItems_score = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
                                    const coinTypes = [
                                        { id: 'additem:coina', value: MoneyItems_score[0] },
                                        { id: 'additem:coinb', value: MoneyItems_score[1] },
                                        { id: 'additem:coinc', value: MoneyItems_score[2] },
                                        { id: 'additem:coind', value: MoneyItems_score[3] },
                                        { id: 'additem:coine', value: MoneyItems_score[4] },
                                        { id: 'additem:billa', value: MoneyItems_score[5] },
                                        { id: 'additem:billb', value: MoneyItems_score[6] },
                                        { id: 'additem:billc', value: MoneyItems_score[7] },
                                    ];
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField(`§5>>>§cチャージ金額(半角数字)`, '0');
                                    form.show(player).then(async r => {
                                        if (r.canceled) return;

                                        const input = r.formValues[0];
                                        const chargeAmount = parseInt(input);

                                        if (isNaN(chargeAmount) || !Number.isInteger(Number(input))) {
                                            player.sendMessage('§r[§bHARUPAY§r] §4半角整数で入力してください');
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }
                                        if (chargeAmount <= 0) {
                                            player.sendMessage('§r[§bHARUPAY§r] §41以上の値を設定してください');
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }

                                        const inventory = player.getComponent('minecraft:inventory').container;
                                        const coinCount = {};
                                        let totalAvailable = 0;

                                        // インベントリ内のコイン数をカウント
                                        for (let { id, value } of coinTypes) {
                                            let count = 0;
                                            for (let i = 0; i < inventory.size; i++) {
                                                const item = inventory.getItem(i);
                                                if (item?.typeId === id) count += item.amount;
                                            }
                                            coinCount[id] = count;
                                            totalAvailable += count * value;
                                        }

                                        // コイン不足のチェック
                                        if (totalAvailable < chargeAmount) {
                                            player.sendMessage('§r[§bHARUPAY§r] §4Moneyが不足しています');
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }

                                        // 必要なコインの枚数を事前計算
                                        let remaining = chargeAmount;
                                        const requiredCoins = {};

                                        for (let { id, value } of coinTypes.reverse()) {
                                            // 大きいコインから優先的に使う
                                            if (remaining <= 0) break;
                                            const needed = Math.min(Math.floor(remaining / value), coinCount[id]);
                                            if (needed > 0) {
                                                requiredCoins[id] = needed;
                                                remaining -= needed * value;
                                            }
                                        }

                                        if (remaining > 0) {
                                            player.sendMessage('§r[§bHARUPAY§r] §4必要なMoneyの組み合わせが不足しています');
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }

                                        try {
                                            // アイテムを削除
                                            for (const [id, needed] of Object.entries(requiredCoins)) {
                                                const removed = removeItemsFromInventory(player, id, needed);
                                                if (removed < needed) {
                                                    // 万が一削除に失敗した場合はエラーとして処理
                                                    throw new Error('アイテムの削除に失敗しました');
                                                }
                                            }

                                            // スコアボード更新
                                            await player.runCommandAsync(`scoreboard players add @s money ${chargeAmount}`);
                                            player.sendMessage(`§r[§bHARUPAY§r] §b${chargeAmount}§ePAYチャージしました`);
                                            player.playSound('random.toast', {
                                                pitch: 1.7,
                                                volume: 1.0,
                                            });
                                        } catch (error) {
                                            player.sendMessage(`§r[§bHARUPAY§r] §cチャージ処理中にエラーが発生しました: ${error.message}`);
                                        }
                                    });
                                    break;
                                case 3:
                                    const TITLE = config['main'][0] ?? 'ランキング';

                                    // ランキング表示（スコアボードID・プレイヤー）
                                    function showRanking(objectiveId, player) {
                                        const obj = world.scoreboard.getObjective(objectiveId);
                                        if (!obj) {
                                            player.sendMessage(`§cスコアボード '${objectiveId}' が見つかりません。`);
                                            return;
                                        }

                                        const onlineNames = [...world.getPlayers()].map(p => p.name);

                                        const scores = obj
                                            .getScores()
                                            .filter(e => e.participant?.displayName)
                                            .map(e => {
                                                const name = e.participant.displayName;
                                                const isOnline = onlineNames.includes(name);
                                                return {
                                                    name: isOnline ? name : '§7(オフライン)',
                                                    score: e.score,
                                                };
                                            })
                                            .sort((a, b) => b.score - a.score);

                                        const text = scores.length === 0 ? '§7（データなし）' : scores.map((e, i) => `§f${i + 1}. ${e.name}：§a${e.score}`).join('\n');

                                        new ActionFormData()
                                            .title(`${TITLE}`)
                                            .body(text)
                                            .button('§l戻る', 'textures/ui/icon_import.png')
                                            .show(player)
                                            .then(res => {
                                                if (!res.canceled && res.selection === 0) {
                                                    HARUPhone1(player);
                                                }
                                            });
                                    }

                                    // メインの選択フォーム（money / account）
                                    function showRankingSelector(player) {
                                        new ActionFormData()
                                            .title(`${TITLE}`)
                                            .body('表示したいスコアボードを選んでください')
                                            .button('§l戻る', 'textures/ui/icon_import.png')
                                            .button('§1HARUPAY')
                                            .button('§4口座')
                                            .show(player)
                                            .then(res => {
                                                if (res.canceled) return;

                                                switch (res.selection) {
                                                    case 0:
                                                        HARUPhone1(player);
                                                        break;
                                                    case 1:
                                                        showRanking('money', player);
                                                        break;
                                                    case 2:
                                                        showRanking('account', player);
                                                        break;
                                                }
                                            });
                                    }
                                    showRankingSelector(player);
                                    break;
                                default:
                            }
                        });
                        break;
                    case 'Quick':
                        // shop_menu をグローバル変数として初期化
                        var shop_menu = loadShopMenu();

                        // 永続化処理を追加
                        player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${player_Cash_Data[player.id].money}`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button(`§1購入`);
                        form.button(`§5出品`);
                        form.button(`§r商品の§4削除`);
                        form.show(player)
                            .then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0:
                                        // 戻る
                                        HARUPhone1(player);
                                        break;
                                    case 1:
                                        if (shop_menu[0].length == 0) {
                                            player.sendMessage(`§r[§bQuick§r] §a商品が見つかりませんでした`);
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body('商品一覧');
                                        for (let i = 0; i < shop_menu[0].length; i++) {
                                            form.button(`§0${shop_menu[0][i][0]}\n§r金額:§s${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
                                        }
                                        form.show(player)
                                            .then(r => {
                                                if (r.canceled) {
                                                    return;
                                                }
                                                // 選択した商品を保存
                                                player_Cash_Data[player.id].select_shop = shop_menu[0][r.selection];
                                                // money取得
                                                player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body(
                                                    `商品名:§a${player_Cash_Data[player.id].select_shop[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_shop[3]}\n§r金額:§b${player_Cash_Data[player.id].select_shop[2]}  §r出品者:§2${player_Cash_Data[player.id].select_shop[1]}\n\n§e購入後自動的に料金が支払われます\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${
                                                        player_Cash_Data[player.id].money
                                                    }§r-§2${player_Cash_Data[player.id].select_shop[2]}\n§r=§b${player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_shop[2]}\n§1///////////////////`
                                                );
                                                form.button('§5この商品を買う');
                                                form.button('§1キャンセル');
                                                form.show(player)
                                                    .then(r => {
                                                        if (r.canceled) {
                                                            return;
                                                        }
                                                        switch (r.selection) {
                                                            case 0:
                                                                player_Cash_Data[player.id].shop_stop = false;
                                                                // オンラインプレイヤー取得
                                                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                                    if (player_Cash_Data[player.id].select_shop[4] == player_Cash_Data[player.id].players[i].id) {
                                                                        player_Cash_Data[player.id].shop_stop = true;
                                                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                                                    }
                                                                }
                                                                if (player_Cash_Data[player.id].shop_stop == false) {
                                                                    player.sendMessage(`§r[§bQuick§r] §4現在販売者がオフラインの為販売を中止します`);
                                                                    player.playSound('random.toast', {
                                                                        pitch: 0.4,
                                                                        volume: 1.0,
                                                                    });
                                                                    return;
                                                                }

                                                                if (shop_menu[1][0] != undefined) {
                                                                    for (let i = 0; i < shop_menu[1].length; i++) {
                                                                        if (player_Cash_Data[player.id].select_shop[5] == shop_menu[1][i]) {
                                                                            player_Cash_Data[player.id].shop_stop = false;
                                                                        }
                                                                    }
                                                                }

                                                                if (player_Cash_Data[player.id].shop_stop == false) {
                                                                    player.sendMessage(`§r[§bQuick§r] §4選択した商品は既に販売終了しております`);
                                                                    player.playSound('random.toast', {
                                                                        pitch: 0.4,
                                                                        volume: 1.0,
                                                                    });
                                                                    return;
                                                                }
                                                                // 残高が設定金額以上の場合のみ実行
                                                                if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_shop[2]) {
                                                                    // マネー操作
                                                                    player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_shop[2]}`);
                                                                    player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_shop[2]}`);

                                                                    // メッセージ関連
                                                                    player.sendMessage(`§r[§bQuick§r] §b${player_Cash_Data[player.id].select_shop[1]}へ${player_Cash_Data[player.id].select_shop[2]}PAY支払いました`);
                                                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §b${player.name}§rが§b${player_Cash_Data[player.id].select_shop[0]}§rを§e注文しました`);
                                                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §e${player.name}から${player_Cash_Data[player.id].select_shop[2]}PAY受け取りました`);

                                                                    // 通知音
                                                                    player.playSound('random.toast', {
                                                                        pitch: 1.7,
                                                                        volume: 1.0,
                                                                    });
                                                                    player_Cash_Data[player.id].select_player.playSound('random.toast', {
                                                                        pitch: 1.7,
                                                                        volume: 1.0,
                                                                    });

                                                                    // log関連
                                                                    logs['quick'].push([time, player.name, player_Cash_Data[player.id].select_shop[1], player_Cash_Data[player.id].select_shop[2]]);

                                                                    // 商品の削除/販売済み商品に追加
                                                                    shop_menu[1].push(player_Cash_Data[player.id].select_shop[5]);
                                                                    for (let i = 0; i < shop_menu[0].length; i++) {
                                                                        if (shop_menu[0][i][5] === player_Cash_Data[player.id].select_shop[5]) {
                                                                            shop_menu[0].splice(i, 1);
                                                                        }
                                                                    }
                                                                    saveShopMenu(shop_menu); // 更新後に保存
                                                                } else {
                                                                    player.sendMessage(`§r[§bQuick§r] §cHARUPAY残高が不足しています`);
                                                                    player.playSound('random.toast', {
                                                                        pitch: 0.4,
                                                                        volume: 1.0,
                                                                    });
                                                                }
                                                                break;
                                                        }
                                                    })
                                                    .catch(e => {
                                                        console.error(e, e.stack);
                                                    });
                                            })
                                            .catch(e => {
                                                console.error(e, e.stack);
                                            });
                                        break;
                                    case 2:
                                        var form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField('商品名', '丸石');
                                        form.textField('詳細', 'エンチャント内容など');
                                        form.textField('販売額(半角数字)', '0');
                                        form.show(player)
                                            .then(r => {
                                                if (r.canceled) return;
                                                if (isNaN(r.formValues[2])) {
                                                    player.sendMessage(`§r[§bQuick§r] §4半角数字で入力してください`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                if (r.formValues[2] > 100000000) {
                                                    player.sendMessage(`§r[§bQuick§r] §41億以下で設定してください`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                if (r.formValues[2] < 0) {
                                                    player.sendMessage(`§r[§bQuick§r] §40以下は設定できません`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                if (r.formValues[0] == '') {
                                                    player.sendMessage(`§r[§bQuick§r] §4商品名が未入力です`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }

                                                if (r.formValues[2] == '') {
                                                    var selection_score_quick = 0;
                                                } else {
                                                    var selection_score_quick = Number(r.formValues[2]);
                                                }

                                                // Code生成
                                                let number = '';
                                                for (let i = 0; i < 8; i++) {
                                                    number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                                                }
                                                shop_menu[0].push([r.formValues[0], player.name, selection_score_quick, r.formValues[1], player.id, number]);

                                                // オンラインプレイヤー取得
                                                player_Cash_Data[player.id].players = world.getAllPlayers();

                                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                    player_Cash_Data[player.id].players[i].sendMessage(`§r[§bQuick§r] §a${r.formValues[0]}§r:§b${selection_score_quick}§rPAYの販売が開始されました`);
                                                    // 通知サウンド
                                                    player_Cash_Data[player.id].players[i].playSound('random.toast', {
                                                        pitch: 1.7,
                                                        volume: 1.0,
                                                    });
                                                }
                                                saveShopMenu(shop_menu); // 出品後に保存
                                            })
                                            .catch(e => {
                                                console.error(e, e.stack);
                                            });
                                        break;
                                    case 3:
                                        if (shop_menu[0].length == 0) {
                                            player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }
                                        player_Cash_Data[player.id].my_shop = [];
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body('削除する商品を選択');
                                        for (let i = 0; i < shop_menu[0].length; i++) {
                                            if (player.id == shop_menu[0][i][4]) {
                                                form.button(`§l${shop_menu[0][i][0]}\n§r額:§b${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
                                                player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
                                            }
                                        }
                                        if (player_Cash_Data[player.id].my_shop.length == 0) {
                                            // lengthが-1にならないよう修正
                                            player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }
                                        form.show(player)
                                            .then(r => {
                                                if (r.canceled) {
                                                    return;
                                                }
                                                for (let i = 0; i < shop_menu[0].length; i++) {
                                                    if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection][5]) {
                                                        shop_menu[0].splice(i, 1);
                                                    }
                                                }
                                                player.sendMessage(`§r[§bQuick§r] §a削除しました`);
                                                player.playSound('random.toast', {
                                                    pitch: 1.7,
                                                    volume: 1.0,
                                                });
                                                saveShopMenu(shop_menu); // 削除後に保存
                                                return;
                                            })
                                            .catch(e => {
                                                console.error(e, e.stack);
                                            });
                                        break;
                                }
                            })
                            .catch(e => {
                                console.error(e, e.stack);
                            });
                        break;
                    case 'メール':
                        //メール

                        //オンラインプレイヤー取得
                        player_Cash_Data[player.id].players = world.getAllPlayers();

                        //送信先プレイヤー選択画面
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l§b${time}§r\n\n§6 >>>§s送信先プレイヤーを選択`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                            form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                        }
                        form.show(player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            //戻る
                            if (r.selection == 0) {
                                //戻る
                                HARUPhone1(player);
                                return;
                            }

                            //↓プレイヤー選択
                            if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
                                player.sendMessage(`§r[§bメール§r] §c自分は選択できません`);
                                player.playSound('random.toast', {
                                    pitch: 0.4,
                                    volume: 1.0,
                                });
                                return;
                            }
                            //選択したプレイヤーを保存
                            player_Cash_Data[player.id].player_select = player_Cash_Data[player.id].players[r.selection - 1];
                            //メッセージ入力画面
                            var form = new ModalFormData();
                            form.title(`${config['main'][0]}`);
                            form.textField(`§l§b${time}§r\n\n§6>>>§r送信先:§a${player_Cash_Data[player.id].player_select.name}`, 'メッセージ入力');
                            form.toggle(`§b座標共有 §r(false/true)`, false);
                            form.show(player).then(r => {
                                if (r.canceled) {
                                    return;
                                }
                                if (r.formValues[0] == '' && r.formValues[1] == false) {
                                    player.sendMessage(`§r[§bメール§r] §4メッセージ未入力です`);
                                    player.playSound('random.toast', {
                                        pitch: 0.4,
                                        volume: 1.0,
                                    });
                                    return;
                                }
                                //現在地を取得
                                player_Cash_Data[player.id].player_location = player.location;
                                //メッセージ送信
                                if (r.formValues[0] !== '') {
                                    player.sendMessage(`§r[§bメール§r] §a${player_Cash_Data[player.id].player_select.name}§rへ送信§6>>>§r${r.formValues[0]}`);
                                    player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §a${player.name}§rから受信§6>>>§r${r.formValues[0]}`);
                                }
                                if (r.formValues[1] == true) {
                                    player.sendMessage(`§r[§bメール§r] §c座標送信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                                    player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §c座標受信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                                }
                                //通知サウンド
                                player.playSound('random.toast', {
                                    pitch: 1.7,
                                    volume: 1.0,
                                });
                                player_Cash_Data[player.id].player_select.playSound('random.toast', {
                                    pitch: 1.7,
                                    volume: 1.0,
                                });
                            });
                        });
                        break;
                    case 'オープンチャット':
                        //オープンチャット送信画面
                        var form = new ModalFormData();
                        form.title(`${config['main'][0]}`);
                        form.textField(`§l§b${time}§r\n\nチャット`, 'メッセージ');
                        form.toggle(`§a座標共有 §r(false/true)`, false);
                        form.show(player)
                            .then(r => {
                                if (r.canceled) return;

                                if (r.formValues[0] == '' && r.formValues[1] == false) {
                                    player.sendMessage(`§r[§bオープンチャット§r] §4メッセージ未入力です`);
                                    player.playSound('random.toast', {
                                        pitch: 0.4,
                                        volume: 1.0,
                                    });
                                    return;
                                }
                                //オンラインプレイヤー取得
                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                //現在地を取得
                                player_Cash_Data[player.id].player_location = player.location;

                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                    if (r.formValues[0] !== '') {
                                        player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §a${player.name}§b:§r${r.formValues[0]}`);
                                    }
                                    if (r.formValues[1] == true) {
                                        player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §c座標§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                                    }

                                    //通知サウンド
                                    player_Cash_Data[player.id].players[i].playSound('random.toast', {
                                        pitch: 1.7,
                                        volume: 1.0,
                                    });
                                }
                            })
                            .catch(e => {
                                console.error(e, e.stack);
                            });
                        break;
                    case '仕事依頼・探す':
                        //仕事依頼設定画面
                        form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l§b${time}§r\n\n§5 >>>§rサービスを選択`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§1募集');
                        form.button('§5探す');
                        form.button('募集の§4削除');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField('仕事ジャンル', '例:整地');
                                    form.textField('仕事内容', '例:約半径30ブロックの整地');
                                    form.textField('報酬額(半角数字)', '0');
                                    form.show(player)
                                        .then(r => {
                                            if (r.canceled) return;
                                            if (r.formValues[2] > 100000000) {
                                                player.sendMessage(`§r[§b仕事依頼§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (r.formValues[0] == '' || r.formValues[2] == '') {
                                                player.sendMessage(`§r[§b仕事依頼§r] §4設定されていない項目があるため開始できませんでした`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (r.formValues[2] < 0) {
                                                player.sendMessage(`§r[§b仕事依頼§r] §40以下は設定できません`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            player_Cash_Data[player.id].players = world.getAllPlayers();
                                            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§b仕事依頼§r] §b${player.name}§aが§b${r.formValues[1]}§aの募集しました`);
                                                player_Cash_Data[player.id].players[i].sendMessage(`§5>>>§a報酬額§r:§b${r.formValues[2]}`);
                                                player_Cash_Data[player.id].players[i].playSound('random.toast', {
                                                    pitch: 1.7,
                                                    volume: 1.0,
                                                });
                                            }
                                            //Code生成
                                            let number = '';
                                            for (let i = 0; i < 8; i++) {
                                                number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                                            }
                                            quest[0].push([r.formValues[0], player.name, r.formValues[2], r.formValues[1], player.id, number]);
                                        })
                                        .catch(e => {
                                            console.error(e, e.stack);
                                        });
                                    break;
                                case 2:
                                    if (quest[0].length == 0) {
                                        player.sendMessage(`§r[§b仕事依頼§r] §a募集が見つかりませんでした`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                        return;
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('仕事一覧');
                                    for (let i = 0; i < quest[0].length; i++) {
                                        form.button(`§0${quest[0][i][0]}\n§r報酬額:§s${quest[0][i][2]}§rPAY  依頼者:§2${quest[0][i][1]}`);
                                    }
                                    form.show(player)
                                        .then(r => {
                                            if (r.canceled) {
                                                return;
                                            }
                                            //選択した商品を保存
                                            player_Cash_Data[player.id].select_quest = quest[0][r.selection];

                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(`仕事:§a${player_Cash_Data[player.id].select_quest[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_quest[3]}\n§r金額:§b${player_Cash_Data[player.id].select_quest[2]}  §r依頼者:§2${player_Cash_Data[player.id].select_quest[1]}`);
                                            form.button('§5仕事を受ける');
                                            form.button('§1キャンセル');
                                            form.show(player).then(r => {
                                                if (r.canceled) {
                                                    return;
                                                }
                                                switch (r.selection) {
                                                    case 0:
                                                        player_Cash_Data[player.id].quest_stop = false;
                                                        //オンラインプレイヤー取得
                                                        player_Cash_Data[player.id].players = world.getAllPlayers();
                                                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                            if (player_Cash_Data[player.id].select_quest[4] == player_Cash_Data[player.id].players[i].id) {
                                                                player_Cash_Data[player.id].quest_stop = true;
                                                                player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                                            }
                                                        }
                                                        if (player_Cash_Data[player.id].quest_stop == false) {
                                                            player.sendMessage(`§r[§b仕事依頼§r] §4現在募集者がオフラインの為処理を中止します`);
                                                            player.playSound('random.toast', {
                                                                pitch: 0.4,
                                                                volume: 1.0,
                                                            });
                                                            return;
                                                        }

                                                        if (quest[1][0] != undefined) {
                                                            for (let i = 0; i < quest[1].length; i++) {
                                                                if (player_Cash_Data[player.id].select_quest[5] == quest[1][i]) {
                                                                    player_Cash_Data[player.id].quest_stop = false;
                                                                }
                                                            }
                                                        }

                                                        if (player_Cash_Data[player.id].quest_stop == false) {
                                                            player.sendMessage(`§r[§b仕事依頼§r] §4選択した募集は既に終了しております`);
                                                            player.playSound('random.toast', {
                                                                pitch: 0.4,
                                                                volume: 1.0,
                                                            });
                                                            return;
                                                        }
                                                        //メッセージ関連
                                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§b仕事依頼§r] §e${player.name}§bが${player_Cash_Data[player.id].select_quest[0]}の仕事募集を受けました`);
                                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§b仕事依頼§r] §b${player_Cash_Data[player.id].select_quest[0]}§aの仕事を受けました §c募集者§r:§e${player_Cash_Data[player.id].select_quest[1]}`);

                                                        //通知音
                                                        player.playSound('random.toast', {
                                                            pitch: 1.7,
                                                            volume: 1.0,
                                                        });
                                                        player_Cash_Data[player.id].select_player.playSound('random.toast', {
                                                            pitch: 1.7,
                                                            volume: 1.0,
                                                        });

                                                        //log関連
                                                        logs['quest'].push([time, player.name, player_Cash_Data[player.id].select_quest[1], player_Cash_Data[player.id].select_quest[0]]);

                                                        quest[1].push(player_Cash_Data[player.id].select_quest[5]);
                                                        for (let i = 0; i < quest[0].length; i++) {
                                                            if (quest[0][i][5] === player_Cash_Data[player.id].select_quest[5]) {
                                                                quest[0].splice(i, 1);
                                                            }
                                                        }
                                                        break;
                                                }
                                            });
                                        })
                                        .catch(e => {
                                            console.error(e, e.stack);
                                        });
                                    break;
                                case 3:
                                    if (quest[0].length == 0) {
                                        player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                        return;
                                    }
                                    player_Cash_Data[player.id].my_quest = [];
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('削除する商品を選択');
                                    for (let i = 0; i < quest[0].length; i++) {
                                        if (player.id == quest[0][i][4]) {
                                            form.button(`§l${quest[0][i][0]}\n§r額:§b${quest[0][i][2]}§rPAY  依頼者:§2${quest[0][i][1]}`);
                                            player_Cash_Data[player.id].my_quest.push(quest[0][i]);
                                        }
                                    }
                                    if (player_Cash_Data[player.id].my_quest.length == -1) {
                                        player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                        return;
                                    }
                                    form.show(player)
                                        .then(r => {
                                            if (r.canceled) {
                                                return;
                                            }
                                            for (let i = 0; i < quest[0].length; i++) {
                                                if (quest[0][i][5] === player_Cash_Data[player.id].my_quest[r.selection][5]) {
                                                    quest[0].splice(i, 1);
                                                }
                                            }
                                            player.sendMessage(`§r[§b仕事依頼§r] §a削除しました`);
                                            player.playSound('random.toast', {
                                                pitch: 1.7,
                                                volume: 1.0,
                                            });
                                            return;
                                        })
                                        .catch(e => {
                                            console.error(e, e.stack);
                                        });
                                    break;
                                default:
                            }
                        });
                        break;
                    case 'Advance':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l§b${time}§r\n\n §5>>>§a商品を見つける`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button(`§9キーワード検索`);
                        form.button(`§2会社指定`);
                        form.button(`§1注文した商品の配送状況`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    var advance_shop = world.getDynamicProperty('advance_shop');
                                    if (advance_shop == undefined) {
                                        var advance_shop_system2 = [];
                                    } else {
                                        var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[], []];
                                    var advance_shop_cash1 = 0;
                                    var advance_shop_cash2 = [];
                                    var advance_shop_cash3 = [];
                                    if (advance_shop == undefined || advance_shop_system2[0] == undefined) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`);
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                        return;
                                    }
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField('検索商品', 'ダイアモンド');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if (r.formValues[0] == '') {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4検索キーワードを入力してください"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                            return;
                                        }
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body('検索商品リスト');
                                        for (let i = 0; i < advance_shop_system2.length; i++) {
                                            advance_shop_cash[0].push(i);
                                            for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                                                if (advance_shop_system2[i][1][i1][0].indexOf(r.formValues[0]) != -1) {
                                                    form.button(`§l${advance_shop_system2[i][1][i1][0]}\n§r金額:§9${advance_shop_system2[i][1][i1][1]} §r在庫:§2${advance_shop_system2[i][1][i1][2]}`);
                                                    advance_shop_cash1 = 1;
                                                    advance_shop_cash2.push(i);
                                                    advance_shop_cash3.push(i1);
                                                }
                                            }
                                        }
                                        if (advance_shop_cash1 == 0) {
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`);
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                            return;
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            advance_shop_cash[1].push(advance_shop_cash2[response]);
                                            advance_shop_cash[1].push(response);
                                            advance_shop_cash[1].push(advance_shop_cash3[response]);
                                            var form = new ModalFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.textField('個数 (半角数字)', '0');
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                advance_shop_cash[1].push(Number(r.formValues[0]));
                                                if (r.formValues[0] <= 0) {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                if (r.formValues[0] == '') {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4個数を入力してください"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                if (Number(r.formValues[0]) > advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2]) {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4在庫数をオーバーしています"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body(
                                                    `§l注文内容\n\n§r商品名:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][0]}\n§r個数:§a${advance_shop_cash[1][3]}§r合計金額:§b${advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}\n\n§r販売元:§a${
                                                        advance_shop_system2[advance_shop_cash[1][0]][0]
                                                    }`
                                                );
                                                form.button(`注文`);
                                                form.button(`閉じる`);
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:
                                                            const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                            if (score >= advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]) {
                                                                var advance_partner = '';
                                                                var advance_member = world.getDynamicProperty('advance_member');
                                                                if (advance_member == undefined) {
                                                                    var advance_member_system2 = [];
                                                                } else {
                                                                    var advance_member_system2 = JSON.parse(advance_member);
                                                                }
                                                                for (let i = 0; i < advance_member_system2.length; i++) {
                                                                    if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                                        advance_partner = `${advance_member_system2[i][0]}`;
                                                                    }
                                                                }
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][2] - advance_shop_cash[1][2];
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][3].push([player.name, advance_shop_cash[1][3], 0]);
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][4] + 1;
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a注文しました"}]}`);
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                                                player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §b${player.name}§aが§b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]§aを注文しました"}]}`);
                                                                player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`);
                                                                var advance_member = world.getDynamicProperty('advance_member');
                                                                var advance_member_system2 = JSON.parse(advance_member);
                                                                for (let i = 0; i < advance_member_system2.length; i++) {
                                                                    if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                                        advance_member_system2[i][3] = advance_member_system2[i][3] + advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1];
                                                                    }
                                                                }
                                                                const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                                                world.setDynamicProperty('advance_shop', advance_shop_system3);
                                                                const advance_member_system3 = JSON.stringify(advance_member_system2);
                                                                world.setDynamicProperty('advance_member', advance_member_system3);
                                                                player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][3] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][2]][1]}`);
                                                            } else {
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4所持金が不足しています"}]}`);
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                            }
                                                            break;
                                                    }
                                                });
                                            });
                                        });
                                    });
                                    break;
                                case 2:
                                    var advance_shop = world.getDynamicProperty('advance_shop');
                                    if (advance_shop == undefined) {
                                        var advance_shop_system2 = [];
                                    } else {
                                        var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = [[], []];
                                    if (advance_shop == undefined || advance_shop_system2[0] == undefined) {
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a商品が見つかりませんでした"}]}`);
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                        return;
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('会社を指定して商品を探します');
                                    for (let i = 0; i < advance_shop_system2.length; i++) {
                                        form.button(`${advance_shop_system2[i][0]}§r`);
                                        advance_shop_cash[0].push(i);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        advance_shop_cash[1].push(response);
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`${advance_shop_system2[advance_shop_cash[0][response]][0]}の商品一覧`);
                                        for (let i = 0; i < advance_shop_system2[advance_shop_cash[0][response]][1].length; i++) {
                                            form.button(`§l${advance_shop_system2[advance_shop_cash[0][response]][1][i][0]}\n§r金額:§9${advance_shop_system2[advance_shop_cash[0][response]][1][i][1]} §r在庫:§2${advance_shop_system2[advance_shop_cash[0][response]][1][i][2]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            advance_shop_cash[1].push(response);
                                            var form = new ModalFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.textField('個数 (半角数字)', '0');
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                                advance_shop_cash[1].push(r.formValues[0]);
                                                if (r.formValues[0] <= 0) {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                if (r.formValues[0] == '') {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4個数を入力してください"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                if (Number(r.formValues[0]) > advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2]) {
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4在庫数をオーバーしています"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                    return;
                                                }
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body(
                                                    `§l注文内容\n\n§r商品名:§a${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]}\n§r個数:§a${advance_shop_cash[1][2]}§r合計金額:§b${advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}\n\n§r販売元:§a${
                                                        advance_shop_system2[advance_shop_cash[1][0]][0]
                                                    }`
                                                );
                                                form.button(`注文`);
                                                form.button(`閉じる`);
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:
                                                            const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                            if (score >= advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]) {
                                                                var advance_partner = '';
                                                                var advance_member = world.getDynamicProperty('advance_member');
                                                                if (advance_member == undefined) {
                                                                    var advance_member_system2 = [];
                                                                } else {
                                                                    var advance_member_system2 = JSON.parse(advance_member);
                                                                }
                                                                for (let i = 0; i < advance_member_system2.length; i++) {
                                                                    if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[1][0]][0]) {
                                                                        advance_partner = `${advance_member_system2[i][0]}`;
                                                                    }
                                                                }
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][2] - advance_shop_cash[1][2];
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][3].push([player.name, advance_shop_cash[1][2], 0]);
                                                                advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4] = advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][4] + 1;
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a注文しました"}]}`);
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                                                player.runCommand(`tellraw @a[name="${advance_partner}"] {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §b${player.name}§aが§b${advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][0]} [${advance_shop_system2[advance_shop_cash[1][0]][0]}]§aを注文しました"}]}`);
                                                                player.runCommand(`playsound random.toast @a[name="${advance_partner}"] ~ ~ ~ 1.0 1.7 0.5`);
                                                                var advance_member = world.getDynamicProperty('advance_member');
                                                                var advance_member_system2 = JSON.parse(advance_member);
                                                                for (let i = 0; i < advance_member_system2.length; i++) {
                                                                    if (advance_member_system2[i][1] == advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][0]) {
                                                                        advance_member_system2[i][3] = advance_member_system2[i][3] + advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1];
                                                                    }
                                                                }
                                                                const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                                                world.setDynamicProperty('advance_shop', advance_shop_system3);
                                                                const advance_member_system3 = JSON.stringify(advance_member_system2);
                                                                world.setDynamicProperty('advance_member', advance_member_system3);
                                                                player.runCommand(`scoreboard players remove @s money ${advance_shop_cash[1][2] * advance_shop_system2[advance_shop_cash[0][advance_shop_cash[1][0]]][1][advance_shop_cash[1][1]][1]}`);
                                                            } else {
                                                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4所持金が不足しています"}]}`);
                                                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                                                            }
                                                            break;
                                                    }
                                                });
                                            });
                                        });
                                    });
                                    break;
                                case 3:
                                    var advance_shop_pattern = [];
                                    var advance_shop = world.getDynamicProperty('advance_shop');
                                    if (advance_shop == undefined) {
                                        var advance_shop_system2 = [];
                                    } else {
                                        var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    for (let i = 0; i < advance_shop_system2.length; i++) {
                                        for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++) {
                                            for (let i2 = 0; i2 < advance_shop_system2[i][1][i1][3].length; i2++) {
                                                if (advance_shop_system2[i][1][i1][3][i2][0] == player.name) {
                                                    advance_shop_pattern.push([advance_shop_system2[i][1][i1][0], advance_shop_system2[i][1][i1][3][i2]]);
                                                }
                                            }
                                        }
                                    }
                                    var advance_shop_pattern_text = '';
                                    for (let i = 0; i < advance_shop_pattern.length; i++) {
                                        if (advance_shop_pattern[i][1][2] == 0) {
                                            var advance_shop_pattern_text_cash = '§9現在配送中です';
                                        } else {
                                            var advance_shop_pattern_text_cash = '§9配送完了';
                                        }
                                        advance_shop_pattern_text = advance_shop_pattern_text + `商品名:§b${advance_shop_pattern[i][0]}§r 個数:§a${advance_shop_pattern[i][1][1]}\n${advance_shop_pattern_text_cash}§r\n`;
                                    }
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`${advance_shop_pattern_text}`);
                                    form.button(`閉じる`);
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                    });
                                    break;
                            }
                        });
                        break;
                    case '換金':
                        showExchangeItems(player);

                        function showExchangeItems(player) {
                            // 換金情報の取得
                            let kannkin_information = world.getDynamicProperty('kannkin_information');
                            let kannkin_information_system2 = kannkin_information ? JSON.parse(kannkin_information) : [];

                            // ジャンル情報の取得
                            let kannkin_genres = world.getDynamicProperty('kannkin_genres');
                            let genres = kannkin_genres ? JSON.parse(kannkin_genres) : ['一般'];

                            // 既存データにジャンルがない場合、デフォルトジャンルを付与
                            kannkin_information_system2 = kannkin_information_system2.map(item => {
                                if (!item[4]) item[4] = '一般';
                                return item;
                            });
                            world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));

                            // 表示するジャンルをフィルタリング（「一般」はアイテムがある場合のみ含む）
                            let displayGenres = genres.filter(genre => {
                                if (genre === '一般') {
                                    return kannkin_information_system2.some(item => item[4] === '一般');
                                }
                                return true;
                            });

                            // ジャンルがない場合の処理
                            if (!displayGenres.length) {
                                player.sendMessage(`§r[§b換金§r] §aジャンルが見つかりません`);
                                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                return;
                            }

                            // ジャンル選択フォームの作成
                            let form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body('§5>>>§aジャンルを選択');
                            form.button(`§l戻る`, 'textures/ui/icon_import.png');
                            displayGenres.forEach(genre => {
                                form.button(`§1${genre}`, 'textures/ui/normalicon1');
                            });

                            form.show(player)
                                .then(r => {
                                    if (r.canceled) return;
                                    if (r.selection === 0) {
                                        HARUPhone1(player);
                                        return;
                                    }

                                    let selectedGenre = displayGenres[r.selection - 1];

                                    // 選択したジャンルのアイテムを取得
                                    let genreItems = kannkin_information_system2.filter(item => item[4] === selectedGenre);

                                    if (!genreItems.length) {
                                        player.sendMessage(`§r[§b換金§r] §a${selectedGenre}にアイテムが見つかりません`);
                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                        return;
                                    }

                                    // アイテム選択フォームの作成
                                    let itemForm = new ActionFormData();
                                    itemForm.title(`${config['main'][0]}`);
                                    itemForm.body(`§5>>>§a${selectedGenre}の換金アイテムを選択`);
                                    itemForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    genreItems.forEach(item => {
                                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                                        itemForm.button(`§1${item[0]} §51個§0:§s${item[1]}§r`, icon);
                                    });

                                    itemForm
                                        .show(player)
                                        .then(r => {
                                            if (r.canceled) return;
                                            if (r.selection === 0) {
                                                showExchangeItems(player); // ジャンル選択に戻る
                                                return;
                                            }

                                            // 選択したアイテムのインデックスをグローバルインデックスに変換
                                            let globalIndex = kannkin_information_system2.findIndex((item, i) => item[4] === selectedGenre && i === kannkin_information_system2.indexOf(genreItems[r.selection - 1]));
                                            player_Cash_Data[player.id].select_item = globalIndex;

                                            // 換金数入力フォームの作成
                                            let form = new ModalFormData();
                                            form.title(`${config['main'][0]}`);

                                            // プレイヤーのインベントリから所持数を計算
                                            let inventory = player.getComponent('minecraft:inventory').container;
                                            let itemCount = 0;
                                            let selectedItemId = kannkin_information_system2[globalIndex][2];
                                            let normalizedItemId = selectedItemId.startsWith('minecraft:') ? selectedItemId : `minecraft:${selectedItemId}`;
                                            try {
                                                for (let i = 0; i < inventory.size; i++) {
                                                    let item = inventory.getItem(i);
                                                    if (item && (item.typeId === normalizedItemId || item.typeId === selectedItemId)) {
                                                        itemCount += item.amount;
                                                    }
                                                }
                                            } catch (e) {
                                                console.error(`インベントリ取得エラー: ${e}, スタック: ${e.stack}`);
                                                player.sendMessage(`§r[§b換金§r] §4インベントリの取得に失敗しました`);
                                                return;
                                            }

                                            form.textField(`§eアイテム§5>>>§c${kannkin_information_system2[globalIndex][0]}\n\n§b所持数: §e${itemCount}\n§a換金数§s(半角数字)`, '0');

                                            form.show(player)
                                                .then(r => {
                                                    if (r.canceled) return;
                                                    let amount = parseInt(r.formValues[0]);
                                                    if (isNaN(amount) || r.formValues[0] === '') {
                                                        player.sendMessage(`§r[§b換金§r] §4半角数字で入力してください`);
                                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                                        return;
                                                    }
                                                    if (amount <= 0) {
                                                        player.sendMessage(`§r[§b換金§r] §40以下は設定できません`);
                                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                                        return;
                                                    }

                                                    // 換金処理
                                                    let itemId = kannkin_information_system2[globalIndex][2];
                                                    let price = kannkin_information_system2[globalIndex][1];
                                                    player.runCommand(`tellraw @s[hasitem={item=${itemId},quantity=..${amount - 1}}]{"rawtext":[{"text":"§r[§b換金§r] §4アイテム数が足りません"}]}`);
                                                    player.runCommand(`playsound random.toast @s[hasitem={item=${itemId},quantity=..${amount - 1}}] ~ ~ ~ 1.0 0.4 0.7`);
                                                    player.runCommand(`tellraw @s[hasitem={item=${itemId},quantity=${amount}..}]{"rawtext":[{"text":"§r[§b換金§r] §e換金し${price * amount}PAY取得しました"}]}`);
                                                    player.runCommand(`playsound random.toast @s[hasitem={item=${itemId},quantity=${amount}..}] ~ ~ ~ 1.0 1.7 0.5`);
                                                    player.runCommand(`scoreboard players add @s[hasitem={item=${itemId},quantity=${amount}..}] money ${price * amount}`);
                                                    player.runCommand(`clear @s[hasitem={item=${itemId},quantity=${amount}..}] ${itemId} 0 ${amount}`);
                                                })
                                                .catch(e => {
                                                    console.error(e, e.stack);
                                                });
                                        })
                                        .catch(e => {
                                            console.error(e, e.stack);
                                        });
                                })
                                .catch(e => {
                                    console.error(e, e.stack);
                                });
                        }

                        break;
                    case '購入':
                        showPurchaseItems(player);
                        function showPurchaseItems(player) {
                            // 購入情報の取得
                            let kounyuu_list = world.getDynamicProperty('kounyuu_list');
                            let kounyuu_list_system2 = kounyuu_list ? JSON.parse(kounyuu_list) : [];

                            // ジャンル情報の取得
                            let kounyuu_genres = world.getDynamicProperty('kounyuu_genres');
                            let genres = kounyuu_genres ? JSON.parse(kounyuu_genres) : ['一般'];

                            // 既存データにジャンルがない場合、デフォルトジャンルを付与
                            kounyuu_list_system2 = kounyuu_list_system2.map(item => {
                                if (!item[4]) item[4] = '一般';
                                return item;
                            });
                            world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));

                            // 表示するジャンルをフィルタリング（「一般」はアイテムがある場合のみ含む）
                            let displayGenres = genres.filter(genre => {
                                if (genre === '一般') {
                                    return kounyuu_list_system2.some(item => item[4] === '一般');
                                }
                                return true;
                            });

                            // ジャンルがない場合の処理
                            if (!displayGenres.length) {
                                player.sendMessage(`§r[§b購入§r] §aジャンルが見つかりません`);
                                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                return;
                            }

                            // ジャンル選択フォームの作成
                            let form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body('§5>>>§aジャンルを選択');
                            form.button(`§l戻る`, 'textures/ui/icon_import.png');
                            displayGenres.forEach(genre => {
                                form.button(`§1${genre}`, 'textures/ui/normalicon1');
                            });

                            form.show(player)
                                .then(r => {
                                    if (r.canceled) return;
                                    if (r.selection === 0) {
                                        HARUPhone1(player);
                                        return;
                                    }

                                    let selectedGenre = displayGenres[r.selection - 1];

                                    // 選択したジャンルのアイテムを取得
                                    let genreItems = kounyuu_list_system2.filter(item => item[4] === selectedGenre);

                                    if (!genreItems.length) {
                                        player.sendMessage(`§r[§b購入§r] §a${selectedGenre}にアイテムが見つかりません`);
                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                        return;
                                    }

                                    // アイテム選択フォームの作成
                                    let itemForm = new ActionFormData();
                                    itemForm.title(`${config['main'][0]}`);
                                    itemForm.body(`§5>>>§a${selectedGenre}の購入アイテムを選択`);
                                    itemForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    genreItems.forEach(item => {
                                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                                        itemForm.button(`§1${item[0]} §51個§0/§s${item[1]}§r`, icon);
                                    });

                                    itemForm
                                        .show(player)
                                        .then(r => {
                                            if (r.canceled) return;
                                            if (r.selection === 0) {
                                                showPurchaseItems(player); // ジャンル選択に戻る
                                                return;
                                            }

                                            // 選択したアイテムのインデックスをグローバルインデックスに変換
                                            let globalIndex = kounyuu_list_system2.findIndex((item, i) => item[4] === selectedGenre && i === kounyuu_list_system2.indexOf(genreItems[r.selection - 1]));
                                            player_Cash_Data[player.id].select_item = globalIndex;

                                            // 購入数入力フォームの作成
                                            let form = new ModalFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.textField(`§eアイテム§5>>>§c${kounyuu_list_system2[globalIndex][0]}\n\n§a購入数§s(半角数字)`, '0');

                                            form.show(player)
                                                .then(r => {
                                                    if (r.canceled) return;
                                                    let amount = parseInt(r.formValues[0]);
                                                    if (isNaN(amount) || r.formValues[0] === '') {
                                                        player.sendMessage(`§r[§b購入§r] §4半角数字で入力してください`);
                                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                                        return;
                                                    }
                                                    if (amount <= 0) {
                                                        player.sendMessage(`§r[§b購入§r] §40以下は設定できません`);
                                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                                        return;
                                                    }

                                                    // 所持金の確認
                                                    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                    const totalCost = kounyuu_list_system2[globalIndex][1] * amount;
                                                    if (score >= totalCost) {
                                                        player.sendMessage(`§r[§b購入§r] §e${amount}個 購入しました`);
                                                        player.sendMessage(`§r[§b購入§r] §e${totalCost}PAY支払いました`);
                                                        player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
                                                        player.runCommand(`give @s ${kounyuu_list_system2[globalIndex][2]} ${amount}`);
                                                        player.runCommand(`scoreboard players remove @s money ${totalCost}`);
                                                    } else {
                                                        player.sendMessage(`§r[§b購入§r] §4Moneyが足りません`);
                                                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                                                    }
                                                })
                                                .catch(e => {
                                                    console.error(e, e.stack);
                                                });
                                        })
                                        .catch(e => {
                                            console.error(e, e.stack);
                                        });
                                })
                                .catch(e => {
                                    console.error(e, e.stack);
                                });
                        }
                        break;
                    case '情報':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body('情報サービスを選択');
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§0アドオン情報\n§8Version', 'textures/items/haruphone1');
                        form.button('§1HARUAddons§5公式サイト\n§5<<<§0QRコードからアクセスできます', 'textures/ui/qr.png');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§aアドオン名§r:§bHARUPhone1\n§eVersion§r:§b2.5.5\n§cリリース日§r:§b2025/05/15`);
                                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                //戻る
                                                HARUPhone1(player);
                                                break;
                                        }
                                    });
                                    break;
                                case 2:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§aHARUAddons§c公式リンク\n§e-------------\n§l§eサイト\n§r§aホームページ§5>>>\n§bhttps://harugames8686.github.io/HARUAddons/\n§r§aX§5>>>\n§bhttps://x.com/haru_addons`);
                                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                //戻る
                                                HARUPhone1(player);
                                                break;
                                        }
                                    });
                                    break;
                            }
                        });
                        break;
                    case 'ブラウザ':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body('サービスを選択');
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§1ページ検索');
                        form.button('§5おすすめページ一覧');
                        form.button('§9ページ作成§0/§5編集§0/§s広告');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    var browser = world.getDynamicProperty('browser');
                                    if (browser == undefined) {
                                        var browser_system2 = [];
                                    } else {
                                        var browser_system2 = JSON.parse(browser);
                                    }
                                    var form = new ModalFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.textField('キーワードを入力', 'キーワード検索');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body('検索結果');
                                        var browser_cashdata1 = [];
                                        for (let i = 0; i < browser_system2.length; i++) {
                                            var domain_keyword_system1 = browser_system2[i][2].indexOf(`${r.formValues[0]}`);
                                            if (domain_keyword_system1 !== -1) {
                                                form.button(`§l${browser_system2[i][2]}\n投稿者:§r§5${browser_system2[i][0]}`);
                                                browser_cashdata1[browser_cashdata1.length] = i;
                                            }
                                        }
                                        if (browser_cashdata1[0] == undefined) {
                                            player.sendMessage(`§r[§bブラウザ§r] §aページが見つかりませんでした`);
                                            player.playSound('random.toast', {
                                                pitch: 0.4,
                                                volume: 1.0,
                                            });
                                            return;
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            browser_system2[browser_cashdata1[response]][1] = browser_system2[browser_cashdata1[response]][1] + 1;
                                            const browsersystem1 = JSON.stringify(browser_system2);
                                            world.setDynamicProperty('browser', browsersystem1);
                                            var form = new ActionFormData();
                                            form.title(`${config['main'][0]}`);
                                            form.body(
                                                `§l${browser_system2[browser_cashdata1[response]][3]}\n§e------------\n§r投稿者:§a${browser_system2[browser_cashdata1[response]][0]}\n§e§l------------\n§r${browser_system2[browser_cashdata1[response]][4]}\n\n${browser_system2[browser_cashdata1[response]][5]}\n\n${browser_system2[browser_cashdata1[response]][6]}\n\n${
                                                    browser_system2[browser_cashdata1[response]][7]
                                                }`
                                            );
                                            form.button(`閉じる`);
                                            form.show(player).then(r => {
                                                if (r.canceled) return;
                                            });
                                        });
                                    });
                                    break;
                                case 2:
                                    var browser = world.getDynamicProperty('browser');
                                    if (browser == undefined) {
                                        var browser_system2 = [];
                                    } else {
                                        var browser_system2 = JSON.parse(browser);
                                    }
                                    if (browser_system2[0] == undefined) {
                                        player.sendMessage(`§r[§bブラウザ§r] §aページが見つかりませんでした`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                        return;
                                    }
                                    browser_system2.sort((a, b) => (a[1] > b[1] ? -1 : 1));
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('おすすめページ');
                                    for (let i = 0; i < browser_system2.length; i++) {
                                        if (i <= 7) {
                                            form.button(`§l${browser_system2[i][2]}\n§r投稿者:§5${browser_system2[i][0]}`);
                                        }
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`§l${browser_system2[response][3]}\n§e------------\n§r投稿者:§a${browser_system2[response][0]}\n§e§l------------\n§r${browser_system2[response][4]}\n\n${browser_system2[response][5]}\n\n${browser_system2[response][6]}\n\n${browser_system2[response][7]}`);
                                        form.button(`閉じる`);
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                        });
                                    });
                                    break;
                                case 3:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('機能を選択');
                                    form.button(`§1新規作成 \n§5ページ投稿費用§r:§s${world.getDynamicProperty('browser_newpage_money')}`);
                                    form.button('§1既存のページ編集');
                                    form.button('§4ページの削除');
                                    form.button(`§s広告\n§r§8こちらで作成したページを広告化できます`);
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                if (world.getDynamicProperty('browser_newpage_money') == undefined) {
                                                    player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                var form = new ModalFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.textField('検索表示タイトル', 'ここは検索されやすいワード推奨');
                                                form.textField('ページタイトル', 'ここは太字になります');
                                                form.textField('文章1', 'タイトルの下に追加されます');
                                                form.textField('文章2', '文章1の下に追加されます');
                                                form.textField('文章3', '文章2の下に追加されます');
                                                form.textField('文章4', '文章3の下に追加されます');
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                    if (score >= world.getDynamicProperty('browser_newpage_money')) {
                                                        var browser = world.getDynamicProperty('browser');
                                                        if (browser == undefined) {
                                                            var browser_system2 = [];
                                                        } else {
                                                            var browser_system2 = JSON.parse(browser);
                                                        }
                                                        browser_system2.push([player.name, 0, r.formValues[0], r.formValues[1], r.formValues[2], r.formValues[3], r.formValues[4], r.formValues[5]]);
                                                        const browser_system3 = JSON.stringify(browser_system2);
                                                        world.setDynamicProperty('browser', browser_system3);
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r §e${world.getDynamicProperty('browser_newpage_money')}PAY支払いました"}]}`);
                                                        player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_newpage_money')}`);
                                                        player.sendMessage(`§r[§bブラウザ§r] §a新規作成しました`);
                                                        let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                                                        if (settings.browser) {
                                                            world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_newpage_money')));
                                                        }
                                                        player.playSound('random.toast', {
                                                            pitch: 1.7,
                                                            volume: 1.0,
                                                        });
                                                    } else {
                                                        player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
                                                        player.playSound('random.toast', {
                                                            pitch: 0.4,
                                                            volume: 1.0,
                                                        });
                                                    }
                                                });
                                                break;
                                            case 1:
                                                var browser = world.getDynamicProperty('browser');
                                                if (browser == undefined) {
                                                    var browser_system2 = [];
                                                } else {
                                                    var browser_system2 = JSON.parse(browser);
                                                }
                                                var browser_cash = [];
                                                for (let i = 0; i < browser_system2.length; i++) {
                                                    if (browser_system2[i][0] == player.name) {
                                                        browser_cash.push([[i], browser_system2[i]]);
                                                    }
                                                }
                                                if (browser_cash[0] == undefined) {
                                                    player.sendMessage(`§r[§bブラウザ§r] §a編集できるページがありません`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body('編集するページを選択');
                                                for (let i = 0; i < browser_cash.length; i++) {
                                                    form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                }
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    player_Cash_Data[player.id].browser_select = r.selection;
                                                    var form = new ModalFormData();
                                                    form.title(`${config['main'][0]}`);
                                                    form.textField('検索表示タイトル', `${browser_cash[player_Cash_Data[player.id].browser_select][1][2]}`);
                                                    form.textField('ページタイトル', `${browser_cash[player_Cash_Data[player.id].browser_select][1][3]}`);
                                                    form.textField('文章1', `${browser_cash[player_Cash_Data[player.id].browser_select][1][4]}`);
                                                    form.textField('文章2', `${browser_cash[player_Cash_Data[player.id].browser_select][1][5]}`);
                                                    form.textField('文章3', `${browser_cash[player_Cash_Data[player.id].browser_select][1][6]}`);
                                                    form.textField('文章4', `${browser_cash[player_Cash_Data[player.id].browser_select][1][7]}`);
                                                    form.show(player).then(r => {
                                                        if (r.canceled) return;
                                                        if (r.formValues[0] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][2] = r.formValues[0];
                                                        }
                                                        if (r.formValues[1] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][3] = r.formValues[1];
                                                        }
                                                        if (r.formValues[2] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][4] = r.formValues[2];
                                                        }
                                                        if (r.formValues[3] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][5] = r.formValues[3];
                                                        }
                                                        if (r.formValues[4] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][6] = r.formValues[4];
                                                        }
                                                        if (r.formValues[5] != '') {
                                                            browser_cash[player_Cash_Data[player.id].browser_select][1][7] = r.formValues[5];
                                                        }
                                                        browser_system2[browser_cash[player_Cash_Data[player.id].browser_select][0][0]] = browser_cash[player_Cash_Data[player.id].browser_select][1];
                                                        const browser_system3 = JSON.stringify(browser_system2);
                                                        world.setDynamicProperty('browser', browser_system3);
                                                        player.sendMessage(`§r[§bブラウザ§r] §aページを編集しました`);
                                                        player.playSound('random.toast', {
                                                            pitch: 1.7,
                                                            volume: 1.0,
                                                        });
                                                    });
                                                });
                                                break;
                                            case 2:
                                                var browser = world.getDynamicProperty('browser');
                                                if (browser == undefined) {
                                                    var browser_system2 = [];
                                                } else {
                                                    var browser_system2 = JSON.parse(browser);
                                                }
                                                var browser_cash = [];
                                                for (let i = 0; i < browser_system2.length; i++) {
                                                    if (browser_system2[i][0] == player.name) {
                                                        browser_cash.push([[i], browser_system2[i]]);
                                                    }
                                                }
                                                if (browser_cash[0] == undefined) {
                                                    player.sendMessage(`§r[§bブラウザ§r] §a削除できるページがありません`);
                                                    player.playSound('random.toast', {
                                                        pitch: 0.4,
                                                        volume: 1.0,
                                                    });
                                                    return;
                                                }
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body('削除するページを選択');
                                                for (let i = 0; i < browser_cash.length; i++) {
                                                    form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                }
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    browser_system2.splice(browser_cash[response][0][0], 1);
                                                    const browser_system3 = JSON.stringify(browser_system2);
                                                    world.setDynamicProperty('browser', browser_system3);
                                                    player.sendMessage(`§r[§bブラウザ§r] §aページを削除しました`);
                                                    player.playSound('random.toast', {
                                                        pitch: 1.7,
                                                        volume: 1.0,
                                                    });
                                                });
                                                break;
                                            case 3:
                                                var form = new ActionFormData();
                                                form.title(`${config['main'][0]}`);
                                                form.body('サービスを選択');
                                                form.button(`§1広告化 \n§5ページ広告化費用§r:§s${world.getDynamicProperty('browser_performance_money')}§rPAY`);
                                                form.button('§4広告削除');
                                                form.show(player).then(r => {
                                                    if (r.canceled) return;
                                                    let response = r.selection;
                                                    switch (response) {
                                                        case 0:
                                                            if (world.getDynamicProperty('browser_performance_money') == undefined) {
                                                                player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
                                                                player.playSound('random.toast', {
                                                                    pitch: 0.4,
                                                                    volume: 1.0,
                                                                });
                                                                return;
                                                            }
                                                            var browser = world.getDynamicProperty('browser');
                                                            if (browser == undefined) {
                                                                var browser_system2 = [];
                                                            } else {
                                                                var browser_system2 = JSON.parse(browser);
                                                            }
                                                            var browser_cash = [];
                                                            for (let i = 0; i < browser_system2.length; i++) {
                                                                if (browser_system2[i][0] == player.name) {
                                                                    browser_cash.push([[i], browser_system2[i]]);
                                                                }
                                                            }
                                                            if (browser_cash[0] == undefined) {
                                                                player.sendMessage(`§r[§bブラウザ§r] §a広告化できるページがありません`);
                                                                player.playSound('random.toast', {
                                                                    pitch: 0.4,
                                                                    volume: 1.0,
                                                                });
                                                                return;
                                                            }
                                                            var form = new ActionFormData();
                                                            form.title(`${config['main'][0]}`);
                                                            form.body('広告化するページを選択');
                                                            for (let i = 0; i < browser_cash.length; i++) {
                                                                form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                            }
                                                            form.show(player).then(r => {
                                                                if (r.canceled) return;
                                                                let response = r.selection;
                                                                const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                                if (score >= world.getDynamicProperty('browser_performance_money')) {
                                                                    var performance = world.getDynamicProperty('performance');
                                                                    if (performance == undefined) {
                                                                        var performance_system2 = [];
                                                                    } else {
                                                                        var performance_system2 = JSON.parse(performance);
                                                                    }
                                                                    var performance_cash_system2 = 0;
                                                                    for (let i = 0; i < performance_system2.length; i++) {
                                                                        if (performance_system2[i][2] == browser_cash[response][1][2] && performance_system2[i][0] == browser_cash[response][1][0] && performance_system2[i][3] == browser_cash[response][1][3] && performance_system2[i][4] == browser_cash[response][1][4] && performance_system2[i][5] == browser_cash[response][1][5]) {
                                                                            performance_cash_system2 = 1;
                                                                        }
                                                                    }
                                                                    if (performance_cash_system2 == 1) {
                                                                        player.sendMessage(`§r[§bブラウザ§r] §4選択したページは既に広告化済みです`);
                                                                        player.playSound('random.toast', {
                                                                            pitch: 0.4,
                                                                            volume: 1.0,
                                                                        });
                                                                        return;
                                                                    }
                                                                    performance_system2.push(browser_cash[response][1]);
                                                                    const performance_system3 = JSON.stringify(performance_system2);
                                                                    world.setDynamicProperty('performance', performance_system3);
                                                                    player.sendMessage(`§r[§bブラウザ§r] §e${world.getDynamicProperty('browser_performance_money')}PAY支払いました`);
                                                                    player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_performance_money')}`);
                                                                    player.sendMessage(`§r[§bブラウザ§r] §aページを広告化しました`);
                                                                    let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                                                                    if (settings.browser) {
                                                                        world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_performance_money')));
                                                                    }
                                                                    player.playSound('random.toast', {
                                                                        pitch: 1.7,
                                                                        volume: 1.0,
                                                                    });
                                                                } else {
                                                                    player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
                                                                    player.playSound('random.toast', {
                                                                        pitch: 0.4,
                                                                        volume: 1.0,
                                                                    });
                                                                }
                                                            });
                                                            break;
                                                        case 1:
                                                            var browser = world.getDynamicProperty('performance');
                                                            if (browser == undefined) {
                                                                var browser_system2 = [];
                                                            } else {
                                                                var browser_system2 = JSON.parse(browser);
                                                            }
                                                            var browser_cash = [];
                                                            for (let i = 0; i < browser_system2.length; i++) {
                                                                if (browser_system2[i][0] == player.name) {
                                                                    browser_cash.push([[i], browser_system2[i]]);
                                                                }
                                                            }
                                                            if (browser_cash[0] == undefined) {
                                                                player.sendMessage(`§r[§bブラウザ§r] §a削除できる広告がありません`);
                                                                player.playSound('random.toast', {
                                                                    pitch: 0.4,
                                                                    volume: 1.0,
                                                                });
                                                                return;
                                                            }
                                                            var form = new ActionFormData();
                                                            form.title(`${config['main'][0]}`);
                                                            form.body('削除する広告を選択');
                                                            for (let i = 0; i < browser_cash.length; i++) {
                                                                form.button(`§l${browser_cash[i][1][2]}\n§r${browser_cash[i][1][3]}`);
                                                            }
                                                            form.show(player).then(r => {
                                                                if (r.canceled) return;
                                                                let response = r.selection;
                                                                browser_system2.splice(browser_cash[response][0][0], 1);
                                                                const browser_system3 = JSON.stringify(browser_system2);
                                                                world.setDynamicProperty('performance', browser_system3);
                                                                player.sendMessage(`§r[§bブラウザ§r] §a広告を削除しました`);
                                                                player.playSound('random.toast', {
                                                                    pitch: 1.7,
                                                                    volume: 1.0,
                                                                });
                                                            });
                                                            break;
                                                    }
                                                });

                                                break;
                                        }
                                    });

                                    break;
                            }
                        });
                        break;
                    case '社会システム':
                        showMainUI(player);
                        break;
                    case '請求':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body('設定を選択');
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§9請求を送る');
                        form.button('§5届いた請求を確認');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    player_Cash_Data[player.id] = {};
                                    player_Cash_Data[player.id].players = world.getAllPlayers();
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('請求送信先プレイヤーを選択');
                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                        form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§5>>>§8${player_Cash_Data[player.id].players[i].id}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection];
                                        var form = new ModalFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.textField('§e請求金額 §r[半角数字]', `0`);
                                        form.textField('§a請求理由', `理由`);
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            if (r.formValues[0] == '') {
                                                player.sendMessage(`§r[§b請求§r] §4金額を設定してください`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (isNaN(r.formValues[0])) {
                                                player.sendMessage(`§r[§b請求§r] §4半角数字で入力してください`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (r.formValues[0] < 0) {
                                                player.sendMessage(`§r[§b請求§r] §40以下は設定できません`);
                                                player.playSound('random.toast', {
                                                    pitch: 0.4,
                                                    volume: 1.0,
                                                });
                                                return;
                                            }
                                            if (Claim[player_Cash_Data[player.id].select_player.name] == undefined) {
                                                Claim[player_Cash_Data[player.id].select_player.name] = [];
                                            }
                                            Claim[player_Cash_Data[player.id].select_player.name].push([player.name, Number(r.formValues[0]), r.formValues[1]]);

                                            //メッセージ
                                            player.sendMessage(`§r[§b請求§r] §a${player_Cash_Data[player.id].select_player.name}§rへ請求を送信しました`);
                                            player_Cash_Data[player.id].select_player.sendMessage(`§r[§b請求§r] §a${player.name}§rから§2${r.formValues[1]}§rの請求が届きました`);
                                            player.playSound('random.toast', {
                                                pitch: 1.5,
                                                volume: 1.0,
                                            });
                                            player_Cash_Data[player.id].select_player.playSound('random.toast', {
                                                pitch: 1.5,
                                                volume: 1.0,
                                            });
                                        });
                                    });
                                    break;
                                case 2:
                                    if (Claim[player.name] == undefined) {
                                        player.sendMessage(`§r[§b請求§r] §a届いた請求が見つかりません`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                        return;
                                    }
                                    player_Cash_Data[player.id] = {};
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body('処理を行う請求をお選びください');
                                    for (let i = 0; i < Claim[player.name].length; i++) {
                                        form.button(`§9${Claim[player.name][i][2]}\n§0送信したプレイヤー:§s${Claim[player.name][i][0]}`);
                                    }
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        player_Cash_Data[player.id].select = r.selection;
                                        var form = new ActionFormData();
                                        form.title(`${config['main'][0]}`);
                                        form.body(`§l請求の詳細\n§r請求理由:§a${Claim[player.name][player_Cash_Data[player.id].select][2]}\n§r請求金額:§a${Claim[player.name][player_Cash_Data[player.id].select][1]}\n§r請求を送信したプレイヤー:§a${Claim[player.name][player_Cash_Data[player.id].select][0]}`);
                                        form.button('§1許可');
                                        form.button('§5拒否');
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            let response = r.selection;
                                            switch (response) {
                                                case 0:
                                                    player_Cash_Data[player.id].claim_stop = false;
                                                    player_Cash_Data[player.id].players = world.getAllPlayers();
                                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                        if (Claim[player.name][player_Cash_Data[player.id].select][0] === player_Cash_Data[player.id].players[i].name) {
                                                            player_Cash_Data[player.id].claim_stop = true;
                                                        }
                                                    }
                                                    if (player_Cash_Data[player.id].claim_stop == false) {
                                                        player.sendMessage(`§r[§b請求§r] §4相手プレイヤーがオフラインの為処理を中止しました`);
                                                        player.playSound('random.toast', {
                                                            pitch: 0.4,
                                                            volume: 1.0,
                                                        });
                                                        return;
                                                    }
                                                    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                    //残高が設定金額以上の場合のみ実行
                                                    if (score >= Claim[player.name][player_Cash_Data[player.id].select][1]) {
                                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§b請求§r] §a請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY送信しました"}]}`);
                                                        player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§b請求§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY受け取りました"}]}`);
                                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`);
                                                        player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`);
                                                        player.runCommand(`scoreboard players add @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                                        player.runCommand(`scoreboard players remove @a[name="${player.name}", scores={money=${Claim[player.name][player_Cash_Data[player.id].select][1]}..}] money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                                        Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                                    }
                                                    break;
                                                case 1:
                                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§b請求§r] §a請求を§4拒否しました"}]}`);
                                                    player.runCommand(`tellraw @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] {"rawtext":[{"text":"§r[§b請求§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を§4拒否しました"}]}`);
                                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.5 0.5`);
                                                    player.runCommand(`playsound random.toast @a[name="${Claim[player.name][player_Cash_Data[player.id].select][0]}"] ~ ~ ~ 1.0 1.5 0.5`);
                                                    Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                                    break;
                                            }
                                        });
                                    });
                                    break;
                            }
                        });
                        break;
                    case 'HARUAssistant':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§aチャットボットを選択`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§1Insight-4\n§8最も賢い');
                        form.button('§1Insight-3');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    chatLoop4(player);
                                    break;
                                case 2:
                                    chatLoop3(player);
                                    break;
                            }
                        });
                        break;
                    case 'Map':
                        openUserNavigationForm(player);
                        break;
                    case 'Operator Controller':
                        Operator_Controller(player);
                        break;
                    default:
                }
            });
        }
    });
}
