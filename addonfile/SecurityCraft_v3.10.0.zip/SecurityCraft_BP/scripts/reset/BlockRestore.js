import { world, system, BlockPermutation, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

// --- 設定項目 ---
const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7;
let GROUPING_INTERVAL_MINUTES = 10;

// --- 内部変数 ---
let saveQueue = new Map();
let isSaveProcessorRunning = false;
let deletionQueue = new Map(); // 復元済みログの削除待ちキュー
let isDeletionProcessorRunning = false; // 削除処理が実行中かのフラグ

const MAX_PROPERTY_SIZE = 30000;
const PART_KEY_PREFIX = '_part_';

export function rreload() {
    try {
        const storedDays = world.getDynamicProperty('blockrestore_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[BlockRestore] 復元データの保存期間読み込みエラー: ${e}`);
    }

    try {
        const storedMinutes = world.getDynamicProperty('blockrestore_save_interval');
        if (typeof storedMinutes === 'number' && !isNaN(storedMinutes) && storedMinutes > 0) {
            GROUPING_INTERVAL_MINUTES = storedMinutes;
        }
    } catch (e) {
        console.warn(`[BlockRestore] データ保存間隔の読み込みエラー: ${e}`);
    }
}

function processSaveQueue() {
    if (saveQueue.size === 0) {
        isSaveProcessorRunning = false;
        return;
    }
    const [chunkKey, newDataToSave] = saveQueue.entries().next().value;
    saveQueue.delete(chunkKey);
    const currentChunkData = getChunkData(chunkKey);

    if (deletionQueue.has(chunkKey)) {
        const posKeysToDelete = deletionQueue.get(chunkKey);
        for (const posKey of posKeysToDelete) {
            currentChunkData.delete(posKey);
        }
        deletionQueue.delete(chunkKey);
    }

    for (const [key, value] of newDataToSave.entries()) {
        currentChunkData.set(key, value);
    }
    saveChunkData(chunkKey, currentChunkData, true); // trueで上書きモード

    system.runTimeout(processSaveQueue, 3);
}

function triggerSaveProcessor() {
    if (!isSaveProcessorRunning) {
        isSaveProcessorRunning = true;
        system.runTimeout(processSaveQueue, 3);
    }
}

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `restore_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z, timestamp) {
    return `${x},${y},${z},${timestamp}`;
}

function saveChunkData(chunkKey, newData, isOverwrite = false) {
    try {
        if (isOverwrite) {
            // 上書きモードの場合、古いパートをすべて削除
            const oldPartCount = world.getDynamicProperty(chunkKey) || 0;
            for (let i = 0; i < oldPartCount; i++) {
                world.setDynamicProperty(`${chunkKey}${PART_KEY_PREFIX}${i}`, undefined);
            }
        }

        const partCount = isOverwrite ? 0 : world.getDynamicProperty(chunkKey) || 0;
        if (typeof partCount !== 'number') {
            console.warn(`[BlockRestore] Part count for ${chunkKey} is not a number. Resetting.`);
            world.setDynamicProperty(chunkKey, 0);
            return;
        }

        const entries = [...newData.entries()];
        if (entries.length === 0 && isOverwrite) {
            // 上書きモードでデータが空なら、キー自体を消して終了
            world.setDynamicProperty(chunkKey, undefined);
            return;
        }

        const jsonString = JSON.stringify(entries);
        let newPartIndex = partCount;

        if (jsonString.length <= MAX_PROPERTY_SIZE) {
            world.setDynamicProperty(`${chunkKey}${PART_KEY_PREFIX}${newPartIndex}`, jsonString);
            newPartIndex++;
        } else {
            // データが大きい場合は分割
            let currentPartEntries = [];
            let currentPartLength = 2;
            for (const entry of entries) {
                const entryString = JSON.stringify(entry);
                const entryLength = entryString.length + (currentPartEntries.length > 0 ? 1 : 0);
                if (currentPartEntries.length > 0 && currentPartLength + entryLength > MAX_PROPERTY_SIZE) {
                    world.setDynamicProperty(`${chunkKey}${PART_KEY_PREFIX}${newPartIndex}`, JSON.stringify(currentPartEntries));
                    newPartIndex++;
                    currentPartEntries = [];
                    currentPartLength = 2;
                }
                currentPartEntries.push(entry);
                currentPartLength += entryLength;
            }
            if (currentPartEntries.length > 0) {
                world.setDynamicProperty(`${chunkKey}${PART_KEY_PREFIX}${newPartIndex}`, JSON.stringify(currentPartEntries));
                newPartIndex++;
            }
        }
        world.setDynamicProperty(chunkKey, newPartIndex);
    } catch (e) {
        console.warn(`[BlockRestore] チャンクデータ保存エラー (Key: ${chunkKey}): ${e}`);
    }
}

function getChunkData(chunkKey) {
    try {
        const queuedData = saveQueue.get(chunkKey) || new Map();
        const partCount = world.getDynamicProperty(chunkKey);
        if (typeof partCount !== 'number' || partCount === 0) return new Map(queuedData);

        let combinedEntries = [];
        for (let i = 0; i < partCount; i++) {
            const partKey = `${chunkKey}${PART_KEY_PREFIX}${i}`;
            const partData = world.getDynamicProperty(partKey);
            if (typeof partData === 'string') {
                try {
                    combinedEntries.push(...JSON.parse(partData));
                } catch (parseError) {
                    console.warn(`[BlockRestore] 分割データのパースに失敗 (Key: ${partKey}): ${parseError}`);
                }
            }
        }
        const finalMap = new Map(combinedEntries);
        for (const [key, value] of queuedData.entries()) {
            finalMap.set(key, value);
        }
        return finalMap;
    } catch (e) {
        console.warn(`[BlockRestore] チャンクデータ読み込みエラー (Key: ${chunkKey}): ${e}`);
        return new Map();
    }
}

function processDeletionQueue() {
    if (deletionQueue.size === 0) {
        isDeletionProcessorRunning = false;
        return;
    }

    const [chunkKey, posKeysToDelete] = deletionQueue.entries().next().value;
    deletionQueue.delete(chunkKey);

    const currentChunkData = getChunkData(chunkKey);
    let modified = false;
    for (const posKey of posKeysToDelete) {
        if (currentChunkData.delete(posKey)) {
            modified = true;
        }
    }

    if (modified) {
        saveChunkData(chunkKey, currentChunkData, true); // trueで上書きモード
    }

    // 次の処理をスケジュールする (3ティック)
    system.runTimeout(processDeletionQueue, 3);
}

function triggerDeletionProcessor() {
    if (!isDeletionProcessorRunning) {
        isDeletionProcessorRunning = true;
        system.runTimeout(processDeletionQueue, 3);
    }
}

function recordBlockBreak({ location, permutation, dimensionId, cause, blockEntityData }) {
    if (world.getDynamicProperty('BlockRestore_system') !== true) return;
    const { x, y, z } = location;
    const timestamp = Date.now();
    const chunkKey = getChunkKey(x, z, timestamp);
    const positionKey = getPositionKey(x, y, z, timestamp);
    if (!saveQueue.has(chunkKey)) saveQueue.set(chunkKey, new Map());
    const chunkUpdateData = saveQueue.get(chunkKey);
    const logEntry = { t: 'b', p: { typeId: permutation.type.id, states: permutation.getAllStates() }, d: dimensionId, ts: timestamp, c: cause, be: blockEntityData };
    chunkUpdateData.set(positionKey, logEntry);
    triggerSaveProcessor();
}

// タイムスタンプをキーに含める
function recordBlockPlace(block, player) {
    if (world.getDynamicProperty('BlockRestore_system') !== true) return;
    const { x, y, z } = block.location;
    const timestamp = Date.now();
    const chunkKey = getChunkKey(x, z, timestamp);
    const positionKey = getPositionKey(x, y, z, timestamp);
    if (!saveQueue.has(chunkKey)) saveQueue.set(chunkKey, new Map());
    const chunkUpdateData = saveQueue.get(chunkKey);
    const logEntry = { t: 'p', p: { typeId: block.typeId, states: block.permutation.getAllStates() }, d: player.dimension.id, ts: timestamp, c: `Player: ${player.name}` };
    chunkUpdateData.set(positionKey, logEntry);
    triggerSaveProcessor();
}

export function BlockRestore() {
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const { player, block } = event;
        let blockEntityData = null;
        try {
            const inventory = block.getComponent('inventory');
            if (inventory?.container) {
                const items = [];
                for (let i = 0; i < inventory.container.size; i++) {
                    const item = inventory.container.getItem(i);
                    if (item) items.push({ slot: i, typeId: item.typeId, amount: item.amount, nameTag: item.nameTag });
                }
                if (items.length > 0) blockEntityData = { type: 'inventory', data: items };
            } else {
                const sign = block.getComponent('sign');
                if (sign) {
                    const text = sign.getText();
                    if (text?.trim().length > 0) blockEntityData = { type: 'sign', data: text };
                }
            }
        } catch (e) {
            /* ignore */
        }
        recordBlockBreak({ location: block.location, permutation: block.permutation, dimensionId: player.dimension.id, cause: `Player: ${player.name}`, blockEntityData });
    });
    world.afterEvents.blockExplode.subscribe(event => {
        const { dimension, source, block, explodedBlockPermutation } = event;
        recordBlockBreak({ location: block.location, permutation: explodedBlockPermutation, dimensionId: dimension.id, cause: `Explosion (Source: ${source?.typeId || 'Unknown'})`, blockEntityData: null });
    });
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        recordBlockPlace(event.block, event.player);
    });
    rreload();
    system.runInterval(() => {
        try {
            const expirationDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY) - DAYS_TO_KEEP;
            const allKeys = world.getDynamicPropertyIds();
            const keysToDelete = [];
            for (const key of allKeys) {
                if (key.startsWith('restore_')) {
                    const parts = key.split('_');
                    if (parts.length >= 4) {
                        const day = parseInt(parts[3], 10);
                        if (!isNaN(day) && day < expirationDay) keysToDelete.push(key);
                    }
                }
            }
            for (const key of keysToDelete) world.setDynamicProperty(key, undefined);
        } catch (e) {
            console.warn(`[BlockRestore] 古いデータ削除エラー: ${e}`);
        }
    }, 20 * 60 * 30);
}

function restoreOrUndoBlocks(player, blocksToProcess) {
    if (!blocksToProcess || blocksToProcess.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §e対象のブロックはありませんでした。');
        return;
    }
    player.sendMessage(`§r[§bSecurityCraft§r] §aブロックの復元/取り消しを開始します... (対象: ${blocksToProcess.length}ブロック)`);

    const gravityBlockIds = new Set([
        'minecraft:sand',
        'minecraft:gravel',
        'minecraft:red_sand',
        'minecraft:anvil',
        'minecraft:chipped_anvil',
        'minecraft:damaged_anvil',
        'minecraft:concrete_powder',
        'minecraft:white_concrete_powder',
        'minecraft:orange_concrete_powder',
        'minecraft:magenta_concrete_powder',
        'minecraft:light_blue_concrete_powder',
        'minecraft:yellow_concrete_powder',
        'minecraft:lime_concrete_powder',
        'minecraft:pink_concrete_powder',
        'minecraft:gray_concrete_powder',
        'minecraft:light_gray_concrete_powder',
        'minecraft:cyan_concrete_powder',
        'minecraft:purple_concrete_powder',
        'minecraft:blue_concrete_powder',
        'minecraft:brown_concrete_powder',
        'minecraft:green_concrete_powder',
        'minecraft:red_concrete_powder',
        'minecraft:black_concrete_powder',
        'minecraft:scaffolding',
        'minecraft:pointed_dripstone',
    ]);
    const attachableBlockIds = new Set([
        'minecraft:water',
        'minecraft:lava',
        'minecraft:torch',
        'minecraft:redstone_wire',
        'minecraft:powered_repeater',
        'minecraft:redstone_torch',
        'minecraft:standing_sign',
        'minecraft:wall_sign',
        'minecraft:lever',
        'minecraft:stone_button',
        'minecraft:oak_button',
        'minecraft:wooden_button',
        'minecraft:spruce_button',
        'minecraft:birch_button',
        'minecraft:jungle_button',
        'minecraft:acacia_button',
        'minecraft:dark_oak_button',
        'minecraft:mangrove_button',
        'minecraft:cherry_button',
        'minecraft:bamboo_button',
        'minecraft:crimson_button',
        'minecraft:warped_button',
        'minecraft:polished_blackstone_button',
        'minecraft:tripwire_hook',
        'minecraft:redstone_wire',
        'minecraft:tripwire',
        'minecraft:repeater',
        'minecraft:comparator',
        'minecraft:ladder',
        'minecraft:vine',
        'minecraft:rail',
        'minecraft:detector_rail',
        'minecraft:golden_rail',
        'minecraft:activator_rail',
        'minecraft:oak_sapling',
        'minecraft:spruce_sapling',
        'minecraft:birch_sapling',
        'minecraft:jungle_sapling',
        'minecraft:acacia_sapling',
        'minecraft:dark_oak_sapling',
        'minecraft:mangrove_propagule',
        'minecraft:cherry_sapling',
        'minecraft:dandelion',
        'minecraft:poppy',
        'minecraft:blue_orchid',
        'minecraft:allium',
        'minecraft:azure_bluet',
        'minecraft:red_tulip',
        'minecraft:orange_tulip',
        'minecraft:white_tulip',
        'minecraft:pink_tulip',
        'minecraft:oxeye_daisy',
        'minecraft:cornflower',
        'minecraft:lily_of_the_valley',
        'minecraft:wither_rose',
        'minecraft:sunflower',
        'minecraft:lilac',
        'minecraft:rose_bush',
        'minecraft:peony',
        'minecraft:torchflower',
        'minecraft:pitcher_plant',
        'minecraft:brown_mushroom',
        'minecraft:red_mushroom',
        'minecraft:crimson_fungus',
        'minecraft:warped_fungus',
        'minecraft:wheat',
        'minecraft:potatoes',
        'minecraft:carrots',
        'minecraft:beetroot',
        'minecraft:nether_wart',
        'minecraft:reeds',
        'minecraft:bamboo',
        'minecraft:bamboo_sapling',
        'minecraft:sugar_cane',
        'minecraft:kelp',
        'minecraft:seagrass',
        'minecraft:hanging_roots',
        'minecraft:iron_door',
        'minecraft:wooden_door',
        'minecraft:spruce_door',
        'minecraft:birch_door',
        'minecraft:jungle_door',
        'minecraft:acacia_door',
        'minecraft:dark_oak_door',
        'minecraft:mangrove_door',
        'minecraft:cherry_door',
        'minecraft:bamboo_door',
        'minecraft:crimson_door',
        'minecraft:warped_door',
        'minecraft:ladder',
        'minecraft:oak_sign',
        'minecraft:spruce_sign',
        'minecraft:birch_sign',
        'minecraft:jungle_sign',
        'minecraft:acacia_sign',
        'minecraft:dark_oak_sign',
        'minecraft:mangrove_sign',
        'minecraft:cherry_sign',
        'minecraft:bamboo_sign',
        'minecraft:crimson_sign',
        'minecraft:warped_sign',
        'minecraft:wooden_pressure_plate',
        'minecraft:spruce_pressure_plate',
        'minecraft:birch_pressure_plate',
        'minecraft:jungle_pressure_plate',
        'minecraft:acacia_pressure_plate',
        'minecraft:dark_oak_pressure_plate',
        'minecraft:mangrove_pressure_plate',
        'minecraft:cherry_pressure_plate',
        'minecraft:bamboo_pressure_plate',
        'minecraft:crimson_pressure_plate',
        'minecraft:warped_pressure_plate',
        'minecraft:heavy_weighted_pressure_plate',
    ]);
    const blocksToUndo = [];
    const solidBlocksToRestore = [];
    const gravityBlocksToRestore = [];
    const attachableBlocksToRestore = [];
    for (const item of blocksToProcess) {
        if (item.t === 'p') {
            blocksToUndo.push(item);
        } else {
            const typeId = item.p.typeId;
            if (gravityBlockIds.has(typeId)) {
                gravityBlocksToRestore.push(item);
            } else if (attachableBlockIds.has(typeId)) {
                attachableBlocksToRestore.push(item);
            } else {
                solidBlocksToRestore.push(item);
            }
        }
    }
    gravityBlocksToRestore.sort((a, b) => a.location.y - b.location.y);
    attachableBlocksToRestore.sort((a, b) => a.location.y - b.location.y);
    const orderedBlocksToProcess = [...solidBlocksToRestore, ...gravityBlocksToRestore, ...attachableBlocksToRestore, ...blocksToUndo];
    const successfullyProcessedBlocks = [];
    const blocksWithEntityData = [];
    const BATCH_SIZE = 50;
    let currentIndex = 0;

    const totalBlocks = orderedBlocksToProcess.length;

    const generateProgressBar = percentage => {
        const barLength = 20; // プログレスバーの長さ
        const filledLength = Math.round(barLength * (percentage / 100));
        const emptyLength = barLength - filledLength;
        const bar = '§a' + '|'.repeat(filledLength) + '§7' + '|'.repeat(emptyLength);
        return `§f復元中: ${bar} §r(§e${percentage}§r%)`;
    };

    const processBatch = () => {
        const batch = orderedBlocksToProcess.slice(currentIndex, currentIndex + BATCH_SIZE);
        currentIndex += batch.length;

        try {
            const percentage = Math.floor((currentIndex / totalBlocks) * 100);
            player.onScreenDisplay.setActionBar(generateProgressBar(percentage));
        } catch (e) {}

        for (const item of batch) {
            try {
                const block = player.dimension.getBlock(item.location);
                if (!block) continue;
                let success = false;
                if (item.t === 'p') {
                    if (!block.isAir) {
                        block.setPermutation(BlockPermutation.resolve('minecraft:air'));
                        success = true;
                    }
                } else {
                    if (block.isAir || block.typeId === 'minecraft:water' || block.typeId === 'minecraft:lava') {
                        const permutation = BlockPermutation.resolve(item.p.typeId, item.p.states);
                        block.setPermutation(permutation);
                        if (item.be) blocksWithEntityData.push(item);
                        success = true;
                    }
                }
                if (success) successfullyProcessedBlocks.push(item);
            } catch (e) {}
        }
        if (currentIndex < orderedBlocksToProcess.length) system.run(processBatch);
        else {
            try {
                if (blocksWithEntityData.length > 0) {
                    player.onScreenDisplay.setActionBar('§eチェスト等のデータを復元中...');
                }
            } catch (e) {}
            system.runTimeout(restoreBlockEntities, 5);
        }
    };

    const restoreBlockEntities = () => {
        let entityIndex = 0;
        const processEntityBatch = () => {
            const batch = blocksWithEntityData.slice(entityIndex, entityIndex + BATCH_SIZE);
            entityIndex += batch.length;
            for (const item of batch) {
                try {
                    const restoredBlock = player.dimension.getBlock(item.location);
                    if (!restoredBlock) continue;
                    if (item.be.type === 'inventory' && item.be.data) {
                        const inventory = restoredBlock.getComponent('inventory');
                        if (inventory) {
                            for (const itemData of item.be.data) {
                                const newItem = new ItemStack(itemData.typeId, itemData.amount);
                                if (itemData.nameTag) newItem.nameTag = itemData.nameTag;
                                inventory.container.setItem(itemData.slot, newItem);
                            }
                        }
                    } else if (item.be.type === 'sign' && item.be.data) {
                        const sign = restoredBlock.getComponent('sign');
                        if (sign) sign.setText(item.be.data);
                    }
                } catch (e) {
                    console.warn(`[BlockRestore] ブロックエンティティ復元エラー: ${e}`);
                }
            }
            if (entityIndex < blocksWithEntityData.length) system.run(processEntityBatch);
            else finishProcess();
        };
        if (blocksWithEntityData.length > 0) system.run(processEntityBatch);
        else finishProcess();
    };

    const finishProcess = () => {
        try {
            player.onScreenDisplay.setActionBar('');
        } catch (e) {}

        for (const item of successfullyProcessedBlocks) {
            const { chunkKey, posKey } = item.key;
            if (!deletionQueue.has(chunkKey)) {
                deletionQueue.set(chunkKey, new Set());
            }
            deletionQueue.get(chunkKey).add(posKey);
        }
        if (successfullyProcessedBlocks.length > 0) triggerDeletionProcessor();

        const processedCount = successfullyProcessedBlocks.length;
        const failedCount = blocksToProcess.length - processedCount;
        if (failedCount > 0) {
            player.sendMessage(`§r[§bSecurityCraft§r] §b${processedCount}個§aのブロック操作を完了しました。`);
            player.sendMessage(`§r[§bSecurityCraft§r] §c注意: §e${failedCount}個§cのブロックが処理できませんでした。`);
        } else {
            player.sendMessage(`§r[§bSecurityCraft§r] §b${processedCount}個§aのブロック操作をすべて完了しました。`);
        }
        player.playSound('random.toast', { pitch: 1.2 });
    };

    system.run(processBatch);
}

function formatTimeAgo(diff) {
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}日`;
    if (hours > 0) return `${hours}時間`;
    if (minutes > 0) return `${minutes}分`;
    return `${seconds}秒`;
}

export async function showRestoreUI(player) {
    const rangeForm = new ModalFormData()
        .title('§0SecurityCraft-§1Core')
        .textField('>§c復元範囲を指定してください\n\n§a中心座標 X', '数値を入力', { defaultValue: `${String(Math.floor(player.location.x))}` })
        .textField('§a中心座標 Y', '数値を入力', { defaultValue: `${String(Math.floor(player.location.y))}` })
        .textField('§a中心座標 Z', '数値を入力', { defaultValue: `${String(Math.floor(player.location.z))}` })
        .textField('§e復元範囲（半径）', '数値を入力', { defaultValue: '10' })
        .submitButton(`§0データ検索`);
    const rangeResponse = await rangeForm.show(player);
    if (rangeResponse.canceled) return;
    const [xStr, yStr, zStr, radiusStr] = rangeResponse.formValues;
    const centerX = parseInt(xStr, 10);
    const centerY = parseInt(yStr, 10);
    const centerZ = parseInt(zStr, 10);
    const radius = parseInt(radiusStr, 10);
    if (isNaN(centerX) || isNaN(centerY) || isNaN(centerZ) || isNaN(radius) || radius < 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §c無効な数値が入力されました。');
        return;
    }
    if (radius > 1200) {
        player.sendMessage('§r[§bSecurityCraft§r] §c半径が大きすぎます（最大1200）。');
        return;
    }
    player.sendMessage(`§r[§bSecurityCraft§r] §a指定範囲のログを検索しています...`);
    const dimension = player.dimension;
    const allLogs = [];
    const minChunkX = Math.floor((centerX - radius) / CHUNK_SIZE);
    const maxChunkX = Math.floor((centerX + radius) / CHUNK_SIZE);
    const minChunkZ = Math.floor((centerZ - radius) / CHUNK_SIZE);
    const maxChunkZ = Math.floor((centerZ + radius) / CHUNK_SIZE);
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const timestamp = Date.now() - i * MILLISECONDS_PER_DAY;
        for (let cx = minChunkX; cx <= maxChunkX; cx++) {
            for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
                const chunkKey = getChunkKey(cx * CHUNK_SIZE, cz * CHUNK_SIZE, timestamp);
                const chunkData = getChunkData(chunkKey);
                for (const [posKey, log] of chunkData.entries()) {
                    if (log.d === dimension.id) {
                        const [x, y, z] = posKey.split(',').map(Number);
                        const distSq = (x - centerX) ** 2 + (y - centerY) ** 2 + (z - centerZ) ** 2;
                        if (distSq <= radius * radius) {
                            allLogs.push({ ...log, location: { x, y, z }, key: { chunkKey, posKey } });
                        }
                    }
                }
            }
        }
    }
    if (allLogs.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §e指定範囲内に復元可能なブロック操作の記録がありません');
        return;
    }
    allLogs.sort((a, b) => b.ts - a.ts);
    const groupedLogs = [];
    if (allLogs.length > 0) {
        const intervalMinutes = world.getDynamicProperty('blockrestore_save_interval') || 10;
        const GROUPING_INTERVAL_MS = intervalMinutes * 60 * 1000;
        const groups = new Map();
        for (const log of allLogs) {
            const groupTimestamp = Math.floor(log.ts / GROUPING_INTERVAL_MS) * GROUPING_INTERVAL_MS;
            if (!groups.has(groupTimestamp)) {
                groups.set(groupTimestamp, []);
            }
            groups.get(groupTimestamp).push(log);
        }
        groupedLogs.push(...[...groups.values()].sort((a, b) => b[0].ts - a[0].ts));
    }
    const displayedGroups = groupedLogs.slice(0, 25);
    const listForm = new ActionFormData().title('§0§l復元ポイントの選択').body('復元/取り消ししたい操作（グループ）を選択してください。');
    for (const group of displayedGroups) {
        const representative = group[0];
        const timeAgo = formatTimeAgo(Date.now() - representative.ts);
        const actionCounts = group.reduce((acc, log) => {
            let actionType = log.t === 'p' ? '§2設置' : log.c.startsWith('Player') ? '§c破壊(人為)' : '§4破壊(爆発)';
            acc[actionType] = (acc[actionType] || 0) + 1;
            return acc;
        }, {});
        const summary = Object.entries(actionCounts)
            .map(([type, count]) => `${type}: ${count}個`)
            .join(', ');
        listForm.button(`§1約${timeAgo}前 §8(${group.length}ブロック)\n§r${summary}`);
    }
    const listResponse = await listForm.show(player);
    if (listResponse.canceled) return;
    const selectedGroup = displayedGroups[listResponse.selection];
    const representativeLog = selectedGroup[0];
    const timeAgo = formatTimeAgo(Date.now() - representativeLog.ts);
    const finalActionCounts = selectedGroup.reduce((acc, log) => {
        let actionType = log.t === 'p' ? '§2設置の取り消し' : '§a破壊の復元';
        acc[actionType] = (acc[actionType] || 0) + 1;
        return acc;
    }, {});
    const finalSummary = Object.entries(finalActionCounts)
        .map(([type, count]) => `${type}: §b${count}個`)
        .join('\n');
    const confirmForm = new MessageFormData()
        .title('§4§l操作確認')
        .body(`以下の操作を復元/取り消ししますか？\n\n` + `§7イベント: §f約${timeAgo}前§r の操作\n` + `§7対象ブロック数: §b${selectedGroup.length}個\n` + `§7内訳:\n${finalSummary}\n\n` + `§c§lこの操作は元に戻せません！`)
        .button2('§4実行')
        .button1('§1キャンセル');
    const confirmResponse = await confirmForm.show(player);
    if (confirmResponse.canceled || confirmResponse.selection === 0) return;
    restoreOrUndoBlocks(player, selectedGroup);
}

export function RestoreSettingUI(player, backCallback) {
    const form = new ActionFormData().title('§0§l復元設定').body('復元機能に関する設定を行います。').button('§l戻る', 'textures/ui/icon_import.png');
    const isEnabled = world.getDynamicProperty('BlockRestore_system');
    form.button(`§0復元システム\n§r(${isEnabled ? '§1有効' : '§4無効'}§r)`, 'textures/ui/bubble_empty')
        .button('§1データ保存期間の設定', 'textures/ui/bubble_empty')
        .button('§1復元ポイントの間隔設定', 'textures/ui/bubble_empty')
        .button('§4復元データを削除', 'textures/ui/bubble_empty');
    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            if (backCallback) backCallback(player);
            return;
        }
        switch (r.selection) {
            case 1:
                const form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                const isLogSystemEnabled = world.getDynamicProperty('BlockRestore_system');
                form.body(`復元システム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                if (isLogSystemEnabled) {
                    form.button('§4無効化', 'textures/ui/bubble_empty');
                } else {
                    form.button('§9有効化', 'textures/ui/bubble_empty');
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    const selection = r.selection;
                    if (selection === 0) {
                        RestoreSettingUI(player, backCallback);
                        return;
                    }
                    if (isLogSystemEnabled) {
                        world.setDynamicProperty('BlockRestore_system', false);
                    } else {
                        world.setDynamicProperty('BlockRestore_system', true);
                    }

                    RestoreSettingUI(player, backCallback);
                });
                break;
            case 2:
                const periodForm = new ModalFormData().title('§1データ保存期間').textField('何日分の破壊データを保存しますか？\n§e※日数を増やすとワールド容量が増加します。', '日数を入力', { defaultValue: String(world.getDynamicProperty('blockrestore_delete_speed') || '7') });
                periodForm.show(player).then(res => {
                    if (!res.canceled) {
                        const days = parseInt(res.formValues[0], 10);
                        if (!isNaN(days) && days > 0) {
                            world.setDynamicProperty('blockrestore_delete_speed', days);
                            rreload();
                            player.sendMessage(`§r[§bSecurityCraft§r] §a保存期間を§b${days}日§aに設定しました。`);
                        } else {
                            player.sendMessage(`§r[§bSecurityCraft§r] §c無効な日数が入力されました。`);
                        }
                    }
                    RestoreSettingUI(player, backCallback);
                });
                break;
            case 3:
                const currentInterval = world.getDynamicProperty('blockrestore_save_interval') || 10;
                const intervalForm = new ModalFormData().title('§1復元ポイントの間隔').textField('復元UIで、操作ログを何分間隔のグループにまとめますか？\n§e※短いとリストが細かくなり、長いと一度に復元/取消する範囲が大きくなります。', '分数を入力', { defaultValue: String(currentInterval) });
                intervalForm.show(player).then(res => {
                    if (!res.canceled) {
                        const minutes = parseInt(res.formValues[0], 10);
                        if (!isNaN(minutes) && minutes > 0) {
                            world.setDynamicProperty('blockrestore_save_interval', minutes);
                            rreload();
                            player.sendMessage(`§r[§bSecurityCraft§r] §a復元ポイントの間隔を§b${minutes}分§aに設定しました。`);
                        } else {
                            player.sendMessage(`§r[§bSecurityCraft§r] §c無効な分数が入力されました。`);
                        }
                    }
                    RestoreSettingUI(player, backCallback);
                });
                break;
            case 4:
                const confirmForm = new MessageFormData().title('§4§l全データ削除確認').body('§c本当にすべての復元データを削除しますか？\nこの操作は取り消せません。').button2('§4削除する').button1('§1キャンセル');
                confirmForm.show(player).then(res => {
                    if (!res.canceled && res.selection === 1) {
                        clearAllRestoreData();
                        player.sendMessage('§r[§bSecurityCraft§r] §cすべての復元データを削除しました。');
                    }
                    RestoreSettingUI(player, backCallback);
                });
                break;
        }
    });
}

export function clearAllRestoreData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('restore_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
        saveQueue.clear();
        // ★削除キューもクリアする
        deletionQueue.clear();
    } catch (e) {
        console.warn(`[BlockRestore] 全データ削除エラー: ${e}`);
    }
}
