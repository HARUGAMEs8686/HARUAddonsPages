import { world, system } from '@minecraft/server';
import { playerCheckModeStatus } from '../main'; // main.jsからインポートしていると仮定

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // Default to 7 days if not set
let pendingUpdates = new Map();

export function breload() {
    try {
        const storedDays = world.getDynamicProperty('breakblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`Error loading breakblock_delete_days: ${e.message}`);
    }
}

world.afterEvents.worldLoad.subscribe(breload);
breload();

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `break_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    const MAX_SIZE = 30000;

    if (chunkData.size === 0) {
        let part = 1;
        while (world.getDynamicProperty(`${chunkKey}_part${part}`)) {
            world.setDynamicProperty(`${chunkKey}_part${part}`, undefined);
            part++;
        }
        pendingUpdates.delete(chunkKey);
        return;
    }

    const newParts = [];
    let currentPartData = new Map();

    for (const [positionKey, data] of chunkData.entries()) {
        const tempMap = new Map(currentPartData).set(positionKey, data);
        if (JSON.stringify([...tempMap]).length > MAX_SIZE) {
            if (currentPartData.size > 0) {
                newParts.push(JSON.stringify([...currentPartData]));
            }
            currentPartData = new Map([[positionKey, data]]);
        } else {
            currentPartData = tempMap;
        }
    }

    if (currentPartData.size > 0) {
        newParts.push(JSON.stringify([...currentPartData]));
    }

    try {
        for (let i = 0; i < newParts.length; i++) {
            world.setDynamicProperty(`${chunkKey}_part${i + 1}`, newParts[i]);
        }

        let oldPart = newParts.length + 1;
        while (world.getDynamicProperty(`${chunkKey}_part${oldPart}`)) {
            world.setDynamicProperty(`${chunkKey}_part${oldPart}`, undefined);
            oldPart++;
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`[BreakBlock] Error saving chunk data for ${chunkKey}: ${e}`);
    }
}

// [修正点] 古いデータ形式との互換性を持たせるように修正
function getChunkData(chunkKey) {
    const chunkData = new Map();
    let part = 1;
    while (true) {
        const storedData = world.getDynamicProperty(`${chunkKey}_part${part}`);
        if (!storedData) break;

        try {
            // 新しい形式（Mapを配列化したもの）としてパースを試みる
            const parsedPart = new Map(JSON.parse(storedData));
            for (const [key, value] of parsedPart) {
                chunkData.set(key, value);
            }
        } catch (e) {
            // エラーが発生した場合、古い形式（オブジェクト）かもしれないので再試行
            if (e instanceof TypeError) {
                try {
                    const legacyData = JSON.parse(storedData); // オブジェクトとしてパース
                    // オブジェクトの各プロパティをMapに変換する
                    for (const key in legacyData) {
                        if (Object.prototype.hasOwnProperty.call(legacyData, key)) {
                            chunkData.set(key, legacyData[key]);
                        }
                    }
                } catch (e2) {
                    console.warn(`[BreakBlock] Failed to parse both new and legacy data for ${chunkKey}_part${part}: ${e2}`);
                }
            } else {
                console.warn(`[BreakBlock] An unexpected error occurred while parsing ${chunkKey}_part${part}: ${e}`);
            }
        }
        part++;
    }
    return chunkData;
}


function getChunkDataForBlock(x, z) {
    const mergedData = new Map();
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);
        const data = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);
        for (const [pos, value] of data) {
            if (!mergedData.has(pos) || value.t > (mergedData.get(pos)?.t || 0)) {
                mergedData.set(pos, value);
            }
        }
    }
    return mergedData;
}

system.runInterval(() => {
    const updatesToProcess = new Map(pendingUpdates);
    for (const [chunkKey, chunkData] of updatesToProcess) {
        saveChunkData(chunkKey, chunkData);
    }
}, 20);

system.runInterval(() => {
    try {
        const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
        const expirationDay = currentDay - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                const match = key.match(/break_-?\d+_-?\d+_(\d+)_part\d+/);
                if (match && parseInt(match[1], 10) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`Error cleaning old data: ${e.message}`);
    }
}, 1200);

export function clearAllBreakData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
        pendingUpdates.clear();
        console.log("すべての破壊情報をクリアしました。");
    } catch (e) {
        console.warn(`Error clearing break data: ${e.message}`);
    }
}

export function BreakBlock() {
    const lastBreakTime = new Map();

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const isRecordingEnabled = world.getDynamicProperty('BreakBlock_system');
        if (!isRecordingEnabled) {
            return;
        }

        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const now = Date.now();
        const lastBreak = lastBreakTime.get(player.name) || 0;

        if (now - lastBreak < 100) return;
        lastBreakTime.set(player.name, now);

        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);
        
        const chunkData = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);
        
        chunkData.set(positionKey, {
            b: player.name,
            t: now,
            bt: block.typeId.replace('minecraft:', ''),
        });
        
        pendingUpdates.set(chunkKey, chunkData);
    });

    const lastCheckTime = new Map();

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!playerCheckModeStatus || !playerCheckModeStatus[player.name]) return;

            const now = Date.now();
            const lastCheck = lastCheckTime.get(player.name) || 0;
            if (now - lastCheck < 1000) return;
            lastCheckTime.set(player.name, now);

            if (!event.block || !event.block.location) {
                return;
            }

            const nearbyBreaks = getNearbyBreakHistory(event.block.location);

            if (nearbyBreaks.length > 0) {
                displayBreakSummary(player, nearbyBreaks);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurityCraft§r] §eこの周辺に最近の破壊履歴はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }
        });
    });

    function getNearbyBreakHistory(centerPos) {
        const history = [];
        const radius = 7;
        const radiusSq = radius * radius;
        const { x, y, z } = centerPos;

        const minChunkX = Math.floor((x - radius) / CHUNK_SIZE);
        const maxChunkX = Math.floor((x + radius) / CHUNK_SIZE);
        const minChunkZ = Math.floor((z - radius) / CHUNK_SIZE);
        const maxChunkZ = Math.floor((z + radius) / CHUNK_SIZE);

        const checkedChunks = new Set();

        for (let cx = minChunkX; cx <= maxChunkX; cx++) {
            for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
                const chunkId = `${cx},${cz}`;
                if (checkedChunks.has(chunkId)) continue;
                checkedChunks.add(chunkId);

                const chunkData = getChunkDataForBlock(cx * CHUNK_SIZE, cz * CHUNK_SIZE);
                
                for (const [posKey, record] of chunkData.entries()) {
                    const [recX, recY, recZ] = posKey.split(',').map(Number);
                    const distSq = (x - recX) ** 2 + (y - recY) ** 2 + (z - recZ) ** 2;

                    if (distSq <= radiusSq) {
                        history.push({
                            position: `(${recX},${recY},${recZ})`,
                            breaker: record.b,
                            timestamp: record.t,
                            blockType: record.bt,
                        });
                    }
                }
            }
        }
        return history;
    }
    
    function toJST(timestamp) {
        const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
        const date = new Date(timestamp + timeSetting * 60 * 60 * 1000);
        const year = date.getUTCFullYear();
        const month = String(date.getUTCMonth() + 1).padStart(2, '0');
        const day = String(date.getUTCDate()).padStart(2, '0');
        const hours = String(date.getUTCHours()).padStart(2, '0');
        const minutes = String(date.getUTCMinutes()).padStart(2, '0');
        const seconds = String(date.getUTCSeconds()).padStart(2, '0');
        return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
    }

    function displayBreakSummary(player, breaks) {
        if (breaks.length === 0) {
            return;
        }

        const sortedByTime = [...breaks].sort((a, b) => a.timestamp - b.timestamp);
        
        player.sendMessage(`§7[§b破壊概要§r]`);

        const breakCount = new Map();
        const latestBreaks = new Map();

        breaks.forEach(record => {
            breakCount.set(record.breaker, (breakCount.get(record.breaker) || 0) + 1);
            if (!latestBreaks.has(record.breaker) || record.timestamp > latestBreaks.get(record.breaker).timestamp) {
                latestBreaks.set(record.breaker, {
                    timestamp: record.timestamp,
                    position: record.position,
                });
            }
        });

        const sortedBreakers = Array.from(breakCount.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3);

        sortedBreakers.forEach(([breaker, count], index) => {
            const latest = latestBreaks.get(breaker);
            player.sendMessage(`§a#${index + 1} §c${breaker} §e${toJST(latest.timestamp)} §6${latest.position} §b${count}個`);
        });

        player.sendMessage(`§7合計: §f${breaks.length}件 (§f${breakCount.size}人)`);
    }
}