import { world, system } from '@minecraft/server';

//設置
world.afterEvents.playerPlaceBlock.subscribe(event => {
    const player = event.player; 

    // 即座に「1ティックA」タグを付与
    player.addTag('PlaceBlock');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('PlaceBlock')) {
            player.removeTag('PlaceBlock');
        }
    }, 1); // 1ティック待機
});

//破壊
world.afterEvents.playerBreakBlock.subscribe((event) => {
    const player = event.player; 

    // 即座に「1ティックA」タグを付与
    player.addTag('BreakBlock');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('BreakBlock')) {
            player.removeTag('BreakBlock');
        }
    }, 1); // 1ティック待機
});

//ブロック右クリック
world.afterEvents.playerInteractWithBlock.subscribe((event) => {
    const player = event.player; 

    // 即座に「1ティックA」タグを付与
    player.addTag('InteractWithBlock');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('InteractWithBlock')) {
            player.removeTag('InteractWithBlock');
        }
    }, 1); // 1ティック待機
});

//ブロック攻撃
world.afterEvents.entityHitBlock.subscribe((event) => {
    const player = event.damagingEntity; 

    // 即座に「1ティックA」タグを付与
    player.addTag('HitBlock');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('HitBlock')) {
            player.removeTag('HitBlock');
        }
    }, 1); // 1ティック待機
});

world.afterEvents.playerInteractWithEntity.subscribe((event) => {
    const player = event.player; 

    // 即座に「1ティックA」タグを付与
    player.addTag('InteractWithEntity');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('InteractWithEntity')) {
            player.removeTag('InteractWithEntity');
        }
    }, 1); // 1ティック待機
})

world.afterEvents.itemUse.subscribe((event) => {
    const player = event.source; 

    // 即座に「1ティックA」タグを付与
    player.addTag('itemUse');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('itemUse')) {
            player.removeTag('itemUse');
        }
    }, 1); // 1ティック待機
})

world.afterEvents.entityDie.subscribe((event) => {
    const playerA = event.damageSource.damagingEntity; 
    const playerB = event.deadEntity; 
    // 即座に「1ティックA」タグを付与
    playerA.addTag('entityDieA');
    playerB.addTag('entityDieB');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (playerA.hasTag('entityDieA')) {
            playerA.removeTag('entityDieA');
        }
        if (playerB.hasTag('entityDieB')) {
            playerB.removeTag('entityDieB');
        }
    }, 1); // 1ティック待機
})

world.afterEvents.entityHurt.subscribe((event) => {
    const player = event.damageSource.damagingEntity;
    // 即座に「1ティックA」タグを付与
    player.addTag('entityHurt');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('entityHurt')) {
            player.removeTag('entityHurt');
        }
    }, 1); // 1ティック待機
})

world.afterEvents.entityHitEntity.subscribe((event) => {
    const player = event.hitEntity;
    // 即座に「1ティックA」タグを付与
    player.addTag('entityHitEntity');

    // 1ティック後にタグを削除
    system.runTimeout(() => {
        if (player.hasTag('entityHitEntity')) {
            player.removeTag('entityHitEntity');
        }
    }, 1); // 1ティック待機
})
