export const config = {
    "main" : [
        //スマホ名
        '§1HARUPhone1'
    ],
    "AppName" : [
        //アプリ表示名
        '広告',
        'HARUPAY',
        'Quick',
        'メール',
        'オープンチャット',
        '仕事依頼・探す',
        'Advance',
        '換金',
        '購入',
        '情報',
        'ブラウザ',
        '国システム',
        '請求',
        'Operator Controller',
        'HARUAssistant',
        '外部アプリケーション',
        'HARU-X Editor\n§0BETA',
        '外部システム'
    ],
    "AppData" : [
        '未設定',
        '広告',
        '外部アプリケーション',
        'HARUPAY',
        'Quick',
        'メール',
        'オープンチャット',
        '仕事依頼・探す',
        'Advance',
        '換金',
        '購入',
        '情報',
        'ブラウザ',
        '国',
        '請求',
        'HARUAssistant',
        'Special Development',
        'Operator Controller'
    ]
}