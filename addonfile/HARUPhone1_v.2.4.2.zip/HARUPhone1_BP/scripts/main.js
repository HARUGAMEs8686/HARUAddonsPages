import { world, system } from "@minecraft/server";

//アイテム実行
import { HARUPhone1 } from "./itemrun/haruphone1.js"
import { Advance } from "./itemrun/advance.js"

//ブロック実行
import { Game } from "./blockrun/game.js"
import { Atm } from "./blockrun/atm.js"
import { Register } from "./blockrun/register.js"

//常時実行
import { systemrun } from "./systemrun.js"

//ダメージ発生時実行
import { entityPOINT } from "./EntityPOINT.js"

//ブロック
world.beforeEvents.playerInteractWithBlock.subscribe((eventData) =>{
    if(eventData.block.typeId === "addblock:game") {
        Game(eventData)
    }
    
    if(eventData.block.typeId === "addblock:register") {
        Register(eventData)
    }

    if(eventData.block.typeId === "addblock:atm") {
        Atm(eventData)
    }
}) 

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    if (eventData.itemStack.typeId === "additem:haruphone1"){
        HARUPhone1(player)
    }
    if (eventData.itemStack.typeId === "additem:advance"){
        Advance(player)
    }
})

//ダメージ
world.afterEvents.entityHurt.subscribe((event) => {
    entityPOINT(event)
})

//常時
system.runInterval(() => {
    systemrun();
})

//初期設定 >>>
 //UI設定
const HARUPhone1_AppNumber = [1,3,4,5,6,7,8,9,10,12,14,11,17]
 //キルカウントシステム
   const kill_id = ['killcount_zombie','killcount_skeleton','killcount_spider','killcount_creeper','killcount_enderman','killcount_warden','killcount_phantom']
   const kill_id_2 = ['killpoint_zombie','killpoint_skeleton','killpoint_spider','killpoint_creeper','killpoint_enderman','killpoint_warden','killpoint_phantom']
   for (let i = 0; i < kill_id.length; i++){
       if(world.getDynamicProperty(`${kill_id[i]}`)==undefined){
          world.setDynamicProperty(`${kill_id[i]}`,0)
       }
       if(world.getDynamicProperty(`${kill_id_2[i]}`)==undefined){
          world.setDynamicProperty(`${kill_id_2[i]}`,0)
       }
    }
 //HARUPAY
    if(world.getDynamicProperty('harupay_op_money')==undefined){
       world.setDynamicProperty('harupay_op_money',0)
    }
    if(world.getDynamicProperty('MoneyList_allow')==undefined){
        world.setDynamicProperty('MoneyList_allow',true)
    }
 //QuickSAVE
 if(world.getDynamicProperty('Quick_DataSAVE')==undefined){
    world.setDynamicProperty('Quick_DataSAVE',false)
 }
 //Quick初期化
  if(world.getDynamicProperty('Quick_DataSAVE') == false){
    world.setDynamicProperty("shop_menu",undefined);
  }
 //AppNumber
 if(world.getDynamicProperty('HARUPhone1_AppNumber')==undefined){
   world.setDynamicProperty('HARUPhone1_AppNumber',JSON.stringify(HARUPhone1_AppNumber)) 
 }
 //MoneyItems
 if(world.getDynamicProperty('MoneyItems_score')==undefined){
    const MoneyItems_score = [0,0,0,0,0,0,0,0]
    world.setDynamicProperty('MoneyItems_score',JSON.stringify(MoneyItems_score)) 
  }
 //browser初期マネー
 if(world.getDynamicProperty('browser_newpage_money')==undefined){
    world.setDynamicProperty('browser_newpage_money',0)
  }
 if(world.getDynamicProperty('browser_performance_money')==undefined){
    world.setDynamicProperty('browser_performance_money',0)
  }
 //国システム関連
 if(world.getDynamicProperty('DANGEROUS_ITEMS') == undefined){
    const DANGEROUS_ITEMS = [
        "additem:haruphone1",
        "additem:advance"
    ]
    world.setDynamicProperty('DANGEROUS_ITEMS',JSON.stringify(DANGEROUS_ITEMS));
 }

 if(world.getDynamicProperty('WorldspaceNAME') == undefined){
    world.setDynamicProperty('WorldspaceNAME','無主の地')
 }

 const UNOWNED_LAND_INTERACTION = "unowned_land_interaction";
 if(world.getDynamicProperty(UNOWNED_LAND_INTERACTION) == undefined){
    world.setDynamicProperty(UNOWNED_LAND_INTERACTION,true)
 }
 const MONEY_OBJECTIVE = "money";
 const CHUNK_PRICE_PROPERTY = "chunk_price";
 const SYSTEM_ENABLED_PROPERTY = "nation_system_enabled";
 const NATION_CREATION_COST_PROPERTY = "nation_creation_cost";
 const ALLOW_MULTIPLE_NATIONS_PROPERTY = "allow_multiple_nations";
    if (!world.scoreboard.getObjective(MONEY_OBJECTIVE)) {
        world.scoreboard.addObjective(MONEY_OBJECTIVE, "Money");
    }
    if (!world.getDynamicProperty(CHUNK_PRICE_PROPERTY)) {
        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, 100);
    }
    if (!world.getDynamicProperty(NATION_CREATION_COST_PROPERTY)) {
        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, 500);
    }
    if (world.getDynamicProperty(SYSTEM_ENABLED_PROPERTY) === undefined) {
        world.setDynamicProperty(SYSTEM_ENABLED_PROPERTY, false);
    }
    if (world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === undefined) {
        world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, false);
    }

 //GAME関連
if(world.getDynamicProperty('MULTIPLIER')==undefined){
    world.setDynamicProperty('MULTIPLIER',1)
}
if(world.getDynamicProperty('TOTAL_LETTERS')==undefined){
    world.setDynamicProperty('TOTAL_LETTERS',4)
}
if(world.getDynamicProperty('WINNING_COUNT')==undefined){
    world.setDynamicProperty('WINNING_COUNT',1)
}
if(world.getDynamicProperty('BET_AMOUNTS')==undefined){
    world.setDynamicProperty('BET_AMOUNTS','10,100,1000')
}

//<<<

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe((eventData) => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if(eventData.id === "killcount:off") {
            world.setDynamicProperty('killPointSystem',false) 
        }
        if(eventData.id === "killcount:on") {
            world.setDynamicProperty('killPointSystem',true) 
        }
        if(eventData.id === "ui:reset") {
            world.setDynamicProperty('HARUPhone1_AppNumber',JSON.stringify(HARUPhone1_AppNumber)) 
            player.sendMessage(`§r[§bシステム§r] §aUIをリセットしました`);
            player.playSound("random.toast", {
                pitch: 1.6,
                volume: 1.0
            });
            HARUPhone1(player)
        }
    })
})

//自動販売機
import { registerShopInteractions } from "./blockrun/penjualan.js"
registerShopInteractions();