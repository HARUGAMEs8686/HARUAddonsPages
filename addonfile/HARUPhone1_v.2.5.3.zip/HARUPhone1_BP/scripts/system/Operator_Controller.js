import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";

import { config } from "../config"
import { player_Cash_Data,Claim,quest,logs,HARUPhone1,loadShopMenu,saveShopMenu } from "../itemrun/haruphone1"
import { adminSettings } from "../system/country"
import { openNavigationForm } from "./Map"
//メニュー ----
export function Operator_Controller(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§5Operator Controller\n§e--------------\n`);
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§1ログ",`textures/ui/normalicon1`);
    form.button("§5データ編集",`textures/ui/normalicon1`);
    form.button("§2データ権限削除",`textures/ui/normalicon1`);
    form.button("§4トラブルシューティング",`textures/ui/normalicon1`);
    form.button("§1機能利用金額のカスタマイズ",`textures/ui/normalicon1`);
    form.button("§3その他",`textures/ui/normalicon1`);
    form.button("§9社会システム設定",`textures/ui/country`);
    form.button("§1HARUPAY §1[§cOP版§1]",`textures/ui/pay`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                HARUPhone1(player);
            break;
            case 1:
                Log(player);
            break;
            case 2:
                Data_Editing(player);
            break;
            case 3:
                Delete_Data(player);
            break;
            case 4:
                troubleshooting(player);
            break;
            case 5:
                Functionality_feeEdit(player);
            break;
            case 6:
                others(player);
            break;
            case 7:
                adminSettings(player);
            break;
            case 8:
                OPHARUPAY(player);
            break;
        }
    })   
}

function OPHARUPAY(player){
    //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, "0");
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
            var time = `${hours}:${minutes}`
        // 管理者マネーの取得
    let adminMoney = world.getDynamicProperty('harupay_op_money') || 0;

    // プレイヤーのマネー取得
    let score = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);

    // 管理者用HARUPAY画面
    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${score}\n§r§4 >>>§c管理者マネー§r:§s${adminMoney}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button("§9送る");
    form.button("§5マネー受け取り設定", 'textures/ui/icon_setting.png');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;

        switch (response) {
            case 0:
                // 戻る
                Operator_Controller(player);
                break;

            case 1:
                // 送金処理
                player_Cash_Data[player.id].players = world.getAllPlayers();
                let sendForm = new ActionFormData();
                sendForm.title(`${config['main'][0]}`);
                sendForm.body(`§b§l${time}\n\n§r§5 >>>§r送り先のプレイヤーを選択`);
                sendForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    sendForm.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                }
                sendForm.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        OPHARUPAY(player);
                        return;
                    }

                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection - 1];

                    let amountForm = new ModalFormData();
                    amountForm.title(`${config['main'][0]}`);
                    amountForm.textField(`§b§l${time}\n\n§r§b送金額§r(半角数字)`, "0");
                    amountForm.show(player).then(r => {
                        if (r.canceled) return;
                        if (isNaN(r.formValues[0])) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`);
                            player.playSound("random.toast", { pitch: 0.4, volume: 1.0 });
                            return;
                        }
                        if (r.formValues[0] > 100000000) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                            player.playSound("random.toast", { pitch: 0.4, volume: 1.0 });
                            return;
                        }
                        if (r.formValues[0] < 0) {
                            player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`);
                            player.playSound("random.toast", { pitch: 0.4, volume: 1.0 });
                            return;
                        }

                        player_Cash_Data[player.id].select_money = r.formValues[0] == '' ? 0 : Number(r.formValues[0]);
                        adminMoney = world.getDynamicProperty('harupay_op_money') || 0;

                        let confirmForm = new ActionFormData();
                        confirmForm.title(`${config['main'][0]}`);
                        confirmForm.body(`§b§l${time}§r\n\n§a送信先プレイヤー§r:§b${player_Cash_Data[player.id].select_player.name} \n§e送金額§r:§b${player_Cash_Data[player.id].select_money}\n\n§1///////////////////\n§r処理後管理者マネー残高\n§5>>>§u${adminMoney}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${adminMoney - player_Cash_Data[player.id].select_money}\n§1///////////////////`);
                        confirmForm.button(`§s送金`);
                        confirmForm.button(`§0キャンセル`);
                        confirmForm.show(player).then(r => {
                            if (r.canceled) return;
                            if (r.selection == 0) {
                                adminMoney = world.getDynamicProperty('harupay_op_money') || 0;
                                if (adminMoney >= player_Cash_Data[player.id].select_money) {
                                    // 管理者マネーから送金
                                    world.setDynamicProperty('harupay_op_money', adminMoney - player_Cash_Data[player.id].select_money);
                                    player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`);

                                    // メッセージ（送信者名を「管理者」に）
                                    player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§rへ§b${player_Cash_Data[player.id].select_money}§rPAY送信されました`);
                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a管理者§rから§b${player_Cash_Data[player.id].select_money}§rPAY受け取りました`);

                                    // 通知音
                                    player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
                                    player_Cash_Data[player.id].select_player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });

                                    // ログ（送信者名を「管理者」に）
                                    logs['harupay'].push([time, "管理者", player_Cash_Data[player.id].select_player.name, player_Cash_Data[player.id].select_money]);
                                } else {
                                    player.sendMessage(`§r[§bHARUPAY§r] §4管理者マネーが不足しています`);
                                    player.playSound("random.toast", { pitch: 0.4, volume: 1.0 });
                                }
                            }else{
                                OPHARUPAY(player);
                            }
                        });
                    });
                });
                break;
            case 2:
                 let settings = world.getDynamicProperty('harupay_op_settings');
                     settings = JSON.parse(settings);
                  let form = new ModalFormData();
                  form.title(`${config['main'][0]}`);
                  form.toggle("§aブラウザ", settings.browser);
                  form.toggle("§a社会システム", settings.socialSystem);

                  form.show(player).then(r => {
                     if (r.canceled) return;

                   let newSettings = {
                     browser: r.formValues[0],
                     socialSystem: r.formValues[1]
                    };

                       world.setDynamicProperty('harupay_op_settings', JSON.stringify(newSettings));
                       player.sendMessage(`§r[§bHARUPAY§r] §a設定を更新しました`);
                       player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });
                    });
                break;
        }
    });
}

//ログ ----
export function Log(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§r確認する§aログ§rを§e選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§9HARUPAY",'textures/ui/pay');
    form.button("§1Quick",'textures/ui/quick');
    form.button("§2仕事依頼",'textures/ui/work');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player)
            break;
            case 1:
                HARUPAY_Log(player);
            break;
            case 2:
                Quick_Log(player);
            break;
            case 3:
                Quest_Log(player);
            break;
        }
    })
}

export function HARUPAY_Log(player){
    var  logs_list = '';
    for (let i = 0; i < logs['harupay'].length; i++){
       logs_list = logs_list+`§s${logs['harupay'][i][0]} §a${logs['harupay'][i][1]}§rから§a${logs['harupay'][i][2]}§rへ§e${logs['harupay'][i][3]}§r送信\n`
    }
    
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§lHARUPAY-LOG§r\n${logs_list}`);
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
            break;
        }
    })
}

export function Quick_Log(player){
    var  logs_list = '';
    for (let i = 0; i < logs['quick'].length; i++){
       logs_list = logs_list+`§s${logs['quick'][i][0]} §a${logs['quick'][i][1]}§rから§a${logs['quick'][i][2]}§rへ§e${logs['quick'][i][3]}§r送信\n`
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§lQuick-LOG§r\n${logs_list}`);
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
            break;
        }
    })
}

export function Quest_Log(player){
    var  logs_list = '';
    for (let i = 0; i < logs['quest'].length; i++){
       logs_list = logs_list+`§s${logs['quest'][i][0]} §a${logs['quest'][i][1]}§rが§a${logs['quest'][i][3]}§rを受けた §a募集者§r:§e${logs['quest'][i][2]}\n`
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l仕事依頼-LOG§r\n${logs_list}`);
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
            break;
        }
    })
}

//データ編集
export function Data_Editing(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("データ編集する項目を選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§4換金データ\n§1追加§r/§0編集§r/§5削除",'textures/ui/redeem');
    form.button("§9購入データ\n§1追加§r/§0編集§r/§5削除",'textures/ui/purchase');
    form.button("§1Coin§r-§5Bill §2金額\n§0編集",'textures/items/money/coinA');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
            break;
            case 1:
                Exchange_dataEdit(player);
            break;
            case 2:
                Purchase_dataEdit(player);
            break;
            case 3:
                Money_item_amountEdit(player);
            break;
        }
    })
}

export function Exchange_dataEdit(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§5>>>§a換金データ\n\n§e-機能を選択-");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§1追加");
    form.button("§0編集");
    form.button("§5削除");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Data_Editing(player);
            break;
            case 1:
                var form = new ModalFormData();
                form.textField("アイテム名", "ダイアモンド")
                form.textField("アイテム換金金額", "0") 
                form.textField("アイテムID", "diamond")
                form.textField("アイコンパス(任意)", "items/diamond")
                form.show(player).then(r => {
                    if (r.canceled) return;
                    var kannkin_information = world.getDynamicProperty('kannkin_information')
                    if(kannkin_information==undefined){
                        var kannkin_information_system2=[]
                    }else{
                    var kannkin_information_system2 = JSON.parse(kannkin_information);
                    }
                    kannkin_information_system2.push([r.formValues[0],r.formValues[1],r.formValues[2],r.formValues[3]])
                    const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                    world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a追加しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    var kannkin_log = world.getDynamicProperty('kannkin_log')
                    if(kannkin_log==undefined){
                        var kannkin_log_system2=[]
                    }else{
                    var kannkin_log_system2 = JSON.parse(kannkin_log);
                    }
                    kannkin_log_system2.push(0)
                    const kannkin_log_system3 = JSON.stringify(kannkin_log_system2);
                    world.setDynamicProperty('kannkin_log',kannkin_log_system3)
                    Exchange_dataEdit(player)
                })
            break;
            case 2:
                var kannkin_information = world.getDynamicProperty('kannkin_information')
                    if(kannkin_information==undefined){
                        var kannkin_information_system2=[]
                    }else{
                    var kannkin_information_system2 = JSON.parse(kannkin_information);
                    }
                    if(kannkin_information_system2[0]==undefined){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a編集できるアイテムがありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        Exchange_dataEdit(player);
                        return;
                    }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("編集する換金アイテム/ブロックを選択");
                form.button(`§l戻る`,'textures/ui/icon_import.png');
                for (let i = 0; i < kannkin_information_system2.length; i++){
                    if((kannkin_information_system2[i][3]==undefined)||(kannkin_information_system2[i][3]=='')||(kannkin_information_system2[i][3]=='delete')){
                        form.button(`§1${kannkin_information_system2[i][0]} §51個§0:§s${kannkin_information_system2[i][1]}§r`,`textures/ui/normalicon1`);
                     }else{
                        form.button(`§1${kannkin_information_system2[i][0]} §51個§0:§s${kannkin_information_system2[i][1]}§r`,`textures/${kannkin_information_system2[i][3]}`);
                     }
                 }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if(r.selection == 0){
                        Exchange_dataEdit(player);
                        return;
                    }
                    let response = r.selection-1;
                    var form = new ModalFormData();
                    form.textField("アイテム名", `${kannkin_information_system2[response][0]}`)
                    form.textField("アイテム金額", `${kannkin_information_system2[response][1]}`) 
                    form.textField("アイテムID", `${kannkin_information_system2[response][2]}`)
                    form.textField("アイコンパス(任意)", `${kannkin_information_system2[response][3]}`) 
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        if(r.formValues[0]!=''){kannkin_information_system2[response][0]=r.formValues[0]}
                        if(r.formValues[1]!=''){kannkin_information_system2[response][1]=r.formValues[1]}
                        if(r.formValues[2]!=''){kannkin_information_system2[response][2]=r.formValues[2]}
                        if(r.formValues[3]!=''){kannkin_information_system2[response][3]=r.formValues[3]}
                        const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                        world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a編集しました"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        Exchange_dataEdit(player)
                    })
                })
            break;
            case 3:
                var kannkin_information = world.getDynamicProperty('kannkin_information')
                    if(kannkin_information==undefined){
                        var kannkin_information_system2=[]
                    }else{
                    var kannkin_information_system2 = JSON.parse(kannkin_information);
                    }
                    if(kannkin_information_system2[0]==undefined){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a削除できるアイテムがありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        Exchange_dataEdit(player);
                        return;
                    }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("削除する換金アイテム/ブロックを選択");
                form.button(`§l戻る`,'textures/ui/icon_import.png');
                for (let i = 0; i < kannkin_information_system2.length; i++){
                    if((kannkin_information_system2[i][3]==undefined)||(kannkin_information_system2[i][3]=='')||(kannkin_information_system2[i][3]=='delete')){
                        form.button(`§1${kannkin_information_system2[i][0]} §51個§0:§s${kannkin_information_system2[i][1]}§r`,`textures/ui/normalicon1`);
                     }else{
                        form.button(`§1${kannkin_information_system2[i][0]} §51個§0:§s${kannkin_information_system2[i][1]}§r`,`textures/${kannkin_information_system2[i][3]}`);
                     }
                 }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if(r.selection == 0){
                        Exchange_dataEdit(player);
                        return;
                    }
                    let response = r.selection-1;
                    kannkin_information_system2.splice( response, 1 );
                    if(kannkin_information_system2==[]){
                        kannkin_information_system2=undefined
                    }
                    const kannkin_information_system3 = JSON.stringify(kannkin_information_system2);
                    world.setDynamicProperty('kannkin_information',kannkin_information_system3)
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(換金)§r] §a削除しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    var kannkin_log = world.getDynamicProperty('kannkin_log')
                    if(kannkin_log==undefined){
                        var kannkin_log_system2=[]
                    }else{
                    var kannkin_log_system2 = JSON.parse(kannkin_log);
                    }
                    kannkin_log_system2.splice( response, 1 );
                    const kannkin_log_system3 = JSON.stringify(kannkin_log_system2);
                    world.setDynamicProperty('kannkin_log',kannkin_log_system3)
                    Exchange_dataEdit(player)
                })
            break;
        }
    })          
}
export function Purchase_dataEdit(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§5>>>§a購入データ\n\n§e-機能を選択-");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§1追加");
    form.button("§0編集");
    form.button("§5削除");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Data_Editing(player);
            break;
            case 1:
                var form = new ModalFormData();
                form.textField("アイテム名", "ダイアモンド")
                form.textField("アイテム金額", "0") 
                form.textField("アイテムID", "diamond")
                form.textField("アイコンパス(任意)", "items/diamond")
                form.show(player).then(r => {
                    if (r.canceled) return;
                    var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                    if(kounyuu_list==undefined){
                        var kounyuu_list_system2=[]
                    }else{
                    var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                    }
                    kounyuu_list_system2.push([r.formValues[0],r.formValues[1],r.formValues[2],r.formValues[3]])
                    const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                    world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a追加しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    var kounyuu_log = world.getDynamicProperty('kounyuu_log')
                    if(kounyuu_log==undefined){
                        var kounyuu_log_system2=[]
                    }else{
                    var kounyuu_log_system2 = JSON.parse(kounyuu_log);
                    }
                    kounyuu_log_system2.push(0)
                    const kounyuu_log_system3 = JSON.stringify(kounyuu_log_system2);
                    world.setDynamicProperty('kounyuu_log',kounyuu_log_system3)
                    Purchase_dataEdit(player);
                })
            break;
            case 2:
                var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                    if(kounyuu_list==undefined){
                        var kounyuu_list_system2=[]
                    }else{
                    var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                    }
                    if(kounyuu_list_system2[0]==undefined){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a編集できるアイテムがありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        Purchase_dataEdit(player);
                        return;
                    }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("編集するアイテム/ブロックを選択");
                form.button(`§l戻る`,'textures/ui/icon_import.png');
                for (let i = 0; i < kounyuu_list_system2.length; i++){
                    if((kounyuu_list_system2[i][3]==undefined)||(kounyuu_list_system2[i][3]=='')||(kounyuu_list_system2[i][3]=='delete')){
                        form.button(`§1${kounyuu_list_system2[i][0]} §51個§0:§s${kounyuu_list_system2[i][1]}§r`,`textures/ui/normalicon1`);
                     }else{
                        form.button(`§1${kounyuu_list_system2[i][0]} §51個§0:§s${kounyuu_list_system2[i][1]}§r`,`textures/${kounyuu_list_system2[i][3]}`);
                     }
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if(r.selection == 0){
                        Purchase_dataEdit(player);
                        return;
                    }
                    let response = r.selection-1;
                    var form = new ModalFormData();
                    form.textField("アイテム名", `${kounyuu_list_system2[response][0]}`)
                    form.textField("アイテム金額", `${kounyuu_list_system2[response][1]}`) 
                    form.textField("アイテムID", `${kounyuu_list_system2[response][2]}`)
                    form.textField("アイコンパス(任意)", `${kounyuu_list_system2[response][3]}`)
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        if(r.formValues[0]!=''){kounyuu_list_system2[response][0]=r.formValues[0]}
                        if(r.formValues[1]!=''){kounyuu_list_system2[response][1]=r.formValues[1]}
                        if(r.formValues[2]!=''){kounyuu_list_system2[response][2]=r.formValues[2]}
                        if(r.formValues[3]!=''){kounyuu_list_system2[response][3]=r.formValues[3]}
                        const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                        world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a編集しました"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        Purchase_dataEdit(player);
                    })
                })
            break;
            case 3:
                var kounyuu_list = world.getDynamicProperty('kounyuu_list')
                    if(kounyuu_list==undefined){
                        var kounyuu_list_system2=[]
                    }else{
                    var kounyuu_list_system2 = JSON.parse(kounyuu_list);
                    }
                    if(kounyuu_list_system2[0]==undefined){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a削除できるアイテムがありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        Purchase_dataEdit(player);
                        return;
                    }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("削除するアイテム/ブロックを選択");
                form.button(`§l戻る`,'textures/ui/icon_import.png');
                for (let i = 0; i < kounyuu_list_system2.length; i++){
                   if((kounyuu_list_system2[i][3]==undefined)||(kounyuu_list_system2[i][3]=='')||(kounyuu_list_system2[i][3]=='delete')){
                       form.button(`§1${kounyuu_list_system2[i][0]} §51個§0:§s${kounyuu_list_system2[i][1]}§r`,`textures/ui/normalicon1`);
                    }else{
                       form.button(`§1${kounyuu_list_system2[i][0]} §51個§0:§s${kounyuu_list_system2[i][1]}§r`,`textures/${kounyuu_list_system2[i][3]}`);
                    }
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if(r.selection == 0){
                        Purchase_dataEdit(player);
                        return;
                    }
                    let response = r.selection-1;
                    kounyuu_list_system2.splice( response, 1 );
                    if(kounyuu_list_system2==[]){
                        kounyuu_list_system2=undefined
                    }
                    const kounyuu_list_system3 = JSON.stringify(kounyuu_list_system2);
                    world.setDynamicProperty('kounyuu_list',kounyuu_list_system3)
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(購入)§r] §a削除しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    Purchase_dataEdit(player);
                })
            break;
        }
    })        
}

export function Money_item_amountEdit(player){
    const MoneyItems_NameID = ['§5>>>§b各アイテムの金額を設定してください\n§c[半角数字]§r\ncoinA','coinB','coinC','coinD','coinE','billA','billB','billC'] 
    var MoneyItems_score = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
    var form = new ModalFormData();
    for (let i = 0; i < MoneyItems_score.length; i++){
       form.textField(`${MoneyItems_NameID[i]}`, `${MoneyItems_score[i]}`)
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        for (let i = 0; i < MoneyItems_score.length; i++){
          if(r.formValues[i]!=''){
            MoneyItems_score[i] = Number(r.formValues[i])
          }
        }
        world.setDynamicProperty('MoneyItems_score',JSON.stringify(MoneyItems_score))
        player.sendMessage(`§r[§b設定§r] §a金額を編集しました`);
        player.playSound("random.toast", {
            pitch: 1.7,
            volume: 1.0
        });
        Data_Editing(player);
    })
}

//データ権限削除----
export function Delete_Data(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§5削除操作§rをする機能を§e選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§0Quickデータ\n§1選択§5>>>§4削除",'textures/ui/quick');
    form.button("§2仕事依頼データ\n§1選択§5>>>§4削除",'textures/ui/work');
    form.button("§5ブラウザページ\n§1選択§5>>>§4削除",'textures/ui/browser');
    form.button("§1広告データ\n§1選択§5>>>§4削除",'textures/ui/browser');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
            break;
            case 1:
                Quick_Data_Deletion(player);
            break;
            case 2:
                Quest_Data_Deletion(player);
            break;
            case 3:
                Delete_browser_page(player);
            break;
            case 4:
                Delete_browser_ad(player);
            break;
        }
    })
}

export function Quick_Data_Deletion(player){
     // shop_menu をグローバル変数として初期化
       var shop_menu = loadShopMenu();
      // 商品削除処理
        if (shop_menu[0].length == 0) {
          player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
          player.playSound("random.toast", {
              pitch: 0.4,
              volume: 1.0
          });
          Delete_Data(player);
          return;
        }

    player_Cash_Data[player.id].my_shop = [];
    var form = new ActionFormData();
      form.title(`${config['main'][0]}`);
      form.body("削除する商品を選択");
      for (let i = 0; i < shop_menu[0].length; i++) {
              form.button(`§l${shop_menu[0][i][0]}\n§r額:§b${shop_menu[0][i][2]}§rPAY  出品者:§2${shop_menu[0][i][1]}`);
              player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
      }

      if (player_Cash_Data[player.id].my_shop.length == 0) { 
          player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
          player.playSound("random.toast", {
              pitch: 0.4,
              volume: 1.0
          });
          Delete_Data(player);
          return;
      }

     form.show(player).then(r => {
         if (r.canceled) {
             return;
         }
         for (let i = 0; i < shop_menu[0].length; i++) {
             if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection][5]) {
                 shop_menu[0].splice(i, 1);
                 break; 
             }
         }
         player.sendMessage(`§r[§bQuick§r] §a削除しました`);
         player.playSound("random.toast", {
             pitch: 1.7,
             volume: 1.0
         });
        saveShopMenu(shop_menu); // データ保存
        Delete_Data(player);
    }).catch(e => {
        console.error(e, e.stack);
    });                                               
}

export function Quest_Data_Deletion(player){
    if(quest[0][0]==undefined){
        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aデータがありません"}]}`) 
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
        Delete_Data(player);
      return
    }

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("shop_menuデータ");
    for (let i = 0; i < quest[0].length; i++){
        form.button(`§l${quest[0][i][0]}\n§r報酬額:§b${quest[0][i][2]}§rPAY  依頼者:§2${quest[0][i][3]}`);
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §b${quest[0][response][0]}§aを削除しました"}]}`) 
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
        quest[0].splice( response, 1 );
        Delete_Data(player);
    })                                                    
}

export function Delete_browser_page(player){
    var browser = world.getDynamicProperty('browser')
    if(browser==undefined){
        var browser_system2=[]
    }else{
    var browser_system2 = JSON.parse(browser);
    }
    if(browser_system2[0]==undefined){
        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できるページがありません"}]}`)
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
        Delete_Data(player);
        return;
    }
   var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("削除するページを選択");
   for (let i = 0; i < browser_system2.length; i++){
       form.button(`§l${browser_system2[i][2]}\n§r${browser_system2[i][3]}`);
   }
   form.show(player).then(r => {
       if (r.canceled) return;
       let response = r.selection;
       browser_system2.splice( response , 1 );
       const browser_system3 = JSON.stringify(browser_system2);
       world.setDynamicProperty('browser',browser_system3)
       player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページを削除しました"}]}`)
       player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
       Delete_Data(player);
   })
 }

export function Delete_browser_ad(player){
    var browser = world.getDynamicProperty('performance')
    if(browser==undefined){
        var browser_system2=[]
    }else{
    var browser_system2 = JSON.parse(browser);
    }
    if(browser_system2[0]==undefined){
        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a削除できる広告がありません"}]}`)
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
        Delete_Data(player);
        return;
    }
   var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("削除するページを選択");
   for (let i = 0; i < browser_system2.length; i++){
     form.button(`§l${browser_system2[i][2]}\n§r${browser_system2[i][3]}`);
  }
    form.show(player).then(r => {
       if (r.canceled) return;
       let response = r.selection;
       browser_system2.splice( response , 1 );
       const browser_system3 = JSON.stringify(browser_system2);
       world.setDynamicProperty('performance',browser_system3)
       player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告を削除しました"}]}`)
       player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
       Delete_Data(player);
   })
}

//トラブルシューティング----
export function troubleshooting(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("トラブルシューティング機能を選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§1プレイヤーキルカウント\n§4リセット",`textures/ui/normalicon1`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
            break;
            case 1:
                Kill_count_reset(player);
            break;
        }
    })
}

export function Kill_count_reset(player){
    var players = world.getAllPlayers()
    for (let i = 0; i < players.length; i++){
        players[i].setDynamicProperty('skeletoncount',0)
        players[i].setDynamicProperty('zombiecount',0)
        players[i].setDynamicProperty('phantomcount',0)
        players[i].setDynamicProperty('wardencount',0)
        players[i].setDynamicProperty('creepercount',0)
        players[i].setDynamicProperty('spidercount',0)
        players[i].setDynamicProperty('endermancount',0)
    }
    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aプレイヤーキルcountをリセットしました"}]}`) 
    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)  
    troubleshooting(player);  
}

//機能利用金額カスタマイズ----
export function Functionality_feeEdit(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("§aカスタマイズ§rする§e機能を選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§2ブラウザ\n§5ページ投稿§r/§1広告化",'textures/ui/browser');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
            break;
            case 1:
                Browser_usage_fee(player);
            break;
        }
    })

}
export function Browser_usage_fee(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("設定を選択...");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§5ページ投稿金額\n§0編集");
    form.button("§1広告化金額\n§0編集");
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Functionality_feeEdit(player);
            break;
            case 1:
                var form = new ModalFormData();
                form.textField("ページ投稿金額(半角数字)", `${world.getDynamicProperty('browser_newpage_money')}`)
                form.show(player).then(r => {
                    if (r.canceled) return;
                    world.setDynamicProperty('browser_newpage_money',r.formValues[0])
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §aページ投稿金額を設定しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    Browser_usage_fee(player);
                })
            break;
            case 2:
                var form = new ModalFormData();
                form.textField("広告化金額(半角数字)", `${world.getDynamicProperty('browser_performance_money')}`)
                form.show(player).then(r => {
                    if (r.canceled) return;
                    world.setDynamicProperty('browser_performance_money',r.formValues[0])
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r] §a広告化金額を設定しました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    Browser_usage_fee(player);
                })
            break;
        }
    }) 
}

//その他----
export function others(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("設定する項目を選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button(`§4初期金額の再設定\n§0現在:§s${world.getDynamicProperty('start_money')}`,`textures/ui/pay`);
    form.button("§1新規プレイヤー\n§0手動付与",`textures/ui/normalicon1`);
    form.button("§3自動付与システム\n§5有効化§r/§1無効化",`textures/ui/normalicon1`);
    form.button("§4キルカウントシステム",`textures/ui/normalicon1`);
    form.button("§0永久保存\n§5有効化§r/§1無効化",'textures/ui/haruapp');
    form.button("§5UIカスタマイズ",'textures/items/haruphone1');
    form.button("§4残高リスト表示\n§5オフ§r:§1管理者のみ§r/§5オン§5:§1全員",'textures/ui/pay');
    form.button("§1マップ\n§5カスタマイズ",'textures/ui/map');
    form.button("§5時刻設定",`textures/ui/normalicon1`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
            break;
            case 1:
                Initial_amount_reset(player);
            break;
            case 2:
                New_player_grant(player);
            break;
            case 3:
                Automatic_Granting_System(player);
            break;
            case 4:
                Kill_Count_System(player);
            break;
            case 5:
                Data_Keep(player);
            break;
            case 6:
                UI_Customization(player);
            break;
            case 7:
                const currentValue = world.getDynamicProperty('MoneyList_allow') === true;

                new ModalFormData()
                    .title(`${config['main'][0]}`)
                    .toggle("§eMoneyList 機能を有効にする", currentValue)
                    .show(player)
                    .then(res => {
                        if (res.canceled) return;
            
                        const toggleValue = res.formValues[0]; // true or false
                        world.setDynamicProperty('MoneyList_allow', toggleValue);
                        player.sendMessage(`[§b設定§r] §aMoneyList_allow を §b${toggleValue ? "§a有効化§r" : "§c無効化§r"} §aしました`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                    });
            break;
            case 8:
                openNavigationForm(player)
            break;
            case 9:
            //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + 0 * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, "0");
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
            var time = `${hours}:${minutes}`

                const Time_Setting = world.getDynamicProperty('Time_Setting');

                new ModalFormData()
                    .title(`${config['main'][0]}`)
                    .textField(`§b${time} §aからの経過時間を入力してください`, `${Time_Setting}`)
                    .show(player)
                    .then(res => {
                        if (res.canceled) return;

                        const toggleValue = Number(res.formValues[0]);
                        world.setDynamicProperty('Time_Setting', toggleValue);
                        player.sendMessage(`[§b設定§r] §a時刻を設定しました`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                        HARUPhone1(player);
                    });
                break;
        }
    })
}
export function Initial_amount_reset(player){
    world.setDynamicProperty('op_fast', undefined)
    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §aリセットしました§r-§cHARUPhone1§eを開いて再設定してください"}]}`)
    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
}

export function New_player_grant(player){
    var players = world.getAllPlayers()
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("新規プレイヤーにスマホ/Money付与");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    for (let i = 0; i < players.length; i++){
     form.button(`${players[i].name}`)   
    }
    form.show(player).then(r => {
        if(r.selection==0){
            others(player);
            return;
        }
        let response = r.selection-1;
        if (r.canceled) {
            return;
        }
        var partner1 = players[response];
        if(partner1.hasTag('HARUPAY_Member')){
            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §4このPlayerは付与済みです"}]}`) 
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
            New_player_grant(player);
            return;
        }
        partner1.runCommand("give @s additem:haruphone1");
        partner1.runCommand(`scoreboard players set @s money ${world.getDynamicProperty('start_money')}`);
        partner1.runCommand(`scoreboard players set @s account 0`);
        partner1.runCommand("tag @s add HARUPAY_Member")
        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §eこのPlayerに付与しました"}]}`)
        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
        New_player_grant(player);
  })
}

export function Automatic_Granting_System(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("設定を選択...");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§5有効化");
    form.button("§1無効化");
    form.show(player).then(r => {
        if (r.canceled) return;
        if(r.selection==0){
            others(player);
            return;
        }
        let response = r.selection-1;
        switch (response) {
            case 0:
                world.setDynamicProperty('money_start_system2',0)
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                others(player);
            break;
            case 1:
                world.setDynamicProperty('money_start_system2',1)
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                others(player);
            break;
        }
    })
}
//-キルカウント-
export function Kill_Count_System(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("設定を選択...");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§5有効化§0/§1無効化");
    form.button("§4キルカウント§0/§1ポイント\n§0編集");
    form.show(player).then(r => {
        if (r.canceled) return;
        if(r.selection==0){
            others(player);
            return;
         }
        let response = r.selection-1;
        switch (response) {
            case 0:
               var form = new ActionFormData();
               form.title(`${config['main'][0]}`);
               form.body("設定を選択...");
               form.button(`§l戻る`,'textures/ui/icon_import.png');
               form.button("§5有効化");
               form.button("§1無効化");
               form.show(player).then(r => {
                   if (r.canceled) return;
                   if(r.selection==0){
                      Kill_Count_System(player);
                      return;
                   }
                   let response = r.selection-1;
                   switch (response) {
                       case 0:
                           world.setDynamicProperty('killPointSystem',true) 
                           player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                           player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                           Kill_Count_System(player);
                       break;
                       case 1:
                           world.setDynamicProperty('killPointSystem',false) 
                           player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                           player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                           Kill_Count_System(player);
                       break;
                   }
               })
            break;
            case 1:
                Kill_Count_System_edit(player);
            break;
        }
    })
}

export function Kill_Count_System_edit(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("編集するモブを選択");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button("§2ゾンビ");
    form.button("§0スケルトン");
    form.button("§4蜘蛛");
    form.button("§2クリーパー");
    form.button("§0エンダーマン");
    form.button("§sウォーデン");
    form.button("§5ファントム");
    form.show(player).then(r => {
        if (r.canceled) return;
        if(r.selection==0){
            Kill_Count_System(player);
            return;
        }
        let response = r.selection-1;
        const kill_id = ['killcount_zombie','killcount_skeleton','killcount_spider','killcount_creeper','killcount_enderman','killcount_warden','killcount_phantom']
        const kill_id_2 = ['killpoint_zombie','killpoint_skeleton','killpoint_spider','killpoint_creeper','killpoint_enderman','killpoint_warden','killpoint_phantom']
            var form = new ModalFormData();
                form.textField("キルカウント", `${world.getDynamicProperty(kill_id[response])}`)
                form.textField("キルポイント", `${world.getDynamicProperty(kill_id_2[response])}`)
                form.show(player).then(r => {
                if (r.canceled) return;
                 if(isNaN(r.formValues[0])||isNaN(r.formValues[1])){
                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §4半角数字で入力してください"}]}`)
                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                    return;
                }
                 if (r.formValues[0]==''||r.formValues[1]==''){
                     player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §4入力してください"}]}`)
                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                      return;
                 }
                if (r.formValues[0]<0||r.formValues[1]<0){
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §40以下は設定できません"}]}`)
                     player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                    return;
                 }
                world.setDynamicProperty(`${kill_id[response]}`,Number(r.formValues[0]))
                world.setDynamicProperty(`${kill_id_2[response]}`,Number(r.formValues[1]))
                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(システム)§r] §a設定しました"}]}`)
                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                Kill_Count_System_edit(player);
            })
        })
}

export function Data_Keep(player){
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body("設定を選択...");
    form.button(`§l戻る`,'textures/ui/icon_import.png');
    form.button(`§0Quick\n§1現在§5>>>§s${world.getDynamicProperty('Quick_DataSAVE')}`);
    form.show(player).then(r => {
        if (r.canceled) return;
        if(r.selection==0){
            others(player);
            return;
         }
        let response = r.selection-1;
        switch (response) {
            case 0:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body("保存システム");
                form.button(`§l戻る`,'textures/ui/icon_import.png');
                form.button("§5有効化");
                form.button("§1無効化");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if(r.selection==0){
                        Data_Keep(player);
                        return;
                     }
                    let response = r.selection-1;
                    switch (response) {
                        case 0:
                            world.setDynamicProperty('Quick_DataSAVE',true) 
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §5有効化§aにしました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                            Data_Keep(player);
                        break;
                        case 1:
                            world.setDynamicProperty('Quick_DataSAVE',false) 
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(設定)§r] §9無効化§aにしました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                            Data_Keep(player);
                        break;
                    }
                })
            break;
        }
    })
}

export function UI_Customization(player){
    var HARUPhone1_AppNumber = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'))
    var form = new ModalFormData()
      form.title(`${config['main'][0]}`)
      for (let i = 0; i < config['AppData'].length-1; i++){
          form.dropdown(`App${i}`, config['AppData'], HARUPhone1_AppNumber[i]) 
      } 
     // フォームを表示
      form.show(player).then(r => {
      if (r.canceled) return; // フォームがキャンセルされた場合は終了
      HARUPhone1_AppNumber = []
      for (let i = 0; i < config['AppData'].length-1; i++){
        if(r.formValues[i] != 0 && r.formValues[i]!=config['AppData'].length-1){
           HARUPhone1_AppNumber.push(r.formValues[i])
        }
      }
      if(HARUPhone1_AppNumber.includes(config['AppData'].length-1)==false){
        HARUPhone1_AppNumber.push(config['AppData'].length-1)
      }
     world.setDynamicProperty('HARUPhone1_AppNumber',JSON.stringify(HARUPhone1_AppNumber)) 
     player.sendMessage(`§r[§b設定§r] §aUI設定を完了しました`)
     player.playSound("random.toast", {
         pitch: 1.7, 
         volume: 1.0
     });  
     HARUPhone1(player);
    });
}

