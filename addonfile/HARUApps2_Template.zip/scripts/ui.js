import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

// ==========================================
// メインUIロジック
// ==========================================

export function showMainMenu(player) {
    const form = new ActionFormData().title('§1テンプレート').body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1ボタン1', 'textures/ui/bubble_empty');
    form.button('§4ボタン2', 'textures/ui/bubble_empty');

    form.show(player).then(res => {
        if (res.canceled) return;
        let selection = res.selection;

        switch (selection) {
            case 0:
                //HARUPhone1のアプリケーションメニューに戻る
                player.runCommand('scriptevent haruphone1:apps');
                break;
            case 1:
                player.sendMessage('ボタン1が押されました')
                break;
            case 2:
                player.sendMessage('ボタン2が押されました')
                break;
        }
    });
}
