import { world, system } from '@minecraft/server';
import { showMainMenu } from './ui';

//UIの表示に必要なID
//例:camera
const EVENT_ID = 'template';
//メニューに表示したいアプリ名
const Application_NAME = '§0テンプレート';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === `haruapps:${EVENT_ID}`) {
            showMainMenu(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

// HARUPhone1に起動データを送信
system.runTimeout(() => {
    const overworld = world.getDimension('overworld');
    overworld.runCommand(`scriptevent haruapps:push ${Application_NAME} scriptevent haruapps:${EVENT_ID}`);
}, 20);
