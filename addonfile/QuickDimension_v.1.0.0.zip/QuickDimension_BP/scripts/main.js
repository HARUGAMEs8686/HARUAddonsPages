import { world, system, BlockVolume } from '@minecraft/server';
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { MAX_SLOTS } from './config';

// --- 設定・定数 ---
const PREFIX = '[§bQuickDimension§r]';
const PROP_CONFIGS = 'qd:configs';
const PROP_SETTINGS = 'qd:settings';
const PROP_RETURNS = 'qd:returns'; // 追加
const SPAWN_POS = { x: 0, y: -59, z: 0 }; // 初期TP位置

// --- 状態管理用 (Map/Set) ---
const portalCooldowns = new Map(); // ゲートのクールダウン管理 { playerName: timestamp }
const generatedCache = new Set(); // 無限フラットの生成済みチャンク

// (中略... getGlobalSettings 等の関数の下辺りに追加)
function getReturns() {
    const data = world.getDynamicProperty(PROP_RETURNS);
    return data ? JSON.parse(data) : {};
}
function saveReturns(returns) {
    world.setDynamicProperty(PROP_RETURNS, JSON.stringify(returns));
}

// 起動時にディメンション登録
system.beforeEvents.startup.subscribe(e => {
    for (let i = 1; i <= MAX_SLOTS; i++) {
        e.dimensionRegistry.registerCustomDimension(`qd:world_${i}`);
    }
});

// --- データ管理 ---
function getConfigs() {
    const data = world.getDynamicProperty(PROP_CONFIGS);
    return data ? JSON.parse(data) : {};
}
function saveConfigs(configs) {
    world.setDynamicProperty(PROP_CONFIGS, JSON.stringify(configs));
}
function getGlobalSettings() {
    const data = world.getDynamicProperty(PROP_SETTINGS);
    return data ? JSON.parse(data) : { frameBlock: 'minecraft:stone' };
}
function saveGlobalSettings(settings) {
    world.setDynamicProperty(PROP_SETTINGS, JSON.stringify(settings));
}

// --- メインループ (無限生成＆ゲート入場検知) ---
system.runInterval(() => {
    const configs = getConfigs();
    const now = Date.now();

    for (const player of world.getAllPlayers()) {
        const dim = player.dimension;
        const pos = player.location;

        // --- 無限フラット生成 ---
        if (configs[dim.id]?.type === 'flat') {
            const px = Math.floor(pos.x >> 4),
                pz = Math.floor(pos.z >> 4);
            for (let x = px - 1; x <= px + 1; x++) {
                for (let z = pz - 1; z <= pz + 1; z++) {
                    const key = `${dim.id}:${x},${z}`;
                    if (!generatedCache.has(key)) {
                        try {
                            // ▼▼▼ ここから追加 ▼▼▼
                            const x0 = x << 4,
                                z0 = z << 4,
                                x1 = x0 + 15,
                                z1 = z0 + 15;
                            dim.fillBlocks(new BlockVolume({ x: x0, y: -64, z: z0 }, { x: x1, y: -64, z: z1 }), 'minecraft:bedrock');
                            dim.fillBlocks(new BlockVolume({ x: x0, y: -63, z: z0 }, { x: x1, y: -61, z: z1 }), 'minecraft:dirt');
                            dim.fillBlocks(new BlockVolume({ x: x0, y: -60, z: z0 }, { x: x1, y: -60, z: z1 }), 'minecraft:grass_block');
                            generatedCache.add(key);
                        } catch (e) {}
                    }
                }
            }
        }

        // --- ゲートUI表示 / 帰還処理 ---
        const headBlock = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y + 1), z: Math.floor(pos.z) });
        const footBlock = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) });

        if (headBlock?.typeId === 'minecraft:glass_pane' || footBlock?.typeId === 'minecraft:glass_pane') {
            // ガラスの真下がフレームブロックかチェック
            const underBlock = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y) - 1, z: Math.floor(pos.z) });
            const settings = getGlobalSettings();

            if (underBlock?.typeId === settings.frameBlock) {
                const last = portalCooldowns.get(player.name) || 0;
                if (now - last > 3000) {
                    portalCooldowns.set(player.name, now);

                    const returns = getReturns();
                    if (dim.id.startsWith('qd:') && returns[player.name]) {
                        const returnData = returns[player.name];
                        player.teleport(returnData.location, { dimension: world.getDimension(returnData.dimensionId) });
                        delete returns[player.name];
                        saveReturns(returns);
                    } else {
                        showDimensionSelector(player);
                    }
                }
            }
        }
    }
}, 20);

// --- ブロックへのインタラクト（着火）を検知してゲート完成（安定版） ---
world.afterEvents.playerInteractWithBlock.subscribe(e => {
    const { player, block, itemStack } = e;
    if (itemStack?.typeId !== 'minecraft:flint_and_steel') return;

    const settings = getGlobalSettings();
    if (block.typeId !== settings.frameBlock) return;

    const dim = player.dimension;

    const queue = [block.location]; // 探索キュー
    const visited = new Set([`${block.x},${block.y},${block.z}`]); // 訪問済み座標
    const frameBlocks = []; // 見つかったフレームブロックの座標リスト

    while (queue.length > 0) {
        if (frameBlocks.length > 20) {
            break; // 無限ループと無駄な探索を防ぐ
        }
        const currentPos = queue.shift();

        if (dim.getBlock(currentPos)?.typeId === settings.frameBlock) {
            frameBlocks.push(currentPos);
            for (let dx = -1; dx <= 1; dx++) {
                for (let dy = -1; dy <= 1; dy++) {
                    for (let dz = -1; dz <= 1; dz++) {
                        if (dx === 0 && dy === 0 && dz === 0) continue;
                        const nextPos = { x: currentPos.x + dx, y: currentPos.y + dy, z: currentPos.z + dz };
                        const key = `${nextPos.x},${nextPos.y},${nextPos.z}`;
                        if (!visited.has(key)) {
                            visited.add(key);
                            queue.push(nextPos);
                        }
                    }
                }
            }
        }
    }

    if (frameBlocks.length < 10 || frameBlocks.length > 14) {
        return;
    }

    const min = { x: Infinity, y: Infinity, z: Infinity };
    const max = { x: -Infinity, y: -Infinity, z: -Infinity };
    for (const pos of frameBlocks) {
        min.x = Math.min(min.x, pos.x);
        max.x = Math.max(max.x, pos.x);
        min.y = Math.min(min.y, pos.y);
        max.y = Math.max(max.y, pos.y);
        min.z = Math.min(min.z, pos.z);
        max.z = Math.max(max.z, pos.z);
    }

    const widthX = max.x - min.x + 1;
    const height = max.y - min.y + 1;
    const widthZ = max.z - min.z + 1;

    let isValidPortal = false;
    let interiorMin, interiorMax;

    if (widthX === 4 && height === 5 && widthZ === 1) {
        interiorMin = { x: min.x + 1, y: min.y + 1, z: min.z };
        interiorMax = { x: max.x - 1, y: max.y - 1, z: max.z };
        isValidPortal = true;
    } else if (widthX === 1 && height === 5 && widthZ === 4) {
        interiorMin = { x: min.x, y: min.y + 1, z: min.z + 1 };
        interiorMax = { x: max.x, y: max.y - 1, z: max.z - 1 };
        isValidPortal = true;
    }

    if (isValidPortal) {
        for (let y = interiorMin.y; y <= interiorMax.y; y++) {
            for (let x = interiorMin.x; x <= interiorMax.x; x++) {
                for (let z = interiorMin.z; z <= interiorMax.z; z++) {
                    const blockId = dim.getBlock({ x, y, z })?.typeId;
                    if (blockId !== 'minecraft:air' && blockId !== 'minecraft:fire') {
                        return;
                    }
                }
            }
        }

        console.warn(`[Debug] 🎉 すべてのチェックを通過しました！ガラスを生成します！`);
        // 内側を板ガラスで埋める
        dim.fillBlocks(new BlockVolume(interiorMin, interiorMax), 'minecraft:glass_pane');
        player.runCommand(`playsound item.flintandsteel.use @a ${block.x} ${block.y} ${block.z}`);
    }
});

// --- ディメンション移動時の処理 ---
world.afterEvents.playerDimensionChange.subscribe(e => {
    const { player, toDimension: dim } = e;
    const configs = getConfigs();
    const config = configs[dim.id];

    if (!config) return;

    // 初期化がまだなら足場を生成
    if (!config.initialized) {
        if (config.type === 'cobble') {
            dim.fillBlocks(new BlockVolume({ x: -5, y: -60, z: -5 }, { x: 5, y: -60, z: 5 }), 'minecraft:cobblestone');
        } else if (config.type === 'flat') {
            dim.fillBlocks(new BlockVolume({ x: -16, y: -64, z: -16 }, { x: 16, y: -60, z: 16 }), 'minecraft:grass_block');
        }
        config.initialized = true;
        const current = getConfigs();
        current[dim.id] = config;
        saveConfigs(current);
    }

    // スポーン地点へテレポート
    player.teleport(SPAWN_POS, { dimension: dim });
});

// --- UI関連 ---
function showDimensionSelector(player) {
    const configs = getConfigs();
    const form = new ActionFormData().title('§1QuickDimension - ポータル').body('>>> §e移動先を選択してください');
    const validDims = Object.keys(configs).filter(id => configs[id].portalEnabled);
    if (validDims.length === 0) return;

    validDims.forEach(id => form.button(`§0${configs[id].name}`, 'textures/ui/bubble_empty'));

    form.show(player).then(res => {
        if (res.canceled) return;

        // 通常ディメンションから移動する場合、帰還地点を記録
        if (!player.dimension.id.startsWith('qd:')) {
            const returns = getReturns();
            returns[player.name] = {
                location: { x: player.location.x, y: player.location.y, z: player.location.z },
                dimensionId: player.dimension.id,
            };
            saveReturns(returns);
        }

        const targetId = validDims[res.selection];
        player.teleport(SPAWN_POS, { dimension: world.getDimension(targetId) });
    });
}

function showMainMenu(player) {
    new ActionFormData()
        .title('§1QuickDimension §0(BETA)')
        .body('Version:§b1.0.0\n§r>>> §e選択してください')
        .button('§0新規作成', 'textures/ui/color_plus')
        .button('§0ディメンション管理', 'textures/ui/bubble_empty')
        .button('§0ゲート設定', 'textures/ui/gear')
        .show(player)
        .then(res => {
            if (res.selection === 0) showCreateUI(player);
            if (res.selection === 1) showManageUI(player);
            if (res.selection === 2) showGlobalSettingsUI(player);
        });
}

function showCreateUI(player) {
    const configs = getConfigs();
    const usedIds = Object.keys(configs);

    new ModalFormData()
        .title('§1新規作成')
        .textField('>>> §e名前を入力', 'My World')
        .dropdown('>>> §eタイプ', ['無 (Void)', '10x10 丸石', 'スーパーフラット'], {
            defaultValueIndex: 2,
        })
        .toggle('>>> §eゲート移動を許可', {
            defaultValue: true,
        })
        .show(player)
        .then(res => {
            if (res.canceled){
                return showMainMenu(player);
            }

            const settings = getGlobalSettings();
            const lastUsed = settings.lastUsedSlot || 0;

            if (lastUsed >= MAX_SLOTS) {
                return player.sendMessage(`${PREFIX} §cワールドの作成回数が上限（${MAX_SLOTS}回）に達しました`);
            }

            const nextSlotNum = lastUsed + 1;
            const nextSlot = `qd:world_${nextSlotNum}`;
            settings.lastUsedSlot = nextSlotNum;
            saveGlobalSettings(settings);

            configs[nextSlot] = {
                name: res.formValues[0] || 'Unnamed',
                type: ['void', 'cobble', 'flat'][res.formValues[1]],
                portalEnabled: res.formValues[2],
                initialized: false,
            };
            saveConfigs(configs);
            player.sendMessage(`${PREFIX} §a作成完了: ${configs[nextSlot].name}`);
        });
}

function showManageUI(player) {
    const configs = getConfigs();
    const ids = Object.keys(configs);
    const form = new ActionFormData().title('§1ディメンション管理');
    if (ids.length === 0) {
        form.body('>>> §eデータがありません');
    } else {
        form.body('>>> §e選択してください');
        form.button('§l戻る', 'textures/ui/icon_import.png');
        form.button('§1オーバーワールドへ帰還', 'textures/items/ender_pearl');
        ids.forEach(id => form.button(`§0${configs[id].name}\n§8${id}`, 'textures/ui/bubble_empty'));
    }
    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) return showMainMenu(player);
        if (res.selection === 1) return executeReturn(player);
        showEditUI(player, ids[res.selection - 2]);
    });
}

function showEditUI(player, id) {
    const configs = getConfigs();
    const conf = configs[id];
    new ActionFormData()
        .title(`§1Edit: ${conf.name}`)
        .body('>>> §e選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1テレポート', 'textures/items/ender_pearl')
        .button(conf.portalEnabled ? '§0ゲート: §1ON' : '§0ゲート: §4OFF', 'textures/ui/bubble_empty')
        .button('§4削除', 'textures/ui/bubble_empty')
        .show(player)
        .then(res => {
            if (res.canceled || res.selection === 0) return showManageUI(player);
            if (res.selection === 1) {
                if (!player.dimension.id.startsWith('qd:')) {
                    const returns = getReturns();
                    returns[player.name] = {
                        location: { x: player.location.x, y: player.location.y, z: player.location.z },
                        dimensionId: player.dimension.id,
                    };
                    saveReturns(returns);
                }
                player.teleport(SPAWN_POS, { dimension: world.getDimension(id) });
            }
            if (res.selection === 2) {
                conf.portalEnabled = !conf.portalEnabled;
                saveConfigs(configs);
                showEditUI(player, id);
            }
            if (res.selection === 3) {
                showDeleteConfirmUI(player, id);
            }
        });
}

function showDeleteConfirmUI(player, id) {
    const configs = getConfigs();
    const conf = configs[id];

    new ActionFormData()
        .title('§4削除確認')
        .body(`ワールド名: §c${conf.name}§r\n\n` + '§e必ずお読みください§r\n\n' + 'この操作は二度と元に戻すことができません\n' + 'ディメンション内の建築、すべてのデータが§c完全にアクセスできなくなります§r。')
        .button('§4削除', 'textures/ui/bubble_empty')
        .button('§0キャンセル', 'textures/ui/icon_import.png')
        .show(player)
        .then(res => {
            // キャンセル、または「いいえ」を選んだら編集画面に戻る
            if (res.canceled || res.selection === 1) {
                return showEditUI(player, id);
            }

            // 「はい」が押された場合のみ削除処理を実行
            if (res.selection === 0) {
                const deletedName = conf.name; // メッセージ用に名前を記憶
                delete configs[id];
                saveConfigs(configs);
                player.sendMessage(`${PREFIX} §eワールド「${deletedName}」を削除しました。`);
                showManageUI(player); // 削除後は管理リスト画面に戻る
            }
        });
}

function showGlobalSettingsUI(player) {
    const settings = getGlobalSettings();
    new ModalFormData()
        .title('§1ゲート設定')
        .textField('>>> §eゲート枠のブロックID', 'minecraft:stone', { defaultValue: settings.frameBlock })
        .show(player)
        .then(res => {
            if (res.canceled) {
                return showMainMenu(player);
            }
            settings.frameBlock = res.formValues[0];
            saveGlobalSettings(settings);
            player.sendMessage(`${PREFIX} §a保存しました`);
        });
}

function executeReturn(player) {
    const returns = getReturns();
    if (returns[player.name]) {
        const returnData = returns[player.name];
        player.teleport(returnData.location, { dimension: world.getDimension(returnData.dimensionId) });
        delete returns[player.name];
        saveReturns(returns);
        player.sendMessage(`${PREFIX} §a記録地点へ帰還しました`);
    } else {
        player.sendMessage(`${PREFIX} §c帰還地点が記録されていません`);
    }
}

// --- コマンド受付 ---
system.afterEvents.scriptEventReceive.subscribe(e => {
    if (e.id === 'qd:menu') showMainMenu(e.sourceEntity);
    if (e.id === 'qd:tp') {
        const args = e.message.split(' ');
        if (args.length < 2) return;
        const selector = args[0];
        const dimId = args[1];
        const targets = parseSelector(selector);
        try {
            const targetDim = world.getDimension(dimId);
            const returns = getReturns();
            for (const p of targets) {
                if (!p.dimension.id.startsWith('qd:')) {
                    returns[p.name] = {
                        location: { x: p.location.x, y: p.location.y, z: p.location.z },
                        dimensionId: p.dimension.id,
                    };
                }
                p.teleport(SPAWN_POS, { dimension: targetDim });
            }
            saveReturns(returns);
        } catch (err) {}
    }
    if (e.id === 'qd:return') {
        const selector = e.message;

        if (!selector || selector.trim() === '') {
            e.sourceEntity.sendMessage(`${PREFIX} §c使い方が間違っています。例: /scriptevent qd:return @s`);
            return;
        }

        const targets = parseSelector(selector);
        for (const p of targets) {
            executeReturn(p);
        }
    }
});

function parseSelector(selector) {
    if (!selector) return [];
    var players = [];
    for (const player of world.getAllPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}
