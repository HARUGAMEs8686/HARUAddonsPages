import { world, system } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';

// ダイナミックプロパティに保存する際のIDを変更
const BORDER_SIZES_PROPERTY_ID = 'worldborder:sizes'; // オブジェクトを保存するためID名を変更
const OP_PROPERTY_ID = 'worldborder:op';
// 境界を超えた場合に少し戻す座標のマージン
const SAFE_MARGIN = 0.5;
// この距離だけ境界の外に出たらテレポートしない
const TELEPORT_BUFFER = 8.5;

// 現在の境界値をディメンションごとに保持する変数
let currentBorderSizes;

let currentOPLimit;

// プレイヤーごとの「最後にいた安全な場所」を記録するマップ
const playerLastValidLocations = new Map();

/**
 * 座標が境界内にあるかチェックし、範囲外なら修正した座標を返す関数
 * @param {number} x - プレイヤーのX座標
 * @param {number} z - プレイヤーのZ座標
 * @param {number} borderSize - このディメンションでの境界サイズ
 * @returns {{x: number, z: number} | null} - 修正後の座標、または修正不要ならnull
 */
function getClampedCoordinates(x, z, borderSize) {
    let clampedX = x;
    let clampedZ = z;
    let needsTeleport = false;

    if (x > borderSize && x <= borderSize + TELEPORT_BUFFER) {
        clampedX = borderSize - SAFE_MARGIN;
        needsTeleport = true;
    } else if (x < -borderSize && x >= -borderSize - TELEPORT_BUFFER) {
        clampedX = -borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    if (z > borderSize && z <= borderSize + TELEPORT_BUFFER) {
        clampedZ = borderSize - SAFE_MARGIN;
        needsTeleport = true;
    } else if (z < -borderSize && z >= -borderSize - TELEPORT_BUFFER) {
        clampedZ = -borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    if (needsTeleport) {
        return { x: clampedX, z: clampedZ };
    }
    return null;
}

// 5ティック（0.25秒）ごとにプレイヤーの座標をチェックする処理
system.runInterval(() => {
    if (typeof currentBorderSizes === 'undefined') return;

    for (const player of world.getAllPlayers()) {
        const dimensionId = player.dimension.id.split(':')[1]; // "overworld", "nether", "the_end"
        const borderSize = currentBorderSizes[dimensionId];

        // 設定がない、またはロード中で座標が取れない場合はスキップ
        if (typeof borderSize === 'undefined' || !player.location) {
            continue;
        }

        const location = player.location;
        const clampedCoords = getClampedCoordinates(location.x, location.z, borderSize);

        if (clampedCoords) {
            // 範囲外に出てしまった場合（徒歩移動など）
            if (!player.hasTag('WorldorderOP') || (player.hasTag('WorldorderOP') && !currentOPLimit)) {
                player.teleport({ x: clampedCoords.x, y: location.y, z: clampedCoords.z }, { rotation: { x: player.getRotation().x, y: player.getRotation().y } });
                player.onScreenDisplay.setActionBar('§c世界の果てに到達した');
            }
        } else {
            // ★変更点: 範囲内にいる場合、その場所を「安全な場所」として記録する
            const isOutsideBorder = Math.abs(location.x) > borderSize || Math.abs(location.z) > borderSize;

            if (isOutsideBorder) {
                player.onScreenDisplay.setActionBar('§e制限範囲内に戻ると制限が有効になります');
            } else {
                // 範囲内、かつ正常な位置なら記録更新
                playerLastValidLocations.set(player.id, {
                    dimensionId: player.dimension.id,
                    location: { x: location.x, y: location.y, z: location.z },
                    rotation: { x: player.getRotation().x, y: player.getRotation().y },
                });
            }
        }
    }
}, 5);

system.runInterval(() => {
    if (typeof currentBorderSizes === 'undefined') return;

    const dimensionIds = ['overworld', 'nether', 'the_end'];

    for (const dimId of dimensionIds) {
        const borderSize = currentBorderSizes[dimId];
        if (typeof borderSize === 'undefined') continue;

        const dimension = world.getDimension(dimId);

        // そのディメンションに存在する全てのエンダーパールを取得
        const pearls = dimension.getEntities({ type: 'minecraft:ender_pearl' });

        for (const pearl of pearls) {
            const location = pearl.location;

            if (Math.abs(location.x) > borderSize || Math.abs(location.z) > borderSize) {
                const projectileComp = pearl.getComponent('minecraft:projectile');
                const owner = projectileComp ? projectileComp.owner : undefined;

                if (currentOPLimit && owner && owner.typeId === 'minecraft:player' && owner.hasTag('WorldorderOP')) {
                    continue;
                }

                try {
                    pearl.remove();
                } catch (e) {}
            }
        }
    }
}, 2);

//スクリプトイベント
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'worldborder:s' && eventData.sourceEntity) {
        const player = eventData.sourceEntity;
        if (!player.hasTag('WorldorderOP')) {
            player.sendMessage(`[§bシステム§r] §a設定を行うにはOPタグが必要です\n §r>>> §eWorldorderOP`);
            return;
        }

        const form = new ModalFormData().title('§1ワールドボーダー設定').textField('オーバーワールドの範囲', '10以上の数値を入力', `${currentBorderSizes.overworld}`).textField('ネザーの範囲', '10以上の数値を入力', `${currentBorderSizes.nether}`).textField('エンドの範囲', '10以上の数値を入力', `${currentBorderSizes.the_end}`);

        form.toggle('OP無制限', currentOPLimit);

        form.show(player).then(response => {
            if (response.canceled) return;

            const [newOverworldSizeStr, newNetherSizeStr, newEndSizeStr] = response.formValues;
            const newOPLimit = response.formValues[3];

            const newOverworldSize = Number(newOverworldSizeStr);
            const newNetherSize = Number(newNetherSizeStr);
            const newEndSize = Number(newEndSizeStr);

            // 有効な数値かチェック
            if (isNaN(newOverworldSize) || newOverworldSize <= 0 || isNaN(newNetherSize) || newNetherSize <= 0 || isNaN(newEndSize) || newEndSize <= 0) {
                player.sendMessage('§cエラー: 全ての範囲に正の数値を指定してください。');
                return;
            }

            const newSizes = {
                overworld: newOverworldSize,
                nether: newNetherSize,
                the_end: newEndSize,
            };

            // ダイナミックプロパティに新しい値をJSON文字列として保存
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(newSizes));
            world.setDynamicProperty(OP_PROPERTY_ID, newOPLimit);

            // 実行中の変数を更新
            currentBorderSizes = newSizes;
            currentOPLimit = newOPLimit;

            player.sendMessage(`[§bシステム§r] §aワールドボーダー設定を更新しました`);
        });
    }
});

// ワールド読み込み
system.run(() => {
    const OLD_BORDER_PROPERTY_ID = 'worldborder:size'; // データ移行元（旧バージョン）のID
    const savedOldBorderSize = world.getDynamicProperty(OLD_BORDER_PROPERTY_ID);
    const savedSizesJSON = world.getDynamicProperty(BORDER_SIZES_PROPERTY_ID);

    if (savedSizesJSON === undefined) {
        // 新しい形式のデータがまだない場合
        if (savedOldBorderSize !== undefined) {
            const migratedSizes = {
                overworld: savedOldBorderSize, // 古い設定値をオーバーワールドに設定
                nether: savedOldBorderSize / 2, // ネザーは半分の値をデフォルトとして設定
                the_end: savedOldBorderSize * 2, // ジ・エンドは2倍の値をデフォルトとして設定
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(migratedSizes));
            currentBorderSizes = migratedSizes;

            world.setDynamicProperty(OLD_BORDER_PROPERTY_ID, undefined);
        } else {
            const defaultSizes = {
                overworld: 1000,
                nether: 500,
                the_end: 2000,
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(defaultSizes));
            currentBorderSizes = defaultSizes;
        }
    } else {
        // 新しい形式のデータが既に存在する場合は、それを読み込む
        currentBorderSizes = JSON.parse(savedSizesJSON);
    }

    const savedOPLimit = world.getDynamicProperty(OP_PROPERTY_ID);
    if (savedOPLimit === undefined) {
        world.setDynamicProperty(OP_PROPERTY_ID, false);
        currentOPLimit = false;
    } else {
        currentOPLimit = savedOPLimit;
    }
});

// ディメンション移動を検知
world.afterEvents.playerDimensionChange.subscribe(event => {
    const player = event.player;
    const toDimension = event.toDimension;
    const dimensionId = toDimension.id.split(':')[1];

    if (typeof currentBorderSizes === 'undefined') return;

    const borderSize = currentBorderSizes[dimensionId];
    if (typeof borderSize === 'undefined') return;

    system.runTimeout(() => {
        if (!player.isValid()) return;

        if (player.hasTag('WorldorderOP') && currentOPLimit) return;

        const location = player.location;
        const isOutside = Math.abs(location.x) > borderSize || Math.abs(location.z) > borderSize;

        if (isOutside) {
            // 範囲外に出る移動だった場合
            const lastData = playerLastValidLocations.get(player.id);

            if (lastData && lastData.dimensionId === event.fromDimension.id) {
                // 元のディメンションを取得
                const fromDim = world.getDimension(lastData.dimensionId);

                // 元の場所にテレポート（強制送還）
                player.teleport(lastData.location, {
                    dimension: fromDim,
                    rotation: lastData.rotation,
                });

                player.onScreenDisplay.setActionBar('§c移動先が世界の果てのため、移動できませんでした');
                player.sendMessage('§c[システム] §e移動先の座標がワールドボーダー外のため、元の場所に戻されました');
            }
        }
    }, 10); // 0.5秒待機
});
