//ワールドスタート時に生成するディメンションスロットの数を変更できます
export const MAX_SLOTS = 20;