import { world, system } from '@minecraft/server';

function loadTrackedPlayers() {
    const data = world.getDynamicProperty('trackedPlayers');
    return data ? JSON.parse(data) : {};
}
const trackedPlayers = loadTrackedPlayers();

function saveTrackedPlayers() {
    world.setDynamicProperty('trackedPlayers', JSON.stringify(trackedPlayers));
}

export function Xray() {
    const globalStats = loadGlobalStats();
    const ORE_LIMITS = {
        'minecraft:diamond_ore': 10,
        'minecraft:deepslate_diamond_ore': 10,
        'minecraft:ancient_debris': 8,
        'minecraft:emerald_ore': 15,
        'minecraft:deepslate_emerald_ore': 15,
    };

    const SUSPICION_RESET_TIME = 290000; // 7分（ミリ秒）
    const PLACED_BLOCK_EXPIRY = 24 * 60 * 60 * 1000; // 24時間（ミリ秒）

    const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL') || 1;

    const LEVEL_CONFIGS = {
        1: {
            TIME_WINDOW: 150,
            MIN_BREAK_INTERVAL: 400,
            SUSPICIOUS_THRESHOLD: 10,
            WARN_LIMIT: 6,
            DETECTION_RADIUS: 6,
            NEARBY_RADIUS: 5,
        },
        2: {
            TIME_WINDOW: 120,
            MIN_BREAK_INTERVAL: 350,
            SUSPICIOUS_THRESHOLD: 9,
            WARN_LIMIT: 5,
            DETECTION_RADIUS: 6,
            NEARBY_RADIUS: 5,
        },
        3: {
            TIME_WINDOW: 90,
            MIN_BREAK_INTERVAL: 300,
            SUSPICIOUS_THRESHOLD: 8,
            WARN_LIMIT: 4,
            DETECTION_RADIUS: 5,
            NEARBY_RADIUS: 4,
        },
        4: {
            TIME_WINDOW: 60,
            MIN_BREAK_INTERVAL: 200,
            SUSPICIOUS_THRESHOLD: 6,
            WARN_LIMIT: 3,
            DETECTION_RADIUS: 4,
            NEARBY_RADIUS: 3,
        },
        5: {
            TIME_WINDOW: 45,
            MIN_BREAK_INTERVAL: 150,
            SUSPICIOUS_THRESHOLD: 4,
            WARN_LIMIT: 2,
            DETECTION_RADIUS: 3,
            NEARBY_RADIUS: 2,
        },
    };

    let TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS;

    if (X_RAY_LEVEL != 0) {
        ({ TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL]);
    }

    function loadGlobalStats() {
        const data = world.getDynamicProperty('globalStats');
        return data
            ? JSON.parse(data)
            : {
                  totalMined: 0,
                  'minecraft:diamond_ore': 0,
                  'minecraft:deepslate_diamond_ore': 0,
                  'minecraft:emerald_ore': 0,
                  'minecraft:deepslate_emerald_ore': 0,
                  'minecraft:ancient_debris': 0,
              };
    }

    function saveGlobalStats() {
        world.setDynamicProperty('globalStats', JSON.stringify(globalStats));
    }

    function loadPlacedBlocks() {
        const data = world.getDynamicProperty('placedBlocks');
        return data ? new Map(JSON.parse(data)) : new Map();
    }

    function savePlacedBlocks() {
        const now = Date.now();
        for (const [key, timestamp] of placedBlocks) {
            if (now - timestamp > PLACED_BLOCK_EXPIRY) {
                placedBlocks.delete(key);
            }
        }
        const serialized = JSON.stringify([...placedBlocks]);
        if (serialized.length > 30000) {
            trimPlacedBlocks();
        }
        world.setDynamicProperty('placedBlocks', JSON.stringify([...placedBlocks]));
    }

    function trimPlacedBlocks() {
        const entries = [...placedBlocks.entries()];
        const halfLength = Math.floor(entries.length / 2);
        placedBlocks = new Map(entries.slice(halfLength));
    }

    function isNearbyOre(block, oreType) {
        const { x, y, z } = block.location;
        const MIN_Y = -64,
            MAX_Y = 320;
        const MIN_XZ = -30000000,
            MAX_XZ = 30000000;

        const offsets = [];
        for (let dx = -NEARBY_RADIUS; dx <= NEARBY_RADIUS; dx++) {
            for (let dy = -NEARBY_RADIUS; dy <= NEARBY_RADIUS; dy++) {
                for (let dz = -NEARBY_RADIUS; dz <= NEARBY_RADIUS; dz++) {
                    const newX = x + dx,
                        newY = y + dy,
                        newZ = z + dz;
                    if (newX < MIN_XZ || newX > MAX_XZ || newY < MIN_Y || newY > MAX_Y || newZ < MIN_XZ || newZ > MAX_XZ) {
                        continue;
                    }
                    offsets.push({ x: dx, y: dy, z: dz });
                }
            }
        }

        for (const offset of offsets) {
            const neighbor = block.dimension.getBlock({
                x: block.location.x + offset.x,
                y: block.location.y + offset.y,
                z: block.location.z + offset.z,
            });
            if (neighbor && neighbor.type.id === oreType) {
                return true;
            }
        }
        return false;
    }

    function isNearbyAir(block) {
        const { x, y, z } = block.location;
        const offsets = [
            { x: 1, y: 0, z: 0 },
            { x: -1, y: 0, z: 0 },
            { x: 0, y: 1, z: 0 },
            { x: 0, y: -1, z: 0 },
            { x: 0, y: 0, z: 1 },
            { x: 0, y: 0, z: -1 },
        ];

        for (const offset of offsets) {
            const neighbor = block.dimension.getBlock({
                x: x + offset.x,
                y: y + offset.y,
                z: z + offset.z,
            });
            if (neighbor && neighbor.typeId === 'minecraft:air') {
                return true;
            }
        }
        return false;
    }

    function getPlayerMiningSpeed(player) {
        let speedMultiplier = 1.0;

        if (!player || typeof player !== 'object' || !player.getComponent) {
            return speedMultiplier;
        }

        const inventory = player.getComponent('minecraft:inventory');
        if (!inventory || !inventory.container) {
            return speedMultiplier;
        }

        const selectedSlot = player.selectedSlot;
        if (typeof selectedSlot !== 'number' || selectedSlot < 0) {
            return speedMultiplier;
        }

        const heldItem = inventory.container.getSlot(selectedSlot);
        if (heldItem && heldItem.typeId && heldItem.typeId.includes('pickaxe')) {
            const enchantments = heldItem.getComponent('minecraft:enchantments');
            if (enchantments) {
                const efficiency = enchantments.getEnchantment('efficiency');
                const efficiencyLevel = efficiency && typeof efficiency.level === 'number' ? efficiency.level : 0;
                speedMultiplier *= 1 + efficiencyLevel * 0.2;
            }
        }

        const effects = player.getEffects ? player.getEffects() : [];
        for (const effect of effects) {
            if (effect && effect.typeId === 'minecraft:haste' && typeof effect.amplifier === 'number') {
                speedMultiplier *= 1 + effect.amplifier * 0.2;
            }
        }

        if (player.hasTag && player.hasTag('beacon_haste')) {
            speedMultiplier *= 1.4;
        }

        return speedMultiplier;
    }

    const placedBlocks = loadPlacedBlocks();
    const placedExplosives = new Map();

    world.afterEvents.playerPlaceBlock.subscribe(event => {
        system.run(() => {
            const block = event.block;
            const blockType = block.type.id;
            const key = `${block.location.x},${block.location.y},${block.location.z}`;

            if (blockType in ORE_LIMITS) {
                placedBlocks.set(key, Date.now());
                savePlacedBlocks();
            }

            if (blockType === 'minecraft:tnt' || blockType === 'minecraft:respawn_anchor' || blockType === 'minecraft:bed') {
                placedExplosives.set(key, {
                    playerId: event.player.name,
                    type: blockType,
                    timestamp: Date.now(),
                });
            }
        });
    });

    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        let { TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL];

        const player = event.player;
        const block = event.block;
        if (!block) return;

        const playerId = player.name;
        const blockPos = block.location;
        if (!blockPos) return;

        const { x, y, z } = blockPos;
        const oreType = block.type.id;

        if (!(oreType in ORE_LIMITS)) return;

        const blockKey = `${x},${y},${z}`;
        const isPlacedBlock = placedBlocks.has(blockKey);
        if (isPlacedBlock) {
            placedBlocks.delete(blockKey);
            savePlacedBlocks();
            return;
        }

        if (!trackedPlayers[playerId]) {
            trackedPlayers[playerId] = {
                ores: {},
                timestamp: Date.now(),
                lastBreakTime: 0,
                suspiciousCount: 0,
                warnCount: 0,
                lastBreakPos: null,
                totalBlocksMined: 0,
                reasons: {},
                straightMiningCount: 0,
                nearbyOreStreak: 0,
            };
        }

        let playerData = trackedPlayers[playerId];
        const now = Date.now();

        const speedMultiplier = getPlayerMiningSpeed(player);
        const adjustedMinBreakInterval = MIN_BREAK_INTERVAL / speedMultiplier;

        if (playerData.lastBreakTime > 0 && now - playerData.lastBreakTime < adjustedMinBreakInterval) {
            playerData.suspiciousCount++;
            playerData.reasons['短時間で掘りすぎた回数'] = (playerData.reasons['短時間で掘りすぎた回数'] || 0) + 1;
        }
        playerData.lastBreakTime = now;

        if (playerData.lastBreakPos) {
            const { x: lastX, y: lastY, z: lastZ } = playerData.lastBreakPos;
            const dx = Math.abs(x - lastX);
            const dy = Math.abs(y - lastY);
            const dz = Math.abs(z - lastZ);

            // 直線掘り：XまたはZ軸に沿って移動し、Yの変化が小さい
            const isStraightMining = dy <= 2 && (dx <= DETECTION_RADIUS || dz <= DETECTION_RADIUS);
            if (isStraightMining && oreType in ORE_LIMITS) {
                playerData.straightMiningCount = (playerData.straightMiningCount || 0) + 1;
                if (playerData.straightMiningCount >= 3) {
                    playerData.suspiciousCount++;
                    playerData.reasons['直線掘りで鉱石発見'] = (playerData.reasons['直線掘りで鉱石発見'] || 0) + 1;
                }
            } else {
                playerData.straightMiningCount = 0;
            }
        }
        playerData.lastBreakPos = { x, y, z };

        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.straightMiningCount = 0;
            playerData.nearbyOreStreak = 0;
        }

        playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
        playerData.totalBlocksMined++;
        globalStats.totalMined++;
        globalStats[oreType] = (globalStats[oreType] || 0) + 1;
        saveGlobalStats();

        if (isNearbyOre(block, oreType)) {
            playerData.nearbyOreStreak = (playerData.nearbyOreStreak || 0) + 1;
            if (playerData.nearbyOreStreak >= 2) {
                playerData.suspiciousCount++;
                playerData.reasons['近くの鉱石を連続で掘った回数'] = (playerData.reasons['近くの鉱石を連続で掘った回数'] || 0) + 1;
            }
        } else {
            playerData.nearbyOreStreak = 0;
        }

        if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
            playerData.suspiciousCount++;
            playerData.reasons['異常に多く掘った鉱石数'] = (playerData.reasons['異常に多く掘った鉱石数'] || 0) + 1;
        }

        const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
        const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
        if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
            playerData.suspiciousCount++;
            playerData.reasons['異常に高い鉱石発見率'] = (playerData.reasons['異常に高い鉱石発見率'] || 0) + 1;
        }

        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                let suspiciousOre = null;
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += `\n  - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(通常: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                    if (playerOreRate > worldOreRate * 2) {
                        suspiciousOre = ore;
                    }
                }

                const detectedOre = suspiciousOre || oreType;
                world.sendMessage(`[§bSecurityCraft§r] §b${playerId} §rが§cX-ray§4の可能性。対象: §b${detectedOre}`);
                world.sendMessage(`§e詳細§r: 発見率${oreStatsMessage}`);
                system.run(() => {
                    player.setGameMode('adventure');
                    world.getAllPlayers().forEach(p => {
                        p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                    });
                });
            }
        }

        saveTrackedPlayers();
    });

    world.beforeEvents.explosion.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        const { TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL];

        const impactedBlocks = event.getImpactedBlocks();
        if (!impactedBlocks.length) return;

        let responsiblePlayerId = null;

        let totalX = 0,
            totalY = 0,
            totalZ = 0;
        for (const block of impactedBlocks) {
            totalX += block.location.x;
            totalY += block.location.y;
            totalZ += block.location.z;
        }
        const centerX = Math.floor(totalX / impactedBlocks.length);
        const centerY = Math.floor(totalY / impactedBlocks.length);
        const centerZ = Math.floor(totalZ / impactedBlocks.length);

        const BLAST_RADIUS = 7;
        for (let dx = -BLAST_RADIUS; dx <= BLAST_RADIUS; dx++) {
            for (let dy = -BLAST_RADIUS; dy <= BLAST_RADIUS; dy++) {
                for (let dz = -BLAST_RADIUS; dz <= BLAST_RADIUS; dz++) {
                    const checkX = centerX + dx;
                    const checkY = centerY + dy;
                    const checkZ = centerZ + dz;
                    const explosionKey = `${checkX},${checkY},${checkZ}`;
                    const explosiveData = placedExplosives.get(explosionKey);

                    if (explosiveData && Date.now() - explosiveData.timestamp < 10000) {
                        responsiblePlayerId = explosiveData.playerId;
                        placedExplosives.delete(explosionKey);
                        break;
                    }
                }
                if (responsiblePlayerId) break;
            }
            if (responsiblePlayerId) break;
        }

        if (!responsiblePlayerId) {
            return;
        }

        const playerData = trackedPlayers[responsiblePlayerId] || {
            ores: {},
            timestamp: Date.now(),
            lastBreakTime: 0,
            suspiciousCount: 0,
            warnCount: 0,
            lastBreakPos: null,
            totalBlocksMined: 0,
            reasons: {},
            straightMiningCount: 0,
            nearbyOreStreak: 0,
        };

        trackedPlayers[responsiblePlayerId] = playerData;
        const now = Date.now();

        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.straightMiningCount = 0;
            playerData.nearbyOreStreak = 0;
        }

        let oreDetected = false;
        for (const block of impactedBlocks) {
            const oreType = block.type.id;
            if (!(oreType in ORE_LIMITS)) continue;

            const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
            if (placedBlocks.has(blockKey)) {
                placedBlocks.delete(blockKey);
                savePlacedBlocks();
                continue;
            }

            const isExposed = isNearbyAir(block);
            if (!isExposed) {
                oreDetected = true;
                playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
                playerData.totalBlocksMined++;
                globalStats.totalMined++;
                globalStats[oreType] = (globalStats[oreType] || 0) + 1;

                const nearby = isNearbyOre(block, oreType);
                if (nearby) {
                    playerData.nearbyOreStreak++;
                    if (playerData.nearbyOreStreak >= 2) {
                        playerData.suspiciousCount++;
                        playerData.reasons['爆発で近くの鉱石を連続で取得'] = (playerData.reasons['爆発で近くの鉱石を連続で取得'] || 0) + 1;
                    }
                }

                if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
                    playerData.suspiciousCount++;
                    playerData.reasons['爆発で異常に多く鉱石を取得'] = (playerData.reasons['爆発で異常に多く鉱石を取得'] || 0) + 1;
                }

                const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
                const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
                if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
                    playerData.suspiciousCount++;
                    playerData.reasons['爆発による異常な鉱石発見率'] = (playerData.reasons['爆発による異常な鉱石発見率'] || 0) + 1;
                }
            }
        }

        saveGlobalStats();
        saveTrackedPlayers();

        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += `\n  - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(通常: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                system.run(() => {
                    const player = world.getPlayers({ name: responsiblePlayerId })[0];
                    if (player) {
                        world.sendMessage(`[§bSecurityCraft§r] §b${responsiblePlayerId} §rが§cX-ray§4の可能性（爆発利用）。`);
                        world.sendMessage(`§e詳細§r: 発見率${oreStatsMessage}`);
                        player.setGameMode('adventure');
                        world.getAllPlayers().forEach(p => {
                            p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                        });
                    }
                });
            }
        }
    });

    system.runInterval(() => {
        for (const player in trackedPlayers) {
            trackedPlayers[player].suspiciousCount = Math.floor(trackedPlayers[player].suspiciousCount / 2);
            trackedPlayers[player].straightMiningCount = 0;
            trackedPlayers[player].nearbyOreStreak = 0;
        }
        savePlacedBlocks();

        const now = Date.now();
        for (const [key, data] of placedExplosives) {
            if (now - data.timestamp > PLACED_BLOCK_EXPIRY) {
                placedExplosives.delete(key);
            }
        }
    }, SUSPICION_RESET_TIME / 50);
}

export function resetPlayerXrayData(playerId) {
    if (trackedPlayers[playerId]) {
        delete trackedPlayers[playerId];
        saveTrackedPlayers();
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データをリセットしました。`);
        console.warn(`[XrayDebug] Reset X-ray data for player: ${playerId}`);
    } else {
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データが見つかりませんでした。`);
    }
}
