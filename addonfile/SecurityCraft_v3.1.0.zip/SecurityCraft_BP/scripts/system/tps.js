import { world, system } from '@minecraft/server';

import { currentTPS } from '../main';

export function TPSAdjustment() {
    // Dynamic Propertiesのキー
    const EMERGENCY_ITEM_KILL_KEY = 'emergencyItemKill';
    const TPS_THRESHOLD_KEY = 'tpsThreshold';

    const waitTicks = 200; // 10秒（20 ticks/sec * 10 sec）
    const averageCheckTicks = 100; // 平均TPSを計算する期間（5秒）
    const tpsHistorySize = 5; // 直近5回のTPS値を保持
    const initialDelayTicks = 100; // 初期遅延（5秒）

    // 状態管理フラグ
    let isProcessing = false;
    let tpsHistory = [];

    // TPSの平均値を計算する関数
    function getAverageTPS() {
        if (tpsHistory.length === 0) return 0;
        const sum = tpsHistory.reduce((a, b) => a + b, 0);
        return (sum / tpsHistory.length).toFixed(2); // 小数点以下2桁で返す
    }

    // エンティティをキルする関数
    function killEntities(entityType) {
        for (const entity of world.getDimension('overworld').getEntities()) {
            if (entityType === 'item' && entity.typeId === 'minecraft:item') {
                entity.kill();
            } else if (entityType === 'nonPlayer' && entity.typeId !== 'minecraft:player') {
                entity.kill();
            }
        }
    }

    // TPS監視を遅延開始
    system.runTimeout(() => {
        // TPS監視とアクションの実行
        const monitorInterval = system.runInterval(() => {
            // 毎回最新のDynamic Propertyを取得
            const emergencyItemKill = world.getDynamicProperty(EMERGENCY_ITEM_KILL_KEY);
            const tpsThreshold = world.getDynamicProperty(TPS_THRESHOLD_KEY);

            if (emergencyItemKill === false) return;
            // 処理中またはTPSが閾値以上の場合、または緊急キルが無効ならスキップ
            if (isProcessing || currentTPS >= tpsThreshold || !emergencyItemKill) {
                tpsHistory.push(currentTPS);
                if (tpsHistory.length > tpsHistorySize) {
                    tpsHistory.shift(); // 古いデータを削除
                }
                return;
            }

            // TPS低下を検知、現在のTPSを表示
            isProcessing = true;
            world.sendMessage(`§r[§bSecurity§r] §cTPSが低下しました §r(§a現在§r: §b${currentTPS.toFixed(2)}§r) §e再度チェックします`);
            const players = world.getPlayers();
            players.forEach(player => {
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            });

            // 10秒後にTPSを再確認
            system.runTimeout(() => {
                // TPS履歴をリセットして新しいデータを収集
                tpsHistory = [];
                let checkTicks = 0;

                // 5秒間TPSを監視して平均を計算
                const checkInterval = system.runInterval(() => {
                    tpsHistory.push(currentTPS);
                    if (tpsHistory.length > tpsHistorySize) {
                        tpsHistory.shift();
                    }
                    checkTicks += 20;

                    if (checkTicks >= averageCheckTicks) {
                        system.clearRun(checkInterval); // インターバルを終了
                        const averageTPS = getAverageTPS();
                        const tpsThreshold = world.getDynamicProperty(TPS_THRESHOLD_KEY); // 最新の閾値を取得
                        if (averageTPS >= tpsThreshold) {
                            world.sendMessage(`§r[§bSecurity§r] §aTPSが平均的に回復しました §r(§a平均§r: §b${averageTPS}§r)`);
                            players.forEach(player => {
                                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                            });
                            isProcessing = false; // 処理終了
                        } else {
                            world.sendMessage(`§r[§bSecurity§r] §cTPSが回復しませんでした §r(§a平均§r: §b${averageTPS}§r) §aアイテムをキルします`);
                            players.forEach(player => {
                                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                            });
                            killEntities('item');

                            // アイテムキル後に再度TPSをチェック（5秒後）
                            system.runTimeout(() => {
                                tpsHistory = [];
                                checkTicks = 0;
                                const postItemCheckInterval = system.runInterval(() => {
                                    tpsHistory.push(currentTPS);
                                    if (tpsHistory.length > tpsHistorySize) {
                                        tpsHistory.shift();
                                    }
                                    checkTicks += 20;

                                    if (checkTicks >= averageCheckTicks) {
                                        system.clearRun(postItemCheckInterval); // インターバルを終了
                                        const finalAverageTPS = getAverageTPS();
                                        const tpsThreshold = world.getDynamicProperty(TPS_THRESHOLD_KEY); // 最新の閾値を取得
                                        if (finalAverageTPS >= tpsThreshold) {
                                            world.sendMessage(`§r[§bSecurity§r] §aTPSが平均的に回復しました §r(§a平均§r: §b${finalAverageTPS}§r)`);
                                            players.forEach(player => {
                                                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                            });
                                        } else {
                                            world.sendMessage(`§r[§bSecurity§r] §cTPSが依然として低いです §r(§a平均§r: §b${finalAverageTPS}§r) §a非プレイヤーエンティティをキルします`);
                                            players.forEach(player => {
                                                player.playSound('random.toast', { pitch: 0.6, volume: 0.7 });
                                            });
                                            killEntities('nonPlayer');
                                            system.runTimeout(() => {
                                                killEntities('item');
                                            }, 10);

                                            // 非プレイヤーエンティティキル後に再度TPSをチェック
                                            system.runTimeout(() => {
                                                tpsHistory = [];
                                                checkTicks = 0;
                                                const finalCheckInterval = system.runInterval(() => {
                                                    tpsHistory.push(currentTPS);
                                                    if (tpsHistory.length > tpsHistorySize) {
                                                        tpsHistory.shift();
                                                    }
                                                    checkTicks += 20;

                                                    if (checkTicks >= averageCheckTicks) {
                                                        system.clearRun(finalCheckInterval);
                                                        const lastAverageTPS = getAverageTPS();
                                                        const tpsThreshold = world.getDynamicProperty(TPS_THRESHOLD_KEY); // 最新の閾値を取得
                                                        if (lastAverageTPS >= tpsThreshold) {
                                                            world.sendMessage(`§r[§bSecurity§r] §aTPSが平均的に回復しました §r(§a平均§r: §b${lastAverageTPS}§r)`);
                                                            players.forEach(player => {
                                                                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                                            });
                                                        } else {
                                                            world.sendMessage(`§r[§bSecurity§r] §cTPSが依然として低いです §r(§a平均§r: §b${lastAverageTPS}§r)`);
                                                            players.forEach(player => {
                                                                player.playSound('random.toast', { pitch: 0.6, volume: 0.7 });
                                                            });
                                                        }
                                                        isProcessing = false; // 処理終了
                                                    }
                                                }, 20); // 1秒ごとにチェック
                                            }, 10); // 非プレイヤーキル後すぐにチェック開始
                                        }
                                    }
                                }, 20); // 1秒ごとにチェック
                            }, 10); // アイテムキル後すぐにチェック開始
                        }
                    }
                }, 20); // 1秒ごとにチェック
            }, waitTicks); // 10秒待機
        }, 20); // 1秒ごとに監視
    }, initialDelayTicks); // 5秒後に監視開始
}