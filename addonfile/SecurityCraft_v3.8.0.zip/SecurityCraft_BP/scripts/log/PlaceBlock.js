import { world, system } from '@minecraft/server';
import { checkModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // Default to 7 days if not set
let pendingUpdates = new Map();

export function preload() {
    try {
        const storedDays = world.getDynamicProperty('placeblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`Error loading placeblock_delete_days: ${e}`);
    }
}

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    try {
        // chunkDataが空のMapになった場合はプロパティを削除する
        if (chunkData.size === 0) {
            world.setDynamicProperty(chunkKey, undefined);
        } else {
            const dataString = JSON.stringify([...chunkData]);
            world.setDynamicProperty(chunkKey, dataString);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`Error saving chunk data for key ${chunkKey}: ${e}`);
    }
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        if (!storedData) return new Map();

        const parsedData = JSON.parse(storedData);
        const chunkDataMap = new Map(parsedData);

        for (const [pos, data] of chunkDataMap.entries()) {
            if (data && typeof data.t === 'undefined') {
                data.t = Date.now();
            }
        }
        return chunkDataMap;
    } catch (e) {
        if (e instanceof SyntaxError) {
            console.warn(`古いデータ形式を検出しました。新しい形式に変換します。Key: ${chunkKey}`);
            const storedData = world.getDynamicProperty(chunkKey);
            const legacyData = storedData ? JSON.parse(storedData) : {};
            const chunkDataMap = new Map();
            for (const key in legacyData) {
                if (legacyData.hasOwnProperty(key)) {
                    if(typeof legacyData[key].t === 'undefined'){
                        legacyData[key].t = Date.now();
                    }
                    chunkDataMap.set(key, legacyData[key]);
                }
            }
            return chunkDataMap;
        }
        console.warn(`Error parsing chunk data for key ${chunkKey}: ${e}`);
        return new Map();
    }
}

function getChunkDataForBlock(x, z) {
    const chunkData = new Map();
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);
        const data = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);
        for (const [pos, value] of data) {
            if (!chunkData.has(pos) || value.t > (chunkData.get(pos)?.t || 0)) {
                chunkData.set(pos, value);
            }
        }
    }
    return chunkData;
}

// Process pending updates
system.runInterval(() => {
    for (const [chunkKey, chunkData] of pendingUpdates) {
        saveChunkData(chunkKey, chunkData);
    }
}, 20); // 少し間隔を長くして安定性を向上

// Clear old keys
system.runInterval(() => {
    const allKeys = world.getDynamicPropertyIds();
    const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
    const expirationDay = currentDay - DAYS_TO_KEEP;
    for (const key of allKeys) {
        if (key.match(/^-?\d+_-?\d+_\d+$/)) {
            // [修正点1] 正しくdayの部分を抽出するように修正
            const day = Number(key.split('_')[2]);
            if (!isNaN(day) && day < expirationDay) {
                world.setDynamicProperty(key, undefined);
            }
        }
    }
}, 1200); // 1分ごと

export function PlaceBlock() {
    function toJST(timestamp) {
        // Time_Settingの取得を関数内で行い、最新の値を使うようにする
        const timeSetting = world.getDynamicProperty('Time_Setting') || 9; // デフォルトは+9時間
        const date = new Date(timestamp + timeSetting * 60 * 60 * 1000);
        const year = date.getUTCFullYear();
        const month = String(date.getUTCMonth() + 1).padStart(2, '0');
        const day = String(date.getUTCDate()).padStart(2, '0');
        const hours = String(date.getUTCHours()).padStart(2, '0');
        const minutes = String(date.getUTCMinutes()).padStart(2, '0');
        const seconds = String(date.getUTCSeconds()).padStart(2, '0');
        return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
    }

    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const isRecordingEnabled = world.getDynamicProperty('PlaceBlock_system');
        if (!isRecordingEnabled) {
            return; 
        }
        
        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        // 保留中の更新があればそちらを優先して取得
        let chunkData = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);
        chunkData.set(positionKey, {
            p: player.name,
            t: Date.now()
        });

        pendingUpdates.set(chunkKey, chunkData);
    });

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const block = event.block;
        const { x, y, z } = block;
        const positionKey = getPositionKey(x, y, z);

        // [修正点2] ブロック破壊時のロジックを全面的に見直し
        // まず、どの日のデータに記録されているかを探す
        const combinedChunkData = getChunkDataForBlock(x, z);
        const blockData = combinedChunkData.get(positionKey);

        if (blockData && blockData.t) {
            // データが見つかったら、そのタイムスタンプから元のキーを特定
            const originalTimestamp = blockData.t;
            const originalChunkKey = getChunkKey(x, z, originalTimestamp);

            // 保留中のデータ、またはワールドに保存されたデータから元のチャンクデータを取得
            let originalChunkData = pendingUpdates.get(originalChunkKey) || getChunkData(originalChunkKey);

            // 該当するキーのデータを削除し、更新リストに入れる
            if (originalChunkData.delete(positionKey)) {
                pendingUpdates.set(originalChunkKey, originalChunkData);
            }
        }
    });

    const playerCache = new Map();
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!checkModePlayers.has(player.name) || playerCache.has(player.id)) return;

            playerCache.set(player.id, true);
            const block = event.block;
            const { x, y, z } = block;
            const positionKey = getPositionKey(x, y, z);
            const chunkData = getChunkDataForBlock(x, z);
            const blockData = chunkData.get(positionKey);

            if (blockData) {
                player.sendMessage(`§r[§bSecurityCraft§r] §5${blockData.p}§rによって§e設置 §r: §a${block.typeId}§r (§7${toJST(blockData.t)}§r)`);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurityCraft§r] §cこのブロックの設置者情報はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }

            system.runTimeout(() => playerCache.delete(player.id), 10);
        });
    });
}

export function clearAllPlaceData() {
    const allKeys = world.getDynamicPropertyIds();
    for (const key of allKeys) {
        if (key.match(/^-?\d+_-?\d+_\d+$/)) {
            world.setDynamicProperty(key, undefined);
        }
    }
    pendingUpdates.clear();
    console.log("すべての設置者情報をクリアしました。");
}