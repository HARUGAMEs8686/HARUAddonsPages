import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData, uiManager } from '@minecraft/server-ui';
import { chestCheckModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // デフォルトは7日間に設定
let pendingUpdates = new Map();

// 削除期間をロード
export function creload() {
    try {
        const storedDays = world.getDynamicProperty('chestlog_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[SecurityCraft]   アクセスログの削除期間のロード中にエラーが発生しました: ${e}`);
    }
}

// ワールドロード時にリロード
world.afterEvents.worldLoad.subscribe(() => {
    creload();
});

creload();

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    // UTCを基準とした日付でキーを生成
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `chest_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`[SecurityCraft] チャンクデータの保存中にエラーが発生しました: ${e}`);
    }
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        const parsedData = storedData ? JSON.parse(storedData) : [];
        return new Map(parsedData);
    } catch (e) {
        console.warn(`[SecurityCraft] チャンクデータのパース中にエラーが発生しました: ${e}`);
        return new Map();
    }
}

function cleanOldData() {
    try {
        const currentTime = Date.now();
        // UTCを基準として削除日を計算
        const expirationDay = Math.floor(currentTime / MILLISECONDS_PER_DAY) - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                const match = key.match(/chest_(-?\d+)_(-?\d+)_(\d+)/);
                if (match && parseInt(match[3]) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 古いデータのクリーンアップ中にエラーが発生しました: ${e}`);
    }
}

system.runInterval(() => {
    if (pendingUpdates.size > 0) {
        const updatesToProcess = new Map(pendingUpdates);
        for (const [chunkKey, chunkData] of updatesToProcess) {
            saveChunkData(chunkKey, chunkData);
        }
    }
    cleanOldData();
}, 20 * 10); // 1分に1回実行

export function addChestLog(block, player) {
    if (world.getDynamicProperty('ChestLog_system') !== true) return;

    const blockLocation = block.location;
    const chunkKey = getChunkKey(blockLocation.x, blockLocation.z);
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);

    let chunkData = pendingUpdates.has(chunkKey) ? pendingUpdates.get(chunkKey) : getChunkData(chunkKey);

    const logEntry = {
        n: player.name,
        t: Date.now(),
        id: block.typeId,
    };

    let logsForPosition = chunkData.has(positionKey) ? chunkData.get(positionKey) : [];
    logsForPosition.push(logEntry);

    // ログを最新の20件に制限
    if (logsForPosition.length > 20) {
        logsForPosition = logsForPosition.slice(-20);
    }

    chunkData.set(positionKey, logsForPosition);
    pendingUpdates.set(chunkKey, chunkData);
}

export function getChestLog(blockLocation) {
    let allLogs = [];
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);
    const currentTime = Date.now();

    // 今日からDAYS_TO_KEEPで設定された日数分、過去に遡ってログを検索
    for (let i = 0; i < DAYS_TO_KEEP; i++) {
        // i日前のタイムスタンプを計算
        const pastTimestamp = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(blockLocation.x, blockLocation.z, pastTimestamp);

        // チャンクデータを取得
        const chunkData = getChunkData(chunkKey);

        // 該当座標のログがあれば取得して結合
        if (chunkData.has(positionKey)) {
            allLogs.push(...chunkData.get(positionKey));
        }
    }

    // ログをタイムスタンプの降順（新しいものが上）に並び替え
    allLogs.sort((a, b) => b.t - a.t);

    // 最新20件に制限
    if (allLogs.length > 20) {
        allLogs = allLogs.slice(0, 20);
    }

    return allLogs;
}

export function clearAllChestData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 全アクセスログの削除中にエラーが発生しました: ${e}`);
    }
}

// プレイヤーごとの最後のUI表示ティックを記録するためのMap
const lastUITick = new Map();
// UIのクールダウン（ティック単位）
const uiCooldownTicks = 10;

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    const blockType = block.typeId;

    // 記録対象のブロックを定義
    const loggableBlocks = ['minecraft:chest', 'minecraft:barrel'];

    // --- クールダウン処理をティックベースに変更 ---
    const currentTick = system.currentTick;
    const lastTick = lastUITick.get(player.name);

    // 最後にUIを表示してからクールダウン（10ティック）が経過していない場合は処理を中断
    if (lastTick !== undefined && currentTick - lastTick < uiCooldownTicks) {
        return;
    }
    // 最後にUIを表示したティックを更新
    lastUITick.set(player.name, currentTick);

    // 記録システムが有効な場合、ログを記録
    if (world.getDynamicProperty('ChestLog_system') === true && loggableBlocks.includes(blockType) && !chestCheckModePlayers.has(player.name)) {
        system.run(() => {
            addChestLog(block, player);
        });
    }

    // 確認モードが有効な場合、UIを表示
    if (chestCheckModePlayers.has(player.name) && loggableBlocks.includes(blockType)) {
        event.cancel = true;

        system.runTimeout(() => {
            uiManager.closeAllForms(player);
            const logs = getChestLog(block.location);
            const form = new ActionFormData().title('§0アクセス履歴');

            if (logs.length > 0) {
                let body = `§a座標§r: §b${Math.floor(block.location.x)}, ${Math.floor(block.location.y)}, ${Math.floor(block.location.z)}\n§r`;
                logs.forEach(log => {
                    const japanTime = new Date(log.t + (world.getDynamicProperty('Time_Setting') || 0) * 60 * 60 * 1000);
                    const timeString = `${japanTime.getUTCFullYear()}/${String(japanTime.getUTCMonth() + 1).padStart(2, '0')}/${String(japanTime.getUTCDate()).padStart(2, '0')} ${String(japanTime.getUTCHours()).padStart(2, '0')}:${String(japanTime.getUTCMinutes()).padStart(2, '0')}:${String(japanTime.getUTCSeconds()).padStart(2, '0')}`;
                    body += `\n§r・§e${log.n} §7(${timeString})§r`;
                });
                form.body(body);
            } else {
                form.body(`§cアクセス履歴がありません`);
            }

            form.button('§l閉じる');
            form.show(player);
        }, 2);
    }
});
