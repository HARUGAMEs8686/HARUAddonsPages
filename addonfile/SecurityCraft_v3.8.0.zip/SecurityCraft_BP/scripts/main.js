import { world, system, CommandPermissionLevel, CustomCommandStatus, CustomCommandOrigin, ItemStack } from '@minecraft/server';
import { BlockRestore, rreload } from './reset/BlockRestore.js';

// グローバルな初期化済みプロパティを保持
let dynamicProperties = {};

// グローバル変数でTPSを保持
export var currentTPS = 0;

// 確認モードのプレイヤーリスト
export const checkModePlayers = new Set();

// 新規追加: チェストアクセス確認モードのプレイヤーリスト
export const chestCheckModePlayers = new Set();

//破壊記録
export const playerCheckModeStatus = {};

// 初期化用の非同期関数
function initializeDynamicProperties() {
    return new Promise((resolve, reject) => {
        system.runTimeout(() => {
            try {
                //時刻
                if (world.getDynamicProperty('Time_Setting') == undefined) {
                    world.setDynamicProperty('Time_Setting', 9);
                }
                // X_RAY_LEVEL
                if (world.getDynamicProperty('X_RAY_LEVEL') == undefined) {
                    world.setDynamicProperty('X_RAY_LEVEL', 3);
                }
                dynamicProperties['X_RAY_LEVEL'] = world.getDynamicProperty('X_RAY_LEVEL');

                // CHAT_LEVEL
                if (world.getDynamicProperty('CHAT_LEVEL') == undefined) {
                    world.setDynamicProperty('CHAT_LEVEL', 1);
                }
                dynamicProperties['CHAT_LEVEL'] = world.getDynamicProperty('CHAT_LEVEL');

                // bannedBlocks
                if (world.getDynamicProperty('bannedBlocks') == undefined) {
                    const bannedBlocks = [
                        'minecraft:tnt',
                        'minecraft:lit_tnt',
                        'minecraft:respawn_anchor',
                        'minecraft:lava',
                        'minecraft:lava_bucket',
                        'minecraft:fire',
                        'minecraft:end_crystal',
                        'minecraft:structure_block',
                        'minecraft:structure_void',
                        'minecraft:jigsaw',
                        'minecraft:command_block',
                        'minecraft:repeating_command_block',
                        'minecraft:chain_command_block',
                        'minecraft:barrier',
                        'minecraft:deny',
                        'minecraft:allow',
                        'minecraft:light_block',
                        'minecraft:web',
                        'minecraft:sweet_berry_bush',
                        'minecraft:wither_skeleton_skull',
                        'minecraft:sculk_shrieker',
                        'minecraft:bedrock',
                        'minecraft:nether_portal',
                        'minecraft:flint_and_steel',
                        'minecraft:fire_charge',
                    ];
                    world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
                }
                dynamicProperties['bannedBlocks'] = world.getDynamicProperty('bannedBlocks');

                // itemUseOn_system
                if (world.getDynamicProperty('itemUseOn_system') == undefined) {
                    world.setDynamicProperty('itemUseOn_system', true);
                }
                dynamicProperties['itemUseOn_system'] = world.getDynamicProperty('itemUseOn_system');

                // Log_system
                if (world.getDynamicProperty('Log_system') == undefined) {
                    world.setDynamicProperty('Log_system', true);
                }
                dynamicProperties['Log_system'] = world.getDynamicProperty('Log_system');

                // pvp_check
                if (world.getDynamicProperty('pvp_check') == undefined) {
                    world.setDynamicProperty('pvp_check', true);
                }
                dynamicProperties['pvp_check'] = world.getDynamicProperty('pvp_check');

                // 削除期間
                if (world.getDynamicProperty('placeblock_delete_speed') == undefined) {
                    world.setDynamicProperty('placeblock_delete_speed', 7);
                }
                dynamicProperties['placeblock_delete_speed'] = world.getDynamicProperty('placeblock_delete_speed');

                if (world.getDynamicProperty('breakblock_delete_speed') == undefined) {
                    world.setDynamicProperty('breakblock_delete_speed', 7);
                }
                dynamicProperties['breakblock_delete_speed'] = world.getDynamicProperty('breakblock_delete_speed');

                if (world.getDynamicProperty('location_delete_speed') == undefined) {
                    world.setDynamicProperty('location_delete_speed', 7);
                }
                dynamicProperties['location_delete_speed'] = world.getDynamicProperty('location_delete_speed');

                if (world.getDynamicProperty('chestlog_delete_speed') == undefined) {
                    world.setDynamicProperty('chestlog_delete_speed', 7);
                }
                dynamicProperties['chestlog_delete_speed'] = world.getDynamicProperty('chestlog_delete_speed');

                //破壊記録 有効無効
                if (world.getDynamicProperty('BreakBlock_system') == undefined) {
                    world.setDynamicProperty('BreakBlock_system', true);
                }
                dynamicProperties['BreakBlock_system'] = world.getDynamicProperty('BreakBlock_system');

                //設置記録 有効無効
                if (world.getDynamicProperty('PlaceBlock_system') == undefined) {
                    world.setDynamicProperty('PlaceBlock_system', true);
                }
                dynamicProperties['PlaceBlock_system'] = world.getDynamicProperty('PlaceBlock_system');

                if (world.getDynamicProperty('ChestLog_system') == undefined) {
                    world.setDynamicProperty('ChestLog_system', true);
                }
                dynamicProperties['ChestLog_system'] = world.getDynamicProperty('ChestLog_system');

                if (world.getDynamicProperty('blockrestore_delete_speed') == undefined) {
                    world.setDynamicProperty('blockrestore_delete_speed', 7);
                }
                dynamicProperties['blockrestore_delete_speed'] = world.getDynamicProperty('blockrestore_delete_speed');

                if (world.getDynamicProperty('BlockRestore_system') == undefined) {
                    world.setDynamicProperty('BlockRestore_system', true);
                }
                dynamicProperties['BlockRestore_system'] = world.getDynamicProperty('BlockRestore_system');

                // 初期化完了ログ
                resolve(dynamicProperties);
            } catch (error) {
                console.error(`Error initializing dynamic properties: ${error}`);
                reject(error);
            }
        }, 20); // 20ティック遅延
    });
}

// メイン処理
async function main() {
    // 初期化を待つ
    dynamicProperties = await initializeDynamicProperties();

    // 動的インポートでモジュールをロード
    const [{ UI }] = await Promise.all([import('./ui.js')]);
    const [{ Xray }] = await Promise.all([import('./detection/x-ray.js')]);
    const [{ Chat }] = await Promise.all([import('./detection/chat.js')]);
    const [{ BreakBlock }] = await Promise.all([import('./log/BreakBlock.js')]);
    const [{ PlaceBlock }] = await Promise.all([import('./log/PlaceBlock.js')]);

    const cooldowns = new Map();
    const cooldownTime = 1000;

    // 禁止アイテムリストの取得
    function getBannedItems() {
        return JSON.parse(world.getDynamicProperty('bannedBlocks') || '[]');
    }

    // 1. ブロックとのインタラクション（例：マグマバケツで大釜やブロックに使用）
    world.beforeEvents.playerInteractWithBlock.subscribe(eventGDP => {
        if (world.getDynamicProperty('itemUseOn_system') === false) return;

        const player = eventGDP.player;
        if (!player || !player.id) return;

        // SecurityMemberタグがない場合
        if (!player.getTags().includes('SecurityMember')) {
            const item = eventGDP.itemStack;
            const bannedItems = getBannedItems();

            // 禁止アイテムかチェック（マグマバケツやブロックなど）
            if (item && bannedItems.includes(item.typeId)) {
                eventGDP.cancel = true; // インタラクションをキャンセル

                // クールダウンチェック
                const lastMessageTime = cooldowns.get(player.id) || 0;
                const now = Date.now();
                if (now - lastMessageTime >= cooldownTime) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §c${item.typeId}§rを使用する§e権限§rがありません`);
                    system.run(() => {
                        player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
                    });
                    cooldowns.set(player.id, now);
                }
            }
        }
    });

    // 2. ブロック以外でのアイテム使用（例：マグマバケツで空間に溶岩を置く）
    world.afterEvents.itemUse.subscribe(eventGDP => {
        if (world.getDynamicProperty('itemUseOn_system') === false) return;

        const player = eventGDP.source;
        if (!player || !player.id) return;

        // SecurityMemberタグがない場合
        if (!player.getTags().includes('SecurityMember')) {
            const item = eventGDP.itemStack;
            const bannedItems = getBannedItems();

            // 禁止アイテムかチェック（マグマバケツやその他）
            if (item && bannedItems.includes(item.typeId)) {
                // itemUseはキャンセル不可なので、結果を元に戻す
                system.run(() => {
                    // 視線先のブロックをチェック（例：マグマバケツが置いた溶岩）
                    const block = player.dimension.getBlock(player.getBlockFromViewDirection()?.block);
                    if (block && (block.typeId === 'minecraft:lava' || block.typeId === 'minecraft:water')) {
                        block.setType('minecraft:air'); // 溶岩や水を削除
                    }
                });

                // クールダウンチェック
                const lastMessageTime = cooldowns.get(player.id) || 0;
                const now = Date.now();
                if (now - lastMessageTime >= cooldownTime) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §c${item.typeId}§rを使用する§e権限§rがありません`);
                    system.run(() => {
                        player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
                    });
                    cooldowns.set(player.id, now);
                }
            }
        }
    });

    //アイテム
    world.beforeEvents.itemUse.subscribe(eventData => {
        if (eventData.itemStack.typeId === 'additem:securecraft') {
            const player = eventData.source;
            system.run(() => {
                if (player.hasTag('SecurityOP')) {
                    UI(player);
                } else {
                    player.sendMessage(`§r[§bSecurityCraft§r] §a権限がありません`);
                }
            });
        }
    });

    function measureTPS() {
        let tickTimes = [];

        system.runInterval(() => {
            const now = Date.now();
            tickTimes.push(now);

            // 十分なサンプルが集まったらTPSを計算
            if (tickTimes.length > 1) {
                const timeDiff = tickTimes[tickTimes.length - 1] - tickTimes[0];
                if (timeDiff >= 1000) {
                    // 1秒以上のデータが集まったら
                    const ticksPerSecond = (tickTimes.length - 1) / (timeDiff / 1000);
                    currentTPS = Math.round(ticksPerSecond * 100) / 100; // 小数点2桁に丸める
                    tickTimes = [tickTimes[tickTimes.length - 1]]; // 最新のデータのみ保持
                }
            }
        }, 1); // 毎ティック実行
    }

    // TPS測定を開始
    measureTPS();

    //スクリプトロード
    Xray();
    Chat();
    BreakBlock();
    PlaceBlock();
    BlockRestore();
    rreload();
}

// スクリプトの実行
main();

//**カスタムコマンド
system.beforeEvents.startup.subscribe(eventData => {
    // 起動コマンド
    const StartSystem = {
        name: 'sc:start',
        description: '§aSecurityCraft§rを§e起動§rします',
        permissionLevel: CommandPermissionLevel.Admin,
        mandatoryParameters: [],
        optionalParameters: [],
    };
    eventData.customCommandRegistry.registerCommand(StartSystem, SCStart);

    //アイテム取得
    const GetItem = {
        name: 'sc:getitem',
        description: '§aSecurityCraft設定画面を開くためのアイテムを取得します',
        permissionLevel: CommandPermissionLevel.Admin,
        mandatoryParameters: [],
        optionalParameters: [],
    };
    eventData.customCommandRegistry.registerCommand(GetItem, SCGetItem);

    //UI表示
    const SettingUI = {
        name: 'sc:ui',
        description: '§aSecurityCraft設定画面を開きます',
        permissionLevel: CommandPermissionLevel.Admin,
        mandatoryParameters: [],
        optionalParameters: [],
    };
    eventData.customCommandRegistry.registerCommand(SettingUI, SCUI);
});

// 起動 F
function SCStart(origin) {
    if (origin.sourceEntity?.typeId !== 'minecraft:player') {
        return;
    }

    const player = origin.sourceEntity;
    system.run(() => {
        player.addTag('SecurityOP');
        player.addTag('SecurityMember');
        player.sendMessage('§r[§bSecurityCraft§r] §eSecurityCraftを起動しました');
        player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
    });
}

//アイテム取得 F
function SCGetItem(origin) {
    if (origin.sourceEntity?.typeId !== 'minecraft:player') {
        return;
    }

    const player = origin.sourceEntity;
    system.run(() => {
        player.getComponent('inventory').container.addItem(new ItemStack('additem:securecraft', 1));
        player.sendMessage('§r[§bSecurityCraft§r] §eアイテムを付与しました');
        player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
    });
}

//UI表示 F
function SCUI(origin) {
    if (origin.sourceEntity?.typeId !== 'minecraft:player') {
        return;
    }

    const player = origin.sourceEntity;
    system.run(() => {
        import('./ui.js').then(({ UI }) => {
            UI(player);
        });
    });
}

//**スクリプトイベント (バックアップ)
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    //起動
    if (eventData.id === 'sc:start' && eventData.sourceEntity) {
        SCStart(eventData);
    }
    //アイテム取得
    if (eventData.id === 'sc:getitem' && eventData.sourceEntity) {
        SCGetItem(eventData);
    }
    //UI表示
    if (eventData.id === 'sc:ui' && eventData.sourceEntity) {
        SCUI(eventData);
    }
});
