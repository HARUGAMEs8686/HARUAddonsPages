import { world, system } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';

// 初期化
if (world.getDynamicProperty('KILL_INTERVAL_MINUTES') === undefined) {
    world.setDynamicProperty('KILL_INTERVAL_MINUTES', 30); // デフォルトを30分に
}
if (world.getDynamicProperty('WARNING_TIME_MINUTES') === undefined) {
    world.setDynamicProperty('WARNING_TIME_MINUTES', 1);
}

// インターバル管理用の変数
let intervalId = null;

function startItemKillSystem() {
    // 現在の設定値を取得
    const killIntervalMinutes = Number(world.getDynamicProperty('KILL_INTERVAL_MINUTES'));
    const warningTimeMinutes = Number(world.getDynamicProperty('WARNING_TIME_MINUTES'));
    const KILL_INTERVAL_TICKS = killIntervalMinutes * 60 * 20;
    const WARNING_TIME_TICKS = warningTimeMinutes * 60 * 20;

    // 警告時間チェック
    if (WARNING_TIME_TICKS >= KILL_INTERVAL_TICKS) {
        console.warn('警告時間がキル間隔以上です。警告は送信されません。');
        return;
    }

    // 既存のインターバルをクリア
    if (intervalId !== null) {
        system.clearRun(intervalId);
    }

    // 初回の警告とキルをスケジュール
    function scheduleKillCycle() {
        // プレイヤーがいない場合はスキップ
        if (world.getPlayers().length === 0) return;

        // 警告メッセージ
        system.runTimeout(() => {
            for (const player of world.getPlayers()) {
                player.sendMessage(`§r[§bシステム§r] §e${warningTimeMinutes}分後にアイテムキルが実行されます`);
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            }

            // カウントダウン（3、2、1）をアクションバーに表示
            system.runTimeout(() => {
                for (const player of world.getPlayers()) {
                    player.onScreenDisplay.setActionBar(`§aアイテムキル前 §e3`);
                }
            }, WARNING_TIME_TICKS - 60); // キル3秒前

            system.runTimeout(() => {
                for (const player of world.getPlayers()) {
                    player.onScreenDisplay.setActionBar(`§aアイテムキル前 §e2`);
                }
            }, WARNING_TIME_TICKS - 40); // キル2秒前

            system.runTimeout(() => {
                for (const player of world.getPlayers()) {
                    player.onScreenDisplay.setActionBar(`§aアイテムキル前 §e1`);
                }
            }, WARNING_TIME_TICKS - 20); // キル1秒前
        }, KILL_INTERVAL_TICKS - WARNING_TIME_TICKS); // キル前に警告

        // アイテムキル実行
        system.runTimeout(() => {
            for (const player of world.getPlayers()) {
                player.sendMessage(`§r[§bシステム§r] §aアイテムキルが実行されました`);
                player.playSound('random.toast', { pitch: 1.9, volume: 1.0 });
            }
            const dimensions = ['overworld', 'nether', 'the_end'];
            for (const dim of dimensions) {
                try {
                    world.getDimension(dim).runCommand('kill @e[type=item]');
                } catch (e) {
                    console.warn(`ディメンション ${dim} でのアイテムキルに失敗: ${e.message}`);
                }
            }
        }, KILL_INTERVAL_TICKS); // インターバル後にキル
    }

    // 初回サイクルを即座に開始
    scheduleKillCycle();

    // 以降のサイクルをインターバルで設定
    intervalId = system.runInterval(() => {
        scheduleKillCycle();
    }, KILL_INTERVAL_TICKS);
}

// 初期起動
startItemKillSystem();

// 設定変更用のスクリプトイベント
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'itemkill:s' && eventData.sourceEntity) {
        const player = eventData.sourceEntity;
        system.run(() => {
            const form = new ModalFormData()
                .title('アイテムキル設定')
                .textField('アイテムキル間隔（分）', '1以上の数値を入力', `${world.getDynamicProperty('KILL_INTERVAL_MINUTES')}`)
                .textField('警告メッセージの送信タイミング（分前）', '0以上の数値を入力', `${world.getDynamicProperty('WARNING_TIME_MINUTES')}`);
            form.show(player).then(response => {
                if (response.canceled) return;

                const killInterval = Number(response.formValues[0]);
                const warningTime = Number(response.formValues[1]);

                // 入力値のバリデーション
                if (isNaN(killInterval) || killInterval < 1) {
                    player.sendMessage(`§r[§bシステム§r] §cエラー: アイテムキル間隔は1以上の数値でなければなりません`);
                    return;
                }
                if (isNaN(warningTime) || warningTime < 0) {
                    player.sendMessage(`§r[§bシステム§r] §cエラー: 警告時間は0以上の数値でなければなりません`);
                    return;
                }
                if (warningTime >= killInterval) {
                    player.sendMessage(`§r[§bシステム§r] §cエラー: 警告時間はキル間隔より小さくしてください`);
                    return;
                }

                // 設定を保存
                world.setDynamicProperty('KILL_INTERVAL_MINUTES', killInterval);
                world.setDynamicProperty('WARNING_TIME_MINUTES', warningTime);
                player.sendMessage(`§r[§bシステム§r] §aアイテムキル設定を変更しました`);
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });

                // インターバルを再設定
                startItemKillSystem();
            });
        });
    }
});
