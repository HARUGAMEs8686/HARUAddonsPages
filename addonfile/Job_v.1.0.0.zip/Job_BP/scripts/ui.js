import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UpdateConfig } from './system';

// 職業の表示名マッピング
const PROFESSION_DISPLAY_NAMES = {
    livestock: '家畜',
    miner: '鉱夫',
    builder: '林業',
    farming: '農業',
    adventurer: '冒険家',
    Angler: '釣り人',
};

// 設定の取得
function getConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    const config = savedConfig ? JSON.parse(savedConfig) : DEFAULT_CONFIG;
    if (!config.levelRewards) {
        config.levelRewards = DEFAULT_CONFIG.levelRewards;
    } else {
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
        professions.forEach(prof => {
            if (!config.levelRewards[prof]) {
                config.levelRewards[prof] = {};
            }
        });
    }
    return config;
}

// 設定の保存
function saveConfig(config) {
    world.setDynamicProperty('business_config', JSON.stringify(config));
    UpdateConfig();
}

// メッセージ送信関数
function sendMessage(player, message, success = true) {
    player.sendMessage(`[§b職業システム§r] ${message}`);
    player.playSound('random.toast', { pitch: success ? 1.7 : 0.4, volume: 1.0 });
}

// エフェクトの常時適用
function applyProfessionEffects(player) {
    const professions = getPlayerProfessions(player);
    const config = getConfig();
    professions.forEach(prof => {
        const level = player.getDynamicProperty(`${prof}_level`) || 1;
        const rewards = config.levelRewards[prof] || {};
        Object.keys(rewards)
            .map(Number)
            .forEach(lvl => {
                if (lvl <= level) {
                    const selectedEffect = player.getDynamicProperty(`${prof}_selected_effect_${lvl}`);
                    const isEffectEnabled = player.getDynamicProperty(`${prof}_effect_enabled_${lvl}`) !== false;
                    if (selectedEffect && isEffectEnabled && selectedEffect !== `money_${rewards[lvl].money}`) {
                        const reward = rewards[lvl];
                        const effect = reward.effect1?.id === selectedEffect ? reward.effect1 : reward.effect2;
                        if (effect) {
                            player.runCommandAsync(`effect ${player.name} ${effect.id} 30 ${effect.amplifier} true`);
                        }
                    }
                }
            });
    });
}

world.getAllPlayers().forEach(player => {
    applyProfessionEffects(player);
});

// エフェクトの定期更新
system.runInterval(() => {
    world.getAllPlayers().forEach(player => {
        applyProfessionEffects(player);
    });
}, 20 * 30); // 30秒ごとに更新

// 管理者UI
function showAdminUI(player) {
    if (!player.hasTag('HARUPhoneOP')) {
        sendMessage(player, '§c管理者権限が必要です', false);
        return;
    }

    const form = new ActionFormData().title('§1管理者設定').body('設定項目を選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§0システム設定', 'textures/ui/icon_setting.png').button('§1職業設定', 'textures/ui/icon_book_writable.png').button('§4レベル報酬設定', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showPlayerUI(player);
        } else if (response.selection === 1) {
            showSystemConfigUI(player);
        } else if (response.selection === 2) {
            showProfessionConfigUI(player);
        } else if (response.selection === 3) {
            showLevelRewardsConfigUI(player);
        }
    });
}

// システム設定UI
function showSystemConfigUI(player) {
    const config = getConfig();
    const form = new ModalFormData().title('§1システム設定').textField('職業解除までの日数', '日数を入力', `${config.system.professionRemoveDays}`).textField('最大職業数', '数を入力', `${config.system.maxProfessions}`);

    form.show(player).then(response => {
        if (response.canceled) {
            showAdminUI(player);
            return;
        }
        const [removeDays, maxProfessions] = response.formValues;
        const newConfig = getConfig();
        newConfig.system.professionRemoveDays = parseInt(removeDays);
        newConfig.system.maxProfessions = parseInt(maxProfessions);
        saveConfig(newConfig);
        sendMessage(player, '§aシステム設定を更新しました');
        showAdminUI(player);
    });
}

// 職業設定UI
function showProfessionConfigUI(player) {
    const form = new ActionFormData()
        .title('§1職業設定')
        .body('設定する職業を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1家畜', 'textures/ui/normalicon1.png')
        .button('§1鉱夫', 'textures/ui/normalicon1.png')
        .button('§1林業', 'textures/ui/normalicon1.png')
        .button('§1農業', 'textures/ui/normalicon1.png')
        .button('§1冒険家', 'textures/ui/normalicon1.png')
        .button('§1釣り人', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminUI(player);
            return;
        }
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
        const selectedProfession = professions[response.selection - 1];
        showProfessionDetailUI(player, selectedProfession);
    });
}

// 職業詳細設定UI
function showProfessionDetailUI(player, profession) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} 設定`).body('アクションを選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§4ポイント設定', 'textures/ui/normalicon1.png').button('§5レベルアップアクション数設定', 'textures/ui/normalicon1.png').button('§1アイテム/ブロック/モブ設定', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionConfigUI(player);
        } else if (response.selection === 1) {
            showItemPointsConfigUI(player, profession);
        } else if (response.selection === 2) {
            showLevelUpActionsConfigUI(player, profession);
        } else if (response.selection === 3) {
            showItemConfigUI(player, profession);
        }
    });
}

// アイテムごとのポイント設定UI
function showItemPointsConfigUI(player, profession) {
    const config = getConfig();
    const items = config.items[profession];
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ポイント設定`).body('設定するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(`§1${item}`, 'textures/ui/icon_crafting.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showItemPointsUI(player, profession, selectedItem);
    });
}

function showItemPointsUI(player, profession, item) {
    const config = getConfig();
    const currentPoints = config.points[profession]?.[item] || 10;
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ${item} ポイント設定`).textField('ポイント', 'ポイントを入力', currentPoints.toString());

    form.show(player).then(response => {
        if (response.canceled) {
            showItemPointsConfigUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        if (!newConfig.points[profession]) newConfig.points[profession] = {};
        newConfig.points[profession][item] = parseInt(response.formValues[0]) || currentPoints;
        saveConfig(newConfig);
        sendMessage(player, `§a${item}のポイントを更新しました`);
        showItemPointsConfigUI(player, profession);
    });
}

// レベルアップアクション数設定UI
function showLevelUpActionsConfigUI(player, profession) {
    const config = getConfig();
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベルアップアクション数設定`).textField('アクション数', '必要アクション数を入力', config.levelUpActions[profession].toString());

    form.show(player).then(response => {
        if (response.canceled) return;
        const newConfig = getConfig();
        newConfig.levelUpActions[profession] = parseInt(response.formValues[0]) || newConfig.levelUpActions[profession];
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベルアップアクション数を更新しました`);
        showProfessionDetailUI(player, profession);
    });
}

// アイテム/ブロック/モブ設定UI
function showItemConfigUI(player, profession) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム設定`).body('アクションを選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1追加', 'textures/ui/normalicon1').button('§0編集', 'textures/ui/normalicon1').button('§4削除', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showProfessionDetailUI(player, profession);
        } else if (response.selection === 1) {
            showAddItemUI(player, profession);
        } else if (response.selection === 2) {
            showEditItemUI(player, profession);
        } else if (response.selection === 3) {
            showDeleteItemUI(player, profession);
        }
    });
}

// アイテム追加UI
function showAddItemUI(player, profession) {
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム追加`).textField('アイテム/ブロック/モブID', 'IDを入力 (例: minecraft:coal_ore)');

    form.show(player).then(response => {
        if (response.canceled) {
            showItemConfigUI(player, profession);
            return;
        }
        const itemId = response.formValues[0].trim();
        if (itemId) {
            const newConfig = getConfig();
            if (!newConfig.items[profession].includes(itemId)) {
                newConfig.items[profession].push(itemId);
                saveConfig(newConfig);
                sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}に${itemId}を追加しました`);
            } else {
                sendMessage(player, `§c${itemId}はすでに登録されています`, false);
            }
        }
        showItemConfigUI(player, profession);
    });
}

// アイテム編集UI
function showEditItemUI(player, profession) {
    const config = getConfig();
    const items = config.items[profession];
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム編集`).body('編集するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(item));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showItemConfigUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showEditItemDetailUI(player, profession, selectedItem);
    });
}

// アイテム編集詳細UI
function showEditItemDetailUI(player, profession, item) {
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム編集`).textField('新しいID', '新しいIDを入力', item);

    form.show(player).then(response => {
        if (response.canceled) {
            showEditItemUI(player, profession);
            return;
        }
        const newId = response.formValues[0].trim();
        if (newId) {
            const newConfig = getConfig();
            const index = newConfig.items[profession].indexOf(item);
            newConfig.items[profession][index] = newId;
            saveConfig(newConfig);
            sendMessage(player, `§a${item}を${newId}に更新しました`);
        }
        showItemConfigUI(player, profession);
    });
}

// アイテム削除UI
function showDeleteItemUI(player, profession) {
    const config = getConfig();
    const items = config.items[profession];
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム削除`).body('削除するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(item));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showItemConfigUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        const newConfig = getConfig();
        newConfig.items[profession] = newConfig.items[profession].filter(item => item !== selectedItem);
        saveConfig(newConfig);
        sendMessage(player, `§a${selectedItem}を削除しました`);
        showItemConfigUI(player, profession);
    });
}

// レベル報酬設定UI
function showLevelRewardsConfigUI(player) {
    const form = new ActionFormData()
        .title('§1レベル報酬設定')
        .body('職業を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1家畜', 'textures/ui/normalicon1.png')
        .button('§1鉱夫', 'textures/ui/normalicon1.png')
        .button('§1林業', 'textures/ui/normalicon1.png')
        .button('§1農業', 'textures/ui/normalicon1.png')
        .button('§1冒険家', 'textures/ui/normalicon1.png')
        .button('§1釣り人', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showAdminUI(player);
            return;
        }
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
        const selectedProfession = professions[response.selection - 1];
        showLevelRewardLevelsUI(player, selectedProfession);
    });
}

// レベル報酬レベル選択UI
function showLevelRewardLevelsUI(player, profession) {
    const config = getConfig();
    const levels = Object.keys(config.levelRewards[profession])
        .map(Number)
        .sort((a, b) => a - b);
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル報酬設定`).body('設定するレベルを選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1新規レベル追加', 'textures/ui/plus.png'); // 新規追加ボタンを緑で強調

    levels.forEach(level => form.button(`§1レベル ${level}`, 'textures/ui/icon_book_writable.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showLevelRewardsConfigUI(player);
        } else if (response.selection === 1) {
            showAddLevelRewardUI(player, profession);
        } else {
            const selectedLevel = levels[response.selection - 2];
            showLevelRewardActionUI(player, profession, selectedLevel); // 編集/削除選択UIへ
        }
    });
}

// レベル報酬のアクション選択UI（編集/削除）
function showLevelRewardActionUI(player, profession, level) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル${level}`).body('アクションを選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1編集').button('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showLevelRewardLevelsUI(player, profession);
        } else if (response.selection === 1) {
            showLevelRewardDetailUI(player, profession, level);
        } else if (response.selection === 2) {
            showDeleteLevelRewardUI(player, profession, level);
        }
    });
}

// レベル報酬削除UI
function showDeleteLevelRewardUI(player, profession, level) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル${level} 削除`).body(`レベル${level}の報酬を削除しますか？`).button('§4削除').button('§1キャンセル');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 1) {
            showLevelRewardLevelsUI(player, profession);
        } else {
            const newConfig = getConfig();
            delete newConfig.levelRewards[profession][level];
            saveConfig(newConfig);
            sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベル${level}報酬を削除しました`);
            showLevelRewardLevelsUI(player, profession);
        }
    });
}

// 新規レベル報酬追加UI
function showAddLevelRewardUI(player, profession) {
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} 新規レベル報酬`).textField('レベル', 'レベルを入力 (例: 5)').textField('エフェクト ID', 'エフェクトID (例: night_vision)').textField('エフェクト 強さ', '強さ (例: 1)');

    form.show(player).then(response => {
        if (response.canceled) return;
        const [level, effId, effAmp] = response.formValues;
        const newConfig = getConfig();
        const levelNum = parseInt(level);
        if (isNaN(levelNum) || levelNum < 1) {
            sendMessage(player, '§c有効なレベルを入力してください', false);
            showLevelRewardLevelsUI(player, profession);
            return;
        }
        newConfig.levelRewards[profession][levelNum] = {
            effect1: effId ? { id: effId.trim(), amplifier: parseInt(effAmp) || 1 } : null,
        };
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベル${levelNum}報酬を追加しました`);
        showLevelRewardLevelsUI(player, profession);
    });
}

// レベル報酬詳細UI
function showLevelRewardDetailUI(player, profession, level) {
    const config = getConfig();
    const reward = config.levelRewards[profession][level];
    const form = new ModalFormData()
        .title(`${profession} レベル${level} 報酬編集`)
        .textField('エフェクト ID', 'エフェクトID', reward.effect1?.id || '')
        .textField('エフェクト 強さ', '強さ', reward.effect1?.amplifier.toString() || '1');

    form.show(player).then(response => {
        if (response.canceled) return;
        const [effId, effAmp] = response.formValues;
        const newConfig = getConfig();
        newConfig.levelRewards[profession][level] = {
            effect1: effId ? { id: effId.trim(), amplifier: parseInt(effAmp) || 1 } : null,
        };
        saveConfig(newConfig);
        sendMessage(player, `§a${profession}のレベル${level}報酬を更新しました`);
        showLevelRewardLevelsUI(player, profession);
    });
}

// プレイヤーUI（職業選択/ステータス確認/職業解除）
export function showPlayerUI(player) {
    const form = new ActionFormData()
        .title('§1職業')
        .body('アクションを選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1職業に就く', `textures/ui/normalicon1`)
        .button('§5ステータス確認', `textures/ui/normalicon1`)
        .button('§4職業解除', `textures/ui/normalicon1`)
        .button('§9報酬の受け取り', `textures/ui/normalicon1`)
        .button('§5エフェクトオン/オフ', `textures/ui/normalicon1`); // 新しいボタン
    if (player.hasTag('HARUPhoneOP')) {
        form.button('§0管理者設定', `textures/ui/operatorcontroller`);
    }
    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            player.runCommand('scriptevent haruphone1:apps');
        } else if (response.selection === 1) {
            showProfessionSelectUI(player);
        } else if (response.selection === 2) {
            showStatusUI(player);
        } else if (response.selection === 3) {
            showProfessionRemoveUI(player);
        } else if (response.selection === 4) {
            showProfessionRewardSelectUI(player);
        } else if (response.selection === 5) {
            showEffectToggleUI(player);
        } else if (response.selection === 6) {
            showAdminUI(player);
        }
    });
}

// エフェクトオン/オフUI（新規）
function showEffectToggleUI(player) {
    const professions = getPlayerProfessions(player);
    const form = new ActionFormData().title('§5エフェクトオン/オフ').body('エフェクトをオン/オフする職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    professions.forEach(prof => {
        form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        const selectedProfession = professions[response.selection - 1];
        showProfessionEffectToggleUI(player, selectedProfession);
    });
}

// 職業ごとのエフェクトオン/オフUI（新規）
function showProfessionEffectToggleUI(player, profession) {
    const level = player.getDynamicProperty(`${profession}_level`) || 1;
    const config = getConfig();
    const rewards = config.levelRewards[profession] || {};
    const availableLevels = Object.keys(rewards)
        .map(Number)
        .filter(lvl => lvl <= level && player.getDynamicProperty(`${profession}_selected_effect_${lvl}`));

    if (availableLevels.length === 0) {
        sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[profession]}でオン/オフ可能なエフェクトがありません`, false);
        showEffectToggleUI(player);
        return;
    }

    const form = new ActionFormData().title(`§4${PROFESSION_DISPLAY_NAMES[profession]} §1エフェクトオン/オフ`).body('エフェクトのオン/オフを切り替えてください').button('§l戻る', 'textures/ui/icon_import.png');

    availableLevels.forEach(lvl => {
        const selectedEffect = player.getDynamicProperty(`${profession}_selected_effect_${lvl}`);
        const isEnabled = player.getDynamicProperty(`${profession}_effect_enabled_${lvl}`) !== false;
        const status = isEnabled ? '§1オン' : '§4オフ';
        const reward = rewards[lvl];
        const effectStrength = reward.effect1 && reward.effect1.id === selectedEffect ? reward.effect1.amplifier : 1;
        form.button(`§0${selectedEffect} (強さ: ${effectStrength})\n${status}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showEffectToggleUI(player);
            return;
        }
        const selectedLevel = availableLevels[response.selection - 1];
        const isEnabled = player.getDynamicProperty(`${profession}_effect_enabled_${selectedLevel}`) !== false;
        player.setDynamicProperty(`${profession}_effect_enabled_${selectedLevel}`, !isEnabled);
        player.runCommandAsync(`effect ${player.name} clear`);
        applyProfessionEffects(player);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]} のエフェクトを${isEnabled ? '§cオフ' : '§eオン'}§aにしました`);
        showProfessionEffectToggleUI(player, profession);
    });
}

// 職業ごとの報酬選択UI
function showProfessionRewardSelectUI(player) {
    const professions = getPlayerProfessions(player);
    const form = new ActionFormData().title('§1報酬の受け取り').body('報酬を確認する職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    professions.forEach(prof => form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}`, 'textures/ui/normalicon1.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        const selectedProfession = professions[response.selection - 1];
        checkLevelRewards(player, selectedProfession);
    });
}

// 職業選択UI
function showProfessionSelectUI(player) {
    const config = getConfig();
    const currentProfessions = getPlayerProfessions(player);

    if (currentProfessions.length >= config.system.maxProfessions) {
        sendMessage(player, `§a最大職業数§r:§e${config.system.maxProfessions} §cに達しています先に職業を解除してください`, false);
        showPlayerUI(player);
        return;
    }

    const form = new ActionFormData()
        .title('§1職業選択')
        .body('就きたい職業を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1家畜', 'textures/ui/normalicon1.png')
        .button('§1鉱夫', 'textures/ui/normalicon1.png')
        .button('§1林業', 'textures/ui/normalicon1.png')
        .button('§1農業', 'textures/ui/normalicon1.png')
        .button('§1冒険家', 'textures/ui/normalicon1.png')
        .button('§1釣り人', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
        const selectedProfession = professions[response.selection - 1];

        if (currentProfessions.includes(selectedProfession)) {
            sendMessage(player, `§cすでに${PROFESSION_DISPLAY_NAMES[selectedProfession]}に就いています`, false);
            showProfessionSelectUI(player);
            return;
        }

        player.addTag(selectedProfession);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}に就きました`);
        applyProfessionEffects(player);
        showPlayerUI(player);
    });
}

// 職業解除UI
// 職業解除UI
function showProfessionRemoveUI(player) {
    const config = getConfig();
    const currentProfessions = getPlayerProfessions(player);
    let lastRemove = player.getDynamicProperty('profession_remove_time');

    // 初回の場合、現在の時刻をセットしてクールダウンを開始
    if (lastRemove === undefined) {
        lastRemove = Date.now();
        player.setDynamicProperty('profession_remove_time', lastRemove);
    }

    const now = Date.now();
    const daysSinceRemove = (now - lastRemove) / (1000 * 60 * 60 * 24);

    if (currentProfessions.length === 0) {
        sendMessage(player, '§c解除する職業がありません', false);
        showPlayerUI(player);
        return;
    }

    const form = new ActionFormData().title('§1職業解除').body('解除する職業を選択してください');

    form.button('§l戻る', 'textures/ui/icon_import.png');
    currentProfessions.forEach(prof => {
        const daysLeft = config.system.professionRemoveDays - daysSinceRemove;
        const label = daysLeft > 0 ? `§0残り §4${daysLeft.toFixed(1)}日` : '§5解除可能';
        form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}\n§r${label}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        const selectedProfession = currentProfessions[response.selection - 1];
        const daysLeft = config.system.professionRemoveDays - daysSinceRemove;
        if (daysLeft > 0) {
            sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[selectedProfession]}の解除まで${daysLeft.toFixed(1)}日必要です`, false);
            showProfessionRemoveUI(player);
            return;
        }
        player.removeTag(selectedProfession);
        player.setDynamicProperty('profession_remove_time', Date.now());
        player.setDynamicProperty(`${selectedProfession}_selected_effect`, null);
        player.runCommandAsync(`effect ${player.name} clear`);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}を解除しました`);
        showPlayerUI(player);
    });
}

// プレイヤーの職業を取得
function getPlayerProfessions(player) {
    const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
    return professions.filter(prof => player.hasTag(prof));
}

// ステータス確認UI
function showStatusUI(player) {
    const professions = getPlayerProfessions(player);
    let body = '§e現在の職業とレベル\n';
    professions.forEach(prof => {
        const level = player.getDynamicProperty(`${prof}_level`) || 1;
        const actions = player.getDynamicProperty(`${prof}_level_actions`) || 0;
        const config = getConfig();
        body += `§a${PROFESSION_DISPLAY_NAMES[prof]}§r: レベル§b${level} §rアクション §b${actions}§r/§b${config.levelUpActions[prof]}\n`;
        const rewards = config.levelRewards[prof] || {};
        Object.keys(rewards)
            .map(Number)
            .forEach(lvl => {
                if (lvl <= level) {
                    const selectedEffect = player.getDynamicProperty(`${prof}_selected_effect_${lvl}`);
                    if (selectedEffect) {
                        body += `  §cレベル${lvl}報酬§r: §d${selectedEffect}\n`;
                    }
                }
            });
    });

    const form = new ActionFormData()
        .title('§5ステータス')
        .body(body || '職業に就いていません')
        .button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (!response.canceled) {
            showPlayerUI(player);
        }
    });
}

// レベル報酬チェックと選択UI
function checkLevelRewards(player, profession) {
    const level = player.getDynamicProperty(`${profession}_level`) || 1;
    const config = getConfig();
    const rewards = config.levelRewards[profession] || {};
    const availableLevels = Object.keys(rewards)
        .map(Number)
        .filter(lvl => lvl <= level && !player.getDynamicProperty(`${profession}_selected_effect_${lvl}`));

    if (availableLevels.length === 0) {
        sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[profession]}で選択可能な報酬がありません`, false);
        showProfessionRewardSelectUI(player);
        return;
    }

    const form = new ActionFormData().title(`§4${PROFESSION_DISPLAY_NAMES[profession]} §1報酬の受け取り`).body('レベル報酬を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    availableLevels.forEach(lvl => {
        const reward = rewards[lvl];
        const effectText = reward.effect1 ? `\n§0${reward.effect1.id} (強さ: ${reward.effect1.amplifier})` : '\n§cエフェクトなし';
        form.button(`§1レベル ${lvl} §4報酬${effectText}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionRewardSelectUI(player);
            return;
        }
        const selectedLevel = availableLevels[response.selection - 1];
        showRewardSelectionUI(player, profession, selectedLevel);
    });
}

// 報酬選択UI
function showRewardSelectionUI(player, profession, level) {
    const config = getConfig();
    const reward = config.levelRewards[profession][level];
    if (reward.effect1) {
        player.setDynamicProperty(`${profession}_selected_effect_${level}`, reward.effect1.id);
        sendMessage(player, `§aレベル${level}のエフェクト${reward.effect1.id}を選択しました`);
        applyProfessionEffects(player);
    } else {
        sendMessage(player, `§cレベル${level}に有効なエフェクトがありません`, false);
    }
    showProfessionRewardSelectUI(player);
}
