import { world, system, ItemStack } from '@minecraft/server';
import { Business } from './system';
import { showPlayerUI } from './ui';

//スクリプトイベント
const RACE_EVENT_ID = 'haruapps:job';
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            showPlayerUI(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }

        if (eventData.id === 'op:job') {
            player.addTag('HARUPhoneOP');
            const objectives = world.scoreboard.getObjectives();
            const moneyObjective = objectives.find(obj => obj.id === 'money');
            if (!moneyObjective) {
                world.scoreboard.addObjective('money', '所持金');
            }
            world.setDynamicProperty('Job_Start', true);
            showPlayerUI(player);
            const players = world.getAllPlayers();
            for (const player of players) {
                if (world.getDynamicProperty('Job_Start') === true && !player.hasTag('Job_Member')) {
                    player.getComponent('inventory').container.addItem(new ItemStack('additem:job', 1));
                    player.runCommand(`scoreboard players set @s money 0`);
                    player.addTag('Job_Member');
                }
            }
        }

        if (eventData.id === 'stop:job') {
            world.setDynamicProperty('Job_Start', false);
            player.sendMessage('§r[§b職業システム§r] §b自動付与システムを無効にしました');
        }
    });
});

world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    system.run(() => {
        if (eventData.itemStack.typeId === 'additem:job') {
            showPlayerUI(player);
        }
    });
});

//スクリプト読み込み
Business();
