import { world, system } from '@minecraft/server';

const objectiveName = 'money';
const DEFAULT_CONFIG = {
    system: {
        professionRemoveDays: 7,
        maxProfessions: 2,
    },
    points: {
        livestock: {
            'minecraft:cow': 10,
            'minecraft:sheep': 10,
            'minecraft:pig': 10,
            'minecraft:chicken': 10,
            'minecraft:rabbit': 10,
            'minecraft:mooshroom': 15,
        },
        miner: {
            'minecraft:coal_ore': 20,
            'minecraft:iron_ore': 30,
            'minecraft:gold_ore': 40,
            'minecraft:diamond_ore': 50,
            'minecraft:lapis_ore': 30,
            'minecraft:redstone_ore': 30,
            'minecraft:emerald_ore': 50,
            'minecraft:copper_ore': 20,
            'minecraft:deepslate_coal_ore': 20,
            'minecraft:deepslate_iron_ore': 30,
            'minecraft:deepslate_gold_ore': 40,
            'minecraft:deepslate_diamond_ore': 50,
            'minecraft:deepslate_lapis_ore': 30,
            'minecraft:deepslate_redstone_ore': 30,
            'minecraft:deepslate_emerald_ore': 50,
            'minecraft:deepslate_copper_ore': 20,
            'minecraft:nether_quartz_ore': 25,
            'minecraft:nether_gold_ore': 35,
            'minecraft:ancient_debris': 60,
        },
        builder: {
            'minecraft:oak_log': 3,
            'minecraft:spruce_log': 3,
            'minecraft:birch_log': 3,
            'minecraft:jungle_log': 3,
            'minecraft:acacia_log': 3,
            'minecraft:dark_oak_log': 3,
            'minecraft:mangrove_log': 3,
            'minecraft:cherry_log': 3,
            'minecraft:stripped_oak_log': 3,
            'minecraft:stripped_spruce_log': 3,
            'minecraft:stripped_birch_log': 3,
            'minecraft:stripped_jungle_log': 3,
            'minecraft:stripped_acacia_log': 3,
            'minecraft:stripped_dark_oak_log': 3,
            'minecraft:stripped_mangrove_log': 3,
            'minecraft:stripped_cherry_log': 3,
            'minecraft:crimson_stem': 5,
            'minecraft:warped_stem': 5,
            'minecraft:stripped_crimson_stem': 5,
            'minecraft:stripped_warped_stem': 5,
        },
        farming: {
            'minecraft:wheat': 5,
            'minecraft:carrots': 5,
            'minecraft:potatoes': 5,
            'minecraft:beetroot': 5,
            'minecraft:pumpkin': 10,
            'minecraft:melon': 10,
            'minecraft:sugar_cane': 5,
            'minecraft:reeds': 5,
            'minecraft:sweet_berry_bush': 8,
        },
        adventurer: {
            'minecraft:zombie': 10,
            'minecraft:husk': 10,
            'minecraft:drowned': 10,
            'minecraft:skeleton': 10,
            'minecraft:stray': 10,
            'minecraft:spider': 10,
            'minecraft:cave_spider': 12,
            'minecraft:creeper': 15,
            'minecraft:enderman': 20,
            'minecraft:slime': 15,
            'minecraft:magma_cube': 15,
            'minecraft:ghast': 25,
            'minecraft:blaze': 20,
            'minecraft:wither_skeleton': 25,
            'minecraft:phantom': 20,
        },
        Angler: {
            'minecraft:cod': 10,
            'minecraft:salmon': 10,
            'minecraft:tropical_fish': 15,
            'minecraft:pufferfish': 15,
            'minecraft:enchanted_book': 50,
            'minecraft:bow': 30,
            'minecraft:leather': 20,
            'minecraft:fishing_rod': 30,
            'minecraft:name_tag': 50,
            'minecraft:saddle': 50,
            'minecraft:lily_pad': 20,
            'minecraft:nautilus_shell': 50,
        },
    },
    levelUpActions: {
        livestock: 20,
        miner: 30,
        builder: 30,
        farming: 25,
        adventurer: 10,
        Angler: 15,
    },
    items: {
        livestock: ['minecraft:cow', 'minecraft:sheep', 'minecraft:pig', 'minecraft:chicken', 'minecraft:rabbit', 'minecraft:mooshroom'],
        miner: [
            'minecraft:coal_ore',
            'minecraft:iron_ore',
            'minecraft:gold_ore',
            'minecraft:diamond_ore',
            'minecraft:lapis_ore',
            'minecraft:redstone_ore',
            'minecraft:emerald_ore',
            'minecraft:copper_ore',
            'minecraft:deepslate_coal_ore',
            'minecraft:deepslate_iron_ore',
            'minecraft:deepslate_gold_ore',
            'minecraft:deepslate_diamond_ore',
            'minecraft:deepslate_lapis_ore',
            'minecraft:deepslate_redstone_ore',
            'minecraft:deepslate_emerald_ore',
            'minecraft:deepslate_copper_ore',
            'minecraft:nether_quartz_ore',
            'minecraft:nether_gold_ore',
            'minecraft:ancient_debris',
        ],
        builder: [
            'minecraft:oak_log',
            'minecraft:spruce_log',
            'minecraft:birch_log',
            'minecraft:jungle_log',
            'minecraft:acacia_log',
            'minecraft:dark_oak_log',
            'minecraft:mangrove_log',
            'minecraft:cherry_log',
            'minecraft:stripped_oak_log',
            'minecraft:stripped_spruce_log',
            'minecraft:stripped_birch_log',
            'minecraft:stripped_jungle_log',
            'minecraft:stripped_acacia_log',
            'minecraft:stripped_dark_oak_log',
            'minecraft:stripped_mangrove_log',
            'minecraft:stripped_cherry_log',
            'minecraft:crimson_stem',
            'minecraft:warped_stem',
            'minecraft:stripped_crimson_stem',
            'minecraft:stripped_warped_stem',
        ],
        farming: ['minecraft:wheat', 'minecraft:carrots', 'minecraft:potatoes', 'minecraft:beetroot', 'minecraft:pumpkin', 'minecraft:melon', 'minecraft:sugar_cane', 'minecraft:reeds', 'minecraft:sweet_berry_bush'],
        adventurer: ['minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:skeleton', 'minecraft:stray', 'minecraft:spider', 'minecraft:cave_spider', 'minecraft:creeper', 'minecraft:enderman', 'minecraft:slime', 'minecraft:magma_cube', 'minecraft:ghast', 'minecraft:blaze', 'minecraft:wither_skeleton', 'minecraft:phantom'],
        Angler: ['minecraft:cod', 'minecraft:salmon', 'minecraft:tropical_fish', 'minecraft:pufferfish', 'minecraft:enchanted_book', 'minecraft:bow', 'minecraft:leather', 'minecraft:fishing_rod', 'minecraft:name_tag', 'minecraft:saddle', 'minecraft:lily_pad', 'minecraft:nautilus_shell'],
    },
    levelRewards: {
        livestock: {},
        miner: {},
        builder: {},
        farming: {},
        adventurer: {},
        Angler: {},
    },
};

// 職業の表示名マッピング
const PROFESSION_DISPLAY_NAMES = {
    livestock: '家畜',
    miner: '鉱夫',
    builder: '林業',
    farming: '農業',
    adventurer: '冒険家',
    Angler: '釣り人',
};

//設定データ
var config;

// 設定の初期化
function initializeConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    if (savedConfig === undefined) {
        config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
        world.setDynamicProperty('business_config', JSON.stringify(config));
    }
}

export function UpdateConfig() {
    config = getConfig();
}

// 設定の取得
function getConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    config = savedConfig ? JSON.parse(savedConfig) : DEFAULT_CONFIG;
    if (!config.levelRewards) {
        config.levelRewards = DEFAULT_CONFIG.levelRewards;
    } else {
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler'];
        professions.forEach(prof => {
            if (!config.levelRewards[prof]) {
                config.levelRewards[prof] = {};
            }
        });
    }
    return config;
}

// プレイヤーが設置したブロックの追跡（一時的）
let placedBlocks = new Map();

// ブロック設置データのクリーンアップ（2時間 = 7200000ms）
const BLOCK_EXPIRY_MS = 2 * 60 * 60 * 1000;

function cleanupExpiredBlocks() {
    const now = Date.now();
    for (const [key, data] of placedBlocks.entries()) {
        if (now - data.timestamp > BLOCK_EXPIRY_MS) {
            placedBlocks.delete(key);
        }
    }
}

// 定期的にクリーンアップを実行
system.runInterval(() => {
    cleanupExpiredBlocks();
}, 1200); // 1分ごとにチェック（20tick * 60秒）

// レベル表示用の関数
function updateLevelDisplay(player, profession, level, actions, currentActions, gainedPoints = 0) {
    const maxBars = 20; // 最大20本
    const actionsPerBar = Math.max(actions / maxBars, 1);
    const bars = Math.min(Math.floor(currentActions / actionsPerBar), maxBars); // 現在のバー数
    const displayBars = '|'.repeat(bars);

    player.onScreenDisplay.setActionBar(`§a${PROFESSION_DISPLAY_NAMES[profession]} §rLevel:§b${level} §c${displayBars} §e+${gainedPoints}P`);
}

// レベルアップチェックとメッセージ
const playerPointsMap = new Map(); // プレイヤーごとのポイントを保持
function checkLevelUp(player, profession, levelUpActions, propertyKey, gainedPoints) {
    const playerId = player.id; // プレイヤーごとに一意なIDを使用
    let currentActions = player.getDynamicProperty(`${propertyKey}_actions`) || 0;
    let totalPoints = playerPointsMap.get(playerId)?.totalPoints || 0;
    currentActions += 1;
    totalPoints += gainedPoints;

    const currentLevel = player.getDynamicProperty(propertyKey) || 1;
    const requiredActions = levelUpActions;

    player.setDynamicProperty(`${propertyKey}_actions`, currentActions);
    playerPointsMap.set(playerId, { totalPoints, lastAction: currentActions });

    // 2秒後にポイントをリセット（アクションバーは更新しない）
    system.runTimeout(() => {
        const currentData = playerPointsMap.get(playerId);
        if (currentData && currentData.lastAction === currentActions) {
            playerPointsMap.set(playerId, { totalPoints: 0, lastAction: currentActions });
        }
    }, 40); // 2秒（20tick * 2）

    if (currentActions >= requiredActions) {
        const newLevel = currentLevel + 1;
        player.setDynamicProperty(propertyKey, newLevel);
        player.setDynamicProperty(`${propertyKey}_actions`, 0);
        playerPointsMap.set(playerId, { totalPoints: gainedPoints, lastAction: 0 }); // 最後のgainedPointsを保持
        updateLevelDisplay(player, profession, newLevel, levelUpActions, 0, gainedPoints); // gainedPointsを表示

        player.sendMessage(`[§b職業システム§r] §e${PROFESSION_DISPLAY_NAMES[profession]}§aがレベル§c${newLevel}§aに到達`);
        player.playSound('random.toast', { pitch: 2.9, volume: 1.8 });

        config = getConfig();
        const availableLevels = Object.keys(config.levelRewards[profession]).map(Number);
        if (availableLevels.includes(newLevel)) {
            player.sendMessage(`[§b職業システム§r] §d報酬を受け取れます`);
        }
    } else {
        updateLevelDisplay(player, profession, currentLevel, levelUpActions, currentActions, totalPoints);
    }
}

// シルクタッチチェック
function hasSilkTouch(player) {
    const inventory = player.getComponent('minecraft:inventory');
    if (!inventory) {
        return false;
    }
    const item = inventory.container.getSlot(player.selectedSlotIndex).getItem();
    if (!item) {
        return false;
    }
    const enchantmentsComponent = item.getComponent('minecraft:enchantable');
    if (enchantmentsComponent == undefined) {
        return false;
    }
    const enchantments = enchantmentsComponent.getEnchantments();
    if (enchantments[0]?.type.id.toLowerCase() === 'silk_touch') {
        return true;
    }
    return false;
}

export function Business() {
    initializeConfig();
    config = getConfig();

    // 家畜
    world.afterEvents.entityDie.subscribe(event => {
        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        if (player?.typeId === 'minecraft:player' && player.hasTag('livestock') && config.items.livestock.includes(Entity.typeId)) {
            const objective = world.scoreboard.getObjective(objectiveName);
            const points = config.points.livestock[Entity.typeId] || 10;
            objective.addScore(player.scoreboardIdentity, points);
            checkLevelUp(player, 'livestock', config.levelUpActions.livestock, 'livestock_level', points);
        }
    });

    // 鉱石
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;

        if (player?.typeId === 'minecraft:player' && player.hasTag('miner') && config.items.miner.includes(block.typeId) && !hasSilkTouch(player)) {
            system.run(() => {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.points.miner[block.typeId] || 20;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'miner', config.levelUpActions.miner, 'miner_level', points);
            });
        }
    });

    // 原木（林業）
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        if (config.items.builder.includes(block.typeId)) {
            const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;
            placedBlocks.set(key, { timestamp: Date.now() });
        }
    });

    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;

        if (player?.typeId === 'minecraft:player' && player.hasTag('builder') && config.items.builder.includes(block.typeId)) {
            if (!placedBlocks.has(key)) {
                system.run(() => {
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.points.builder[block.typeId] || 3;
                    objective.addScore(player.scoreboardIdentity, points);
                    checkLevelUp(player, 'builder', config.levelUpActions.builder, 'builder_level', points);
                });
            }
            placedBlocks.delete(key);
        }
    });

    // 農業
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;

        if (player?.typeId === 'minecraft:player' && player.hasTag('farming') && config.items.farming.includes(block.typeId)) {
            system.run(() => {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.points.farming[block.typeId] || 5;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'farming', config.levelUpActions.farming, 'farming_level', points);
            });
        }
    });

    // 冒険家
    world.afterEvents.entityDie.subscribe(event => {
        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        if (player?.typeId === 'minecraft:player' && player.hasTag('adventurer') && config.items.adventurer.includes(Entity.typeId)) {
            const objective = world.scoreboard.getObjective(objectiveName);
            const points = config.points.adventurer[Entity.typeId] || 10;
            objective.addScore(player.scoreboardIdentity, points);
            checkLevelUp(player, 'adventurer', config.levelUpActions.adventurer, 'adventurer_level', points);
        }
    });

    // 釣り人
    let AnglerPlayers = new Set(); // 釣り中のプレイヤー名を保持
    const fishingEntityIds = new Map(); // プレイヤー名と釣りフックの紐づけ
    const recentCasts = new Map(); // プレイヤー名と最後に釣り竿を使用した時間を保持

    // 釣り竿使用イベント
    world.beforeEvents.itemUse.subscribe(ev => {
        const { source, itemStack } = ev;
        if (source.typeId !== 'minecraft:player' || !source.hasTag('Angler') || itemStack.typeId !== 'minecraft:fishing_rod') return;

        const player = source;
        const playerName = player.name;
        system.runTimeout(() => {
            // 古いフックをクリア
            if (fishingEntityIds.has(playerName)) {
                fishingEntityIds.delete(playerName);
            }

            // キャスト時間をミリ秒で記録
            recentCasts.set(playerName, Date.now());
            AnglerPlayers.add(playerName);
        }, 10);
    });

    // フックスポーンイベント
    world.afterEvents.entitySpawn.subscribe(ev => {
        const { entity } = ev;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        system.runTimeout(() => {
            // フックがまだ存在するか確認
            if (!entity.isValid()) return;

            // フックの位置に水があるかチェック
            const block = entity.dimension.getBlock(entity.location);
            if (!block || block.typeId !== 'minecraft:water') {
                return;
            }

            // 近くのプレイヤーを検索
            const players = entity.dimension.getPlayers({
                location: entity.location,
                maxDistance: 7.0, // 釣り竿の最大距離
            });

            let closestPlayer = null;
            let minDistance = Infinity;
            let latestCastTime = -Infinity;

            for (const player of players) {
                if (!player.hasTag('Angler') || !recentCasts.has(player.name)) continue;

                // キャストから2秒以内のフックのみ考慮
                const castTime = recentCasts.get(player.name) || 0;
                if (Date.now() - castTime > 2000) continue;

                // プレイヤーからフックへの距離
                const distance = Math.sqrt((player.location.x - entity.location.x) ** 2 + (player.location.y - entity.location.y) ** 2 + (player.location.z - entity.location.z) ** 2);

                // プレイヤーの視線方向とフックの位置関係を確認
                const viewVector = player.getViewDirection();
                const playerPos = player.location;
                const hookPos = entity.location;
                const toHookVector = {
                    x: hookPos.x - playerPos.x,
                    y: hookPos.y - playerPos.y,
                    z: hookPos.z - playerPos.z,
                };
                const dotProduct = viewVector.x * toHookVector.x + viewVector.y * toHookVector.y + viewVector.z * toHookVector.z;
                const viewMagnitude = Math.sqrt(viewVector.x ** 2 + viewVector.y ** 2 + viewVector.z ** 2);
                const hookMagnitude = Math.sqrt(toHookVector.x ** 2 + toHookVector.y ** 2 + toHookVector.z ** 2);
                const cosTheta = hookMagnitude > 0 ? dotProduct / (viewMagnitude * hookMagnitude) : 0;

                // 視線とフックの方向が一致しているか（cosθが0.5以上）
                if (cosTheta < 0.5) continue;

                if (distance < minDistance && castTime > latestCastTime) {
                    minDistance = distance;
                    latestCastTime = castTime;
                    closestPlayer = player;
                }
            }

            if (closestPlayer) {
                fishingEntityIds.set(closestPlayer.name, entity.id);
            }
        }, 20); // 1秒待機してフックが水中に安定しているか確認
    });

    // フック削除イベント
    world.beforeEvents.entityRemove.subscribe(event => {
        const entity = event.removedEntity;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        let targetPlayer = null;
        let targetPlayerName = null;
        for (const [playerName, hookId] of fishingEntityIds.entries()) {
            if (hookId === entity.id) {
                targetPlayerName = playerName;
                targetPlayer = world.getAllPlayers().find(p => p.name === playerName);
                fishingEntityIds.delete(playerName);
                break;
            }
        }

        if (!targetPlayer || !targetPlayer.hasTag('Angler')) {
            if (targetPlayerName) {
                AnglerPlayers.delete(targetPlayerName);
                recentCasts.delete(targetPlayerName);
            }
            return;
        }

        // フック位置にドロップしたアイテムをチェック
        const entities = entity.dimension.getEntities({
            location: entity.location,
            maxDistance: 1,
            type: 'minecraft:item',
        });
        for (const item of entities) {
            const itemStack = item.getComponent('minecraft:item')?.itemStack;
            if (itemStack && config.items.Angler.includes(itemStack.typeId)) {
                // アイテムが水面に近いかチェック
                const block = item.dimension.getBlock(item.location);
                if (!block || block.typeId !== 'minecraft:water') {
                    continue;
                }

                system.run(() => {
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.points.Angler[itemStack.typeId] || 10;
                    objective.addScore(targetPlayer.scoreboardIdentity, points);
                    checkLevelUp(targetPlayer, 'Angler', config.levelUpActions.Angler, 'Angler_level', points);
                });
                break;
            }
        }

        // プレイヤーの状態をクリア
        AnglerPlayers.delete(targetPlayerName);
        recentCasts.delete(targetPlayerName);
    });
}
