import { world,system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}

export function Atm(eventData){
    const player = eventData.player
        player_Cash_Data[player.id]={} 
        system.run(() => {
             if (!player_Cash_Data[player.id].AtmStop) {
                player_Cash_Data[player.id].AtmStop = true
                //ここから実行

                //残高取得
                player_Cash_Data[player.id].Myscore_A = world.scoreboard.getObjective("account").getScore(eventData.player.scoreboardIdentity);
                player_Cash_Data[player.id].Myscore_B = world.scoreboard.getObjective("money").getScore(eventData.player.scoreboardIdentity);

                //時刻を取得
                const now = new Date();
                const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
                const hours = String(japanTime.getUTCHours()).padStart(2, "0");
                const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
                var time = `${hours}:${minutes}`

                var form = new ActionFormData();
                form.title("ATM");
                form.body(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}`);
                form.button("§5預け入れ");
                form.button("§1引き出し");
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            var form = new ModalFormData();
                            form.title("ATM");
                            form.textField(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§r預け入れ金額(半角数字)`, "0")
                            form.show(eventData.player).then(r => {
                                if (r.canceled) {
                                    return;
                                };
                                if(isNaN(r.formValues[0])){
                                    player.sendMessage(`§r[§bATM§r] §4半角数字で入力してください`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }

                                //預け入れ金額を保存
                                player_Cash_Data[player.id].selection_money = 0;
                                if(r.formValues[0]=='') {
                                    player_Cash_Data[player.id].selection_money = 0
                                }else{
                                    player_Cash_Data[player.id].selection_money = Number(r.formValues[0])
                                }
                                

                                if (player_Cash_Data[player.id].selection_money>100000000){
                                    player.sendMessage(`§r[§bATM§r] §41億以下で設定してください`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }
                                if (player_Cash_Data[player.id].selection_money<0){
                                    player.sendMessage(`§r[§bATM§r] §40以下は設定できません`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    }); 
                                    return;
                                }
   
                                //処理
                                if(player_Cash_Data[player.id].Myscore_B >= player_Cash_Data[player.id].selection_money){
                                    eventData.player.runCommand(`scoreboard players add @s account ${player_Cash_Data[player.id].selection_money}`)
                                    eventData.player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].selection_money}`)
                                    player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}§a預け入れました`)
                                    player.playSound("random.toast", {
                                        pitch: 1.7, 
                                        volume: 1.0
                                    });  
                                }else{
                                    player.sendMessage(`§r[§bATM§r] §4Moneyが不足しています`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                }
                            }
                        )  
                        break;
                        case 1:
                            var form = new ModalFormData();
                            form.title("ATM");
                            form.textField(`§l§b${time}\n§r§s\n§6>>>§e口座残高§r:§s${player_Cash_Data[player.id].Myscore_A}\n§6>>>§aHARUPAY残高§r:§s${player_Cash_Data[player.id].Myscore_B}\n\n§r引き出し金額(半角数字)`, "0")
                            form.show(eventData.player).then(r => {
                                if (r.canceled) {
                                    return;
                                };
                                if(isNaN(r.formValues[0])){
                                    player.sendMessage(`§r[§bATM§r] §4半角数字で入力してください`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }

                                //預け入れ金額を保存
                                player_Cash_Data[player.id].selection_money = 0;
                                if(r.formValues[0]=='') {
                                    player_Cash_Data[player.id].selection_money = 0
                                }else{
                                    player_Cash_Data[player.id].selection_money = Number(r.formValues[0])
                                }
                                
                                if (player_Cash_Data[player.id].selection_money>100000000){
                                    player.sendMessage(`§r[§bATM§r] §41億以下で設定してください`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }
                                if (player_Cash_Data[player.id].selection_money<0){
                                    player.sendMessage(`§r[§bATM§r] §40以下は設定できません`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                    return;
                                }
   
                                //処理
                                if(player_Cash_Data[player.id].Myscore_A >= player_Cash_Data[player.id].selection_money){
                                    eventData.player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].selection_money}`)
                                    eventData.player.runCommand(`scoreboard players remove @s account ${player_Cash_Data[player.id].selection_money}`)
                                    player.sendMessage(`§r[§bATM§r] §b${player_Cash_Data[player.id].selection_money}§a引き出しました`)
                                    player.playSound("random.toast", {
                                        pitch: 1.7, 
                                        volume: 1.0
                                    });  
                                }else{
                                    player.sendMessage(`§r[§bATM§r] §4Moneyが不足しています`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                }
                            }
                        )  
                        break;
                    }
                })
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.id].AtmStop = false
                }, 20); 
        }
    })
}