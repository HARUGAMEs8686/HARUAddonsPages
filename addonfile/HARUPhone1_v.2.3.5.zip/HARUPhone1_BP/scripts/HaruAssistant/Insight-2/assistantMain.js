import { world, system } from "@minecraft/server";

//一時データ
var player_Cash_Data = {}
// assistantMain.js
import { detectTopic, getTopicResponse, topicData } from './topics.js';
import { detectCasualPattern, getCasualResponse } from './casualConversations.js';
import { ModalFormData } from "@minecraft/server-ui";

// グローバル学習データ
let globalLearningData = world.getDynamicProperty("globalLearningData") ? JSON.parse(world.getDynamicProperty("globalLearningData")) : {
    commonTopics: {},
    commonWords: [],
    wordAssociations: {},
    wordMeanings: {},
    pastConversations: {}
};

// プレイヤーごとのチャット履歴管理
const MAX_HISTORY = 5;

// プレイヤーデータの初期化
function initializePlayerData(player) {
    if (!player_Cash_Data) {
        player_Cash_Data = {};
    }

    let chatHistory = player_Cash_Data[player.id]?.assistantHistory || [];
    let learningData = player_Cash_Data[player.id]?.learningData || {
        prefersDetail: false,
        frequentTopics: {},
        favoriteWords: [],
        lastContext: null,
        personalAssociations: {},
        personalMeanings: {},
        mood: "neutral",
        recentTopics: [],
        convoDepth: 0,
        knownQuestions: {},
        awaitingMeaning: null // 意味を待っている単語
    };

    // 初回メッセージ
    if (!chatHistory.length) {
        chatHistory.push(`§e[HARUassistant] こんにちは、${player.name}さん！よろしくお願いいたします。`);
        player.playSound("random.orb", { pitch: 1.5, volume: 1.0 });
    }

    if (!player_Cash_Data[player.id]) player_Cash_Data[player.id] = {};
    player_Cash_Data[player.id].assistantHistory = chatHistory;
    player_Cash_Data[player.id].learningData = learningData;

    return { chatHistory, learningData };
}

// 未知の単語を抽出する関数
function extractUnknownWords(message) {
    if (typeof message !== "string" || !message) return [];
    let words = message.split(/[\s、。！？って]+/).filter(w => w && w.length > 1);
    const knownWords = Object.values(topicData.detectKeywords).flat();
    return words.filter(word => !knownWords.includes(word.toLowerCase()));
}

// 意味と関連性の学習（強化版）
function learnAssociationsAndMeanings(message, unknownWords, learningData) {
    if (typeof message !== "string" || !message) {
        return;
    }

    const words = message.split(/[\s、。！？って]+/).filter(w => w && w.length > 1);
    if (!words.length) {
        return;
    }

    // 関連性の学習
    for (let i = 0; i < words.length - 1; i++) {
        const word1 = words[i];
        const word2 = words[i + 1];
        if (typeof word1 !== "string" || typeof word2 !== "string") {
            continue;
        }

        if (!learningData.personalAssociations) {
            learningData.personalAssociations = {};
        }
        learningData.personalAssociations[word1] = learningData.personalAssociations[word1] || {};
        learningData.personalAssociations[word1][word2] = (learningData.personalAssociations[word1][word2] || 0) + 1;

        if (!globalLearningData.wordAssociations) {
            globalLearningData.wordAssociations = {};
        }
        globalLearningData.wordAssociations[word1] = globalLearningData.wordAssociations[word1] || {};
        globalLearningData.wordAssociations[word1][word2] = (globalLearningData.wordAssociations[word1][word2] || 0) + 1;
    }

    // 「〇〇って何？」の形式を検出して意味を待つ
    const whatIsMatch = message.match(/(.+)って何/);
    if (whatIsMatch && whatIsMatch[1]) {
        const word = whatIsMatch[1].trim();
        learningData.awaitingMeaning = word;
    }

    // 意味の学習（「〇〇って△△」の形式）
    if (message.includes("って") && !message.includes("って何")) {
        const parts = message.split("って");
        const word = parts[0]?.trim();
        const meaning = parts[1]?.trim() || "不明";
        if (typeof word !== "string" || !word || !meaning) {
            return;
        }

        if (!learningData.personalMeanings) {
            learningData.personalMeanings = {};
        }
        learningData.personalMeanings[word] = meaning;

        if (!globalLearningData.wordMeanings) {
            globalLearningData.wordMeanings = {};
        }
        if (!globalLearningData.wordMeanings[word]) {
            globalLearningData.wordMeanings[word] = { meaning: meaning, confidence: 0.5, sourceCount: 1 };
        } else {
            const existing = globalLearningData.wordMeanings[word];
            if (!existing) {
                globalLearningData.wordMeanings[word] = { meaning: meaning, confidence: 0.5, sourceCount: 1 };
            } else if (existing.meaning === meaning) {
                existing.sourceCount = (existing.sourceCount || 0) + 1;
                existing.confidence = Math.min(1.0, (existing.confidence || 0) + 0.1);
            } else {
                existing.confidence = (existing.confidence || 1.0) - 0.1;
                if (existing.confidence < 0.3) {
                    existing.needsReconfirm = true;
                }
            }
        }

        // 意味を待っていた単語と一致したら待機状態を解除
        if (learningData.awaitingMeaning === word) {
            learningData.awaitingMeaning = null;

            // 過去の質問を更新
            if (learningData.knownQuestions[`${word}って何`]) {
                learningData.knownQuestions[`${word}って何`] = [`${word}は${meaning}という意味ですよね？`];
            }
        }
    }

    // 気分を推測
    if (message.match(/(疲れた|眠い|だるい|つかれた|ねむい)/)) {
        learningData.mood = "tired";
    } else if (message.match(/(元気|楽しい|嬉しい|うれしい|たのしい)/)) {
        learningData.mood = "happy";
    } else if (message.match(/(悲しい|辛い|つらい|かなしい)/)) {
        learningData.mood = "sad";
    } else {
        learningData.mood = "neutral";
    }

    // 質問と応答の学習
    if (!globalLearningData.pastConversations) {
        globalLearningData.pastConversations = {};
    }
    globalLearningData.pastConversations[message] = globalLearningData.pastConversations[message] || [];
    if (!learningData.knownQuestions) {
        learningData.knownQuestions = {};
    }
    learningData.knownQuestions[message] = learningData.knownQuestions[message] || [];
}

// 動的応答生成関数（学習データを活用）
function generateResponse(message, currentTopic, unknownWords, player, learningData) {
    let response = `§e[HARUassistant] `;

    // 過去の質問をチェック
    if (learningData.knownQuestions[message] && learningData.knownQuestions[message].length > 0) {
        const pastResponse = learningData.knownQuestions[message][learningData.knownQuestions[message].length - 1];
        response += `以前も同じことをお尋ねになりましたね。${pastResponse} 何か他にお聞きになりたいことはありますか？`;
        return response;
    }

    // 意味を待っている状態での応答
    if (learningData.awaitingMeaning) {
        const awaitingWord = learningData.awaitingMeaning;
        if (!message.includes("って") || message.includes("って何")) {
            response += `${player.name}さん、「${awaitingWord}」の意味を教えていただけますか？`;
            return response;
        }
    }

    // トピックがある場合
    if (currentTopic) {
        const topicResponse = getTopicResponse(currentTopic, player.name, learningData.prefersDetail);
        response += topicResponse;
        response += ` ${player.name}さん、他に知りたいことがあればお気軽にお尋ねくださいね。`;
        if (learningData.recentTopics.includes(currentTopic)) {
            response += `\n§e最近、${currentTopic}についてよくお話ししていますね。もっと詳しくお話ししますか？`;
        }
        learningData.recentTopics = [...new Set([currentTopic, ...learningData.recentTopics])].slice(0, 3);
    }
    // 日常会話パターンがある場合
    else {
        const casualPattern = detectCasualPattern(message);
        if (casualPattern) {
            const casualResponse = getCasualResponse(casualPattern, player.name, message);
            response += casualResponse;
        }
        // 未知の単語がある場合
        else if (unknownWords.length > 0) {
            const word = unknownWords[0];
            const wordData = globalLearningData.wordMeanings[word];

            if (wordData && (wordData.confidence >= 0.5 || wordData.sourceCount > 0)) { // 条件を緩和
                response += `${player.name}さん、「${word}」は${wordData.meaning}という意味ですよね？`;
                response += ` 以前教えていただいた気がしますが、合っていますか？`;
                if (learningData.personalAssociations[word]) {
                    const relatedWords = Object.keys(learningData.personalAssociations[word]);
                    const mostRelated = relatedWords.sort((a, b) => (learningData.personalAssociations[word][b] || 0) - (learningData.personalAssociations[word][a] || 0))[0];
                    if (mostRelated) {
                        response += ` そういえば、${mostRelated}という言葉と一緒に使っていたことがありましたね。関連するお話でしょうか？`;
                    }
                }
            } else if (wordData && wordData.needsReconfirm) {
                response += `${player.name}さん、「${word}」は${wordData.meaning}と伺いましたが、少し自信がありません。`;
                response += ` もう一度教えていただけますか？`;
            } else {
                response += `${player.name}さん、「${word}」というのは初めて聞きました。`;
                response += ` どのような意味か教えていただけると嬉しいです。`;
            }
        }
        // 対応できない場合
        else {
            response += `${player.name}さん、申し訳ありません、ちょっとよく分からなくて…。`;
            response += ` もう少し詳しく教えていただけると助かります。`;
            if (learningData.lastContext?.topic) {
                response += ` 少し前は${learningData.lastContext.topic}についてお話ししていましたね。そちらに関係ありますか？`;
                if (learningData.personalAssociations[learningData.lastContext.message]) {
                    const relatedWords = Object.keys(learningData.personalAssociations[learningData.lastContext.message]);
                    const mostRelated = relatedWords.sort((a, b) => (learningData.personalAssociations[learningData.lastContext.message][b] || 0) - (learningData.personalAssociations[learningData.lastContext.message][a] || 0))[0];
                    if (mostRelated) {
                        response += ` そういえば、${mostRelated}という言葉も出てきましたね。そちらのお話をしましょうか？`;
                    }
                }
            } else if (learningData.recentTopics.length > 0) {
                response += ` 最近は${learningData.recentTopics[0]}のお話をしていましたね。そちらのお話を続けますか？`;
            }
        }
    }

    // 学習データに記録
    learningData.knownQuestions[message] = learningData.knownQuestions[message] || [];
    learningData.knownQuestions[message].push(response.replace("§e[HARUassistant] ", ""));

    return response;
}

// チャットループ関数
function chatLoop2(player, eventData) {
    if (!player || typeof player !== "object") {
        return;
    }

    const { chatHistory, learningData } = initializePlayerData(player);

    let chatForm = new ModalFormData();
    chatForm.title("§1HARUassistant");

    let displayHistory = chatHistory.slice(-MAX_HISTORY).map(line => {
        if (line.startsWith("§7")) {
            return `§7>> ${line.replace(`§7[${player.name}] `, "")}§r`;
        } else {
            let formattedLine = line.replace("§e[HARUassistant] ", "§e[HARUassistant] §r");
            if (formattedLine.includes("嬉しい")) {
                formattedLine = formattedLine.replace("嬉しい", "§a嬉しい§r");
            } else if (formattedLine.includes("申し訳")) {
                formattedLine = formattedLine.replace("申し訳", "§c申し訳§r");
            }
            return formattedLine;
        }
    }).join("\n§r\n");

    const label = `§l§b=== チャット履歴 ===§r\n${displayHistory || "§7（まだ何もお話ししていません）"}\n§l§b=================`;
    const placeholder = "何かお話ししたいことはありますか？お気軽にどうぞ！";

    chatForm.textField(label, placeholder);

    chatForm.show(player).then(r => {
        if (r.canceled) {
            chatHistory.push(`§e[HARUassistant] そうですか、${player.name}さん、またお話ししたくなったらお呼びくださいね！`);
            player.playSound("random.orb", { pitch: 0.8, volume: 1.0 });
            if (typeof HARUPhone1 === "function") {
                HARUPhone1(eventData);
            } else {
            }
            return;
        }

        const message = r.formValues[0]?.trim().toLowerCase() || "";
        let response = "";

        if (message === "exit") {
            response = `§e[HARUassistant] では、${player.name}さん、またお会いしましょう！お話しできて楽しかったです。`;
            chatHistory.push(response);
            player.playSound("random.orb", { pitch: 0.8, volume: 1.0 });
            if (typeof HARUPhone1 === "function") {
                HARUPhone1(eventData);
            } else {
            }
            return;
        }

        const currentTopic = detectTopic(message);
        const unknownWords = extractUnknownWords(message);

        try {
            if (currentTopic) {
                learningData.frequentTopics[currentTopic] = (learningData.frequentTopics[currentTopic] || 0) + 1;
                if (message.includes("もっと") || message.includes("詳しく")) {
                    learningData.prefersDetail = true;
                }
            }
            if (Array.isArray(unknownWords) && unknownWords.length > 0) {
                learningData.favoriteWords = [...new Set([...learningData.favoriteWords, ...unknownWords])].slice(-10);
                learnAssociationsAndMeanings(message, unknownWords, learningData);
            }
            if (currentTopic) {
                globalLearningData.commonTopics[currentTopic] = (globalLearningData.commonTopics[currentTopic] || 0) + 1;
            }
            if (Array.isArray(unknownWords) && unknownWords.length > 0) {
                globalLearningData.commonWords = [...new Set([...globalLearningData.commonWords, ...unknownWords])].slice(-20);
            }
        } catch (e) {
            response = `§e[HARUassistant] ${player.name}さん、申し訳ありません、ちょっと処理に失敗してしまいました。でも大丈夫ですよ、何かお話ししたいことありますか？`;
        }

        learningData.lastContext = { topic: currentTopic, message: message };
        response = response || generateResponse(message, currentTopic, unknownWords, player, learningData);

        chatHistory.push(`§7[${player.name}] ${message}`);
        chatHistory.push(response);
        player.playSound("random.toast", { pitch: 1.7, volume: 1.0 });

        player_Cash_Data[player.id].assistantHistory = chatHistory;
        player_Cash_Data[player.id].learningData = learningData;
        world.setDynamicProperty("globalLearningData", JSON.stringify(globalLearningData));

        chatLoop2(player, eventData);
    }).catch(e => {
        chatHistory.push(`§e[HARUassistant] 申し訳ありません、${player.name}さん、エラーが出てしまいました…。詳細: ${e.message || "不明"} またお試しくださいね。`);
        world.setDynamicProperty("globalLearningData", JSON.stringify(globalLearningData));
        if (typeof HARUPhone1 === "function") {
            HARUPhone1(eventData);
        } else {
        }
    });
}

export { chatLoop2 };