import { world, system } from "@minecraft/server";
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";

var  player_Cash_Data = {}
export function Advance(eventData){
    system.run(() => {
        const player = eventData.source;
        if(!player.hasTag('advance_member')){
            var form = new ActionFormData();
            form.title("Advance");
            form.body(`サービスを選択してください`);
            form.button(`§9Advanceアカウント作成`);
            form.button(`§2Advanceアカウントにログイン`);
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = r.selection;
                switch (response) {
                    case 0:
                        var form = new ModalFormData();
                        form.title("Advance");
                        form.textField("会社名(店名)", ``)
                        form.textField("会社(店)の詳細", ``)
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            if(r.formValues[0]==''){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4入力されていない項目があります"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            var advance_member = world.getDynamicProperty('advance_member')
                            if(advance_member==undefined){
                                var advance_member_system2=[]
                            }else{
                            var advance_member_system2 = JSON.parse(advance_member);
                            }
                            for (let i = 0; i < advance_member_system2.length; i++){
                                if(advance_member_system2[i][1]==r.formValues[0]){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4この会社名は既に使われています"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                            }
                            advance_member_system2.push([player.name,r.formValues[0],r.formValues[1],0,[]])
                            const advance_member_system3 = JSON.stringify(advance_member_system2);
                            world.setDynamicProperty('advance_member',advance_member_system3)
                            player.setDynamicProperty('advance_member_data',r.formValues[0])
                            player.runCommand('tag @s add advance_member')
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §aアカウントを作成しました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        })
                    break;
                    case 1:
                        var advance_member = world.getDynamicProperty('advance_member')
                            if(advance_member==undefined){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4ログインできるアカウントがありません"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }else{
                            var advance_member_system2 = JSON.parse(advance_member);
                            }
                            var advance_member_system3 = []
                            var advance_member_cash1 = 0
                            var form = new ActionFormData();
                            form.title("Advance");
                            form.body(`アカウントを選択してください`);
                            for (let i = 0; i < advance_member_system2.length; i++){
                                if(advance_member_system2[i][0]==player.name){
                                    form.button(`${advance_member_system2[i][1]}`);
                                    advance_member_system3.push(i)
                                    advance_member_cash1 = 1
                                }
                            }
                            if(advance_member_cash1 == 0){
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4ログインできるアカウントがありません"}]}`)
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                return;
                            }
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                player.setDynamicProperty('advance_member_data',advance_member_system2[advance_member_system3[response]][1])
                                player.runCommand('tag @s add advance_member')
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §aログインしました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                            })
                    break;
                }
            })  
        }else{
            var advance_member_data = player.getDynamicProperty('advance_member_data')
            var advance_member = world.getDynamicProperty('advance_member')
            var advance_member_system2 = JSON.parse(advance_member);
            for (let i = 0; i < advance_member_system2.length; i++){
                if(advance_member_system2[i][1]==advance_member_data){
                    var advance_id = i
                }
            }
        var form = new ActionFormData();
        form.title("Advance");
        form.body(`§r会社名(店名):§b${advance_member_system2[advance_id][1]}\n§r資産:§a${advance_member_system2[advance_id][3]}\n§e-------------\n§b[アプリ一覧]`);
        form.button(`§4ログアウト`);
        form.button(`§9配送完了設定`);
        form.button(`§2資産からHARUPAYに送信`);
        form.button(`§3商品の追加/編集/削除`);
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    player.runCommand('tag @s remove advance_member')
                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §aログアウトしました"}]}`)
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                break;
                case 1:
                    var advance_member_data = player.getDynamicProperty('advance_member_data')
                    var advance_shop = world.getDynamicProperty('advance_shop')
                    var advance_id = -1;
                    if(advance_shop==undefined){
                        var advance_shop_system2=[]
                    }else{
                    var advance_shop_system2 = JSON.parse(advance_shop);
                    }
                    for (let i = 0; i < advance_shop_system2.length; i++){
                        if(advance_shop_system2[i][0]==advance_member_data){
                            advance_id = i
                        }
                    }
                    if(advance_id == -1){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4配送未完了の商品がありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        return;
                    }
                    var advance_id_cash = [];
                    var advance_id_cash1 = [];
                    var advance_id_cash2 = [];
                    var advance_id_cash3 = 0;
                    
                    var form = new ActionFormData();
                    form.title("Advance");
                    form.body(`配送完了した商品を選択`);
                    for (let i = 0; i < advance_shop_system2[advance_id][1].length; i++){
                        for (let i1 = 0; i1 < advance_shop_system2[advance_id][1][i][3].length; i1++){
                        if(advance_shop_system2[advance_id][1][i][3][i1][2]!=1&&advance_id_cash2.includes(advance_shop_system2[advance_id][1][i][0])==false){
                         form.button(`§l${advance_shop_system2[advance_id][1][i][0]}`);
                         advance_id_cash.push(i)
                         advance_id_cash2.push(advance_shop_system2[advance_id][1][i][0])
                        }
                       } 
                    }
                    if(advance_id_cash[0]==undefined){
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4配送未完了の商品がありません"}]}`)
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                        return;
                    }
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        var form = new ActionFormData();
                        form.title("Advance");
                        form.body(`§b${advance_shop_system2[advance_id][1][advance_id_cash[response]][0]}§rで配送完了した商品を選択`);
                        for (let i = 0; i < advance_shop_system2[advance_id][1][advance_id_cash[response]][3].length; i++){
                            if(advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][2]==0){
                            form.button(`§r個数:§2${advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][1]}  §r配送先:§9${advance_shop_system2[advance_id][1][advance_id_cash[response]][3][i][0]}`);
                            advance_id_cash1.push(i)
                        }
                        }
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response1 = r.selection;
                            advance_shop_system2[advance_id][1][advance_id_cash[response]][3][advance_id_cash1[response1]][2]=1
                            const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                            world.setDynamicProperty('advance_shop',advance_shop_system3)
                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §a配送を完了しました"}]}`)
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                        })
                    })
                break;
                case 2:
                    var advance_member_data = player.getDynamicProperty('advance_member_data')
                    var advance_member = world.getDynamicProperty('advance_member')
                    var advance_member_system2 = JSON.parse(advance_member);
                    for (let i = 0; i < advance_member_system2.length; i++){
                        if(advance_member_system2[i][1]==advance_member_data){
                            var advance_id = i
                        }
                    }

                    player_Cash_Data[player.name]={}

                //全プレイヤー取得
                    player_Cash_Data[player.name].players = world.getAllPlayers()
                //HARIPAY送信画面
                    var form = new ActionFormData();
                    form.body(`§r§5 >>>§r送り先のプレイヤーを選択`);
                    for (let i = 0; i < player_Cash_Data[player.name].players.length; i++){
                         form.button(`§1${player_Cash_Data[player.name].players[i].name}\n§4>>>§8${player_Cash_Data[player.name].players[i].id}`);
                    }
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        };
                        //送信先プレイヤーの設定
                        player_Cash_Data[player.name].select_player = player_Cash_Data[player.name].players[r.selection]
                        //送金額設定画面
                        var form = new ModalFormData();
                        form.textField(`§r§b送金額§r(半角数字)`, "0")
                        form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        };
                        if(isNaN(r.formValues[0])){
                            player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`)
                            player.playSound("random.toast", {
                                pitch: 0.4, 
                                volume: 1.0
                            });  
                            return;
                        }
                        if (r.formValues[0]>100000000){
                            player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`)
                            player.playSound("random.toast", {
                                pitch: 0.4, 
                                volume: 1.0
                            });  
                            return;
                        }
                        if (r.formValues[0]<0){
                            player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`)
                            player.playSound("random.toast", {
                                pitch: 0.4, 
                                volume: 1.0
                            });  
                            return;
                        }
                        //送金額を保存
                        if(r.formValues[0]=='') {
                            player_Cash_Data[player.name].select_money = 0
                        }else{
                            player_Cash_Data[player.name].select_money = Number(r.formValues[0])
                        }
                            //残高が設定金額以上の場合のみ実行
                            if(advance_member_system2[advance_id][3] >= player_Cash_Data[player.name].select_money){
                                player_Cash_Data[player.name].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.name].select_money}`)  
                                advance_member_system2[advance_id][3]=advance_member_system2[advance_id][3]-player_Cash_Data[player.name].select_money
                                const advance_member_system3 = JSON.stringify(advance_member_system2);
                                world.setDynamicProperty('advance_member',advance_member_system3)
                                
                                player.sendMessage(`§r[§bAdvance§r] §b${player_Cash_Data[player.name].select_player.name}§aへ§b${player_Cash_Data[player.name].select_money}§a送信されました`)
                                player_Cash_Data[player.name].select_player.sendMessage(`§r[§bAdvance§r] §b${player.name}§aから§b${player_Cash_Data[player.name].select_money}§a受け取りました`)
                                
                                player_Cash_Data[player.name].select_player.playSound("random.toast", {
                                    pitch: 1.7, 
                                    volume: 1.0
                                });  
                                player.playSound("random.toast", {
                                    pitch: 1.7, 
                                    volume: 1.0
                                });  
                                
                             }else{
                                 //残高不足時メッセージ
                                 player.sendMessage(`§r[§bAdvance§r] §4Moneyが不足しています`)
                                    player.playSound("random.toast", {
                                        pitch: 0.4, 
                                        volume: 1.0
                                    });  
                                return;
                             }
                        })
                    })
                break;
                case 3:
                    var form = new ActionFormData();
                    form.title("Advance");
                    form.body("選択してください");
                    form.button("§1追加");
                    form.button("§0編集");
                    form.button("§5削除");
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                var form = new ModalFormData();
                                form.title("Advance");
                                form.textField("商品名", "ダイアモンド")
                                form.textField("金額", "0") 
                                form.textField("在庫数", "0") 
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                    if (Number(r.formValues[1])<0){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    if(isNaN(r.formValues[1])){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4半角数字で入力してください"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    if (Number(r.formValues[2])<0){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                    if(isNaN(r.formValues[2])){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4半角数字で入力してください"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
    
                                    var advance_shop = world.getDynamicProperty('advance_shop')
                                    if(advance_shop==undefined){
                                        var advance_shop_system2=[]
                                    }else{
                                    var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                    var advance_shop_cash = 0
                                    for (let i = 0; i < advance_shop_system2.length; i++){
                                        if(advance_shop_system2[i][0]==player.getDynamicProperty('advance_member_data')){
                                            advance_shop_cash = 1
                                            advance_shop_system2[i][1].push([r.formValues[0],r.formValues[1],r.formValues[2],[]])
                                        }
                                    }
                                    if(advance_shop_cash==0){
                                        advance_shop_system2.push([player.getDynamicProperty('advance_member_data'),[[r.formValues[0],r.formValues[1],r.formValues[2],[],0]]])
                                    }
                                    const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                    world.setDynamicProperty('advance_shop',advance_shop_system3)
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a追加しました"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                })
                            break;
                            case 1:
                                var advance_shop = world.getDynamicProperty('advance_shop')
                                    if(advance_shop==undefined){
                                        var advance_shop_system2=[]
                                    }else{
                                    var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                var advance_shop_cash = [[],[]]
                                var form = new ActionFormData();
                                form.title("Advance");
                                form.body("編集するアイテム/ブロックを選択");
                                for (let i = 0; i < advance_shop_system2.length; i++){
                                    for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++){
                                    if(advance_shop_system2[i][0]==player.getDynamicProperty('advance_member_data')){
                                    form.button(`${advance_shop_system2[i][1][i1][0]}\n金額:§b${advance_shop_system2[i][1][i1][1]}§r`);
                                    advance_shop_cash[0].push(i)
                                    advance_shop_cash[1].push(i1)
                                    }
                                }
                                }
                                if(advance_shop_cash[0][0]==undefined){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4編集可能な商品がありません"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                    let response = r.selection;
                                    var form = new ModalFormData();
                                    form.textField("商品名", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][0]}`)
                                    form.textField("金額", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][1]}`) 
                                    form.textField("在庫数", `${advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][2]}`)
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        if (Number(r.formValues[1])<0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if(isNaN(r.formValues[1])){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4半角数字で入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if (Number(r.formValues[2])<0){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §40以下は設定できません"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if(isNaN(r.formValues[2])){
                                            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §4半角数字で入力してください"}]}`)
                                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                            return;
                                        }
                                        if(r.formValues[0]!=''){advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][0]=r.formValues[0]}
                                        if(r.formValues[1]!=''){advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][1]=r.formValues[1]}
                                        if(r.formValues[2]!=''){advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][2]=r.formValues[2]}
                                        const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                        world.setDynamicProperty('advance_shop',advance_shop_system3)
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a編集しました"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                    })
                                })
                            break;
                            case 2:
                                var advance_shop = world.getDynamicProperty('advance_shop')
                                    if(advance_shop==undefined){
                                        var advance_shop_system2=[]
                                    }else{
                                    var advance_shop_system2 = JSON.parse(advance_shop);
                                    }
                                var advance_shop_cash = [[],[]]
                                var form = new ActionFormData();
                                form.title("Advance");
                                form.body("削除する商品を選択");
                                for (let i = 0; i < advance_shop_system2.length; i++){
                                    if(advance_shop_system2[i][0]==player.getDynamicProperty('advance_member_data')){
                                    for (let i1 = 0; i1 < advance_shop_system2[i][1].length; i1++){
                                    form.button(`${advance_shop_system2[i][1][i1][0]}\n金額:§b${advance_shop_system2[i][1][i1][1]}§r`);
                                    advance_shop_cash[0].push(i)
                                    advance_shop_cash[1].push(i1)
                                    }
                                }
                                }
                                if(advance_shop_cash[0][0]==undefined){
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4削除可能な商品がありません"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                    return;
                                }
                                form.show(player).then(r => {
                                    if (r.canceled) return;
                                    let response = r.selection;
                                    for (let i = 0; i < advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][3].length; i++){
                                    if(advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][response]][3][i][2]!=1){
                                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(Advance)§r] §4選択した商品の配送がすべて完了していません"}]}`)
                                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`)
                                        return;
                                    }
                                   }
                                        // advance_shop_system2.push([player.getDynamicProperty('advance_member_data'),[[r.formValues[0],r.formValues[1],r.formValues[2],[],0]]])
                                    advance_shop_system2[advance_shop_cash[0][response]][1].splice(advance_shop_cash[1][response], 1 );
                                    if(advance_shop_system2[advance_shop_cash[0][response]][1][advance_shop_cash[1][0]]==undefined){
                                        advance_shop_system2.splice(advance_shop_cash[0][response], 1 )
                                    }
                                    const advance_shop_system3 = JSON.stringify(advance_shop_system2);
                                    world.setDynamicProperty('advance_shop',advance_shop_system3)
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(advance)§r] §a削除しました"}]}`)
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`)
                                })
                            break;
                        }
                    })
                    
                break;
            }
        })
    }
    })
}