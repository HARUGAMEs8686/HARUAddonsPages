import { world, system, BlockInventoryComponent, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

// DynamicPropertiesのプレフィックス
const OWNER_PREFIX = 'pembelian:owner:';
const PRICE_PREFIX = 'pembelian:price:';
const BUDGET_PREFIX = 'pembelian:budget:';
const DISPLAY_NAME_PREFIX = 'pembelian:displayName:';
const BUY_LIMIT_PREFIX = 'pembelian:buyLimit:';
const LIMIT_PERIOD_PREFIX = 'pembelian:limitPeriod:';
const BUY_COUNT_PREFIX = 'pembelian:buyCount:';
const LAST_RESET_PREFIX = 'pembelian:lastReset:';
const HISTORY_PREFIX = 'pembelian:history:';

// スコアボードの設定
const MONEY_OBJECTIVE = 'money';

// ショップブロックと樽のID (買取機用のIDに変更しています)
const SHOP_BLOCK = 'addblock:pembelian';
const BARREL_BLOCK = 'minecraft:barrel';

// クールダウン設定（ミリ秒）
const COOLDOWN_MS = 1000;

// プレイヤーのインタラクションクールダウンを管理
const interactionCooldowns = new Map();

// エンチャント情報を文字列として取得
function getEnchantmentString(itemStack) {
    const enchantable = itemStack.getComponent('minecraft:enchantable');
    if (!enchantable) return '';
    const enchantments = enchantable.getEnchantments();
    if (enchantments.length === 0) return '';
    return enchantments
        .map(e => `${e.type.id.replace('minecraft:', '')}${e.level}`)
        .sort()
        .join(',');
}

// エンチャントに基づく一意のキーを作成
function getItemUniqueKey(itemStack) {
    const enchantString = getEnchantmentString(itemStack);
    return enchantString ? `${itemStack.typeId}:${enchantString}` : itemStack.typeId;
}

// アイテムの表示名を取得（カスタム優先、エンチャント情報含む）
function getItemDisplayName(block, itemStack) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const customName = world.getDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`);
    if (customName) return customName;
    const enchantString = getEnchantmentString(itemStack);
    const baseName = itemStack.typeId.split('minecraft:')[1] || itemStack.typeId;
    return enchantString ? `${baseName} (${enchantString})` : baseName;
}

// アイテムの価格を取得
function getItemPRICE(block, itemStack) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const customPRICE = Number(world.getDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`));
    return customPRICE || 0;
}

// 座標をキーとして変換（x:y:z形式）
function getLocationKey(location) {
    return `${location.x}:${location.y}:${location.z}`;
}

// プレイヤーが指定のアイテムをいくつ持っているか取得
function getPlayerItemCount(player, targetItemStack) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const targetUniqueKey = getItemUniqueKey(targetItemStack);
    let count = 0;
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item && getItemUniqueKey(item) === targetUniqueKey) {
            count += item.amount;
        }
    }
    return count;
}

// 樽のインベントリに空き容量が十分にあるかチェック
function hasEnoughBarrelSpace(inventory, quantity, itemStack) {
    let emptySlots = 0;
    let availableStackSpace = 0;
    const maxStack = itemStack.maxAmount || 64;
    const targetUniqueKey = getItemUniqueKey(itemStack);

    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (!item) {
            emptySlots++;
        } else if (getItemUniqueKey(item) === targetUniqueKey) {
            availableStackSpace += maxStack - item.amount;
        }
    }

    const totalAvailableSpace = emptySlots * maxStack + availableStackSpace;
    return totalAvailableSpace >= quantity;
}

// 買取上限とリセット期間のチェック（機体全体でのカウント）
function checkBuyLimit(block, itemStack, quantity) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);

    const buyLimit = Number(world.getDynamicProperty(`${BUY_LIMIT_PREFIX}${key}:${uniqueKey}`)) || 0;
    if (buyLimit === 0) return true; // 上限未設定(0)なら無制限

    const limitPeriod = world.getDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`) || '86400000'; // デフォルト1日
    const machineKeySuffix = `${key}:${uniqueKey}`;
    const lastReset = Number(world.getDynamicProperty(`${LAST_RESET_PREFIX}${machineKeySuffix}`)) || 0;
    const now = Date.now();

    if (now - lastReset >= Number(limitPeriod)) {
        world.setDynamicProperty(`${BUY_COUNT_PREFIX}${machineKeySuffix}`, 0);
        world.setDynamicProperty(`${LAST_RESET_PREFIX}${machineKeySuffix}`, now);
    }

    const buyCount = Number(world.getDynamicProperty(`${BUY_COUNT_PREFIX}${machineKeySuffix}`)) || 0;

    if (buyCount + quantity > buyLimit) {
        return false; // 上限を超える場合は買取不可
    }
    return true;
}

// 買取数を更新
function updateBuyCount(block, itemStack, quantity) {
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(itemStack);
    const machineKeySuffix = `${key}:${uniqueKey}`;

    const buyCount = Number(world.getDynamicProperty(`${BUY_COUNT_PREFIX}${machineKeySuffix}`)) || 0;
    world.setDynamicProperty(`${BUY_COUNT_PREFIX}${machineKeySuffix}`, buyCount + quantity);
}

// ショップブロックのインタラクト処理
export function registerPembelianInteractions() {
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        const { player, block } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        event.cancel = true;

        const locationKey = getLocationKey(block.location);
        const playerId = player.id;
        const now = Date.now();
        const cooldownData = interactionCooldowns.get(playerId);

        if (cooldownData && cooldownData.location === locationKey && now - cooldownData.lastInteraction < COOLDOWN_MS) {
            return;
        }

        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

        system.run(() => {
            handlePembelianInteraction(player, block);
        });
    });

    // 樽へのアクセス制限
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        const { player, block } = event;
        if (block.typeId !== BARREL_BLOCK) return;

        const shopBlock = block.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(shopBlock.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;
            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                system.run(() => {
                    player.sendMessage(`§r[§b自動買取機§r] §cこの樽には設置者しかアクセスできません`);
                    player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                });
            }
        }
    });

    // ブロック設置
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(block.location);
        world.setDynamicProperty(`${OWNER_PREFIX}${key}`, player.name);
        world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, 0); // 予算の初期化
    });

    // ブロック破壊時のクリーンアップと予算返還
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(block.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;
            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                system.run(() => {
                    player.sendMessage(`§r[§b自動買取機§r] §cこの自動買取機は設置者しか破壊できません`);
                    player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                });
            }
            return;
        }

        system.run(() => {
            receiveBudget_BreakBlock(player, block);
            world.setDynamicProperty(`${OWNER_PREFIX}${key}`, undefined);
            world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, undefined);

            const barrelBlock = block.below();
            if (barrelBlock && barrelBlock.typeId === BARREL_BLOCK) {
                const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
                if (inventoryComponent && inventoryComponent.container) {
                    const items = getInventoryItems(inventoryComponent.container);
                    items.forEach(item => {
                        const uniqueKey = getItemUniqueKey(item.itemStack);
                        world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${BUY_LIMIT_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${BUY_COUNT_PREFIX}${key}:${uniqueKey}`, undefined);
                        world.setDynamicProperty(`${LAST_RESET_PREFIX}${key}:${uniqueKey}`, undefined);
                    });
                }
            }
        });
    });

    // 爆発保護
    world.beforeEvents.explosion.subscribe(event => {
        const impactedBlocks = event.getImpactedBlocks();
        const dimension = event.dimension;

        const newImpactedBlocks = impactedBlocks.filter(blockLocation => {
            try {
                const block = dimension.getBlock(blockLocation);
                if (!block) return true;

                if (block.typeId === SHOP_BLOCK) {
                    const key = getLocationKey(block.location);
                    if (world.getDynamicProperty(`${OWNER_PREFIX}${key}`)) return false;
                }

                if (block.typeId === BARREL_BLOCK) {
                    const shopBlock = block.above();
                    if (shopBlock && shopBlock.typeId === SHOP_BLOCK) {
                        const key = getLocationKey(shopBlock.location);
                        if (world.getDynamicProperty(`${OWNER_PREFIX}${key}`)) return false;
                    }
                }
                return true;
            } catch (e) {
                return true;
            }
        });
        event.setImpactedBlocks(newImpactedBlocks);
    });

    // 樽の破壊防止
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== BARREL_BLOCK) return;

        const shopBlock = block.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        const key = getLocationKey(shopBlock.location);
        const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

        if (!player.hasTag('HARUPhoneOP') && ownerName !== player.name) {
            event.cancel = true;
            const locationKey = getLocationKey(block.location);
            const playerId = player.id;
            const now = Date.now();
            const cooldownData = interactionCooldowns.get(playerId);

            if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                system.run(() => {
                    player.sendMessage(`§r[§b自動買取機§r] §cこの樽は設置者しか破壊できません`);
                    player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                });
            }
        }
    });

    // ホッパー等の設置防止ロジック（割愛せずそのまま維持）
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        if (block.typeId !== 'minecraft:hopper') return;
        const barrelBlock = block.above();
        if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) return;
        const shopBlock = barrelBlock.above();
        if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

        block.setType('minecraft:air');
        const locationKey = getLocationKey(block.location);
        const playerId = player.id;
        const now = Date.now();
        const cooldownData = interactionCooldowns.get(playerId);

        if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
            interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
            system.run(() => {
                player.sendMessage(`§r[§b自動買取機§r] §cホッパーは樽の下に置けません`);
                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            });
        }
    });

    // ピストン制限
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const { block, player } = event;
        const restrictedBlocks = ['minecraft:piston', 'minecraft:sticky_piston'];
        if (!restrictedBlocks.includes(block.typeId)) return;

        const directions = [];
        for (let x = -2; x <= 2; x++) {
            for (let y = -2; y <= 2; y++) {
                for (let z = -2; z <= 2; z++) {
                    if ((x === 0 && y === 0 && z === 0) || (x !== 0 && y !== 0) || (x !== 0 && z !== 0) || (y !== 0 && z !== 0)) continue;
                    directions.push({ x, y, z });
                }
            }
        }

        for (const dir of directions) {
            const checkLocation = { x: block.location.x + dir.x, y: block.location.y + dir.y, z: block.location.z + dir.z };
            const adjacentBlock = block.dimension.getBlock(checkLocation);
            if (!adjacentBlock) continue;

            if (adjacentBlock.typeId === SHOP_BLOCK) {
                block.setType('minecraft:air');
                const locationKey = getLocationKey(block.location);
                const playerId = player.id;
                const now = Date.now();
                const cooldownData = interactionCooldowns.get(playerId);
                if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                    interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                    system.run(() => {
                        player.sendMessage(`§r[§b自動買取機§r] §c自動買取機の周りにピストンは置けません`);
                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                    });
                }
                return;
            }

            if (adjacentBlock.typeId === BARREL_BLOCK) {
                const shopBlock = adjacentBlock.above();
                if (shopBlock && shopBlock.typeId === SHOP_BLOCK) {
                    block.setType('minecraft:air');
                    const locationKey = getLocationKey(block.location);
                    const playerId = player.id;
                    const now = Date.now();
                    const cooldownData = interactionCooldowns.get(playerId);
                    if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
                        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });
                        system.run(() => {
                            player.sendMessage(`§r[§b自動買取機§r] §c自動買取機の樽の周りにピストンは置けません`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                        });
                    }
                    return;
                }
            }
        }
    });
}

// 破壊時に予算を残金として返却
async function receiveBudget_BreakBlock(player, block) {
    const key = getLocationKey(block.location);
    const budget = world.getDynamicProperty(`${BUDGET_PREFIX}${key}`) || 0;
    if (budget === 0) return;

    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) {
        player.sendMessage(`§r[§b自動買取機§r] §cスコアボード 'money' が見つかりません`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    objective.addScore(player, budget);
    world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, 0);
    player.sendMessage(`§r[§b自動買取機§r] §a残っていた買取予算§c${budget}§aを回収し、データを初期化しました`);
    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
}

// インタラクト処理分岐
export async function handlePembelianInteraction(player, block, blockLocation) {
    let targetBlock = block;
    if (!targetBlock) {
        try {
            targetBlock = player.dimension.getBlock(blockLocation);
            if (!targetBlock) return;
        } catch (error) {
            return;
        }
    }

    const key = getLocationKey(targetBlock.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);
    const isOwner = ownerName === player.name;

    const barrelBlock = targetBlock.below();
    if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) {
        player.sendMessage(`§r[§b自動買取機§r] §c下に樽が必要です`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
    if (!inventoryComponent || !inventoryComponent.container) {
        player.sendMessage(`§r[§b自動買取機§r] §c樽のインベントリを取得できませんでした`);
        return;
    }
    const inventory = inventoryComponent.container;

    if (isOwner) {
        await showOwnerMenu(player, targetBlock, inventory);
    } else {
        await showSellMenu(player, targetBlock, inventory);
    }
}

// 設置者向けメニュー
async function showOwnerMenu(player, block, inventory) {
    const form = new ActionFormData().title('§1自動買取機 §0(買取者)').body('>>> §e選択してください').button('§1買取カスタマイズ', 'textures/ui/normalicon1').button('§5買取履歴', 'textures/ui/normalicon1').button('§4予算管理', 'textures/ui/pay').button('§9売却画面を表示', `textures/blocks/pembelian`);

    const response = await form.show(player);
    if (response.canceled) return;

    switch (response.selection) {
        case 0:
            await showPriceSettingMenu(player, block, inventory);
            break;
        case 1:
            await showPurchaseHistoryMenu(player, block);
            break;
        case 2:
            await showBudgetMenu(player, block);
            break;
        case 3:
            await showSellMenu(player, block, inventory);
            break;
    }
}

// 予算管理メニュー
async function showBudgetMenu(player, block) {
    const key = getLocationKey(block.location);
    const currentBudget = Number(world.getDynamicProperty(`${BUDGET_PREFIX}${key}`)) || 0;

    const form = new ActionFormData().title('§1予算管理').body(`>>> §e現在の買取予算: §c${currentBudget}`).button(`§l戻る`, 'textures/ui/icon_import.png').button('§1予算を追加する', 'textures/ui/normalicon1').button('§4予算を回収する', 'textures/ui/normalicon1');

    const response = await form.show(player);
    if (response.canceled) return;

    if (response.selection === 0) {
        const barrelBlock = block.below();
        const inv = barrelBlock.getComponent('inventory').container;
        await showOwnerMenu(player, block, inv);
    } else if (response.selection === 1) {
        await addBudget(player, block, currentBudget);
    } else {
        await collectBudget(player, block, currentBudget);
    }
}

async function addBudget(player, block, currentBudget) {
    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) return;
    const playerMoney = objective.getScore(player) || 0;

    const form = new ModalFormData().title('§1予算追加').textField(`§a追加する金額 §b(所持金: ${playerMoney})`, '半角整数');

    const response = await form.show(player);
    if (response.canceled || !response.formValues) {
        showBudgetMenu(player, block);
        return;
    }

    const amount = parseInt(response.formValues[0]);
    if (isNaN(amount) || amount <= 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c無効な金額です`);
        return;
    }

    if (playerMoney < amount) {
        player.sendMessage(`§r[§b自動買取機§r] §c所持金が不足しています`);
        return;
    }

    objective.setScore(player, playerMoney - amount);
    const key = getLocationKey(block.location);
    world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, currentBudget + amount);
    player.sendMessage(`§r[§b自動買取機§r] §a予算を §c${amount} §a追加しました\n現在の予算: §c${currentBudget + amount}`);
    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
}

async function collectBudget(player, block, currentBudget) {
    const form = new ModalFormData().title('§1予算回収').textField(`§a回収する金額 §b(現在予算: ${currentBudget})`, '半角整数', {
        defaultValue: String(currentBudget),
    });

    const response = await form.show(player);
    if (response.canceled || !response.formValues) {
        showBudgetMenu(player, block);
        return;
    }

    const amount = parseInt(response.formValues[0]);
    if (isNaN(amount) || amount <= 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c無効な金額です`);
        return;
    }

    if (currentBudget < amount) {
        player.sendMessage(`§r[§b自動買取機§r] §c回収金額が予算を超えています`);
        return;
    }

    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) return;
    const playerMoney = objective.getScore(player) || 0;

    objective.setScore(player, playerMoney + amount);
    const key = getLocationKey(block.location);
    world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, currentBudget - amount);
    player.sendMessage(`§r[§b自動買取機§r] §a予算を §c${amount} §a回収しました\n残りの予算: §c${currentBudget - amount}`);
    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
}

// 価格・上限設定メニュー
async function showPriceSettingMenu(player, block, inventory) {
    const items = getInventoryItems(inventory);
    if (items.length === 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c買取の見本となるアイテムが樽に入っていません`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const selectionForm = new ActionFormData().title('§1買取カスタマイズ').body('>>> §eカスタマイズする商品を選択');
    selectionForm.button(`§l戻る`, 'textures/ui/icon_import.png');
    items.forEach(item => {
        const price = getItemPRICE(block, item.itemStack);
        selectionForm.button(`§1${getItemDisplayName(block, item.itemStack)} §5- §4買取額:${price}`, 'textures/ui/normalicon1');
    });

    const selectionResponse = await selectionForm.show(player);
    if (selectionResponse.canceled || selectionResponse.selection === undefined) return;

    if (selectionResponse.selection == 0) {
        await showOwnerMenu(player, block, inventory);
        return;
    }

    const selectedItem = items[selectionResponse.selection - 1];
    const key = getLocationKey(block.location);
    const uniqueKey = getItemUniqueKey(selectedItem.itemStack);

    const currentPrice = world.getDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`) || '';
    const currentDisplayName = world.getDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`) || '';
    const currentBuyLimit = world.getDynamicProperty(`${BUY_LIMIT_PREFIX}${key}:${uniqueKey}`) || 0;
    const currentPeriod = world.getDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`) || '86400000';
    const periods = ['3600000', '43200000', '86400000', '259200000', '604800000'];
    const periodLabels = ['1時間', '12時間', '1日', '3日', '7日'];
    const defaultPeriodIndex = periods.indexOf(currentPeriod) !== -1 ? periods.indexOf(currentPeriod) : 2;

    const form = new ModalFormData()
        .title(`§1${getItemDisplayName(block, selectedItem.itemStack)} の設定`)
        .textField('§a買取価格 §b(数値) §5- §e1個あたり', '例:10', { defaultValue: String(currentPrice) })
        .textField('§a表示名', '例:ダイヤモンド', { defaultValue: String(currentDisplayName) })
        .textField('§a全体の買取上限 §b(整数, 0で無制限)', '例:100', { defaultValue: String(currentBuyLimit) })
        .dropdown('§a上限リセット期間', periodLabels, { defaultValueIndex: defaultPeriodIndex });

    const response = await form.show(player);
    if (response.canceled || !response.formValues) {
        await showPriceSettingMenu(player, block, inventory);
        return;
    }

    const price = response.formValues[0];
    const displayName = response.formValues[1];
    let buyLimit = response.formValues[2] === '' ? '0' : response.formValues[2];
    const periodIndex = response.formValues[3];

    if (price !== '' && (isNaN(price) || price < 0)) {
        player.sendMessage(`§r[§b自動買取機§r] §c無効な価格です`);
        return;
    }
    if (isNaN(buyLimit) || Number(buyLimit) < 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c無効な買取上限です`);
        return;
    }

    if (displayName !== '') {
        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, displayName);
        player.sendMessage(`§r[§b自動買取機§r] §a表示名§r:§b${displayName}§aに設定しました`);
    } else {
        world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, undefined);
    }

    if (price !== '') {
        world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, price);
        player.sendMessage(`§r[§b自動買取機§r] §a価格§r:§c${price} §aに設定しました`);
    }

    world.setDynamicProperty(`${BUY_LIMIT_PREFIX}${key}:${uniqueKey}`, buyLimit);
    if (Number(buyLimit) === 0) {
        player.sendMessage(`§r[§b自動買取機§r] §a買取上限§r:§c無制限 §aに設定しました`);
    } else {
        player.sendMessage(`§r[§b自動買取機§r] §a買取上限§r:§c${buyLimit} §aに設定しました`);
    }

    const selectedPeriod = periods[periodIndex];
    if (currentPeriod !== selectedPeriod) {
        world.setDynamicProperty(`${LIMIT_PERIOD_PREFIX}${key}:${uniqueKey}`, selectedPeriod);
        player.sendMessage(`§r[§b自動買取機§r] §aリセット期間§r:§c${periodLabels[periodIndex]} §aに設定しました`);
    }
    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
}

// 買取履歴メニュー
async function showPurchaseHistoryMenu(player, block) {
    const key = getLocationKey(block.location);
    let history = [];
    try {
        const rawHistory = world.getDynamicProperty(`${HISTORY_PREFIX}${key}`);
        if (rawHistory) history = JSON.parse(rawHistory);
    } catch (e) {}

    let bodyText = history.length === 0 ? '§7買取履歴はありません' : history.map(h => `§e[${h.time}] §b${h.seller}\n§r商品: ${h.item} §a(x${h.amount}) §c支払い: ${h.price}`).join('\n\n');

    const form = new ActionFormData().title('§1買取履歴 (最新20件)').body(bodyText).button('§l戻る', 'textures/ui/icon_import.png');
    const response = await form.show(player);

    if (!response.canceled && response.selection === 0) {
        const barrelBlock = block.below();
        if (barrelBlock && barrelBlock.typeId === BARREL_BLOCK) {
            const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
            if (inventoryComponent) {
                await showOwnerMenu(player, block, inventoryComponent.container);
            }
        }
    }
}

// 一般売却メニュー
async function showSellMenu(player, block, inventory) {
    const items = getInventoryItems(inventory);
    const key = getLocationKey(block.location);
    const buyableItems = items.filter(item => getItemPRICE(block, item.itemStack) > 0);

    if (buyableItems.length === 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c現在買取を行っている商品はありません`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`) || '不明';
    const budget = Number(world.getDynamicProperty(`${BUDGET_PREFIX}${key}`)) || 0;

    const form = new ActionFormData().title('§1自動買取機').body(`買取者:§a${ownerName}\n§r現在の買取予算: §c${budget}`).divider();

    const prices = buyableItems.map(item => getItemPRICE(block, item.itemStack));
    buyableItems.forEach((item, index) => {
        form.button(`§1${getItemDisplayName(block, item.itemStack)} §51個買取額§r:§c${prices[index]}`, 'textures/ui/normalicon1');
    });

    const response = await form.show(player);
    if (response.canceled || response.selection == null) return;

    const selectedItem = buyableItems[response.selection];
    const price = prices[response.selection];
    await showQuantitySelectionMenu(player, block, inventory, selectedItem, price);
}

// 数量選択メニュー
async function showQuantitySelectionMenu(player, block, inventory, selectedItem, price) {
    const maxPossessed = getPlayerItemCount(player, selectedItem.itemStack);

    if (maxPossessed === 0) {
        player.sendMessage(`§r[§b自動買取機§r] §cこのアイテムを所持していません`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const form = new ModalFormData().title('§1数量選択').textField(`§a売却する数量 §r(§b1~${maxPossessed}§r)`, '半角整数');
    const response = await form.show(player);
    if (response.canceled || !response.formValues) return;

    const quantity = parseInt(response.formValues[0]);
    if (isNaN(quantity) || quantity <= 0) {
        player.sendMessage(`§r[§b自動買取機§r] §c数量は正の整数で入力してください`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }
    if (quantity > maxPossessed) {
        player.sendMessage(`§r[§b自動買取機§r] §c所持数§a（${maxPossessed}個）§4を超える数量です`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    await showConfirmSellMenu(player, block, inventory, selectedItem, price, quantity);
}

// 売却確認と実行
async function showConfirmSellMenu(player, block, inventory, selectedItem, price, quantity) {
    const rawEarnings = price * quantity;
    const totalEarnings = rawEarnings > 0 && rawEarnings <= 1 ? 1 : Math.round(rawEarnings);
    const form = new ActionFormData()
        .title('§1売却確認')
        .body(`売却詳細`)
        .divider()
        .label(`§a商品: §b${getItemDisplayName(block, selectedItem.itemStack)}\n§a数量: §e${quantity}個\n§a合計買取額: §c${totalEarnings}`)
        .divider()
        .label(`>>> §e売却しますか？`)
        .button('§1売却する')
        .button('§4キャンセル');

    const response = await form.show(player);
    if (response.canceled || response.selection !== 0) return;

    const key = getLocationKey(block.location);
    const currentBudget = Number(world.getDynamicProperty(`${BUDGET_PREFIX}${key}`)) || 0;

    // 予算チェック
    if (currentBudget < totalEarnings) {
        player.sendMessage(`§r[§b自動買取機§r] §c買取機の予算が不足しています (予算: §e${currentBudget}§c)`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    // 買取上限チェック
    if (!checkBuyLimit(block, selectedItem.itemStack, quantity)) {
        const uniqueKey = getItemUniqueKey(selectedItem.itemStack);
        const buyCount = Number(world.getDynamicProperty(`${BUY_COUNT_PREFIX}${key}:${uniqueKey}`)) || 0;
        const buyLimit = Number(world.getDynamicProperty(`${BUY_LIMIT_PREFIX}${key}:${uniqueKey}`)) || 0;
        const remaining = buyLimit - buyCount;

        player.sendMessage(`§r[§b自動買取機§r] §c設定されている買取上限に達するため、その数量は売却できません`);
        if (remaining > 0) {
            player.sendMessage(`>>> §aこの商品の残り買取可能数は §e${remaining}個§a です`);
        }
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    // 樽の容量チェック
    if (!hasEnoughBarrelSpace(inventory, quantity, selectedItem.itemStack)) {
        player.sendMessage(`§r[§b自動買取機§r] §c買取機（樽）が満杯です`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    // プレイヤーのインベントリからアイテムを減らし、スタックを取得
    const extractedStacks = reducePlayerInventoryAndGetStacks(player, selectedItem.itemStack, quantity);
    if (!extractedStacks) {
        player.sendMessage(`§r[§b自動買取機§r] §cアイテムの売却に失敗しました`);
        return;
    }

    // 樽にアイテムを追加
    extractedStacks.forEach(stack => {
        inventory.addItem(stack);
    });

    // お金・予算・カウントの処理
    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (objective) {
        const playerMoney = objective.getScore(player) || 0;
        objective.setScore(player, playerMoney + totalEarnings);
    }

    world.setDynamicProperty(`${BUDGET_PREFIX}${key}`, currentBudget - totalEarnings);
    updateBuyCount(block, selectedItem.itemStack, quantity);

    // 履歴保存処理
    const historyKey = `${HISTORY_PREFIX}${key}`;
    let history = [];
    try {
        const rawHistory = world.getDynamicProperty(historyKey);
        if (rawHistory) history = JSON.parse(rawHistory);
    } catch (e) {}

    const now = new Date();
    const timeOffset = world.getDynamicProperty('Time_Setting') !== undefined ? world.getDynamicProperty('Time_Setting') : 9;
    const japanTime = new Date(now.getTime() + timeOffset * 60 * 60 * 1000);
    const timeString = `${String(japanTime.getUTCMonth() + 1).padStart(2, '0')}/${String(japanTime.getUTCDate()).padStart(2, '0')} ${String(japanTime.getUTCHours()).padStart(2, '0')}:${String(japanTime.getUTCMinutes()).padStart(2, '0')}`;

    history.unshift({
        seller: player.name,
        item: getItemDisplayName(block, selectedItem.itemStack),
        amount: quantity,
        time: timeString,
        price: totalEarnings,
    });
    if (history.length > 20) history = history.slice(0, 20);
    world.setDynamicProperty(historyKey, JSON.stringify(history));

    // オーナーへの通知と自身へのメッセージ
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);
    world.getAllPlayers().forEach(p => {
        if (p.name == ownerName) {
            p.sendMessage(`§r[§b自動買取機§r] §b${player.name}§aが§b${getItemDisplayName(block, selectedItem.itemStack)}§aを§e${quantity}個 §a売却しました`);
            p.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
        }
    });

    player.sendMessage(`§r[§b自動買取機§r] §b${getItemDisplayName(block, selectedItem.itemStack)}§aを§e${quantity}個 §c${totalEarnings}§aで売却しました`);
    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
}

// プレイヤーのインベントリから指定数量を減らし、追加用のItemStackの配列を返す
function reducePlayerInventoryAndGetStacks(player, targetItemStack, quantity) {
    const inventory = player.getComponent('minecraft:inventory').container;
    const targetUniqueKey = getItemUniqueKey(targetItemStack);
    let remaining = quantity;
    const extractedStacks = [];

    for (let i = 0; i < inventory.size && remaining > 0; i++) {
        const item = inventory.getItem(i);
        if (item && getItemUniqueKey(item) === targetUniqueKey) {
            if (item.amount <= remaining) {
                const stack = item.clone();
                extractedStacks.push(stack);
                remaining -= item.amount;
                inventory.setItem(i, undefined);
            } else {
                const stack = item.clone();
                stack.amount = remaining;
                extractedStacks.push(stack);
                item.amount -= remaining;
                inventory.setItem(i, item);
                remaining = 0;
            }
        }
    }
    return remaining === 0 ? extractedStacks : null;
}

// 樽のインベントリからアイテムリストを取得
function getInventoryItems(inventory) {
    const itemMap = new Map();
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) {
            const uniqueKey = getItemUniqueKey(item);
            const current = itemMap.get(uniqueKey) || { typeId: item.typeId, amount: 0, itemStack: item };
            itemMap.set(uniqueKey, {
                typeId: item.typeId,
                amount: current.amount + item.amount,
                itemStack: current.itemStack,
            });
        }
    }
    return Array.from(itemMap.values());
}

// Command実行
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        let Pembelian_Command = [];
        if (world.getDynamicProperty('Pembelian_Command') != undefined) {
            Pembelian_Command = JSON.parse(world.getDynamicProperty('Pembelian_Command'));
        }

        for (let i = 0; i < Pembelian_Command.length; i++) {
            if (eventData.id === `${Pembelian_Command[i][0]}`) {
                const args = eventData.message.trim().split(/\s+/);
                const selectorOrPlayer = args[0] || '';
                const targetPlayers = parseSelector(selectorOrPlayer);

                if (targetPlayers.length === 0) {
                    if (eventData.sourceEntity?.typeId === 'minecraft:player') {
                        eventData.sourceEntity.sendMessage(`§r[§b自動買取機§r] §c対象プレイヤーが見つかりません。`);
                    }
                    return;
                }

                targetPlayers.forEach(targetPlayer => {
                    targetPlayer.sendMessage(`§r[§b自動買取機§r] §a読み込み中...`);
                    targetPlayer.playSound('haru.notification1', { pitch: 1.3, volume: 0.5 });
                    system.runTimeout(() => {
                        try {
                            if (targetPlayer) {
                                targetPlayer.playSound('haru.notification1', { pitch: 1.9, volume: 0.5 });
                                handlePembelianInteraction(targetPlayer, undefined, Pembelian_Command[i][1]);
                            }
                        } catch (e) {}
                    }, 20);
                });
            }
        }
    });
});

// セレクター
function parseSelector(selector) {
    if (!selector) return [];

    var players = [];
    for (const player of world.getPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}
