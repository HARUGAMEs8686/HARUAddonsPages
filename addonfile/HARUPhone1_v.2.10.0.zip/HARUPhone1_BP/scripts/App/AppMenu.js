import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';
import { HARUPhone1 } from '../itemrun/haruphone1';
import { LiteFrameA } from './LiteFrame_engine/LiteFrameA';
import { FilesApplicationData } from '../FilesSetting';
import { FilesAppEngine } from './FilesApp_engine/base';
import { HARUAppsDATA } from '../haruapps';
import { HARUAppsEngine } from './HARUApps_engine/base';

var player_Cash_Data = {};
export function App(player) {
    system.run(() => {
        const HARUApps_Status = world.getDynamicProperty('HARUApps_AutoLoad');
        player_Cash_Data[player.id] = {};
        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        //AppDataを取得
        player_Cash_Data[player.id].AppData = world.getDynamicProperty(`AppData`);
        if (player_Cash_Data[player.id].AppData == undefined) {
            player_Cash_Data[player.id].AppData = [];
        } else {
            player_Cash_Data[player.id].AppData = JSON.parse(player_Cash_Data[player.id].AppData);
        }
        player_Cash_Data[player.id].AppDataList = [];
        for (let i = 0; i < player_Cash_Data[player.id].AppData.length; i++) {
            var AppDataName = JSON.parse(world.getDynamicProperty(player_Cash_Data[player.id].AppData[i][0])).ApplicationName;
            player_Cash_Data[player.id].AppDataList.push([AppDataName, player_Cash_Data[player.id].AppData[i][1]]);
        }
        player_Cash_Data[player.id].HARUAppsDATA = HARUAppsDATA;
        if (!HARUApps_Status) {
            player_Cash_Data[player.id].HARUAppsDATA = [];
        }
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}`);
        const buttonActions = [];
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        buttonActions.push({ type: 'back' });

        const hiddenAppsStr = world.getDynamicProperty('HARUApps_Hidden');
        const hiddenApps = hiddenAppsStr ? JSON.parse(hiddenAppsStr) : [];

        // HARUApps
        if (player_Cash_Data[player.id].HARUAppsDATA.AppLoad) {
            for (let APPNAME of player_Cash_Data[player.id].HARUAppsDATA.AppLoad) {
                if (!hiddenApps.includes(APPNAME)) {
                    form.button(`${APPNAME}`, `textures/ui/auto_haruapp`);
                    buttonActions.push({ type: 'haru_static', name: APPNAME });
                }
            }
        }

        // HARU-X-Editor-App
        for (let i = 0; i < player_Cash_Data[player.id].AppDataList.length; i++) {
            const isHaru = HARUApps(JSON.parse(world.getDynamicProperty(player_Cash_Data[player.id].AppData[i][0])));
            const texture = isHaru ? `textures/ui/haruapp2` : `textures/ui/normalicon1`;

            form.button(`${player_Cash_Data[player.id].AppDataList[i][0]}`, texture);
            buttonActions.push({
                type: 'dynamic',
                dataListIndex: i,
                frameType: player_Cash_Data[player.id].AppDataList[i][1],
                propertyKey: player_Cash_Data[player.id].AppData[i][0],
            });
        }

        // File-APP
        for (let APPNAME of FilesApplicationData.AppLoad) {
            form.button(`${APPNAME}`, `textures/ui/normalicon1`);
            buttonActions.push({ type: 'files', name: APPNAME });
        }

        form.show(player).then(r => {
            if (r.canceled) return;
            const action = buttonActions[r.selection];
            if (!action) return;

            switch (action.type) {
                case 'back':
                    HARUPhone1(player);
                    break;

                case 'haru_static':
                    HARUAppsEngine(player_Cash_Data[player.id].HARUAppsDATA[action.name], player);
                    break;

                case 'dynamic':
                    if (action.frameType === 'LiteFrameA') {
                        const propertyData = JSON.parse(world.getDynamicProperty(action.propertyKey));
                        LiteFrameA(propertyData, player);
                    } else {
                    }
                    break;

                case 'files':
                    FilesAppEngine(FilesApplicationData[action.name], player);
                    break;
            }
        });
    });
}

function HARUApps(Application_Data) {
    if (!Application_Data || !Application_Data.CommandRunList || Application_Data.CommandRunNumber === 0) return false;

    for (let i = 0; i < Application_Data.CommandRunNumber; i++) {
        let command = Application_Data.CommandRunList[i];
        if (command && command.includes('haruapps')) {
            return true;
        }
    }
    return false;
}
