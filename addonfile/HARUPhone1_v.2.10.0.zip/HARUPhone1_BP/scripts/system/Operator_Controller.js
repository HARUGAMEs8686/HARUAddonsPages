import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

import { config } from '../config';
import { player_Cash_Data, Claim, quest, logs, HARUPhone1, loadShopMenu, saveShopMenu } from '../itemrun/haruphone1';
import { adminSettings } from '../system/country';
import { openNavigationForm } from './Map';
import { Kill_Count_System_edit } from '../EntityPOINT';
import { HARU_XEditor } from '../App/HARU-XEditor';
import { loadSplitProperty, saveSplitProperty } from './browser';
import { AdvanceshowAdminMenu } from '../itemrun/advance';
import { HARUAppsDATA } from '../haruapps';

//メニュー ----
export function Operator_Controller(player) {
    if (!player.hasTag('HARUPhoneOP')) {
        player.sendMessage(`§r[§b設定§r] §c権限がありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`>>> §eOperator Controller`);
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1ログ', `textures/ui/normalicon1`);
    form.button('§5データ編集', `textures/ui/normalicon1`);
    form.button('§2データ管理', `textures/ui/normalicon1`);
    form.button('§4サウンド通知', `textures/ui/normalicon1`);
    form.button('§3その他', `textures/ui/normalicon1`);
    form.button('§0UIカスタマイズ', 'textures/items/haruphone1');
    form.button('§9社会システム設定', `textures/ui/country`);
    form.button('§5マップ設定', 'textures/ui/map');
    form.button('§9Advance設定', 'textures/ui/advance');
    form.button('§2ブラウザ設定', 'textures/ui/browser');
    form.button(`§1${config['AppName'][1]} §1[§4OP版§1]`, `textures/ui/pay`);
    form.button(`§1${config['AppName'][18]}設定`, 'textures/ui/auto_haruapp');
    form.button(`§1${config['AppName'][16]}`, 'textures/ui/editor');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                if (player_Cash_Data[player.id].HARUPhoneMode) {
                    HARUPhone1(player);
                }
                break;
            case 1:
                Log(player);
                break;
            case 2:
                Data_Editing(player);
                break;
            case 3:
                Delete_Data(player);
                break;
            case 4:
                Sound_Notification(player);
                break;
            case 5:
                others(player);
                break;
            case 6:
                UI_Customization(player);
                break;
            case 7:
                adminSettings(player);
                break;
            case 8:
                openNavigationForm(player);
                break;
            case 9:
                AdvanceshowAdminMenu(player);
                break;
            case 10:
                Browser_usage_fee(player);
                break;
            case 11:
                OPHARUPAY(player);
                break;
            case 12:
                HARUApps_Setting(player);
                break;
            case 13:
                HARU_XEditor(player);
                break;
        }
    });
}

function HARUApps_Setting(player) {
    const Status = world.getDynamicProperty('HARUApps_AutoLoad');

    let hiddenAppsStr = world.getDynamicProperty('HARUApps_Hidden');
    let hiddenApps = hiddenAppsStr ? JSON.parse(hiddenAppsStr) : [];

    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`>>> §eHARUApps設定`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§0全体自動読み込み\n§0(${Status === true ? '§1有効' : '§4無効'}§0)`, `textures/ui/auto_haruapp`);
    form.button('§0UI最上部に追加\n§0(§1アプリケーション§0)', 'textures/ui/editor');
    form.label('>>> §bApps個別設定');

    for (const ApplicationNAME of HARUAppsDATA.AppLoad) {
        const cleanName = ApplicationNAME.replace(/§./g, '');
        const isHidden = hiddenApps.includes(ApplicationNAME);
        form.button(`§0${cleanName}\n§0(${!isHidden ? '§1表示' : '§4非表示'}§0)`, `textures/ui/normalicon1`);
    }

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;

        if (response === 0) {
            Operator_Controller(player);
        } else if (response === 1) {
            world.setDynamicProperty('HARUApps_AutoLoad', !world.getDynamicProperty('HARUApps_AutoLoad'));
            player.sendMessage(`§r[§bHARUApps§r] §a全体設定を更新しました`);
            HARUApps_Setting(player);
        } else if (response === 1) {
            world.setDynamicProperty('HARUApps_AutoLoad', !world.getDynamicProperty('HARUApps_AutoLoad'));
            player.sendMessage(`§r[§bHARUApps§r] §a全体設定を更新しました`);
            HARUApps_Setting(player);
        } else if (response === 2) {
            let appNumbers = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber') || '[]');

            appNumbers = appNumbers.filter(id => id !== 2);
            appNumbers.unshift(2);

            const opIndex = config['AppData'].length - 1;
            if (!appNumbers.includes(opIndex)) {
                appNumbers.push(opIndex);
            }

            world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(appNumbers));
            player.sendMessage(`§r[§bHARUApps§r] §aHARUPhoneUIにアプリケーションを追加しました`);
            player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
            HARUPhone1(player);
        } else {
            const appIndex = response - 3;
            const targetApp = HARUAppsDATA.AppLoad[appIndex];

            if (hiddenApps.includes(targetApp)) {
                hiddenApps = hiddenApps.filter(name => name !== targetApp);
                player.sendMessage(`§r[§bHARUApps§r] §e${targetApp.replace(/§./g, '')}§rを(§a表示§r)に変更しました`);
            } else {
                hiddenApps.push(targetApp);
                player.sendMessage(`§r[§bHARUApps§r] §e${targetApp.replace(/§./g, '')}§rを(§c非表示§r)に変更しました`);
            }

            world.setDynamicProperty('HARUApps_Hidden', JSON.stringify(hiddenApps));
            HARUApps_Setting(player);
        }
    });
}

function Sound_Notification(player) {
    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`>>> §eサウンド通知`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4キルカウントシステム', 'textures/ui/normalicon1.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;

        switch (response) {
            case 0:
                // 戻る
                Operator_Controller(player);
                break;
            case 1:
                Sound_Notification_Kill_Count(player);
                break;
        }
    });
}

function Sound_Notification_Kill_Count(player) {
    // Added player argument
    let soundSettings = {};
    try {
        const storedSettings = world.getDynamicProperty('Sound_Notification');
        soundSettings = storedSettings ? JSON.parse(storedSettings) : {};
    } catch (e) {
        soundSettings = {};
    }

    let form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.toggle('§aカウント数通知', {
        defaultValue: soundSettings['Kill Count']['Count Notification'],
    });
    form.toggle('§aマネー取得通知', {
        defaultValue: soundSettings['Kill Count']['Money Acquisition Notification'],
    });
    form.show(player).then(r => {
        if (r.canceled) {
            Sound_Notification(player);
            return;
        }

        soundSettings['Kill Count']['Count Notification'] = r.formValues[0];
        soundSettings['Kill Count']['Money Acquisition Notification'] = r.formValues[1];

        world.setDynamicProperty('Sound_Notification', JSON.stringify(soundSettings));

        player.sendMessage(`§r[§b設定§r] §aキルカウント通知設定を更新しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        Sound_Notification(player);
    });
}

function OPHARUPAY(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;
    // 管理者マネーの取得
    let adminMoney = world.getDynamicProperty('harupay_op_money') || 0;

    // プレイヤーのマネー取得
    let score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

    // 管理者用HARUPAY画面
    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}\n\n§r>>>§e所持金§r:§b${score}\n§r>>>§c管理者マネー§r:§b${adminMoney}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§9送る', 'textures/ui/normalicon1.png');
    form.button('§5マネー受け取り設定', 'textures/ui/icon_setting.png');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;

        switch (response) {
            case 0:
                // 戻る
                Operator_Controller(player);
                break;

            case 1:
                // 送金処理
                player_Cash_Data[player.id].players = world.getAllPlayers();
                let sendForm = new ActionFormData();
                sendForm.title(`${config['main'][0]}`);
                sendForm.body(`§b§l${time}\n\n§r>>> §e送り先のプレイヤーを選択`);
                sendForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    sendForm.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`, 'textures/ui/normalicon1.png');
                }
                sendForm.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        OPHARUPAY(player);
                        return;
                    }

                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection - 1];

                    let amountForm = new ModalFormData();
                    amountForm.title(`${config['main'][0]}`);
                    amountForm.textField(`§b§l${time}\n\n§r§b送金額§r(半角数字)`, '0');
                    amountForm.submitButton(`§1確認画面へ`);
                    amountForm.show(player).then(r => {
                        if (r.canceled) return;
                        if (isNaN(r.formValues[0])) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }
                        if (r.formValues[0] > 100000000) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }
                        if (r.formValues[0] < 0) {
                            player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }

                        player_Cash_Data[player.id].select_money = r.formValues[0] == '' ? 0 : Number(r.formValues[0]);
                        adminMoney = world.getDynamicProperty('harupay_op_money') || 0;

                        let confirmForm = new ActionFormData();
                        confirmForm.title(`${config['main'][0]}`);
                        confirmForm.body(`§b§l${time}§r\n\n§a送信先プレイヤー§r:§b${player_Cash_Data[player.id].select_player.name} \n§e送金額§r:§b${player_Cash_Data[player.id].select_money}\n\n§e///////////////////\n§r処理後管理者マネー残高\n§5>>>§u${adminMoney}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${adminMoney - player_Cash_Data[player.id].select_money}\n§e///////////////////`);
                        confirmForm.button(`§1送金`, 'textures/ui/normalicon1.png');
                        confirmForm.button(`§0キャンセル`, 'textures/ui/normalicon1.png');
                        confirmForm.show(player).then(r => {
                            if (r.canceled) return;
                            if (r.selection == 0) {
                                adminMoney = world.getDynamicProperty('harupay_op_money') || 0;
                                if (adminMoney >= player_Cash_Data[player.id].select_money) {
                                    // 管理者マネーから送金
                                    world.setDynamicProperty('harupay_op_money', adminMoney - player_Cash_Data[player.id].select_money);
                                    player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`);

                                    // メッセージ（送信者名を「管理者」に）
                                    player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§rへ§b${player_Cash_Data[player.id].select_money}§rPAY送信されました`);
                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a管理者§rから§b${player_Cash_Data[player.id].select_money}§rPAY受け取りました`);

                                    // 通知音
                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                    player_Cash_Data[player.id].select_player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                                    // ログ（送信者名を「管理者」に）
                                    logs['harupay'].push([time, '管理者', player_Cash_Data[player.id].select_player.name, player_Cash_Data[player.id].select_money]);
                                } else {
                                    player.sendMessage(`§r[§bHARUPAY§r] §4管理者マネーが不足しています`);
                                    player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                }
                            } else {
                                OPHARUPAY(player);
                            }
                        });
                    });
                });
                break;
            case 2:
                let settings = world.getDynamicProperty('harupay_op_settings');
                settings = JSON.parse(settings);
                let form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.toggle('§aブラウザ', {
                    defaultValue: settings.browser,
                });
                form.toggle('§a社会システム', {
                    defaultValue: settings.socialSystem,
                });
                form.toggle('§aPost', {
                    defaultValue: settings.post,
                });

                form.show(player).then(r => {
                    if (r.canceled) return;

                    let newSettings = {
                        browser: r.formValues[0],
                        socialSystem: r.formValues[1],
                        post: r.formValues[1],
                    };

                    world.setDynamicProperty('harupay_op_settings', JSON.stringify(newSettings));
                    player.sendMessage(`§r[§bHARUPAY§r] §a設定を更新しました`);
                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                });
                break;
        }
    });
}

//ログ ----
export function Log(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §r確認する§aログ§rを§e選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§9${config['AppName'][1]}`, 'textures/ui/pay');
    form.button('§1Quick', 'textures/ui/quick');
    form.button('§2仕事依頼', 'textures/ui/work');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                HARUPAY_Log(player);
                break;
            case 2:
                Quick_Log(player);
                break;
            case 3:
                Quest_Log(player);
                break;
        }
    });
}

export function HARUPAY_Log(player) {
    var logs_list = '';
    for (let i = 0; i < logs['harupay'].length; i++) {
        logs_list = logs_list + `§s${logs['harupay'][i][0]} §a${logs['harupay'][i][1]}§rから§a${logs['harupay'][i][2]}§rへ§e${logs['harupay'][i][3]}§r送信\n`;
    }

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${config['AppName'][1]}-LOG§r\n${logs_list}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
                break;
        }
    });
}

export function Quick_Log(player) {
    var logs_list = '';
    for (let i = 0; i < logs['quick'].length; i++) {
        logs_list = logs_list + `§s${logs['quick'][i][0]} §a${logs['quick'][i][1]}§rから§a${logs['quick'][i][2]}§rへ§e${logs['quick'][i][3]}§r送信\n`;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§lQuick-LOG§r\n${logs_list}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
                break;
        }
    });
}

export function Quest_Log(player) {
    var logs_list = '';
    for (let i = 0; i < logs['quest'].length; i++) {
        logs_list = logs_list + `§s${logs['quest'][i][0]} §a${logs['quest'][i][1]}§rが§a${logs['quest'][i][3]}§rを受けた §a募集者§r:§e${logs['quest'][i][2]}\n`;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l仕事依頼-LOG§r\n${logs_list}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Log(player);
                break;
        }
    });
}

//データ編集
export function Data_Editing(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §eデータ編集する項目を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4換金データ\n§1追加§r/§0編集§r/§5削除', 'textures/ui/redeem');
    form.button('§9購入データ\n§1追加§r/§0編集§r/§5削除', 'textures/ui/purchase');
    form.button('§1Coin§r-§5Bill §2金額\n§0編集', 'textures/items/money/coinA');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                Exchange_dataEdit(player);
                break;
            case 2:
                Purchase_dataEdit(player);
                break;
            case 3:
                Money_item_amountEdit(player);
                break;
        }
    });
}

export function Exchange_dataEdit(player) {
    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e換金データ');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1アイテム追加', 'textures/ui/normalicon1.png');
    form.button('§0アイテム編集', 'textures/ui/normalicon1.png');
    form.button('§5アイテム削除', 'textures/ui/normalicon1.png');
    form.button('§2ジャンル管理', 'textures/ui/normalicon1.png');

    form.show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            let kannkin_information = world.getDynamicProperty('kannkin_information');
            let kannkin_information_system2 = kannkin_information ? JSON.parse(kannkin_information) : [];
            let kannkin_genres = world.getDynamicProperty('kannkin_genres');
            let genres = kannkin_genres ? JSON.parse(kannkin_genres) : ['一般'];

            switch (response) {
                case 0:
                    Data_Editing(player);
                    break;
                case 1: // アイテム追加
                    let formAdd = new ModalFormData();
                    formAdd.title(`${config['main'][0]}`);
                    formAdd.textField('§aアイテム名', 'ダイアモンド');
                    formAdd.textField('§eアイテム換金金額', '0');
                    formAdd.textField('§bアイテムID', 'diamond');
                    formAdd.textField('§cアイコンパス(任意)', 'items/diamond');
                    formAdd.dropdown('ジャンル', [...genres, '新しいジャンルを追加'], {
                        defaultValueIndex: 0,
                    });
                    formAdd.textField('新しいジャンル名（選択した場合は入力）', '');

                    formAdd.show(player).then(r => {
                        if (r.canceled) {
                            Exchange_dataEdit(player);
                            return;
                        }
                        let [itemName, price, itemId, icon, genreIndex, newGenre] = r.formValues;
                        let selectedGenre = genreIndex === genres.length ? newGenre : genres[genreIndex];

                        if (genreIndex === genres.length && (!newGenre || newGenre.trim() === '')) {
                            player.sendMessage(`§r[§b換金§r] §4新しいジャンル名を入力してください`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }

                        if (genreIndex === genres.length && !genres.includes(newGenre)) {
                            genres.push(newGenre);
                            world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                        }

                        kannkin_information_system2.push([itemName, price, itemId, icon, selectedGenre]);
                        world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));

                        player.sendMessage(`§r[§b換金§r] §aアイテムを追加しました`);
                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                        let kannkin_log = world.getDynamicProperty('kannkin_log');
                        let kannkin_log_system2 = kannkin_log ? JSON.parse(kannkin_log) : [];
                        kannkin_log_system2.push(0);
                        world.setDynamicProperty('kannkin_log', JSON.stringify(kannkin_log_system2));

                        Exchange_dataEdit(player);
                    });
                    break;
                case 2: // アイテム編集
                    if (!kannkin_information_system2.length) {
                        player.sendMessage(`§r[§b換金§r] §a編集できるアイテムがありません`);
                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                        Exchange_dataEdit(player);
                        return;
                    }

                    let formEditSelect = new ActionFormData();
                    formEditSelect.title(`${config['main'][0]}`);
                    formEditSelect.body('編集する換金アイテム/ブロックを選択');
                    formEditSelect.button(`§l戻る`, 'textures/ui/icon_import.png');
                    kannkin_information_system2.forEach(item => {
                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                        formEditSelect.button(`§1${item[0]} §51個§0:§s${item[1]} §0(${item[4]})`, icon);
                    });

                    formEditSelect.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Exchange_dataEdit(player);
                            return;
                        }
                        let index = r.selection - 1;
                        let item = kannkin_information_system2[index];

                        // 現在のジャンルのインデックスを取得
                        const currentGenreIndex = genres.indexOf(item[4]);
                        let formEdit = new ModalFormData();
                        formEdit.title(`${config['main'][0]}`);
                        formEdit.textField('§aアイテム名', '', {
                            defaultValue: item[0],
                        });
                        formEdit.textField('§eアイテム金額', '', {
                            defaultValue: item[1],
                        });
                        formEdit.textField('§bアイテムID', '', {
                            defaultValue: item[2],
                        });
                        formEdit.textField('§cアイコンパス(任意)', '', {
                            defaultValue: item[3],
                        });
                        formEdit.dropdown('ジャンル', [...genres, '新しいジャンルを追加'], {
                            defaultValueIndex: currentGenreIndex !== -1 ? currentGenreIndex : 0,
                        });
                        formEdit.textField('新しいジャンル名（選択した場合は入力）', '');

                        formEdit.show(player).then(r => {
                            if (r.canceled) {
                                Exchange_dataEdit(player);
                                return;
                            }
                            let [name, price, id, icon, genreIndex, newGenre] = r.formValues;
                            let selectedGenre = genreIndex === genres.length ? newGenre : genres[genreIndex];

                            if (genreIndex === genres.length && (!newGenre || newGenre.trim() === '')) {
                                player.sendMessage(`§r[§b換金§r] §4新しいジャンル名を入力してください`);
                                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                return;
                            }

                            if (genreIndex === genres.length && !genres.includes(newGenre)) {
                                genres.push(newGenre);
                                world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                            }

                            if (name) item[0] = name;
                            if (price) item[1] = price;
                            if (id) item[2] = id;
                            if (icon) item[3] = icon;
                            item[4] = selectedGenre;

                            world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));
                            player.sendMessage(`§r[§b換金§r] §aアイテムを編集しました`);
                            player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                            Exchange_dataEdit(player);
                        });
                    });
                    break;
                case 3: // アイテム削除
                    if (!kannkin_information_system2.length) {
                        player.sendMessage(`§r[§b換金§r] §a削除できるアイテムがありません`);
                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                        Exchange_dataEdit(player);
                        return;
                    }

                    let formDelete = new ActionFormData();
                    formDelete.title(`${config['main'][0]}`);
                    formDelete.body('削除する換金アイテム/ブロックを選択');
                    formDelete.button(`§l戻る`, 'textures/ui/icon_import.png');
                    kannkin_information_system2.forEach(item => {
                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                        formDelete.button(`§1${item[0]} §51個§0:§s${item[1]} §0(${item[4]})`, icon);
                    });

                    formDelete.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Exchange_dataEdit(player);
                            return;
                        }
                        let index = r.selection - 1;
                        kannkin_information_system2.splice(index, 1);

                        if (!kannkin_information_system2.length) {
                            kannkin_information_system2 = [];
                        }

                        world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));
                        player.sendMessage(`§r[§b換金§r] §aアイテムを削除しました`);
                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                        let kannkin_log = world.getDynamicProperty('kannkin_log');
                        let kannkin_log_system2 = kannkin_log ? JSON.parse(kannkin_log) : [];
                        kannkin_log_system2.splice(index, 1);
                        world.setDynamicProperty('kannkin_log', JSON.stringify(kannkin_log_system2));

                        Exchange_dataEdit(player);
                    });
                    break;
                case 4: // ジャンル管理
                    let formGenre = new ActionFormData();
                    formGenre.title(`${config['main'][0]}`);
                    formGenre.body('>>> §eジャンル管理§r(§b換金§r)');
                    formGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                    formGenre.button('§1ジャンル追加', 'textures/ui/normalicon1.png');
                    formGenre.button('§0ジャンル編集', 'textures/ui/normalicon1.png');
                    formGenre.button('§5ジャンル削除', 'textures/ui/normalicon1.png');

                    formGenre.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Exchange_dataEdit(player);
                            return;
                        }

                        switch (r.selection) {
                            case 1: // ジャンル追加
                                let formAddGenre = new ModalFormData();
                                formAddGenre.title(`${config['main'][0]}`);
                                formAddGenre.textField('新しいジャンル名', '');
                                formAddGenre.show(player).then(r => {
                                    if (r.canceled) {
                                        return;
                                    }
                                    if (!r.formValues[0] || r.formValues[0].trim() === '') {
                                        player.sendMessage(`§r[§b換金§r] §4ジャンル名を入力してください`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Exchange_dataEdit(player);
                                        return;
                                    }
                                    let newGenre = r.formValues[0];
                                    if (genres.includes(newGenre)) {
                                        player.sendMessage(`§r[§b換金§r] §4このジャンルはすでに存在します`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Exchange_dataEdit(player);
                                        return;
                                    }
                                    genres.push(newGenre);
                                    world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                                    player.sendMessage(`§r[§b換金§r] §aジャンルを追加しました`);
                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                    Exchange_dataEdit(player);
                                });
                                break;
                            case 2: // ジャンル編集
                                let formEditGenre = new ActionFormData();
                                formEditGenre.title(`${config['main'][0]}`);
                                formEditGenre.body('編集するジャンルを選択');
                                formEditGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                                genres.forEach(genre => {
                                    formEditGenre.button(`§1${genre}`, 'textures/ui/normalicon1');
                                });

                                formEditGenre.show(player).then(r => {
                                    if (r.canceled || r.selection === 0) {
                                        Exchange_dataEdit(player);
                                        return;
                                    }
                                    let index = r.selection - 1;
                                    let oldGenre = genres[index];

                                    let formEditGenreName = new ModalFormData();
                                    formEditGenreName.title(`${config['main'][0]}`);
                                    formEditGenreName.textField('新しいジャンル名', oldGenre);
                                    formEditGenreName.show(player).then(r => {
                                        if (r.canceled || !r.formValues[0] || r.formValues[0].trim() === '') {
                                            player.sendMessage(`§r[§b換金§r] §4ジャンル名を入力してください`);
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            Exchange_dataEdit(player);
                                            return;
                                        }
                                        let newGenre = r.formValues[0];
                                        if (genres.includes(newGenre)) {
                                            player.sendMessage(`§r[§b換金§r] §4このジャンルはすでに存在します`);
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            Exchange_dataEdit(player);
                                            return;
                                        }
                                        genres[index] = newGenre;
                                        kannkin_information_system2.forEach(item => {
                                            if (item[4] === oldGenre) item[4] = newGenre;
                                        });
                                        world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                                        world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));
                                        player.sendMessage(`§r[§b換金§r] §aジャンルを編集しました`);
                                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                        Exchange_dataEdit(player);
                                    });
                                });
                                break;
                            case 3: // ジャンル削除
                                let formDeleteGenre = new ActionFormData();
                                formDeleteGenre.title(`${config['main'][0]}`);
                                formDeleteGenre.body('削除するジャンルを選択');
                                formDeleteGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                                genres.forEach(genre => {
                                    formDeleteGenre.button(`§1${genre}`, 'textures/ui/normalicon1');
                                });

                                formDeleteGenre.show(player).then(r => {
                                    if (r.canceled || r.selection === 0) {
                                        Exchange_dataEdit(player);
                                        return;
                                    }
                                    let index = r.selection - 1;
                                    let genreToDelete = genres[index];

                                    if (genreToDelete === '一般') {
                                        player.sendMessage(`§r[§b換金§r] §4デフォルトジャンル「一般」は削除できません`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Exchange_dataEdit(player);
                                        return;
                                    }

                                    // ジャンルのアイテムを一般に移動
                                    kannkin_information_system2.forEach(item => {
                                        if (item[4] === genreToDelete) item[4] = '一般';
                                    });
                                    genres.splice(index, 1);
                                    world.setDynamicProperty('kannkin_genres', JSON.stringify(genres));
                                    world.setDynamicProperty('kannkin_information', JSON.stringify(kannkin_information_system2));
                                    player.sendMessage(`§r[§b換金§r] §aジャンルを削除しました`);
                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                    Exchange_dataEdit(player);
                                });
                                break;
                        }
                    });
                    break;
            }
        })
        .catch(e => {
            console.error(e, e.stack);
        });
}

//購入データ編集画面
export function Purchase_dataEdit(player) {
    let form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e購入データ');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1アイテム追加', 'textures/ui/normalicon1.png');
    form.button('§0アイテム編集', 'textures/ui/normalicon1.png');
    form.button('§5アイテム削除', 'textures/ui/normalicon1.png');
    form.button('§2ジャンル管理', 'textures/ui/normalicon1.png');

    form.show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            let kounyuu_list = world.getDynamicProperty('kounyuu_list');
            let kounyuu_list_system2 = kounyuu_list ? JSON.parse(kounyuu_list) : [];
            let kounyuu_genres = world.getDynamicProperty('kounyuu_genres');
            let genres = kounyuu_genres ? JSON.parse(kounyuu_genres) : ['一般'];

            switch (response) {
                case 0:
                    Data_Editing(player);
                    break;
                case 1: // アイテム追加
                    let formAdd = new ModalFormData();
                    formAdd.title(`${config['main'][0]}`);
                    formAdd.textField('§aアイテム名', 'ダイアモンド');
                    formAdd.textField('§eアイテム金額', '0');
                    formAdd.textField('§bアイテムID', 'diamond');
                    formAdd.textField('§cアイコンパス(任意)', 'items/diamond');
                    formAdd.dropdown('ジャンル', [...genres, '新しいジャンルを追加'], {
                        defaultValueIndex: 0,
                    });
                    formAdd.textField('新しいジャンル名（選択した場合は入力）', '');

                    formAdd.show(player).then(r => {
                        if (r.canceled) {
                            Purchase_dataEdit(player);
                            return;
                        }
                        let [itemName, price, itemId, icon, genreIndex, newGenre] = r.formValues;
                        let selectedGenre = genreIndex === genres.length ? newGenre : genres[genreIndex];

                        if (genreIndex === genres.length && (!newGenre || newGenre.trim() === '')) {
                            player.sendMessage(`§r[§b購入§r] §4新しいジャンル名を入力してください`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }

                        if (genreIndex === genres.length && !genres.includes(newGenre)) {
                            genres.push(newGenre);
                            world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                        }

                        kounyuu_list_system2.push([itemName, price, itemId, icon, selectedGenre]);
                        world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));

                        player.sendMessage(`§r[§b購入§r] §aアイテムを追加しました`);
                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                        let kounyuu_log = world.getDynamicProperty('kounyuu_log');
                        let kounyuu_log_system2 = kounyuu_log ? JSON.parse(kounyuu_log) : [];
                        kounyuu_log_system2.push(0);
                        world.setDynamicProperty('kounyuu_log', JSON.stringify(kounyuu_log_system2));

                        Purchase_dataEdit(player);
                    });
                    break;
                case 2: // アイテム編集
                    if (!kounyuu_list_system2.length) {
                        player.sendMessage(`§r[§b購入§r] §a編集できるアイテムがありません`);
                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                        Purchase_dataEdit(player);
                        return;
                    }

                    let formEditSelect = new ActionFormData();
                    formEditSelect.title(`${config['main'][0]}`);
                    formEditSelect.body('編集する購入アイテム/ブロックを選択');
                    formEditSelect.button(`§l戻る`, 'textures/ui/icon_import.png');
                    kounyuu_list_system2.forEach(item => {
                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                        formEditSelect.button(`§1${item[0]} §51個§0/§s${item[1]} §0(${item[4]})`, icon);
                    });

                    formEditSelect.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Purchase_dataEdit(player);
                            return;
                        }
                        let index = r.selection - 1;
                        let item = kounyuu_list_system2[index];
                        // 現在のジャンルのインデックスを取得
                        const currentGenreIndex = genres.indexOf(item[4]);

                        let formEdit = new ModalFormData();
                        formEdit.title(`${config['main'][0]}`);
                        formEdit.textField('§aアイテム名', '', {
                            defaultValue: item[0],
                        });
                        formEdit.textField('§eアイテム金額', '', {
                            defaultValue: item[1],
                        });
                        formEdit.textField('§bアイテムID', '', {
                            defaultValue: item[2],
                        });
                        formEdit.textField('§cアイコンパス(任意)', '', {
                            defaultValue: item[3],
                        });
                        formEdit.dropdown('ジャンル', [...genres, '新しいジャンルを追加'], {
                            defaultValueIndex: currentGenreIndex !== -1 ? currentGenreIndex : 0,
                        });
                        formEdit.textField('新しいジャンル名（選択した場合は入力）', '');

                        formEdit.show(player).then(r => {
                            if (r.canceled) {
                                Purchase_dataEdit(player);
                                return;
                            }
                            let [name, price, id, icon, genreIndex, newGenre] = r.formValues;
                            let selectedGenre = genreIndex === genres.length ? newGenre : genres[genreIndex];

                            if (genreIndex === genres.length && (!newGenre || newGenre.trim() === '')) {
                                player.sendMessage(`§r[§b購入§r] §4新しいジャンル名を入力してください`);
                                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                return;
                            }

                            if (genreIndex === genres.length && !genres.includes(newGenre)) {
                                genres.push(newGenre);
                                world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                            }

                            if (name) item[0] = name;
                            if (price) item[1] = price;
                            if (id) item[2] = id;
                            if (icon) item[3] = icon;
                            item[4] = selectedGenre;

                            world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));
                            player.sendMessage(`§r[§b購入§r] §aアイテムを編集しました`);
                            player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                            Purchase_dataEdit(player);
                        });
                    });
                    break;
                case 3: // アイテム削除
                    if (!kounyuu_list_system2.length) {
                        player.sendMessage(`§r[§b購入§r] §a削除できるアイテムがありません`);
                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                        Purchase_dataEdit(player);
                        return;
                    }

                    let formDelete = new ActionFormData();
                    formDelete.title(`${config['main'][0]}`);
                    formDelete.body('削除する購入アイテム/ブロックを選択');
                    formDelete.button(`§l戻る`, 'textures/ui/icon_import.png');
                    kounyuu_list_system2.forEach(item => {
                        let icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
                        formDelete.button(`§1${item[0]} §51個§0/§s${item[1]} §0(${item[4]})`, icon);
                    });

                    formDelete.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Purchase_dataEdit(player);
                            return;
                        }
                        let index = r.selection - 1;
                        kounyuu_list_system2.splice(index, 1);

                        if (!kounyuu_list_system2.length) {
                            kounyuu_list_system2 = [];
                        }

                        world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));
                        player.sendMessage(`§r[§b購入§r] §aアイテムを削除しました`);
                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                        let kounyuu_log = world.getDynamicProperty('kounyuu_log');
                        let kounyuu_log_system2 = kounyuu_log ? JSON.parse(kounyuu_log) : [];
                        kounyuu_log_system2.splice(index, 1);
                        world.setDynamicProperty('kounyuu_log', JSON.stringify(kounyuu_log_system2));

                        Purchase_dataEdit(player);
                    });
                    break;
                case 4: // ジャンル管理
                    let formGenre = new ActionFormData();
                    formGenre.title(`${config['main'][0]}`);
                    formGenre.body('>>> §eジャンル管理§r(§b購入§r)');
                    formGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                    formGenre.button('§1ジャンル追加', 'textures/ui/normalicon1.png');
                    formGenre.button('§0ジャンル編集', 'textures/ui/normalicon1.png');
                    formGenre.button('§5ジャンル削除', 'textures/ui/normalicon1.png');

                    formGenre.show(player).then(r => {
                        if (r.canceled || r.selection === 0) {
                            Purchase_dataEdit(player);
                            return;
                        }

                        switch (r.selection) {
                            case 1: // ジャンル追加
                                let formAddGenre = new ModalFormData();
                                formAddGenre.title(`${config['main'][0]}`);
                                formAddGenre.textField('新しいジャンル名', '');
                                formAddGenre.show(player).then(r => {
                                    if (r.canceled || !r.formValues[0] || r.formValues[0].trim() === '') {
                                        player.sendMessage(`§r[§b購入§r] §4ジャンル名を入力してください`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Purchase_dataEdit(player);
                                        return;
                                    }
                                    let newGenre = r.formValues[0];
                                    if (genres.includes(newGenre)) {
                                        player.sendMessage(`§r[§b購入§r] §4このジャンルはすでに存在します`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Purchase_dataEdit(player);
                                        return;
                                    }
                                    genres.push(newGenre);
                                    world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                                    player.sendMessage(`§r[§b購入§r] §aジャンルを追加しました`);
                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                    Purchase_dataEdit(player);
                                });
                                break;
                            case 2: // ジャンル編集
                                let formEditGenre = new ActionFormData();
                                formEditGenre.title(`${config['main'][0]}`);
                                formEditGenre.body('編集するジャンルを選択');
                                formEditGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                                genres.forEach(genre => {
                                    formEditGenre.button(`§1${genre}`, 'textures/ui/normalicon1');
                                });

                                formEditGenre.show(player).then(r => {
                                    if (r.canceled || r.selection === 0) {
                                        Purchase_dataEdit(player);
                                        return;
                                    }
                                    let index = r.selection - 1;
                                    let oldGenre = genres[index];

                                    let formEditGenreName = new ModalFormData();
                                    formEditGenreName.title(`${config['main'][0]}`);
                                    formEditGenreName.textField('新しいジャンル名', oldGenre);
                                    formEditGenreName.show(player).then(r => {
                                        if (r.canceled || !r.formValues[0] || r.formValues[0].trim() === '') {
                                            player.sendMessage(`§r[§b購入§r] §4ジャンル名を入力してください`);
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            Purchase_dataEdit(player);
                                            return;
                                        }
                                        let newGenre = r.formValues[0];
                                        if (genres.includes(newGenre)) {
                                            player.sendMessage(`§r[§b購入§r] §4このジャンルはすでに存在します`);
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            Purchase_dataEdit(player);
                                            return;
                                        }
                                        genres[index] = newGenre;
                                        kounyuu_list_system2.forEach(item => {
                                            if (item[4] === oldGenre) item[4] = newGenre;
                                        });
                                        world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                                        world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));
                                        player.sendMessage(`§r[§b購入§r] §aジャンルを編集しました`);
                                        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                        Purchase_dataEdit(player);
                                    });
                                });
                                break;
                            case 3: // ジャンル削除
                                let formDeleteGenre = new ActionFormData();
                                formDeleteGenre.title(`${config['main'][0]}`);
                                formDeleteGenre.body('削除するジャンルを選択');
                                formDeleteGenre.button(`§l戻る`, 'textures/ui/icon_import.png');
                                genres.forEach(genre => {
                                    formDeleteGenre.button(`§1${genre}`, 'textures/ui/normalicon1');
                                });

                                formDeleteGenre.show(player).then(r => {
                                    if (r.canceled || r.selection === 0) {
                                        Purchase_dataEdit(player);
                                        return;
                                    }
                                    let index = r.selection - 1;
                                    let genreToDelete = genres[index];

                                    if (genreToDelete === '一般') {
                                        player.sendMessage(`§r[§b購入§r] §4デフォルトジャンル「一般」は削除できません`);
                                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                        Purchase_dataEdit(player);
                                        return;
                                    }

                                    // ジャンルのアイテムを一般に移動
                                    kounyuu_list_system2.forEach(item => {
                                        if (item[4] === genreToDelete) item[4] = '一般';
                                    });
                                    genres.splice(index, 1);
                                    world.setDynamicProperty('kounyuu_genres', JSON.stringify(genres));
                                    world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));
                                    player.sendMessage(`§r[§b購入§r] §aジャンルを削除しました`);
                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                    Purchase_dataEdit(player);
                                });
                                break;
                        }
                    });
                    break;
            }
        })
        .catch(e => {
            console.error(e, e.stack);
        });
}

export function Money_item_amountEdit(player) {
    const MoneyItems_NameID = ['>>> §e各アイテムの金額を設定してください\n§c[半角数字]§r\ncoinA', 'coinB', 'coinC', 'coinD', 'coinE', 'billA', 'billB', 'billC'];
    var MoneyItems_score = JSON.parse(world.getDynamicProperty('MoneyItems_score'));
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    for (let i = 0; i < MoneyItems_score.length; i++) {
        form.textField(`${MoneyItems_NameID[i]}`, `${MoneyItems_score[i]}`);
    }
    form.show(player).then(r => {
        if (r.canceled) {
            Data_Editing(player);
            return;
        }
        for (let i = 0; i < MoneyItems_score.length; i++) {
            if (r.formValues[i] != '') {
                MoneyItems_score[i] = Number(r.formValues[i]);
            }
        }
        world.setDynamicProperty('MoneyItems_score', JSON.stringify(MoneyItems_score));
        player.sendMessage(`§r[§b設定§r] §a金額を編集しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        Data_Editing(player);
    });
}

//データ権限削除----
export function Delete_Data(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §5削除操作§rをする機能を§e選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§0Quickデータ\n§1選択§5>>>§4削除', 'textures/ui/quick');
    form.button('§2仕事依頼データ\n§1選択§5>>>§4削除', 'textures/ui/work');
    form.button('§5ブラウザページ\n§1選択§5>>>§4削除', 'textures/ui/browser');
    form.button('§1広告データ\n§1選択§5>>>§4削除', 'textures/ui/browser');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                Quick_Data_Deletion(player);
                break;
            case 2:
                Quest_Data_Deletion(player);
                break;
            case 3:
                Delete_browser_page(player);
                break;
            case 4:
                Delete_browser_ad(player);
                break;
        }
    });
}

export function Quick_Data_Deletion(player) {
    // shop_menu をグローバル変数として初期化
    var shop_menu = loadShopMenu();
    // 商品削除処理
    if (shop_menu[0].length == 0) {
        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        Delete_Data(player);
        return;
    }

    player_Cash_Data[player.id].my_shop = [];
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e削除できる商品一覧');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < shop_menu[0].length; i++) {
        form.button(`§1${shop_menu[0][i][0]}\n§0金額:§s${shop_menu[0][i][2]}§0PAY  出品者:§2${shop_menu[0][i][1]}`, 'textures/ui/normalicon1');
        player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
    }

    if (player_Cash_Data[player.id].my_shop.length == 0) {
        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        Delete_Data(player);
        return;
    }

    form.show(player)
        .then(r => {
            if (r.canceled) {
                return;
            }
            if (r.selection == 0) {
                Delete_Data(player);
                return;
            }
            for (let i = 0; i < shop_menu[0].length; i++) {
                if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection - 1][5]) {
                    shop_menu[0].splice(i, 1);
                    break;
                }
            }
            player.sendMessage(`§r[§bQuick§r] §a削除しました`);
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            saveShopMenu(shop_menu); // データ保存
            Delete_Data(player);
        })
        .catch(e => {
            console.error(e, e.stack);
        });
}

export function Quest_Data_Deletion(player) {
    if (quest[0][0] == undefined) {
        player.sendMessage(`§r[§b設定§r] §aデータがありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        Delete_Data(player);
        return;
    }

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e削除できる仕事依頼一覧');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < quest[0].length; i++) {
        form.button(`§1${quest[0][i][0]}\n§0報酬額:§s${quest[0][i][2]}§0PAY  §0依頼者:§2${quest[0][i][3]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        if (response == 0) {
            Delete_Data(player);
            return;
        }
        player.sendMessage(`§r[§b設定§r] §b${quest[0][response - 1][0]}§aを削除しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        quest[0].splice(response - 1, 1);
        Delete_Data(player);
    });
}

export function Delete_browser_page(player) {
    var browser_system2 = loadSplitProperty('browser');

    if (browser_system2.length === 0) {
        player.sendMessage(`§r[§bブラウザ§r] §a削除できるページがありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e削除するページを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_system2.length; i++) {
        form.button(`§0§l${browser_system2[i][2]}\n§r§0投稿者:§1${browser_system2[i][0]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            Delete_Data(player);
            return;
        }
        let response = r.selection - 1;
        browser_system2.splice(response, 1);

        // saveSplitProperty を使ってデータを保存する
        saveSplitProperty('browser', browser_system2);

        player.sendMessage(`§r[§bブラウザ§r] §aページを削除しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
    });
}

export function Delete_browser_ad(player) {
    var browser_system2 = loadSplitProperty('performance');

    if (browser_system2.length === 0) {
        player.sendMessage(`§r[§bブラウザ§r] §a削除できる広告がありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e削除する広告を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_system2.length; i++) {
        form.button(`§0§l${browser_system2[i][2]}\n§r§0投稿者:§1${browser_system2[i][0]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            Delete_Data(player);
            return;
        }
        let response = r.selection - 1;
        browser_system2.splice(response, 1);

        saveSplitProperty('performance', browser_system2);

        player.sendMessage(`§r[§bブラウザ§r] §a広告を削除しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
    });
}

export function Browser_usage_fee(player) {
    var form = new ActionFormData();
    form.title(`§1ブラウザ設定`);
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§5ページ投稿金額\n§0(§1${world.getDynamicProperty('browser_newpage_money')}§0)`, 'textures/ui/normalicon1');
    form.button(`§0広告化金額\n§0(§1${world.getDynamicProperty('browser_performance_money')}§0)`, 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                var form = new ModalFormData();
                form.title(`§5ページ投稿金額`);
                form.textField('§eページ投稿金額(半角数字)', `${world.getDynamicProperty('browser_newpage_money')}`, {
                    defaultValue: `${world.getDynamicProperty('browser_newpage_money')}`,
                });
                form.show(player).then(r => {
                    if (r.canceled) {
                        Browser_usage_fee(player);
                        return;
                    }
                    world.setDynamicProperty('browser_newpage_money', r.formValues[0]);
                    player.sendMessage(`§r[§bブラウザ§r] §aページ投稿金額を設定しました`);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    Browser_usage_fee(player);
                });
                break;
            case 2:
                var form = new ModalFormData();
                form.title(`§1広告化金額`);
                form.textField('§e広告化金額(半角数字)', `${world.getDynamicProperty('browser_performance_money')}`, {
                    defaultValue: `${world.getDynamicProperty('browser_performance_money')}`,
                });
                form.show(player).then(r => {
                    if (r.canceled) {
                        Browser_usage_fee(player);
                        return;
                    }
                    world.setDynamicProperty('browser_performance_money', r.formValues[0]);
                    player.sendMessage(`§r[§bブラウザ§r] §a広告化金額を設定しました`);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    Browser_usage_fee(player);
                });
                break;
        }
    });
}

//その他----
export function others(player) {
    //自動付与システム (true/false)
    const currentStatus = world.getDynamicProperty('money_start_system2') ?? 0;

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§4初期金額の再設定\n§0現在:§s${world.getDynamicProperty('start_money')}`, `textures/ui/pay`);
    form.button('§1新規プレイヤー\n§0手動付与', `textures/ui/normalicon1`);
    form.button(`§0自動付与システム\n§0(${currentStatus === 0 ? '§1有効' : '§4無効'}§0)`, `textures/ui/normalicon1`);
    form.button('§4キルカウントシステム', `textures/ui/normalicon1`);
    form.button('§0データ維持設定', 'textures/ui/normalicon1');
    form.button(`§4残高リスト表示\n§0(${world.getDynamicProperty('MoneyList_allow') ? '§1有効' : '§4無効'}§0)`, 'textures/ui/pay');
    form.button('§5時刻設定', `textures/ui/normalicon1`);
    form.button('§1自動販売機コマンド設定', `textures/blocks/penjualan`);
    form.button(`§4自動販売機売り上げ表示\n§0(${world.getDynamicProperty('Penjualan_Moneyshow_allow') ? '§1有効' : '§4無効'}§0)`, `textures/blocks/penjualan`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                Initial_amount_reset(player);
                break;
            case 2:
                New_player_grant(player);
                break;
            case 3:
                Automatic_Granting_System(player);
                break;
            case 4:
                Kill_Count_System(player);
                break;
            case 5:
                Data_Keep(player);
                break;
            case 6:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e残高リスト表示');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.button(`${world.getDynamicProperty('MoneyList_allow') ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        others(player);
                        return;
                    }
                    if (r.selection == 1) {
                        world.setDynamicProperty('MoneyList_allow', !world.getDynamicProperty('MoneyList_allow'));
                        player.sendMessage(`§r[§b設定§r] §a残高リストの表示設定を更新しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        others(player);
                    }
                });
                break;
            case 7:
                //時刻を取得
                const now = new Date();
                const japanTime = new Date(now.getTime() + 0 * 60 * 60 * 1000);
                const hours = String(japanTime.getUTCHours()).padStart(2, '0');
                const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
                var time = `${hours}:${minutes}`;

                const Time_Setting = world.getDynamicProperty('Time_Setting');

                new ModalFormData()
                    .title(`${config['main'][0]}`)
                    .textField(`§b${time} §aからの時差を入力してください`, `${Time_Setting}`)
                    .submitButton('§1適用')
                    .show(player)
                    .then(res => {
                        if (res.canceled) {
                            others(player);
                            return;
                        }

                        const toggleValue = Number(res.formValues[0]);
                        world.setDynamicProperty('Time_Setting', toggleValue);
                        player.sendMessage(`[§b設定§r] §a時刻を設定しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        HARUPhone1(player);
                    });
                break;
            case 8:
                Penjualan_Command_Edit(player);
                break;
            case 9:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e自動販売機売り上げ表示');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.button(`${world.getDynamicProperty('Penjualan_Moneyshow_allow') ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        others(player);
                        return;
                    }
                    if (r.selection == 1) {
                        world.setDynamicProperty('Penjualan_Moneyshow_allow', !world.getDynamicProperty('Penjualan_Moneyshow_allow'));
                        player.sendMessage(`§r[§b設定§r] §a自動販売機売り上げの表示設定を更新しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        others(player);
                    }
                });
                break;
        }
    });
}

function Penjualan_Command_Edit(player) {
    // 最初の選択フォーム: 追加、編集、削除をアクションボタンで選択
    var selectForm = new ActionFormData();
    selectForm.title('§1自動販売機');
    selectForm.body('§5>>>§a操作を選択してください\n§c※自動販売機が読み込まれない距離での実行はできません');
    selectForm.button(`§l戻る`, 'textures/ui/icon_import.png');
    selectForm.button('§1追加', 'textures/ui/normalicon1');
    selectForm.button('§0編集', 'textures/ui/normalicon1');
    selectForm.button('§4削除', 'textures/ui/normalicon1');

    selectForm.show(player).then(response => {
        if (response.canceled || response.selection === undefined) return; // キャンセル時は終了

        const choice = response.selection; // 選択したボタン（0:追加, 1:編集, 2:削除）

        // 動的プロパティから現在のコマンドリストを取得
        let Penjualan_Command = [];
        if (world.getDynamicProperty('Penjualan_Command') != undefined) {
            Penjualan_Command = JSON.parse(world.getDynamicProperty('Penjualan_Command'));
        }

        if (choice === 0) {
            others(player);
        } else if (choice === 1) {
            var addForm = new ModalFormData();
            addForm.title('§1コマンドを追加');
            addForm.textField('ID', '', {
                defaultValue: 'penjualan:',
            });
            addForm.textField('X座標', '0');
            addForm.textField('Y座標', '0');
            addForm.textField('Z座標', '0');

            addForm.show(player).then(r => {
                if (r.canceled) return;

                // 新しいコマンドを追加
                Penjualan_Command.push([
                    r.formValues[0], // ID
                    {
                        x: Number(r.formValues[1]), // X座標
                        y: Number(r.formValues[2]), // Y座標
                        z: Number(r.formValues[3]), // Z座標
                    },
                ]);

                // 動的プロパティを更新
                world.setDynamicProperty('Penjualan_Command', JSON.stringify(Penjualan_Command));

                // 通知とサウンド
                player.sendMessage(`§r[§b自動販売機§r] §aコマンドを追加しました`);
                player.playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: config['Volume'],
                });
                Penjualan_Command_Edit(player);
            });
        }

        // 2. 編集機能
        else if (choice === 2) {
            if (Penjualan_Command.length === 0) {
                player.sendMessage(`§r[§b自動販売機§r] §c編集するコマンドがありません`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
                Penjualan_Command_Edit(player);
                return;
            }

            // ID一覧を取得
            const idList = Penjualan_Command.map(cmd => cmd[0]);

            var editSelectForm = new ModalFormData();
            editSelectForm.title('編集するコマンドを選択');
            editSelectForm.dropdown('IDを選択', idList, 0);

            editSelectForm.show(player).then(r => {
                if (r.canceled) return;

                const selectedIndex = r.formValues[0]; // 選択したコマンドのインデックス
                const selectedCommand = Penjualan_Command[selectedIndex];

                // 編集フォームを表示（現在の値をデフォルトとして設定）
                var editForm = new ModalFormData();
                editForm.title('コマンドを編集');
                editForm.textField('ID', '', {
                    defaultValue: selectedCommand[0],
                });
                editForm.textField('X座標', '', {
                    defaultValue: selectedCommand[1].x.toString(),
                });
                editForm.textField('Y座標', '', {
                    defaultValue: selectedCommand[1].y.toString(),
                });
                editForm.textField('Z座標', '', {
                    defaultValue: selectedCommand[1].z.toString(),
                });

                editForm.show(player).then(editResponse => {
                    if (editResponse.canceled) return;

                    // 選択したコマンドを更新
                    Penjualan_Command[selectedIndex] = [
                        editResponse.formValues[0], // 新しいID
                        {
                            x: Number(editResponse.formValues[1]), // 新しいX座標
                            y: Number(editResponse.formValues[2]), // 新しいY座標
                            z: Number(editResponse.formValues[3]), // 新しいZ座標
                        },
                    ];

                    // 動的プロパティを更新
                    world.setDynamicProperty('Penjualan_Command', JSON.stringify(Penjualan_Command));

                    // 通知とサウンド
                    player.sendMessage(`§r[§b自動販売機§r] §aコマンドを編集しました`);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    Penjualan_Command_Edit(player);
                });
            });
        }

        // 3. 削除機能
        else if (choice === 3) {
            if (Penjualan_Command.length === 0) {
                player.sendMessage(`§r[§b自動販売機§r] §c削除するコマンドがありません`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
                Penjualan_Command_Edit(player);
                return;
            }

            // ID一覧を取得
            const idList = Penjualan_Command.map(cmd => cmd[0]);

            var deleteSelectForm = new ModalFormData();
            deleteSelectForm.title('削除するコマンドを選択');
            deleteSelectForm.dropdown('IDを選択', idList, {
                defaultValueIndex: 0,
            });

            deleteSelectForm.show(player).then(r => {
                if (r.canceled) return;

                const selectedIndex = r.formValues[0]; // 選択したコマンドのインデックス

                // 選択したコマンドを削除
                Penjualan_Command.splice(selectedIndex, 1);

                // 動的プロパティを更新
                world.setDynamicProperty('Penjualan_Command', JSON.stringify(Penjualan_Command));

                // 通知とサウンド
                player.sendMessage(`§r[§b自動販売機§r] §aコマンドを削除しました`);
                player.playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: config['Volume'],
                });
                Penjualan_Command_Edit(player);
            });
        }
    });
}

export function Initial_amount_reset(player) {
    world.setDynamicProperty('op_fast', undefined);
    player.sendMessage(`§r[§b設定§r] §aリセットしました§r-§cHARUPhone1§eを開いて再設定してください`);
    player.playSound('haru.notification1', {
        pitch: 1.7,
        volume: config['Volume'],
    });
}

export function New_player_grant(player) {
    var players = world.getAllPlayers();
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e新規プレイヤーに付与');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < players.length; i++) {
        form.button(`§1${players[i].name}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.selection == 0) {
            others(player);
            return;
        }
        let response = r.selection - 1;
        if (r.canceled) {
            return;
        }
        var partner1 = players[response];
        if (partner1.hasTag('HARUPAY_Member')) {
            player.sendMessage(`§r[§b設定§r] §c選択したプレイヤーは付与済みです`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            New_player_grant(player);
            return;
        }
        partner1.runCommand('give @s additem:haruphone1');
        player.runCommand(`scoreboard players add @s money 0`);
        const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
        if (score == 0) {
            partner1.runCommand(`scoreboard players set @s money ${world.getDynamicProperty('start_money')}`);
        }
        partner1.runCommand(`scoreboard players set @s account 0`);
        partner1.runCommand('tag @s add HARUPAY_Member');
        player.sendMessage(`§r[§b設定§r] §e${players[response].name}に付与しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        New_player_grant(player);
    });
}

export function Automatic_Granting_System(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e自動付与システム');

    const currentStatus = world.getDynamicProperty('money_start_system2') ?? 0;

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`${currentStatus === 0 ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            others(player);
            return;
        }
        if (r.selection == 1) {
            const nextStatus = currentStatus === 0 ? 1 : 0;

            world.setDynamicProperty('money_start_system2', nextStatus);

            player.sendMessage(`§r[§b設定§r] §a自動付与システムの設定を更新しました`);
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            others(player);
        }
    });
}
//-キルカウント-
export function Kill_Count_System(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§0キルカウントシステム\n§0(${world.getDynamicProperty('killPointSystem') ? '§1有効' : '§4無効'}§0)`, 'textures/ui/normalicon1');
    form.button('§4エンティティ§0/§1ポイント\n§0編集', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            others(player);
            return;
        }
        let response = r.selection - 1;
        switch (response) {
            case 0:
                world.setDynamicProperty('killPointSystem', !world.getDynamicProperty('killPointSystem'));
                player.sendMessage(`§r[§bキルポイント§r] §aシステムを${world.getDynamicProperty('killPointSystem') ? '§b有効化' : '§c無効化'}§rしました`);
                player.playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: config['Volume'],
                });
                Kill_Count_System(player);
                break;
            case 1:
                Kill_Count_System_edit(player);
                break;
        }
    });
}

export function Data_Keep(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§0Quick\n§0(${world.getDynamicProperty('Quick_DataSAVE') ? '§1有効' : '§4無効'}§0)`, 'textures/ui/quick');
    form.button(`§0仕事依頼\n§0(${world.getDynamicProperty('Work_DataSAVE') ? '§1有効' : '§4無効'}§0)`, 'textures/ui/work');
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            others(player);
            return;
        }
        let response = r.selection - 1;
        switch (response) {
            case 0:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §eQuickデータ維持');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.button(`${world.getDynamicProperty('Quick_DataSAVE') ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Data_Keep(player);
                        return;
                    }
                    if (r.selection == 1) {
                        world.setDynamicProperty('Quick_DataSAVE', !world.getDynamicProperty('Quick_DataSAVE'));
                        player.sendMessage(`§r[§b設定§r] §aQuickデータ維持設定を更新しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        Data_Keep(player);
                    }
                });
                break;
            case 1:
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e仕事依頼データ維持');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.button(`${world.getDynamicProperty('Work_DataSAVE') ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Data_Keep(player);
                        return;
                    }
                    if (r.selection == 1) {
                        world.setDynamicProperty('Work_DataSAVE', !world.getDynamicProperty('Work_DataSAVE'));
                        player.sendMessage(`§r[§b設定§r] §a仕事依頼データ維持設定を更新しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        Data_Keep(player);
                    }
                });
                break;
        }
    });
}

export function UI_Customization(player) {
    var HARUPhone1_AppNumber = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'));
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    for (let i = 0; i < config['AppData'].length - 1; i++) {
        form.dropdown(`App${i}`, config['AppData'], {
            defaultValueIndex: HARUPhone1_AppNumber[i],
        });
    }
    form.submitButton(`§0適用`);
    // フォームを表示
    form.show(player).then(r => {
        if (r.canceled) {
            Operator_Controller(player);
            return;
        }
        HARUPhone1_AppNumber = [];
        for (let i = 0; i < config['AppData'].length - 1; i++) {
            if (r.formValues[i] != 0 && r.formValues[i] != config['AppData'].length - 1) {
                HARUPhone1_AppNumber.push(r.formValues[i]);
            }
        }
        if (HARUPhone1_AppNumber.includes(config['AppData'].length - 1) == false) {
            HARUPhone1_AppNumber.push(config['AppData'].length - 1);
        }
        world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber));
        player.sendMessage(`§r[§b設定§r] §aUI設定を完了しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        HARUPhone1(player);
    });
}
