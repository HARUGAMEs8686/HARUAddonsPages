import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { getSecureRandom, Game_system } from '../blockrun/game';

const activeSlotPlayers = new Set();

export function openSlotMachine(player) {
    if (activeSlotPlayers.has(player.id)) {
        player.sendMessage('§cゲーム実行中です');
        return;
    }

    // スコアボードから所持金を取得する内部関数
    function getMoney(player) {
        return new Promise(resolve => {
            system.run(() => {
                const score = world.scoreboard.getObjective('money')?.getScore(player.scoreboardIdentity) ?? 0;
                resolve(score);
            });
        });
    }

    try {
        const text = world.getDynamicProperty('SLOT_BET_AMOUNTS') ?? '100,500,1000';
        const BET_AMOUNTS = text
            .split(',')
            .map(Number)
            .filter(n => n > 0);

        if (BET_AMOUNTS.length === 0) {
            player.sendMessage('§cベット額が設定されていません。管理者に連絡してください。');
            return;
        }

        getMoney(player).then(currentMoney => {
            const form = new ActionFormData();
            form.title('§1スロットマシン');
            form.body(`§aHARUPAY所持金: §b${currentMoney}`);

            BET_AMOUNTS.forEach((amount, index) => {
                form.button(`§${(index % 5) + 1}${amount}`);
            });
            form.button('§5>>>やめる<<<');

            form.show(player).then(res => {
                if (res.canceled || res.selection === BET_AMOUNTS.length) {
                    Game_system(player);
                    return;
                }

                const betIndex = res.selection;
                const bet = BET_AMOUNTS[betIndex];
                getMoney(player).then(money => {
                    if (money < bet) {
                        player.sendMessage('§c所持金が不足しています。');
                        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                        openSlotMachine(player);
                        return;
                    }
                    // スロットゲーム実行
                    playSlotReels(player, bet, betIndex);
                });
            });
        });
    } catch (e) {
        player.sendMessage(`§cエラーが発生しました: ${e.message}`);
    }
}

function playSlotReels(player, bet, betIndex) {
    activeSlotPlayers.add(player.id);
    // スコアボード操作の内部関数
    function getMoney(player) {
        return new Promise(resolve => {
            system.run(() => {
                const score = world.scoreboard.getObjective('money')?.getScore(player.scoreboardIdentity) ?? 0;
                resolve(score);
            });
        });
    }
    function setMoney(player, amount) {
        world.scoreboard.getObjective('money').setScore(player.scoreboardIdentity, amount);
    }

    try {
        // 設定を読み込む
        const symbolsText = world.getDynamicProperty('SLOT_SYMBOLS') ?? '1,2,3';
        const symbols = symbolsText.split(',');

        const rewardsText = world.getDynamicProperty('SLOT_REWARDS') ?? '1:1,2:2,3:3';
        const rewards = rewardsText.split(',').reduce((obj, str) => {
            const [key, value] = str.split(':');
            obj[key] = Number(value);
            return obj;
        }, {});

        if (symbols.length < 1) {
            player.sendMessage('§cシンボルが設定されていません。');
            return;
        }

        // 所持金を取得してから処理を開始
        getMoney(player).then(currentMoney => {
            // ベット額を支払う
            setMoney(player, currentMoney - bet);
            player.sendMessage(`§c-${bet}円§rでスロットを回しました。`);

            // 3つのリールの結果をランダムに決定
            const results = [symbols[getSecureRandom(player, symbols.length)], symbols[getSecureRandom(player, symbols.length)], symbols[getSecureRandom(player, symbols.length)]];

            //システムの脆弱性を対策する最終システム
            if (player.hasTag('HARUPhone1_BlackList_GAME') && symbols.length > 1) {
                if (results[0] === results[1] && results[1] === results[2]) {
                    let forcedLoser;
                    do {
                        forcedLoser = symbols[getSecureRandom(player, symbols.length)];
                    } while (forcedLoser === results[0]);

                    results[2] = forcedLoser;
                }
            }

            let display = ['  ', '  ', '  '];

            // リール演出の開始
            player.playSound('note.hat', { pitch: 0.5, volume: config['Volume'] });
            player.runCommand(`title @s actionbar スロット開始`);
            player.runCommand(`title @s title §r[${display[0]}] [${display[1]}] [${display[2]}]`);

            // 20tick (1秒) 後に1つ目のリールを表示
            system.runTimeout(() => {
                display[0] = `§e${results[0]}§r`;
                player.playSound('note.hat', { pitch: 1.0, volume: config['Volume'] });
                player.runCommand(`title @s title §r[${display[0]}] [${display[1]}] [${display[2]}]`);

                // さらに20tick後に2つ目のリールを表示
                system.runTimeout(() => {
                    display[1] = `§e${results[1]}§r`;
                    player.playSound('note.hat', { pitch: 1.2, volume: config['Volume'] });
                    player.runCommand(`title @s title §r[${display[0]}] [${display[1]}] [${display[2]}]`);

                    // さらに20tick後に3つ目のリールを表示
                    system.runTimeout(() => {
                        display[2] = `§e${results[2]}§r`;
                        player.playSound('note.hat', { pitch: 1.5, volume: config['Volume'] });
                        player.runCommand(`title @s title §r[${display[0]}] [${display[1]}] [${display[2]}]`);

                        // 40tick (結果表示)後に当たり判定
                        system.runTimeout(() => {
                            if (results[0] === results[1] && results[1] === results[2]) {
                                // --- 当たりの処理 ---
                                const wonSymbol = results[0];
                                const betMultiStr = world.getDynamicProperty('SLOT_BET_MULTIPLIERS') ?? '';
                                const betMultiList = betMultiStr.trim() !== '' ? betMultiStr.split(',').map(s => Number(s.trim())) : [];
                                const betModifier = betMultiList[betIndex] !== undefined && !isNaN(betMultiList[betIndex]) ? betMultiList[betIndex] : 1;

                                const multiplier = rewards[wonSymbol] ?? 1;
                                const reward = Math.floor(bet * multiplier * betModifier);

                                getMoney(player).then(finalMoney => {
                                    setMoney(player, finalMoney + reward);
                                    player.sendMessage(`§a当たり！ §e${wonSymbol}§aが揃いました！\n§a報酬: §e${reward}`);
                                    player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                                    player.playSound('haru.notification1', {
                                        pitch: 1.7,
                                        volume: config['Volume'],
                                    });
                                    player.playSound('random.levelup', { volume: config['Volume'], pitch: 1.5 });

                                    activeSlotPlayers.delete(player.id);
                                    // 3秒後に再度メニューを開く
                                    system.runTimeout(() => openSlotMachine(player), 20);
                                });
                            } else {
                                // --- はずれの処理 ---
                                player.sendMessage('§9残念...はずれです。');
                                player.playSound('haru.notification1', {
                                    pitch: 0.6,
                                    volume: config['Volume'],
                                });

                                activeSlotPlayers.delete(player.id);
                                // 3秒後に再度メニューを開く
                                system.runTimeout(() => openSlotMachine(player), 10);
                            }
                        }, 10);
                    }, 20);
                }, 20);
            }, 20);
        });
    } catch (e) {
        player.sendMessage(`§cスロットのプレイ中にエラーが発生しました: ${e.message}`);
        activeSlotPlayers.delete(player.id);
    }
}
