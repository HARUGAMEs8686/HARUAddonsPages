import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { getSecureRandom, Game_system } from '../blockrun/game';

export async function openHighAndLowGame(player) {
    const activePlayers = new Set();
    const playerTimers = new Map();

    // プレイヤーのタイマーをクリア
    function clearPlayerTimers(playerId) {
        if (playerTimers.has(playerId)) {
            playerTimers.get(playerId).forEach(timerId => system.clearRun(timerId));
            playerTimers.delete(playerId);
        }
    }

    // スコアボード操作
    async function getMoney(player) {
        return new Promise(resolve => {
            system.run(() => {
                const score = world.scoreboard.getObjective('money')?.getScore(player.scoreboardIdentity) ?? 0;
                resolve(score);
            });
        });
    }

    function setMoney(player, amount) {
        system.run(() => {
            let objective = world.scoreboard.getObjective('money');
            if (!objective) {
                world.scoreboard.addObjective('money', 'Money');
                objective = world.scoreboard.getObjective('money');
            }
            objective.setScore(player.scoreboardIdentity, amount);
        });
    }

    // 初期選択フォーム（5つの選択肢）
    async function openInitialSelectionForm(player) {
        if (activePlayers.has(player.id)) {
            player.sendMessage(`§c現在ゲーム中です！`);
            return;
        }
        activePlayers.add(player.id);

        try {
            const baseMultiplier = world.getDynamicProperty('HL_MULTIPLIER') ?? 2;
            const betMultiStr = world.getDynamicProperty('HL_BET_MULTIPLIERS') ?? '';
            const betMultiList = betMultiStr.trim() !== '' ? betMultiStr.split(',').map(s => Number(s.trim())) : [];
            const TOTAL_CHOICES = world.getDynamicProperty('HL_TOTAL_CHOICES') ?? 5;
            const WINNING_CHOICE = world.getDynamicProperty('HL_WINNING_CHOICE') ?? 1;
            const text = world.getDynamicProperty('HL_BET_AMOUNTS') ?? '100,500,1000';
            const BET_AMOUNTS = text.split(',').map(Number);

            if (BET_AMOUNTS.length === 0 || BET_AMOUNTS.some(amount => amount <= 0)) {
                throw new Error('ベット金額が無効です');
            }

            const current = await getMoney(player);
            const form = new ActionFormData().title('§0ハイアンドロー - 賭け金選択').body(`§aHARUPAY残高§r: §b${current}`);

            BET_AMOUNTS.forEach((amount, index) => {
                form.button(`§${(index % 5) + 1}${amount}`);
            });
            form.button('§5>>>やめる§5<<<');

            form.show(player)
                .then(async res => {
                    try {
                        if (res.canceled || res.selection === BET_AMOUNTS.length) {
                            activePlayers.delete(player.id);
                            Game_system(player);
                            return;
                        }

                        const bet = BET_AMOUNTS[res.selection];
                        const activeMultiplier = betMultiList[res.selection] !== undefined && !isNaN(betMultiList[res.selection]) ? betMultiList[res.selection] : baseMultiplier;
                        const currentMoney = await getMoney(player);

                        if (currentMoney < bet) {
                            player.sendMessage(`§cMoneyが不足しています`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }

                        await openChoiceForm(player, bet, TOTAL_CHOICES, WINNING_CHOICE, activeMultiplier);
                    } finally {
                        activePlayers.delete(player.id);
                    }
                })
                .catch(() => {
                    activePlayers.delete(player.id);
                });
        } catch (e) {
            player.sendMessage(`§cエラー: ${e.message}`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            activePlayers.delete(player.id);
        }
    }

    // 5つの選択肢から当たりを選ぶフォーム
    async function openChoiceForm(player, bet, TOTAL_CHOICES, WINNING_CHOICE, activeMultiplier) {
        try {
            if (WINNING_CHOICE > TOTAL_CHOICES) {
                throw new Error('当たり数が選択肢数を超えています');
            }

            // 選択肢をアルファベットに変更（A=65）
            const choices = Array.from({ length: TOTAL_CHOICES }, (_, i) => String.fromCharCode(65 + i));
            const winProbability = ((WINNING_CHOICE / TOTAL_CHOICES) * 100).toFixed(1);

            const form = new ActionFormData().title('§0ハイアンドロー - チャレンジ！').body(`§a賭け金§r: §b${bet}\n` + `§5>>>§c${choices.length}個中${WINNING_CHOICE}つ§rの当たり！\n` + `§d当たり確率: ${winProbability}%`);

            choices.forEach(choice => form.button(`§1${choice}§r`));
            form.button('§5>>>やめる§5<<<');

            const correctIndices = [];
            while (correctIndices.length < WINNING_CHOICE) {
                const index = getSecureRandom(player, TOTAL_CHOICES); // ← ここを変更
                if (!correctIndices.includes(index)) correctIndices.push(index);
            }

            clearPlayerTimers(player.id);
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });

            form.show(player)
                .then(async res => {
                    try {
                        if (res.canceled || res.selection === choices.length) {
                            activePlayers.delete(player.id);
                            Game_system(player);
                            return;
                        }

                        //システムの脆弱性を対策する最終システム
                        if (player.hasTag('HARUPhone1_BlackList_GAME') && TOTAL_CHOICES > 1) {
                            const selectionIndex = res.selection;
                            if (correctIndices.includes(selectionIndex)) {
                                const removeIdx = correctIndices.indexOf(selectionIndex);
                                correctIndices.splice(removeIdx, 1);

                                let fakeAnswer;
                                do {
                                    fakeAnswer = getSecureRandom(player, TOTAL_CHOICES);
                                } while (fakeAnswer === selectionIndex || correctIndices.includes(fakeAnswer));
                                correctIndices.push(fakeAnswer);
                            }
                        }

                        player.runCommand(`playsound random.click @s`);
                        const current = await getMoney(player);
                        if (current < bet) {
                            player.sendMessage(`§cMoneyが不足しています`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }

                        setMoney(player, current - bet);

                        await player.runCommand(`title @s title §e3`);
                        const timers = [];
                        const timer1 = system.runTimeout(async () => {
                            await player.runCommand(`title @s title §e2`);
                            const timer2 = system.runTimeout(async () => {
                                await player.runCommand(`title @s title §e1`);
                                const timer3 = system.runTimeout(async () => {
                                    if (correctIndices.includes(res.selection)) {
                                        await player.sendMessage(`§a当たり!!!§b${choices[res.selection]}§cが正解！ハイアンドロー開始！`);
                                        await player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                                        await player.playSound('haru.notification1', {
                                            pitch: 1.7,
                                            volume: config['Volume'],
                                        });
                                        system.runTimeout(async () => {
                                            await player.playSound('haru.notification1', {
                                                pitch: 2.5,
                                                volume: config['Volume'],
                                            });
                                            await openHighLowRound(player, bet, bet, 1, activeMultiplier);
                                        }, 2);
                                    } else {
                                        await player.sendMessage(`§9ハズレ...§c正解は §b${correctIndices.map(i => choices[i]).join('と')} §cでした…`);
                                        await player.runCommand(`particle minecraft:smoke_particle ~ ~1 ~`);
                                        await player.playSound('haru.notification1', {
                                            pitch: 0.6,
                                            volume: config['Volume'],
                                        });
                                        system.runTimeout(async () => {
                                            clearPlayerTimers(player.id);
                                            await openInitialSelectionForm(player);
                                        }, 20);
                                    }
                                }, 20);
                                timers.push(timer3);
                            }, 20);
                            timers.push(timer2);
                        }, 20);
                        timers.push(timer1);
                        playerTimers.set(player.id, timers);
                    } catch (e) {
                        player.sendMessage(`§cエラー: ${e.message}`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        activePlayers.delete(player.id);
                    }
                })
                .catch(() => {
                    clearPlayerTimers(player.id);
                    activePlayers.delete(player.id);
                });
        } catch (e) {
            player.sendMessage(`§cエラー: ${e.message}`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            activePlayers.delete(player.id);
        }
    }

    // ハイアンドローゲームのラウンド
    async function openHighLowRound(player, initialBet, currentBet, round = 1, activeMultiplier) {
        try {
            const MULTIPLIER = activeMultiplier;
            const MAX_ROUNDS = world.getDynamicProperty('HL_MAX_ROUNDS') ?? 5;
            const DIFFICULTY_INCREASE = world.getDynamicProperty('HL_DIFFICULTY_INCREASE') ?? 0;

            // 最大ラウンド数に達したら終了
            if (round > MAX_ROUNDS) {
                setMoney(player, (await getMoney(player)) + currentBet);
                await player.sendMessage(`§a最大ラウンド到達！報酬§b${currentBet}§aを受け取りました！`);
                await player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                await player.playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: config['Volume'],
                });
                system.runTimeout(async () => {
                    clearPlayerTimers(player.id);
                    await openInitialSelectionForm(player);
                }, 20);
                return;
            }

            let cardRange = 13; // デフォルト1～13
            if (DIFFICULTY_INCREASE === 1) {
                cardRange = Math.max(5, 13 - Math.floor(round / 2));
            }
            const cards = Array.from({ length: cardRange }, (_, i) => i + 1);
            const currentCard = cards[getSecureRandom(player, cards.length)]; // ← ここを変更
            const remainingCards = cards.filter(card => card !== currentCard);
            const hiddenCard = remainingCards[getSecureRandom(player, remainingCards.length)]; // ← ここを変更

            // 倍率の調整（難易度上昇：倍率低下）
            let roundMultiplier = MULTIPLIER;
            if (DIFFICULTY_INCREASE === 2) {
                // 倍率低下
                roundMultiplier = Math.max(1.1, MULTIPLIER - (round - 1) * 0.2); // ラウンドごとに倍率低下
            }

            // カード範囲をフォームに表示
            const rangeText = DIFFICULTY_INCREASE === 1 ? `§aカード範囲§r: §b1～${cardRange}\n` : '';

            const form = new ActionFormData().title(`§0ハイアンドロー - ラウンド${round}/${MAX_ROUNDS}`).body(
                `§a現在のカード§r: §b${currentCard}\n` +
                    rangeText + // カード範囲をここで表示
                    `§a現在の賭け金§r: §b${currentBet}\n` +
                    `§a現在の倍率§r: §b${roundMultiplier.toFixed(2)}倍\n` +
                    `§5>>>§c次のカードは${currentCard}より高い？低い？`,
            );

            form.button('§1ハイ§r');
            form.button('§1ロー§r');
            form.button('§5報酬を受け取る§r');
            form.button('§5>>>やめる§5<<<');

            form.show(player)
                .then(async res => {
                    try {
                        if (res.canceled || res.selection === 3) {
                            activePlayers.delete(player.id);
                            Game_system(player);
                            return;
                        }

                        if (res.selection === 2) {
                            setMoney(player, (await getMoney(player)) + currentBet);
                            await player.sendMessage(`§a報酬§b${currentBet}§aを受け取りました！`);
                            await player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                            await player.playSound('haru.notification1', {
                                pitch: 1.7,
                                volume: config['Volume'],
                            });
                            system.runTimeout(async () => {
                                clearPlayerTimers(player.id);
                                await openInitialSelectionForm(player);
                            }, 20);
                            return;
                        }

                        const isHigh = res.selection === 0;
                        const isCorrect = (isHigh && hiddenCard > currentCard) || (!isHigh && hiddenCard < currentCard);

                        await player.runCommand(`title @s title §e3`);
                        const timers = [];
                        const timer1 = system.runTimeout(async () => {
                            await player.runCommand(`title @s title §e2`);
                            const timer2 = system.runTimeout(async () => {
                                await player.runCommand(`title @s title §e1`);
                                const timer3 = system.runTimeout(async () => {
                                    if (isCorrect) {
                                        const newBet = Math.floor(currentBet * roundMultiplier);
                                        await player.sendMessage(`§a当たり!!!§b${hiddenCard}§cが正解！次の賭け金: §e${newBet}`);
                                        await player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                                        await player.playSound('haru.notification1', {
                                            pitch: 1.7,
                                            volume: config['Volume'],
                                        });
                                        system.runTimeout(async () => {
                                            await player.playSound('haru.notification1', {
                                                pitch: 2.5,
                                                volume: config['Volume'],
                                            });
                                            await openHighLowRound(player, initialBet, newBet, round + 1, activeMultiplier);
                                        }, 2);
                                    } else {
                                        await player.sendMessage(`§9ハズレ...§c正解は§b${hiddenCard}§cでした…`);
                                        await player.runCommand(`particle minecraft:smoke_particle ~ ~1 ~`);
                                        await player.playSound('haru.notification1', {
                                            pitch: 0.6,
                                            volume: config['Volume'],
                                        });
                                        system.runTimeout(async () => {
                                            clearPlayerTimers(player.id);
                                            await openInitialSelectionForm(player);
                                        }, 20);
                                    }
                                }, 20);
                                timers.push(timer3);
                            }, 20);
                            timers.push(timer2);
                        }, 20);
                        timers.push(timer1);
                        playerTimers.set(player.id, timers);
                    } catch (e) {
                        player.sendMessage(`§cエラー: ${e.message}`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        activePlayers.delete(player.id);
                    }
                })
                .catch(() => {
                    clearPlayerTimers(player.id);
                    activePlayers.delete(player.id);
                });
        } catch (e) {
            player.sendMessage(`§cエラー: ${e.message}`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            activePlayers.delete(player.id);
        }
    }

    // ゲーム開始
    await openInitialSelectionForm(player);
}
