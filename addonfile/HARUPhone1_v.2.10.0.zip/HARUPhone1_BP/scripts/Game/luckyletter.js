import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';
import { getSecureRandom, Game_system } from '../blockrun/game';

const activePlayers = new Set();
const playerTimers = new Map();

// プレイヤーのタイマーをクリア
function clearPlayerTimers(playerId) {
    if (playerTimers.has(playerId)) {
        playerTimers.get(playerId).forEach(timerId => system.clearRun(timerId));
        playerTimers.delete(playerId);
    }
}

// スコアボード操作
async function getMoney(player) {
    return new Promise(resolve => {
        system.run(() => {
            const score = world.scoreboard.getObjective('money')?.getScore(player.scoreboardIdentity) ?? 0;
            resolve(score);
        });
    });
}

function setMoney(player, amount) {
    system.run(() => {
        let objective = world.scoreboard.getObjective('money');
        if (!objective) {
            world.scoreboard.addObjective('money', 'Money');
            objective = world.scoreboard.getObjective('money');
        }
        objective.setScore(player.scoreboardIdentity, amount);
    });
}

// 選択肢の生成（A〜Zまで対応）
function generateLetters(count) {
    if (count < 1 || count > 26) throw new Error('選択肢の数は1〜26で設定してください');
    return Array.from({ length: count }, (_, i) => String.fromCharCode(65 + i)); // A=65
}

// ベット金額選択フォーム
export async function openBetForm(player) {
    if (activePlayers.has(player.id)) {
        player.sendMessage(`§c現在ゲーム中です！`);
        return;
    }
    activePlayers.add(player.id);

    try {
        // グローバル設定をローカルにコピー
        const MULTIPLIER = world.getDynamicProperty('MULTIPLIER') ?? 3;
        const TOTAL_LETTERS = world.getDynamicProperty('TOTAL_LETTERS') ?? 10;
        const WINNING_COUNT = world.getDynamicProperty('WINNING_COUNT') ?? 1;
        const text = world.getDynamicProperty('BET_AMOUNTS') ?? '100,500,1000';
        const BET_AMOUNTS = text.split(',').map(Number);
        const baseMultiplier = world.getDynamicProperty('MULTIPLIER') ?? 3;
        const betMultiStr = world.getDynamicProperty('LL_BET_MULTIPLIERS') ?? '';
        const betMultiList = betMultiStr.trim() !== '' ? betMultiStr.split(',').map(s => Number(s.trim())) : [];

        // ベット金額のバリデーション
        if (BET_AMOUNTS.length === 0 || BET_AMOUNTS.some(amount => amount <= 0)) {
            throw new Error('ベット金額が無効です');
        }

        const current = await getMoney(player);
        const form = new ActionFormData().title('§0賭け金を選択').body(`§aHARUPAY残高§r: §b${current}`);

        // 動的にベット金額ボタンを追加
        BET_AMOUNTS.forEach((amount, index) => {
            form.button(`§${(index % 5) + 1}${amount}`);
        });
        form.button('§5>>>やめる§5<<<');

        form.show(player)
            .then(async res => {
                try {
                    if (res.canceled || res.selection === BET_AMOUNTS.length) {
                        Game_system(player);
                        return;
                    }

                    const bet = BET_AMOUNTS[res.selection];
                    const currentMoney = await getMoney(player);
                    const activeMultiplier = betMultiList[res.selection] !== undefined && !isNaN(betMultiList[res.selection]) ? betMultiList[res.selection] : baseMultiplier;

                    if (currentMoney < bet) {
                        player.sendMessage(`§cMoneyが不足しています`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        return;
                    }

                    await openLetterForm(player, bet, activeMultiplier, TOTAL_LETTERS, WINNING_COUNT);
                } finally {
                    activePlayers.delete(player.id);
                }
            })
            .catch(() => {
                activePlayers.delete(player.id);
            });
    } catch (e) {
        player.sendMessage(`§cエラー: ${e.message}`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        activePlayers.delete(player.id);
    }
}

// A〜?の選択フォーム
async function openLetterForm(player, bet, MULTIPLIER, TOTAL_LETTERS, WINNING_COUNT) {
    try {
        // 設定のバリデーション
        if (WINNING_COUNT > TOTAL_LETTERS) {
            throw new Error('当たり数が選択肢数を超えています');
        }

        const letters = generateLetters(TOTAL_LETTERS);
        const winProbability = ((WINNING_COUNT / TOTAL_LETTERS) * 100).toFixed(1);

        const form = new ActionFormData().title('§0ギャンブルチャレンジ！').body(`§a賭け金§r: §b${bet}\n` + `§5>>>§c${letters.length}個中${WINNING_COUNT}つ§rの当たりで§e${bet * MULTIPLIER}§rゲット！\n` + `§d当たり確率: ${winProbability}%`);

        letters.forEach(letter => form.button(`§1${letter}§r`));
        form.button('§cやめる§r');

        // ランダムに当たりインデックスを選択
        const correctIndices = [];
        while (correctIndices.length < WINNING_COUNT) {
            const index = getSecureRandom(player, TOTAL_LETTERS); // ← ここを変更
            if (!correctIndices.includes(index)) correctIndices.push(index);
        }

        clearPlayerTimers(player.id); // 既存のタイマーをクリア
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });

        form.show(player)
            .then(async res => {
                try {
                    if (res.canceled || res.selection === letters.length) {
                        activePlayers.delete(player.id);
                        Game_system(player);
                        return;
                    }

                    //システムの脆弱性を対策する最終システム
                    if (player.hasTag('HARUPhone1_BlackList_GAME') && TOTAL_LETTERS > 1) {
                        const selectionIndex = res.selection;
                        if (correctIndices.includes(selectionIndex)) {
                            const removeIdx = correctIndices.indexOf(selectionIndex);
                            correctIndices.splice(removeIdx, 1);
                            let fakeAnswer;
                            do {
                                fakeAnswer = getSecureRandom(player, TOTAL_LETTERS);
                            } while (fakeAnswer === selectionIndex || correctIndices.includes(fakeAnswer));

                            correctIndices.push(fakeAnswer);
                        }
                    }

                    player.runCommand(`playsound random.click @s`);
                    const current = await getMoney(player);
                    if (current < bet) {
                        player.sendMessage(`§cMoneyが不足しています`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        return;
                    }

                    setMoney(player, current - bet);

                    // カウントダウン演出
                    const timers = [];
                    await player.runCommand(`title @s title §e3`);
                    const timer1 = system.runTimeout(async () => {
                        await player.runCommand(`title @s title §e2`);
                        const timer2 = system.runTimeout(async () => {
                            await player.runCommand(`title @s title §e1`);
                            const timer3 = system.runTimeout(async () => {
                                if (correctIndices.includes(res.selection)) {
                                    const reward = bet * MULTIPLIER;
                                    setMoney(player, (await getMoney(player)) + reward);
                                    await player.sendMessage(`§a当たり!!!§b${letters[res.selection]}§cが正解！§a+§e${reward}`);
                                    await player.runCommand(`particle minecraft:heart_particle ~ ~1 ~`);
                                    await player.playSound('haru.notification1', {
                                        pitch: 1.7,
                                        volume: config['Volume'],
                                    });
                                    system.runTimeout(async () => {
                                        await player.playSound('haru.notification1', {
                                            pitch: 2.5,
                                            volume: config['Volume'],
                                        });
                                    }, 2);
                                } else {
                                    await player.sendMessage(`§9ハズレ...§c正解は §b${correctIndices.map(i => letters[i]).join('と')} §cでした…`);
                                    await player.runCommand(`particle minecraft:smoke_particle ~ ~1 ~`);
                                    await player.playSound('haru.notification1', {
                                        pitch: 0.6,
                                        volume: config['Volume'],
                                    });
                                }
                                system.runTimeout(async () => {
                                    clearPlayerTimers(player.id);
                                    await openBetForm(player);
                                }, 20);
                            }, 20);
                            timers.push(timer3);
                        }, 20);
                        timers.push(timer2);
                    }, 20);
                    timers.push(timer1);
                    playerTimers.set(player.id, timers);
                } catch (e) {
                    player.sendMessage(`§cエラー: ${e.message}`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                } finally {
                    if (!playerTimers.has(player.id)) {
                        activePlayers.delete(player.id);
                    }
                }
            })
            .catch(() => {
                clearPlayerTimers(player.id);
                activePlayers.delete(player.id);
            });
    } catch (e) {
        player.sendMessage(`§cエラー: ${e.message}`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        activePlayers.delete(player.id);
    }
}
