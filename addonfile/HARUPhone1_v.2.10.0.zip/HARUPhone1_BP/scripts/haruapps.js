import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { App } from './App/AppMenu';
import { config } from './config';

export var HARUAppsDATA = {
    AppLoad: [],
};

export function HARUApps() {
    system.afterEvents.scriptEventReceive.subscribe(eventData => {
        const { id, message, sourceEntity: player } = eventData;

        //>>> HARUApps
        if (id === 'haruapps:push') {
            const args = message.split(' ');
            if (args.length < 2) {
                return;
            }
            const ApplicationName = args[0];
            const Command = args.slice(1).join(' ');

            if (!HARUAppsDATA.AppLoad.includes(ApplicationName)) {
                HARUAppsDATA.AppLoad.push(ApplicationName);
                HARUAppsDATA[ApplicationName] = [];
            }
            HARUAppsDATA[ApplicationName].push(Command);
        }
        if (id === 'haruapps:reset') {
            HARUAppsDATA = {
                AppLoad: [],
            };
        }
    });
}
