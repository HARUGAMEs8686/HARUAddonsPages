export const config = {
    defaultBlacklist: ['HARUAddons8'],
    uiItem: 'additem:blacklist',
    adminTag: 'SecurityOP',
};
