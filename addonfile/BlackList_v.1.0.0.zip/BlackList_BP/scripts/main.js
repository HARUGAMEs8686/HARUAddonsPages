import * as admin from '@minecraft/server-admin';
import { world, system, CommandPermissionLevel } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from './config.js';
export var playerHARUAppsOpen = {};

// ==========================================
// データの取得・保存系 (Dynamic Propertiesを使用)
// ==========================================

// UI等で手動追加されたリスト(ダイナミックプロパティ)のみを取得
function getDynamicBlacklist() {
    const listStr = world.getDynamicProperty('blacklist');
    return listStr ? JSON.parse(listStr) :[];
}

function isBlacklisted(name) {
    const lowerName = name.toLowerCase();
    const dynamicList = getDynamicBlacklist();
    const configList = (config.defaultBlacklist ||[]).map(n => n.toLowerCase());

    return dynamicList.includes(lowerName) || configList.includes(lowerName);
}

function saveBlacklist(list) {
    world.setDynamicProperty('blacklist', JSON.stringify(list));
}

function addBlacklist(name) {
    const list = getDynamicBlacklist();
    const lowerName = name.toLowerCase();
    const configList = (config.defaultBlacklist ||[]).map(n => n.toLowerCase());

    if (!list.includes(lowerName) && !configList.includes(lowerName)) {
        list.push(lowerName);
        saveBlacklist(list);
    }

    // ブラックリストに追加されたら接続履歴から削除
    removeFromRecentJoined(lowerName);
}

function removeBlacklist(name) {
    const list = getDynamicBlacklist();
    const lowerName = name.toLowerCase();
    const newList = list.filter(n => n !== lowerName);
    saveBlacklist(newList);
}

// ブラックリスト用の履歴機能：最近参加したプレイヤーのリスト
function getRecentJoined() {
    const listStr = world.getDynamicProperty('recentJoined');
    return listStr ? JSON.parse(listStr) :[];
}

function addRecentJoined(name) {
    let list = getRecentJoined();
    const lowerName = name.toLowerCase();
    // 既にリストにあれば削除して一番上(最新)に追加
    list = list.filter(n => n !== lowerName);
    list.unshift(lowerName);
    // 最大20件まで保存
    if (list.length > 20) list.pop();
    world.setDynamicProperty('recentJoined', JSON.stringify(list));
}

function removeFromRecentJoined(name) {
    const list = getRecentJoined();
    const lowerName = name.toLowerCase();
    const newList = list.filter(n => n !== lowerName);
    world.setDynamicProperty('recentJoined', JSON.stringify(newList));
}

system.run(() => {
    // ==========================================
    // プレイヤー参加前のチェック
    // ==========================================

    admin.beforeEvents.asyncPlayerJoin.subscribe(data => {
        const name = data.name.toLowerCase();

        if (isBlacklisted(name)) {
            data.disallowJoin('ブラックリストに登録されています');
            world.sendMessage(`[§bBlacklist§r] §aブラックリスト登録プレイヤーの参加をキャンセルしました§r\n §r>>> §e${name}`);
        } else {
            // ブラックリストに入っていない場合は接続履歴に追加
            system.run(() => {
                addRecentJoined(name);
            });
        }

        return Promise.resolve();
    });
});

// ==========================================
// 管理用UIの表示イベント
// ==========================================

world.afterEvents.itemUse.subscribe(event => {
    const { source, itemStack } = event;

    // プレイヤーが、指定のアイテムを持ち、管理者タグを持っている場合
    if (source.typeId === 'minecraft:player' && itemStack.typeId === config.uiItem) {
        system.run(() => {
            playerHARUAppsOpen[source.id] = false;
            showMainUI(source);
        });
    }
});

const RACE_EVENT_ID = 'haruapps:blacklist';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'hd:blacklist') {
            playerHARUAppsOpen[player.id] = false;
            showMainUI(player);
        }
        if (eventData.id === RACE_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            showMainUI(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

system.beforeEvents.startup.subscribe(eventData => {
    // 起動コマンド
    const Command = {
        name: 'hd:blacklist',
        description: '§cBlackList§eUI§rを開きます',
        permissionLevel: CommandPermissionLevel.Admin,
        mandatoryParameters: [],
        optionalParameters:[],
    };
    eventData.customCommandRegistry.registerCommand(Command, StartUI);
});

function StartUI(origin) {
    const player = origin.sourceEntity;
    system.run(() => {
        playerHARUAppsOpen[player.id] = true;
        showMainUI(player);
    });
}

// ==========================================
// UI画面の構築
// ==========================================

function showMainUI(player) {
    if (!player.hasTag(config.adminTag)) {
        player.sendMessage('[§bBlacklist§r] §c管理者ではありません');
        return;
    }
    const form = new ActionFormData().title('§0ブラックリスト管理').body('>>> §e選択してください');
    if (playerHARUAppsOpen[player.id]) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1接続履歴から追加', 'textures/ui/bubble_empty')
        .button('§0手動で追加 (ゲーマータグ入力)', 'textures/ui/bubble_empty')
        .button('§4リストから削除', 'textures/ui/bubble_empty');

    form.show(player)
        .then(response => {
            if (response.canceled) return;
            if (response.selection === 0) {
                if (playerHARUAppsOpen[player.id]) {
                    player.runCommand('scriptevent haruphone1:apps');
                }
                return;
            }
            if (response.selection === 1) showHistoryUI(player);
            if (response.selection === 2) showManualAddUI(player);
            if (response.selection === 3) showRemoveUI(player);
        })
        .catch(e => console.error(e));
}

function showHistoryUI(player) {
    const history = getRecentJoined();
    if (history.length === 0) {
        player.sendMessage('[§bBlacklist§r] §c最近参加したプレイヤーの履歴はありません');
        return;
    }

    const form = new ActionFormData().title('§0履歴から追加').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');

    history.forEach(name => {
        form.button('§0' + name, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainUI(player);
            return;
        }
        const selectedName = history[response.selection - 1];
        addBlacklist(selectedName);
        player.sendMessage(`[§bBlacklist§r] (§e${selectedName}§r)§aをブラックリストに追加しました`);
    });
}

function showManualAddUI(player) {
    const form = new ModalFormData()
        .title('§0手動で追加')
        .textField('>>> §e追加するゲーマータグを入力\n§a(大文字・小文字は区別されません)', 'ゲーマータグ');

    form.show(player).then(response => {
        if (response.canceled) {
            showMainUI(player);
            return;
        }
        const name = response.formValues[0].trim();
        if (name) {
            addBlacklist(name);
            player.sendMessage(`[§bBlacklist§r] (§e${name}§r)§aをブラックリストに追加しました`);
        } else {
            player.sendMessage('[§bBlacklist§r] §cゲーマータグが入力されていません');
        }
    });
}

function showRemoveUI(player) {
    const blacklist = getDynamicBlacklist();
    if (blacklist.length === 0) {
        player.sendMessage('[§bBlacklist§r] §cブラックリスト登録者が居ません');
        return;
    }

    const form = new ActionFormData().title('§4リストから削除').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    blacklist.forEach(name => {
        form.button('§0' + name, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainUI(player);
            return;
        }
        const selectedName = blacklist[response.selection - 1];
        removeBlacklist(selectedName);
        player.sendMessage(`[§bBlacklist§r] (§e${selectedName}§r) §aをブラックリストから削除しました`);
    });
}