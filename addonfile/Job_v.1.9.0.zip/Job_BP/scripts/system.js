import { world, system } from '@minecraft/server';

const objectiveName = 'money';

// デフォルト設定に制限とポイントの有効/無効設定を追加
export const DEFAULT_CONFIG = {
    system: {
        professionRemoveDays: 7,
        maxProfessions: 2,
        businessSystemEnabled: true, // 全体的なビジネスシステム有効/無効
        levelRankingEnabled: true, // レベルランキング表示の有効/無効 (追加)
    },
    // 各職業の設定をネストされたオブジェクトに変更
    professions: {
        livestock: {
            enabled: true, // 新しく追加: 職業の有効/無効 (UI表示制御用)
            limitEnabled: false, // デフォルトで制限は無効
            pointsEnabled: true, // デフォルトでポイントは有効
            points: {
                'minecraft:cow': 10,
                'minecraft:sheep': 10,
                'minecraft:pig': 10,
                'minecraft:chicken': 10,
                'minecraft:rabbit': 10,
                'minecraft:mooshroom': 15,
            },
            levelUpActions: 20,
            items: ['minecraft:cow', 'minecraft:sheep', 'minecraft:pig', 'minecraft:chicken', 'minecraft:rabbit', 'minecraft:mooshroom'],
            limit: {},
        },
        miner: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:coal_ore': 20,
                'minecraft:iron_ore': 30,
                'minecraft:gold_ore': 40,
                'minecraft:diamond_ore': 50,
                'minecraft:lapis_ore': 30,
                'minecraft:redstone_ore': 30,
                'minecraft:lit_redstone_ore': 30,
                'minecraft:emerald_ore': 50,
                'minecraft:copper_ore': 20,
                'minecraft:deepslate_coal_ore': 20,
                'minecraft:deepslate_iron_ore': 30,
                'minecraft:deepslate_gold_ore': 40,
                'minecraft:deepslate_diamond_ore': 50,
                'minecraft:deepslate_lapis_ore': 30,
                'minecraft:deepslate_redstone_ore': 30,
                'minecraft:lit_deepslate_redstone_ore': 30,
                'minecraft:deepslate_emerald_ore': 50,
                'minecraft:deepslate_copper_ore': 20,
                'minecraft:nether_quartz_ore': 25,
                'minecraft:nether_gold_ore': 35,
                'minecraft:ancient_debris': 60,
            },
            levelUpActions: 30,
            items: [
                'minecraft:coal_ore',
                'minecraft:iron_ore',
                'minecraft:gold_ore',
                'minecraft:diamond_ore',
                'minecraft:lapis_ore',
                'minecraft:redstone_ore',
                'minecraft:emerald_ore',
                'minecraft:copper_ore',
                'minecraft:deepslate_coal_ore',
                'minecraft:deepslate_iron_ore',
                'minecraft:deepslate_gold_ore',
                'minecraft:deepslate_diamond_ore',
                'minecraft:deepslate_lapis_ore',
                'minecraft:deepslate_redstone_ore',
                'minecraft:lit_deepslate_redstone_ore',
                'minecraft:deepslate_emerald_ore',
                'minecraft:deepslate_copper_ore',
                'minecraft:nether_quartz_ore',
                'minecraft:nether_gold_ore',
                'minecraft:ancient_debris',
            ],
            limit: {
                maxBreaksPerPeriod: 50,
                periodDays: 3,
            },
        },
        builder: {
            // 林業 (既存のbuilderタグを使用)
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:oak_log': 3,
                'minecraft:spruce_log': 3,
                'minecraft:birch_log': 3,
                'minecraft:jungle_log': 3,
                'minecraft:acacia_log': 3,
                'minecraft:dark_oak_log': 3,
                'minecraft:mangrove_log': 3,
                'minecraft:cherry_log': 3,
                'minecraft:stripped_oak_log': 3,
                'minecraft:stripped_spruce_log': 3,
                'minecraft:stripped_birch_log': 3,
                'minecraft:stripped_jungle_log': 3,
                'minecraft:stripped_acacia_log': 3,
                'minecraft:stripped_dark_oak_log': 3,
                'minecraft:stripped_mangrove_log': 3,
                'minecraft:stripped_cherry_log': 3,
                'minecraft:crimson_stem': 5,
                'minecraft:warped_stem': 5,
                'minecraft:stripped_crimson_stem': 5,
                'minecraft:stripped_warped_stem': 5,
            },
            levelUpActions: 30,
            items: [
                'minecraft:oak_log',
                'minecraft:spruce_log',
                'minecraft:birch_log',
                'minecraft:jungle_log',
                'minecraft:acacia_log',
                'minecraft:dark_oak_log',
                'minecraft:mangrove_log',
                'minecraft:cherry_log',
                'minecraft:stripped_oak_log',
                'minecraft:stripped_spruce_log',
                'minecraft:stripped_birch_log',
                'minecraft:stripped_jungle_log',
                'minecraft:stripped_acacia_log',
                'minecraft:stripped_dark_oak_log',
                'minecraft:stripped_mangrove_log',
                'minecraft:stripped_cherry_log',
                'minecraft:crimson_stem',
                'minecraft:warped_stem',
                'minecraft:stripped_crimson_stem',
                'minecraft:stripped_warped_stem',
            ],
            limit: {
                maxBreaksPerPeriod: 50, // 破壊数と設置数を共有
                periodDays: 3,
            },
        },
        farming: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:wheat': 5,
                'minecraft:carrots': 5,
                'minecraft:potatoes': 5,
                'minecraft:beetroot': 5,
                'minecraft:pumpkin': 10,
                'minecraft:melon': 10,
                'minecraft:reeds': 5,
                'minecraft:sweet_berry_bush': 8,
                'minecraft:sugar_cane': 5, // サトウキビもポイント対象に追加
            },
            levelUpActions: 25,
            items: ['minecraft:wheat', 'minecraft:carrots', 'minecraft:potatoes', 'minecraft:beetroot', 'minecraft:pumpkin', 'minecraft:melon', 'minecraft:sugar_cane', 'minecraft:reeds', 'minecraft:sweet_berry_bush'],
            limit: {},
        },
        adventurer: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:zombie': 10,
                'minecraft:husk': 10,
                'minecraft:drowned': 10,
                'minecraft:skeleton': 10,
                'minecraft:stray': 10,
                'minecraft:spider': 10,
                'minecraft:cave_spider': 12,
                'minecraft:creeper': 15,
                'minecraft:enderman': 20,
                'minecraft:slime': 15,
                'minecraft:magma_cube': 15,
                'minecraft:ghast': 25,
                'minecraft:blaze': 20,
                'minecraft:wither_skeleton': 25,
                'minecraft:phantom': 20,
            },
            levelUpActions: 10,
            items: ['minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:skeleton', 'minecraft:stray', 'minecraft:spider', 'minecraft:cave_spider', 'minecraft:creeper', 'minecraft:enderman', 'minecraft:slime', 'minecraft:magma_cube', 'minecraft:ghast', 'minecraft:blaze', 'minecraft:wither_skeleton', 'minecraft:phantom'],
            limit: {},
        },
        Angler: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:cod': 10,
                'minecraft:salmon': 10,
                'minecraft:tropical_fish': 15,
                'minecraft:pufferfish': 15,
                'minecraft:enchanted_book': 50,
                'minecraft:bow': 30,
                'minecraft:leather': 20,
                'minecraft:fishing_rod': 30,
                'minecraft:name_tag': 50,
                'minecraft:saddle': 50,
                'minecraft:lily_pad': 20,
                'minecraft:nautilus_shell': 50,
            },
            levelUpActions: 15,
            items: ['minecraft:cod', 'minecraft:salmon', 'minecraft:tropical_fish', 'minecraft:pufferfish', 'minecraft:enchanted_book', 'minecraft:bow', 'minecraft:leather', 'minecraft:fishing_rod', 'minecraft:name_tag', 'minecraft:saddle', 'minecraft:lily_pad', 'minecraft:nautilus_shell'],
            limit: {},
        },
        architect: {
            // 建築家 (新しく追加)
            enabled: false, // デフォルトで無効
            limitEnabled: false, // 制限は有効
            pointsEnabled: false, // ポイントレベルはなし
            points: {}, // ポイントは使用しない
            levelUpActions: 0, // レベルアップなし
            items: [
                // business.jsのbuildBlocksから主要なものを抜粋
                // 色付きガラス
                'minecraft:white_stained_glass',
                'minecraft:orange_stained_glass',
                'minecraft:magenta_stained_glass',
                'minecraft:light_blue_stained_glass',
                'minecraft:yellow_stained_glass',
                'minecraft:lime_stained_glass',
                'minecraft:pink_stained_glass',
                'minecraft:gray_stained_glass',
                'minecraft:light_gray_stained_glass',
                'minecraft:cyan_stained_glass',
                'minecraft:purple_stained_glass',
                'minecraft:blue_stained_glass',
                'minecraft:brown_stained_glass',
                'minecraft:green_stained_glass',
                'minecraft:red_stained_glass',
                'minecraft:black_stained_glass',
                // 色付きガラス板
                'minecraft:white_stained_glass_pane',
                'minecraft:orange_stained_glass_pane',
                'minecraft:magenta_stained_glass_pane',
                'minecraft:light_blue_stained_glass_pane',
                'minecraft:yellow_stained_glass_pane',
                'minecraft:lime_stained_glass_pane',
                'minecraft:pink_stained_glass_pane',
                'minecraft:gray_stained_glass_pane',
                'minecraft:light_gray_stained_glass_pane',
                'minecraft:cyan_stained_glass_pane',
                'minecraft:purple_stained_glass_pane',
                'minecraft:blue_stained_glass_pane',
                'minecraft:brown_stained_glass_pane',
                'minecraft:green_stained_glass_pane',
                'minecraft:red_stained_glass_pane',
                'minecraft:black_stained_glass_pane',
                // テラコッタ（非彩釉）
                'minecraft:white_terracotta',
                'minecraft:orange_terracotta',
                'minecraft:magenta_terracotta',
                'minecraft:light_blue_terracotta',
                'minecraft:yellow_terracotta',
                'minecraft:lime_terracotta',
                'minecraft:pink_terracotta',
                'minecraft:gray_terracotta',
                'minecraft:light_gray_terracotta',
                'minecraft:cyan_terracotta',
                'minecraft:purple_terracotta',
                'minecraft:blue_terracotta',
                'minecraft:brown_terracotta',
                'minecraft:green_terracotta',
                'minecraft:red_terracotta',
                'minecraft:black_terracotta',
                // 彩釉テラコッタ（各色が個別のID）
                'minecraft:white_glazed_terracotta',
                'minecraft:orange_glazed_terracotta',
                'minecraft:magenta_glazed_terracotta',
                'minecraft:light_blue_glazed_terracotta',
                'minecraft:yellow_glazed_terracotta',
                'minecraft:lime_glazed_terracotta',
                'minecraft:pink_glazed_terracotta',
                'minecraft:gray_glazed_terracotta',
                'minecraft:light_gray_glazed_terracotta',
                'minecraft:cyan_glazed_terracotta',
                'minecraft:purple_glazed_terracotta',
                'minecraft:blue_glazed_terracotta',
                'minecraft:brown_glazed_terracotta',
                'minecraft:green_glazed_terracotta',
                'minecraft:red_glazed_terracotta',
                'minecraft:black_glazed_terracotta',
                // 羊毛
                'minecraft:white_wool',
                'minecraft:orange_wool',
                'minecraft:magenta_wool',
                'minecraft:light_blue_wool',
                'minecraft:yellow_wool',
                'minecraft:lime_wool',
                'minecraft:pink_wool',
                'minecraft:gray_wool',
                'minecraft:light_gray_wool',
                'minecraft:cyan_wool',
                'minecraft:purple_wool',
                'minecraft:blue_wool',
                'minecraft:brown_wool',
                'minecraft:green_wool',
                'minecraft:red_wool',
                'minecraft:black_wool',
                // カーペット
                'minecraft:white_carpet',
                'minecraft:orange_carpet',
                'minecraft:magenta_carpet',
                'minecraft:light_blue_carpet',
                'minecraft:yellow_carpet',
                'minecraft:lime_carpet',
                'minecraft:pink_carpet',
                'minecraft:gray_carpet',
                'minecraft:light_gray_carpet',
                'minecraft:cyan_carpet',
                'minecraft:purple_carpet',
                'minecraft:blue_carpet',
                'minecraft:brown_carpet',
                'minecraft:green_carpet',
                'minecraft:red_carpet',
                'minecraft:black_carpet',
                // コンクリート
                'minecraft:white_concrete',
                'minecraft:orange_concrete',
                'minecraft:magenta_concrete',
                'minecraft:light_blue_concrete',
                'minecraft:yellow_concrete',
                'minecraft:lime_concrete',
                'minecraft:pink_concrete',
                'minecraft:gray_concrete',
                'minecraft:light_gray_concrete',
                'minecraft:cyan_concrete',
                'minecraft:purple_concrete',
                'minecraft:blue_concrete',
                'minecraft:brown_concrete',
                'minecraft:green_concrete',
                'minecraft:red_concrete',
                'minecraft:black_concrete',
                // コンクリートパウダー
                'minecraft:white_concrete_powder',
                'minecraft:orange_concrete_powder',
                'minecraft:magenta_concrete_powder',
                'minecraft:light_blue_concrete_powder',
                'minecraft:yellow_concrete_powder',
                'minecraft:lime_concrete_powder',
                'minecraft:pink_concrete_powder',
                'minecraft:gray_concrete_powder',
                'minecraft:light_gray_concrete_powder',
                'minecraft:cyan_concrete_powder',
                'minecraft:purple_concrete_powder',
                'minecraft:blue_concrete_powder',
                'minecraft:brown_concrete_powder',
                'minecraft:green_concrete_powder',
                'minecraft:red_concrete_powder',
                'minecraft:black_concrete_powder',
                // 旗（色はパターンで表現されるが、ブロックIDは統一）
                'minecraft:banner',
                // その他の装飾ブロック（色バリエーションなし）
                'minecraft:sea_lantern',
                'minecraft:prismarine',
                'minecraft:prismarine_bricks',
                'minecraft:dark_prismarine',
                //クウォーツ
                'minecraft:quartz_bricks',
                'minecraft:quartz_block',
                'minecraft:chiseled_quartz_block',
                'minecraft:quartz_pillar',
                'minecraft:smooth_quartz',
                //壁
                'minecraft:cobblestone_wall',
                'minecraft:mossy_cobblestone_wall',
                'minecraft:stone_brick_wall',
                'minecraft:mossy_stone_brick_wall',
                'minecraft:brick_wall',
                'minecraft:sandstone_wall',
                'minecraft:red_sandstone_wall',
                'minecraft:granite_wall',
                'minecraft:andesite_wall',
                'minecraft:diorite_wall',
                'minecraft:nether_brick_wall',
                'minecraft:red_nether_brick_wall',
                'minecraft:end_stone_brick_wall',
                'minecraft:prismarine_wall',
                'minecraft:blackstone_wall',
                'minecraft:polished_blackstone_wall',
                'minecraft:polished_blackstone_brick_wall',
                'minecraft:deepslate_brick_wall',
                'minecraft:polished_deepslate_wall',
                'minecraft:deepslate_tile_wall',
                'minecraft:cobbled_deepslate_wall',
                'minecraft:mud_brick_wall',
                'minecraft:resin_brick_wall',
                'minecraft:tuff_brick_wall',
                'minecraft:polished_tuff_wall',
                'minecraft:tuff_wall',
                //ドア
                'minecraft:oak_door',
                'minecraft:spruce_door',
                'minecraft:birch_door',
                'minecraft:jungle_door',
                'minecraft:acacia_door',
                'minecraft:dark_oak_door',
                'minecraft:mangrove_door',
                'minecraft:cherry_door',
                'minecraft:bamboo_door',
                'minecraft:iron_door',
                'minecraft:crimson_door',
                'minecraft:warped_door',
            ],
            limit: {
                maxBreaksPerPeriod: 50, // 破壊数と設置数を共有
                periodDays: 3,
            },
        },
        land_leveling: {
            // 整地 (新しく追加)
            enabled: false, // デフォルトで無効
            limitEnabled: false, // 制限は有効
            pointsEnabled: true, // ポイント付与は有効
            pointsPerBreaks: 10,
            points: {
                'minecraft:dirt': 1,
                'minecraft:grass_block': 1,
                'minecraft:podzol': 2,
                'minecraft:mycelium': 2,
                'minecraft:farmland': 1,
                'minecraft:coarse_dirt': 1,
                'minecraft:rooted_dirt': 1,
                'minecraft:mud': 1,
                'minecraft:packed_mud': 1,
                'minecraft:muddy_mangrove_roots': 1,
            },
            levelUpActions: 50, // レベルアップに必要なアクション数
            items: [
                // 整地対象ブロック
                'minecraft:dirt',
                'minecraft:grass_block',
                'minecraft:podzol',
                'minecraft:mycelium',
                'minecraft:farmland',
                'minecraft:coarse_dirt',
                'minecraft:rooted_dirt',
                'minecraft:mud',
                'minecraft:packed_mud',
                'minecraft:muddy_mangrove_roots',
            ],
            limit: {
                maxBreaksPerPeriod: 100, // 破壊数制限
                periodDays: 3,
            },
        },
    },
    levelRewards: {
        livestock: {},
        miner: {},
        builder: {}, // 林業
        farming: {},
        adventurer: {},
        Angler: {},
        architect: {}, // 建築家 (報酬はなし)
        land_leveling: {}, // 整地
    },
};

// 職業の表示名マッピング
const PROFESSION_DISPLAY_NAMES = {
    livestock: '家畜',
    miner: '鉱夫',
    builder: '林業', // 林業はbuilderタグを使用
    farming: '農業',
    adventurer: '冒険家',
    Angler: '釣り人',
    architect: '建築家', // 新しく追加
    land_leveling: '整地', // 新しく追加
};

// メッセージクールダウン
const messageCooldowns = new Map();
const COOLDOWN_TICKS = 30; // 1.5秒 (20 tick/秒 * 1.5秒)

function sendRestrictedMessage(player, message) {
    const now = system.currentTick;
    const lastSent = messageCooldowns.get(player.id) || 0;
    if (now - lastSent >= COOLDOWN_TICKS) {
        player.sendMessage(`[§b職業システム§r] §c${message}`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        messageCooldowns.set(player.id, now);
    }
}

// 設定データ (グローバル変数として宣言)
var config;

// 設定の初期化
export function initializeConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    if (savedConfig === undefined) {
        config = JSON.parse(JSON.stringify(DEFAULT_CONFIG)); // ディープコピー
        world.setDynamicProperty('business_config', JSON.stringify(config));
    } else {
        // 既存の設定がある場合はロード
        config = JSON.parse(savedConfig);
        // 新しいプロパティが追加された場合に既存の設定を更新
        config = mergeConfigs(config, DEFAULT_CONFIG);
        world.setDynamicProperty('business_config', JSON.stringify(config)); // 更新した設定を保存
    }
}

// 設定をマージするヘルパー関数
function mergeConfigs(currentConfig, defaultTemplate) {
    const merged = { ...currentConfig };

    for (const key in defaultTemplate) {
        if (defaultTemplate.hasOwnProperty(key)) {
            if (typeof defaultTemplate[key] === 'object' && defaultTemplate[key] !== null && !Array.isArray(defaultTemplate[key])) {
                // オブジェクトの場合は再帰的にマージ
                merged[key] = mergeConfigs(currentConfig[key] || {}, defaultTemplate[key]);
            } else if (!(key in currentConfig)) {
                // 既存の設定にない場合はデフォルトを追加
                merged[key] = JSON.parse(JSON.stringify(defaultTemplate[key])); // ディープコピー
            }
        }
    }
    return merged;
}

// 設定の更新
export function UpdateConfig() {
    config = getConfig();
}

// 設定の取得
export function getConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    let currentConfig = savedConfig ? JSON.parse(savedConfig) : JSON.parse(JSON.stringify(DEFAULT_CONFIG));

    // 新しいプロパティが追加された場合に既存の設定を更新
    currentConfig = mergeConfigs(currentConfig, DEFAULT_CONFIG);

    return currentConfig;
}

// プレイヤーが設置したブロックの追跡（一時的）
let placedBlocks = new Map();

// ブロック設置データのクリーンアップ
const BLOCK_EXPIRY_MS = 6 * 60 * 60 * 1000;

function cleanupExpiredBlocks() {
    const now = Date.now();
    for (const [key, data] of placedBlocks.entries()) {
        if (now - data.timestamp > BLOCK_EXPIRY_MS) {
            placedBlocks.delete(key);
        }
    }
}

// 定期的にクリーンアップを実行
system.runInterval(() => {
    cleanupExpiredBlocks();
}, 1200); // 1分ごとにチェック（20tick * 60秒）

// レベル表示用の関数
function updateLevelDisplay(player, profession, level, actions, currentActions, gainedPoints = 0) {
    // 建築家はポイントレベルがないため、表示をスキップ
    if (profession === 'architect') {
        return;
    }

    const maxBars = 20; // 最大20本
    const actionsPerBar = Math.max(actions / maxBars, 1);
    const filledBars = Math.min(Math.floor(currentActions / actionsPerBar), maxBars); // 現在のアクションで埋まったバーの数
    const emptyBars = maxBars - filledBars; // 残りの空のバーの数

    const displayBars = `§c${'|'.repeat(filledBars)}§8${'|'.repeat(emptyBars)}`;

    player.onScreenDisplay.setActionBar(`§a${PROFESSION_DISPLAY_NAMES[profession]} §rLevel:§b${level} ${displayBars} §e+${gainedPoints}P`);
}

// レベルアップチェックとメッセージ
const playerPointsMap = new Map(); // プレイヤーごとのポイントを保持
function checkLevelUp(player, profession, levelUpActions, propertyKey, gainedPoints) {
    // 建築家はポイントレベルがないため、処理をスキップ
    if (profession === 'architect') {
        return;
    }

    const playerId = player.id; // プレイヤーごとに一意なIDを使用
    let currentActions = player.getDynamicProperty(`${propertyKey}_actions`) || 0;
    let totalPoints = playerPointsMap.get(playerId)?.totalPoints || 0;
    currentActions += 1;
    totalPoints += gainedPoints;

    const currentLevel = player.getDynamicProperty(propertyKey) || 1;
    const requiredActions = levelUpActions;

    player.setDynamicProperty(`${propertyKey}_actions`, currentActions);
    playerPointsMap.set(playerId, { totalPoints, lastAction: currentActions });

    // 2秒後にポイントをリセット（アクションバーは更新しない）
    system.runTimeout(() => {
        const currentData = playerPointsMap.get(playerId);
        if (currentData && currentData.lastAction === currentActions) {
            playerPointsMap.set(playerId, { totalPoints: 0, lastAction: currentActions });
        }
    }, 40); // 2秒（20tick * 2）

    if (currentActions >= requiredActions) {
        const newLevel = currentLevel + 1;
        player.setDynamicProperty(propertyKey, newLevel);
        player.setDynamicProperty(`${propertyKey}_actions`, 0);
        playerPointsMap.set(playerId, { totalPoints: gainedPoints, lastAction: 0 }); // 最後のgainedPointsを保持
        updateLevelDisplay(player, profession, newLevel, levelUpActions, 0, gainedPoints); // gainedPointsを表示

        player.sendMessage(`[§b職業システム§r] §e${PROFESSION_DISPLAY_NAMES[profession]}§aがレベル§c${newLevel}§aに到達`);
        player.playSound('random.toast', { pitch: 2.9, volume: 1.8 });

        config = getConfig();
        const availableLevels = Object.keys(config.levelRewards[profession]).map(Number);
        if (availableLevels.includes(newLevel)) {
            player.sendMessage(`[§b職業システム§r] §d報酬を受け取れます`);
        }
    } else {
        updateLevelDisplay(player, profession, currentLevel, levelUpActions, currentActions, totalPoints);
    }
}

// シルクタッチチェック
function hasSilkTouch(player) {
    const inventory = player.getComponent('minecraft:inventory');
    if (!inventory) {
        return false;
    }
    const item = inventory.container.getSlot(player.selectedSlotIndex).getItem();
    if (!item) {
        return false;
    }
    const enchantmentsComponent = item.getComponent('minecraft:enchantable');
    if (enchantmentsComponent === undefined) {
        return false;
    }
    const enchantments = enchantmentsComponent.getEnchantments();
    if (enchantments && enchantments.length > 0 && enchantments[0]?.type.id.toLowerCase() === 'silk_touch') {
        return true;
    }
    return false;
}

export function Business() {
    initializeConfig(); // 初期化をここで行う
    config = getConfig(); // 最新の設定をロード

    // 家畜
    world.afterEvents.entityDie.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        if (player?.typeId === 'minecraft:player' && config.professions.livestock.items.includes(Entity.typeId)) {
            // 制限が有効で、プレイヤーが家畜職業に就いていない場合
            if (config.professions.livestock.limitEnabled && !player.hasTag('livestock')) {
                const entities = Entity.dimension.getEntities({
                    location: Entity.location,
                    maxDistance: 1, // ドロップアイテムの検索範囲
                    type: 'minecraft:item',
                });
                for (const item of entities) {
                    item.remove();
                }
                sendRestrictedMessage(player, `${PROFESSION_DISPLAY_NAMES.livestock}の職業に就いていないため、ドロップアイテムを取得できません`);
                return; // ポイント付与も行わない
            }

            // ポイント付与が有効な場合
            if (config.professions.livestock.pointsEnabled && player.hasTag('livestock')) {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.livestock.points[Entity.typeId] || 10;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'livestock', config.professions.livestock.levelUpActions, 'livestock_level', points);
            }
        }
    });

    // 鉱石
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const blockTypeId = event.block.typeId;
        if (player?.typeId === 'minecraft:player' && config.professions.miner.items.includes(blockTypeId) && !hasSilkTouch(player)) {
            // 制限が有効で、プレイヤーが鉱夫職業に就いていない場合
            if (config.professions.miner.limitEnabled && !player.hasTag('miner')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_miner') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_miner') ?? 0;
                const maxBreaks = config.professions.miner.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.miner.limit.periodDays * 24 * 60 * 60 * 1000;

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_miner', breakCount);
                    player.setDynamicProperty('lastReset_miner', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true;
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.miner.limit.periodDays}日間で${maxBreaks}個まで鉱石ブロックを破壊できます`);
                    });
                    return; // ポイント付与も行わない
                } else {
                    // 破壊を許可し、カウントを増やす
                    breakCount++;
                    player.setDynamicProperty('breakCount_miner', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 鉱石ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }

            // ポイント付与が有効な場合
            if (config.professions.miner.pointsEnabled && player.hasTag('miner')) {
                system.run(() => {
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.professions.miner.points[blockTypeId] || 20;
                    objective.addScore(player.scoreboardIdentity, points);
                    checkLevelUp(player, 'miner', config.professions.miner.levelUpActions, 'miner_level', points);
                });
            } else if (config.professions.miner.limitEnabled && !player.hasTag('miner')) {
                // 制限有効で職業に就いていない場合、アイテムを削除
                system.runTimeout(() => {
                    const entities = player.dimension.getEntities({
                        location: { x: event.block.location.x + 0.5, y: event.block.location.y + 0.5, z: event.block.location.z + 0.5 },
                        maxDistance: 1,
                        type: 'minecraft:item',
                    });
                    for (const item of entities) {
                        try {
                            if (item.isValid()) {
                                item.remove();
                            }
                        } catch (error) {
                            console.warn(`アイテム削除エラー: ${error.message}`);
                        }
                    }
                    sendRestrictedMessage(player, '鉱夫の職業に就いていないため、鉱石のドロップアイテムを取得できません');
                }, 2); // 2ティック遅延（アイテムスポーンを待つ）
            }
        }
    });

    // 林業 (builderタグを使用)
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;

        if (config.professions.builder.items.includes(blockTypeId)) {
            // 制限が有効で、プレイヤーが林業職業に就いていない場合
            if (config.professions.builder.limitEnabled && !player.hasTag('builder')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_builder') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_builder') ?? 0;
                const maxBreaks = config.professions.builder.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.builder.limit.periodDays * 24 * 60 * 60 * 1000;

                // 自分で設置したブロックで、免除期間内かチェック
                if (placedBlocks.has(key) && currentTick - placedBlocks.get(key).timestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key); // データ削除
                    return; // 破壊を許可（カウントなし）
                }

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_builder', breakCount);
                    player.setDynamicProperty('lastReset_builder', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true; // ブロック破壊をキャンセル
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.builder.limit.periodDays}日間で${maxBreaks}個まで原木を破壊できます`);
                    });
                    return; // ポイント付与も行わない
                } else {
                    // 破壊を許可し、カウントを増やす
                    breakCount++;
                    player.setDynamicProperty('breakCount_builder', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 原木破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }

            // ポイント付与が有効な場合
            if (config.professions.builder.pointsEnabled && player.hasTag('builder') && !placedBlocks.has(key)) {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.builder.points[blockTypeId] || 3;
                system.run(() => {
                    objective.addScore(player.scoreboardIdentity, points);
                    checkLevelUp(player, 'builder', config.professions.builder.levelUpActions, 'builder_level', points);
                });
            }
            placedBlocks.delete(key); // 設置ブロック追跡から削除
        }
    });

    // 農業
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block; // beforeEventsではblockプロパティから情報を取得
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`; // 設置ブロック判定用

        // パミューテーションの取得 (beforeEventsでもgetStateが利用可能)
        const blockPermutation = block.permutation;

        // 作物が完全に成長しているか、またはカカオ豆が完全に成長しているか
        const isMatureCrop = (blockPermutation.getTags().includes(`minecraft:crop`) && blockPermutation.getState(`growth`) == 7) || (blockTypeId === `minecraft:cocoa` && blockPermutation.getState(`age`) === 2);
        const isNonGrowthBlock = blockPermutation.getState(`growth`) === undefined; // 'growth'がないブロック（カボチャ、スイカ、サトウキビなど）

        if (config.professions.farming.items.includes(blockTypeId)) {
            // 制限が有効で、プレイヤーが農業職業に就いていない場合
            if (config.professions.farming.limitEnabled && !player.hasTag('farming')) {
                event.cancel = true; // 破壊をキャンセル
                system.run(() => {
                    sendRestrictedMessage(player, '農業の職業に就いていないため、作物を収穫できません');
                });
                return;
            }
        }
    });

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const brokenBlockPermutation = event.brokenBlockPermutation;
        const blockTypeId = brokenBlockPermutation.type.id;
        const key = `${event.block.x},${event.block.y},${event.block.z},${event.block.dimension.id}`; // 設置ブロック判定用

        // 作物が完全に成長しているか、またはカカオ豆が完全に成長しているか
        const isMatureCrop = (brokenBlockPermutation.getTags().includes(`minecraft:crop`) && brokenBlockPermutation.getState(`growth`) == 7) || (blockTypeId === `minecraft:cocoa` && brokenBlockPermutation.getState(`age`) === 2);
        const isNonGrowthBlock = brokenBlockPermutation.getState(`growth`) === undefined; // 'growth'がないブロック（カボチャ、スイカ、サトウキビなど）

        if (config.professions.farming.items.includes(blockTypeId)) {
            // ポイント付与が有効な場合（農業タグを持つプレイヤーのみ）
            // 成長済み作物、または自分で設置していない成長しないブロックの場合にポイント付与
            if (config.professions.farming.pointsEnabled && player.hasTag('farming') && (isMatureCrop || (isNonGrowthBlock && !placedBlocks.has(key)))) {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.farming.points[blockTypeId] || 5;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'farming', config.professions.farming.levelUpActions, 'farming_level', points);
            }
            placedBlocks.delete(key); // 設置ブロック追跡から削除
        }
    });

    // プレイヤーがブロックを設置したときに追跡
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;
        const config = getConfig(); // 最新の設定を常に取得

        // 農業または建築家のアイテムリストに含まれるブロックを追跡
        if (
            config.professions.farming.items.includes(block.typeId) ||
            config.professions.architect.items.includes(block.typeId) ||
            config.professions.builder.items.includes(block.typeId) || // 林業を追加
            config.professions.land_leveling.items.includes(block.typeId) // 整地を追加
        ) {
            placedBlocks.set(key, { playerId: player.id, timestamp: Date.now() });
        }

        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        // 建築家 (architect) のブロック設置制限（既存のコードはそのまま）
        if (config.professions.architect.items.includes(block.typeId)) {
            if (config.professions.architect.limitEnabled && !player.hasTag('architect')) {
                const currentTick = Date.now();
                let placeCount = player.getDynamicProperty('placeCount_architect') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_architect') ?? 0;
                const maxPlaces = config.professions.architect.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;

                // リセットチェック
                if (currentTick - lastReset >= periodMs) {
                    placeCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('placeCount_architect', placeCount);
                    player.setDynamicProperty('lastReset_architect', lastReset);
                }

                // 上限チェック
                if (maxPlaces > 0 && placeCount >= maxPlaces) {
                    // ブロックをairに置き換える
                    system.run(() => {
                        block.setType('minecraft:air');
                        sendRestrictedMessage(player, `${config.professions.architect.limit.periodDays}日間で${maxPlaces}個まで装飾ブロックを設置できます`);
                    });
                } else {
                    placeCount++;
                    player.setDynamicProperty('placeCount_architect', placeCount);
                    system.run(() => {
                        if (placeCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 装飾ブロック設置: ${placeCount}/${maxPlaces}`);
                        }
                    });
                }
            }
        }
    });

    // 建築家 (architect) のブロック破壊制限
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;

        if (config.professions.architect.items.includes(blockTypeId)) {
            if (config.professions.architect.limitEnabled && !player.hasTag('architect')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_architect') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_architect') ?? 0;
                const maxBreaks = config.professions.architect.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;

                // 自分で設置したブロックで、免除期間内かチェック
                if (placedBlocks.has(key) && currentTick - placedBlocks.get(key).timestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key); // データ削除
                    return; // 破壊を許可（カウントなし）
                }

                // リセットチェック
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_architect', breakCount);
                    player.setDynamicProperty('lastReset_architect', lastReset);
                }

                // 上限チェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true;
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.architect.limit.periodDays}日間で${maxBreaks}個まで装飾ブロックを破壊できます`);
                    });
                    return;
                } else {
                    breakCount++;
                    player.setDynamicProperty('breakCount_architect', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 装飾ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }
            placedBlocks.delete(key); // 設置ブロック追跡から削除
        }
    });

    // 整地 (land_leveling) のブロック破壊制限
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;

        if (config.professions.land_leveling.items.includes(blockTypeId)) {
            // 制限が有効で、プレイヤーが整地職業に就いていない場合
            if (config.professions.land_leveling.limitEnabled && !player.hasTag('land_leveling')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_land_leveling') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_land_leveling') ?? 0;
                const maxBreaks = config.professions.land_leveling.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.land_leveling.limit.periodDays * 24 * 60 * 60 * 1000;

                // 自分で設置したブロックで、免除期間内かチェック
                if (placedBlocks.has(key) && currentTick - placedBlocks.get(key).timestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key); // データ削除
                    return; // 破壊を許可（カウントなし）
                }

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_land_leveling', breakCount);
                    player.setDynamicProperty('lastReset_land_leveling', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true; // ブロック破壊をキャンセル
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.land_leveling.limit.periodDays}日間で${maxBreaks}個まで土ブロックを破壊できます`);
                    });
                    return; // ポイント付与も行わない
                } else {
                    // 破壊を許可し、カウントを増やす
                    breakCount++;
                    player.setDynamicProperty('breakCount_land_leveling', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 土ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }

            // ポイント付与が有効な場合
            if (config.professions.land_leveling.pointsEnabled && player.hasTag('land_leveling') && !placedBlocks.has(key)) {
                let breakCountPoints = player.getDynamicProperty('breakCountPoints_land_leveling') ?? 0;
                breakCountPoints++;
                player.setDynamicProperty('breakCountPoints_land_leveling', breakCountPoints);

                // pointsPerBreaksごとにポイントを付与
                const pointsPerBreaks = config.professions.land_leveling.pointsPerBreaks || 10;
                if (breakCountPoints >= pointsPerBreaks) {
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.professions.land_leveling.points[blockTypeId] || 1;
                    system.run(() => {
                        objective.addScore(player.scoreboardIdentity, points);
                        checkLevelUp(player, 'land_leveling', config.professions.land_leveling.levelUpActions, 'land_leveling_level', points);
                    });
                    breakCountPoints = 0; // リセット
                    player.setDynamicProperty('breakCountPoints_land_leveling', breakCountPoints);
                }
                placedBlocks.delete(key); // 設置ブロック追跡から削除
            }
        }
    });

    // 冒険家
    world.afterEvents.entityDie.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        if (player?.typeId === 'minecraft:player' && config.professions.adventurer.items.includes(Entity.typeId)) {
            // 制限が有効で、プレイヤーが冒険家職業に就いていない場合
            if (config.professions.adventurer.limitEnabled && !player.hasTag('adventurer')) {
                const entities = Entity.dimension.getEntities({
                    location: Entity.location,
                    maxDistance: 3,
                    type: 'minecraft:item',
                });
                for (const item of entities) {
                    item.remove();
                }
                sendRestrictedMessage(player, `${PROFESSION_DISPLAY_NAMES.adventurer}の職業に就いていないため、ドロップアイテムを取得できません`);
                return; // ポイント付与も行わない
            }

            // ポイント付与が有効な場合
            if (config.professions.adventurer.pointsEnabled && player.hasTag('adventurer')) {
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.adventurer.points[Entity.typeId] || 10;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'adventurer', config.professions.adventurer.levelUpActions, 'adventurer_level', points);
            }
        }
    });

    // 釣り人
    let AnglerPlayers = new Set(); // 釣り中のプレイヤー名を保持
    const fishingEntityIds = new Map(); // プレイヤー名と釣りフックの紐づけ
    const recentCasts = new Map(); // プレイヤー名と最後に釣り竿を使用した時間を保持

    // 釣り竿使用イベント
    world.beforeEvents.itemUse.subscribe(ev => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const { source, itemStack } = ev;
        if (source.typeId !== 'minecraft:player' || itemStack.typeId !== 'minecraft:fishing_rod') return;

        // 制限が有効で、プレイヤーが釣り人職業に就いていない場合
        if (config.professions.Angler.limitEnabled && !source.hasTag('Angler')) {
            ev.cancel = true;
            system.run(() => {
                sendRestrictedMessage(source, '釣り人の職業に就いていないため、釣り竿を使用できません');
            });
            return;
        }

        // 職業に就いている場合のみ、釣りフックの追跡を開始
        if (source.hasTag('Angler')) {
            const player = source;
            const playerName = player.name;
            system.runTimeout(() => {
                if (fishingEntityIds.has(playerName)) {
                    fishingEntityIds.delete(playerName);
                }
                recentCasts.set(playerName, Date.now());
                AnglerPlayers.add(playerName);
            }, 10);
        }
    });

    // フックスポーンイベント
    world.afterEvents.entitySpawn.subscribe(ev => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const { entity } = ev;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        system.runTimeout(() => {
            if (!entity.isValid()) return;

            const block = entity.dimension.getBlock(entity.location);
            if (!block || block.typeId !== 'minecraft:water') {
                return;
            }

            const players = entity.dimension.getPlayers({
                location: entity.location,
                maxDistance: 7.0,
            });

            let closestPlayer = null;
            let minDistance = Infinity;
            let latestCastTime = -Infinity;

            for (const player of players) {
                if (!player.hasTag('Angler') || !recentCasts.has(player.name)) continue;

                const castTime = recentCasts.get(player.name) || 0;
                if (Date.now() - castTime > 2000) continue;

                const distance = Math.sqrt((player.location.x - entity.location.x) ** 2 + (player.location.y - entity.location.y) ** 2 + (player.location.z - entity.location.z) ** 2);

                const viewVector = player.getViewDirection();
                const playerPos = player.location;
                const hookPos = entity.location;
                const toHookVector = {
                    x: hookPos.x - playerPos.x,
                    y: hookPos.y - playerPos.y,
                    z: hookPos.z - playerPos.z,
                };
                const dotProduct = viewVector.x * toHookVector.x + viewVector.y * toHookVector.y + viewVector.z * toHookVector.z;
                const viewMagnitude = Math.sqrt(viewVector.x ** 2 + viewVector.y ** 2 + viewVector.z ** 2);
                const hookMagnitude = Math.sqrt(toHookVector.x ** 2 + toHookVector.y ** 2 + toHookVector.z ** 2);
                const cosTheta = hookMagnitude > 0 ? dotProduct / (viewMagnitude * hookMagnitude) : 0;

                if (cosTheta < 0.5) continue;

                if (distance < minDistance && castTime > latestCastTime) {
                    minDistance = distance;
                    latestCastTime = castTime;
                    closestPlayer = player;
                }
            }

            if (closestPlayer) {
                fishingEntityIds.set(closestPlayer.name, entity.id);
            }
        }, 20);
    });

    // フック削除イベント
    world.beforeEvents.entityRemove.subscribe(event => {
        config = getConfig(); // 最新の設定を常に取得
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const entity = event.removedEntity;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        let targetPlayer = null;
        let targetPlayerName = null;
        for (const [playerName, hookId] of fishingEntityIds.entries()) {
            if (hookId === entity.id) {
                targetPlayerName = playerName;
                targetPlayer = world.getAllPlayers().find(p => p.name === playerName);
                fishingEntityIds.delete(playerName);
                break;
            }
        }

        if (!targetPlayer || !targetPlayer.hasTag('Angler')) {
            if (targetPlayerName) {
                AnglerPlayers.delete(targetPlayerName);
                recentCasts.delete(targetPlayerName);
            }
            return;
        }

        // ポイント付与が有効な場合のみアイテムをチェック
        if (config.professions.Angler.pointsEnabled) {
            const entities = entity.dimension.getEntities({
                location: entity.location,
                maxDistance: 1,
                type: 'minecraft:item',
            });
            for (const item of entities) {
                const itemStack = item.getComponent('minecraft:item')?.itemStack;
                if (itemStack && config.professions.Angler.items.includes(itemStack.typeId)) {
                    const block = item.dimension.getBlock(item.location);
                    if (!block || block.typeId !== 'minecraft:water') {
                        continue;
                    }

                    system.run(() => {
                        const objective = world.scoreboard.getObjective(objectiveName);
                        const points = config.professions.Angler.points[itemStack.typeId] || 10;
                        objective.addScore(targetPlayer.scoreboardIdentity, points);
                        checkLevelUp(targetPlayer, 'Angler', config.professions.Angler.levelUpActions, 'Angler_level', points);
                    });
                    break;
                }
            }
        } else if (config.professions.Angler.limitEnabled && !targetPlayer.hasTag('Angler')) {
            // 制限が有効で職業に就いていない場合、ドロップアイテムを削除
            const entities = entity.dimension.getEntities({
                location: entity.location,
                maxDistance: 1,
                type: 'minecraft:item',
            });
            for (const item of entities) {
                const itemStack = item.getComponent('minecraft:item')?.itemStack;
                if (itemStack && config.professions.Angler.items.includes(itemStack.typeId)) {
                    item.remove();
                }
            }
            sendRestrictedMessage(targetPlayer, '釣り人の職業に就いていないため、ドロップアイテムを取得できません');
        }

        AnglerPlayers.delete(targetPlayerName);
        recentCasts.delete(targetPlayerName);
    });

    // 定期的にリセット確認 (鉱夫、林業、建築家、整地)
    system.runInterval(() => {
        config = getConfig(); // 最新の設定を常に取得
        const currentTick = Date.now();
        for (const player of world.getAllPlayers()) {
            // 鉱夫のリセット
            if (config.professions.miner.limitEnabled) {
                let lastResetMiner = player.getDynamicProperty('lastReset_miner') ?? 0;
                const periodMsMiner = config.professions.miner.limit.periodDays * 24 * 60 * 60 * 1000;
                if (currentTick - lastResetMiner >= periodMsMiner) {
                    player.setDynamicProperty('breakCount_miner', 0);
                    player.setDynamicProperty('lastReset_miner', currentTick);
                }
            }

            // 林業のリセット (builderタグを使用)
            if (config.professions.builder.limitEnabled) {
                let lastResetBuilder = player.getDynamicProperty('lastReset_builder') ?? 0;
                const periodMsBuilder = config.professions.builder.limit.periodDays * 24 * 60 * 60 * 1000;
                if (currentTick - lastResetBuilder >= periodMsBuilder) {
                    player.setDynamicProperty('placeCount_builder', 0);
                    player.setDynamicProperty('breakCount_builder', 0);
                    player.setDynamicProperty('lastReset_builder', currentTick);
                }
            }

            // 建築家 (architect) のリセット
            if (config.professions.architect.limitEnabled) {
                let lastResetArchitect = player.getDynamicProperty('lastReset_architect') ?? 0;
                const periodMsArchitect = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;
                if (currentTick - lastResetArchitect >= periodMsArchitect) {
                    player.setDynamicProperty('placeCount_architect', 0);
                    player.setDynamicProperty('breakCount_architect', 0);
                    player.setDynamicProperty('lastReset_architect', currentTick);
                }
            }

            // 整地 (land_leveling) のリセット
            if (config.professions.land_leveling.limitEnabled) {
                let lastResetLandLeveling = player.getDynamicProperty('lastReset_land_leveling') ?? 0;
                const periodMsLandLeveling = config.professions.land_leveling.limit.periodDays * 24 * 60 * 60 * 1000;
                if (currentTick - lastResetLandLeveling >= periodMsLandLeveling) {
                    player.setDynamicProperty('breakCount_land_leveling', 0);
                    player.setDynamicProperty('lastReset_land_leveling', currentTick);
                }
            }
        }
    }, 60 * 60 * 1000); // 1時間ごとにチェック
}
