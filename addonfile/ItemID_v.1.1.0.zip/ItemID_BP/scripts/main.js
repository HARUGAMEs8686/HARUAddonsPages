import { world, system } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';

world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    system.run(() => {
        if (player.hasTag('idc')) {
            player.sendMessage(`§aItemID§r:§b${eventData.itemStack.typeId}`);
        }
        if (player.hasTag('idui')) {
            const form = new ModalFormData();
            form.title('§0ItemID');
            form.textField('§bItemID', `${eventData.itemStack.typeId}`, `${eventData.itemStack.typeId}`);
            form.submitButton('§0閉じる');
            form.show(player).then(res => {
                if (res.canceled) {
                    return;
                }
            });
        }
    });
});

const cooldowns = new Map();

world.beforeEvents.playerInteractWithBlock.subscribe(eventData => {
    const player = eventData.player;
    const playerId = player.id;
    system.run(() => {
        if (cooldowns.has(playerId) && system.currentTick < cooldowns.get(playerId)) {
            return;
        }

        cooldowns.set(playerId, system.currentTick + 10);
        // 元の処理を実行
        if (player.hasTag('idc')) {
            player.sendMessage(`§aBlockID§r:§b${eventData.block.typeId}`);
        }
        if (player.hasTag('idui')) {
            const form = new ModalFormData();
            form.title('§0ItemID');
            form.textField('§bBlockID', `${eventData.block.typeId}`, `${eventData.block.typeId}`);
            form.submitButton('§0閉じる');
            form.show(player).then(res => {
                if (res.canceled) {
                    return;
                }
            });
        }
    });
});
