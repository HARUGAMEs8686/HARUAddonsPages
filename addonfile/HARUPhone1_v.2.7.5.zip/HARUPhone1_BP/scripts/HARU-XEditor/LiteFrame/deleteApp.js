import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../../config';
import { LiteFrame_editor } from './editor/LiteFrame_editor';

var player_Cash_Data = {};
export function HARU_XEditor_LiteFrame_delete(player, Application) {
    system.run(() => {
        player_Cash_Data[player.id] = {};
        player_Cash_Data[player.id].Application = JSON.parse(world.getDynamicProperty(`${Application[0]}`));
        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§c本当にApplicationを削除しますか？\n\n§a対象アプリケーション§r:§b${player_Cash_Data[player.id].Application.ApplicationName}`);
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        form.button(`§4削除`);
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    LiteFrame_editor(player, Application);
                    break;
                case 1:
                    //MY_AppData(Player)のアプリIDを削除
                    var MY_AppData = player.getDynamicProperty(`MY_AppData`);
                    if (MY_AppData == undefined) {
                        var MY_AppData = [];
                    } else {
                        var MY_AppData = JSON.parse(MY_AppData);
                    }
                    var index = MY_AppData.findIndex(item => Array.isArray(item) && item[0] === Application[0] && item[1] === Application[1]);
                    if (index !== -1) {
                        MY_AppData.splice(index, 1); // 見つかったら削除
                    }
                    player.setDynamicProperty(`MY_AppData`, JSON.stringify(MY_AppData));

                    //AppDataのアプリIDを削除
                    var AppData = world.getDynamicProperty(`AppData`);
                    if (AppData == undefined) {
                        var AppData = [];
                    } else {
                        var AppData = JSON.parse(AppData);
                    }
                    var index = AppData.findIndex(item => Array.isArray(item) && item[0] === Application[0] && item[1] === Application[1]);
                    if (index !== -1) {
                        AppData.splice(index, 1); // 見つかったら削除
                    }
                    world.setDynamicProperty(`AppData`, JSON.stringify(AppData));

                    world.setDynamicProperty(`${Application[0]}`, undefined);

                    player.sendMessage(`§r[§bHARU-XEditor§r] §a削除完了`);
                    player.playSound('random.toast', {
                        pitch: 1.4,
                        volume: 1.0,
                    });
                    break;
            }
        });
    });
}
