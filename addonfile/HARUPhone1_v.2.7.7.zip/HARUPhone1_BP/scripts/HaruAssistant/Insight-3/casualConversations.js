// casualConversations.js
const casualResponses = {
    greetings: {
        patterns: ["こんにちは", "こんちゃ", "やあ", "ハロー", "ちゃ", "ねえ","こんちは","こ～んにちは","こ～んに～ちは","hello"],
        response: (playerName, message) => {
            const greeting = message.includes("こんちゃ") ? "こんちゃ" : "こんにちは";
            return `${greeting}、${playerName}さん！お元気ですか？`;
        }
    },
    morning: {
        patterns: ["おはよう", "朝", "おっは","オッハー"],
        response: (playerName, message) => {
            const greeting = message.includes("おっは") ? "おっは" : "おはようございます";
            return `${greeting}、${playerName}さん！朝から元気そうですね。今日の予定はありますか？`;
        }
    },
    evening: {
        patterns: ["こんばんは", "ばんちゃ", "夜", "夕方", "ばん"],
        response: (playerName, message) => {
            const greeting = message.includes("ばんちゃ") ? "ばんちゃ" : "こんばんは";
            return `${greeting}、${playerName}さん。夜は落ち着きますね。何か面白いことありました？`;
        }
    },
    thanks: {
        patterns: ["ありがとう", "ありがと", "感謝", "サンキュー","あざす"],
        response: (playerName, message) => {
            const thanks = message.includes("サンキュー") ? "サンキュー" : "ありがとうございます";
            return `${thanks}、${playerName}さん！そう言っていただけると嬉しいです。また何かお手伝いできることがあれば教えてくださいね。`;
        }
    },
    tired: {
        patterns: ["疲れた", "眠い", "だるい", "休みたい", "つかれた", "ねむい"],
        response: (playerName, message) => {
            const state = message.includes("ねむい") ? "眠そう" : "お疲れ";
            return `${playerName}さん、${state}なんですね。無理せずゆっくり休んでくださいね。何かお手伝いできることがあれば言ってください。`;
        }
    },
    happy: {
        patterns: ["楽しい", "嬉しい", "うれしい", "たのしい"],
        response: (playerName) => {
            return `${playerName}さん、楽しそうで何よりです！何がそんなに嬉しいんですか？私も一緒に喜びたいです。`;
        }
    },
    sad: {
        patterns: ["悲しい", "辛い", "つらい", "かなしい"],
        response: (playerName) => {
            return `${playerName}さん、悲しい気持ちなんですね…。もしよければお話を聞かせてください。私、しっかりお聞きしますよ。`;
        }
    },
    doing: {
        patterns: ["何してる", "いま", "どうしてる", "何してますか", "いま何", "何やってる", "なにしてんの"],
        response: (playerName) => {
            return `今は${playerName}さんとこうやってお話ししていますよ。${playerName}さんは何をしていますか？`;
        }
    },
    naruhodo: {
        patterns: ["なるほど", "分かった", "ナルホド", "わかった", "わかりました", "分かりました", "ワカリマシタ","ワカッタ","分かりやすい","わかりやすい","ok","おけ","オッケー","了解","理解した","りょうかい"],
        response: (playerName) => {
            return `${playerName}さん、理解頂けて嬉しいです。他にも何か分からないことがあれば、いつでもお声がけください！`;
        }
    },
    genki: {
        patterns: ["元気です", "元気っす", "げんきです", "げんきっす", "元気よ", "ゲンキデス", "調子いい","調子よい","ちょういいい","ちょうしよい"],
        response: (playerName) => {
            return `${playerName}さん、元気そうで何よりです。分からないことがあれば、いつでもお声がけください！`;
        }
    },
    hanasitakuanai: {
        patterns: ["したくない", "ほしくない", "やだ", "嫌だ", "いやだ", "欲しくない", "だまれ","黙って"],
        response: (playerName) => {
            return `${playerName}さん、失礼しました！また何か、ご質問などあればいつでもお待ちしますよ！`;
        }
    },
    gomen: {
        patterns: ["ごめん", "ソーリー", "sorry", "すまん", "めんご", "申し訳"],
        response: (playerName) => {
            return `${playerName}さん、全然大丈夫ですよ！また何か、ご質問などあればいつでもお待ちしますよ！`;
        }
    },
    hazimemasite: {
        patterns: ["自己紹介", "はじめまして", "初めまして", "じこしょうかい"],
        response: (playerName) => {
            return `${playerName}さん、はじめまして！私はHARUassistantです。よろしくね！`;
        }
    },
    hazimemasite: {
        patterns: ["よろしく", "ヨロシク", "お願いします"],
        response: (playerName) => {
            return `${playerName}さん、よろしくお願いします！何か、ご質問などあればいつでもお待ちしますよ！`;
        }
    }
};
// 日常会話パターン検出関数
function detectCasualPattern(message) {
    for (let pattern in casualResponses) {
        if (casualResponses[pattern].patterns.some(keyword => message.includes(keyword))) {
            return pattern;
        }
    }
    return null;
}

// 日常会話応答取得関数
function getCasualResponse(pattern, playerName, message) {
    const responseFunc = casualResponses[pattern]?.response;
    if (!responseFunc) return null;
    return responseFunc(playerName, message);
}

export { detectCasualPattern, getCasualResponse };