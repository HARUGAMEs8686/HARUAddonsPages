import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../../config';
import { LiteFrame_editor } from './editor/LiteFrame_editor';

var player_Cash_Data = {};
export function HARU_XEditor_LiteFrame_upload(player, Application) {
    system.run(() => {
        player_Cash_Data[player.id] = {};
        player_Cash_Data[player.id].Application = JSON.parse(world.getDynamicProperty(`${Application[0]}`));
        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§aアプリをアップロードしますか？\n\n§a対象アプリケーション§r:§b${player_Cash_Data[player.id].Application.ApplicationName}`);
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        form.button(`§5アップロード`);
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    LiteFrame_editor(player, Application);
                    break;
                case 1:
                    //AppDataにアプリIDを保存
                    var AppData = world.getDynamicProperty(`AppData`);
                    if (AppData == undefined) {
                        var AppData = [];
                    } else {
                        var AppData = JSON.parse(AppData);
                    }

                    if (AppData.some(app => JSON.stringify(app) === JSON.stringify(Application))) {
                        player.sendMessage(`§r[§bHARU-XEditor§r] §4既にアップロード済みです`);
                        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                        LiteFrame_editor(player, Application);
                        return;
                    }

                    AppData.push(Application);
                    world.setDynamicProperty(`AppData`, JSON.stringify(AppData));
                    player.sendMessage(`§r[§bHARU-XEditor§r] §aアップロード完了`);
                    player.playSound('random.toast', {
                        pitch: 1.4,
                        volume: 1.0,
                    });
                    break;
            }
        });
    });
}
