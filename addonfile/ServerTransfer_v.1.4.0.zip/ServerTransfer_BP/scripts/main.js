import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { transferPlayer } from '@minecraft/server-admin';

import { config } from './config.js';

world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    system.run(() => {
        if (eventData.itemStack.typeId === 'additem:servertransfer') {
            ServerListUI(player);
        }
    });
});

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'servertransfer:ui') {
        const selector = eventData.message.trim();
        if (!selector) {
            console.warn(`[ServerTransfer] エラー: /scriptevent servertransfer:ui <selector|playerName> の形式で指定してください。入力: ${eventData.message}`);
            return;
        }

        const targetPlayers = parseSelector(selector);
        if (targetPlayers.length === 0) {
            console.warn(`[ServerTransfer] セレクター "${selector}" に一致するプレイヤーが見つかりませんでした。`);
            return;
        }
        system.run(async () => {
            targetPlayers.forEach(player => {
                ServerListUI(player);
            });
        });
    } else if (eventData.id === 'servertransfer:go') {
        const args = eventData.message.trim().split(/\s+/);
        if (args.length < 2) {
            console.warn(`[ServerTransfer] エラー: /scriptevent servertransfer:go <サーバーID> <セレクター> の形式で指定してください。入力: ${eventData.message}`);
            return;
        }

        const serverIndex = parseInt(args[0], 10);
        const selector = args.slice(1).join(' ');

        if (isNaN(serverIndex)) {
            console.warn(`[ServerTransfer] エラー: サーバーセレクトは数字である必要があります。入力: ${args[0]}`);
            return;
        }

        if (serverIndex < 0 || serverIndex >= config.length) {
            console.warn(`[ServerTransfer] エラー: サーバーセレクト ${serverIndex} は無効です。設定されているサーバーは0から${config.length - 1}までです。`);
            return;
        }

        const targetPlayers = parseSelector(selector);
        if (targetPlayers.length === 0) {
            console.warn(`[ServerTransfer] セレクター "${selector}" に一致するプレイヤーが見つかりませんでした。`);
            return;
        }

        const selectedServer = config[serverIndex];

        system.run(() => {
            for (const player of targetPlayers) {
                try {
                    transferPlayer(player, { hostname: selectedServer.ip, port: selectedServer.port });
                } catch (error) {
                    console.error(`[ServerTransfer] ${player.name} の転送中にエラーが発生しました:`, error);
                }
            }
        });
    }
});

function ServerListUI(player) {
    try {
        const form = new ActionFormData().title('§0サーバー移動').body('>>>§e選択してください');
        for (const server of config) {
            form.button(`§1${server.name}`, 'textures/ui/bubble_empty');
        }
        form.show(player).then(r => {
            if (r.canceled) {
                return;
            }
            const selection = r.selection;
            const selectedServer = config[selection];
            transferPlayer(player, { hostname: selectedServer.ip, port: selectedServer.port });
        });
    } catch (error) {
        console.error('サーバー転送フォームの処理中にエラーが発生しました:', error);
    }
}

//セレクター
function parseSelector(selector) {
    if (!selector) return [];

    var players = [];
    for (const player of world.getPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}
