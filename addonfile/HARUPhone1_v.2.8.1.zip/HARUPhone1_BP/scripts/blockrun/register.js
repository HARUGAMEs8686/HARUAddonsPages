import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';

// プレイヤーデータを管理するオブジェクト
const player_Cash_Data = {};
// 支払いログ
const harupay_logs = [];

export function Register(seller) {
    const sellerId = seller.id;

    // プレイヤーデータの初期化
    if (!player_Cash_Data[sellerId]) {
        player_Cash_Data[sellerId] = {
            cash: 0,
            isRegistering: false,
            RegisterStop: false,
            lastTransaction: null,
        };
    }

    // クールダウン中なら何もせず終了
    if (player_Cash_Data[sellerId].RegisterStop) {
        return;
    }

    // クールダウン開始（1秒=20tick）
    player_Cash_Data[sellerId].RegisterStop = true;
    system.runTimeout(() => {
        player_Cash_Data[sellerId].RegisterStop = false;
    }, 20);

    system.run(() => {
        try {
            // --- フロー変更：ここから販売者が操作 ---

            // 1. 販売者の近くにいるプレイヤー（支払者候補）を探す
            const { x: sellerX, y: sellerY, z: sellerZ } = seller.location;
            const allPlayers = world.getPlayers();
            const nearbyPlayers = [];
            const maxDistance = 4; // 4ブロック以内

            for (const target of allPlayers) {
                if (target.name === seller.name) continue; // 自分を除外
                const { x: targetX, y: targetY, z: targetZ } = target.location;
                const distance = Math.sqrt(Math.pow(targetX - sellerX, 2) + Math.pow(targetY - sellerY, 2) + Math.pow(targetZ - sellerZ, 2));
                if (distance <= maxDistance) {
                    nearbyPlayers.push(target);
                }
            }

            if (nearbyPlayers.length === 0) {
                seller.sendMessage('§r[§bレジ§r] §c取引可能なプレイヤーが見つかりませんでした');
                seller.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
                return;
            }

            // 2. 販売者に、支払者を選択させるUIを表示
            const targetForm = new ActionFormData().title('§1レジ').body('>>> §e支払い者を選択してください');
            nearbyPlayers.forEach(target => {
                targetForm.button(`§0${target.name}`, 'textures/ui/normalicon1');
            });

            targetForm
                .show(seller)
                .then(targetResponse => {
                    if (targetResponse.canceled) {
                        return;
                    }

                    const player = nearbyPlayers[targetResponse.selection]; // 選択された支払者

                    // --- フロー変更：ここから支払者が操作 ---

                    // 3. 支払者に、支払い方法を選択させるUIを表示
                    const paymentForm = new ActionFormData().title('§1レジ').body('お支払い方法を選択してください...').button('§1HARUPAY', 'textures/ui/normalicon1');

                    paymentForm
                        .show(player)
                        .then(paymentResponse => {
                            if (paymentResponse.canceled) {
                                seller.sendMessage('§r[§bレジ§r] §e支払者が支払いをキャンセルしました');
                                return;
                            }

                            if (paymentResponse.selection === 0) {
                                // HARUPAYが選択された
                                seller.sendMessage(`§r[§bレジ§r] §e${player.name}さんのお支払いを確認中です...`);
                                player.sendMessage('§r[§bレジ§r] §e管理者が金額を設定中です。しばらくお待ちください...');

                                // --- フロー変更：ここから再び販売者が操作 ---

                                // 4. 販売者に、金額を入力させるUIを表示
                                const amountForm = new ModalFormData().title('§1レジ').textField('合計金額(半角数字)', '0');

                                amountForm
                                    .show(seller)
                                    .then(amountResponse => {
                                        if (amountResponse.canceled) {
                                            player.sendMessage('§r[§bレジ§r] §4支払いを管理者がキャンセルしました');
                                            player.playSound('haru.notification1', {
                                                pitch: 0.8,
                                                volume: config['Volume'],
                                            });
                                            return;
                                        }

                                        const amount = amountResponse.formValues[0];
                                        if (!amount || isNaN(amount)) {
                                            seller.sendMessage('§4半角数字で入力してください');
                                            player.sendMessage('§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください');
                                            seller.playSound('haru.notification1', {
                                                pitch: 0.8,
                                                volume: config['Volume'],
                                            });
                                            player.playSound('haru.notification1', {
                                                pitch: 0.8,
                                                volume: config['Volume'],
                                            });
                                            return;
                                        }

                                        const cashAmount = parseInt(amount);
                                        if (cashAmount > 100000000) {
                                            seller.sendMessage('§4設定した金額は上限を超えています(1億以下で設定してください)');
                                            player.sendMessage('§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください');
                                            seller.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            return;
                                        }
                                        if (cashAmount <= 0) {
                                            // 0円は許可しない
                                            seller.sendMessage('§40より大きい金額を設定してください');
                                            player.sendMessage('§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください');
                                            seller.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                            return;
                                        }

                                        // --- フロー変更：最後に支払者が確認 ---

                                        // 5. 支払者に、最終確認UIを表示
                                        const confirmForm = new ActionFormData()
                                            .title('§1レジ')
                                            .body(`§6相手§r:§c${seller.name}`)
                                            .divider()
                                            .header(`支払い確認`)
                                            .divider()
                                            .label(`§aHARUPAY残高§r:§e${world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity)}\n支払い金額は§b${cashAmount}PAY§rです`)
                                            .button('§1HARUPAYで支払う', 'textures/ui/normalicon1')
                                            .button('§0キャンセル', 'textures/ui/normalicon1');

                                        confirmForm.show(player).then(confirmResponse => {
                                            if (confirmResponse.canceled || confirmResponse.selection === 1) {
                                                seller.sendMessage('§r[§bレジ§r] §e支払者が支払いをキャンセルしました');
                                                return;
                                            }

                                            if (confirmResponse.selection === 0) {
                                                const playerScore = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                                if (playerScore >= cashAmount) {
                                                    // 支払い処理
                                                    seller.runCommand(`scoreboard players add @s account ${cashAmount}`);
                                                    player.runCommand(`scoreboard players remove @s money ${cashAmount}`);

                                                    player.sendMessage('§r[§bレジ§r] §e正常に支払いが完了しました');
                                                    seller.sendMessage('§r[§bレジ§r] §e正常に支払われました\n§r>>>§aATMから受け取れます');

                                                    player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
                                                    seller.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });

                                                    // ログ記録
                                                    const timer = new Date();
                                                    harupay_logs.push(`[${timer.getHours()}:${timer.getMinutes()}] ${player.name}が${seller.name}へ${cashAmount}PAY送信(レジ)`);
                                                } else {
                                                    player.sendMessage('§r[§bレジ§r] §eHARUPAY残高が不足しています');
                                                    seller.sendMessage('§r[§bレジ§r] §e支払いが残高不足により中止されました');

                                                    player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                                    seller.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                                                }
                                            }
                                        });
                                    })
                                    .catch(error => {
                                        console.error('金額入力UIエラー:', error);
                                        seller.sendMessage('§4エラーが発生しました。');
                                    });
                            }
                        })
                        .catch(error => {
                            console.error('支払い方法選択UIエラー:', error);
                            player.sendMessage('§4エラーが発生しました。');
                        });
                })
                .catch(error => {
                    console.error('支払者選択UIエラー:', error);
                    seller.sendMessage('§4エラーが発生しました。');
                });
        } catch (error) {
            console.error('レジ処理エラー:', error);
            seller.sendMessage('§4予期せぬエラーが発生しました。');
        }
    });
}
