import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../../config';
import { HARU_XEditor_NewApp } from '../../App/HARU-XEditor';
import { HARU_XEditor } from '../../App/HARU-XEditor';
import { LiteFrame_editor } from './editor/LiteFrame_editor';

var player_Cash_Data = {};
export function HARU_XEditor_LiteFrame_NewApp(player) {
    system.run(() => {
        player_Cash_Data[player.id] = {};
        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;

        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField(`§b§l${time}\n\n§r§aアプリケーション名`, '例:HARUPAY');
        form.show(player).then(r => {
            //↓開発中の為
            // if (r.canceled) {
            //     HARU_XEditor_NewApp(player, time);
            //     return;
            // }
            if (r.canceled) {
                HARU_XEditor(player);
                return;
            }
            player_Cash_Data[player.id].ApplicationName = r.formValues[0];
            HARU_XEditor_LiteFrame_NewApp_Actionselect(player, time);
        });
    });
}

function HARU_XEditor_LiteFrame_NewApp_Actionselect(player, time) {
    const ACTION = [
        [`§s起動§0>>>§1コマンド(複数可)を実行`, 'LiteFrameA'],
        //↓開発中の為非表示
        // [`§s起動§0>>>§5Playerlistを選択§0>>>\n§1コマンド実行`, 'LiteFrameB'],
        // [`§s起動§0>>>§5Playerlistを選択§0>>>\n§5入力§0>>>§1コマンド実行`, 'LiteFrameC'],
        // [`§s起動§0>>>§5テキスト画面を表示`, 'LiteFrameD'],
    ];
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}\n§r§5>>>§rActionパターンを選択`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < ACTION.length; i++) {
        form.button(ACTION[i][0]);
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            HARU_XEditor_LiteFrame_NewApp(player);
            return;
        }
        player_Cash_Data[player.id].ActionPattern = r.selection - 1;
        //利用できない機能を制限 (削除予定)
        if (player_Cash_Data[player.id].ActionPattern !== 0) {
            player.sendMessage(`§r[§bHARU-XEditor§r] §c選択した機能は利用できません`);
            player.playSound('random.toast', {
                pitch: 0.5,
                volume: 1.0,
            });
            HARU_XEditor_LiteFrame_NewApp_Actionselect(player, time);
            return;
        }
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§aアプリ名§r:§b${player_Cash_Data[player.id].ApplicationName}\n\n§e-ActionPattern-\n§c>>>${ACTION[player_Cash_Data[player.id].ActionPattern][0]}\n\n§a開発者§r:${player.name}`);
        form.button(`§5作成`);
        form.button(`§1キャンセル`);
        form.show(player).then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    player_Cash_Data[player.id].CommandRunNumber = 10;
                    //Code生成
                    let number = '';
                    for (let i = 0; i < 8; i++) {
                        number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                    }
                    world.setDynamicProperty(`App_${player_Cash_Data[player.id].ApplicationName}_${number}`, JSON.stringify(player_Cash_Data[player.id]));

                    //MY_AppData(Player)にアプリIDを保存
                    var MY_AppData = player.getDynamicProperty(`MY_AppData`);
                    if (MY_AppData == undefined) {
                        var MY_AppData = [];
                    } else {
                        var MY_AppData = JSON.parse(MY_AppData);
                    }
                    MY_AppData.push([`App_${player_Cash_Data[player.id].ApplicationName}_${number}`, ACTION[player_Cash_Data[player.id].ActionPattern][1]]);
                    player.setDynamicProperty(`MY_AppData`, JSON.stringify(MY_AppData));

                    player.sendMessage(`§r[§bHARU-XEditor§r] §a新規作成しました`);
                    player.playSound('random.toast', {
                        pitch: 1.5,
                        volume: 1.0,
                    });

                    LiteFrame_editor(player, [`App_${player_Cash_Data[player.id].ApplicationName}_${number}`, ACTION[player_Cash_Data[player.id].ActionPattern][1]]);
                    break;
                case 1:
                    player.sendMessage(`§r[§bHARU-XEditor§r] §c作成をキャンセルしました`);
                    player.playSound('random.toast', {
                        pitch: 0.5,
                        volume: 1.0,
                    });
                    break;
            }
        });
    });
}
