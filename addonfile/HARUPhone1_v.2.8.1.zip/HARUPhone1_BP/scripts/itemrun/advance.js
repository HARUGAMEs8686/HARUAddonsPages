import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { HARUPhone1 } from './haruphone1';

// --- データ管理 ---
const KEYS = {
    COMPANIES: 'adv_companies', // 会社情報
    PRODUCTS: 'adv_products', // 商品情報
    ORDERS_META: 'adv_orders_meta', // 注文データのチャンク情報
    ORDERS_PREFIX: 'adv_orders_', // 注文データのチャンクのプレフィックス
    MIGRATION_FLAG: 'adv_migration_completed', // データ移行完了フラグ
    PENDING_NOTIFICATIONS: 'adv_pending_notifications', // ★変更点: 保留中の通知
};
const MAX_CHUNK_SIZE = 30000; // チャンクごとの最大おおよそのサイズ (バイト)

// データを安全に読み込む（JSONパースエラー対策）
function loadData(key, defaultValue = {}) {
    const savedData = world.getDynamicProperty(key);
    if (savedData === undefined) {
        return defaultValue;
    }
    try {
        return JSON.parse(savedData);
    } catch (e) {
        console.error(`[Advance] Failed to parse JSON for key "${key}". Error: ${e}`);
        return defaultValue;
    }
}

// データを保存する
function saveData(key, data) {
    world.setDynamicProperty(key, JSON.stringify(data));
}

// 簡易的なユニークIDを生成する
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

// --- 注文データ（チャンキング対応） ---
function loadAllOrders() {
    const meta = loadData(KEYS.ORDERS_META, { chunkCount: 1 });
    const allOrders = {};
    for (let i = 0; i < meta.chunkCount; i++) {
        const chunkKey = `${KEYS.ORDERS_PREFIX}${i}`;
        const chunkData = loadData(chunkKey, {});
        Object.assign(allOrders, chunkData);
    }
    return allOrders;
}

function saveAllOrders(allOrders) {
    // 1. 古いチャンクを一旦すべて削除する
    const oldMeta = loadData(KEYS.ORDERS_META, { chunkCount: 1 });
    for (let i = 0; i < oldMeta.chunkCount; i++) {
        world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${i}`, undefined);
    }

    // 2. 新しいチャンクを作成して保存する
    const orderEntries = Object.entries(allOrders);
    if (orderEntries.length === 0) {
        // 注文が空の場合はメタ情報だけ更新し、空のチャンクを1つ作成
        saveData(KEYS.ORDERS_META, { chunkCount: 1 });
        world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}0`, '{}');
        return;
    }

    let chunkIndex = 0;
    let currentChunk = {};
    let currentChunkString = '{}';

    for (const [orderId, orderData] of orderEntries) {
        const newChunk = { ...currentChunk, [orderId]: orderData };
        const newChunkString = JSON.stringify(newChunk);

        // 現在のチャンクが一杯になった場合 (ただし、チャンクが空の場合は必ず1つは要素を入れる)
        if (newChunkString.length > MAX_CHUNK_SIZE && Object.keys(currentChunk).length > 0) {
            world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${chunkIndex}`, currentChunkString);
            chunkIndex++;
            currentChunk = { [orderId]: orderData };
            currentChunkString = JSON.stringify(currentChunk);
        } else {
            currentChunk = newChunk;
            currentChunkString = newChunkString;
        }
    }

    // 最後のチャンクを保存
    world.setDynamicProperty(`${KEYS.ORDERS_PREFIX}${chunkIndex}`, currentChunkString);

    // 3. 新しいメタ情報を保存
    saveData(KEYS.ORDERS_META, { chunkCount: chunkIndex + 1 });
}

// --- データ移行処理 ---
// 古いデータ構造から新しいデータ構造へ変換
function migrateData() {
    // 既に移行が完了している場合は何もしない
    if (world.getDynamicProperty(KEYS.MIGRATION_FLAG)) {
        return;
    }

    console.log('[Advance] Starting data migration...');

    const oldMembers = world.getDynamicProperty('advance_member');
    const oldShops = world.getDynamicProperty('advance_shop');
    // 古いadv_ordersもチェック
    const oldOrdersDirect = world.getDynamicProperty('adv_orders');

    const newCompanies = {};
    const newProducts = {};
    const newOrders = {};

    // advance_memberの移行
    if (oldMembers) {
        try {
            const members = JSON.parse(oldMembers);
            for (const member of members) {
                // [playerName, companyName, companyDetails, assets, []]
                const companyName = member[1];
                if (companyName) {
                    newCompanies[companyName] = {
                        owner: member[0],
                        details: member[2],
                        assets: member[3] || 0,
                    };
                }
            }
        } catch (e) {
            console.error(`[Advance] Failed to migrate 'advance_member': ${e}`);
        }
    }

    // advance_shopの移行
    if (oldShops) {
        try {
            const shops = JSON.parse(oldShops);
            for (const shop of shops) {
                // [companyName, [products...]]
                const companyName = shop[0];
                const productList = shop[1];

                for (const product of productList) {
                    // [productName, price, stock, orders[], ?]
                    const productId = generateId();
                    newProducts[productId] = {
                        companyName: companyName,
                        name: product[0],
                        price: Number(product[1]) || 0,
                        stock: Number(product[2]) || 0,
                    };

                    // 注文履歴の移行
                    const oldOrders = product[3] || [];
                    for (const order of oldOrders) {
                        // [buyerName, quantity, status (0 or 1)]
                        const orderId = generateId();
                        newOrders[orderId] = {
                            productId: productId,
                            productName: product[0], // 履歴表示用に商品名も保存
                            companyName: companyName,
                            buyerName: order[0],
                            quantity: Number(order[1]) || 0,
                            totalPrice: (Number(product[1]) || 0) * (Number(order[1]) || 0),
                            status: order[2] === 1 ? 'completed' : 'delivering', // 0 -> delivering, 1 -> completed
                        };
                    }
                }
            }
        } catch (e) {
            console.error(`[Advance] Failed to migrate 'advance_shop': ${e}`);
        }
    }

    // 新しいデータを保存
    saveData(KEYS.COMPANIES, newCompanies);
    saveData(KEYS.PRODUCTS, newProducts);
    // チャンキング対応の保存関数を呼び出す
    saveAllOrders(newOrders);

    // 移行完了フラグを立てる
    world.setDynamicProperty(KEYS.MIGRATION_FLAG, true);

    // 古いデータを削除
    world.setDynamicProperty('advance_member', undefined);
    world.setDynamicProperty('advance_shop', undefined);
    world.setDynamicProperty('adv_orders', undefined); // 古いordersキーも削除

    console.log('[Advance] Data migration completed successfully.');
}

// --- メイン機能 ---
export function Advance(player) {
    system.run(() => {
        // ★変更点: ここから追加
        // --- 保留中の通知を処理 ---
        const pendingNotifications = loadData(KEYS.PENDING_NOTIFICATIONS, {});
        const notificationsForPlayer = pendingNotifications[player.name];

        if (notificationsForPlayer && notificationsForPlayer.length > 0) {
            player.sendMessage('§r[§bAdvance§r] §eオフライン中の注文通知があります:');
            notificationsForPlayer.forEach(message => {
                player.sendMessage(message);
            });

            // 通知を削除して保存
            delete pendingNotifications[player.name];
            saveData(KEYS.PENDING_NOTIFICATIONS, pendingNotifications);
        }

        // ワールド参加時に一度だけデータ移行を試みる
        migrateData();

        const currentCompany = player.getDynamicProperty('advance_member_data');

        if (!currentCompany || !player.hasTag('advance_member')) {
            showLoginMenu(player);
        } else {
            showCompanyMenu(player, currentCompany);
        }
    });
}

// --- UI関数 ---

// ログイン/アカウント作成メニュー
function showLoginMenu(player) {
    const form = new ActionFormData();
    form.title('§1Advance');
    form.body('>>> §e選択してください');
    form.button('§1Advanceアカウント作成', 'textures/ui/normalicon1');
    form.button('§5Advanceアカウントにログイン', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            createAccountUI(player);
        } else {
            loginAccountUI(player);
        }
    });
}

// アカウント作成UI
function createAccountUI(player) {
    const form = new ModalFormData();
    form.title('§1Advance');
    form.textField('§a会社名(店名)', '私の会社');
    form.textField('§b会社(店)の詳細', '様々な商品を扱っています');
    form.show(player).then(r => {
        if (r.canceled) {
            showLoginMenu(player);
            return;
        }

        const [companyName, companyDetails] = r.formValues;
        if (!companyName) {
            player.sendMessage('§r[§bAdvance§r] §c会社名を入力してください。');
            showLoginMenu(player);
            return;
        }

        const companies = loadData(KEYS.COMPANIES);
        if (companies[companyName]) {
            player.sendMessage('§r[§bAdvance§r] §cこの会社名は既に使われています。');
            showLoginMenu(player);
            return;
        }

        companies[companyName] = {
            owner: player.name,
            details: companyDetails,
            assets: 0,
        };
        saveData(KEYS.COMPANIES, companies);

        player.setDynamicProperty('advance_member_data', companyName);
        player.addTag('advance_member');
        player.sendMessage('§r[§bAdvance§r] §aアカウントを作成しました。');
    });
}

// ログインUI
function loginAccountUI(player) {
    const companies = loadData(KEYS.COMPANIES);
    const playerCompanies = Object.keys(companies).filter(name => companies[name].owner === player.name);

    if (playerCompanies.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §cログインできるアカウントがありません。');
        return;
    }

    const form = new ActionFormData();
    form.title('§1Advance');
    form.body('>>> §eアカウントを選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    playerCompanies.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showLoginMenu(player);
            return;
        }
        const selectedCompany = playerCompanies[r.selection - 1];
        player.setDynamicProperty('advance_member_data', selectedCompany);
        player.addTag('advance_member');
        player.sendMessage('§r[§bAdvance§r] §aログインしました。');
        Advance(player);
    });
}

// 会社運営メニュー
function showCompanyMenu(player, companyName) {
    const companies = loadData(KEYS.COMPANIES);
    const company = companies[companyName];

    if (!company) {
        player.sendMessage('§r[§bAdvance§r] §c会社情報が見つかりません。自動的にログアウトします。');
        player.removeTag('advance_member');
        player.setDynamicProperty('advance_member_data', undefined);
        Advance(player);
        return;
    }

    const form = new ActionFormData();
    form.title('§1Advance');
    form.body(`§rアカウント:§b${companyName}`);
    form.button('§4ログアウト', 'textures/ui/icon_import.png');
    form.button('§1配送完了設定', 'textures/ui/normalicon1');
    form.button(`§9送金\n§0資産:§3${company.assets.toLocaleString()}`, 'textures/ui/normalicon1');
    form.button('§5商品編集', 'textures/ui/normalicon1');

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0: // ログアウト
                player.removeTag('advance_member');
                player.setDynamicProperty('advance_member_data', undefined);
                player.sendMessage('§r[§bAdvance§r] §aログアウトしました。');
                Advance(player);
                break;
            case 1: // 配送完了設定
                deliveryManagementUI(player, companyName);
                break;
            case 2: // 資産送信
                sendAssetsUI(player, companyName);
                break;
            case 3: // 商品管理
                productManagementUI(player, companyName);
                break;
        }
    });
}

// 配送管理UI
function deliveryManagementUI(player, companyName) {
    const allOrders = loadAllOrders();
    const pendingOrders = Object.entries(allOrders).filter(([id, order]) => order.companyName === companyName && order.status === 'delivering');

    if (pendingOrders.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c配送未完了の商品がありません');
        return;
    }

    const form = new ActionFormData();
    form.title('§1配送完了設定');
    form.body('>>> §e配送完了した注文を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    pendingOrders.forEach(([id, order]) => {
        form.button(`§1${order.productName}§r\n§0個数:§2${order.quantity} §0配送先:§9${order.buyerName}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showCompanyMenu(player, companyName);
            return;
        }
        const [orderIdToComplete] = pendingOrders[r.selection - 1];

        // --- 操作直前の再検証 ---
        const latestOrders = loadAllOrders();
        if (latestOrders[orderIdToComplete] && latestOrders[orderIdToComplete].status === 'delivering') {
            latestOrders[orderIdToComplete].status = 'completed';
            saveAllOrders(latestOrders);
            player.sendMessage('§r[§bAdvance§r] §a配送を完了しました');
            deliveryManagementUI(player, companyName);
        } else {
            player.sendMessage('§r[§bAdvance§r] §cエラー: この注文は既に処理されているか、存在しません');
        }
    });
}

// 商品管理UI (追加/編集/削除の選択)
function productManagementUI(player, companyName) {
    const form = new ActionFormData();
    form.title('§1商品管理');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1追加', 'textures/ui/normalicon1');
    form.button('§0編集', 'textures/ui/normalicon1');
    form.button('§5削除', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                showCompanyMenu(player, companyName);
                break;
            case 1:
                addProductUI(player, companyName);
                break;
            case 2:
                editProductListUI(player, companyName);
                break;
            case 3:
                deleteProductListUI(player, companyName);
                break;
        }
    });
}

// 商品追加UI
function addProductUI(player, companyName) {
    const form = new ModalFormData();
    form.title('§1商品の追加');
    form.textField('§a商品名', 'ダイヤモンド');
    form.textField('§e金額', '1000');
    form.textField('§b在庫数', '64');
    form.show(player).then(r => {
        if (r.canceled) {
            productManagementUI(player, companyName);
            return;
        }

        const [name, priceStr, stockStr] = r.formValues;
        const price = parseInt(priceStr, 10);
        const stock = parseInt(stockStr, 10);

        if (!name || isNaN(price) || isNaN(stock) || price < 0 || stock < 0) {
            player.sendMessage('§r[§bAdvance§r] §c入力内容が正しくありません。');
            return;
        }

        const products = loadData(KEYS.PRODUCTS);
        const productId = generateId();
        products[productId] = { companyName, name, price, stock };
        saveData(KEYS.PRODUCTS, products);

        player.sendMessage('§r[§bAdvance§r] §a商品を追加しました。');
    });
}

// 編集する商品を選択するUI
function editProductListUI(player, companyName) {
    const allProducts = loadData(KEYS.PRODUCTS);
    const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === companyName);

    if (companyProducts.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c編集可能な商品がありません。');
        return;
    }

    const form = new ActionFormData();
    form.title('§0商品の編集');
    form.body('>>> §e編集する商品を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyProducts.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額: §9${product.price} §0在庫: §2${product.stock}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            productManagementUI(player, companyName);
            return;
        }
        const [productId, productToEdit] = companyProducts[r.selection - 1];
        editProductUI(player, productId, productToEdit, companyName);
    });
}

// 商品編集UI
function editProductUI(player, productId, product, companyName) {
    const form = new ModalFormData();
    form.title('商品の編集');
    form.textField('§a商品名', product.name);
    form.textField('§e金額', product.price.toString());
    form.textField('§b在庫数', product.stock.toString());
    form.show(player).then(r => {
        if (r.canceled) {
            editProductListUI(player, companyName);
            return;
        }

        const [name, priceStr, stockStr] = r.formValues;
        const price = parseInt(priceStr, 10);
        const stock = parseInt(stockStr, 10);

        if (!name || isNaN(price) || isNaN(stock) || price < 0 || stock < 0) {
            player.sendMessage('§r[§bAdvance§r] §c入力内容が正しくありません。');
            return;
        }

        // --- 操作直前の再検証 ---
        const latestProducts = loadData(KEYS.PRODUCTS);
        if (latestProducts[productId]) {
            latestProducts[productId] = { ...latestProducts[productId], name, price, stock };
            saveData(KEYS.PRODUCTS, latestProducts);
            player.sendMessage('§r[§bAdvance§r] §a商品を編集しました。');
        } else {
            player.sendMessage('§r[§bAdvance§r] §cエラー: 編集しようとした商品は既に削除されています。');
        }
    });
}

// 削除する商品を選択するUI
function deleteProductListUI(player, companyName) {
    const allProducts = loadData(KEYS.PRODUCTS);
    const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === companyName);

    if (companyProducts.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c削除可能な商品がありません。');
        return;
    }

    const form = new ActionFormData();
    form.title('§4商品の削除');
    form.body('>>> §e削除する商品を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyProducts.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額: §9${product.price}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            productManagementUI(player, companyName);
            return;
        }

        const [productIdToDelete] = companyProducts[r.selection - 1];

        // --- 操作直前の再検証 ---
        const latestProducts = loadData(KEYS.PRODUCTS);
        const latestOrders = loadAllOrders();

        if (!latestProducts[productIdToDelete]) {
            player.sendMessage('§r[§bAdvance§r] §cエラー: この商品は既に削除されています。');
            return;
        }

        const hasPendingOrders = Object.values(latestOrders).some(order => order.productId === productIdToDelete && order.status === 'delivering');

        if (hasPendingOrders) {
            player.sendMessage('§r[§bAdvance§r] §c選択した商品の配送がすべて完了していません。');
            deleteProductListUI(player, companyName);
            return;
        }

        delete latestProducts[productIdToDelete];
        saveData(KEYS.PRODUCTS, latestProducts);

        player.sendMessage('§r[§bAdvance§r] §a商品を削除しました。');
        deleteProductListUI(player, companyName);
    });
}

// 資産をHARUPAY (個人のmoneyスコア) に送信するUI
function sendAssetsUI(player, companyName) {
    // 自分以外の全プレイヤーを取得
    const otherPlayers = world.getAllPlayers();

    if (otherPlayers.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c送金対象となる他のプレイヤーがサーバーにいません。');
        return;
    }

    // --- ステップ1: 送金相手の選択 ---
    const form = new ActionFormData();
    form.title('§0資産の送信');
    form.body('>>> §e送り先のプレイヤーを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    otherPlayers.forEach(p => {
        form.button(`§1${p.name}\n§5>>>§0${p.id}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showCompanyMenu(player, companyName);
            return;
        }
        const targetPlayer = otherPlayers[r.selection - 1];

        // --- ステップ2: 送金額の入力 ---
        // 画面表示用に現在の資産を取得
        const companies = loadData(KEYS.COMPANIES);
        // 会社が存在しないケースを考慮
        const currentAssets = companies[companyName]?.assets ?? 0;

        const amountForm = new ModalFormData();
        amountForm.title(`§1${targetPlayer.name} §0への送金`);
        amountForm.textField(`§r§b送金額§r(半角数字)を入力してください。\n\n` + `§r現在の会社資産: §a${currentAssets.toLocaleString()}`, '0');

        amountForm.show(player).then(r2 => {
            if (r2.canceled) {
                sendAssetsUI(player, companyName);
                return;
            }

            const amountStr = r2.formValues[0];
            const amount = parseInt(amountStr, 10);

            // --- ステップ3: 入力値のバリデーション ---
            if (isNaN(amount) || amountStr === '') {
                player.sendMessage('§r[§bAdvance§r] §c半角数字で金額を入力してください。');
                return;
            }
            if (amount <= 0) {
                player.sendMessage('§r[§bAdvance§r] §c送金額は0より大きい値を設定してください。');
                return;
            }
            if (amount > 100000000) {
                // 上限チェック
                player.sendMessage('§r[§bAdvance§r] §c一度に送金できる上限は1億です。');
                return;
            }

            // --- ステップ4: 最終確認と送金処理 (※ここが最も重要) ---
            // 処理の直前に最新のデータを読み込み、競合状態を防ぐ
            system.run(() => {
                const latestCompanies = loadData(KEYS.COMPANIES);
                const company = latestCompanies[companyName];

                // 会社データの存在チェック
                if (!company) {
                    player.sendMessage('§r[§bAdvance§r] §cエラー: 会社情報が見つかりませんでした。');
                    return;
                }

                // 資産残高の最終チェック
                if (company.assets < amount) {
                    player.sendMessage(`§r[§bAdvance§r] §c会社の資産が不足しています。(現在の資産: ${company.assets.toLocaleString()})`);
                    return;
                }

                // --- 全てのチェックを通過したら処理を実行 ---
                // 会社の資産を減らす
                company.assets -= amount;
                saveData(KEYS.COMPANIES, latestCompanies);

                // 相手の所持金を増やす
                targetPlayer.runCommand(`scoreboard players add @s money ${amount}`);

                // 通知メッセージ
                player.sendMessage(`§r[§bAdvance§r] §b${targetPlayer.name}§a へ §b${amount.toLocaleString()}§a 送信しました。`);
                targetPlayer.sendMessage(`§r[§bAdvance§r] §b${companyName}§a(${player.name}) から §b${amount.toLocaleString()}§a 受け取りました。`);
            });
        });
    });
}

// -----------------------------------------------------------------
// --- 購入者向け機能 (haruphone1.jsから呼び出される) ---
// -----------------------------------------------------------------

export function showAdvanceBuyerMenu(player) {
    const form = new ActionFormData();
    form.title('§1Advance');
    form.body('>>> §e商品を見つける');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§0キーワード検索', 'textures/ui/normalicon1');
    form.button('§5会社から探す', 'textures/ui/normalicon1');
    form.button('§1注文した商品の配送状況', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                HARUPhone1(player);
                break;
            case 1:
                searchByKeywordUI(player);
                break;
            case 2:
                searchByCompanyUI(player);
                break;
            case 3:
                showDeliveryStatusUI(player);
                break;
        }
    });
}

// キーワード検索UI
function searchByKeywordUI(player) {
    const form = new ModalFormData();
    form.title('§0キーワード検索');
    form.textField('§a検索したい商品名を入力', 'ダイヤモンド');
    form.show(player).then(r => {
        if (r.canceled || !r.formValues[0]) {
            showAdvanceBuyerMenu(player);
            return;
        }
        const keyword = r.formValues[0];
        const allProducts = loadData(KEYS.PRODUCTS);

        const searchResults = Object.entries(allProducts).filter(([id, product]) => product.name.includes(keyword) && product.stock > 0);

        if (searchResults.length === 0) {
            player.sendMessage('§r[§bAdvance§r] §c商品が見つかりませんでした。');
            return;
        }

        showProductListUI(player, searchResults, '§0検索結果', true);
    });
}

// 会社指定での検索UI
function searchByCompanyUI(player) {
    const companies = loadData(KEYS.COMPANIES);
    const companyNames = Object.keys(companies);

    if (companyNames.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c現在営業中の会社がありません。');
        return;
    }

    const form = new ActionFormData();
    form.title('§1会社から探す');
    form.body('>>> §e会社を選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    companyNames.forEach(name => form.button(`§1${name}`, 'textures/ui/normalicon1'));

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            showAdvanceBuyerMenu(player);
            return;
        }
        const selectedCompany = companyNames[r.selection - 1];
        const allProducts = loadData(KEYS.PRODUCTS);

        const companyProducts = Object.entries(allProducts).filter(([id, product]) => product.companyName === selectedCompany && product.stock > 0);

        if (companyProducts.length === 0) {
            player.sendMessage(`§r[§bAdvance§r] §c${selectedCompany} は現在商品を販売していません。`);
            return;
        }

        showProductListUI(player, companyProducts, `§5${selectedCompany} §0の商品`);
    });
}

// 商品リスト表示UI
function showProductListUI(player, productList, title, search) {
    const form = new ActionFormData();
    form.title(title);
    form.body('>>> §e商品一覧');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    productList.forEach(([id, product]) => {
        form.button(`§1${product.name}\n§0金額:§9${product.price.toLocaleString()} §0在庫:§2${product.stock}`, 'textures/ui/normalicon1');
    });
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0 && !search) {
            searchByCompanyUI(player);
            return;
        } else if (r.selection === 0 && search) {
            searchByKeywordUI(player);
            return;
        }
        const [productId, selectedProduct] = productList[r.selection - 1];
        purchaseQuantityUI(player, productId, selectedProduct, productList, title, search);
    });
}

// 購入個数入力UI
function purchaseQuantityUI(player, productId, product, productList, title, search) {
    const form = new ModalFormData();
    form.title('§1購入個数の入力');
    form.textField(`§a商品名§r: §b${product.name}\n§e価格§r: §b${product.price.toLocaleString()}\n§d在庫§r: §b${product.stock}\n\n>>> §e購入数`, '1');
    form.show(player).then(r => {
        if (r.canceled) {
            showProductListUI(player, productList, title, search);
            return;
        }
        const quantity = parseInt(r.formValues[0], 10);

        if (isNaN(quantity) || quantity <= 0) {
            player.sendMessage('§r[§bAdvance§r] §c正しい個数を入力してください。');
            return;
        }
        // ここでの在庫チェックは一次的なもの
        if (quantity > product.stock) {
            player.sendMessage('§r[§bAdvance§r] §c在庫数をオーバーしています。');
            return;
        }

        const totalPrice = product.price * quantity;
        confirmPurchaseUI(player, productId, product.companyName, product.name, quantity, totalPrice, product, productList, title, search);
    });
}

// 購入確認UI
function confirmPurchaseUI(player, productId, companyName, productName, quantity, totalPrice, product, productList, title, search) {
    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

    const form = new ActionFormData();
    form.title('§5注文内容の確認');
    form.body(`§l§e注文内容\n\n` + `§r商品名: §a${productName}\n` + `§r個数: §a${quantity}\n` + `§r合計金額: §b${totalPrice.toLocaleString()}\n\n` + `§r販売元: §a${companyName}\n\n` + `§r現在の所持金: §e${score.toLocaleString()}\n` + `${score < totalPrice ? '§c所持金が不足しています' : ''}`);
    form.button('§1注文を確定する', 'textures/ui/normalicon1');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        if (r.selection === 1) {
            purchaseQuantityUI(player, productId, product, productList, title, search);
            return;
        }
        system.run(() => {
            const latestProducts = loadData(KEYS.PRODUCTS);
            const latestCompanies = loadData(KEYS.COMPANIES);
            const latestProduct = latestProducts[productId];
            const currentScore = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity) ?? 0;

            // 1. 商品が存在し、会社も存在するか
            if (!latestProduct || !latestCompanies[companyName]) {
                player.sendMessage('§r[§bAdvance§r] §cエラー: 商品または会社情報が見つかりません。');
                return;
            }
            // 2. 所持金は足りているか
            if (currentScore < totalPrice) {
                player.sendMessage('§r[§bAdvance§r] §c所持金が不足しています。');
                return;
            }
            // 3. 在庫は足りているか
            if (latestProduct.stock < quantity) {
                player.sendMessage('§r[§bAdvance§r] §c申し訳ありません。他の方が先に購入したため在庫が不足しています。');
                return;
            }

            // --- 全ての検証をクリアした場合のみ、処理を実行 ---
            // 在庫を減らす
            latestProducts[productId].stock -= quantity;
            // 会社資産を増やす
            latestCompanies[companyName].assets += totalPrice;
            // 注文履歴を作成
            const orders = loadAllOrders();
            const orderId = generateId();
            orders[orderId] = {
                productId: productId,
                productName: productName,
                companyName: companyName,
                buyerName: player.name,
                quantity: quantity,
                totalPrice: totalPrice,
                status: 'delivering',
            };

            // データを保存
            saveData(KEYS.PRODUCTS, latestProducts);
            saveData(KEYS.COMPANIES, latestCompanies);
            saveAllOrders(orders);

            // プレイヤーの所持金を減らす
            player.runCommand(`scoreboard players remove @s money ${totalPrice}`);

            player.sendMessage('§r[§bAdvance§r] §a商品を注文しました。');

            // オーナーへの通知処理
            const companyOwnerName = latestCompanies[companyName]?.owner;
            if (companyOwnerName) {
                const notificationMessage = `§r[§bAdvance§r] §b${productName}§r(${quantity}個):§e${companyName}§rが§a${player.name}§rによって注文されました`;

                // サーバー内の全プレイヤーからオーナーを探す
                const ownerPlayer = world.getAllPlayers().find(p => p.name === companyOwnerName);

                if (ownerPlayer) {
                    // オーナーがオンラインの場合
                    ownerPlayer.sendMessage(notificationMessage);
                } else {
                    // オーナーがオフラインの場合
                    const pendingNotifications = loadData(KEYS.PENDING_NOTIFICATIONS, {});
                    if (!pendingNotifications[companyOwnerName]) {
                        pendingNotifications[companyOwnerName] = [];
                    }
                    pendingNotifications[companyOwnerName].push(notificationMessage);
                    saveData(KEYS.PENDING_NOTIFICATIONS, pendingNotifications);
                }
            }
            // ★変更点: ここまで追加
        });
    });
}

// 配送状況確認UI
function showDeliveryStatusUI(player) {
    const allOrders = loadAllOrders();
    const myOrders = Object.entries(allOrders).filter(([id, order]) => order.buyerName === player.name);

    if (myOrders.length === 0) {
        player.sendMessage('§r[§bAdvance§r] §c注文履歴がありません。');
        return;
    }

    // 新しい順にソート
    myOrders.sort(([idA], [idB]) => parseInt(idB, 36) - parseInt(idA, 36));

    let body = '§l注文履歴\n\n§r';
    myOrders.forEach(([id, order]) => {
        const statusText = order.status === 'completed' ? '§a配送完了' : '§9配送中';
        body += `商品名: §b${order.productName}§r\n個数: §a${order.quantity} §r| ${statusText}§r\n- - - - -\n`;
    });

    const form = new ActionFormData();
    form.title('§0配送状況');
    form.body(body);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4完了済み履歴をクリア', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            showAdvanceBuyerMenu(player);
            return;
        }
        if (r.selection === 1) {
            // 完了済み履歴をクリアする処理
            let orders = loadAllOrders();
            let clearedCount = 0;
            for (const id in orders) {
                const order = orders[id];
                if (order.buyerName === player.name && order.status === 'completed') {
                    delete orders[id];
                    clearedCount++;
                }
            }

            if (clearedCount > 0) {
                saveAllOrders(orders);
                player.sendMessage(`§r[§bAdvance§r] §a完了済みの注文履歴を${clearedCount}件削除しました。`);
            } else {
                player.sendMessage('§r[§bAdvance§r] §c削除できる完了済みの履歴がありません。');
            }
        }
    });
}
