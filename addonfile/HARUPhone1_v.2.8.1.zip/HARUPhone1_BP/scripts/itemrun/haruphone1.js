import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

import { config } from '../config';

import { chatLoop4 } from '../HaruAssistant/Insight-4/assistantMain';
import { chatLoop3 } from '../HaruAssistant/Insight-3/assistantMain';

//Advance
import { showAdvanceBuyerMenu } from './advance';

import { App } from '../App/AppMenu';
import { Operator_Controller } from '../system/Operator_Controller';

//HARUPAY
import { HARUPAY } from '../system/harupay';
//社会システム
import { showMainUI } from '../system/country';
//マップ
import { openUserNavigationForm } from '../system/Map';
//ブラウザ
import { Browser, loadSplitProperty, saveSplitProperty } from '../system/browser';
//換金
import { showExchangeItems } from '../system/exchange';
//購入
import { showPurchaseItems } from '../system/purchase';
//Quick
import { Quick } from '../system/quick';
//請求
import { ClaimUI } from '../system/claim';
//メール
import { Mail } from '../system/mail';
//仕事依頼
import { Work } from '../system/work';
//オープンチャット
import { OpenChat } from '../system/openchat';

//一時データ
export var player_Cash_Data = {};
//請求データ
export var Claim = {};
//仕事募集データ
export var quest = [[], []];

//Quick関連
// 初期化時に保存済みデータを読み込む
export function loadShopMenu() {
    const savedData = world.getDynamicProperty('shop_menu');
    if (savedData) {
        return JSON.parse(savedData);
    }
    return [[], []]; // デフォルト値（初回起動時用）
}

// データを保存する関数
export function saveShopMenu(shopMenu) {
    world.setDynamicProperty('shop_menu', JSON.stringify(shopMenu));
}
//logデータ
export var logs = {};
logs['harupay'] = [];
logs['quick'] = [];
logs['quest'] = [];

export function HARUPhone1(player) {
    system.run(() => {
        //実行アイテム=additem:haruphone1
        if (player.hasTag('HARUPhoneOP') && world.getDynamicProperty('op_fast') === undefined) {
            var form = new ModalFormData();
            form.title(`${config['main'][0]}`);
            form.textField('§e§o初期配布金額\n§5>>>§c後から変更可能ですが、経済バランスに影響する可能性があります。\n\n§r-§a目安§r-\n§r・§bPlayer間の取引を中心に経済を回したい\n§5>>>§a100000 §r~§a 1000000\n§r・§b換金システムを中心に経済を回したい\n§5>>>§a0 §r~§a 100000\n§r・§b迷って決めれない方へ\n§5>>>§a5000 §r~§a 10000', '半角数字');
            form.show(player).then(r => {
                if (r.canceled) {
                    return;
                }
                if (isNaN(r.formValues[0])) {
                    player.sendMessage(`§r[§bシステム§r] §4半角数字で入力してください`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: 0.8,
                    });
                    return;
                }
                if (r.formValues[0] > 100000000) {
                    player.sendMessage(`§r[§bシステム§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: 0.8,
                    });
                    return;
                }
                if (r.formValues[0] < 0) {
                    player.sendMessage(`§r[§bシステム§r] §40以下は設定できません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: 0.8,
                    });
                    return;
                }
                if (r.formValues[0] == '') {
                    player.sendMessage(`§r[§bシステム§r] §e初期設定を完了して下さい`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: 0.8,
                    });
                    return;
                }
                //初期設定実行
                world.setDynamicProperty('start_money', r.formValues[0]);
                world.setDynamicProperty('op_fast', 1);
                world.setDynamicProperty('money_start_system1', 1);
                player.sendMessage(`§r[§bシステム§r] §a初期設定が完了しました`);
                player.playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: 0.8,
                });

                const players = world.getAllPlayers();
                for (const player of players) {
                    if (world.getDynamicProperty('money_start_system1') === 1 && !player.hasTag('HARUPAY_Member')) {
                        if (world.getDynamicProperty('money_start_system2') == 0 || world.getDynamicProperty('money_start_system2') == undefined) {
                            try {
                                // 必要なプロパティをキャッシュ
                                const startMoney = world.getDynamicProperty('start_money') || 0;

                                // ネイティブAPIで処理
                                player.getComponent('inventory').container.addItem(new ItemStack('additem:haruphone1', 1));
                                player.runCommand(`scoreboard players set @s money ${startMoney}`);
                                player.sendMessage(`§r[§bHARUPhone1§r] §aようこそ！§eHARUPhone1を開いてみましょう！`);
                                player.playSound('haru.notification1', {
                                    pitch: 1.7,
                                    volume: 0.8,
                                });
                                player.addTag('HARUPAY_Member');
                            } catch (error) {
                                console.warn(`Failed to process player ${player.name}: ${error}`);
                            }
                        }
                    }
                }

                HARUPhone1(player);
            });
        } else {
            //未設定時の実行ストップ
            if (world.getDynamicProperty('money_start_system1') !== 1) {
                player.sendMessage(`§r[§bHARUPhone1§r] §c初期設定が完了していません`);
                player.sendMessage(`§5>>> §a詳細は配布ページをご確認ください`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: 0.8,
                });
                return;
            }
            //money取得
            const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

            //時刻を取得
            const now = new Date();
            const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
            const hours = String(japanTime.getUTCHours()).padStart(2, '0');
            const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
            var time = `${hours}:${minutes}`;

            //広告取得 (修正必須)
            var performance_system2 = loadSplitProperty('performance');
            const random_performance = Math.floor(Math.random() * performance_system2.length);

            //playerの一時ファイルを作成(リセット)
            player_Cash_Data[player.id] = {};
            const HARUPhone1_Cash_AppNumber = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'));

            //モード
            player_Cash_Data[player.id].HARUPhoneMode = true;

            //HOME画面
            var form = new ActionFormData();
            form.title(`${config['main'][0]}`);
            form.body(`§l§b${time}`);
            for (let i = 0; i < HARUPhone1_Cash_AppNumber.length; i++) {
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '広告') {
                    if (performance_system2[0] == undefined) {
                        form.button(`§l${config['AppName'][0]}\n§r-`, 'textures/ui/browser');
                    } else {
                        form.button(`§l${config['AppName'][0]}§r\n${performance_system2[random_performance][2]}`, 'textures/ui/browser');
                    }
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'アプリケーション') {
                    form.button(`§1${config['AppName'][15]}\n`, 'textures/ui/editor');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'HARUPAY') {
                    form.button(`§9${config['AppName'][1]}\n§0残高:§s${score}`, 'textures/ui/pay');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Quick') {
                    form.button(`§1${config['AppName'][2]}`, 'textures/ui/quick');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'メール') {
                    form.button(`§3${config['AppName'][3]}`, 'textures/ui/mail');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'オープンチャット') {
                    form.button(`§5${config['AppName'][4]}`, 'textures/ui/openchat');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '仕事依頼・探す') {
                    form.button(`§2${config['AppName'][5]}`, 'textures/ui/work');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Advance') {
                    form.button(`§0${config['AppName'][6]}`, 'textures/ui/advance');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '換金') {
                    form.button(`§5${config['AppName'][7]}`, 'textures/ui/redeem');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '購入') {
                    form.button(`§9${config['AppName'][8]}`, 'textures/ui/purchase');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '情報') {
                    form.button(`§0${config['AppName'][9]}`, 'textures/ui/haruaddons');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'ブラウザ') {
                    form.button(`§2${config['AppName'][10]}`, 'textures/ui/browser');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '社会システム') {
                    form.button(`§9${config['AppName'][11]}`, 'textures/ui/country');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == '請求') {
                    form.button(`§s${config['AppName'][12]}`, 'textures/ui/claim');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'HARUAssistant') {
                    form.button(`§1${config['AppName'][14]}`, 'textures/ui/haruapp');
                }
                if (config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Map') {
                    form.button(`§5${config['AppName'][17]}`, 'textures/ui/map');
                }
                if ((config['AppData'][HARUPhone1_Cash_AppNumber[i]] == 'Operator Controller') & player.hasTag('HARUPhoneOP')) {
                    form.button(`§1${config['AppName'][13]}`, 'textures/ui/operatorcontroller');
                }
            }
            form.show(player).then(r => {
                if (r.canceled) return;
                let response = config['AppData'][HARUPhone1_Cash_AppNumber[r.selection]];
                switch (response) {
                    case '広告':
                        if (performance_system2[0] == undefined) {
                            player.sendMessage(`§r[§bbrowser§r] §a広告データが見つかりません`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: 0.8,
                            });
                            return;
                        }

                        // 広告クリック時に閲覧数をカウントアップ
                        const clickedAd = performance_system2[random_performance];
                        let browser_system = loadSplitProperty('browser');
                        const pageIndex = browser_system.findIndex(
                            page =>
                                page[0] === clickedAd[0] && // 投稿者名
                                page[2] === clickedAd[2] && // 検索表示タイトル
                                page[3] === clickedAd[3] // ページタイトル
                        );

                        if (pageIndex !== -1) {
                            browser_system[pageIndex][1]++; // 閲覧数をインクリメント
                            saveSplitProperty('browser', browser_system);
                        }

                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§l${performance_system2[random_performance][3]}`);
                        form.divider();
                        form.label(`投稿者:§a${performance_system2[random_performance][0]}`);
                        form.divider();
                        form.label(`${performance_system2[random_performance][4]}\n\n${performance_system2[random_performance][5]}\n\n${performance_system2[random_performance][6]}\n\n${performance_system2[random_performance][7]}`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            HARUPhone1(player);
                        });
                        break;
                    case 'アプリケーション':
                        App(player);
                        break;
                    case 'HARUPAY':
                        HARUPAY(player);
                        break;
                    case 'Quick':
                        Quick(player);
                        break;
                    case 'メール':
                        Mail(player);
                        break;
                    case 'オープンチャット':
                        OpenChat(player);
                        break;
                    case '仕事依頼・探す':
                        Work(player);
                        break;
                    case 'Advance':
                        showAdvanceBuyerMenu(player);
                        break;
                    case '換金':
                        showExchangeItems(player);
                        break;
                    case '購入':
                        showPurchaseItems(player);
                        break;
                    case '情報':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body('情報サービスを選択');
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§0アドオン情報\n§8Version', 'textures/items/haruphone1');
                        form.button('§1HARUAddons§5公式サイト\n§5<<<§0QRコードからアクセスできます', 'textures/ui/qr.png');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§aアドオン名§r:§bHARUPhone1\n§eVersion§r:§b2.8.0\n§cリリース日§r:§b2025/10/18`);
                                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                //戻る
                                                HARUPhone1(player);
                                                break;
                                        }
                                    });
                                    break;
                                case 2:
                                    var form = new ActionFormData();
                                    form.title(`${config['main'][0]}`);
                                    form.body(`§aHARUAddons§c公式リンク\n§e-------------\n§l§eサイト\n§r§aホームページ§5>>>\n§bhttps://haruaddons.f5.si/\n§r§aX§5>>>\n§bhttps://x.com/haru_addons`);
                                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                                    form.show(player).then(r => {
                                        if (r.canceled) return;
                                        let response = r.selection;
                                        switch (response) {
                                            case 0:
                                                //戻る
                                                HARUPhone1(player);
                                                break;
                                        }
                                    });
                                    break;
                            }
                        });
                        break;
                    case 'ブラウザ':
                        Browser(player);
                        break;
                    case '社会システム':
                        showMainUI(player);
                        break;
                    case '請求':
                        ClaimUI(player);
                        break;
                    case 'HARUAssistant':
                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`§aチャットボットを選択`);
                        form.button(`§l戻る`, 'textures/ui/icon_import.png');
                        form.button('§1Insight-4\n§8最も賢い', 'textures/ui/normalicon1');
                        form.button('§1Insight-3', 'textures/ui/normalicon1');
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    //戻る
                                    HARUPhone1(player);
                                    break;
                                case 1:
                                    chatLoop4(player);
                                    break;
                                case 2:
                                    chatLoop3(player);
                                    break;
                            }
                        });
                        break;
                    case 'Map':
                        openUserNavigationForm(player);
                        break;
                    case 'Operator Controller':
                        Operator_Controller(player);
                        break;
                    default:
                }
            });
        }
    });
}
