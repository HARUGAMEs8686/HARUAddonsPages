import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';
import { player_Cash_Data } from '../itemrun/haruphone1';
import { loadShopMenu } from '../itemrun/haruphone1';
import { saveShopMenu } from '../itemrun/haruphone1';
import { logs } from '../itemrun/haruphone1';

export function Quick(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    // shop_menu をグローバル変数として初期化
    var shop_menu = loadShopMenu();

    // 永続化処理を追加
    player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§b§l${time}\n\n§r§6 >>>§a所持金§r:§s${player_Cash_Data[player.id].money}`);
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button(`§1購入`, 'textures/ui/normalicon1');
    form.button(`§5出品`, 'textures/ui/normalicon1');
    form.button(`§0商品の§4削除`, 'textures/ui/normalicon1');
    form.show(player)
        .then(r => {
            if (r.canceled) return;
            let response = r.selection;
            switch (response) {
                case 0:
                    // 戻る
                    if (player_Cash_Data[player.id].HARUPhoneMode) {
                        HARUPhone1(player);
                    }
                    break;
                case 1:
                    if (shop_menu[0].length == 0) {
                        player.sendMessage(`§r[§bQuick§r] §a商品が見つかりませんでした`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        return;
                    }
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body('>>> §e商品一覧');
                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                    for (let i = 0; i < shop_menu[0].length; i++) {
                        form.button(`§1${shop_menu[0][i][0]}\n§0金額:§s${shop_menu[0][i][2]}§0PAY  §0出品者:§2${shop_menu[0][i][1]}`, 'textures/ui/normalicon1');
                    }
                    form.show(player)
                        .then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (r.selection == 0) {
                                Quick(player);
                                return;
                            }
                            // 選択した商品を保存
                            player_Cash_Data[player.id].select_shop = shop_menu[0][r.selection - 1];
                            // money取得
                            player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

                            var form = new ActionFormData();
                            form.title(`${config['main'][0]}`);
                            form.body(
                                `商品名:§a${player_Cash_Data[player.id].select_shop[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_shop[3]}\n§r金額:§b${player_Cash_Data[player.id].select_shop[2]}  §r出品者:§2${player_Cash_Data[player.id].select_shop[1]}\n\n§e購入後自動的に料金が支払われます\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${
                                    player_Cash_Data[player.id].select_shop[2]
                                }\n§r=§b${player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_shop[2]}\n§1///////////////////`
                            );
                            form.button('§5この商品を買う', 'textures/ui/normalicon1');
                            form.button('§1キャンセル', 'textures/ui/normalicon1');
                            form.show(player)
                                .then(r => {
                                    if (r.canceled) {
                                        return;
                                    }
                                    switch (r.selection) {
                                        case 0:
                                            player_Cash_Data[player.id].shop_stop = false;
                                            // オンラインプレイヤー取得
                                            player_Cash_Data[player.id].players = world.getAllPlayers();
                                            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                                if (player_Cash_Data[player.id].select_shop[4] == player_Cash_Data[player.id].players[i].id) {
                                                    player_Cash_Data[player.id].shop_stop = true;
                                                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                                }
                                            }
                                            if (player_Cash_Data[player.id].shop_stop == false) {
                                                player.sendMessage(`§r[§bQuick§r] §4現在販売者がオフラインの為販売を中止します`);
                                                player.playSound('haru.notification1', {
                                                    pitch: 0.8,
                                                    volume: config['Volume'],
                                                });
                                                return;
                                            }

                                            if (shop_menu[1][0] != undefined) {
                                                for (let i = 0; i < shop_menu[1].length; i++) {
                                                    if (player_Cash_Data[player.id].select_shop[5] == shop_menu[1][i]) {
                                                        player_Cash_Data[player.id].shop_stop = false;
                                                    }
                                                }
                                            }

                                            if (player_Cash_Data[player.id].shop_stop == false) {
                                                player.sendMessage(`§r[§bQuick§r] §4選択した商品は既に販売終了しております`);
                                                player.playSound('haru.notification1', {
                                                    pitch: 0.8,
                                                    volume: config['Volume'],
                                                });
                                                return;
                                            }
                                            // 残高が設定金額以上の場合のみ実行
                                            if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_shop[2]) {
                                                // マネー操作
                                                player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_shop[2]}`);
                                                player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_shop[2]}`);

                                                // メッセージ関連
                                                player.sendMessage(`§r[§bQuick§r] §b${player_Cash_Data[player.id].select_shop[1]}へ${player_Cash_Data[player.id].select_shop[2]}PAY支払いました`);
                                                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §b${player.name}§rが§b${player_Cash_Data[player.id].select_shop[0]}§rを§e注文しました`);
                                                player_Cash_Data[player.id].select_player.sendMessage(`§r[§bQuick§r] §e${player.name}から${player_Cash_Data[player.id].select_shop[2]}PAY受け取りました`);

                                                // 通知音
                                                player.playSound('haru.notification1', {
                                                    pitch: 1.7,
                                                    volume: config['Volume'],
                                                });
                                                player_Cash_Data[player.id].select_player.playSound('haru.notification1', {
                                                    pitch: 1.7,
                                                    volume: config['Volume'],
                                                });

                                                // log関連
                                                logs['quick'].push([time, player.name, player_Cash_Data[player.id].select_shop[1], player_Cash_Data[player.id].select_shop[2]]);

                                                // 商品の削除/販売済み商品に追加
                                                shop_menu[1].push(player_Cash_Data[player.id].select_shop[5]);
                                                for (let i = 0; i < shop_menu[0].length; i++) {
                                                    if (shop_menu[0][i][5] === player_Cash_Data[player.id].select_shop[5]) {
                                                        shop_menu[0].splice(i, 1);
                                                    }
                                                }
                                                saveShopMenu(shop_menu); // 更新後に保存
                                            } else {
                                                player.sendMessage(`§r[§bQuick§r] §cHARUPAY残高が不足しています`);
                                                player.playSound('haru.notification1', {
                                                    pitch: 0.8,
                                                    volume: config['Volume'],
                                                });
                                            }
                                            break;
                                    }
                                })
                                .catch(e => {
                                    console.error(e, e.stack);
                                });
                        })
                        .catch(e => {
                            console.error(e, e.stack);
                        });
                    break;
                case 2:
                    var form = new ModalFormData();
                    form.title(`${config['main'][0]}`);
                    form.textField('§a商品名', '丸石');
                    form.textField('§e詳細', 'エンチャント内容など');
                    form.textField('§c販売額(半角数字)', '0');
                    form.submitButton(`§1出品`);
                    form.show(player)
                        .then(r => {
                            if (r.canceled) {
                                Quick(player);
                                return;
                            }
                            if (isNaN(r.formValues[2])) {
                                player.sendMessage(`§r[§bQuick§r] §4半角数字で入力してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }
                            if (r.formValues[2] > 100000000) {
                                player.sendMessage(`§r[§bQuick§r] §41億以下で設定してください`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }
                            if (r.formValues[2] < 0) {
                                player.sendMessage(`§r[§bQuick§r] §40以下は設定できません`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }
                            if (r.formValues[0] == '') {
                                player.sendMessage(`§r[§bQuick§r] §4商品名が未入力です`);
                                player.playSound('haru.notification1', {
                                    pitch: 0.8,
                                    volume: config['Volume'],
                                });
                                return;
                            }

                            if (r.formValues[2] == '') {
                                var selection_score_quick = 0;
                            } else {
                                var selection_score_quick = Number(r.formValues[2]);
                            }

                            // Code生成
                            let number = '';
                            for (let i = 0; i < 8; i++) {
                                number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                            }
                            shop_menu[0].push([r.formValues[0], player.name, selection_score_quick, r.formValues[1], player.id, number]);

                            // オンラインプレイヤー取得
                            player_Cash_Data[player.id].players = world.getAllPlayers();

                            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                player_Cash_Data[player.id].players[i].sendMessage(`§r[§bQuick§r] §a${r.formValues[0]}§r:§e${selection_score_quick}§rPAYが出品されました`);
                                // 通知サウンド
                                player_Cash_Data[player.id].players[i].playSound('haru.notification1', {
                                    pitch: 1.7,
                                    volume: config['Volume'],
                                });
                            }
                            saveShopMenu(shop_menu); // 出品後に保存
                        })
                        .catch(e => {
                            console.error(e, e.stack);
                        });
                    break;
                case 3:
                    if (shop_menu[0].length == 0) {
                        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        return;
                    }
                    player_Cash_Data[player.id].my_shop = [];
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body('>>> §e削除する商品を選択');
                    form.button(`§l戻る`, 'textures/ui/icon_import.png');
                    for (let i = 0; i < shop_menu[0].length; i++) {
                        if (player.id == shop_menu[0][i][4]) {
                            form.button(`§1${shop_menu[0][i][0]}\n§0金額:§s${shop_menu[0][i][2]}§0PAY  §0出品者:§2${shop_menu[0][i][1]}`, 'textures/ui/normalicon1');
                            player_Cash_Data[player.id].my_shop.push(shop_menu[0][i]);
                        }
                    }
                    if (player_Cash_Data[player.id].my_shop.length == 0) {
                        // lengthが-1にならないよう修正
                        player.sendMessage(`§r[§bQuick§r] §a削除できる商品が見つかりませんでした`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        return;
                    }
                    form.show(player)
                        .then(r => {
                            if (r.canceled) {
                                return;
                            }
                            if (r.selection == 0) {
                                Quick(player);
                                return;
                            }
                            for (let i = 0; i < shop_menu[0].length; i++) {
                                if (shop_menu[0][i][5] === player_Cash_Data[player.id].my_shop[r.selection - 1][5]) {
                                    shop_menu[0].splice(i, 1);
                                }
                            }
                            player.sendMessage(`§r[§bQuick§r] §a削除しました`);
                            player.playSound('haru.notification1', {
                                pitch: 1.7,
                                volume: config['Volume'],
                            });
                            saveShopMenu(shop_menu); // 削除後に保存
                            return;
                        })
                        .catch(e => {
                            console.error(e, e.stack);
                        });
                    break;
            }
        })
        .catch(e => {
            console.error(e, e.stack);
        });
}
