import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

export function OpenChat(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    //オープンチャット送信画面
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField(`§l§b${time}§r\n\nチャット`, 'メッセージ');
    form.toggle(`§a座標共有 §r(false/true)`, {
        defaultValue: false,
    });
    form.submitButton(`§5送信`);
    form.show(player)
        .then(r => {
            if (r.canceled) return;

            if (r.formValues[0] == '' && r.formValues[1] == false) {
                player.sendMessage(`§r[§bオープンチャット§r] §4メッセージ未入力です`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
                return;
            }
            //オンラインプレイヤー取得
            player_Cash_Data[player.id].players = world.getAllPlayers();
            //現在地を取得
            player_Cash_Data[player.id].player_location = player.location;

            for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                if (r.formValues[0] !== '') {
                    player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §a${player.name}§b:§r${r.formValues[0]}`);
                }
                if (r.formValues[1] == true) {
                    player_Cash_Data[player.id].players[i].sendMessage(`§r[§bチャット§r] §c座標§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                }

                //通知サウンド
                player_Cash_Data[player.id].players[i].playSound('haru.notification1', {
                    pitch: 1.7,
                    volume: config['Volume'],
                });
            }
        })
        .catch(e => {
            console.error(e, e.stack);
        });
}
