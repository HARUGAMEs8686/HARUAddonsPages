import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

export function Mail(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    //オンラインプレイヤー取得
    player_Cash_Data[player.id].players = world.getAllPlayers();

    //送信先プレイヤー選択画面
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}§r\n\n§r >>> §e送信先プレイヤーを選択`);
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
        form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        //戻る
        if (r.selection == 0) {
            //戻る
            if (player_Cash_Data[player.id].HARUPhoneMode) {
                HARUPhone1(player);
            }
            return;
        }

        //↓プレイヤー選択
        if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
            player.sendMessage(`§r[§bメール§r] §c自分は選択できません`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            Mail(player);
            return;
        }
        //選択したプレイヤーを保存
        player_Cash_Data[player.id].player_select = player_Cash_Data[player.id].players[r.selection - 1];
        //メッセージ入力画面
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField(`§l§b${time}§r\n\n§6>>>§r送信先:§a${player_Cash_Data[player.id].player_select.name}`, 'メッセージ入力');
        form.toggle(`§a座標共有 §r(false/true)`, {
            defaultValue: false,
        });
        form.submitButton(`§5送信`);
        form.show(player).then(r => {
            if (r.canceled) {
                return;
            }
            if (r.formValues[0] == '' && r.formValues[1] == false) {
                player.sendMessage(`§r[§bメール§r] §4メッセージ未入力です`);
                player.playSound('haru.notification1', {
                    pitch: 0.8,
                    volume: config['Volume'],
                });
                return;
            }
            //現在地を取得
            player_Cash_Data[player.id].player_location = player.location;
            //メッセージ送信
            if (r.formValues[0] !== '') {
                player.sendMessage(`§r[§bメール§r] §a${player_Cash_Data[player.id].player_select.name}§rへ送信§6>>>§r${r.formValues[0]}`);
                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §a${player.name}§rから受信§6>>>§r${r.formValues[0]}`);
            }
            if (r.formValues[1] == true) {
                player.sendMessage(`§r[§bメール§r] §c座標送信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
                player_Cash_Data[player.id].player_select.sendMessage(`§r[§bメール§r] §c座標受信§r(${player.name})§r:§b${Math.round(player_Cash_Data[player.id].player_location.x)},${Math.round(player_Cash_Data[player.id].player_location.y)},${Math.round(player_Cash_Data[player.id].player_location.z)}`);
            }
            //通知サウンド
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            player_Cash_Data[player.id].player_select.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
        });
    });
}
