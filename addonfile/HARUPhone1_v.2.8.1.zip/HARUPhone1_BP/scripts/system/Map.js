import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';
import { Operator_Controller } from './Operator_Controller';
import { player_Cash_Data } from '../itemrun/haruphone1';

let waypoints = JSON.parse(world.getDynamicProperty('waypoints') || '[]');
let activeNavigations = new Map();

// 管理者用フォーム（座標登録、編集、削除）
export function openNavigationForm(player) {
    if (!player.hasTag('HARUPhoneOP')) {
        player.sendMessage('§r[§bマップ§r] §c権限がありません');
        return;
    }

    const form = new ActionFormData().title('§1HARUPhone1').body('§5>§aMap§5>§aカスタマイズ').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1座標を登録', 'textures/ui/normalicon1').button('§5座標を編集', 'textures/ui/normalicon1').button('§4座標を削除', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            Operator_Controller(player);
        } else if (response.selection === 1) {
            showRegisterForm(player);
        } else if (response.selection === 2) {
            showEditForm(player);
        } else if (response.selection === 3) {
            showDeleteForm(player);
        }
    });
}

// 非管理者用フォーム（ジャンル選択または座標一覧、案内停止）
export function openUserNavigationForm(player) {
    const form = new ActionFormData().title('§1HARUPhone1').body('§cナビゲーションシステム');
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1ナビゲーション', 'textures/ui/normalicon1');

    if (activeNavigations.has(player.id)) {
        form.button('§5案内を停止', 'textures/ui/normalicon1');
    }

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            if (player_Cash_Data[player.id].HARUPhoneMode) {
                HARUPhone1(player);
            }
        } else if (response.selection === 1) {
            const genres = [...new Set(waypoints.map(wp => wp.genre || 'その他'))];
            if (genres.length === 1 && genres[0] === 'その他') {
                showWaypointList(player, 'その他');
            } else {
                showGenreList(player);
            }
        } else if (response.selection === 2 && activeNavigations.has(player.id)) {
            stopNavigation(player);
        }
    });
}

function showGenreList(player) {
    const genres = [...new Set(waypoints.map(wp => wp.genre || 'その他'))];
    if (waypoints.length === 0) {
        player.sendMessage('§r[§bマップ§r] §c登録された座標がありません。');
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const form = new ActionFormData().title('§1HARUPhone1').body('§aジャンルを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    genres.forEach(genre => {
        form.button(`§5${genre}`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            openUserNavigationForm(player);
            return;
        }
        const selectedGenre = genres[response.selection - 1];
        showWaypointList(player, selectedGenre);
    });
}

function showRegisterForm(player) {
    const form = new ModalFormData()
        .title('§1HARUPhone1')
        .textField('場所の名前', '例: 拠点')
        .textField('ジャンル（任意）', '例: 拠点、資源')
        .textField('X座標', `${Math.floor(player.location.x)}`)
        .textField('Y座標', `${Math.floor(player.location.y)}`)
        .textField('Z座標', `${Math.floor(player.location.z)}`)
        .textField('到着判定距離（ブロック）', '10');

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            openNavigationForm(player);
            return;
        }
        const [name, genre, x, y, z, arrivalDistance] = response.formValues;
        if (!name || isNaN(x) || isNaN(y) || isNaN(z) || isNaN(arrivalDistance) || parseInt(arrivalDistance) < 1) {
            player.sendMessage('§r[§bマップ§r] §c入力が無効です。');
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }
        // 更新前に最新のwaypointsを再取得
        waypoints = JSON.parse(world.getDynamicProperty('waypoints') || '[]');
        waypoints.push({
            name,
            genre: genre || 'その他',
            x: parseInt(x),
            y: parseInt(y),
            z: parseInt(z),
            arrivalDistance: parseInt(arrivalDistance),
        });
        world.setDynamicProperty('waypoints', JSON.stringify(waypoints));
        player.sendMessage(`§r[§bマップ§r] §b${name} (${x}, ${y}, ${z}) §aを登録しました`);
        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
    });
}

function showEditForm(player) {
    if (waypoints.length === 0) {
        player.sendMessage('§r[§bマップ§r] §c編集する座標がありません。');
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const form = new ActionFormData().title('§1HARUPhone1').body('§e編集する座標を選択');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    waypoints.forEach((wp, index) => {
        form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z}) §0[§5${wp.genre || 'その他'}§0]`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection == 0) {
            openNavigationForm(player);
            return;
        }
        const index = response.selection - 1;
        const wp = waypoints[index];

        const editForm = new ModalFormData()
            .title('§1HARUPhone1')
            .textField('場所の名前', wp.name, {
                defaultValue: wp.name,
            })
            .textField('ジャンル（任意）', wp.genre || '例: 拠点、資源', {
                defaultValue: wp.genre,
            })
            .textField('X座標', `${wp.x}`, {
                defaultValue: `${wp.x}`,
            })
            .textField('Y座標', `${wp.y}`, {
                defaultValue: `${wp.y}`,
            })
            .textField('Z座標', `${wp.z}`, {
                defaultValue: `${wp.z}`,
            })
            .textField('到着判定距離（ブロック）', `${wp.arrivalDistance}`, {
                defaultValue: `${wp.arrivalDistance}`,
            });

        editForm.show(player).then(editResponse => {
            if (editResponse.canceled || !editResponse.formValues) {
                showEditForm(player);
                return;
            }
            const [name, genre, x, y, z, arrivalDistance] = editResponse.formValues;
            if (!name || isNaN(x) || isNaN(y) || isNaN(z) || isNaN(arrivalDistance) || parseInt(arrivalDistance) < 1) {
                player.sendMessage('§r[§bマップ§r] §c入力が無効です。');
                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                return;
            }
            // 更新前に最新のwaypointsを再取得
            waypoints = JSON.parse(world.getDynamicProperty('waypoints') || '[]');
            waypoints[index] = {
                name,
                genre: genre || 'その他',
                x: parseInt(x),
                y: parseInt(y),
                z: parseInt(z),
                arrivalDistance: parseInt(arrivalDistance),
            };
            world.setDynamicProperty('waypoints', JSON.stringify(waypoints));
            player.sendMessage(`§r[§bマップ§r] §b${name} (${x}, ${y}, ${z}) §aを編集しました`);
            player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
        });
    });
}

function showDeleteForm(player) {
    if (waypoints.length === 0) {
        player.sendMessage('§r[§bマップ§r] §c削除する座標がありません。');
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const form = new ActionFormData().title('§1HARUPhone1').body('§c削除する座標を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    waypoints.forEach((wp, index) => {
        form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z}) §0[§5${wp.genre || 'その他'}§0]`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection == 0) {
            openNavigationForm(player);
            return;
        }
        const index = response.selection - 1;
        // 更新前に最新のwaypointsを再取得
        waypoints = JSON.parse(world.getDynamicProperty('waypoints') || '[]');
        const deleted = waypoints.splice(index, 1)[0];
        world.setDynamicProperty('waypoints', JSON.stringify(waypoints));
        player.sendMessage(`§r[§bマップ§r] §b${deleted.name} (${deleted.x}, ${deleted.y}, ${deleted.z}) §aを削除しました`);
        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
    });
}

export function showWaypointList(player, genreFilter = null) {
    const filteredWaypoints = genreFilter === null ? waypoints : waypoints.filter(wp => wp.genre === genreFilter);

    if (filteredWaypoints.length === 0) {
        player.sendMessage(`§r[§bマップ§r] §c${genreFilter || '登録された'}座標がありません。`);
        player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
        return;
    }

    const form = new ActionFormData().title('§1HARUPhone1').body('§a場所を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    filteredWaypoints.forEach(wp => {
        form.button(`§1${wp.name} §4(${wp.x}, ${wp.y}, ${wp.z})`, 'textures/ui/normalicon1');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            openUserNavigationForm(player);
            return;
        }
        const selected = filteredWaypoints[response.selection - 1];
        startNavigation(player, selected);
    });
}

function startNavigation(player, waypoint) {
    if (activeNavigations.has(player.id)) {
        stopNavigation(player);
    }

    player.sendMessage(`§r[§bマップ§r] §b${waypoint.name} §aへナビゲーション開始します`);
    player.playSound('haru.notification1', { pitch: 1.9, volume: config['Volume'] });

    let animationTick = 0;

    const intervalId = system.runInterval(() => {
        if (!player) {
            stopNavigation(player);
            return;
        }

        const playerPos = player.location;
        const dx = waypoint.x - playerPos.x;
        const dz = waypoint.z - playerPos.z;
        const distance = Math.sqrt(dx * dx + dz * dz);

        // 方角の計算
        const yaw = player.getRotation().y;
        const targetAngle = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
        const angleDiff = ((yaw - targetAngle + 180) % 360) - 180;
        const relativeDirection = getRelativeDirection(angleDiff);

        // アクションバーに距離と相対方向を表示（矢印なし）
        player.onScreenDisplay.setActionBar(`§6${waypoint.name} まで: §e${Math.floor(distance)}ブロック §b[${relativeDirection}§b]`);

        // 到着判定
        if (distance < waypoint.arrivalDistance) {
            player.sendMessage(`§r[§bマップ§r] §a${waypoint.name} に到着しました`);
            player.onScreenDisplay.setActionBar('');
            stopNavigation(player);
            return;
        }
    }, 10);

    activeNavigations.set(player.id, intervalId);
}

function stopNavigation(player) {
    const intervalId = activeNavigations.get(player.id);
    if (intervalId) {
        system.clearRun(intervalId);
        activeNavigations.delete(player.id);
        player.sendMessage('§r[§bマップ§r] §cナビゲーションを停止しました。');
        player.onScreenDisplay.setActionBar('');
        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
    }
}

function getRelativeDirection(angleDiff) {
    if (Math.abs(angleDiff) < 45) return '§c前';
    if (angleDiff >= 45 && angleDiff < 135) return '§d左';
    if (angleDiff <= -45 && angleDiff > -135) return '§a右';
    return '§9後';
}
