import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';
import { player_Cash_Data } from '../itemrun/haruphone1';

const CHUNK_SIZE = 50; // 1つのプロパティに保存するデータ数（必要に応じて変更可能）

// 分割されたデータを読み込み＆古いデータからの移行処理
export function loadSplitProperty(baseKey) {
    const oldDataRaw = world.getDynamicProperty(baseKey);
    const chunkCount = world.getDynamicProperty(`${baseKey}_chunk_count`);

    // 新形式のデータがあればそれを読み込む
    if (typeof chunkCount === 'number') {
        let combinedData = [];
        for (let i = 0; i < chunkCount; i++) {
            const chunkRaw = world.getDynamicProperty(`${baseKey}_${i}`);
            if (chunkRaw) {
                combinedData = combinedData.concat(JSON.parse(chunkRaw));
            }
        }
        return combinedData;
    }

    // 旧形式のデータがあれば読み込んで新形式へ移行する
    if (typeof oldDataRaw === 'string') {
        try {
            const data = JSON.parse(oldDataRaw);
            saveSplitProperty(baseKey, data); // 新形式で保存
            world.setDynamicProperty(baseKey, undefined); // 移行が完了したので古いキーを削除
            return data;
        } catch (e) {
            console.warn(`[HARUPhone1] Failed to parse old data for ${baseKey}: ${e}`);
            return [];
        }
    }

    // データが何も存在しない場合は空の配列を返す
    return [];
}

// データを分割して保存する関数
export function saveSplitProperty(baseKey, data) {
    const oldChunkCount = world.getDynamicProperty(`${baseKey}_chunk_count`) || 0;
    const newChunkCount = Math.ceil(data.length / CHUNK_SIZE);

    // 新しいチャンク（分割データ）を保存
    for (let i = 0; i < newChunkCount; i++) {
        const chunk = data.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
        world.setDynamicProperty(`${baseKey}_${i}`, JSON.stringify(chunk));
    }
    world.setDynamicProperty(`${baseKey}_chunk_count`, newChunkCount);

    // データが減った場合に、不要になった古いチャンクを削除
    for (let i = newChunkCount; i < oldChunkCount; i++) {
        world.setDynamicProperty(`${baseKey}_${i}`, undefined);
    }
}

export function Browser(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('サービスを選択');
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1ページ検索', 'textures/ui/normalicon1');
    form.button('§5おすすめページ一覧', 'textures/ui/normalicon1');
    form.button('§9ページ作成§0/§5編集§0/§s広告', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                if (player_Cash_Data[player.id].HARUPhoneMode) {
                    HARUPhone1(player);
                }
                break;
            case 1:
                searchPage(player);
                break;
            case 2:
                recommendPage(player);
                break;
            case 3:
                managePage(player);
                break;
        }
    });
}

function searchPage(player) {
    var browser_system2 = loadSplitProperty('browser');

    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField('キーワードを入力', 'スペースで区切って複数検索できます');
    form.submitButton(`§0検索`);
    form.show(player).then(r => {
        if (r.canceled) {
            Browser(player);
            return;
        }

        const searchKeywords = r.formValues[0]
            .toLowerCase()
            .split(' ')
            .filter(kw => kw);

        // キーワードが入力されなかった場合の処理
        if (searchKeywords.length === 0) {
            player.sendMessage(`§r[§bブラウザ§r] §c検索キーワードを入力してください。`);
            searchPage(player);
            return;
        }

        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body('検索結果');
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        var browser_cashdata1 = [];

        for (let i = 0; i < browser_system2.length; i++) {
            const pageKeywords = browser_system2[i][2]
                .toLowerCase()
                .split(' ')
                .filter(kw => kw);

            const isMatch = searchKeywords.some(searchKw => pageKeywords.some(pageKw => pageKw.includes(searchKw)));

            if (isMatch) {
                form.button(`§l§0${browser_system2[i][2]}\n§r§0投稿者:§5${browser_system2[i][0]}`, 'textures/ui/normalicon1');
                browser_cashdata1.push(i); // 元のデータのインデックスを保存
            }
        }

        if (browser_cashdata1.length === 0) {
            // 配列の長さでヒットしたかを確認する方が安全です
            player.sendMessage(`§r[§bブラウザ§r] §aページが見つかりませんでした`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            searchPage(player);
            return;
        }

        form.show(player).then(res => {
            if (res.canceled) return;
            if (res.selection == 0) {
                searchPage(player);
                return;
            }
            let response = res.selection - 1;
            const originalIndex = browser_cashdata1[response];

            browser_system2[originalIndex][1] = browser_system2[originalIndex][1] + 1;
            saveSplitProperty('browser', browser_system2);

            var viewForm = new ActionFormData();
            viewForm.title(`${config['main'][0]}`);
            viewForm.body(`§l${browser_system2[originalIndex][3]}`);
            viewForm.divider();
            viewForm.label(`投稿者:§a${browser_system2[originalIndex][0]}`);
            viewForm.divider();
            viewForm.label(`${browser_system2[originalIndex][4]}\n\n${browser_system2[originalIndex][5]}\n\n${browser_system2[originalIndex][6]}\n\n${browser_system2[originalIndex][7]}`);
            viewForm.button(`§l戻る`, 'textures/ui/icon_import.png');
            viewForm.show(player).then(() => {
                searchPage(player);
            });
        });
    });
}

function recommendPage(player) {
    var browser_system2 = loadSplitProperty('browser');

    if (browser_system2.length === 0) {
        player.sendMessage(`§r[§bブラウザ§r] §aページがまだありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        Browser(player);
        return;
    }

    const pagesWithIndices = browser_system2.map((page, index) => ({
        data: page,
        originalIndex: index,
    }));

    const sortedByViews = [...pagesWithIndices].sort((a, b) => b.data[1] - a.data[1]);
    const newPages = pagesWithIndices.slice(-5).reverse();
    const popularPages = sortedByViews.slice(0, 8); // 人気ページを5件取得
    const finalDisplayList = [];
    const addedIndices = new Set(); // 表示済みのページのindexを記録

    // 人気ページを追加
    popularPages.forEach(page => {
        finalDisplayList.push(page);
        addedIndices.add(page.originalIndex);
    });

    const uniqueNewPages = [];
    newPages.forEach(page => {
        if (!addedIndices.has(page.originalIndex)) {
            uniqueNewPages.push(page);
        }
    });

    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('§6人気のおすすめページ');
    form.divider();
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    popularPages.forEach(page => {
        form.button(`§l§0${page.data[2]}\n§r§0投稿者:§5${page.data[0]}`, 'textures/ui/normalicon1');
    });

    if (uniqueNewPages.length > 0) {
        form.label('§b新着ページ');
        form.divider();
        uniqueNewPages.forEach(page => {
            form.button(`§l§0${page.data[2]}\n§r§0投稿者:§5${page.data[0]}`, 'textures/ui/normalicon1');
        });
    }

    const combinedListForSelection = [...popularPages, ...uniqueNewPages];

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            Browser(player);
            return;
        }

        const selectedItem = combinedListForSelection[r.selection - 1];
        if (!selectedItem) return;

        const originalIndex = selectedItem.originalIndex;

        browser_system2[originalIndex][1]++;
        saveSplitProperty('browser', browser_system2);

        var viewForm = new ActionFormData();
        viewForm.title(`${config['main'][0]}`);
        viewForm.body(`§l${browser_system2[originalIndex][3]}`);
        viewForm.divider();
        viewForm.label(`投稿者:§a${browser_system2[originalIndex][0]}`);
        viewForm.divider();
        viewForm.label(`${browser_system2[originalIndex][4]}\n\n${browser_system2[originalIndex][5]}\n\n${browser_system2[originalIndex][6]}\n\n${browser_system2[originalIndex][7]}`);
        viewForm.button(`§l戻る`, 'textures/ui/icon_import.png');
        viewForm.show(player).then(() => {
            recommendPage(player);
        });
    });
}

function createPage(player) {
    if (world.getDynamicProperty('browser_newpage_money') == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        Browser(player);
        return;
    }
    var form = new ModalFormData();
    form.title(`${config['main'][0]}`);
    form.textField('検索表示タイトル', 'ここは検索されやすいワード推奨');
    form.textField('ページタイトル', 'ここは太字になります');
    form.textField('文章1', 'タイトルの下に追加されます');
    form.textField('文章2', '文章1の下に追加されます');
    form.textField('文章3', '文章2の下に追加されます');
    form.textField('文章4', '文章3の下に追加されます');
    form.show(player).then(r => {
        if (r.canceled) {
            managePage(player);
            return;
        }
        const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
        if (score >= world.getDynamicProperty('browser_newpage_money')) {
            var browser_system2 = loadSplitProperty('browser');

            browser_system2.push([player.name, 0, r.formValues[0], r.formValues[1], r.formValues[2], r.formValues[3], r.formValues[4], r.formValues[5]]);
            saveSplitProperty('browser', browser_system2);

            player.runCommand(`tellraw @s {"rawtext":[{"text":"§r[§a通知§7(browser)§r §e${world.getDynamicProperty('browser_newpage_money')}PAY支払いました"}]}`);
            player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_newpage_money')}`);
            player.sendMessage(`§r[§bブラウザ§r] §a新規作成しました`);
            let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
            if (settings.browser) {
                world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_newpage_money')));
            }
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            managePage(player);
        } else {
            player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
            player.playSound('haru.notification1', {
                pitch: 0.8,
                volume: config['Volume'],
            });
            managePage(player);
        }
    });
}

function editPage(player) {
    var browser_system2 = loadSplitProperty('browser');
    var browser_cash = [];

    for (let i = 0; i < browser_system2.length; i++) {
        if (browser_system2[i][0] == player.name) {
            browser_cash.push([[i], browser_system2[i]]);
        }
    }
    if (browser_cash[0] == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §a編集できるページがありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        managePage(player);
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('編集するページを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_cash.length; i++) {
        form.button(`§0§l${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            managePage(player);
            return;
        }
        player_Cash_Data[player.id].browser_select = r.selection - 1;
        var form = new ModalFormData();
        form.title(`${config['main'][0]}`);
        form.textField('検索表示タイトル', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][2]}`,
        });
        form.textField('ページタイトル', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][3]}`,
        });
        form.textField('文章1', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][4]}`,
        });
        form.textField('文章2', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][5]}`,
        });
        form.textField('文章3', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][6]}`,
        });
        form.textField('文章4', '', {
            defaultValue: `${browser_cash[player_Cash_Data[player.id].browser_select][1][7]}`,
        });
        form.show(player).then(r => {
            if (r.canceled) {
                managePage(player);
                return;
            }
            if (r.formValues[0] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][2] = r.formValues[0];
            }
            if (r.formValues[1] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][3] = r.formValues[1];
            }
            if (r.formValues[2] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][4] = r.formValues[2];
            }
            if (r.formValues[3] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][5] = r.formValues[3];
            }
            if (r.formValues[4] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][6] = r.formValues[4];
            }
            if (r.formValues[5] != '') {
                browser_cash[player_Cash_Data[player.id].browser_select][1][7] = r.formValues[5];
            }
            browser_system2[browser_cash[player_Cash_Data[player.id].browser_select][0][0]] = browser_cash[player_Cash_Data[player.id].browser_select][1];
            saveSplitProperty('browser', browser_system2);

            player.sendMessage(`§r[§bブラウザ§r] §aページを編集しました`);
            player.playSound('haru.notification1', {
                pitch: 1.7,
                volume: config['Volume'],
            });
            managePage(player);
        });
    });
}

function deletePage(player) {
    var browser_system2 = loadSplitProperty('browser');
    var browser_cash = [];

    for (let i = 0; i < browser_system2.length; i++) {
        if (browser_system2[i][0] == player.name) {
            browser_cash.push([[i], browser_system2[i]]);
        }
    }
    if (browser_cash[0] == undefined) {
        player.sendMessage(`§r[§bブラウザ§r] §a削除できるページがありません`);
        player.playSound('haru.notification1', {
            pitch: 0.8,
            volume: config['Volume'],
        });
        managePage(player);
        return;
    }
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('削除するページを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (let i = 0; i < browser_cash.length; i++) {
        form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection == 0) {
            managePage(player);
            return;
        }
        let response = r.selection - 1;
        browser_system2.splice(browser_cash[response][0][0], 1);
        saveSplitProperty('browser', browser_system2);

        player.sendMessage(`§r[§bブラウザ§r] §aページを削除しました`);
        player.playSound('haru.notification1', {
            pitch: 1.7,
            volume: config['Volume'],
        });
        managePage(player);
    });
}

function Ad(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('サービスを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§1広告化 \n§5ページ広告化費用§r:§s${world.getDynamicProperty('browser_performance_money')}§rPAY`, 'textures/ui/normalicon1');
    form.button('§4広告削除', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                managePage(player);
                break;
            case 1:
                if (world.getDynamicProperty('browser_performance_money') == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §4管理者が初期設定を完了していない為新規作成出来ません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    Ad(player);
                    return;
                }
                var browser_system2 = loadSplitProperty('browser');
                var browser_cash = [];

                for (let i = 0; i < browser_system2.length; i++) {
                    if (browser_system2[i][0] == player.name) {
                        browser_cash.push([[i], browser_system2[i]]);
                    }
                }
                if (browser_cash[0] == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §a広告化できるページがありません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    Ad(player);
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e広告化するページを選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < browser_cash.length; i++) {
                    form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Ad(player);
                        return;
                    }
                    let response = r.selection - 1;
                    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                    if (score >= world.getDynamicProperty('browser_performance_money')) {
                        var performance_system2 = loadSplitProperty('performance');
                        var performance_cash_system2 = 0;

                        for (let i = 0; i < performance_system2.length; i++) {
                            if (performance_system2[i][2] == browser_cash[response][1][2] && performance_system2[i][0] == browser_cash[response][1][0] && performance_system2[i][3] == browser_cash[response][1][3] && performance_system2[i][4] == browser_cash[response][1][4] && performance_system2[i][5] == browser_cash[response][1][5]) {
                                performance_cash_system2 = 1;
                            }
                        }
                        if (performance_cash_system2 == 1) {
                            player.sendMessage(`§r[§bブラウザ§r] §4選択したページは既に広告化済みです`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            Ad(player);
                            return;
                        }
                        performance_system2.push(browser_cash[response][1]);
                        saveSplitProperty('performance', performance_system2);

                        player.sendMessage(`§r[§bブラウザ§r] §e${world.getDynamicProperty('browser_performance_money')}PAY支払いました`);
                        player.runCommand(`scoreboard players remove @s money ${world.getDynamicProperty('browser_performance_money')}`);
                        player.sendMessage(`§r[§bブラウザ§r] §aページを広告化しました`);
                        let settings = JSON.parse(world.getDynamicProperty('harupay_op_settings') || '{}');
                        if (settings.browser) {
                            world.setDynamicProperty('harupay_op_money', world.getDynamicProperty('harupay_op_money') + Number(world.getDynamicProperty('browser_performance_money')));
                        }
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        Ad(player);
                    } else {
                        player.sendMessage(`§r[§bブラウザ§r] §4Moneyが足りません`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        Ad(player);
                    }
                });
                break;
            case 2:
                var browser_system2 = loadSplitProperty('performance');
                var browser_cash = [];

                for (let i = 0; i < browser_system2.length; i++) {
                    if (browser_system2[i][0] == player.name) {
                        browser_cash.push([[i], browser_system2[i]]);
                    }
                }
                if (browser_cash[0] == undefined) {
                    player.sendMessage(`§r[§bブラウザ§r] §a削除できる広告がありません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    Ad(player);
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e削除する広告を選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < browser_cash.length; i++) {
                    form.button(`§l§0${browser_cash[i][1][2]}\n§r§1${browser_cash[i][1][3]}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        Ad(player);
                        return;
                    }
                    let response = r.selection - 1;
                    browser_system2.splice(browser_cash[response][0][0], 1);
                    saveSplitProperty('performance', browser_system2);

                    player.sendMessage(`§r[§bブラウザ§r] §a広告を削除しました`);
                    player.playSound('haru.notification1', {
                        pitch: 1.7,
                        volume: config['Volume'],
                    });
                    Ad(player);
                });
                break;
        }
    });
}

function managePage(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('機能を選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§1新規作成 \n§5ページ投稿費用§r:§s${world.getDynamicProperty('browser_newpage_money')}`, 'textures/ui/normalicon1');
    form.button('§1既存のページ編集', 'textures/ui/normalicon1');
    form.button('§4ページの削除', 'textures/ui/normalicon1');
    form.button(`§s広告\n§r§8こちらで作成したページを広告化できます`, 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Browser(player);
                break;
            case 1:
                createPage(player);
                break;
            case 2:
                editPage(player);
                break;
            case 3:
                deletePage(player);
                break;
            case 4:
                Ad(player);
                break;
        }
    });
}
