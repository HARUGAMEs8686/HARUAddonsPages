import { world, system, ItemStack } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

export async function showPurchaseItems(player) {
    try {
        // 購入情報の取得
        const kounyuu_list = world.getDynamicProperty('kounyuu_list');
        let kounyuu_list_system2 = kounyuu_list ? JSON.parse(kounyuu_list) : [];

        // ジャンル情報の取得
        const kounyuu_genres = world.getDynamicProperty('kounyuu_genres');
        let genres = kounyuu_genres ? JSON.parse(kounyuu_genres) : ['一般'];

        // 既存データにジャンルがない場合、デフォルトジャンルを付与
        kounyuu_list_system2 = kounyuu_list_system2.map(item => {
            if (!item[4]) item[4] = '一般';
            return item;
        });
        world.setDynamicProperty('kounyuu_list', JSON.stringify(kounyuu_list_system2));

        // 表示するジャンルをフィルタリング
        const displayGenres = genres.filter(genre => {
            if (genre === '一般') {
                return kounyuu_list_system2.some(item => item[4] === '一般');
            }
            return true;
        });

        if (!displayGenres.length) {
            player.sendMessage(`§r[§b購入§r] §aジャンルが見つかりません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // --- ジャンル選択フォーム ---
        const genreForm = new ActionFormData();
        genreForm.title(`${config['main'][0]}`);
        genreForm.body('§5>>>§aジャンルを選択');
        if (player_Cash_Data[player.id].HARUPhoneMode) {
            genreForm.button(`§l戻る`, 'textures/ui/icon_import.png');
        } else {
            genreForm.button(`§0閉じる`, 'textures/ui/icon_import.png');
        }
        displayGenres.forEach(genre => {
            genreForm.button(`§1${genre}`, 'textures/ui/normalicon1');
        });

        const genreResponse = await genreForm.show(player);
        if (genreResponse.canceled) return;
        if (genreResponse.selection === 0) {
            if (player_Cash_Data[player.id].HARUPhoneMode) {
                HARUPhone1(player);
            }
            return;
        }

        const selectedGenre = displayGenres[genreResponse.selection - 1];
        const genreItems = kounyuu_list_system2.filter(item => item[4] === selectedGenre);

        if (!genreItems.length) {
            player.sendMessage(`§r[§b購入§r] §a${selectedGenre}にアイテムが見つかりません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // --- アイテム選択フォーム ---
        const itemForm = new ActionFormData();
        itemForm.title(`${config['main'][0]}`);
        itemForm.body(`§5>>>§a${selectedGenre}の購入アイテムを選択`);
        itemForm.button(`§l戻る`, 'textures/ui/icon_import.png');
        genreItems.forEach(item => {
            const icon = item[3] && item[3] !== 'delete' ? `textures/${item[3]}` : 'textures/ui/normalicon1';
            itemForm.button(`§1${item[0]} §51個§0/§s${item[1]}§r`, icon);
        });

        const itemResponse = await itemForm.show(player);
        if (itemResponse.canceled) return;
        if (itemResponse.selection === 0) {
            showPurchaseItems(player);
            return;
        }

        const selectedItemObject = genreItems[itemResponse.selection - 1];
        const globalIndex = kounyuu_list_system2.indexOf(selectedItemObject);
        if (globalIndex === -1) {
            player.sendMessage('§r[§b購入§r] §cエラー: アイテムの選択を正しく処理できませんでした。');
            return;
        }
        player_Cash_Data[player.id].select_item = globalIndex;

        // --- 購入数入力フォーム ---
        const amountForm = new ModalFormData();
        const selectedItemInfo = kounyuu_list_system2[globalIndex];
        amountForm.title(`${config['main'][0]}`);
        amountForm.textField(`§eアイテム§5>>>§c${selectedItemInfo[0]}\n\n§a購入数§s(半角数字)`, '0');

        const amountResponse = await amountForm.show(player);
        if (amountResponse.canceled) return;

        const amount = parseInt(amountResponse.formValues[0]);
        if (isNaN(amount) || amountResponse.formValues[0] === '') {
            player.sendMessage(`§r[§b購入§r] §4半角数字で入力してください`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }
        if (amount <= 0) {
            player.sendMessage(`§r[§b購入§r] §40以下は設定できません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        // --- 確認フォーム ---
        const price = selectedItemInfo[1];
        const totalCost = price * amount;

        const confirmForm = new MessageFormData();
        confirmForm.title(`${config['main'][0]}`);
        confirmForm.body(`§eアイテム§5>>>§c ${selectedItemInfo[0]}\n` + `§a購入数§5>>>§e ${amount}個\n\n` + `§c支払い額§5>>>§6 ${totalCost}PAY\n\n` + `§r上記の内容で購入しますか？`);
        confirmForm.button2('§0いいえ');
        confirmForm.button1('§1はい');

        const confirmResponse = await confirmForm.show(player);

        if (confirmResponse.canceled || confirmResponse.selection === 1) {
            showPurchaseItems(player); // キャンセルされたら最初から
            return;
        }

        // --- 「はい」が押された場合のみ、以下の購入処理を実行 ---
        const objective = world.scoreboard.getObjective('money');
        if (!objective) {
            console.warn("[購入システム] スコアボード 'money' が存在しません。");
            player.sendMessage('§r[§b購入§r] §cエラー: 購入システムの準備ができていません。');
            return;
        }

        const score = objective.getScore(player.scoreboardIdentity) ?? 0;

        if (score < totalCost) {
            player.sendMessage(`§r[§b購入§r] §4PAYが足りません`);
            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
            return;
        }

        const inventory = player.getComponent('minecraft:inventory').container;
        const itemId = selectedItemInfo[2];
        const tempItemStack = new ItemStack(itemId, 1); // アイテムの最大スタック数を取得するために一時的に作成
        const maxStackSize = tempItemStack.maxAmount;

        let remainingAmount = amount;

        for (let i = 0; i < inventory.size && remainingAmount > 0; i++) {
            const currentItem = inventory.getItem(i);
            if (currentItem && currentItem.typeId === itemId && currentItem.amount < maxStackSize) {
                const spaceInStack = maxStackSize - currentItem.amount;
                const amountToAdd = Math.min(remainingAmount, spaceInStack);
                remainingAmount -= amountToAdd;
            }
        }

        if (remainingAmount > 0) {
            const requiredSlots = Math.ceil(remainingAmount / maxStackSize);
            if (inventory.emptySlotsCount < requiredSlots) {
                player.sendMessage(`§r[§b購入§r] §4インベントリの空きが足りません。`);
                player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                return;
            }
        }

        objective.addScore(player.scoreboardIdentity, -totalCost);

        while (remainingAmount > 0) {
            const amountToGive = Math.min(remainingAmount, maxStackSize);
            const itemStack = new ItemStack(itemId, amountToGive);
            inventory.addItem(itemStack);
            remainingAmount -= amountToGive;
        }

        player.sendMessage(`§r[§b購入§r] §e${selectedItemInfo[0]}を${amount}個 購入しました`);
        player.sendMessage(`§r[§b購入§r] §e${totalCost}PAY支払いました`);
        player.playSound('haru.notification1', { pitch: 1.7, volume: config['Volume'] });
    } catch (e) {
        console.error(`[購入システム] エラーが発生しました: ${e}, スタック: ${e.stack}`);
        player.sendMessage(`§r[§b購入§r] §4エラーが発生しました。`);
    }
}
