import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

import { Claim } from '../itemrun/haruphone1';

export function ClaimUI(player) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body('>>> §e選択してください');
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1請求を送る', 'textures/ui/normalicon1');
    form.button('§5届いた請求を確認', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                if (player_Cash_Data[player.id].HARUPhoneMode) {
                    HARUPhone1(player);
                }
                break;
            case 1:
                player_Cash_Data[player.id].players = world.getAllPlayers();
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e請求送信先プレイヤーを選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        ClaimUI(player);
                        return;
                    }
                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection - 1];
                    if (player_Cash_Data[player.id].select_player.name == player.name) {
                        player.sendMessage(`§r[§b請求§r] §c自分は選択できません`);
                        player.playSound('haru.notification1', {
                            pitch: 0.8,
                            volume: config['Volume'],
                        });
                        ClaimUI(player);
                        return;
                    }
                    var form = new ModalFormData();
                    form.title(`${config['main'][0]}`);
                    form.textField('§e請求金額 §r[半角数字]', `0`);
                    form.textField('§a請求理由', `理由`);
                    form.submitButton(`§1送信`);
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        if (r.formValues[0] == '') {
                            player.sendMessage(`§r[§b請求§r] §4金額を設定してください`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }
                        if (isNaN(Number(r.formValues[0])) || !Number.isInteger(Number(r.formValues[0]))) {
                            player.sendMessage(`§r[§b請求§r] §4整数を入力してください`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }
                        if (Number(r.formValues[0]) <= 0) {
                            player.sendMessage(`§r[§b請求§r] §40以下の金額は設定できません`);
                            player.playSound('haru.notification1', { pitch: 0.8, volume: config['Volume'] });
                            return;
                        }
                        if (r.formValues[1] == '') {
                            player.sendMessage(`§r[§b請求§r] §4理由を入力してください`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }
                        if (Claim[player_Cash_Data[player.id].select_player.name] == undefined) {
                            Claim[player_Cash_Data[player.id].select_player.name] = [];
                        }
                        Claim[player_Cash_Data[player.id].select_player.name].push([player.name, Number(r.formValues[0]), r.formValues[1]]);

                        //メッセージ
                        player.sendMessage(`§r[§b請求§r] §a${player_Cash_Data[player.id].select_player.name}§rへ請求を送信しました`);
                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§b請求§r] §a${player.name}§rから§2${r.formValues[1]}§rの請求が届きました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.5,
                            volume: config['Volume'],
                        });
                        player_Cash_Data[player.id].select_player.playSound('haru.notification1', {
                            pitch: 1.5,
                            volume: config['Volume'],
                        });
                    });
                });
                break;
            case 2:
                if (Claim[player.name] == undefined) {
                    player.sendMessage(`§r[§b請求§r] §a届いた請求が見つかりません`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e処理を行う請求を選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < Claim[player.name].length; i++) {
                    form.button(`§5${Claim[player.name][i][2]}\n§0送信者:§1${Claim[player.name][i][0]}`, 'textures/ui/normalicon1');
                }
                form.show(player).then(r => {
                    if (r.canceled) return;
                    if (r.selection == 0) {
                        ClaimUI(player);
                        return;
                    }
                    player_Cash_Data[player.id].select = r.selection - 1;
                    var form = new ActionFormData();
                    form.title(`${config['main'][0]}`);
                    form.body(`§r-請求の詳細-\n\n§e請求理由§r:§a${Claim[player.name][player_Cash_Data[player.id].select][2]}\n§e請求金額§r:§b${Claim[player.name][player_Cash_Data[player.id].select][1]}\n\n§c請求を送信者§r:§a${Claim[player.name][player_Cash_Data[player.id].select][0]}`);
                    form.button('§1許可', 'textures/ui/normalicon1');
                    form.button('§5拒否', 'textures/ui/normalicon1');
                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0:
                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                    if (Claim[player.name][player_Cash_Data[player.id].select][0] === player_Cash_Data[player.id].players[i].name) {
                                        player_Cash_Data[player.id].claim_player = player_Cash_Data[player.id].players[i];
                                    }
                                }
                                if (player_Cash_Data[player.id].claim_player == undefined) {
                                    player.sendMessage(`§r[§b請求§r] §4相手プレイヤーがオフラインの為処理を中止しました`);
                                    player.playSound('haru.notification1', {
                                        pitch: 0.8,
                                        volume: config['Volume'],
                                    });
                                    return;
                                }
                                const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                //残高が設定金額以上の場合のみ実行
                                if (score >= Claim[player.name][player_Cash_Data[player.id].select][1]) {
                                    player_Cash_Data[player.id].claim_player.runCommand(`scoreboard players add @s money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                    player.runCommand(`scoreboard players remove @s money ${Claim[player.name][player_Cash_Data[player.id].select][1]}`);
                                    player.sendMessage(`§r[§b請求§r] §a請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY送信しました`);
                                    player_Cash_Data[player.id].claim_player.sendMessage(`§r[§b請求§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を許可しました §e${Claim[player.name][player_Cash_Data[player.id].select][1]}PAY受け取りました`);
                                    player.playSound('haru.notification1', {
                                        pitch: 1.5,
                                        volume: config['Volume'],
                                    });
                                    player_Cash_Data[player.id].claim_player.playSound('haru.notification1', {
                                        pitch: 1.5,
                                        volume: config['Volume'],
                                    });
                                    Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                }
                                break;
                            case 1:
                                player_Cash_Data[player.id].players = world.getAllPlayers();
                                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                    if (Claim[player.name][player_Cash_Data[player.id].select][0] === player_Cash_Data[player.id].players[i].name) {
                                        player_Cash_Data[player.id].claim_player = player_Cash_Data[player.id].players[i];
                                    }
                                }
                                if (player_Cash_Data[player.id].claim_player == undefined) {
                                    player.sendMessage(`§r[§b請求§r] §4相手プレイヤーがオフラインの為処理を中止しました`);
                                    player.playSound('haru.notification1', {
                                        pitch: 0.8,
                                        volume: config['Volume'],
                                    });
                                    return;
                                }
                                player.sendMessage(`§r[§b請求§r] §a請求を§4拒否しました`);
                                player_Cash_Data[player.id].claim_player.sendMessage(`§r[§b請求§r] §a${player.name}が${Claim[player.name][player_Cash_Data[player.id].select][2]}の請求を§4拒否しました`);
                                player.playSound('haru.notification1', {
                                    pitch: 1.5,
                                    volume: config['Volume'],
                                });
                                player_Cash_Data[player.id].claim_player.playSound('haru.notification1', {
                                    pitch: 1.5,
                                    volume: config['Volume'],
                                });
                                Claim[player.name].splice(player_Cash_Data[player.id].select, 1);
                                break;
                        }
                    });
                });
                break;
        }
    });
}
