import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { config } from '../config';

import { HARUPhone1 } from '../itemrun/haruphone1';

import { player_Cash_Data } from '../itemrun/haruphone1';

import { quest } from '../itemrun/haruphone1';

import { logs } from '../itemrun/haruphone1';

export function Work(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    //仕事依頼設定画面
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}§r\n\n§5 >>>§rサービスを選択`);
    if (player_Cash_Data[player.id].HARUPhoneMode) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1募集', 'textures/ui/normalicon1');
    form.button('§5探す', 'textures/ui/normalicon1');
    form.button('§0募集の§4削除', 'textures/ui/normalicon1');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                if (player_Cash_Data[player.id].HARUPhoneMode) {
                    HARUPhone1(player);
                }
                break;
            case 1:
                var form = new ModalFormData();
                form.title(`${config['main'][0]}`);
                form.textField('§e仕事ジャンル', '例:整地');
                form.textField('§a仕事内容', '例:約半径30ブロックの整地');
                form.textField('§c報酬額(半角数字)', '0');
                form.submitButton(`§1募集`);
                form.show(player)
                    .then(r => {
                        if (r.canceled) {
                            Work(player);
                            return;
                        }
                        if (r.formValues[2] > 100000000) {
                            player.sendMessage(`§r[§b仕事依頼§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }
                        if (r.formValues[0] == '' || r.formValues[2] == '') {
                            player.sendMessage(`§r[§b仕事依頼§r] §4設定されていない項目があるため開始できませんでした`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }
                        if (r.formValues[2] < 0) {
                            player.sendMessage(`§r[§b仕事依頼§r] §40以下は設定できません`);
                            player.playSound('haru.notification1', {
                                pitch: 0.8,
                                volume: config['Volume'],
                            });
                            return;
                        }
                        player_Cash_Data[player.id].players = world.getAllPlayers();
                        for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                            player_Cash_Data[player.id].players[i].sendMessage(`§r[§b仕事依頼§r] §b${player.name}§aが§b${r.formValues[0]}§aの募集しました`);
                            player_Cash_Data[player.id].players[i].sendMessage(`>>> §e報酬額§r:§b${r.formValues[2]}`);
                            player_Cash_Data[player.id].players[i].playSound('haru.notification1', {
                                pitch: 1.7,
                                volume: config['Volume'],
                            });
                        }
                        //Code生成
                        let number = '';
                        for (let i = 0; i < 8; i++) {
                            number += Math.floor(Math.random() * 10); // 0〜9のランダムな数字
                        }
                        quest[0].push([r.formValues[0], player.name, r.formValues[2], r.formValues[1], player.id, number]);
                    })
                    .catch(e => {
                        console.error(e, e.stack);
                    });
                break;
            case 2:
                if (quest[0].length == 0) {
                    player.sendMessage(`§r[§b仕事依頼§r] §a募集が見つかりませんでした`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    return;
                }
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e仕事一覧');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < quest[0].length; i++) {
                    form.button(`§1${quest[0][i][0]}\n§0報酬額:§s${quest[0][i][2]}§0PAY  §0依頼者:§2${quest[0][i][1]}`, 'textures/ui/normalicon1');
                }
                form.show(player)
                    .then(r => {
                        if (r.canceled) {
                            return;
                        }
                        if (r.selection == 0) {
                            Work(player);
                            return;
                        }
                        //選択した商品を保存
                        player_Cash_Data[player.id].select_quest = quest[0][r.selection - 1];

                        var form = new ActionFormData();
                        form.title(`${config['main'][0]}`);
                        form.body(`仕事:§a${player_Cash_Data[player.id].select_quest[0]}\n§r詳細:§c${player_Cash_Data[player.id].select_quest[3]}\n§r金額:§b${player_Cash_Data[player.id].select_quest[2]}  §r依頼者:§2${player_Cash_Data[player.id].select_quest[1]}`);
                        form.button('§5仕事を受ける', 'textures/ui/normalicon1');
                        form.button('§1キャンセル', 'textures/ui/normalicon1');
                        form.show(player).then(r => {
                            if (r.canceled) {
                                return;
                            }
                            switch (r.selection) {
                                case 0:
                                    player_Cash_Data[player.id].quest_stop = false;
                                    //オンラインプレイヤー取得
                                    player_Cash_Data[player.id].players = world.getAllPlayers();
                                    for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                                        if (player_Cash_Data[player.id].select_quest[4] == player_Cash_Data[player.id].players[i].id) {
                                            player_Cash_Data[player.id].quest_stop = true;
                                            player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[i];
                                        }
                                    }
                                    if (player_Cash_Data[player.id].quest_stop == false) {
                                        player.sendMessage(`§r[§b仕事依頼§r] §4現在募集者がオフラインの為処理を中止します`);
                                        player.playSound('haru.notification1', {
                                            pitch: 0.8,
                                            volume: config['Volume'],
                                        });
                                        return;
                                    }

                                    if (quest[1][0] != undefined) {
                                        for (let i = 0; i < quest[1].length; i++) {
                                            if (player_Cash_Data[player.id].select_quest[5] == quest[1][i]) {
                                                player_Cash_Data[player.id].quest_stop = false;
                                            }
                                        }
                                    }

                                    if (player_Cash_Data[player.id].quest_stop == false) {
                                        player.sendMessage(`§r[§b仕事依頼§r] §4選択した募集は既に終了しております`);
                                        player.playSound('haru.notification1', {
                                            pitch: 0.8,
                                            volume: config['Volume'],
                                        });
                                        return;
                                    }
                                    //メッセージ関連
                                    player_Cash_Data[player.id].select_player.sendMessage(`§r[§b仕事依頼§r] §e${player.name}§bが§a${player_Cash_Data[player.id].select_quest[0]}§bの仕事募集を受けました`);
                                    player.sendMessage(`§r[§b仕事依頼§r] §b${player_Cash_Data[player.id].select_quest[0]}§aの仕事を受けました §c募集者§r:§e${player_Cash_Data[player.id].select_quest[1]}`);
                                    //通知音
                                    player.playSound('haru.notification1', {
                                        pitch: 1.7,
                                        volume: config['Volume'],
                                    });
                                    player_Cash_Data[player.id].select_player.playSound('haru.notification1', {
                                        pitch: 1.7,
                                        volume: config['Volume'],
                                    });

                                    //log関連
                                    logs['quest'].push([time, player.name, player_Cash_Data[player.id].select_quest[1], player_Cash_Data[player.id].select_quest[0]]);

                                    quest[1].push(player_Cash_Data[player.id].select_quest[5]);
                                    for (let i = 0; i < quest[0].length; i++) {
                                        if (quest[0][i][5] === player_Cash_Data[player.id].select_quest[5]) {
                                            quest[0].splice(i, 1);
                                        }
                                    }
                                    break;
                            }
                        });
                    })
                    .catch(e => {
                        console.error(e, e.stack);
                    });
                break;
            case 3:
                if (quest[0].length == 0) {
                    player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    return;
                }
                player_Cash_Data[player.id].my_quest = [];
                var form = new ActionFormData();
                form.title(`${config['main'][0]}`);
                form.body('>>> §e削除する仕事依頼を選択');
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < quest[0].length; i++) {
                    if (player.id == quest[0][i][4]) {
                        form.button(`§1${quest[0][i][0]}\n§0報酬額:§s${quest[0][i][2]}§0PAY  §0依頼者:§2${quest[0][i][1]}`, 'textures/ui/normalicon1');
                        player_Cash_Data[player.id].my_quest.push(quest[0][i]);
                    }
                }
                if (player_Cash_Data[player.id].my_quest.length == -1) {
                    player.sendMessage(`§r[§b仕事依頼§r] §a削除できる募集が見つかりませんでした`);
                    player.playSound('haru.notification1', {
                        pitch: 0.8,
                        volume: config['Volume'],
                    });
                    return;
                }
                form.show(player)
                    .then(r => {
                        if (r.canceled) {
                            return;
                        }
                        if (r.selection == 0) {
                            Work(player);
                            return;
                        }
                        for (let i = 0; i < quest[0].length; i++) {
                            if (quest[0][i][5] === player_Cash_Data[player.id].my_quest[r.selection - 1][5]) {
                                quest[0].splice(i, 1);
                            }
                        }
                        player.sendMessage(`§r[§b仕事依頼§r] §a削除しました`);
                        player.playSound('haru.notification1', {
                            pitch: 1.7,
                            volume: config['Volume'],
                        });
                        return;
                    })
                    .catch(e => {
                        console.error(e, e.stack);
                    });
                break;
            default:
        }
    });
}
