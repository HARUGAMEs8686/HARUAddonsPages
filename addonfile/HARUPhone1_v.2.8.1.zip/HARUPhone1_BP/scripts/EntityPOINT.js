import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

import { Kill_Count_System } from './system/Operator_Controller';

// 現在のエンティティ設定（Dynamic Propertyからロード）
let entityConfig = {};

// エンティティ設定をロード
function loadEntityConfig() {
    const storedConfig = world.getDynamicProperty('entityConfig');
    try {
        entityConfig = storedConfig ? JSON.parse(storedConfig) : {};
    } catch (e) {
        entityConfig = {};
    }
}

// エンティティ設定を保存
function saveEntityConfig() {
    world.setDynamicProperty('entityConfig', JSON.stringify(entityConfig));
}

export function entityPOINT(event) {
    if (world.getDynamicProperty('killPointSystem') !== true) {
        return;
    }

    const entity = event.hurtEntity;
    const healthComponent = entity.getComponent('health');

    if (!healthComponent || healthComponent.currentValue > 0) {
        return;
    }

    const damager = event.damageSource.damagingEntity;
    if (!damager || damager.typeId !== 'minecraft:player') {
        return;
    }

    const player = damager;
    const config = Object.values(entityConfig).find(cfg => cfg.typeId === entity.typeId);
    if (!config) {
        return;
    }

    const entityKey = Object.keys(entityConfig).find(key => entityConfig[key].typeId === entity.typeId);

    let killCounts = player.getDynamicProperty('playerKillCounts');
    try {
        killCounts = killCounts ? JSON.parse(killCounts) : {};
    } catch (e) {
        killCounts = {};
    }

    let soundSettings = {};
    try {
        const storedSettings = world.getDynamicProperty('Sound_Notification');
        soundSettings = storedSettings ? JSON.parse(storedSettings) : {};
    } catch (e) {
        soundSettings = {};
    }

    if (config.requiredKills != 0) {
        killCounts[entityKey] = (killCounts[entityKey] || 0) + 1;
        player.setDynamicProperty('playerKillCounts', JSON.stringify(killCounts));

        if (killCounts[entityKey] >= config.requiredKills && config.requiredKills > 0) {
            player.runCommand(`scoreboard players add @s money ${config.points}`);
            if (soundSettings['Kill Count']['Money Acquisition Notification']) {
                player.sendMessage({
                    rawtext: [
                        {
                            text: `[§bPOINT§r] §e${config.points}POINTゲットしました§6(${config.displayName})`,
                        },
                    ],
                });
                player.playSound('haru.notification1', {
                    pitch: 1.9,
                    volume: 1.0,
                });
            }
            killCounts[entityKey] = 0;
            player.setDynamicProperty('playerKillCounts', JSON.stringify(killCounts));
        } else {
            const remaining = config.requiredKills - killCounts[entityKey];
            if (soundSettings['Kill Count']['Count Notification']) {
                player.sendMessage({
                    rawtext: [
                        {
                            text: `[§bPOINT§r] §aPOINTゲットまで残り§b${remaining}§a体です`,
                        },
                    ],
                });
                player.playSound('haru.notification1', {
                    pitch: 1.3,
                    volume: 1.0,
                });
            }
        }
    }
}

export function Kill_Count_System_edit(player) {
    const form = new ActionFormData();
    form.title('§4ポイントシステム設定');
    form.body('§aモブを選択して編集/追加');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button('§1新しいモブを追加');
    Object.entries(entityConfig).forEach(([key, cfg]) => {
        form.button(`§1${cfg.displayName} §0(§4キル: §s${cfg.requiredKills} §5ポイント: §s${cfg.points}§0)`);
    });

    form.show(player).then(r => {
        if (r.canceled) return;

        if (r.selection === 0) {
            Kill_Count_System(player);
            return;
        }

        if (r.selection === 1) {
            const addForm = new ModalFormData();
            addForm.title('§1新しいモブの追加');
            addForm.textField('モブのTypeID（例: minecraft:pig）', 'minecraft:');
            addForm.textField('表示名（例: ピッグ）', '');
            addForm.textField('必要キル数', '10');
            addForm.textField('ポイント', '100');

            addForm.show(player).then(r => {
                if (r.canceled) return;

                const [typeId, displayName, requiredKills, points] = r.formValues;
                if (!typeId || !displayName || !requiredKills || !points) {
                    player.sendMessage({
                        rawtext: [{ text: '§r[§bキルポイント§r] §4すべての項目を入力してください' }],
                    });
                    player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                    return;
                }

                if (isNaN(requiredKills) || isNaN(points)) {
                    player.sendMessage({
                        rawtext: [{ text: '§r[§bキルポイント§r] §4キル数とポイントは半角数字で入力してください' }],
                    });
                    player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                    return;
                }

                const numKills = Number(requiredKills);
                const numPoints = Number(points);
                if (numKills <= 0 || numPoints <= 0) {
                    player.sendMessage({
                        rawtext: [{ text: '§r[§bキルポイント§r] §40以下の値は設定できません' }],
                    });
                    player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                    return;
                }

                const key = typeId.replace('minecraft:', '');
                if (entityConfig[key]) {
                    player.sendMessage({
                        rawtext: [{ text: '§r[§bキルポイント§r] §4このモブはすでに存在します' }],
                    });
                    player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                    return;
                }

                entityConfig[key] = {
                    typeId,
                    displayName,
                    requiredKills: numKills,
                    points: numPoints,
                };
                saveEntityConfig();

                player.sendMessage({
                    rawtext: [{ text: `§r[§bキルポイント§r] §a${displayName}を追加しました` }],
                });
                player.playSound('haru.notification1', { pitch: 1.7, volume: 0.8 });
                Kill_Count_System_edit(player);
            });
            return;
        }

        const selectedKey = Object.keys(entityConfig)[r.selection - 2];
        const selectedConfig = entityConfig[selectedKey];

        const editForm = new ModalFormData();
        editForm.title(`§1${selectedConfig.displayName}の編集`);
        editForm.textField('必要キル数', '', {
            defaultValue: `${selectedConfig.requiredKills}`,
        });
        editForm.textField('ポイント', '', {
            defaultValue: `${selectedConfig.points}`,
        });
        editForm.toggle('このモブを削除する', {
            defaultValue: false,
        });

        editForm.show(player).then(r => {
            if (r.canceled) return;

            const [requiredKills, points, deleteMob] = r.formValues;

            if (deleteMob) {
                delete entityConfig[selectedKey];
                saveEntityConfig();
                player.sendMessage({
                    rawtext: [{ text: `§r[§bキルポイント§r] §a${selectedConfig.displayName}を削除しました` }],
                });
                player.playSound('haru.notification1', { pitch: 1.7, volume: 0.8 });
                Kill_Count_System_edit(player);
                return;
            }

            if (!requiredKills || !points) {
                player.sendMessage({
                    rawtext: [{ text: '§r[§bキルポイント§r] §4すべての項目を入力してください' }],
                });
                player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                return;
            }

            if (isNaN(requiredKills) || isNaN(points)) {
                player.sendMessage({
                    rawtext: [{ text: '§r[§bキルポイント§r] §4キル数とポイントは半角数字で入力してください' }],
                });
                player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                return;
            }

            const numKills = Number(requiredKills);
            const numPoints = Number(points);
            if (numKills <= 0 || numPoints <= 0) {
                player.sendMessage({
                    rawtext: [{ text: '§r[§bキルポイント§r] §40以下の値は設定できません' }],
                });
                player.playSound('haru.notification1', { pitch: 0.8, volume: 0.8 });
                return;
            }

            entityConfig[selectedKey].requiredKills = numKills;
            entityConfig[selectedKey].points = numPoints;
            saveEntityConfig();

            player.sendMessage({
                rawtext: [{ text: `§r[§bキルポイント§r] §a${selectedConfig.displayName}の設定を更新しました` }],
            });
            player.playSound('haru.notification1', { pitch: 1.7, volume: 0.8 });
            Kill_Count_System_edit(player);
        });
    });
}

//初期設定>>>
export function initializePointSystem() {
    // デフォルトのエンティティ設定をDynamic Propertyに保存
    if (!world.getDynamicProperty('entityConfig')) {
        entityConfig = {
            zombie: {
                typeId: 'minecraft:zombie',
                displayName: 'ゾンビ',
                requiredKills: 0,
                points: 0,
            },
            skeleton: {
                typeId: 'minecraft:skeleton',
                displayName: 'スケルトン',
                requiredKills: 0,
                points: 0,
            },
            spider: {
                typeId: 'minecraft:spider',
                displayName: '蜘蛛',
                requiredKills: 0,
                points: 0,
            },
            creeper: {
                typeId: 'minecraft:creeper',
                displayName: 'クリーパー',
                requiredKills: 0,
                points: 0,
            },
            enderman: {
                typeId: 'minecraft:enderman',
                displayName: 'エンダーマン',
                requiredKills: 0,
                points: 0,
            },
            warden: {
                typeId: 'minecraft:warden',
                displayName: 'ウォーデン',
                requiredKills: 0,
                points: 0,
            },
            phantom: {
                typeId: 'minecraft:phantom',
                displayName: 'ファントム',
                requiredKills: 0,
                points: 0,
            },
        };
        saveEntityConfig();
    } else {
        loadEntityConfig();
    }
}

initializePointSystem();
