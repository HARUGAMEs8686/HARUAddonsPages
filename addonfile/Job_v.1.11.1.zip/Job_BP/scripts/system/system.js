import { world, system } from '@minecraft/server';

const objectiveName = 'money';

// デフォルト設定に制限とポイントの有効/無効設定を追加
export const DEFAULT_CONFIG = {
    system: {
        professionRemoveDays: 7,
        maxProfessions: 2,
        businessSystemEnabled: true, // 全体的なビジネスシステム有効/無効
        levelRankingEnabled: true, // レベルランキング表示の有効/無効
        antiIdleEnabled: false,
    },
    // 各職業の設定をネストされたオブジェクトに変更
    professions: {
        livestock: {
            enabled: true, // 新しく追加: 職業の有効/無効 (UI表示制御用)
            limitEnabled: false, // デフォルトで制限は無効
            pointsEnabled: true, // デフォルトでポイントは有効
            points: {
                'minecraft:cow': 10,
                'minecraft:sheep': 10,
                'minecraft:pig': 10,
                'minecraft:chicken': 10,
                'minecraft:rabbit': 10,
                'minecraft:mooshroom': 15,
            },
            levelUpActions: 20,
            items: ['minecraft:cow', 'minecraft:sheep', 'minecraft:pig', 'minecraft:chicken', 'minecraft:rabbit', 'minecraft:mooshroom'],
            limit: {},
        },
        miner: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:coal_ore': 20,
                'minecraft:iron_ore': 30,
                'minecraft:gold_ore': 40,
                'minecraft:diamond_ore': 50,
                'minecraft:lapis_ore': 30,
                'minecraft:redstone_ore': 30,
                'minecraft:lit_redstone_ore': 30,
                'minecraft:emerald_ore': 50,
                'minecraft:copper_ore': 20,
                'minecraft:deepslate_coal_ore': 20,
                'minecraft:deepslate_iron_ore': 30,
                'minecraft:deepslate_gold_ore': 40,
                'minecraft:deepslate_diamond_ore': 50,
                'minecraft:deepslate_lapis_ore': 30,
                'minecraft:deepslate_redstone_ore': 30,
                'minecraft:lit_deepslate_redstone_ore': 30,
                'minecraft:deepslate_emerald_ore': 50,
                'minecraft:deepslate_copper_ore': 20,
                'minecraft:nether_quartz_ore': 25,
                'minecraft:nether_gold_ore': 35,
                'minecraft:ancient_debris': 60,
            },
            levelUpActions: 30,
            items: [
                'minecraft:coal_ore',
                'minecraft:iron_ore',
                'minecraft:gold_ore',
                'minecraft:diamond_ore',
                'minecraft:lapis_ore',
                'minecraft:redstone_ore',
                'minecraft:emerald_ore',
                'minecraft:copper_ore',
                'minecraft:deepslate_coal_ore',
                'minecraft:deepslate_iron_ore',
                'minecraft:deepslate_gold_ore',
                'minecraft:deepslate_diamond_ore',
                'minecraft:deepslate_lapis_ore',
                'minecraft:deepslate_redstone_ore',
                'minecraft:lit_deepslate_redstone_ore',
                'minecraft:deepslate_emerald_ore',
                'minecraft:deepslate_copper_ore',
                'minecraft:nether_quartz_ore',
                'minecraft:nether_gold_ore',
                'minecraft:ancient_debris',
            ],
            limit: {
                maxBreaksPerPeriod: 50,
                periodDays: 3,
            },
        },
        builder: {
            // 林業 (既存のbuilderタグを使用)
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:oak_log': 3,
                'minecraft:spruce_log': 3,
                'minecraft:birch_log': 3,
                'minecraft:jungle_log': 3,
                'minecraft:acacia_log': 3,
                'minecraft:dark_oak_log': 3,
                'minecraft:mangrove_log': 3,
                'minecraft:cherry_log': 3,
                'minecraft:stripped_oak_log': 3,
                'minecraft:stripped_spruce_log': 3,
                'minecraft:stripped_birch_log': 3,
                'minecraft:stripped_jungle_log': 3,
                'minecraft:stripped_acacia_log': 3,
                'minecraft:stripped_dark_oak_log': 3,
                'minecraft:stripped_mangrove_log': 3,
                'minecraft:stripped_cherry_log': 3,
                'minecraft:crimson_stem': 5,
                'minecraft:warped_stem': 5,
                'minecraft:stripped_crimson_stem': 5,
                'minecraft:stripped_warped_stem': 5,
            },
            levelUpActions: 30,
            items: [
                'minecraft:oak_log',
                'minecraft:spruce_log',
                'minecraft:birch_log',
                'minecraft:jungle_log',
                'minecraft:acacia_log',
                'minecraft:dark_oak_log',
                'minecraft:mangrove_log',
                'minecraft:cherry_log',
                'minecraft:stripped_oak_log',
                'minecraft:stripped_spruce_log',
                'minecraft:stripped_birch_log',
                'minecraft:stripped_jungle_log',
                'minecraft:stripped_acacia_log',
                'minecraft:stripped_dark_oak_log',
                'minecraft:stripped_mangrove_log',
                'minecraft:stripped_cherry_log',
                'minecraft:crimson_stem',
                'minecraft:warped_stem',
                'minecraft:stripped_crimson_stem',
                'minecraft:stripped_warped_stem',
            ],
            limit: {
                maxBreaksPerPeriod: 50, // 破壊数と設置数を共有
                periodDays: 3,
            },
        },
        farming: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:wheat': 5,
                'minecraft:carrots': 5,
                'minecraft:potatoes': 5,
                'minecraft:beetroot': 5,
                'minecraft:pumpkin': 10,
                'minecraft:melon': 10,
                'minecraft:reeds': 5,
                'minecraft:sweet_berry_bush': 8,
                'minecraft:sugar_cane': 5, // サトウキビもポイント対象に追加
            },
            levelUpActions: 25,
            items: ['minecraft:wheat', 'minecraft:carrots', 'minecraft:potatoes', 'minecraft:beetroot', 'minecraft:pumpkin', 'minecraft:melon', 'minecraft:sugar_cane', 'minecraft:reeds', 'minecraft:sweet_berry_bush'],
            limit: {},
        },
        adventurer: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:zombie': 10,
                'minecraft:husk': 10,
                'minecraft:drowned': 10,
                'minecraft:skeleton': 10,
                'minecraft:stray': 10,
                'minecraft:spider': 10,
                'minecraft:cave_spider': 12,
                'minecraft:creeper': 15,
                'minecraft:enderman': 20,
                'minecraft:slime': 15,
                'minecraft:magma_cube': 15,
                'minecraft:ghast': 25,
                'minecraft:blaze': 20,
                'minecraft:wither_skeleton': 25,
                'minecraft:phantom': 20,
            },
            levelUpActions: 10,
            items: ['minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:skeleton', 'minecraft:stray', 'minecraft:spider', 'minecraft:cave_spider', 'minecraft:creeper', 'minecraft:enderman', 'minecraft:slime', 'minecraft:magma_cube', 'minecraft:ghast', 'minecraft:blaze', 'minecraft:wither_skeleton', 'minecraft:phantom'],
            limit: {},
        },
        Angler: {
            enabled: true, // 新しく追加
            limitEnabled: false,
            pointsEnabled: true,
            points: {
                'minecraft:cod': 10,
                'minecraft:salmon': 10,
                'minecraft:tropical_fish': 15,
                'minecraft:pufferfish': 15,
                'minecraft:enchanted_book': 50,
                'minecraft:bow': 30,
                'minecraft:leather': 20,
                'minecraft:fishing_rod': 30,
                'minecraft:name_tag': 50,
                'minecraft:saddle': 50,
                'minecraft:lily_pad': 20,
                'minecraft:nautilus_shell': 50,
            },
            levelUpActions: 15,
            items: ['minecraft:cod', 'minecraft:salmon', 'minecraft:tropical_fish', 'minecraft:pufferfish', 'minecraft:enchanted_book', 'minecraft:bow', 'minecraft:leather', 'minecraft:fishing_rod', 'minecraft:name_tag', 'minecraft:saddle', 'minecraft:lily_pad', 'minecraft:nautilus_shell'],
            limit: {},
        },
        architect: {
            // 建築家 (新しく追加)
            enabled: false, // デフォルトで無効
            limitEnabled: false, // 制限は有効
            pointsEnabled: false, // ポイントレベルはなし
            points: {}, // ポイントは使用しない
            levelUpActions: 0, // レベルアップなし
            items: [
                // business.jsのbuildBlocksから主要なものを抜粋
                // 色付きガラス
                'minecraft:white_stained_glass',
                'minecraft:orange_stained_glass',
                'minecraft:magenta_stained_glass',
                'minecraft:light_blue_stained_glass',
                'minecraft:yellow_stained_glass',
                'minecraft:lime_stained_glass',
                'minecraft:pink_stained_glass',
                'minecraft:gray_stained_glass',
                'minecraft:light_gray_stained_glass',
                'minecraft:cyan_stained_glass',
                'minecraft:purple_stained_glass',
                'minecraft:blue_stained_glass',
                'minecraft:brown_stained_glass',
                'minecraft:green_stained_glass',
                'minecraft:red_stained_glass',
                'minecraft:black_stained_glass',
                // 色付きガラス板
                'minecraft:white_stained_glass_pane',
                'minecraft:orange_stained_glass_pane',
                'minecraft:magenta_stained_glass_pane',
                'minecraft:light_blue_stained_glass_pane',
                'minecraft:yellow_stained_glass_pane',
                'minecraft:lime_stained_glass_pane',
                'minecraft:pink_stained_glass_pane',
                'minecraft:gray_stained_glass_pane',
                'minecraft:light_gray_stained_glass_pane',
                'minecraft:cyan_stained_glass_pane',
                'minecraft:purple_stained_glass_pane',
                'minecraft:blue_stained_glass_pane',
                'minecraft:brown_stained_glass_pane',
                'minecraft:green_stained_glass_pane',
                'minecraft:red_stained_glass_pane',
                'minecraft:black_stained_glass_pane',
                // テラコッタ（非彩釉）
                'minecraft:white_terracotta',
                'minecraft:orange_terracotta',
                'minecraft:magenta_terracotta',
                'minecraft:light_blue_terracotta',
                'minecraft:yellow_terracotta',
                'minecraft:lime_terracotta',
                'minecraft:pink_terracotta',
                'minecraft:gray_terracotta',
                'minecraft:light_gray_terracotta',
                'minecraft:cyan_terracotta',
                'minecraft:purple_terracotta',
                'minecraft:blue_terracotta',
                'minecraft:brown_terracotta',
                'minecraft:green_terracotta',
                'minecraft:red_terracotta',
                'minecraft:black_terracotta',
                // 彩釉テラコッタ（各色が個別のID）
                'minecraft:white_glazed_terracotta',
                'minecraft:orange_glazed_terracotta',
                'minecraft:magenta_glazed_terracotta',
                'minecraft:light_blue_glazed_terracotta',
                'minecraft:yellow_glazed_terracotta',
                'minecraft:lime_glazed_terracotta',
                'minecraft:pink_glazed_terracotta',
                'minecraft:gray_glazed_terracotta',
                'minecraft:light_gray_glazed_terracotta',
                'minecraft:cyan_glazed_terracotta',
                'minecraft:purple_glazed_terracotta',
                'minecraft:blue_glazed_terracotta',
                'minecraft:brown_glazed_terracotta',
                'minecraft:green_glazed_terracotta',
                'minecraft:red_glazed_terracotta',
                'minecraft:black_glazed_terracotta',
                // 羊毛
                'minecraft:white_wool',
                'minecraft:orange_wool',
                'minecraft:magenta_wool',
                'minecraft:light_blue_wool',
                'minecraft:yellow_wool',
                'minecraft:lime_wool',
                'minecraft:pink_wool',
                'minecraft:gray_wool',
                'minecraft:light_gray_wool',
                'minecraft:cyan_wool',
                'minecraft:purple_wool',
                'minecraft:blue_wool',
                'minecraft:brown_wool',
                'minecraft:green_wool',
                'minecraft:red_wool',
                'minecraft:black_wool',
                // カーペット
                'minecraft:white_carpet',
                'minecraft:orange_carpet',
                'minecraft:magenta_carpet',
                'minecraft:light_blue_carpet',
                'minecraft:yellow_carpet',
                'minecraft:lime_carpet',
                'minecraft:pink_carpet',
                'minecraft:gray_carpet',
                'minecraft:light_gray_carpet',
                'minecraft:cyan_carpet',
                'minecraft:purple_carpet',
                'minecraft:blue_carpet',
                'minecraft:brown_carpet',
                'minecraft:green_carpet',
                'minecraft:red_carpet',
                'minecraft:black_carpet',
                // コンクリート
                'minecraft:white_concrete',
                'minecraft:orange_concrete',
                'minecraft:magenta_concrete',
                'minecraft:light_blue_concrete',
                'minecraft:yellow_concrete',
                'minecraft:lime_concrete',
                'minecraft:pink_concrete',
                'minecraft:gray_concrete',
                'minecraft:light_gray_concrete',
                'minecraft:cyan_concrete',
                'minecraft:purple_concrete',
                'minecraft:blue_concrete',
                'minecraft:brown_concrete',
                'minecraft:green_concrete',
                'minecraft:red_concrete',
                'minecraft:black_concrete',
                // コンクリートパウダー
                'minecraft:white_concrete_powder',
                'minecraft:orange_concrete_powder',
                'minecraft:magenta_concrete_powder',
                'minecraft:light_blue_concrete_powder',
                'minecraft:yellow_concrete_powder',
                'minecraft:lime_concrete_powder',
                'minecraft:pink_concrete_powder',
                'minecraft:gray_concrete_powder',
                'minecraft:light_gray_concrete_powder',
                'minecraft:cyan_concrete_powder',
                'minecraft:purple_concrete_powder',
                'minecraft:blue_concrete_powder',
                'minecraft:brown_concrete_powder',
                'minecraft:green_concrete_powder',
                'minecraft:red_concrete_powder',
                'minecraft:black_concrete_powder',
                // 旗（色はパターンで表現されるが、ブロックIDは統一）
                'minecraft:banner',
                // その他の装飾ブロック（色バリエーションなし）
                'minecraft:sea_lantern',
                'minecraft:prismarine',
                'minecraft:prismarine_bricks',
                'minecraft:dark_prismarine',
                //クウォーツ
                'minecraft:quartz_bricks',
                'minecraft:quartz_block',
                'minecraft:chiseled_quartz_block',
                'minecraft:quartz_pillar',
                'minecraft:smooth_quartz',
                //壁
                'minecraft:cobblestone_wall',
                'minecraft:mossy_cobblestone_wall',
                'minecraft:stone_brick_wall',
                'minecraft:mossy_stone_brick_wall',
                'minecraft:brick_wall',
                'minecraft:sandstone_wall',
                'minecraft:red_sandstone_wall',
                'minecraft:granite_wall',
                'minecraft:andesite_wall',
                'minecraft:diorite_wall',
                'minecraft:nether_brick_wall',
                'minecraft:red_nether_brick_wall',
                'minecraft:end_stone_brick_wall',
                'minecraft:prismarine_wall',
                'minecraft:blackstone_wall',
                'minecraft:polished_blackstone_wall',
                'minecraft:polished_blackstone_brick_wall',
                'minecraft:deepslate_brick_wall',
                'minecraft:polished_deepslate_wall',
                'minecraft:deepslate_tile_wall',
                'minecraft:cobbled_deepslate_wall',
                'minecraft:mud_brick_wall',
                'minecraft:resin_brick_wall',
                'minecraft:tuff_brick_wall',
                'minecraft:polished_tuff_wall',
                'minecraft:tuff_wall',
                //ドア
                'minecraft:oak_door',
                'minecraft:spruce_door',
                'minecraft:birch_door',
                'minecraft:jungle_door',
                'minecraft:acacia_door',
                'minecraft:dark_oak_door',
                'minecraft:mangrove_door',
                'minecraft:cherry_door',
                'minecraft:bamboo_door',
                'minecraft:iron_door',
                'minecraft:crimson_door',
                'minecraft:warped_door',
            ],
            limit: {
                maxBreaksPerPeriod: 50, // 破壊数と設置数を共有
                periodDays: 3,
            },
        },
        land_leveling: {
            // 整地 (新しく追加)
            enabled: false, // デフォルトで無効
            limitEnabled: false, // 制限は有効
            pointsEnabled: true, // ポイント付与は有効
            pointsPerBreaks: 10,
            points: {
                'minecraft:dirt': 1,
                'minecraft:grass_block': 1,
                'minecraft:podzol': 2,
                'minecraft:mycelium': 2,
                'minecraft:farmland': 1,
                'minecraft:coarse_dirt': 1,
                'minecraft:rooted_dirt': 1,
                'minecraft:mud': 1,
                'minecraft:packed_mud': 1,
                'minecraft:muddy_mangrove_roots': 1,
            },
            levelUpActions: 50, // レベルアップに必要なアクション数
            items: [
                // 整地対象ブロック
                'minecraft:dirt',
                'minecraft:grass_block',
                'minecraft:podzol',
                'minecraft:mycelium',
                'minecraft:farmland',
                'minecraft:coarse_dirt',
                'minecraft:rooted_dirt',
                'minecraft:mud',
                'minecraft:packed_mud',
                'minecraft:muddy_mangrove_roots',
            ],
            limit: {
                maxBreaksPerPeriod: 100, // 破壊数制限
                periodDays: 3,
            },
        },
    },
    levelRewards: {
        livestock: {},
        miner: {},
        builder: {}, // 林業
        farming: {},
        adventurer: {},
        Angler: {},
        architect: {}, // 建築家 (報酬はなし)
        land_leveling: {}, // 整地
    },
};

// 職業の表示名マッピング
const PROFESSION_DISPLAY_NAMES = {
    livestock: '家畜',
    miner: '鉱夫',
    builder: '林業', // 林業はbuilderタグを使用
    farming: '農業',
    adventurer: '冒険家',
    Angler: '釣り人',
    architect: '建築家', // 新しく追加
    land_leveling: '整地', // 新しく追加
};

// メッセージクールダウン
const messageCooldowns = new Map();
const COOLDOWN_TICKS = 30; // 1.5秒 (20 tick/秒 * 1.5秒)

function sendRestrictedMessage(player, message) {
    const now = system.currentTick;
    const lastSent = messageCooldowns.get(player.id) || 0;
    if (now - lastSent >= COOLDOWN_TICKS) {
        player.sendMessage(`[§b職業システム§r] §c${message}`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        messageCooldowns.set(player.id, now);
    }
}

// プレイヤーの行動座標履歴を保存するマップ
const playerActionHistory = new Map();

function isCamping(player) {
    // 設定が無効ならチェックをスキップしてfalseを返す
    if (config.system.antiIdleEnabled === false) return false;

    const HISTORY_SIZE = 15;
    const MIN_SPREAD = 2;

    // プレイヤーの履歴を取得
    let history = playerActionHistory.get(player.id) || [];

    // 現在の座標を追加
    const currentLoc = player.location;
    history.push({ x: currentLoc.x, z: currentLoc.z });

    if (history.length > HISTORY_SIZE) {
        history.shift();
    }

    // 履歴を更新
    playerActionHistory.set(player.id, history);

    // データが溜まるまでは判定しない
    if (history.length < HISTORY_SIZE) {
        return false;
    }

    let minX = Infinity,
        maxX = -Infinity;
    let minZ = Infinity,
        maxZ = -Infinity;

    for (const loc of history) {
        if (loc.x < minX) minX = loc.x;
        if (loc.x > maxX) maxX = loc.x;
        if (loc.z < minZ) minZ = loc.z;
        if (loc.z > maxZ) maxZ = loc.z;
    }

    const spreadX = maxX - minX;
    const spreadZ = maxZ - minZ;

    if (spreadX < MIN_SPREAD && spreadZ < MIN_SPREAD) {
        return true;
    }

    return false;
}

// 設定データ (グローバル変数として宣言)
var config;

// 設定の初期化
export function initializeConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    if (savedConfig === undefined) {
        config = JSON.parse(JSON.stringify(DEFAULT_CONFIG)); // ディープコピー
        world.setDynamicProperty('business_config', JSON.stringify(config));
    } else {
        // 既存の設定がある場合はロード
        config = JSON.parse(savedConfig);
        // 新しいプロパティが追加された場合に既存の設定を更新
        config = mergeConfigs(config, DEFAULT_CONFIG);
        world.setDynamicProperty('business_config', JSON.stringify(config)); // 更新した設定を保存
    }
}

// 設定をマージするヘルパー関数
function mergeConfigs(currentConfig, defaultTemplate) {
    const merged = { ...currentConfig };

    for (const key in defaultTemplate) {
        if (defaultTemplate.hasOwnProperty(key)) {
            if (typeof defaultTemplate[key] === 'object' && defaultTemplate[key] !== null && !Array.isArray(defaultTemplate[key])) {
                // オブジェクトの場合は再帰的にマージ
                merged[key] = mergeConfigs(currentConfig[key] || {}, defaultTemplate[key]);
            } else if (!(key in currentConfig)) {
                // 既存の設定にない場合はデフォルトを追加
                merged[key] = JSON.parse(JSON.stringify(defaultTemplate[key])); // ディープコピー
            }
        }
    }
    return merged;
}

// 設定の更新
export function UpdateConfig() {
    config = getConfig();
}

// 設定の取得
export function getConfig() {
    const savedConfig = world.getDynamicProperty('business_config');
    let currentConfig = savedConfig ? JSON.parse(savedConfig) : JSON.parse(JSON.stringify(DEFAULT_CONFIG));

    // 新しいプロパティが追加された場合に既存の設定を更新
    currentConfig = mergeConfigs(currentConfig, DEFAULT_CONFIG);

    return currentConfig;
}

// --- 置き換えるコード ---
let placedBlocks = new Map();
let placedBlocksChanged = false;

// 起動時にデータを読み込む処理
function loadPlacedBlocks() {
    placedBlocks.clear();

    // 前回の個別プロパティ形式 (pb:x,y,z,dim) のデータを統合してゴミを削除
    const oldKeys = world.getDynamicPropertyIds().filter(id => id.startsWith('pb:'));
    for (const k of oldKeys) {
        const timestamp = world.getDynamicProperty(k);
        const actualKey = k.substring(3); // "pb:" を削除した元の座標
        placedBlocks.set(actualKey, timestamp);
        world.setDynamicProperty(k, undefined); // 古い形式は消去
        placedBlocksChanged = true;
    }

    // 分担(チャンク)されたデータを読み込む
    const chunkKeys = world.getDynamicPropertyIds().filter(id => id.startsWith('pb_chunk_'));
    for (const k of chunkKeys) {
        try {
            const dataStr = world.getDynamicProperty(k);
            if (dataStr) {
                const data = JSON.parse(dataStr);
                for (const key in data) {
                    placedBlocks.set(key, data[key]);
                }
            }
        } catch (e) {
            console.warn('設置ブロックデータの読み込みに失敗しました:', e);
        }
    }
}
loadPlacedBlocks();

// データを分担してダイナミックプロパティに保存する処理
function savePlacedBlocks() {
    if (!placedBlocksChanged) return;

    // 既存のチャンクをクリア
    const existingChunkKeys = world.getDynamicPropertyIds().filter(id => id.startsWith('pb_chunk_'));
    for (const k of existingChunkKeys) {
        world.setDynamicProperty(k, undefined);
    }

    let currentChunk = {};
    let chunkIndex = 0;
    let currentLength = 2; // "{}" の分

    for (const [key, timestamp] of placedBlocks.entries()) {
        const entryString = `"${key}":${timestamp},`;

        // マイクラのプロパティ文字数上限を考慮し、25000文字程度で分割(分担)する
        if (currentLength + entryString.length > 25000) {
            world.setDynamicProperty(`pb_chunk_${chunkIndex}`, JSON.stringify(currentChunk));
            chunkIndex++;
            currentChunk = {};
            currentLength = 2;
        }
        currentChunk[key] = timestamp;
        currentLength += entryString.length;
    }

    // 余ったデータを保存
    if (Object.keys(currentChunk).length > 0) {
        world.setDynamicProperty(`pb_chunk_${chunkIndex}`, JSON.stringify(currentChunk));
    }

    placedBlocksChanged = false;
}

const BLOCK_EXPIRY_MS = 12 * 60 * 60 * 1000;

function cleanupExpiredBlocks() {
    const now = Date.now();

    // 12時間経過した古いデータを削除
    for (const [key, timestamp] of placedBlocks.entries()) {
        if (now - timestamp > BLOCK_EXPIRY_MS) {
            placedBlocks.delete(key);
            placedBlocksChanged = true;
        }
    }

    // 変更があれば保存（分割チャンク方式）
    savePlacedBlocks();
}

// 1分ごとにクリーンアップ＆セーブ処理を実行
system.runInterval(() => {
    cleanupExpiredBlocks();
}, 1200);

// レベル表示用の関数
function updateLevelDisplay(player, profession, level, actions, currentActions, gainedPoints = 0) {
    // 建築家はポイントレベルがないため、表示をスキップ
    if (profession === 'architect') {
        return;
    }

    const maxBars = 20; // 最大20本
    const actionsPerBar = Math.max(actions / maxBars, 1);
    const filledBars = Math.min(Math.floor(currentActions / actionsPerBar), maxBars); // 現在のアクションで埋まったバーの数
    const emptyBars = maxBars - filledBars; // 残りの空のバーの数

    const displayBars = `§c${'|'.repeat(filledBars)}§8${'|'.repeat(emptyBars)}`;

    player.onScreenDisplay.setActionBar(`§a${PROFESSION_DISPLAY_NAMES[profession]} §rLevel:§b${level} ${displayBars} §e+${gainedPoints}P`);
}

// レベルアップチェックとメッセージ
const playerPointsMap = new Map(); // プレイヤーごとのポイントを保持
function checkLevelUp(player, profession, levelUpActions, propertyKey, gainedPoints) {
    // 建築家はポイントレベルがないため、処理をスキップ
    if (profession === 'architect') {
        return;
    }

    const playerId = player.id; // プレイヤーごとに一意なIDを使用
    let currentActions = player.getDynamicProperty(`${propertyKey}_actions`) || 0;
    let totalPoints = playerPointsMap.get(playerId)?.totalPoints || 0;
    currentActions += 1;
    totalPoints += gainedPoints;

    const currentLevel = player.getDynamicProperty(propertyKey) || 1;
    const requiredActions = levelUpActions;

    player.setDynamicProperty(`${propertyKey}_actions`, currentActions);
    playerPointsMap.set(playerId, { totalPoints, lastAction: currentActions });

    // 2秒後にポイントをリセット（アクションバーは更新しない）
    system.runTimeout(() => {
        const currentData = playerPointsMap.get(playerId);
        if (currentData && currentData.lastAction === currentActions) {
            playerPointsMap.set(playerId, { totalPoints: 0, lastAction: currentActions });
        }
    }, 40); // 2秒（20tick * 2）

    if (currentActions >= requiredActions) {
        const newLevel = currentLevel + 1;
        player.setDynamicProperty(propertyKey, newLevel);
        player.setDynamicProperty(`${propertyKey}_actions`, 0);
        playerPointsMap.set(playerId, { totalPoints: gainedPoints, lastAction: 0 }); // 最後のgainedPointsを保持
        updateLevelDisplay(player, profession, newLevel, levelUpActions, 0, gainedPoints); // gainedPointsを表示

        player.sendMessage(`[§b職業システム§r] §e${PROFESSION_DISPLAY_NAMES[profession]}§aがレベル§c${newLevel}§aに到達`);
        player.playSound('random.toast', { pitch: 2.9, volume: 1.8 });

        config = getConfig();
        const availableLevels = Object.keys(config.levelRewards[profession]).map(Number);
        if (availableLevels.includes(newLevel)) {
            player.sendMessage(`[§b職業システム§r] §d報酬を受け取れます`);
        }
    } else {
        updateLevelDisplay(player, profession, currentLevel, levelUpActions, currentActions, totalPoints);
    }
}

// シルクタッチチェック
function hasSilkTouch(player) {
    const inventory = player.getComponent('minecraft:inventory');
    if (!inventory) return false;

    const item = inventory.container.getSlot(player.selectedSlotIndex).getItem();
    if (!item) return false;

    const enchantmentsComponent = item.getComponent('minecraft:enchantable');
    if (enchantmentsComponent === undefined) return false;

    const enchantments = enchantmentsComponent.getEnchantments();

    return enchantments.some(enchant => enchant.type.id === 'minecraft:silk_touch' || enchant.type.id === 'silk_touch');
}

// ピストンが近くにあるかチェックする関数 (半径2ブロック)
function isNearPiston(dimension, location) {
    const radius = 2; // 検知半径
    for (let x = -radius; x <= radius; x++) {
        for (let y = -radius; y <= radius; y++) {
            for (let z = -radius; z <= radius; z++) {
                try {
                    const block = dimension.getBlock({ x: location.x + x, y: location.y + y, z: location.z + z });

                    if (block && block.typeId.includes('piston')) {
                        return true;
                    }
                } catch (error) {
                    continue;
                }
            }
        }
    }
    return false;
}

function shouldProtectItem(itemEntity) {
    try {
        if (!itemEntity.isValid()) return false;
        const itemComp = itemEntity.getComponent('minecraft:item');
        if (!itemComp) return false;
        const itemStack = itemComp.itemStack;
        if (!itemStack) return false;

        // 1. 金床等で名付けられたアイテム
        if (itemStack.nameTag) return true;

        // 2. エンチャントが付いているアイテム
        const enchantable = itemStack.getComponent('minecraft:enchantable');
        if (enchantable && enchantable.getEnchantments().length > 0) return true;

        // 3. 耐久値を持つアイテム（武器・防具・ツール類全般）
        const durability = itemStack.getComponent('minecraft:durability');
        if (durability !== undefined) return true;

        // 4. 貴重品
        if (itemStack.typeId.includes('shulker_box') || itemStack.typeId.includes('totem_of_undying') || itemStack.typeId.includes('bundle')) {
            return true;
        }

        return false;
    } catch (e) {
        return false;
    }
}

const recentlySpawnedItemTicks = new Map();
const restrictedMobDeaths = [];

function cleanRestrictedMobDrops(deadEntity, radius = 3.5) {
    const dim = deadEntity.dimension;
    const loc = { x: deadEntity.location.x, y: deadEntity.location.y, z: deadEntity.location.z };
    const currentTick = system.currentTick;

    restrictedMobDeaths.push({
        dimensionId: dim.id,
        location: loc,
        tick: currentTick,
    });

    const executeCleanup = () => {
        const nowTick = system.currentTick;
        const nearbyItems = dim.getEntities({
            location: loc,
            maxDistance: radius,
            type: 'minecraft:item',
        });

        for (const item of nearbyItems) {
            if (shouldProtectItem(item)) continue;

            const spawnTick = recentlySpawnedItemTicks.get(item.id);
            if (spawnTick !== undefined && Math.abs(nowTick - spawnTick) <= 10) {
                try {
                    if (item.isValid()) {
                        item.remove();
                        recentlySpawnedItemTicks.delete(item.id);
                    }
                } catch (e) {}
            }
        }
        const nearbyXp = dim.getEntities({ location: loc, maxDistance: radius, type: 'minecraft:xp_orb' });
        for (const xp of nearbyXp) {
            try {
                if (xp.isValid()) xp.remove();
            } catch (e) {}
        }
    };
    executeCleanup();

    system.runTimeout(() => {
        executeCleanup();
    }, 2);
}

export function Business() {
    initializeConfig();
    config = getConfig();

    world.afterEvents.entitySpawn.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const { entity } = event;
        if ((entity.typeId !== 'minecraft:item' && entity.typeId !== 'minecraft:xp_orb') || !entity.isValid()) return;

        const currentTick = system.currentTick;

        recentlySpawnedItemTicks.set(entity.id, currentTick);

        for (const [id, tick] of recentlySpawnedItemTicks.entries()) {
            if (currentTick - tick > 100) {
                recentlySpawnedItemTicks.delete(id);
            }
        }

        for (let i = restrictedMobDeaths.length - 1; i >= 0; i--) {
            if (currentTick - restrictedMobDeaths[i].tick > 50) {
                restrictedMobDeaths.splice(i, 1);
            }
        }

        if (restrictedMobDeaths.length === 0) return;
        if (entity.typeId === 'minecraft:item' && shouldProtectItem(entity)) return;

        const itemLoc = entity.location;
        for (const death of restrictedMobDeaths) {
            if (death.dimensionId !== entity.dimension.id) continue;
            const dist = Math.hypot(itemLoc.x - death.location.x, itemLoc.y - death.location.y, itemLoc.z - death.location.z);
            if (dist <= 3.5) {
                system.run(() => {
                    try {
                        if (entity.isValid()) {
                            entity.remove();
                        }
                    } catch (e) {}
                });
                break;
            }
        }
    });

    // 家畜
    world.afterEvents.entityDie.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        // マグマなどによるキルを対策
        if (config.professions.livestock.limitEnabled && player?.typeId !== 'minecraft:player' && config.professions.livestock.items.includes(Entity.typeId)) {
            cleanRestrictedMobDrops(Entity, 3.5);
            return;
        }

        if (player?.typeId === 'minecraft:player' && config.professions.livestock.items.includes(Entity.typeId)) {
            if (config.professions.livestock.limitEnabled && !player.hasTag('livestock')) {
                cleanRestrictedMobDrops(Entity, 3.5);
                sendRestrictedMessage(player, `${PROFESSION_DISPLAY_NAMES.livestock}の職業に就いていないため、ドロップアイテムを取得できません`);
                return;
            }

            // ポイント付与
            if (config.professions.livestock.pointsEnabled && player.hasTag('livestock')) {
                if (isCamping(player)) {
                    return;
                }
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.livestock.points[Entity.typeId] ?? 10;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'livestock', config.professions.livestock.levelUpActions, 'livestock_level', points);
            }
        }
    });

    // 鉱石
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const blockTypeId = event.block.typeId;

        const key = `${event.block.x},${event.block.y},${event.block.z},${event.block.dimension.id}`;
        if (player?.typeId === 'minecraft:player' && config.professions.miner.items.includes(blockTypeId) && !hasSilkTouch(player)) {
            if (blockTypeId === 'minecraft:ancient_debris' && placedBlocks.has(key)) {
                placedBlocks.delete(key);
                placedBlocksChanged = true;
                return;
            }

            // 制限が有効で、プレイヤーが鉱夫職業に就いていない場合
            if (config.professions.miner.limitEnabled && !player.hasTag('miner')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_miner') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_miner') ?? 0;
                const maxBreaks = config.professions.miner.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.miner.limit.periodDays * 24 * 60 * 60 * 1000;

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_miner', breakCount);
                    player.setDynamicProperty('lastReset_miner', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    system.runTimeout(() => {
                        const entities = player.dimension.getEntities({
                            location: { x: event.block.x + 0.5, y: event.block.y + 0.5, z: event.block.z + 0.5 },
                            maxDistance: 2,
                            type: 'minecraft:item',
                        });

                        for (const item of entities) {
                            try {
                                if (item.isValid()) {
                                    item.remove();
                                }
                            } catch (error) {
                                console.warn(`アイテム削除エラー: ${error.message}`);
                            }
                        }
                        sendRestrictedMessage(player, `${config.professions.miner.limit.periodDays}日間で${maxBreaks}個の制限を超えたため、アイテムはドロップしません`);
                    }, 2);
                    return; // ポイント付与も行わない
                } else {
                    // 破壊を許可し、カウントを増やす
                    breakCount++;
                    player.setDynamicProperty('breakCount_miner', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 鉱石ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
                placedBlocks.delete(key);
                placedBlocksChanged = true;
            }

            // ポイント付与が有効な場合
            if (config.professions.miner.pointsEnabled && player.hasTag('miner')) {
                system.run(() => {
                    if (isCamping(player)) {
                        return;
                    }
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.professions.miner.points[blockTypeId] ?? 20;
                    objective.addScore(player.scoreboardIdentity, points);
                    checkLevelUp(player, 'miner', config.professions.miner.levelUpActions, 'miner_level', points);
                });
            } else if (config.professions.miner.limitEnabled && !player.hasTag('miner')) {
                // 制限有効で職業に就いていない場合、アイテムを削除
                system.runTimeout(() => {
                    const entities = player.dimension.getEntities({
                        location: { x: event.block.location.x + 0.5, y: event.block.location.y + 0.5, z: event.block.location.z + 0.5 },
                        maxDistance: 2,
                        type: 'minecraft:item',
                    });
                    for (const item of entities) {
                        try {
                            if (item.isValid()) {
                                item.remove();
                            }
                        } catch (error) {
                            console.warn(`アイテム削除エラー: ${error.message}`);
                        }
                    }
                    sendRestrictedMessage(player, '鉱夫の職業に就いていないため、鉱石のドロップアイテムを取得できません');
                }, 2); // 2ティック遅延（アイテムスポーンを待つ）
            }
        }
    });

    // 林業 (builderタグを使用)
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;
        const placedTimestamp = placedBlocks.get(key);

        if (config.professions.builder.items.includes(blockTypeId)) {
            // 制限が有効で、プレイヤーが林業職業に就いていない場合
            if (config.professions.builder.limitEnabled && !player.hasTag('builder')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_builder') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_builder') ?? 0;
                const maxBreaks = config.professions.builder.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.builder.limit.periodDays * 24 * 60 * 60 * 1000;

                // 自分で設置したブロックで、免除期間内かチェック
                if (placedTimestamp && currentTick - placedTimestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return; // 破壊を許可（カウントなし）
                }

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_builder', breakCount);
                    player.setDynamicProperty('lastReset_builder', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    system.runTimeout(() => {
                        const entities = player.dimension.getEntities({
                            location: { x: block.x + 0.5, y: block.y + 0.5, z: block.z + 0.5 },
                            maxDistance: 2,
                            type: 'minecraft:item',
                        });

                        for (const item of entities) {
                            try {
                                if (item.isValid()) {
                                    item.remove();
                                }
                            } catch (error) {
                                console.warn(`アイテム削除エラー: ${error.message}`);
                            }
                        }
                        sendRestrictedMessage(player, `${config.professions.builder.limit.periodDays}日間で${maxBreaks}個の制限を超えたため、アイテムはドロップしません`);
                    }, 2);
                    return;
                } else {
                    // 破壊を許可し、カウントを増やす
                    breakCount++;
                    player.setDynamicProperty('breakCount_builder', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 原木破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }

            // ポイント付与が有効な場合
            if (config.professions.builder.pointsEnabled && player.hasTag('builder') && !placedTimestamp) {
                if (isNearPiston(block.dimension, block.location)) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return; // 制限チェックもポイント付与もせず終了
                }
                if (isCamping(player)) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return;
                }
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.builder.points[blockTypeId] ?? 3;
                system.run(() => {
                    objective.addScore(player.scoreboardIdentity, points);
                    checkLevelUp(player, 'builder', config.professions.builder.levelUpActions, 'builder_level', points);
                });
            }
            placedBlocks.delete(key);
            placedBlocksChanged = true;
        }
    });

    // 農業
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block; // beforeEventsではblockプロパティから情報を取得
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`; // 設置ブロック判定用
        const blockPermutation = block.permutation;

        if (config.professions.farming.items.includes(blockTypeId)) {
            // 制限が有効で、プレイヤーが農業職業に就いていない場合
            if (config.professions.farming.limitEnabled && !player.hasTag('farming')) {
                event.cancel = true; // 破壊をキャンセル
                system.run(() => {
                    sendRestrictedMessage(player, '農業の職業に就いていないため、作物を収穫できません');
                });
                return;
            }
        }
    });

    world.afterEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const brokenBlockPermutation = event.brokenBlockPermutation;
        const blockTypeId = brokenBlockPermutation.type.id;
        const key = `${event.block.x},${event.block.y},${event.block.z},${event.block.dimension.id}`; // 設置ブロック判定用
        const isMatureCrop = (brokenBlockPermutation.getTags().includes(`minecraft:crop`) && brokenBlockPermutation.getState(`growth`) == 7) || (blockTypeId === `minecraft:cocoa` && brokenBlockPermutation.getState(`age`) === 2);
        const isNonGrowthBlock = brokenBlockPermutation.getState(`growth`) === undefined; // 'growth'がないブロック（カボチャ、スイカ、サトウキビなど）

        if (config.professions.farming.items.includes(blockTypeId)) {
            if (config.professions.farming.pointsEnabled && player.hasTag('farming') && (isMatureCrop || (isNonGrowthBlock && !placedBlocks.has(key)))) {
                if (isCamping(player)) {
                    placedBlocks.delete(key); // 削除
                    placedBlocksChanged = true;
                    return;
                }
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.farming.points[blockTypeId] ?? 5;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'farming', config.professions.farming.levelUpActions, 'farming_level', points);
            }
            placedBlocks.delete(key);
            placedBlocksChanged = true;
        }
    });

    // プレイヤーがブロックを設置したときに追跡
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;

        // 農業または建築家のアイテムリストに含まれるブロックを追跡
        if (
            config.professions.farming.items.includes(block.typeId) ||
            config.professions.architect.items.includes(block.typeId) ||
            config.professions.builder.items.includes(block.typeId) || // 林業
            config.professions.land_leveling.items.includes(block.typeId) || // 整地
            block.typeId === 'minecraft:ancient_debris' //鉱夫
        ) {
            placedBlocks.set(key, Date.now());
            placedBlocksChanged = true;
        }

        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        // 建築家 (architect) のブロック設置制限（既存のコードはそのまま）
        if (config.professions.architect.items.includes(block.typeId)) {
            if (config.professions.architect.limitEnabled && !player.hasTag('architect')) {
                const currentTick = Date.now();
                let placeCount = player.getDynamicProperty('placeCount_architect') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_architect') ?? 0;
                const maxPlaces = config.professions.architect.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;

                // リセットチェック
                if (currentTick - lastReset >= periodMs) {
                    placeCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('placeCount_architect', placeCount);
                    player.setDynamicProperty('lastReset_architect', lastReset);
                }

                // 上限チェック
                if (maxPlaces > 0 && placeCount >= maxPlaces) {
                    // ブロックをairに置き換える
                    system.run(() => {
                        block.setType('minecraft:air');
                        sendRestrictedMessage(player, `${config.professions.architect.limit.periodDays}日間で${maxPlaces}個まで装飾ブロックを設置できます`);
                    });
                } else {
                    placeCount++;
                    player.setDynamicProperty('placeCount_architect', placeCount);
                    system.run(() => {
                        if (placeCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 装飾ブロック設置: ${placeCount}/${maxPlaces}`);
                        }
                    });
                }
            }
        }
    });

    // 建築家 (architect) のブロック破壊制限
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return; // 全体システムが無効なら処理しない

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;
        const placedTimestamp = placedBlocks.get(key);

        if (config.professions.architect.items.includes(blockTypeId)) {
            if (config.professions.architect.limitEnabled && !player.hasTag('architect')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_architect') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_architect') ?? 0;
                const maxBreaks = config.professions.architect.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;

                // 自分で設置したブロックで、免除期間内かチェック
                if (placedTimestamp && currentTick - placedTimestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return; // 破壊を許可（カウントなし）
                }

                // リセットチェック
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_architect', breakCount);
                    player.setDynamicProperty('lastReset_architect', lastReset);
                }

                // 上限チェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true;
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.architect.limit.periodDays}日間で${maxBreaks}個まで装飾ブロックを破壊できます`);
                    });
                    return;
                } else {
                    breakCount++;
                    player.setDynamicProperty('breakCount_architect', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 装飾ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }
            placedBlocks.delete(key);
            placedBlocksChanged = true;
        }
    });

    // 整地
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const player = event.player;
        const block = event.block;
        const blockTypeId = block.typeId;
        const key = `${block.x},${block.y},${block.z},${block.dimension.id}`;
        const placedTimestamp = placedBlocks.get(key);

        if (config.professions.land_leveling.items.includes(blockTypeId)) {
            if (config.professions.land_leveling.limitEnabled && !player.hasTag('land_leveling')) {
                const currentTick = Date.now();
                let breakCount = player.getDynamicProperty('breakCount_land_leveling') ?? 0;
                let lastReset = player.getDynamicProperty('lastReset_land_leveling') ?? 0;
                const maxBreaks = config.professions.land_leveling.limit.maxBreaksPerPeriod;
                const periodMs = config.professions.land_leveling.limit.periodDays * 24 * 60 * 60 * 1000;

                if (placedTimestamp && currentTick - placedTimestamp <= BLOCK_EXPIRY_MS) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return;
                }

                // リセット期間の確認
                if (currentTick - lastReset >= periodMs) {
                    breakCount = 0;
                    lastReset = currentTick;
                    player.setDynamicProperty('breakCount_land_leveling', breakCount);
                    player.setDynamicProperty('lastReset_land_leveling', lastReset);
                }

                // 破壊カウントをチェック
                if (maxBreaks > 0 && breakCount >= maxBreaks) {
                    event.cancel = true;
                    system.run(() => {
                        sendRestrictedMessage(player, `${config.professions.land_leveling.limit.periodDays}日間で${maxBreaks}個まで土ブロックを破壊できます`);
                    });
                    return;
                } else {
                    breakCount++;
                    player.setDynamicProperty('breakCount_land_leveling', breakCount);
                    system.run(() => {
                        if (breakCount % 10 === 0) {
                            player.sendMessage(`[§b職業システム§r] 土ブロック破壊: ${breakCount}/${maxBreaks}`);
                        }
                    });
                }
            }

            // ポイント付与が有効な場合
            if (config.professions.land_leveling.pointsEnabled && player.hasTag('land_leveling') && !placedTimestamp) {
                if (isNearPiston(block.dimension, block.location)) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return;
                }
                if (isCamping(player)) {
                    placedBlocks.delete(key);
                    placedBlocksChanged = true;
                    return;
                }
                let breakCountPoints = player.getDynamicProperty('breakCountPoints_land_leveling') ?? 0;
                breakCountPoints++;
                player.setDynamicProperty('breakCountPoints_land_leveling', breakCountPoints);

                // pointsPerBreaksごとにポイントを付与
                const pointsPerBreaks = config.professions.land_leveling.pointsPerBreaks || 10;
                if (breakCountPoints >= pointsPerBreaks) {
                    const objective = world.scoreboard.getObjective(objectiveName);
                    const points = config.professions.land_leveling.points[blockTypeId] ?? 1;
                    system.run(() => {
                        objective.addScore(player.scoreboardIdentity, points);
                        checkLevelUp(player, 'land_leveling', config.professions.land_leveling.levelUpActions, 'land_leveling_level', points);
                    });
                    breakCountPoints = 0; // リセット
                    player.setDynamicProperty('breakCountPoints_land_leveling', breakCountPoints);
                }
                placedBlocks.delete(key);
                placedBlocksChanged = true;
            }
        }
    });

    // 冒険家
    world.afterEvents.entityDie.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const player = event.damageSource.damagingEntity;
        const Entity = event.deadEntity;

        if (player?.typeId === 'minecraft:player' && config.professions.adventurer.items.includes(Entity.typeId)) {
            if (config.professions.adventurer.limitEnabled && !player.hasTag('adventurer')) {
                cleanRestrictedMobDrops(Entity, 3.5);
                sendRestrictedMessage(player, `${PROFESSION_DISPLAY_NAMES.adventurer}の職業に就いていないため、ドロップアイテムを取得できません`);
                return;
            }

            // ポイント付与
            if (config.professions.adventurer.pointsEnabled && player.hasTag('adventurer')) {
                if (isCamping(player)) {
                    return;
                }
                const objective = world.scoreboard.getObjective(objectiveName);
                const points = config.professions.adventurer.points[Entity.typeId] ?? 10;
                objective.addScore(player.scoreboardIdentity, points);
                checkLevelUp(player, 'adventurer', config.professions.adventurer.levelUpActions, 'adventurer_level', points);
            }
        }
    });

    // 釣り人
    const recentRodUses = new Map();
    const fishingHookOwners = new Map();
    const recentlyRemovedHooks = [];

    // 釣り竿使用イベント
    world.beforeEvents.itemUse.subscribe(ev => {
        if (!config.system.businessSystemEnabled) return;

        const { source, itemStack } = ev;
        if (source.typeId !== 'minecraft:player' || itemStack.typeId !== 'minecraft:fishing_rod') return;

        if (config.professions.Angler.limitEnabled && !source.hasTag('Angler')) {
            ev.cancel = true;
            system.run(() => {
                sendRestrictedMessage(source, '釣り人の職業に就いていないため、釣り竿を使用できません');
            });
            return;
        }

        if (source.hasTag('Angler')) {
            recentRodUses.set(source.id, {
                player: source,
                tick: system.currentTick,
                location: { ...source.location },
            });
        }
    });

    // フックスポーンイベント
    world.afterEvents.entitySpawn.subscribe(ev => {
        if (!config.system.businessSystemEnabled) return;

        const { entity } = ev;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        try {
            const projectileComp = entity.getComponent('minecraft:projectile');
            if (projectileComp?.owner && projectileComp.owner.typeId === 'minecraft:player') {
                const owner = projectileComp.owner;
                fishingHookOwners.set(entity.id, {
                    playerId: owner.id,
                    playerName: owner.name,
                });
                return;
            }
        } catch (e) {}

        const currentTick = system.currentTick;
        let matchedPlayer = null;
        let minDistance = Infinity;

        for (const [playerId, data] of recentRodUses.entries()) {
            if (currentTick - data.tick <= 5) {
                const dist = Math.hypot(data.location.x - entity.location.x, data.location.y - entity.location.y, data.location.z - entity.location.z);
                if (dist < 3.5 && dist < minDistance) {
                    minDistance = dist;
                    matchedPlayer = data.player;
                }
            } else if (currentTick - data.tick > 60) {
                recentRodUses.delete(playerId);
            }
        }

        if (!matchedPlayer) {
            const nearbyPlayers = entity.dimension.getPlayers({
                location: entity.location,
                maxDistance: 3.5,
            });
            for (const p of nearbyPlayers) {
                if (p.hasTag('Angler')) {
                    matchedPlayer = p;
                    break;
                }
            }
        }

        if (matchedPlayer) {
            fishingHookOwners.set(entity.id, {
                playerId: matchedPlayer.id,
                playerName: matchedPlayer.name,
            });
        }
    });

    // フック削除イベント
    world.beforeEvents.entityRemove.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const entity = event.removedEntity;
        if (entity.typeId !== 'minecraft:fishing_hook') return;

        const ownerData = fishingHookOwners.get(entity.id);
        if (!ownerData) return;

        fishingHookOwners.delete(entity.id);

        let isNearWater = false;
        const fx = Math.floor(entity.location.x);
        const fy = Math.floor(entity.location.y);
        const fz = Math.floor(entity.location.z);

        for (let dx = -1; dx <= 1 && !isNearWater; dx++) {
            for (let dy = -1; dy <= 1 && !isNearWater; dy++) {
                for (let dz = -1; dz <= 1 && !isNearWater; dz++) {
                    try {
                        const b = entity.dimension.getBlock({ x: fx + dx, y: fy + dy, z: fz + dz });
                        if (b && (b.typeId === 'minecraft:water' || b.typeId === 'minecraft:lava' || b.permutation.getState('waterlogged') === true)) {
                            isNearWater = true;
                        }
                    } catch (e) {}
                }
            }
        }

        if (!isNearWater) {
            return;
        }

        const player = world.getAllPlayers().find(p => p.id === ownerData.playerId);

        const record = {
            playerId: ownerData.playerId,
            playerName: ownerData.playerName,
            hookLocation: { x: entity.location.x, y: entity.location.y, z: entity.location.z },
            playerLocation: player ? { x: player.location.x, y: player.location.y, z: player.location.z } : null,
            timestamp: Date.now(),
        };

        recentlyRemovedHooks.push(record);

        system.runTimeout(() => {
            const index = recentlyRemovedHooks.indexOf(record);
            if (index !== -1) {
                recentlyRemovedHooks.splice(index, 1);
            }
        }, 40);
    });

    // アイテムスポーンイベント
    world.afterEvents.entitySpawn.subscribe(event => {
        if (!config.system.businessSystemEnabled) return;

        const { entity } = event;
        if (entity.typeId !== 'minecraft:item' || !entity.isValid()) return;

        const itemComponent = entity.getComponent('minecraft:item');
        if (!itemComponent) return;
        const itemStack = itemComponent.itemStack;

        if (!config.professions.Angler.items.includes(itemStack.typeId)) {
            return;
        }

        const itemLoc = entity.location;

        let isNearFishingSpot = false;
        const ix = Math.floor(itemLoc.x);
        const iy = Math.floor(itemLoc.y);
        const iz = Math.floor(itemLoc.z);

        for (let dx = -1; dx <= 1 && !isNearFishingSpot; dx++) {
            for (let dy = -1; dy <= 1 && !isNearFishingSpot; dy++) {
                for (let dz = -1; dz <= 1 && !isNearFishingSpot; dz++) {
                    try {
                        const b = entity.dimension.getBlock({ x: ix + dx, y: iy + dy, z: iz + dz });
                        if (b && (b.typeId === 'minecraft:water' || b.typeId === 'minecraft:lava' || b.typeId.includes('hopper') || b.permutation.getState('waterlogged') === true)) {
                            isNearFishingSpot = true;
                        }
                    } catch (e) {}
                }
            }
        }

        if (!isNearFishingSpot) {
            return;
        }

        const now = Date.now();

        // 直近に消えたフック照合
        let matchedIndex = -1;
        let targetPlayer = null;

        for (let i = recentlyRemovedHooks.length - 1; i >= 0; i--) {
            const evidence = recentlyRemovedHooks[i];

            if (now - evidence.timestamp > 2000) continue;

            const distToHook = Math.hypot(itemLoc.x - evidence.hookLocation.x, itemLoc.y - evidence.hookLocation.y, itemLoc.z - evidence.hookLocation.z);

            let distToPlayer = Infinity;
            if (evidence.playerLocation) {
                distToPlayer = Math.hypot(itemLoc.x - evidence.playerLocation.x, itemLoc.y - evidence.playerLocation.y, itemLoc.z - evidence.playerLocation.z);
            }

            if (distToHook <= 5.0 || distToPlayer <= 8.0) {
                targetPlayer = world.getAllPlayers().find(p => p.id === evidence.playerId);
                if (targetPlayer) {
                    matchedIndex = i;
                    break;
                }
            }
        }

        if (targetPlayer && matchedIndex !== -1) {
            recentlyRemovedHooks.splice(matchedIndex, 1);

            // 釣り人職業のポイント付与
            if (targetPlayer.hasTag('Angler')) {
                if (config.professions.Angler.pointsEnabled) {
                    system.run(() => {
                        const objective = world.scoreboard.getObjective(objectiveName);
                        const points = config.professions.Angler.points[itemStack.typeId] ?? 10;
                        objective.addScore(targetPlayer.scoreboardIdentity, points);
                        checkLevelUp(targetPlayer, 'Angler', config.professions.Angler.levelUpActions, 'Angler_level', points);
                    });
                }
            } else {
                if (config.professions.Angler.limitEnabled) {
                    try {
                        entity.remove();
                    } catch (e) {}
                    sendRestrictedMessage(targetPlayer, '釣り人の職業に就いていないため、ドロップアイテムを取得できません');
                }
            }
        }
    });

    // 定期的にリセット確認 (鉱夫、林業、建築家、整地)
    system.runInterval(
        () => {
            const currentTick = Date.now();
            for (const player of world.getAllPlayers()) {
                // 鉱夫のリセット
                if (config.professions.miner.limitEnabled) {
                    let lastResetMiner = player.getDynamicProperty('lastReset_miner') ?? 0;
                    const periodMsMiner = config.professions.miner.limit.periodDays * 24 * 60 * 60 * 1000;
                    if (currentTick - lastResetMiner >= periodMsMiner) {
                        player.setDynamicProperty('breakCount_miner', 0);
                        player.setDynamicProperty('lastReset_miner', currentTick);
                    }
                }

                // 林業のリセット (builderタグを使用)
                if (config.professions.builder.limitEnabled) {
                    let lastResetBuilder = player.getDynamicProperty('lastReset_builder') ?? 0;
                    const periodMsBuilder = config.professions.builder.limit.periodDays * 24 * 60 * 60 * 1000;
                    if (currentTick - lastResetBuilder >= periodMsBuilder) {
                        player.setDynamicProperty('placeCount_builder', 0);
                        player.setDynamicProperty('breakCount_builder', 0);
                        player.setDynamicProperty('lastReset_builder', currentTick);
                    }
                }

                // 建築家 (architect) のリセット
                if (config.professions.architect.limitEnabled) {
                    let lastResetArchitect = player.getDynamicProperty('lastReset_architect') ?? 0;
                    const periodMsArchitect = config.professions.architect.limit.periodDays * 24 * 60 * 60 * 1000;
                    if (currentTick - lastResetArchitect >= periodMsArchitect) {
                        player.setDynamicProperty('placeCount_architect', 0);
                        player.setDynamicProperty('breakCount_architect', 0);
                        player.setDynamicProperty('lastReset_architect', currentTick);
                    }
                }

                // 整地 (land_leveling) のリセット
                if (config.professions.land_leveling.limitEnabled) {
                    let lastResetLandLeveling = player.getDynamicProperty('lastReset_land_leveling') ?? 0;
                    const periodMsLandLeveling = config.professions.land_leveling.limit.periodDays * 24 * 60 * 60 * 1000;
                    if (currentTick - lastResetLandLeveling >= periodMsLandLeveling) {
                        player.setDynamicProperty('breakCount_land_leveling', 0);
                        player.setDynamicProperty('lastReset_land_leveling', currentTick);
                    }
                }
            }
        },
        20 * 60 * 60,
    ); // 1時間ごとにチェック
}
