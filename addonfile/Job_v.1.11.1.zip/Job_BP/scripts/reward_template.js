//※本ファイル(reward_template.js)のみ編集許可 / HARUAddons
//(未設定の職業、レベルは除外して問題ありません)
//例>>> 100: { effect: { id: 'speed', amplifier: 1 }, money: 1000, items: [{ id: 'minecraft:cooked_beef', amount: 32 }]},
export const REWARD_TEMPLATE = {
    livestock: {
        60: { effect: { id: 'speed', amplifier: 0 }, money: 0, items: [] },
        120: { effect: { id: 'speed', amplifier: 1 }, money: 0, items: [] },
        180: { effect: { id: 'speed', amplifier: 2 }, money: 0, items: [] },
    },
    miner: {
        60: { effect: { id: 'haste', amplifier: 0 }, money: 0, items: [] },
        120: { effect: { id: 'haste', amplifier: 1 }, money: 0, items: [] },
        180: { effect: { id: 'haste', amplifier: 2 }, money: 0, items: [] },
        250: { effect: { id: 'night_vision', amplifier: 0 }, money: 0, items: [] },
    },
    builder: {
        100: { effect: { id: 'haste', amplifier: 0 }, money: 0, items: [] },
        200: { effect: { id: 'haste', amplifier: 1 }, money: 0, items: [] },
        300: { effect: { id: 'haste', amplifier: 2 }, money: 0, items: [] },
    },
    farming: {
        200: { effect: { id: 'speed', amplifier: 0 }, money: 0, items: [] },
        400: { effect: { id: 'speed', amplifier: 1 }, money: 0, items: [] },
        600: { effect: { id: 'speed', amplifier: 2 }, money: 0, items: [] },
    },
    adventurer: {
        80: { effect: { id: 'health_boost', amplifier: 0 }, money: 0, items: [] },
        160: { effect: { id: 'health_boost', amplifier: 1 }, money: 0, items: [] },
        240: { effect: { id: 'health_boost', amplifier: 2 }, money: 0, items: [] },
        400: { effect: { id: 'night_vision', amplifier: 0 }, money: 0, items: [] },
    },
    Angler: {
        50: { effect: { id: 'speed', amplifier: 0 }, money: 0, items: [] },
        100: { effect: { id: 'water_breathing', amplifier: 0 }, money: 0, items: [] },
        150: { effect: { id: 'conduit_power', amplifier: 0 }, money: 0, items: [] },
    },
};
