import { world, system, ItemStack } from '@minecraft/server';
import { Business, initializeConfig } from './system/system'; // initializeConfigをインポート
import { showPlayerUI } from './system/ui';
import { First_grant } from './system/First_grant';

//====初期設定====
// HARUPhone1_Systemの初期設定はそのまま
if (world.getDynamicProperty('HARUPhone1_System') == undefined) {
    world.setDynamicProperty('HARUPhone1_System', true);
}
// system.jsで設定を初期化する関数を呼び出す
initializeConfig();
//===============

export var playerHARUAppsOpen = {};
//スクリプトイベント
const RACE_EVENT_ID = 'haruapps:job';
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            showPlayerUI(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }

        if (eventData.id === 'op:job') {
            playerHARUAppsOpen[player.id] = false;
            player.addTag('HARUPhoneOP');
            world.setDynamicProperty('Job_Start', true);
            world.setDynamicProperty('HARUPhone1_System', false);
            const objectives = world.scoreboard.getObjectives();
            const moneyObjective = objectives.find(obj => obj.id === 'money');
            if (!moneyObjective) {
                world.scoreboard.addObjective('money', '所持金');
            }

            const players = world.getAllPlayers();
            for (const player of players) {
                if (world.getDynamicProperty('Job_Start') === true && !player.hasTag('HARUPAY_Member')) {
                    player.getComponent('inventory').container.addItem(new ItemStack('additem:job', 1));
                    player.runCommand(`scoreboard players add @s money 0`);
                    player.addTag('HARUPAY_Member');
                }
            }
            showPlayerUI(player);
        }

        if (eventData.id === 'stop:job') {
            world.setDynamicProperty('Job_Start', false);
            player.sendMessage('§r[§b職業システム§r] §a自動付与システムを無効にしました');
        }

        if (eventData.id === 'haruphone:job') {
            world.setDynamicProperty('HARUPhone1_System', true);
            player.sendMessage('§r[§b職業システム§r] §aHARUPhone1連携をONにしました');
        }
    });
});

system.runTimeout(() => {
    const overworld = world.getDimension('overworld');
    overworld.runCommand(`scriptevent haruapps:push §1職業 scriptevent ${RACE_EVENT_ID}`);
}, 20);

world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    system.run(() => {
        if (eventData.itemStack.typeId === 'additem:job') {
            playerHARUAppsOpen[player.id] = false;
            showPlayerUI(player);
        }
    });
});

//スクリプト読み込み
Business();
First_grant();
