import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { transferPlayer } from '@minecraft/server-admin';

import { config } from './config.js';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'servertransfer:ui') {
        const selector = eventData.message.trim();
        if (!selector) {
            console.warn(`[ServerTransfer] エラー: /scriptevent servertransfer:ui <selector|playerName> の形式で指定してください。入力: ${eventData.message}`);
            return;
        }

        const targetPlayers = parseSelector(selector);
        if (targetPlayers.length === 0) {
            console.warn(`[ServerTransfer] セレクター "${selector}" に一致するプレイヤーが見つかりませんでした。`);
            return;
        }
        system.run(async () => {
            targetPlayers.forEach(player => {
                try {
                    const form = new ActionFormData().title('§0サーバー移動').body('>>>§e選択してください');
                    for (const server of config) {
                        form.button(`§1${server.name}`, 'textures/ui/bubble_empty');
                    }
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        }
                        const selection = r.selection;
                        const selectedServer = config[selection];
                        transferPlayer(player, { hostname: selectedServer.ip, port: selectedServer.port });
                    });
                } catch (error) {
                    console.error('サーバー転送フォームの処理中にエラーが発生しました:', error);
                }
            });
        });
    }
});

//セレクター
function parseSelector(selector) {
    if (!selector) return [];

    var players = [];
    for (const player of world.getPlayers()) {
        for (const Name of selector.split(', ')) {
            if (Name == player.name) {
                players.push(player);
            }
        }
    }
    return players;
}
