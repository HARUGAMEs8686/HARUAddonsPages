import { world, system, BlockInventoryComponent, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// DynamicPropertiesのプレフィックス
const OWNER_PREFIX = "penjualan:owner:";
const PRICE_PREFIX = "penjualan:price:";
const REVENUE_PREFIX = "penjualan:revenue:";
const DISPLAY_NAME_PREFIX = "penjualan:displayName:";

// スコアボードの設定
const MONEY_OBJECTIVE = "money";

// ショップブロックと樽のID
const SHOP_BLOCK = "addblock:penjualan";
const BARREL_BLOCK = "minecraft:barrel";

// クールダウン設定（ミリ秒）
const COOLDOWN_MS = 1000;

// プレイヤーのインタラクションクールダウンを管理
const interactionCooldowns = new Map();

// エンチャント情報を文字列として取得
function getEnchantmentString(itemStack) {
  const enchantable = itemStack.getComponent("minecraft:enchantable");
  if (!enchantable) return "";
  const enchantments = enchantable.getEnchantments();
  if (enchantments.length === 0) return "";
  return enchantments
    .map(e => `${e.type.id.replace("minecraft:", "")}${e.level}`)
    .sort()
    .join(",");
}

// エンチャントに基づく一意のキーを作成
function getItemUniqueKey(itemStack) {
  const enchantString = getEnchantmentString(itemStack);
  return enchantString ? `${itemStack.typeId}:${enchantString}` : itemStack.typeId;
}

// アイテムの表示名を取得（カスタム優先、エンチャント情報含む）
function getItemDisplayName(block, itemStack) {
  const key = getLocationKey(block.location);
  const uniqueKey = getItemUniqueKey(itemStack);
  const customName = world.getDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`);
  const enchantString = getEnchantmentString(itemStack);
  const baseName = customName || itemStack.typeId.split("minecraft:")[1] || itemStack.typeId;
  return enchantString ? `${baseName} (${enchantString})` : baseName;
}

// アイテムの価格を取得
function getItemPRICE(block, itemStack) {
  const key = getLocationKey(block.location);
  const uniqueKey = getItemUniqueKey(itemStack);
  const customPRICE = Number(world.getDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`));
  return customPRICE || 0;
}

// 座標をキーとして変換（x:y:z形式）
function getLocationKey(location) {
  return `${location.x}:${location.y}:${location.z}`;
}

// プレイヤーのインベントリに空きがあるかチェック
function hasEnoughInventorySpace(player, quantity, itemStack) {
  const inventory = player.getComponent("minecraft:inventory").container;
  let emptySlots = 0;

  for (let i = 0; i < inventory.size; i++) {
    if (!inventory.getItem(i)) {
      emptySlots++;
    }
  }

  // アイテムのスタック上限を考慮して必要なスロット数を計算
  const maxStack = itemStack.maxAmount || 64;
  return emptySlots >= Math.ceil(quantity / maxStack);
}

// ショップブロックのインタラクト処理
// ショップブロックおよび樽のインタラクト処理
export function registerShopInteractions() {
  // ショップブロックのインタラクト処理
  world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { player, block } = event;
    if (block.typeId !== SHOP_BLOCK) return;

    // キャンセルしてデフォルト動作を防ぐ
    event.cancel = true;

    // クールダウンチェック
    const locationKey = getLocationKey(block.location);
    const playerId = player.id;
    const now = Date.now();
    const cooldownData = interactionCooldowns.get(playerId);

    if (cooldownData && cooldownData.location === locationKey && now - cooldownData.lastInteraction < COOLDOWN_MS) {
      return; // クールダウン中の場合はスキップ
    }

    // クールダウンデータを更新
    interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

    system.run(() => {
      handleShopInteraction(player, block);
    });
  });

  // 樽へのインタラクトを制限
  world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { player, block } = event;
    if (block.typeId !== BARREL_BLOCK) return;

    // 樽の1ブロック上に自動販売機があるか確認
    const shopBlock = block.above();
    if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

    // 自動販売機の所有者を取得
    const key = getLocationKey(shopBlock.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

    // 所有者でない場合、アクセスをキャンセル（メッセージにクールダウン適用）
    if (!(player.hasTag('HARUPhoneOP')) && (ownerName !== player.name)) {
      event.cancel = true;

      // クールダウンチェック
      const locationKey = getLocationKey(block.location);
      const playerId = player.id;
      const now = Date.now();
      const cooldownData = interactionCooldowns.get(playerId);

      if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
        // クールダウンデータを更新
        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

        system.run(() => {
          player.sendMessage(`§r[§b自動販売機§r] §4この樽には設置者しかアクセスできません`);
          player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
          });
        });
      }
    }
  });

  // ブロック設置時に所有者を記録
  world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const { block, player } = event;
    if (block.typeId !== SHOP_BLOCK) return;

    const key = getLocationKey(block.location);
    world.setDynamicProperty(`${OWNER_PREFIX}${key}`, player.name);
    world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
  });

  // 設置者以外による自動販売機の破壊を防ぎ、設置者の場合は売り上げ取得とクリーンアップ
  world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { block, player } = event;
    if (block.typeId !== SHOP_BLOCK) return;

    const key = getLocationKey(block.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

    // 設置者でない場合、破壊をキャンセル（メッセージにクールダウン適用）
    if (!(player.hasTag('HARUPhoneOP')) && (ownerName !== player.name)) {
      event.cancel = true;

      // クールダウンチェック
      const locationKey = getLocationKey(block.location);
      const playerId = player.id;
      const now = Date.now();
      const cooldownData = interactionCooldowns.get(playerId);

      if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
        // クールダウンデータを更新
        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

        system.run(() => {
          player.sendMessage(`§r[§b自動販売機§r] §4この自動販売機は設置者しか破壊できません`);
          player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
          });
        });
      }
      return;
    }

    system.run(() => {
      // 収益受け取り
      receiveRevenue_BreakBlock(player, block);

      // Dynamic Propertiesをクリーンアップ
      world.setDynamicProperty(`${OWNER_PREFIX}${key}`, undefined);
      world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, undefined);

      const barrelBlock = block.below();
      if (barrelBlock && barrelBlock.typeId === BARREL_BLOCK) {
        const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
        if (inventoryComponent && inventoryComponent.container) {
          const items = getInventoryItems(inventoryComponent.container);
          items.forEach((item) => {
            const uniqueKey = getItemUniqueKey(item.itemStack);
            world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, undefined);
            world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, undefined);
          });
        }
      }
    });
  });

  // 収益受け取り
  async function receiveRevenue_BreakBlock(player, block) {
    const key = getLocationKey(block.location);
    const revenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
    if (revenue === 0) {
      return;
    }

    const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
    if (!objective) {
      player.sendMessage(`§r[§b自動販売機§r] §4スコアボード 'money' が見つかりません`);
      player.playSound("random.toast", {
        pitch: 0.4,
        volume: 1.0
      });
      return;
    }

    objective.addScore(player, revenue);
    world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
    player.sendMessage(`§r[§b自動販売機§r] §a売上§c${revenue}§aを回収し、データを初期化しました`);
    player.playSound("random.toast", {
      pitch: 1.7,
      volume: 1.0
    });
  }

  // 設置者以外による樽の破壊を防ぐ
  world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { block, player } = event;
    if (block.typeId !== BARREL_BLOCK) return;

    // 樽の1ブロック上に自動販売機があるか確認
    const shopBlock = block.above();
    if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

    // 自動販売機の所有者を取得
    const key = getLocationKey(shopBlock.location);
    const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);

    if (!(player.hasTag('HARUPhoneOP')) && (ownerName !== player.name)) {
      event.cancel = true;

      const locationKey = getLocationKey(block.location);
      const playerId = player.id;
      const now = Date.now();
      const cooldownData = interactionCooldowns.get(playerId);

      if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
        interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

        system.run(() => {
          player.sendMessage(`§r[§b自動販売機§r] §4この樽は設置者しか破壊できません`);
          player.playSound("random.toast", {
            pitch: 0.4,
            volume: 1.0
          });
        });
      }
    }
  });

  // 樽の下にホッパーを置けないようにする
  world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const { block, player } = event;
    if (block.typeId !== "minecraft:hopper") return;

    // ホッパーの上に樽があるか確認
    const barrelBlock = block.above();
    if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) return;

    // さらにその上に自動販売機があるか確認
    const shopBlock = barrelBlock.above();
    if (!shopBlock || shopBlock.typeId !== SHOP_BLOCK) return;

    // 自販機と関連する樽の下にホッパーが置かれたので、ブロックを破壊
    block.setType("minecraft:air");

    // クールダウンチェック
    const locationKey = getLocationKey(block.location);
    const playerId = player.id;
    const now = Date.now();
    const cooldownData = interactionCooldowns.get(playerId);

    if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
      // クールダウンデータを更新
      interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

      system.run(() => {
        player.sendMessage(`§r[§b自動販売機§r] §4ホッパーは樽の下に置けません`);
        player.playSound("random.toast", {
          pitch: 0.4,
          volume: 1.0
        });
      });
    }
  });

  // 自販機と樽の周りにピストンや粘着ピストンを置けないようにする（2ブロック範囲）
  world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const { block, player } = event;
    const restrictedBlocks = ["minecraft:piston", "minecraft:sticky_piston"];
    if (!restrictedBlocks.includes(block.typeId)) return;

    // 2ブロック範囲をチェック（X, Y, Z軸で-2から+2）
    const directions = [];
    for (let x = -2; x <= 2; x++) {
      for (let y = -2; y <= 2; y++) {
        for (let z = -2; z <= 2; z++) {
          // 軸方向（X, Y, Z のいずれかが 0 でない、かつ斜め方向は除外）
          if ((x === 0 && y === 0 && z === 0) || (x !== 0 && y !== 0) || (x !== 0 && z !== 0) || (y !== 0 && z !== 0)) continue;
          directions.push({ x, y, z });
        }
      }
    }

    for (const dir of directions) {
      const checkLocation = {
        x: block.location.x + dir.x,
        y: block.location.y + dir.y,
        z: block.location.z + dir.z,
      };
      const adjacentBlock = block.dimension.getBlock(checkLocation);

      if (!adjacentBlock) continue;

      // 自販機ブロックかチェック
      if (adjacentBlock.typeId === SHOP_BLOCK) {
        block.setType("minecraft:air");

        // クールダウンチェック
        const locationKey = getLocationKey(block.location);
        const playerId = player.id;
        const now = Date.now();
        const cooldownData = interactionCooldowns.get(playerId);

        if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
          // クールダウンデータを更新
          interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

          system.run(() => {
            player.sendMessage(`§r[§b自動販売機§r] §4自動販売機の周りにピストンは置けません`);
            player.playSound("random.toast", {
              pitch: 0.4,
              volume: 1.0
            });
          });
        }
        return;
      }

      // 隣接ブロックが樽で、その上に自販機があるかチェック
      if (adjacentBlock.typeId === BARREL_BLOCK) {
        const shopBlock = adjacentBlock.above();
        if (shopBlock && shopBlock.typeId === SHOP_BLOCK) {
          block.setType("minecraft:air");

          // クールダウンチェック
          const locationKey = getLocationKey(block.location);
          const playerId = player.id;
          const now = Date.now();
          const cooldownData = interactionCooldowns.get(playerId);

          if (!cooldownData || cooldownData.location !== locationKey || now - cooldownData.lastInteraction >= COOLDOWN_MS) {
            // クールダウンデータを更新
            interactionCooldowns.set(playerId, { location: locationKey, lastInteraction: now });

            system.run(() => {
              player.sendMessage(`§r[§b自動販売機§r] §4自動販売機の樽の周りにピストンは置けません`);
              player.playSound("random.toast", {
                pitch: 0.4,
                volume: 1.0
              });
            });
          }
          return;
        }
      }
    }
  });
}

// ショップのインタラクト処理
async function handleShopInteraction(player, block) {
  const key = getLocationKey(block.location);
  const ownerName = world.getDynamicProperty(`${OWNER_PREFIX}${key}`);
  const isOwner = ownerName === player.name;

  // 1ブロック下の樽を取得
  const barrelBlock = block.below();
  if (!barrelBlock || barrelBlock.typeId !== BARREL_BLOCK) {
    player.sendMessage(`§r[§b自動販売機§r] §4ショップブロックの下に樽が必要です`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  // 樽のインベントリを取得
  const inventoryComponent = barrelBlock.getComponent(BlockInventoryComponent.componentId);
  if (!inventoryComponent || !inventoryComponent.container) {
    player.sendMessage(`§r[§b自動販売機§r] §4樽のインベントリを取得できませんでした`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }
  const inventory = inventoryComponent.container;

  if (isOwner) {
    // 設置者向けUIを表示
    await showOwnerMenu(player, block, inventory);
  } else {
    // 一般プレイヤー向け購入UIを表示
    await showBuyMenu(player, block, inventory);
  }
}

// 設置者向けメニュー
async function showOwnerMenu(player, block, inventory) {
  const form = new ActionFormData()
    .title("自動販売機")
    .body("§5>>>§a管理メニューを選択してください")
    .button("§1商品カスタマイズ")
    .button("§4売り上げ受け取り")
    .button("§5商品確認")
    .button("§9購入画面を表示");
  const response = await form.show(player);
  if (response.canceled) return;

  switch (response.selection) {
    case 0:
      await showPriceSettingMenu(player, block, inventory);
      break;
    case 1:
      await receiveRevenue(player, block);
      break;
    case 2:
      await showInventoryMenu(player, inventory);
      break;
    case 3:
      await showBuyMenu(player, block, inventory)
      break;
  }
}

// 価格設定メニュー
async function showPriceSettingMenu(player, block, inventory) {
  const items = getInventoryItems(inventory);
  if (items.length === 0) {
    player.sendMessage(`§r[§b自動販売機§r] §4商品がありません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  const form = new ModalFormData()
    .title("自動販売機")
    .dropdown(
      "§a商品を選択",
      items.map((item) => `${getItemDisplayName(block, item.itemStack)} (${item.amount}) §5- §r${getItemPRICE(block, item.itemStack)}`),
      0
    )
    .textField("§a価格 §b(整数) §5- §e1個あたり", "例:10")
    .textField("§a表示名", "例:ダイヤモンド");

  const response = await form.show(player);
  if (response.canceled || !response.formValues) return;

  const selectedItemIndex = response.formValues[0];
  const price = response.formValues[1];
  const displayName = response.formValues[2];

  if (price !== '' && (isNaN(price) || price < 0)) {
    player.sendMessage(`§r[§b自動販売機§r] §4無効な価格です`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  const item = items[selectedItemIndex];
  const key = getLocationKey(block.location);
  const uniqueKey = getItemUniqueKey(item.itemStack);

  // 表示名を設定（空なら削除）
  if (displayName !== '') {
    world.setDynamicProperty(`${DISPLAY_NAME_PREFIX}${key}:${uniqueKey}`, displayName);
    player.sendMessage(`§r[§b自動販売機§r] §a表示名§r:§b${getItemDisplayName(block, item.itemStack)}§aに設定しました`);
  }

  // 価格を設定
  if (price !== '') {
    world.setDynamicProperty(`${PRICE_PREFIX}${key}:${uniqueKey}`, price);
    player.sendMessage(`§r[§b自動販売機§r] §a価格§r:§c${price} §aに設定しました`);
  }
  player.playSound("random.toast", {
      pitch: 1.7, 
      volume: 1.0
  });  
}

// 売り上げ受け取り
async function receiveRevenue(player, block) {
  const key = getLocationKey(block.location);
  const revenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
  if (revenue === 0) {
    player.sendMessage(`§r[§b自動販売機§r] §a現在売り上げはありません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });  
    return;
  }

  const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
  if (!objective) {
    player.sendMessage(`§r[§b自動販売機§r] §4スコアボード 'money' が見つかりません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    }); 
    return;
  }

  objective.addScore(player, revenue);
  world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, 0);
  player.sendMessage(`§r[§b自動販売機§r] §c${revenue}§aの売り上げを受け取りました`);
  player.playSound("random.toast", {
      pitch: 1.7, 
      volume: 1.0
  }); 
}

// 商品確認メニュー
async function showInventoryMenu(player, inventory) {
  const items = getInventoryItems(inventory);
  if (items.length === 0) {
    player.sendMessage(`§r[§b自動販売機§r] §4商品がありません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  const block = player.dimension.getBlock({ x: player.location.x, y: player.location.y - 1, z: player.location.z });
  const form = new ActionFormData()
    .title("自動販売機")
    .body("§a樽内の商品§r：\n" + items.map((item) => `${getItemDisplayName(block, item.itemStack)} (${item.amount})`).join("\n"));

  await form.show(player);
}

// 購入メニュー
async function showBuyMenu(player, block, inventory) {
  const items = getInventoryItems(inventory);
  if (items.length === 0) {
    player.sendMessage(`§r[§b自動販売機§r] §4商品がありません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  const key = getLocationKey(block.location);
  const form = new ActionFormData()
    .title("自動販売機")
    .body("購入する商品を選択してください");

  const prices = items.map((item) => world.getDynamicProperty(`${PRICE_PREFIX}${key}:${getItemUniqueKey(item.itemStack)}`) || 0);
  items.forEach((item, index) => {
    form.button(`§1${getItemDisplayName(block, item.itemStack)} (${item.amount}) §51個§r:§c${prices[index]}`);
  });

  const response = await form.show(player);
  if (response.canceled || response.selection == null) return;

  const selectedItem = items[response.selection];
  const price = prices[response.selection];
  await showQuantitySelectionMenu(player, block, inventory, selectedItem, price);
}

// 数量選択メニュー
async function showQuantitySelectionMenu(player, block, inventory, selectedItem, price) {
  const form = new ModalFormData()
    .title("数量選択")
    .textField(`§a購入する数量 §r(§b1~${selectedItem.amount}§r)`, "半角整数");

  const response = await form.show(player);
  if (response.canceled || !response.formValues) return;

  const quantity = parseInt(response.formValues[0]);
  if (isNaN(quantity) || quantity <= 0) {
    player.sendMessage(`§r[§b自動販売機§r] §4数量は正の整数で入力してください`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }
  if (quantity > selectedItem.amount) {
    player.sendMessage(`§r[§b自動販売機§r] §4在庫§a（${selectedItem.amount}個）§4を超える数量です`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  if (quantity >= 256) {
    player.sendMessage(`§r[§b自動販売機§r] §4256以上の数量は購入できません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  const totalCost = price * quantity;
  const objective = world.scoreboard.getObjective(MONEY_OBJECTIVE);
  if (!objective) {
    player.sendMessage(`§r[§b自動販売機§r] §4スコアボード 'money' が見つかりません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }
  const playerMoney = objective.getScore(player) || 0;
  if (playerMoney < totalCost) {
    player.sendMessage(`§r[§b自動販売機§r] §4Moneyが不足しています`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  // インベントリ空きチェック
  if (!hasEnoughInventorySpace(player, quantity, selectedItem.itemStack)) {
    player.sendMessage(`§r[§b自動販売機§r] §4インベントリに空きがありません`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  // 在庫から指定数量を減らし、アイテムスタックを取得
  const itemStacks = await reduceInventory(inventory, selectedItem.itemStack, quantity);
  if (!itemStacks || itemStacks.length === 0) {
    player.sendMessage(`§r[§b自動販売機§r] §4在庫の更新に失敗しました`);
    player.playSound("random.toast", {
        pitch: 0.4, 
        volume: 1.0
    });
    return;
  }

  // プレイヤーにアイテムを付与（NBTデータを保持）
  const playerInventory = player.getComponent("minecraft:inventory").container;
  itemStacks.forEach(stack => {
    playerInventory.addItem(stack);
  });

  // 所持金を減らし、売り上げを加算
  objective.setScore(player, playerMoney - totalCost);
  const key = getLocationKey(block.location);
  const currentRevenue = world.getDynamicProperty(`${REVENUE_PREFIX}${key}`) || 0;
  world.setDynamicProperty(`${REVENUE_PREFIX}${key}`, currentRevenue + totalCost);

  player.sendMessage(`§r[§b自動販売機§r] §b${getItemDisplayName(block, selectedItem.itemStack)}§aを§e${quantity}個 §c${totalCost}§aで購入しました`);
  player.playSound("random.toast", {
      pitch: 1.7, 
      volume: 1.0
  }); 
}

// 在庫から指定数量を減らす（NBTデータを保持、スタック上限を考慮）
async function reduceInventory(inventory, targetItemStack, quantity) {
  let remaining = quantity;
  const itemStacks = [];
  const targetUniqueKey = getItemUniqueKey(targetItemStack);

  for (let i = 0; i < inventory.size && remaining > 0; i++) {
    const item = inventory.getItem(i);
    if (item && getItemUniqueKey(item) === targetUniqueKey) {
      const maxStack = item.maxAmount || 64;
      
      if (item.amount <= remaining) {
        const stack = item.clone();
        stack.amount = item.amount;
        itemStacks.push(stack);
        remaining -= item.amount;
        inventory.setItem(i, undefined);
      } else {
        const stack = item.clone();
        stack.amount = remaining;
        itemStacks.push(stack);
        item.amount -= remaining;
        inventory.setItem(i, item);
        remaining = 0;
      }
    }
  }

  return remaining === 0 ? itemStacks : null;
}

// インベントリからアイテムリストを取得（エンチャントデータに基づいてグループ化）
function getInventoryItems(inventory) {
  const itemMap = new Map();

  for (let i = 0; i < inventory.size; i++) {
    const item = inventory.getItem(i);
    if (item) {
      const uniqueKey = getItemUniqueKey(item);
      const current = itemMap.get(uniqueKey) || { typeId: item.typeId, amount: 0, itemStack: item };
      itemMap.set(uniqueKey, {
        typeId: item.typeId,
        amount: current.amount + item.amount,
        itemStack: current.itemStack
      });
    }
  }

  return Array.from(itemMap.values());
}

// 特定のアイテムのスロットを探す（エンチャントデータ考慮）
function findItemSlot(inventory, itemStack) {
  const targetUniqueKey = getItemUniqueKey(itemStack);
  for (let i = 0; i < inventory.size; i++) {
    const item = inventory.getItem(i);
    if (item && getItemUniqueKey(item) === targetUniqueKey) {
      return i;
    }
  }
  return -1;
}