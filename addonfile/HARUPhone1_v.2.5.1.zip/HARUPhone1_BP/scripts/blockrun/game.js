import { world,system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}

export function Game(eventData){
    const player = eventData.player
        player_Cash_Data[player.id]={}
        system.run(() => {
            if (!player_Cash_Data[player.id].TitaniumStop) {
                player_Cash_Data[player.id].TitaniumStop = true
                //ここから実行
                 Game_system(player);
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.id].TitaniumStop = false
                }, 20); 
        }
    })    
}

function Game_system(player){
    const now = new Date();
    const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, "0");
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, "0");
    var time = `${hours}:${minutes}`

    var form = new ActionFormData();
    form.title("§1GAME");
    form.body(`§l§b${time}`);
    form.button("§1ラッキーレター",'textures/ui/haruapp');
    if (player.hasTag('HARUPhoneOP')) {
        form.button("§0設定",'textures/ui/haruapp');
      }
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                const activePlayers = new Set();
                const playerTimers = new Map();
                
                // プレイヤーのタイマーをクリア
                function clearPlayerTimers(playerId) {
                    if (playerTimers.has(playerId)) {
                        playerTimers.get(playerId).forEach(timerId => system.clearRun(timerId));
                        playerTimers.delete(playerId);
                    }
                }
                
                // スコアボード操作
                async function getMoney(player) {
                    return new Promise((resolve) => {
                        system.run(() => {
                            const score = world.scoreboard.getObjective("money")?.getScore(player.scoreboardIdentity) ?? 0;
                            resolve(score);
                        });
                    });
                }
                
                function setMoney(player, amount) {
                    system.run(() => {
                        let objective = world.scoreboard.getObjective("money");
                        if (!objective) {
                            world.scoreboard.addObjective("money", "Money");
                            objective = world.scoreboard.getObjective("money");
                        }
                        objective.setScore(player.scoreboardIdentity, amount);
                    });
                }
                
                // 選択肢の生成（A〜Zまで対応）
                function generateLetters(count) {
                    if (count < 1 || count > 26) throw new Error("選択肢の数は1〜26で設定してください");
                    return Array.from({ length: count }, (_, i) => String.fromCharCode(65 + i)); // A=65
                }
                
                // ベット金額選択フォーム
                async function openBetForm(player) {
                    if (activePlayers.has(player.id)) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§c現在ゲーム中です！"}]}`);
                        return;
                    }
                    activePlayers.add(player.id);
                
                    try {
                        // グローバル設定をローカルにコピー
                        const MULTIPLIER = world.getDynamicProperty('MULTIPLIER') ?? 3;
                        const TOTAL_LETTERS = world.getDynamicProperty('TOTAL_LETTERS') ?? 10;
                        const WINNING_COUNT = world.getDynamicProperty('WINNING_COUNT') ?? 1;
                        const text = world.getDynamicProperty('BET_AMOUNTS') ?? "100,500,1000";
                        const BET_AMOUNTS = text.split(',').map(Number);
                
                        // ベット金額のバリデーション
                        if (BET_AMOUNTS.length === 0 || BET_AMOUNTS.some(amount => amount <= 0)) {
                            throw new Error("ベット金額が無効です");
                        }
                
                        const current = await getMoney(player);
                        const form = new ActionFormData()
                            .title("§0賭け金を選択")
                            .body(`§aHARUPAY残高§r: §b${current}`);
                
                        // 動的にベット金額ボタンを追加
                        BET_AMOUNTS.forEach((amount, index) => {
                            form.button(`§${index % 5 + 1}${amount}`);
                        });
                        form.button("§5>>>やめる§5<<<");
                
                        form.show(player).then(async res => {
                            try {
                                if (res.canceled || res.selection === BET_AMOUNTS.length) {
                                    Game_system(player);
                                    return;
                                }
                
                                const bet = BET_AMOUNTS[res.selection];
                                const currentMoney = await getMoney(player);
                
                                if (currentMoney < bet) {
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                                    return;
                                }
                
                                await openLetterForm(player, bet, MULTIPLIER, TOTAL_LETTERS, WINNING_COUNT);
                            } finally {
                                activePlayers.delete(player.id);
                            }
                        }).catch(() => {
                            activePlayers.delete(player.id);
                        });
                    } catch (e) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        activePlayers.delete(player.id);
                    }
                }
                
                // A〜?の選択フォーム
                async function openLetterForm(player, bet, MULTIPLIER, TOTAL_LETTERS, WINNING_COUNT) {
                    try {
                        // 設定のバリデーション
                        if (WINNING_COUNT > TOTAL_LETTERS) {
                            throw new Error("当たり数が選択肢数を超えています");
                        }
                
                        const letters = generateLetters(TOTAL_LETTERS);
                        const winProbability = ((WINNING_COUNT / TOTAL_LETTERS) * 100).toFixed(1);
                
                        const form = new ActionFormData()
                            .title("§0ギャンブルチャレンジ！")
                            .body(
                                `§a賭け金§r: §b${bet}\n` +
                                `§5>>>§c${letters.length}個中${WINNING_COUNT}つ§rの当たりで§e${bet * MULTIPLIER}§rゲット！\n` +
                                `§d当たり確率: ${winProbability}%`
                            );
                
                        letters.forEach(letter => form.button(`§1${letter}§r`));
                        form.button("§cやめる§r");
                
                        // ランダムに当たりインデックスを選択
                        const correctIndices = [];
                        while (correctIndices.length < WINNING_COUNT) {
                            const index = Math.floor(Math.random() * TOTAL_LETTERS);
                            if (!correctIndices.includes(index)) correctIndices.push(index);
                        }
                
                        clearPlayerTimers(player.id); // 既存のタイマーをクリア
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                
                        form.show(player).then(async res => {
                            try {
                                if (res.canceled || res.selection === letters.length) {
                                    activePlayers.delete(player.id);
                                    return;
                                }
                
                                player.runCommandAsync(`playsound random.click @s`);
                                const current = await getMoney(player);
                                if (current < bet) {
                                    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cMoneyが不足しています"}]}`);
                                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                                    return;
                                }
                
                                setMoney(player, current - bet);
                
                                // カウントダウン演出
                                const timers = [];
                                await player.runCommandAsync(`title @s title §e3`);
                                const timer1 = system.runTimeout(async () => {
                                    await player.runCommandAsync(`title @s title §e2`);
                                    const timer2 = system.runTimeout(async () => {
                                        await player.runCommandAsync(`title @s title §e1`);
                                        const timer3 = system.runTimeout(async () => {
                                            if (correctIndices.includes(res.selection)) {
                                                const reward = bet * MULTIPLIER;
                                                setMoney(player, await getMoney(player) + reward);
                                                await player.runCommandAsync(
                                                    `tellraw @s {"rawtext":[{"text":"§a当たり!!!§b${letters[res.selection]}§cが正解！§a+§e${reward}"}]}`
                                                );
                                                await player.runCommandAsync(`particle minecraft:heart_particle ~ ~1 ~`);
                                                await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                                system.runTimeout(async () => {
                                                    await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 2.5 0.5`);
                                                }, 2);
                                            } else {
                                                await player.runCommandAsync(
                                                    `tellraw @s {"rawtext":[{"text":"§9ハズレ...§c正解は §b${correctIndices
                                                        .map(i => letters[i])
                                                        .join("と")} §cでした…"}]}`
                                                );
                                                await player.runCommandAsync(`particle minecraft:smoke_particle ~ ~1 ~`);
                                                await player.runCommandAsync(`playsound random.toast @s ~ ~ ~ 1.0 0.3 0.5`);
                                            }
                                            system.runTimeout(async () => {
                                                clearPlayerTimers(player.id);
                                                await openBetForm(player);
                                            }, 20);
                                        }, 20);
                                        timers.push(timer3);
                                    }, 20);
                                    timers.push(timer2);
                                }, 20);
                                timers.push(timer1);
                                playerTimers.set(player.id, timers);
                            } catch (e) {
                                player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                            } finally {
                                if (!playerTimers.has(player.id)) {
                                    activePlayers.delete(player.id);
                                }
                            }
                        }).catch(() => {
                            clearPlayerTimers(player.id);
                            activePlayers.delete(player.id);
                        });
                    } catch (e) {
                        player.runCommand(`tellraw @s {"rawtext":[{"text":"§cエラー: ${e.message}"}]}`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.5`);
                        activePlayers.delete(player.id);
                    }
                }
                
                // ゲーム開始
                openBetForm(player);
            break;
            case 1:
                var form = new ActionFormData();
                form.title(`§1GAME`);
                form.body(`§a設定`);
                form.button(`§l戻る`,'textures/ui/icon_import.png');       
                form.button(`§5ラッキーレター`);                   
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //戻る
                            Game_system(player);
                        break;
                        case 1:
                            form = new ModalFormData();
                            form.title(`§1GAME`);
                            form.textField(`§e報酬倍率`, `${world.getDynamicProperty('MULTIPLIER')}`)
                            form.textField(`§a選択肢の数`, `${world.getDynamicProperty('TOTAL_LETTERS')}`)
                            form.textField(`§d当たりの数`, `${world.getDynamicProperty('WINNING_COUNT')}`)
                            form.textField(`§cベット金額`, `${world.getDynamicProperty('BET_AMOUNTS')}`)
                            form.show(player).then(r => {
                                if (r.canceled) {
                                    return;
                                };
                                if(r.formValues[0]!=''){
                                    world.setDynamicProperty('MULTIPLIER',Number(r.formValues[0]))
                                }
                                if(r.formValues[1]!=''){
                                    world.setDynamicProperty('TOTAL_LETTERS',Number(r.formValues[1]))
                                }
                                if(r.formValues[2]!=''){
                                    world.setDynamicProperty('WINNING_COUNT',Number(r.formValues[2]))
                                }
                                if(r.formValues[3]!=''){
                                    world.setDynamicProperty('BET_AMOUNTS',r.formValues[3])
                                }
                                player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 1.7 0.5`);
                                Game_system(player);
                            })
                        break;
                    }
                })
            break;
        }
    })
}