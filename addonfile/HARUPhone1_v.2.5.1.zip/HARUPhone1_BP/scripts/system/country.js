import { world, system } from "@minecraft/server";
import { ModalFormData, ActionFormData, MessageFormData } from "@minecraft/server-ui";

import { Operator_Controller } from '../system/Operator_Controller';
import { HARUPhone1 } from '../itemrun/haruphone1';

// スコアボードと動的プロパティの初期化
const MONEY_OBJECTIVE = "money";
const CHUNK_PRICE_PROPERTY = "chunk_price";
const NATION_DB = "nation_data";
const CHUNK_DB = "chunk_data";
const SYSTEM_ENABLED_PROPERTY = "nation_system_enabled";
const NATION_CREATION_COST_PROPERTY = "nation_creation_cost";
const ALLOW_MULTIPLE_NATIONS_PROPERTY = "allow_multiple_nations";
const UNOWNED_LAND_INTERACTION = "unowned_land_interaction";

// システムが有効か確認
function isSystemEnabled() {
    return world.getDynamicProperty(SYSTEM_ENABLED_PROPERTY) === true;
}

// 複数国所属が許可されているか確認
function isMultipleNationsAllowed() {
    return world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === true;
}

// チャンク座標の取得
function getChunkCoords(location) {
    return {
        x: Math.floor(location.x / 16),
        z: Math.floor(location.z / 16)
    };
}

// 国のデータの管理
function getNationData() {
    try {
        const data = world.getDynamicProperty(NATION_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn("Failed to parse nation data:", e);
        return {};
    }
}

function setNationData(data) {
    try {
        world.setDynamicProperty(NATION_DB, JSON.stringify(data));
    } catch (e) {
        console.warn("Failed to set nation data:", e);
    }
}

// チャンクデータの管理
function getChunkData() {
    try {
        const data = world.getDynamicProperty(CHUNK_DB);
        return data ? JSON.parse(data) : {};
    } catch (e) {
        console.warn("Failed to parse chunk data:", e);
        return {};
    }
}

function setChunkData(data) {
    try {
        world.setDynamicProperty(CHUNK_DB, JSON.stringify(data));
    } catch (e) {
        console.warn("Failed to set chunk data:", e);
    }
}

// プレイヤーの所属国を取得
function getPlayerNations(player) {
    const nationData = getNationData();
    return Object.entries(nationData).filter(([_, nation]) => nation.members.includes(player.name));
}

// メインUIを表示
export function showMainUI(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§b社会システム§r] §c社会システムは現在無効です。");
        return;
    }

    const playerNations = getPlayerNations(player);
    const hasNation = playerNations.length > 0;

    //現在地の国名取得
    const chunk = getChunkCoords(player.location);
        const chunkKey = `${chunk.x}:${chunk.z}`;
        const chunkData = getChunkData();
        const nationData = getNationData();

        let nowChunkName = world.getDynamicProperty('WorldspaceNAME');
        // 現在の国のIDを取得（未所属の場合はnull）
        const currentNationId = chunkData[chunkKey]?.nation || null;
        if (currentNationId) {
            const nation = nationData[currentNationId];
            if (nation) {
                nowChunkName = nation.name;
            }
        }
        
    const form = new ActionFormData()
        .title("§1HARUPhone1")
        .body(`§c-現在地-\n §a>§e${nowChunkName}`);

    // ボタンを動的に追加
    const buttons = [];
    buttons.push({ text: "§l戻る", action: "back", icon: "textures/ui/icon_import.png" });
    if (hasNation) {
        buttons.push({ text: `§4土地を購入\n§5>>>§1コスト§r:§s${world.getDynamicProperty(CHUNK_PRICE_PROPERTY)}`, action: "buyLand" });
        buttons.push(
            playerNations.some(([_, nation]) => nation.leader === player.name)
                ? { text: `§1${world.getDynamicProperty('WorldgroupName')}を管理`, action: "manageNation" }
                : { text: `§4${world.getDynamicProperty('WorldgroupName')}を退出`, action: "leaveNation" }
        );
    } else {
        buttons.push({ text: `§1${world.getDynamicProperty('WorldgroupName')}を作成\n§5>>>§1コスト§r:§s${world.getDynamicProperty(NATION_CREATION_COST_PROPERTY)}`, action: "createNation" });
    }
    buttons.push({ text: "§0マイ情報", action: "showMyInfo" });
    buttons.push({ text: "§9招待を確認", action: "checkInvites" });

    buttons.forEach(button => form.button(button.text,button.icon));

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedAction = buttons[response.selection].action;

        if (hasNation) {
            if (selectedAction === "back") {
                HARUPhone1(player);
            }else
            if (selectedAction === "buyLand" || selectedAction === "manageNation" || selectedAction === "leaveNation") {
                selectNationForAction(player, selectedAction);
            } else if (selectedAction === "showMyInfo") {
                showMyInfo(player);
            } else if (selectedAction === "checkInvites") {
                checkInvites(player);
            }
        } else {
            if (selectedAction === "back") {
                HARUPhone1(player);
            }else
            if (selectedAction === "createNation") {
                createNation(player);
            } else if (selectedAction === "showMyInfo") {
                showMyInfo(player);
            } else if (selectedAction === "checkInvites") {
                checkInvites(player);
            }
        }
    });
}

// 複数国所属時の国選択UI
function selectNationForAction(player, action) {
    const playerNations = getPlayerNations(player);
    if (playerNations.length === 1) {
        const [nationId, nation] = playerNations[0];
        if (action === "buyLand" && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === "manageNation" && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === "leaveNation") {
            leaveNation(player, nationId);
        } else {
            player.sendMessage("§r[§b社会システム§r] §cこの操作の権限がありません。");
        }
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}を選択`)
        .body(`§fどの${world.getDynamicProperty('WorldgroupName')}を操作しますか？`);
    playerNations.forEach(([nationId, nation]) => {
        form.button(`§e${nation.name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled) return;
        const [nationId, nation] = playerNations[response.selection];
        if (action === "buyLand" && (nation.leader === player.name || nation.permissions?.[player.name]?.canBuyLand)) {
            buyLand(player, nationId);
        } else if (action === "manageNation" && nation.leader === player.name) {
            manageNation(player, nationId);
        } else if (action === "leaveNation") {
            leaveNation(player, nationId);
        } else {
            player.sendMessage("§r[§b社会システム§r] §cこの操作の権限がありません。");
        }
    });
}

// マイ情報表示
function showMyInfo(player) {
    const playerNations = getPlayerNations(player);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;

    let body = `§a所持金: §e${score}\n\n§b所属${world.getDynamicProperty('WorldgroupName')}:\n`;
    if (playerNations.length === 0) {
        body += "§7なし\n";
    } else {
        playerNations.forEach(([_, nation]) => {
            const isLeader = nation.leader === player.name;
            const canBuyLand = nation.permissions?.[player.name]?.canBuyLand || false;
            body += `- §6${nation.name} (§c${isLeader ? "リーダー" : "メンバー"})\n`;
            body += `  §a土地購入権限: §e${canBuyLand ? "あり" : "なし"}\n`;
        });
    }

    const form = new ActionFormData()
        .title("§1HARUPhone1")
        .body(body)
        .button("§1OK");

    form.show(player);
}

// 土地購入
function buyLand(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§b社会システム§r] §c社会システムは現在無効です。");
        return;
    }

    const chunk = getChunkCoords(player.location);
    const chunkData = getChunkData();
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);

    if (chunkData[chunkKey]) {
        player.sendMessage("§r[§b社会システム§r] §cこのチャンクはすでに購入されています。");
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const hasPurchasePermission = nation.leader === player.name || (nation.permissions?.[player.name]?.canBuyLand);
    if (!hasPurchasePermission) {
        player.sendMessage("§r[§b社会システム§r] §c土地購入の権限がありません。");
        return;
    }

    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < chunkPrice) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${chunkPrice}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new MessageFormData()
        .title("§1HARUPhone1")
        .body(`§fこのチャンクを§a${chunkPrice}§fで購入しますか？\n§b座標: (§e${chunk.x}, ${chunk.z}§b)`)
        .button1("§4キャンセル")
        .button2("§1購入");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -chunkPrice);
            chunkData[chunkKey] = { nation: nationId };
            setChunkData(chunkData);
            player.sendMessage("§r[§b社会システム§r] §aチャンクを購入しました！");
        }
    });
}

// 国作成
function createNation(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§b社会システム§r] §c社会システムは現在無効です。");
        return;
    }

    const nationData = getNationData();
    const playerNations = getPlayerNations(player);
    if (playerNations.length > 0 && !isMultipleNationsAllowed()) {
        player.sendMessage(`§r[§b社会システム§r] §cすでに${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
        return;
    }

    const creationCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const score = world.scoreboard.getObjective(MONEY_OBJECTIVE).getScore(player) || 0;
    if (score < creationCost) {
        player.sendMessage(`§r[§b社会システム§r] §c所持金が足りません（必要: §e${creationCost}§c、所持: §e${score}§c）。`);
        return;
    }

    const form = new ModalFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}を作成`)
        .textField(`§f${world.getDynamicProperty('WorldgroupName')}の名前`, "例: MyNation")
        .dropdown("§fメンバーシップ", ["オープン", "招待制"], 0);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [nationName, membershipType] = response.formValues;
        if (!nationName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}の名前を入力してください。`);
            return;
        }
        const nationId = nationName.toLowerCase().replace(/\s/g, "_");
        if (nationData[nationId]) {
            player.sendMessage(`§r[§b社会システム§r] §cこの名前の${world.getDynamicProperty('WorldgroupName')}はすでに存在します。`);
            return;
        }

        world.scoreboard.getObjective(MONEY_OBJECTIVE).addScore(player, -creationCost);
        nationData[nationId] = {
            name: nationName,
            leader: player.name,
            members: [player.name],
            membership: membershipType === 0 ? "open" : "invite",
            invites: [],
            permissions: {}
        };
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nationName}§a」を作成しました！`);
    });
}

// 国管理
function manageNation(player, nationId) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§b社会システム§r] §c社会システムは現在無効です。");
        return;
    }

    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}に所属していません。`);
        return;
    }

    const isLeader = nation.leader === player.name;
    if (!isLeader) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}のリーダーではありません。`);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}管理§r: §1${nation.name}`)
        .body("§4>>>")
        .button(`§l戻る`,'textures/ui/icon_import.png')
        .button("§4メンバーを招待")
        .button(`§0${world.getDynamicProperty('WorldgroupName')}の情報`)
        .button("§1メンバー権限設定")
        .button(`§2${world.getDynamicProperty('WorldgroupName')}名を変更`)
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を解散`);

    form.show(player).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showMainUI(player);
            break;
            case 1:
                inviteMember(player, nationId);
                break;
            case 2:
                showNationInfo(player, nationId);
                break;
            case 3:
                setMemberPermissions(player, nationId);
                break;
            case 4:
                changeNationName(player, nationId);
                break;
            case 5:
                confirmDissolveNation(player, nationId);
                break;
        }
    });
}

// 国の情報表示
function showNationInfo(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const memberCount = nation.members.length;
    const memberList = nation.members.join(", ");
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` +
                 `§aリーダー: §c${nation.leader}\n` +
                 `§aメンバー数: §e${memberCount}\n` +
                 `§aメンバー: §f${memberList}\n` +
                 `§aメンバーシップ: §e${nation.membership === "open" ? "オープン" : "招待制"}\n` +
                 `§a所有チャンク数: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の情報§r: §1${nation.name}`)
        .body(body)
        .button("§1閉じる");

    form.show(player);
}

// 国名変更
function changeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new ModalFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}名を変更`)
        .textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, "_");
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
    });
}

// メンバー招待
function inviteMember(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    if (nation.leader !== player.name && nation.membership !== "open") {
        player.sendMessage("§r[§b社会システム§r] §c招待権限がありません。");
        return;
    }

    const form = new ModalFormData()
        .title("§aメンバーを招待")
        .textField("§fプレイヤー名", "例: Steve");

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [targetName] = response.formValues;
        const targetPlayer = world.getPlayers().find(p => p.name === targetName);
        if (!targetPlayer) {
            player.sendMessage("§r[§b社会システム§r] §cプレイヤーが見つかりません。");
            return;
        }
        if (targetPlayer.name === player.name) {
            player.sendMessage("§r[§b社会システム§r] §c自分自身を招待できません。");
            return;
        }

        if (nation.members.includes(targetName)) {
            player.sendMessage("§r[§b社会システム§r] §cこのプレイヤーはすでにメンバーです。");
            return;
        }

        nation.invites.push(targetName);
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${targetName}を招待しました。`);
        targetPlayer.sendMessage(`§r[§b社会システム§r] §a${nation.name}から招待されました。`);
    });
}

// 招待確認
function checkInvites(player) {
    if (!isSystemEnabled()) {
        player.sendMessage("§r[§b社会システム§r] §c社会システムは現在無効です。");
        return;
    }

    const nationData = getNationData();
    const invites = [];
    for (const nationId in nationData) {
        if (nationData[nationId].invites.includes(player.name) || nationData[nationId].membership === "open") {
            invites.push(nationId);
        }
    }

    if (invites.length === 0) {
        player.sendMessage("§r[§b社会システム§r] §c招待がありません。");
        return;
    }

    const form = new ActionFormData()
        .title("§5招待リスト")
        .body(`§fどの${world.getDynamicProperty('WorldgroupName')}に参加しますか？`);
    invites.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedNation = invites[response.selection];
        const nation = nationData[selectedNation];
        if (!nation) return;

        if (nation.members.includes(player.name)) {
            player.sendMessage(`§r[§b社会システム§r] §cすでにこの${world.getDynamicProperty('WorldgroupName')}に所属しています。`);
            return;
        }

        if (!isMultipleNationsAllowed()) {
            const playerNations = getPlayerNations(player);
            if (playerNations.length > 0) {
                player.sendMessage(`§r[§b社会システム§r] §c複数の${world.getDynamicProperty('WorldgroupName')}に所属することはできません。`);
                return;
            }
        }

        nation.members.push(player.name);
        if (nation.invites.includes(player.name)) {
            nation.invites = nation.invites.filter(name => name !== player.name);
        }
        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${nation.name}に参加しました！`);
    });
}

// 国を退出
function leaveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    nation.members = nation.members.filter(name => name !== player.name);
    if (nation.leader === player.name && nation.members.length > 0) {
        nation.leader = nation.members[0];
    }
    if (nation.members.length === 0) {
        delete nationData[nationId];
    }
    setNationData(nationData);
    player.sendMessage(`§r[§b社会システム§r] §a${nation.name}を退出しました。`);
}

// 国解散確認
function confirmDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}解散の確認`)
        .body(`§c本当に「§e${nation.name}§c」を解散しますか？\n§7この操作は元に戻せません。`)
        .button1("§1キャンセル")
        .button2("§4解散");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) return;
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}を解散しました。`);
        }
    });
}

// メンバー権限設定
function setMemberPermissions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const members = nation.members.filter(name => name !== player.name);

    if (members.length === 0) {
        player.sendMessage("§r[§b社会システム§r] §c権限を設定できるメンバーがいません。");
        return;
    }

    const form = new ModalFormData()
        .title("§1メンバー権限設定")
        .dropdown("§fメンバー", members, 0)
        .toggle("§a土地購入権限", false);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) return;
        const [memberIndex, canBuyLand] = response.formValues;
        const selectedMember = members[memberIndex];

        if (!nation.permissions) {
            nation.permissions = {};
        }
        if (!nation.permissions[selectedMember]) {
            nation.permissions[selectedMember] = {};
        }
        nation.permissions[selectedMember].canBuyLand = canBuyLand;

        setNationData(nationData);
        player.sendMessage(`§r[§b社会システム§r] §a${selectedMember}の土地購入権限を${canBuyLand ? "§e有効" : "§e無効"}にしました。`);
    });
}

// 管理者設定
export function adminSettings(player) {
    const form = new ActionFormData()
        .title("§5管理者設定")
        .body("設定を選択してください")
        .button(`§l戻る`,'textures/ui/icon_import.png')
        .button("§1システム設定")
        .button(`§4${world.getDynamicProperty('WorldgroupName')}の管理`);

    form.show(player).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                Operator_Controller(player);
                break;
            case 1:
                showSystemSettingsMenu(player);
                break;
            case 2:
                manageNations(player);
                break;
        }
    });
}

// システム設定メニュー
function showSystemSettingsMenu(player) {
    const form = new ActionFormData()
        .title("§1社会システム設定")
        .body("§fどの設定を変更しますか？")
        .button(`§l戻る`,'textures/ui/icon_import.png')
        .button("§4チャンク価格設定")
        .button(`§4${world.getDynamicProperty('WorldgroupName')}作成コスト設定`)
        .button("§9社会システム\n§1有効§r/§4無効")
        .button(`§2複数${world.getDynamicProperty('WorldgroupName')}所属の許可`)
        .button("§1許可アイテム\n§8未所持の土地で利用できるアイテム")
        .button("§9未購入の土地の表示名")
        .button("§5未購入の土地での操作\n§1許可§r/§4禁止")
        .button("§2拠点種別の名称変更")
        .button(`§1${world.getDynamicProperty('WorldgroupName')}名タイトル\n§5表示§r/§1非表示`);
    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        switch (response.selection) {
            case 1:
                setChunkPrice(player);
                break;
            case 2:
                setNationCreationCost(player);
                break;
            case 3:
                toggleSystemEnabled(player);
                break;
            case 4:
                toggleMultipleNations(player);
                break;
            case 5:
                var form = new ActionFormData()
                .title("§1社会システム設定")
                .body("§fどの設定を変更しますか？")
                .button(`§l戻る`,'textures/ui/icon_import.png')
                .button("§1アイテムを追加")
                .button("§4アイテムを削除")
               form.show(player).then((response) => {
                if (response.canceled || response.selection === 0) {
                    adminSettings(player);
                    return;
                }
                switch (response.selection) {
                    case 1:
                        var form = new ModalFormData()
                        .title("§1許可アイテムを追加")
                        .textField("§5>>>追加するアイテムID\n§r(例: additem:haruphone1)", "");
                    
                    form.show(player).then((response) => {
                        if (response.canceled) return;
                    
                        const itemId = response.formValues[0].trim();
                        if (!itemId) {
                            player.sendMessage("§r[§b社会システム§r] §c入力が空です。アイテムIDを入力してください");
                            return;
                        }
                    
                        let DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
                    
                        if (DANGEROUS_ITEMS.includes(itemId)) {
                            player.sendMessage(`§r[§b社会システム§r] §r[§b社会システム§r] §e${itemId} はすでに登録されています`);
                            return;
                        }
                    
                        DANGEROUS_ITEMS.push(itemId);
                        world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                        player.sendMessage(`§r[§b社会システム§r] §a${itemId} を許可アイテムとして追加しました`);
                        showSystemSettingsMenu(player)
                    });                    
                    break;
                    case 2:
                        const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');

                        if (DANGEROUS_ITEMS.length === 0) {
                            player.sendMessage("§r[§b社会システム§r] §c現在、削除できるアイテムはありません");
                            break;
                        }
                    
                        var form = new ActionFormData()
                            .title("§4許可アイテムを削除")
                            .body("§5>>>削除したいアイテムを選んでください");
                    
                        // ボタンをアイテムIDごとに追加
                        for (const id of DANGEROUS_ITEMS) {
                            form.button(id);
                        }
                    
                        form.show(player).then((response) => {
                            if (response.canceled) {
                                return;
                            }
                                const selectedIndex = response.selection;
                                const removedItem = DANGEROUS_ITEMS[selectedIndex];
                                DANGEROUS_ITEMS.splice(selectedIndex, 1);
                    
                                world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
                                player.sendMessage(`§r[§b社会システム§r] §a${removedItem} をリストから削除しました`);
                            showSystemSettingsMenu(player)
                        });
                    break;
                }
            })
                break;
                case 6:
                    var form = new ModalFormData()
                        .title("§1未購入土地の表示名")
                        .textField("§5>>>表示名", `${world.getDynamicProperty('WorldspaceNAME')}`);
                    
                    form.show(player).then((response) => {
                        if (response.canceled) return;
                    
                        if (!response.formValues[0]) {
                            player.sendMessage("§r[§b社会システム§r] §c入力が空です。表示名を入力してください");
                            return;
                        }
                    
                        world.setDynamicProperty('WorldspaceNAME',response.formValues[0])
                        player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を表示名として設定しました`);
                        showSystemSettingsMenu(player)
                    });             
                break;
                case 7:
                toggleUnownedLandInteraction(player);
                break;
                case 8:
                    var form = new ModalFormData()
                        .title("§1拠点種別の名称")
                        .textField("§5>>>名称", `${world.getDynamicProperty('WorldgroupName')}`);
                    
                    form.show(player).then((response) => {
                        if (response.canceled) return;
                    
                        if (!response.formValues[0]) {
                            player.sendMessage("§r[§b社会システム§r] §c入力が空です。名称を入力してください");
                            return;
                        }
                    
                        world.setDynamicProperty('WorldgroupName',response.formValues[0])
                        player.sendMessage(`§r[§b社会システム§r] §a${response.formValues[0]} を拠点種別の名称として設定しました`);
                        showSystemSettingsMenu(player)
                    });             
                break;
                case 9:
                    var form = new MessageFormData()
                    .title("§1タイトル表示/非表示")
                    .body(`§c${world.getDynamicProperty('WorldgroupName')}名タイトル ${world.getDynamicProperty('WorldTitle') ? "§c非表示" : "§a表示"}にしますか？`)
                    .button1("§1キャンセル")
                    .button2(world.getDynamicProperty('WorldTitle') ? "§4非表示にする" : "§1表示にする");
            
                     form.show(player).then((response) => {
                        if (response.canceled || response.selection === 0) {
                           showSystemSettingsMenu(player);
                           return;
                        }
                        if (response.selection === 1) {
                           world.setDynamicProperty('WorldTitle', !world.getDynamicProperty('WorldTitle'));
                           player.sendMessage(`§r[§b社会システム§r] §aタイトルを§e${!world.getDynamicProperty('WorldTitle') ? "非表示" : "表示"}§aにしました。`);
                        }
                        showSystemSettingsMenu(player);
                     });
                break;
        }
    });
}

// 未購入の土地での操作許可/禁止切り替え（新しい関数）
function toggleUnownedLandInteraction(player) {
    const isAllowed = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
    const form = new MessageFormData()
        .title("§1未購入の土地での操作")
        .body(`§f未購入の土地でのブロック破壊/設置を${isAllowed ? "§c禁止" : "§a許可"}しますか？`)
        .button1("§1キャンセル")
        .button2(isAllowed ? "§4禁止する" : "§1許可する");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(UNOWNED_LAND_INTERACTION, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a未購入の土地でのブロック破壊/設置を§e${!isAllowed ? "許可" : "禁止"}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// チャンク価格設定
function setChunkPrice(player) {
    const currentPrice = world.getDynamicProperty(CHUNK_PRICE_PROPERTY);
    const form = new ModalFormData()
        .title("§1チャンク価格設定")
        .textField("§f新しいチャンク価格", currentPrice.toString());

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [chunkPrice] = response.formValues;
        const parsedChunkPrice = parseInt(chunkPrice);

        if (isNaN(parsedChunkPrice) || parsedChunkPrice < 0) {
            player.sendMessage("§r[§b社会システム§r] §c有効なチャンク価格を入力してください。");
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(CHUNK_PRICE_PROPERTY, parsedChunkPrice);
        player.sendMessage(`§r[§b社会システム§r] §aチャンク価格を§e${parsedChunkPrice}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 国作成コスト設定
function setNationCreationCost(player) {
    const currentCost = world.getDynamicProperty(NATION_CREATION_COST_PROPERTY);
    const form = new ModalFormData()
        .title(`§1${world.getDynamicProperty('WorldgroupName')}作成コスト設定`)
        .textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}作成コスト`, currentCost.toString());

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showSystemSettingsMenu(player);
            return;
        }
        const [creationCost] = response.formValues;
        const parsedCreationCost = parseInt(creationCost);

        if (isNaN(parsedCreationCost) || parsedCreationCost < 0) {
            player.sendMessage(`§r[§b社会システム§r] §c有効な${world.getDynamicProperty('WorldgroupName')}作成コストを入力してください。`);
            showSystemSettingsMenu(player);
            return;
        }

        world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, parsedCreationCost);
        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}作成コストを§e${parsedCreationCost}§aに設定しました。`);
        showSystemSettingsMenu(player);
    });
}

// 社会システムの有効/無効切り替え
function toggleSystemEnabled(player) {
    const isEnabled = isSystemEnabled();
    const form = new MessageFormData()
        .title("§1社会システムの有効/無効")
        .body(`§f社会システムを${isEnabled ? "§c無効" : "§a有効"}にしますか？`)
        .button1("§1キャンセル")
        .button2(isEnabled ? "§4無効にする" : "§1有効にする");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(SYSTEM_ENABLED_PROPERTY, !isEnabled);
            player.sendMessage(`§r[§b社会システム§r] §a社会システムを§e${!isEnabled ? "有効" : "無効"}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 複数国所属の許可/禁止切り替え
function toggleMultipleNations(player) {
    const isAllowed = isMultipleNationsAllowed();
    const form = new MessageFormData()
        .title(`§1複数${world.getDynamicProperty('WorldgroupName')}所属の許可`)
        .body(`§f複数${world.getDynamicProperty('WorldgroupName')}所属を${isAllowed ? "§c禁止" : "§a許可"}しますか？`)
        .button1("§1キャンセル")
        .button2(isAllowed ? "§4禁止する" : "§1許可する");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showSystemSettingsMenu(player);
            return;
        }
        if (response.selection === 1) {
            world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, !isAllowed);
            player.sendMessage(`§r[§b社会システム§r] §a複数${world.getDynamicProperty('WorldgroupName')}所属を§e${!isAllowed ? "許可" : "禁止"}§aにしました。`);
        }
        showSystemSettingsMenu(player);
    });
}

// 国の管理（管理者用）
function manageNations(player) {
    const nationData = getNationData();
    const nationIds = Object.keys(nationData);

    if (nationIds.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §c現在、存在する${world.getDynamicProperty('WorldgroupName')}はありません。`);
        adminSettings(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§5${world.getDynamicProperty('WorldgroupName')}の管理`)
        .body(`§f管理する${world.getDynamicProperty('WorldgroupName')}を選択してください。`)
        .button(`§l戻る`,'textures/ui/icon_import.png');

    nationIds.forEach(nationId => {
        form.button(`§1${nationData[nationId].name}`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            adminSettings(player);
            return;
        }
        const selectedNationId = nationIds[response.selection - 1];
        showNationAdminOptions(player, selectedNationId);
    });
}

// 国の管理オプション（管理者用）
function showNationAdminOptions(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const memberCount = nation.members.length;
    const chunkData = getChunkData();
    const chunkCount = Object.values(chunkData).filter(chunk => chunk.nation === nationId).length;

    const body = `§a${world.getDynamicProperty('WorldgroupName')}名: §e${nation.name}\n` +
                 `§aリーダー: §c${nation.leader}\n` +
                 `§aメンバー数: §e${memberCount}\n` +
                 `§aメンバー: §f${nation.members.join(", ")}\n` +
                 `§aメンバーシップ: §e${nation.membership === "open" ? "オープン" : "招待制"}\n` +
                 `§a所有チャンク数: §e${chunkCount}`;

    const form = new ActionFormData()
        .title(`§e${world.getDynamicProperty('WorldgroupName')}の管理: ${nation.name}`)
        .body(body)
        .button("§1メンバー管理")
        .button(`§4${world.getDynamicProperty('WorldgroupName')}名変更`)
        .button(`§4${world.getDynamicProperty('WorldgroupName')}を強制削除`)
        .button(`§l戻る`,'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 3) {
            manageNations(player);
            return;
        }
        switch (response.selection) {
            case 0:
                manageNationMembers(player, nationId);
                break;
            case 1:
                adminChangeNationName(player, nationId);
                break;
            case 2:
                confirmForceDissolveNation(player, nationId);
                break;
        }
    });
}

// 国のメンバー管理
function manageNationMembers(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }
    const members = nation.members;

    if (members.length === 0) {
        player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}にメンバーがいません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ActionFormData()
        .title(`§5メンバー管理§r: §1${nation.name}`)
        .body("§fどのメンバーを管理しますか？")
        .button(`§l戻る`,'textures/ui/icon_import.png');

    members.forEach(member => {
        form.button(`§1${member}${member === nation.leader ? " (§cリーダー§1)" : ""}`);
    });

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const selectedMember = members[response.selection - 1];
        showMemberOptions(player, nationId, selectedMember);
    });
}

// メンバーオプション
function showMemberOptions(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNationMembers(player, nationId);
        return;
    }
    const isLeader = nation.leader === memberName;

    const form = new ActionFormData()
        .title(`§aメンバー管理: ${memberName}`)
        .body(`§f${memberName}の操作を選択してください。\n§a土地購入権限: §e${nation.permissions?.[memberName]?.canBuyLand ? "あり" : "なし"}`);

    if (!isLeader) form.button("§4リーダーに設定");
    form.button("§4土地購入権限切り替え");
    form.button("§4メンバー除外");
    form.button(`§l戻る`,'textures/ui/icon_import.png');

    form.show(player).then((response) => {
        if (response.canceled) {
            manageNationMembers(player, nationId);
            return;
        }

        const backButtonIndex = isLeader ? 2 : 3;
        if (response.selection === backButtonIndex) {
            manageNationMembers(player, nationId);
            return;
        }

        if (isLeader) {
            switch (response.selection) {
                case 0:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 1:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        } else {
            switch (response.selection) {
                case 0:
                    setNationLeader(player, nationId, memberName);
                    break;
                case 1:
                    toggleLandPurchasePermission(player, nationId, memberName);
                    break;
                case 2:
                    confirmRemoveMember(player, nationId, memberName);
                    break;
            }
        }
    });
}

// リーダー設定
function setNationLeader(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title("§4リーダー設定")
        .body(`§f${memberName}を${nation.name}のリーダーに設定しますか？`)
        .button1("§1キャンセル")
        .button2("§4設定");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.leader = memberName;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}のリーダーに設定しました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// 土地購入権限切り替え
function toggleLandPurchasePermission(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;
    const currentPermission = nation.permissions?.[memberName]?.canBuyLand || false;

    const form = new MessageFormData()
        .title("§a土地購入権限")
        .body(`§f${memberName}の土地購入権限を${currentPermission ? "§c無効" : "§a有効"}にしますか？`)
        .button1("§1キャンセル")
        .button2(currentPermission ? "§4無効にする" : "§1有効にする");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            if (!nation.permissions) nation.permissions = {};
            if (!nation.permissions[memberName]) nation.permissions[memberName] = {};
            nation.permissions[memberName].canBuyLand = !currentPermission;
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}の土地購入権限を${!currentPermission ? "§e有効" : "§e無効"}にしました。`);
            showMemberOptions(player, nationId, memberName);
        }
    });
}

// メンバー除外確認
function confirmRemoveMember(player, nationId, memberName) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) return;

    const form = new MessageFormData()
        .title("§4メンバー除外")
        .body(`§c${memberName}を${nation.name}から除外しますか？`)
        .button1("§1キャンセル")
        .button2("§4除外");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showMemberOptions(player, nationId, memberName);
            return;
        }
        if (response.selection === 1) {
            nation.members = nation.members.filter(name => name !== memberName);
            if (nation.leader === memberName && nation.members.length > 0) {
                nation.leader = nation.members[0];
            }
            if (nation.members.length === 0) {
                delete nationData[nationId];
            }
            setNationData(nationData);
            player.sendMessage(`§r[§b社会システム§r] §a${memberName}を${nation.name}から除外しました。`);
            showNationAdminOptions(player, nationId);
        }
    });
}

// 国名変更（管理者用）
function adminChangeNationName(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        showNationAdminOptions(player, nationId);
        return;
    }

    const form = new ModalFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}名変更`)
        .textField(`§f新しい${world.getDynamicProperty('WorldgroupName')}名`, nation.name);

    form.show(player).then((response) => {
        if (response.canceled || !response.formValues) {
            showNationAdminOptions(player, nationId);
            return;
        }
        const [newName] = response.formValues;
        if (!newName) {
            player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}名を入力してください。`);
            showNationAdminOptions(player, nationId);
            return;
        }
        const newNationId = newName.toLowerCase().replace(/\s/g, "_");
        if (nationData[newNationId] && newNationId !== nationId) {
            player.sendMessage(`§r[§b社会システム§r] §cこの${world.getDynamicProperty('WorldgroupName')}名はすでに使用されています。`);
            showNationAdminOptions(player, nationId);
            return;
        }

        nationData[newNationId] = { ...nation, name: newName };
        if (newNationId !== nationId) {
            delete nationData[nationId];
        }
        setNationData(nationData);

        const chunkData = getChunkData();
        for (const chunkKey in chunkData) {
            if (chunkData[chunkKey].nation === nationId) {
                chunkData[chunkKey].nation = newNationId;
            }
        }
        setChunkData(chunkData);

        player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}名を「§e${newName}§a」に変更しました。`);
        showNationAdminOptions(player, nationId);
    });
}

// 国強制削除確認
function confirmForceDissolveNation(player, nationId) {
    const nationData = getNationData();
    const nation = nationData[nationId];
    if (!nation) {
        player.sendMessage(`§r[§b社会システム§r] §c${world.getDynamicProperty('WorldgroupName')}が存在しません。`);
        manageNations(player);
        return;
    }

    const form = new MessageFormData()
        .title(`§4${world.getDynamicProperty('WorldgroupName')}強制削除`)
        .body(`§c本当に「§e${nation.name}§c」を強制削除しますか？\n§7この操作は元に戻せません。`)
        .button1("§1キャンセル")
        .button2("§4削除");

    form.show(player).then((response) => {
        if (response.canceled || response.selection === 0) {
            showNationAdminOptions(player, nationId);
            return;
        }
        if (response.selection === 1) {
            delete nationData[nationId];
            setNationData(nationData);

            const chunkData = getChunkData();
            for (const chunkKey in chunkData) {
                if (chunkData[chunkKey].nation === nationId) {
                    delete chunkData[chunkKey];
                }
            }
            setChunkData(chunkData);

            player.sendMessage(`§r[§b社会システム§r] §a${world.getDynamicProperty('WorldgroupName')}「§e${nation.name}§a」を強制削除しました。`);
            manageNations(player);
        }
    });
}

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const chunk = getChunkCoords(event.block.location);
    const chunkData = getChunkData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = "";

    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = "§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを破壊できません。";
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        event.cancel = true;
        const now = Date.now();
        const last = lastWarnTime.get(player.id) ?? 0;
        if (now - last >= 3000) { // 3秒クールタイム
            player.sendMessage(message);
            lastWarnTime.set(player.id, now);
        }
    }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.player;
    const block = event.block;
    const chunk = getChunkCoords(block.location);
    const chunkData = getChunkData();
    const chunkKey = `${chunk.x}:${chunk.z}`;

    let shouldCancel = false;
    let message = "";

    if (!chunkData[chunkKey]) {
        const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
        if (!allowInteraction) {
            shouldCancel = true;
            message = "§r[§b社会システム§r] §cこのチャンクは購入されていません。社会システムが有効なため、ブロックを設置できません。";
        }
    } else {
        const nationData = getNationData();
        const nation = nationData[chunkData[chunkKey].nation];
        if (!nation || !nation.members.includes(player.name)) {
            shouldCancel = true;
            message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。`;
        }
    }

    if (shouldCancel) {
        try {
            block.dimension.runCommandAsync(`setblock ${block.x} ${block.y} ${block.z} air`);
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) { // 3秒クールタイム
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        } catch (e) {
            console.warn("Failed to remove placed block:", e);
        }
    }
});


// 危険なアイテムの使用制限
const lastWarnTime = new Map(); // プレイヤーごとの警告タイムスタンプ

world.beforeEvents.itemUseOn.subscribe((event) => {
    if (!isSystemEnabled()) return;

    const player = event.source;
    const item = event.itemStack;
    if (player.typeId !== "minecraft:player") return;

    const DANGEROUS_ITEMS = JSON.parse(world.getDynamicProperty('DANGEROUS_ITEMS') ?? '[]');
    if (!DANGEROUS_ITEMS.includes(item?.typeId)) {
        const chunk = getChunkCoords(player.location);
        const chunkData = getChunkData();
        const chunkKey = `${chunk.x}:${chunk.z}`;

        let shouldCancel = false;
        let message = "";

        if (!chunkData[chunkKey]) {
            const allowInteraction = world.getDynamicProperty(UNOWNED_LAND_INTERACTION) === true;
            if (!allowInteraction) {
                shouldCancel = true;
                message = "§r[§b社会システム§r] §cこのチャンクは購入されていません。このアイテムを使用できません。";
            }
        } else {
            const nationData = getNationData();
            const nation = nationData[chunkData[chunkKey].nation];
            if (!nation || !nation.members.includes(player.name)) {
                shouldCancel = true;
                message = `§r[§b社会システム§r] §cこのチャンクは別の${world.getDynamicProperty('WorldgroupName')}が所有しています。このアイテムは使用できません。`;
            }
        }

        if (shouldCancel) {
            event.cancel = true;
            const now = Date.now();
            const last = lastWarnTime.get(player.id) ?? 0;
            if (now - last >= 3000) { // 3秒クールタイム
                player.sendMessage(message);
                lastWarnTime.set(player.id, now);
            }
        }
    }
});

// プレイヤーの最後の国IDを保持するマップ（チャンクキーではなく国IDを追跡）
const lastPlayerNation = new Map();

// 定期的にプレイヤーの国移動を監視
system.runInterval(() => {
    if (!isSystemEnabled()) return;

    for (const player of world.getPlayers()) {
        const chunk = getChunkCoords(player.location);
        const chunkKey = `${chunk.x}:${chunk.z}`;
        const chunkData = getChunkData();
        const nationData = getNationData();

        // 現在の国のIDを取得（未所属の場合はnull）
        const currentNationId = chunkData[chunkKey]?.nation || null;
        const lastNationId = lastPlayerNation.get(player.id);

        // 国が変更された場合のみタイトルを表示
        if (lastNationId !== currentNationId) {
            try {
                if(!world.getDynamicProperty('WorldTitle')){
                    return;
                }
                if (currentNationId) {
                    const nation = nationData[currentNationId];
                    if (nation) {
                        player.runCommandAsync(`title ${player.name} title §a${nation.name}§r`);
                    }
                } else {
                    player.runCommandAsync(`title ${player.name} title §7${world.getDynamicProperty('WorldspaceNAME')}§r`);
                }
            } catch (e) {
                console.warn(`Failed to display title for ${player.name}:`, e);
            }

            // 最後の国IDを更新
            lastPlayerNation.set(player.id, currentNationId);
        }
    }
}, 35); // 20ティック（1秒）ごとにチェック

// プレイヤーが参加したときに初期国を設定
world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    const chunk = getChunkCoords(player.location);
    const chunkKey = `${chunk.x}:${chunk.z}`;
    const chunkData = getChunkData();
    const nationId = chunkData[chunkKey]?.nation || null;
    lastPlayerNation.set(player.id, nationId);
});
