import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { checkModePlayers, playerCheckModeStatus, currentTPS, chestCheckModePlayers } from './main';

import { showMainMenu_Location } from './log/Location';

import { showRestoreUI } from './reset/BlockRestore';

import { SettingUI } from './setting';

import { startPerformanceDiagnosis } from './detection/performance';

import { showMonitorSelectUI, isMonitoringPlayer, stopMonitoringPlayer } from './detection/monitor.js';

import { showPlayerSelectionForInventory } from './toul/inventory_check.js';

world.beforeEvents.chatSend.subscribe(event => {
    if (world.getDynamicProperty('CHAT_LEVEL') == 0) {
        return;
    }
    const player = event.sender;
    const message = event.message;

    if (message == '!scp' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (checkModePlayers.has(player.name)) {
                checkModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                checkModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scb' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (playerCheckModeStatus[player.name] == true) {
                playerCheckModeStatus[player.name] = false;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                playerCheckModeStatus[player.name] = true;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§e破壊された周辺のブロックタッチすると破壊者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scc' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (chestCheckModePlayers.has(player.name)) {
                chestCheckModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                chestCheckModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5ON§rにしました.§eチェストや樽をタッチするとアクセス履歴を見れます');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
});

export function UI(player) {
    // --- データ容量計算ロジック ---
    let totalStorageSize = '計算中...';
    try {
        let totalBytes = 0;
        const keys = world.getDynamicPropertyIds();

        for (const key of keys) {
            // キー自体の長さ
            totalBytes += key.length;

            const value = world.getDynamicProperty(key);
            if (typeof value === 'string') {
                // 文字列の長さ (JSONデータが大半なのでこれで概算)
                totalBytes += value.length;
            } else if (typeof value === 'number') {
                totalBytes += 8; // 数値は約8バイト
            } else if (typeof value === 'boolean') {
                totalBytes += 4; // 真偽値は約4バイト
            }
        }

        // 表示単位の調整
        if (totalBytes < 1024) {
            totalStorageSize = `${totalBytes} B`;
        } else if (totalBytes < 1024 * 1024) {
            totalStorageSize = `${(totalBytes / 1024).toFixed(2)} KB`;
        } else {
            totalStorageSize = `${(totalBytes / (1024 * 1024)).toFixed(2)} MB`;
        }
    } catch (e) {
        totalStorageSize = 'エラー';
    }

    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;

    var players = world.getPlayers();
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`§b${time}`);
    form.divider();
    form.label(`§r・§aプレイヤー人数§r: §r§b${players.length}\n§r・§eTPS§r:§b${currentTPS}\n§r・§cデータ容量(約)§r:§b${totalStorageSize}`);
    form.divider();
    form.button('§0セキュリティー情報', 'textures/ui/blue_info_glyph.png');
    form.button('§1座標ログ', 'textures/ui/icon_timer.png');
    form.button('§2確認モード', 'textures/ui/check.png');
    form.button('§5復元', 'textures/ui/backup_replace.png');
    form.button('§4信頼メンバー', 'textures/ui/permissions_member_star.png');
    form.button('§0パフォーマンス', 'textures/ui/bubble_empty');
    form.button('§4プレイヤー視点を監視', 'textures/ui/bubble_empty');
    form.button('§5インベントリ確認', 'textures/ui/bubble_empty');
    form.button('§1設定', 'textures/ui/icon_setting');
    form.button('§0アドオン情報\n§8Version', 'textures/items/stick');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Securityinformation(player);
                break;
            case 1:
                showMainMenu_Location(player);
                break;
            case 2:
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                form.label('>>> §eモードを操作してください');
                form.toggle('§a設置確認', {
                    defaultValue: checkModePlayers.has(player.name),
                });
                form.toggle('§c破壊確認', {
                    defaultValue: playerCheckModeStatus[player.name] ?? false,
                });
                form.toggle('§eアクセス確認', {
                    defaultValue: chestCheckModePlayers.has(player.name) ?? false,
                });
                form.submitButton(`§1適用`);
                form.show(player).then(r => {
                    if (r.canceled) {
                        UI(player);
                        return;
                    }
                    const [Text, setPlacementCheck, setBreakCheck, setChestCheck] = r.formValues;
                    const wasPlacementCheck = checkModePlayers.has(player.name);
                    const wasBreakCheck = playerCheckModeStatus[player.name] ?? false;
                    const wasChestCheck = chestCheckModePlayers.has(player.name);

                    // 設置チェック切替
                    if (setPlacementCheck !== wasPlacementCheck) {
                        if (setPlacementCheck) {
                            checkModePlayers.add(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            checkModePlayers.delete(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }

                    // 破壊チェック切替
                    if (setBreakCheck !== wasBreakCheck) {
                        playerCheckModeStatus[player.name] = setBreakCheck;
                        if (setBreakCheck) {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§eブロック周辺をタッチで破壊履歴を確認');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }

                    if (setChestCheck !== wasChestCheck) {
                        if (setChestCheck) {
                            chestCheckModePlayers.add(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5ON§rにしました.§e収納ブロックや竈をタッチするとアクセス履歴を見れます');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            chestCheckModePlayers.delete(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }
                });
                break;
            case 3:
                showRestoreUI(player);
                break;
            case 4:
                showPlayerSelector(player);
                break;
            case 5:
                Performance(player);
                break;
            case 6: // プレイヤー監視
                showMonitorSelectUI(player);
                break;
            case 7: // インベントリ確認
                showPlayerSelectionForInventory(player);
                break;
            case 8:
                SettingUI(player);
                break;
            case 9:
                var form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                form.body(`§aアドオン名§r:§bSecurityCraft-Core\n§eVersion§r:§b3.11.0\n§cリリース日§r:§b2026/03/04`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //戻る
                            UI(player);
                            break;
                    }
                });
                break;
            default:
                break;
        }
    });
}

function showPlayerSelector(player) {
    const allPlayers = world.getAllPlayers();
    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body('>>> §eプレイヤー選択して権限を切り替え');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (const targetPlayer of allPlayers) {
        const isMember = targetPlayer.hasTag('SecurityMember');

        if (isMember) {
            form.button(`§0${targetPlayer.name}§r\n§0(§1信頼済み§0)`, 'textures/ui/bubble_empty');
        } else {
            form.button(`§0${targetPlayer.name}§r\n§0(§4未設定§0)`, 'textures/ui/bubble_empty');
        }
    }

    // フォームを表示
    form.show(player).then(response => {
        if (response.canceled) {
            return;
        }

        if (response.selection === 0) {
            UI(player);
            return;
        }
        // 選択されたプレイヤーを取得
        const selectedPlayer = allPlayers[response.selection - 1];

        if (!selectedPlayer) return; // エラー回避

        // 権限のトグル処理（切り替え）
        const isMember = selectedPlayer.hasTag('SecurityMember');

        if (isMember) {
            selectedPlayer.removeTag('SecurityMember');
            player.sendMessage(`§r[§bSecurityCraft§r] §b${selectedPlayer.name}§rを§eMember§rから§c解除しました`);
            player.playSound('random.orb', { pitch: 0.8, volume: 1.0 });
        } else {
            selectedPlayer.addTag('SecurityMember');
            player.sendMessage(`§r[§bSecurityCraft§r] §b${selectedPlayer.name}§rを§eMember§rに§a追加しました`);
            player.playSound('random.toast', { pitch: 1.0, volume: 1.0 });
        }
        system.run(() => {
            showPlayerSelector(player);
        });
    });
}

function Performance(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`>>> §e選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§0パフォーマンス診断', 'textures/ui/bubble_empty');
    form.button('§1エンティティ情報', 'textures/ui/bubble_empty');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                UI(player);
                break;
            case 1:
                //パフォーマンス診断開始
                startPerformanceDiagnosis(player);
                break;
            case 2:
                //エンティティ情報表示
                showEntityCountUI(player);
                break;
        }
    });
}

function showEntityCountUI(player) {
    const form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');

    let bodyText = '各ディメンションのエンティティ数\n\n';
    const dimensionIds = ['overworld', 'nether', 'the_end'];

    for (const dimId of dimensionIds) {
        bodyText += `${getDimensionName(dimId)}§r\n--------------------\n`;

        try {
            const dimension = world.getDimension(dimId);
            const entities = dimension.getEntities();
            if (entities.length === 0) {
                bodyText += '§7エンティティはいません\n\n';
                continue;
            }
            const entityCounts = new Map();
            for (const entity of entities) {
                const count = entityCounts.get(entity.typeId) || 0;
                entityCounts.set(entity.typeId, count + 1);
            }

            const sortedCounts = new Map([...entityCounts.entries()].sort());
            for (const [typeId, count] of sortedCounts) {
                const cleanTypeId = typeId.replace('minecraft:', '');
                bodyText += `§r- §e${cleanTypeId}§r: §b${count}\n`;
            }
        } catch (error) {
            bodyText += '§c読み込み失敗\n';
        }

        bodyText += '\n';
    }

    form.body(bodyText);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.selection === 0) {
            Performance(player);
        }
    });
}

function getDimensionName(dimId) {
    switch (dimId) {
        case 'overworld':
            return '§2オーバーワールド§r';
        case 'nether':
            return '§4ネザー§r';
        case 'the_end':
            return '§5エンド§r';
        default:
            return dimId;
    }
}

function Securityinformation(player) {
    const form = new ActionFormData();

    form.title('§0SecurityCraft-§1Core');
    form.body(`>>> §eセキュリティー情報`);

    const logSystem = world.getDynamicProperty('Log_system');
    const placeBlockSystem = world.getDynamicProperty('PlaceBlock_system');
    const breakBlockSystem = world.getDynamicProperty('BreakBlock_system');
    const chestLogSystem = world.getDynamicProperty('ChestLog_system');
    const itemUseOnSystem = world.getDynamicProperty('itemUseOn_system');
    const chatLevel = world.getDynamicProperty('CHAT_LEVEL');
    const BlockRestoreSystem = world.getDynamicProperty('BlockRestore_system');
    const ProxyCheck_system = world.getDynamicProperty('ProxyCheck_system');

    const getStatusText = status => {
        if (status === true || status === 'ON') {
            return `§a有効`; // 緑色
        }
        return `§c無効`; // 赤色
    };

    const getLevelText = level => {
        if (typeof level === 'number' && level > 0) {
            return `§eLevel ${level}`; // 黄色
        }
        return `§7無効`; // 灰色
    };

    const securityInfo = [
        `§7・座標ログ: ${getStatusText(logSystem)}`,
        `§7・設置記録: ${getStatusText(placeBlockSystem)}`,
        `§7・破壊記録: ${getStatusText(breakBlockSystem)}`,
        `§7・アクセス記録: ${getStatusText(chestLogSystem)}`,
        `§7・復元システム: ${getStatusText(BlockRestoreSystem)}`,
        `§7・禁止アイテム設置検知: ${getStatusText(itemUseOnSystem)}`,
        `§7・不正プロキシ検知: ${getStatusText(ProxyCheck_system)}`,
        `§7・不正チャット検知: ${getLevelText(chatLevel)}`,
    ].join('\n'); // 配列の各要素を改行で連結

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.divider();
    form.label(securityInfo);

    // --- フォームを表示 ---
    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            UI(player);
        }
    });
}
