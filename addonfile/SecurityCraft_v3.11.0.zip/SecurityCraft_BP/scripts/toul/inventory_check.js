import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';

import { UI } from '../ui.js';

/**
 * インベントリを確認するプレイヤーを選択するUIを表示します。
 * @param {import('@minecraft/server').Player} player UIを表示するプレイヤー
 */
export function showPlayerSelectionForInventory(player) {
    const allPlayers = world.getAllPlayers();
    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body('>>> §e確認するプレイヤーを選択');
    form.button('§l戻る', 'textures/ui/icon_import.png');

    for (const targetPlayer of allPlayers) {
        form.button(`§0${targetPlayer.name}`, 'textures/ui/bubble_empty');
    }

    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            UI(player);
            return;
        }

        const selectedPlayer = allPlayers[response.selection - 1];
        if (selectedPlayer) {
            showInventoryContents(player, selectedPlayer);
        }
    });
}

function showInventoryContents(player, targetPlayer) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;
    const inventory = targetPlayer.getComponent('inventory').container;
    const form = new ActionFormData().title(`§4${targetPlayer.name} §0のインベントリ`);

    let bodyText = '';
    let itemCount = 0;

    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (item) {
            const cleanTypeId = item.typeId.replace('minecraft:', '');
            bodyText += `§r- §e${cleanTypeId} §r(§b${item.amount}§r個)\n`;
            itemCount++;
        }
    }

    if (itemCount === 0) {
        bodyText = '§7インベントリは空です';
    }

    form.body(`${time}`);
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.label(bodyText);

    form.show(player).then(() => {
        showPlayerSelectionForInventory(player);
    });
}
