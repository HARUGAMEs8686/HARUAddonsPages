import { world } from '@minecraft/server';

export function ProxyCheck() {
    world.afterEvents.playerSpawn.subscribe(event => {
        if (!world.getDynamicProperty('ProxyCheck_system')) return;

        const { player } = event;

        if (world.getAllPlayers().length >= 2 && player.clientSystemInfo.maxRenderDistance === 0) {
            // プレイヤーをキック
            player.runCommand('kick @s 不正なクライアント接続を検知しました');

            const players = world.getPlayers();
            for (const messageplayer of players) {
                messageplayer.sendMessage(`[§bSecurityCraft§r] §e${player.name}§r:§c不正なクライアント接続を検知した為追放しました`);
            }
        }
    });
}