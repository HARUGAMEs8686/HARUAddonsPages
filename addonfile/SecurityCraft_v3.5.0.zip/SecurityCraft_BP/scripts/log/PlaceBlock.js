import { world, system } from '@minecraft/server';
import { checkModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // Default to 7 days if not set
let pendingUpdates = new Map();

export function preload() {
    try {
        const storedDays = world.getDynamicProperty('placeblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`Error loading placeblock_delete_days: ${e}`);
    }
}

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    let dataString;
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
    }
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        return storedData ? new Map(JSON.parse(storedData)) : new Map();
    } catch (e) {
        return new Map();
    }
}

function getChunkDataForBlock(x, z) {
    const chunkData = new Map();
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);
        const data = getChunkData(chunkKey);
        for (const [pos, value] of data) {
            if (!chunkData.has(pos) || value.t > (chunkData.get(pos)?.t || 0)) {
                chunkData.set(pos, value);
            }
        }
    }
    return chunkData;
}

// Process pending updates
system.runInterval(() => {
    for (const [chunkKey, chunkData] of pendingUpdates) {
        saveChunkData(chunkKey, chunkData);
    }
}, 1);

// Clear old keys
system.runInterval(() => {
    const allKeys = world.getDynamicPropertyIds();
    const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
    const expirationDay = currentDay - DAYS_TO_KEEP;
    for (const key of allKeys) {
        if (key.match(/^-?\d+_-?\d+_\d+$/)) {
            const [, , , day] = key.split('_').map(Number);
            if (day < expirationDay) {
                world.setDynamicProperty(key, undefined);
            }
        }
    }
}, 1200); // 1分ごと

export function PlaceBlock() {
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        let chunkData = getChunkData(chunkKey);
        chunkData.set(positionKey, {
            p: player.name,
            t: Date.now()
        });

        const expirationTime = Date.now() - (DAYS_TO_KEEP * MILLISECONDS_PER_DAY);
        for (const [pos, data] of chunkData) {
            if (data.t < expirationTime) {
                chunkData.delete(pos);
            }
        }

        pendingUpdates.set(chunkKey, chunkData);
    });

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const block = event.block;
        const { x, y, z } = block;
        const chunkData = getChunkDataForBlock(x, z);
        const positionKey = getPositionKey(x, y, z);
        if (chunkData.delete(positionKey)) {
            const currentChunkKey = getChunkKey(x, z);
            pendingUpdates.set(currentChunkKey, chunkData);
        }
    });

    const playerCache = new Map();
    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!checkModePlayers.has(player.name) || playerCache.has(player.id)) return;

            playerCache.set(player.id, true);
            const block = event.block;
            const { x, y, z } = block;
            const positionKey = getPositionKey(x, y, z);
            const chunkData = getChunkDataForBlock(x, z);
            const blockData = chunkData.get(positionKey);

            if (blockData) {
                player.sendMessage(`§r[§bSecurity§r] §5${blockData.p}§rによって§e設置`);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurity§r] §cこのブロックの設置者情報はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }

            system.runTimeout(() => playerCache.delete(player.id), 10);
        });
    });
}

export function clearAllPlaceData() {
    console.log('Clearing all place data...');
    const allKeys = world.getDynamicPropertyIds();
    for (const key of allKeys) {
        if (key.match(/^-?\d+_-?\d+_\d+$/)) {
            world.setDynamicProperty(key, undefined);
        }
    }
    pendingUpdates.clear();
    console.log('All place data cleared.');
}