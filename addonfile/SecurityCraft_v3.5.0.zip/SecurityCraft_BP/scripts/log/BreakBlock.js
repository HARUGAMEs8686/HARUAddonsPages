import { world, system } from '@minecraft/server';
import { playerCheckModeStatus } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // Default to 7 days if not set
let pendingUpdates = {};

// Initialize DAYS_TO_KEEP
export function breload() {
    try {
        const storedDays = world.getDynamicProperty('breakblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
            console.log(`Loaded DAYS_TO_KEEP: ${DAYS_TO_KEEP}`);
        }
    } catch (e) {
        console.warn(`Error loading breakblock_delete_days: ${e.message}`);
    }
}

// Run breload on world load
world.afterEvents.worldLoad.subscribe(() => {
    breload();
});

// Initialize immediately as well
breload();

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `break_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    const MAX_SIZE = 256 * 1024; // 256KB
    let part = 1;
    let currentData = {};
    const newParts = [];

    for (const [positionKey, data] of Object.entries(chunkData)) {
        const temp = { ...currentData, [positionKey]: data };
        const tempString = JSON.stringify(temp);

        if (tempString.length > MAX_SIZE) {
            if (Object.keys(currentData).length > 0) {
                newParts.push(JSON.stringify(currentData));
            }
            currentData = { [positionKey]: data };
            part++;
        } else {
            currentData = temp;
        }
    }

    if (Object.keys(currentData).length > 0) {
        newParts.push(JSON.stringify(currentData));
    }

    try {
        for (let i = 0; i < newParts.length; i++) {
            world.setDynamicProperty(`${chunkKey}_part${i + 1}`, newParts[i]);
        }

        let oldPart = newParts.length + 1;
        while (world.getDynamicProperty(`${chunkKey}_part${oldPart}`)) {
            world.setDynamicProperty(`${chunkKey}_part${oldPart}`, undefined);
            oldPart++;
        }

        delete pendingUpdates[chunkKey];
    } catch (e) {}
}

function getChunkData(chunkKey) {
    let chunkData = {};
    let part = 1;
    while (true) {
        const storedData = world.getDynamicProperty(`${chunkKey}_part${part}`);
        if (!storedData) break;
        try {
            Object.assign(chunkData, JSON.parse(storedData));
        } catch (e) {}
        part++;
    }
    return chunkData;
}

function getChunkDataForBlock(x, z) {
    let chunkData = {};
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);
        const data = getChunkData(chunkKey);
        for (const [pos, value] of Object.entries(data)) {
            if (!chunkData[pos] || value.t > (chunkData[pos]?.t || 0)) {
                chunkData[pos] = value;
            }
        }
    }
    return chunkData;
}

function cleanOldData() {
    try {
        const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
        const expirationDay = currentDay - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                const match = key.match(/break_(-?\d+)_(-?\d+)_(\d+)(?:_part\d+)?/);
                if (match && parseInt(match[3]) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                    console.log(`Cleared old key: ${key}`);
                }
            }
        }
    } catch (e) {
        console.warn(`Error cleaning old data: ${e.message}`);
    }
}

system.runInterval(() => {
    const updatesToProcess = { ...pendingUpdates };
    for (const chunkKey in updatesToProcess) {
        try {
            saveChunkData(chunkKey, updatesToProcess[chunkKey]);
        } catch (e) {
            console.warn(`Error saving chunk data for ${chunkKey}: ${e.message}`);
        }
    }
    pendingUpdates = {};
    cleanOldData();
}, 1);

export function clearAllBreakData() {
    try {
        console.log('Clearing all break data...');
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
        pendingUpdates = {};
        console.log('All break data cleared.');
    } catch (e) {
        console.warn(`Error clearing break data: ${e.message}`);
    }
}

export function BreakBlock() {
    const lastBreakTime = new Map();

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const player = event.player;
        const block = event.block;
        const { x, y, z } = block;
        const now = Date.now();
        const lastBreak = lastBreakTime.get(player.name) || 0;

        if (now - lastBreak < 100) return;
        lastBreakTime.set(player.name, now);

        const chunkKey = getChunkKey(x, z);
        const positionKey = getPositionKey(x, y, z);

        let chunkData = getChunkData(chunkKey);
        chunkData[positionKey] = {
            b: player.name,
            t: now,
            bt: block.typeId.replace('minecraft:', ''), // Optimize size
        };
        pendingUpdates[chunkKey] = chunkData;

        // Clean old data within chunk
        const expirationTime = Date.now() - DAYS_TO_KEEP * MILLISECONDS_PER_DAY;
        for (const [pos, data] of Object.entries(chunkData)) {
            if (data.t < expirationTime) {
                delete chunkData[pos];
            }
        }
        pendingUpdates[chunkKey] = chunkData;
    });

    const lastCheckTime = new Map();

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const player = event.player;
            if (!playerCheckModeStatus[player.name]) return;

            const now = Date.now();
            const lastCheck = lastCheckTime.get(player.name) || 0;
            if (now - lastCheck < 1000) return;
            lastCheckTime.set(player.name, now);

            if (!event.block || !event.block.location) {
                console.error('Invalid block location');
                return;
            }

            const nearbyBreaks = getNearbyBreakHistory(event.block.location);

            if (nearbyBreaks.length > 0) {
                displayBreakSummary(player, nearbyBreaks);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurity§r] §eこの周辺に最近の破壊履歴はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }
        });
    });

    function getNearbyBreakHistory(position) {
        const history = [];
        const radius = 7;
        const { x, y, z } = position;

        const minChunkX = Math.floor((x - radius) / CHUNK_SIZE);
        const maxChunkX = Math.floor((x + radius) / CHUNK_SIZE);
        const minChunkZ = Math.floor((z - radius) / CHUNK_SIZE);
        const maxChunkZ = Math.floor((z + radius) / CHUNK_SIZE);

        for (let cx = minChunkX; cx <= maxChunkX; cx++) {
            for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
                const chunkData = getChunkDataForBlock(cx * CHUNK_SIZE, cz * CHUNK_SIZE);
                for (let dx = -radius; dx <= radius; dx++) {
                    for (let dy = -radius; dy <= radius; dy++) {
                        for (let dz = -radius; dz <= radius; dz++) {
                            const checkX = x + dx;
                            const checkY = y + dy;
                            const checkZ = z + dz;
                            if (Math.floor(checkX / CHUNK_SIZE) === cx && Math.floor(checkZ / CHUNK_SIZE) === cz) {
                                const checkPos = getPositionKey(checkX, checkY, checkZ);
                                if (chunkData[checkPos]) {
                                    const record = chunkData[checkPos];
                                    history.push({
                                        position: `(${checkX},${checkY},${checkZ})`,
                                        breaker: record.b,
                                        timestamp: new Date(record.t).toLocaleString('ja-JP').split(' ')[1],
                                        blockType: record.bt,
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
        return history;
    }

    function displayBreakSummary(player, breaks) {
        const currentTime = new Date().toLocaleString('ja-JP').split(' ')[1];
        player.sendMessage(`§7[§b破壊概要§7 | §f${currentTime}§7]`);

        const breakCount = new Map();
        const latestBreaks = new Map();
        breaks.forEach(record => {
            breakCount.set(record.breaker, (breakCount.get(record.breaker) || 0) + 1);
            latestBreaks.set(record.breaker, {
                timestamp: record.timestamp,
                position: record.position,
                blockType: record.bt,
            });
        });

        const sortedBreakers = Array.from(breakCount.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 3);

        sortedBreakers.forEach(([breaker, count], index) => {
            const latest = latestBreaks.get(breaker);
            player.sendMessage(`§a#${index + 1} §c${breaker} §e${latest.timestamp} §6${latest.position} §b${count}個`);
        });

        player.sendMessage(`§7合計: §f${breaks.length}件 (§f${breakCount.size}人)`);
    }
}
