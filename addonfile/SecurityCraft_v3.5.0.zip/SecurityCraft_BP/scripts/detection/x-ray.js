import { world, system } from '@minecraft/server';

// プレイヤーの追跡データを読み込み
function loadTrackedPlayers() {
    const data = world.getDynamicProperty('trackedPlayers');
    return data ? JSON.parse(data) : {};
}
const trackedPlayers = loadTrackedPlayers();

// プレイヤーの追跡データを保存
function saveTrackedPlayers() {
    world.setDynamicProperty('trackedPlayers', JSON.stringify(trackedPlayers));
}

// グローバル統計データを読み込み
function loadGlobalStats() {
    const data = world.getDynamicProperty('globalStats');
    return data ? JSON.parse(data) : {
        totalMined: 0,
        'minecraft:diamond_ore': 0,
        'minecraft:deepslate_diamond_ore': 0,
        'minecraft:ancient_debris': 0,
        'minecraft:emerald_ore': 0,
        'minecraft:deepslate_emerald_ore': 0,
    };
}
const globalStats = loadGlobalStats();

// グローバル統計データを保存
function saveGlobalStats() {
    world.setDynamicProperty('globalStats', JSON.stringify(globalStats));
}

// 設置されたブロックのデータを読み込み
function loadPlacedBlocks() {
    const data = world.getDynamicProperty('placedBlocks');
    return data ? new Map(JSON.parse(data)) : new Map();
}
let placedBlocks = loadPlacedBlocks();

// 設置されたブロックのデータを保存
function savePlacedBlocks() {
    const now = Date.now();
    for (const [key, timestamp] of placedBlocks) {
        // 古いブロックデータを削除
        if (now - timestamp > PLACED_BLOCK_EXPIRY) {
            placedBlocks.delete(key);
        }
    }
    const serialized = JSON.stringify([...placedBlocks]);
    // データサイズが大きくなりすぎた場合、半分にトリミング
    if (serialized.length > 30000) {
        trimPlacedBlocks();
    }
    world.setDynamicProperty('placedBlocks', JSON.stringify([...placedBlocks]));
}

// 設置されたブロックのデータをトリミング
function trimPlacedBlocks() {
    const entries = [...placedBlocks.entries()];
    const halfLength = Math.floor(entries.length / 2);
    placedBlocks = new Map(entries.slice(halfLength));
}

export function Xray() {
    const ORE_LIMITS = {
        'minecraft:diamond_ore': 10,
        'minecraft:deepslate_diamond_ore': 10,
        'minecraft:ancient_debris': 8,
        'minecraft:emerald_ore': 15,
        'minecraft:deepslate_emerald_ore': 15,
    };

    const SUSPICION_RESET_TIME = 290000; // 7分（ミリ秒）
    const PLACED_BLOCK_EXPIRY = 24 * 60 * 60 * 1000; // 24時間（ミリ秒）
    const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL') || 1;

    const LEVEL_CONFIGS = {
        1: {
            TIME_WINDOW: 150,
            MIN_BREAK_INTERVAL: 400,
            SUSPICIOUS_THRESHOLD: 10,
            WARN_LIMIT: 6,
            DETECTION_RADIUS: 6,
            NEARBY_RADIUS: 5,
            MAX_NON_ORE_BLOCKS_BEFORE_ORE: 10,
            MINED_HISTORY_SIZE: 10,
        },
        2: {
            TIME_WINDOW: 120,
            MIN_BREAK_INTERVAL: 350,
            SUSPICIOUS_THRESHOLD: 9,
            WARN_LIMIT: 5,
            DETECTION_RADIUS: 6,
            NEARBY_RADIUS: 5,
            MAX_NON_ORE_BLOCKS_BEFORE_ORE: 8,
            MINED_HISTORY_SIZE: 8,
        },
        3: {
            TIME_WINDOW: 90,
            MIN_BREAK_INTERVAL: 300,
            SUSPICIOUS_THRESHOLD: 8,
            WARN_LIMIT: 4,
            DETECTION_RADIUS: 5,
            NEARBY_RADIUS: 4,
            MAX_NON_ORE_BLOCKS_BEFORE_ORE: 6,
            MINED_HISTORY_SIZE: 6,
        },
        4: {
            TIME_WINDOW: 60,
            MIN_BREAK_INTERVAL: 200,
            SUSPICIOUS_THRESHOLD: 6,
            WARN_LIMIT: 3,
            DETECTION_RADIUS: 4,
            NEARBY_RADIUS: 3,
            MAX_NON_ORE_BLOCKS_BEFORE_ORE: 4,
            MINED_HISTORY_SIZE: 4,
        },
        5: {
            TIME_WINDOW: 45,
            MIN_BREAK_INTERVAL: 150,
            SUSPICIOUS_THRESHOLD: 4,
            WARN_LIMIT: 2,
            DETECTION_RADIUS: 3,
            NEARBY_RADIUS: 2,
            MAX_NON_ORE_BLOCKS_BEFORE_ORE: 2,
            MINED_HISTORY_SIZE: 2,
        },
    };

    let TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE;

    if (X_RAY_LEVEL != 0) {
        ({ TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE } = LEVEL_CONFIGS[X_RAY_LEVEL]);
    }

    const placedExplosives = new Map();

    // プレイヤーの採掘速度を計算する関数
    function getPlayerMiningSpeed(player) {
        let speedMultiplier = 1.0;
        if (!player || typeof player !== 'object' || !player.getComponent) return speedMultiplier;

        const inventory = player.getComponent('minecraft:inventory');
        if (!inventory || !inventory.container) return speedMultiplier;

        const selectedSlot = player.selectedSlot;
        if (typeof selectedSlot !== 'number' || selectedSlot < 0) return speedMultiplier;

        const heldItem = inventory.container.getSlot(selectedSlot);
        if (heldItem && heldItem.typeId && heldItem.typeId.includes('pickaxe')) {
            const enchantments = heldItem.getComponent('minecraft:enchantments');
            if (enchantments) {
                const efficiency = enchantments.getEnchantment('efficiency');
                const efficiencyLevel = efficiency && typeof efficiency.level === 'number' ? efficiency.level : 0;
                speedMultiplier *= 1 + efficiencyLevel * 0.2;
            }
        }

        const effects = player.getEffects ? player.getEffects() : [];
        for (const effect of effects) {
            if (effect && effect.typeId === 'minecraft:haste' && typeof effect.amplifier === 'number') {
                speedMultiplier *= 1 + effect.amplifier * 0.2;
            }
        }

        if (player.hasTag && player.hasTag('beacon_haste')) {
            speedMultiplier *= 1.4;
        }

        return speedMultiplier;
    }

    // ブロックがプレイヤーの視線内にあるかをチェックする関数
    function isBlockInPlayerSight(player, blockLocation, maxDistance = 8) {
        const playerLocation = player.location;
        const viewDirection = player.getViewDirection();
        const eyeHeightOffset = 1.62;
        const eyeLocation = {
            x: playerLocation.x,
            y: playerLocation.y + eyeHeightOffset,
            z: playerLocation.z,
        };
        const blockCenter = {
            x: blockLocation.x + 0.5,
            y: blockLocation.y + 0.5,
            z: blockLocation.z + 0.5,
        };
        const toBlockX = blockCenter.x - eyeLocation.x;
        const toBlockY = blockCenter.y - eyeLocation.y;
        const toBlockZ = blockCenter.z - eyeLocation.z;
        const distance = Math.sqrt(toBlockX * toBlockX + toBlockY * toBlockY + toBlockZ * toBlockZ);

        if (distance > maxDistance) return false;

        let normalizedToBlockX = 0, normalizedToBlockY = 0, normalizedToBlockZ = 0;
        if (distance > 0) {
            normalizedToBlockX = toBlockX / distance;
            normalizedToBlockY = toBlockY / distance;
            normalizedToBlockZ = toBlockZ / distance;
        }

        const dotProduct = viewDirection.x * normalizedToBlockX + viewDirection.y * normalizedToBlockY + viewDirection.z * normalizedToBlockZ;
        const FOV_THRESHOLD = Math.cos(Math.PI / 4);

        if (dotProduct < FOV_THRESHOLD) return false;

        try {
            const hitResult = player.dimension.getBlockFromRay(eyeLocation, viewDirection, {
                maxDistance: maxDistance,
                includePassableBlocks: false,
                ignoreBlockPermutation: false,
            });

            if (hitResult && hitResult.block) {
                const hitBlockLoc = hitResult.block.location;
                const targetBlockLoc = blockLocation;
                if (hitBlockLoc.x === targetBlockLoc.x && hitBlockLoc.y === targetBlockLoc.y && hitBlockLoc.z === targetBlockLoc.z) {
                    return true;
                }
            }
        } catch (e) {
            console.error(`Error in getBlockFromRay: ${e}`);
        }
        return false;
    }

    // プレイヤーがブロックを設置した際のイベント
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        system.run(() => {
            const block = event.block;
            const blockType = block.type.id;
            const key = `${block.location.x},${block.location.y},${block.location.z}`;

            // 鉱石を設置した場合、設置ブロックとして記録
            if (blockType in ORE_LIMITS) {
                placedBlocks.set(key, Date.now());
                savePlacedBlocks();
            }

            // 爆発物を設置した場合、記録
            if (blockType === 'minecraft:tnt' || blockType === 'minecraft:respawn_anchor' || blockType === 'minecraft:bed') {
                placedExplosives.set(key, {
                    playerId: event.player.name,
                    type: blockType,
                    timestamp: Date.now(),
                });
            }
        });
    });

    // プレイヤーがブロックを破壊する際のイベント
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        const { MINED_HISTORY_SIZE, TIME_WINDOW, MIN_BREAK_INTERVAL, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, NEARBY_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE } = LEVEL_CONFIGS[X_RAY_LEVEL];

        const player = event.player;
        const block = event.block;
        if (!block) return;

        const playerId = player.name;
        const blockPos = block.location;
        if (!blockPos) return;

        const { x, y, z } = blockPos;
        const oreType = block.type.id;

        const blockKey = `${x},${y},${z}`;
        const isPlacedBlock = placedBlocks.has(blockKey);
        // 設置されたブロックなら検知対象外
        if (isPlacedBlock) {
            placedBlocks.delete(blockKey);
            savePlacedBlocks();
            return;
        }

        // プレイヤーデータが存在しない場合は初期化
        if (!trackedPlayers[playerId]) {
            trackedPlayers[playerId] = {
                ores: {},
                timestamp: Date.now(),
                lastBreakTime: 0,
                suspiciousCount: 0,
                warnCount: 0,
                lastBreakPos: null,
                totalBlocksMined: 0,
                reasons: {},
                straightMiningCount: 0,
                nearbyOreStreak: 0,
                nonOreBlocksMinedBeforeOre: 0,
                minedBlockHistory: [],
            };
        }

        let playerData = trackedPlayers[playerId];
        const now = Date.now();
        const isOre = oreType in ORE_LIMITS;

        // 掘ったブロックの履歴を更新
        playerData.minedBlockHistory.push({ type: oreType, location: blockPos, timestamp: now });
        if (playerData.minedBlockHistory.length > MINED_HISTORY_SIZE) {
            playerData.minedBlockHistory.shift();
        }

        // プレイヤーの統計データを更新
        playerData.totalBlocksMined++;
        globalStats.totalMined++;

        // 鉱石を掘る前の非鉱石ブロック数をリセット
        if (isOre) {
            playerData.nonOreBlocksMinedBeforeOre = 0;
        } else {
            playerData.nonOreBlocksMinedBeforeOre++;
        }

        // 鉱石を破壊した場合のみ検知ロジックを適用
        if (isOre) {
            const speedMultiplier = getPlayerMiningSpeed(player);
            const adjustedMinBreakInterval = MIN_BREAK_INTERVAL / speedMultiplier;

            // 鉱石を掘る前に不自然に非鉱石ブロックが少ない場合
            // これによりブランチマイニングを誤検知しにくくする
            if (playerData.nonOreBlocksMinedBeforeOre <= MAX_NON_ORE_BLOCKS_BEFORE_ORE) {
                playerData.suspiciousCount++;
                playerData.reasons['鉱石に一直線で到達'] = (playerData.reasons['鉱石に一直線で到達'] || 0) + 1;
            }

            // プレイヤーの視線内にブロックがなかった場合
            if (!isBlockInPlayerSight(player, blockPos, DETECTION_RADIUS)) {
                playerData.suspiciousCount++;
                playerData.reasons['視線外の鉱石を採掘'] = (playerData.reasons['視線外の鉱石を採掘'] || 0) + 1;
            }

            // 短時間に連続で採掘した場合
            if (playerData.lastBreakTime > 0 && now - playerData.lastBreakTime < adjustedMinBreakInterval) {
                playerData.suspiciousCount++;
                playerData.reasons['短時間で掘りすぎた回数'] = (playerData.reasons['短時間で掘りすぎた回数'] || 0) + 1;
            }
            playerData.lastBreakTime = now;

            // 直線掘りチェック
            if (playerData.lastBreakPos) {
                const { x: lastX, y: lastY, z: lastZ } = playerData.lastBreakPos;
                const dx = Math.abs(x - lastX);
                const dy = Math.abs(y - lastY);
                const dz = Math.abs(z - lastZ);
                const isStraightMining = dy <= 2 && (dx <= 1 || dz <= 1);
                if (isStraightMining) {
                    playerData.straightMiningCount = (playerData.straightMiningCount || 0) + 1;
                } else {
                    playerData.straightMiningCount = 0;
                }

                // 鉱石発見時に直線掘りが続いている場合
                if (playerData.straightMiningCount >= 5 && playerData.nonOreBlocksMinedBeforeOre < 2) {
                     playerData.suspiciousCount++;
                     playerData.reasons['直線掘り中に鉱石発見'] = (playerData.reasons['直線掘り中に鉱石発見'] || 0) + 1;
                }
            }
            playerData.lastBreakPos = { x, y, z };

            // 近くの鉱石を連続で掘ったかチェック
            if (playerData.minedBlockHistory.length >= 2) {
                const lastBlock = playerData.minedBlockHistory[playerData.minedBlockHistory.length - 2];
                const distance = Math.sqrt(
                    Math.pow(blockPos.x - lastBlock.location.x, 2) +
                    Math.pow(blockPos.y - lastBlock.location.y, 2) +
                    Math.pow(blockPos.z - lastBlock.location.z, 2)
                );
                if (isOre && lastBlock.type in ORE_LIMITS && distance < NEARBY_RADIUS) {
                    playerData.nearbyOreStreak = (playerData.nearbyOreStreak || 0) + 1;
                    if (playerData.nearbyOreStreak >= 3) {
                        playerData.suspiciousCount++;
                        playerData.reasons['近くの鉱石を連続で掘った回数'] = (playerData.reasons['近くの鉱石を連続で掘った回数'] || 0) + 1;
                    }
                } else {
                    playerData.nearbyOreStreak = 0;
                }
            }


            // プレイヤーの採掘数を更新
            playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
            globalStats[oreType] = (globalStats[oreType] || 0) + 1;
            saveGlobalStats();

            // 時間ウィンドウが経過した場合、データをリセット
            if (now - playerData.timestamp > TIME_WINDOW * 1000) {
                playerData.ores = {};
                playerData.timestamp = now;
                playerData.totalBlocksMined = 0;
                playerData.reasons = {};
                playerData.straightMiningCount = 0;
                playerData.nearbyOreStreak = 0;
                playerData.nonOreBlocksMinedBeforeOre = 0;
                playerData.minedBlockHistory = [];
            }

            // 異常に多い鉱石を掘ったかチェック
            if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
                playerData.suspiciousCount++;
                playerData.reasons['異常に多く掘った鉱石数'] = (playerData.reasons['異常に多く掘った鉱石数'] || 0) + 1;
            }

            // 異常に高い鉱石発見率をチェック
            const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
            const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
            if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
                playerData.suspiciousCount++;
                playerData.reasons['異常に高い鉱石発見率'] = (playerData.reasons['異常に高い鉱石発見率'] || 0) + 1;
            }
        }

        // 警告レベルのチェックと対応
        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                let suspiciousOre = null;
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += `\n  - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(通常: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                    if (playerOreRate > worldOreRate * 2) {
                        suspiciousOre = ore;
                    }
                }

                const detectedOre = suspiciousOre || oreType;
                world.sendMessage(`[§bSecurityCraft§r] §a${playerId} §rが§cX-ray§4の可能性 対象: §b${detectedOre}`);
                world.sendMessage(`§e詳細§r: 発見率${oreStatsMessage}`);
                console.warn(`[SecurityCraft§r] Possible "X-ray" by ${playerId} at: ${detectedOre}`);

                let reasonMessage = '';
                for (const reason in playerData.reasons) {
                    reasonMessage += `\n  - ${reason}: ${playerData.reasons[reason]}回`;
                }
                if (reasonMessage) {
                    world.getAllPlayers().forEach(p => {
                        if (p.hasTag('SecurityOP')) {
                            p.sendMessage(`§6不審な理由§r:${reasonMessage}`);
                        }
                    });
                }

                system.run(() => {
                    player.setGameMode('Adventure');
                    world.getAllPlayers().forEach(p => {
                        p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                    });
                });
            }
        }

        saveTrackedPlayers();
    });

    world.beforeEvents.explosion.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        const { TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL];
        const impactedBlocks = event.getImpactedBlocks();
        if (!impactedBlocks.length) return;

        let responsiblePlayerId = null;
        let totalX = 0, totalY = 0, totalZ = 0;
        for (const block of impactedBlocks) {
            totalX += block.location.x;
            totalY += block.location.y;
            totalZ += block.location.z;
        }
        const centerX = Math.floor(totalX / impactedBlocks.length);
        const centerY = Math.floor(totalY / impactedBlocks.length);
        const centerZ = Math.floor(totalZ / impactedBlocks.length);

        const BLAST_RADIUS = 7;
        for (let dx = -BLAST_RADIUS; dx <= BLAST_RADIUS; dx++) {
            for (let dy = -BLAST_RADIUS; dy <= BLAST_RADIUS; dy++) {
                for (let dz = -BLAST_RADIUS; dz <= BLAST_RADIUS; dz++) {
                    const checkX = centerX + dx;
                    const checkY = centerY + dy;
                    const checkZ = centerZ + dz;
                    const explosionKey = `${checkX},${checkY},${checkZ}`;
                    const explosiveData = placedExplosives.get(explosionKey);

                    if (explosiveData && Date.now() - explosiveData.timestamp < 10000) {
                        responsiblePlayerId = explosiveData.playerId;
                        placedExplosives.delete(explosionKey);
                        break;
                    }
                }
                if (responsiblePlayerId) break;
            }
            if (responsiblePlayerId) break;
        }

        if (!responsiblePlayerId) return;

        const playerData = trackedPlayers[responsiblePlayerId] || {
            ores: {},
            timestamp: Date.now(),
            lastBreakTime: 0,
            suspiciousCount: 0,
            warnCount: 0,
            lastBreakPos: null,
            totalBlocksMined: 0,
            reasons: {},
            straightMiningCount: 0,
            nearbyOreStreak: 0,
            nonOreBlocksMinedBeforeOre: 0,
            minedBlockHistory: [],
        };
        trackedPlayers[responsiblePlayerId] = playerData;
        const now = Date.now();

        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.straightMiningCount = 0;
            playerData.nearbyOreStreak = 0;
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.minedBlockHistory = [];
        }

        for (const block of impactedBlocks) {
            const oreType = block.type.id;
            if (!(oreType in ORE_LIMITS)) continue;

            const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
            if (placedBlocks.has(blockKey)) {
                placedBlocks.delete(blockKey);
                savePlacedBlocks();
                continue;
            }

            const isExposed = isNearbyAir(block);
            if (!isExposed) {
                playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
                playerData.totalBlocksMined++;
                globalStats.totalMined++;
                globalStats[oreType] = (globalStats[oreType] || 0) + 1;

                if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
                    playerData.suspiciousCount++;
                    playerData.reasons['爆発で異常に多く鉱石を取得'] = (playerData.reasons['爆発で異常に多く鉱石を取得'] || 0) + 1;
                }

                const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
                const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
                if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
                    playerData.suspiciousCount++;
                    playerData.reasons['爆発による異常な鉱石発見率'] = (playerData.reasons['爆発による異常な鉱石発見率'] || 0) + 1;
                }
            }
        }

        saveGlobalStats();
        saveTrackedPlayers();

        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += `\n  - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(通常: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                system.run(() => {
                    const player = world.getPlayers({ name: responsiblePlayerId })[0];
                    if (player) {
                        world.sendMessage(`[§bSecurityCraft§r] §b${responsiblePlayerId} §rが§cX-ray§4の可能性（爆発利用）。`);
                        world.sendMessage(`§e詳細§r: 発見率${oreStatsMessage}`);
                        let reasonMessage = '';
                        for (const reason in playerData.reasons) {
                            reasonMessage += `\n  - ${reason}: ${playerData.reasons[reason]}回`;
                        }
                        if (reasonMessage) {
                            world.sendMessage(`§6不審な理由§r:${reasonMessage}`);
                        }

                        player.setGameMode('adventure');
                        world.getAllPlayers().forEach(p => {
                            p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                        });
                    }
                });
            }
        }
    });

    // 定期的にサスペンスカウントをリセット
    system.runInterval(() => {
        for (const player in trackedPlayers) {
            trackedPlayers[player].suspiciousCount = Math.floor(trackedPlayers[player].suspiciousCount / 2);
            trackedPlayers[player].straightMiningCount = 0;
            trackedPlayers[player].nearbyOreStreak = 0;
            trackedPlayers[player].nonOreBlocksMinedBeforeOre = 0;
            trackedPlayers[player].minedBlockHistory = [];
        }
        savePlacedBlocks();

        const now = Date.now();
        for (const [key, data] of placedExplosives) {
            if (now - data.timestamp > PLACED_BLOCK_EXPIRY) {
                placedExplosives.delete(key);
            }
        }
    }, SUSPICION_RESET_TIME / 30);
}

// プレイヤーデータをリセットする関数
export function resetPlayerXrayData(playerId) {
    if (trackedPlayers[playerId]) {
        delete trackedPlayers[playerId];
        saveTrackedPlayers();
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データをリセットしました。`);
        console.warn(`[SecurityCraft] Reset X-ray data for player: ${playerId}`);
    } else {
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データが見つかりませんでした。`);
    }
}
