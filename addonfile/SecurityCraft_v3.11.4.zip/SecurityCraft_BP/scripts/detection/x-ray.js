import { world, system } from '@minecraft/server';

// プレイヤーの追跡データを読み込み
function loadTrackedPlayers() {
    const data = world.getDynamicProperty('trackedPlayers');
    return data ? JSON.parse(data) : {};
}
const trackedPlayers = loadTrackedPlayers();

// プレイヤーの追跡データを保存
function saveTrackedPlayers() {
    world.setDynamicProperty('trackedPlayers', JSON.stringify(trackedPlayers));
}

// グローバル統計データを読み込み
function loadGlobalStats() {
    const data = world.getDynamicProperty('globalStats');
    return data
        ? JSON.parse(data)
        : {
              totalMined: 0,
              'minecraft:diamond_ore': 0,
              'minecraft:deepslate_diamond_ore': 0,
              'minecraft:ancient_debris': 0,
              'minecraft:emerald_ore': 0,
              'minecraft:deepslate_emerald_ore': 0,
          };
}
const globalStats = loadGlobalStats();

// グローバル統計データを保存
function saveGlobalStats() {
    world.setDynamicProperty('globalStats', JSON.stringify(globalStats));
}

// 設置されたブロックのデータを読み込み
function loadPlacedBlocks() {
    const data = world.getDynamicProperty('placedBlocks');
    return data ? new Map(JSON.parse(data)) : new Map();
}
let placedBlocks = loadPlacedBlocks();

// 24時間（ミリ秒）
const PLACED_BLOCK_EXPIRY = 24 * 60 * 60 * 1000;

// 設置されたブロックのデータを保存
function savePlacedBlocks() {
    const now = Date.now();
    for (const [key, timestamp] of placedBlocks) {
        // 古いブロックデータを削除
        if (now - timestamp > PLACED_BLOCK_EXPIRY) {
            placedBlocks.delete(key);
        }
    }
    const serialized = JSON.stringify([...placedBlocks]);
    // データサイズが大きくなりすぎた場合、半分にトリミング
    if (serialized.length > 30000) {
        trimPlacedBlocks();
    }
    world.setDynamicProperty('placedBlocks', JSON.stringify([...placedBlocks]));
}

// 設置されたブロックのデータをトリミング
function trimPlacedBlocks() {
    const entries = [...placedBlocks.entries()];
    const halfLength = Math.floor(entries.length / 2);
    placedBlocks = new Map(entries.slice(halfLength));
}

function getSurroundingOpenness(player) {
    let airBlocks = 0;
    const sampleSize = 4; // 周囲4x4x4ブロックをサンプリング
    const totalSamples = Math.pow(sampleSize * 2 + 1, 3);
    const { x, y, z } = player.location;

    for (let dx = -sampleSize; dx <= sampleSize; dx++) {
        for (let dy = -sampleSize; dy <= sampleSize; dy++) {
            for (let dz = -sampleSize; dz <= sampleSize; dz++) {
                try {
                    const block = player.dimension.getBlock({ x: Math.floor(x + dx), y: Math.floor(y + dy), z: Math.floor(z + dz) });
                    if (block && block.isAir) {
                        airBlocks++;
                    }
                } catch (e) {
                    // 読み込めないチャンクは無視
                }
            }
        }
    }
    return airBlocks / totalSamples;
}

function analyzeMiningPath(path) {
    if (path.length < 5) return { isWinding: false, isXrayStraight: false, turns: 0, isTunnel: false };

    let turns = 0;
    let lastDir = null;

    let minX = path[0].x,
        maxX = path[0].x;
    let minY = path[0].y,
        maxY = path[0].y;
    let minZ = path[0].z,
        maxZ = path[0].z;

    // --- 1. 掘った空間の全体形状（バウンディングボックス）を記録 ---
    for (let i = 1; i < path.length; i++) {
        const p = path[i];
        if (p.x < minX) minX = p.x;
        if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.y > maxY) maxY = p.y;
        if (p.z < minZ) minZ = p.z;
        if (p.z > maxZ) maxZ = p.z;
    }

    const sizeX = maxX - minX + 1;
    const sizeY = maxY - minY + 1;
    const sizeZ = maxZ - minZ + 1;

    const isTunnel = (sizeX <= 3 && sizeZ >= 5) || (sizeZ <= 3 && sizeX >= 5);

    // --- 2. 蛇行判定（★直近15ブロックのみを対象にする） ---
    const startIndex = Math.max(1, path.length - 15);
    for (let i = startIndex; i < path.length; i++) {
        const p1 = path[i - 1];
        const p2 = path[i];

        let dx = p2.x - p1.x;
        let dz = p2.z - p1.z;

        if (dx !== 0 || dz !== 0) {
            const dir = `${Math.sign(dx)},${Math.sign(dz)}`;
            if (lastDir !== null && dir !== lastDir) {
                turns++;
            }
            lastDir = dir;
        }
    }

    // --- 定ロジックの改善 ---
    const isXrayStraight = !isTunnel && sizeX >= 5 && sizeY >= 5 && sizeZ >= 5;
    const isWinding = !isTunnel && turns >= 3;

    return { isWinding, isXrayStraight, turns, isTunnel };
}

export function Xray() {
    const ORE_LIMITS = {
        'minecraft:diamond_ore': 10,
        'minecraft:deepslate_diamond_ore': 10,
        'minecraft:ancient_debris': 8,
        'minecraft:emerald_ore': 15,
        'minecraft:deepslate_emerald_ore': 15,
    };

    const X_RAYCheck_LEVEL = world.getDynamicProperty('X_RAYCheck_LEVEL') || 0;

    const LEVEL_CONFIGS = {
        1: { TIME_WINDOW: 300, SUSPICIOUS_THRESHOLD: 30, WARN_LIMIT: 1 },
        2: { TIME_WINDOW: 240, SUSPICIOUS_THRESHOLD: 25, WARN_LIMIT: 1 },
        3: { TIME_WINDOW: 180, SUSPICIOUS_THRESHOLD: 20, WARN_LIMIT: 1 },
        4: { TIME_WINDOW: 120, SUSPICIOUS_THRESHOLD: 16, WARN_LIMIT: 1 },
        5: { TIME_WINDOW: 60, SUSPICIOUS_THRESHOLD: 12, WARN_LIMIT: 1 },
    };

    let TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT;

    if (X_RAYCheck_LEVEL != 0) {
        ({ TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT } = LEVEL_CONFIGS[X_RAYCheck_LEVEL]);
    }

    const placedExplosives = new Map();

    world.afterEvents.playerPlaceBlock.subscribe(event => {
        system.run(() => {
            const block = event.block;
            const blockType = block.type.id;
            const key = `${block.location.x},${block.location.y},${block.location.z}`;
            if (blockType in ORE_LIMITS) {
                placedBlocks.set(key, Date.now());
                savePlacedBlocks();
            }
            if (blockType === 'minecraft:tnt' || blockType === 'minecraft:respawn_anchor' || blockType === 'minecraft:bed') {
                placedExplosives.set(key, {
                    playerId: event.player.name,
                    type: blockType,
                    timestamp: Date.now(),
                });
            }
        });
    });

    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const Y_LIMIT = world.getDynamicProperty('XRAY_Y_LIMIT');
        if (Y_LIMIT !== undefined && event.block.location.y >= Y_LIMIT && event.dimension.id == 'minecraft:overworld') {
            return;
        }

        const X_RAYCheck_LEVEL = world.getDynamicProperty('X_RAYCheck_LEVEL');
        if (X_RAYCheck_LEVEL == 0) return;
        const { TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE } = LEVEL_CONFIGS[X_RAYCheck_LEVEL];

        const player = event.player;
        const block = event.block;
        if (!block) return;

        const playerId = player.name;
        const blockPos = block.location;
        const oreType = block.type.id;
        const now = Date.now();

        const blockKey = `${blockPos.x},${blockPos.y},${blockPos.z}`;
        if (placedBlocks.has(blockKey)) {
            placedBlocks.delete(blockKey);
            savePlacedBlocks();
            return;
        }

        // プレイヤーデータの初期化（不足プロパティがあれば補完）
        if (!trackedPlayers[playerId]) {
            trackedPlayers[playerId] = {
                ores: {},
                timestamp: now,
                suspiciousCount: 0,
                warnCount: 0,
                totalBlocksMined: 0,
                reasons: {},
                nonOreBlocksMinedBeforeOre: 0,
                miningPath: [],
                lastBrokenBlocks: [], // 新規: 直近の破壊履歴
                straightMiningStreak: 0, // 新規: 直線掘りカウンター
                lastWarningTime: 0,
            };
        }
        let playerData = trackedPlayers[playerId];

        // 既存データの互換性維持（古いデータ構造の場合の補完）
        if (!playerData.lastBrokenBlocks) playerData.lastBrokenBlocks = [];
        if (typeof playerData.straightMiningStreak === 'undefined') playerData.straightMiningStreak = 0;

        const isOre = oreType in ORE_LIMITS;

        // 時間ウィンドウリセット
        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.suspiciousCount = Math.floor(playerData.suspiciousCount * 0.8);
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.miningPath = [];
            playerData.straightMiningStreak = 0;
        }

        playerData.totalBlocksMined++;
        globalStats.totalMined++;

        // --- 履歴とパスの更新 ---
        playerData.lastBrokenBlocks.push(blockPos);
        if (playerData.lastBrokenBlocks.length > 5) playerData.lastBrokenBlocks.shift();

        playerData.miningPath.push(blockPos);
        if (playerData.miningPath.length > 30) playerData.miningPath.shift();

        if (isMiningStraight(playerData.miningPath)) {
            playerData.straightMiningStreak++;
        } else {
            playerData.straightMiningStreak = 0;
        }

        if (isOre) {
            let totalSuspicionPoints = 0;
            const suspicionReasons = new Set();

            let isSameVein = false;
            // 前回の鉱石から距離3以内なら「同じ鉱脈」
            if (playerData.lastOrePos && playerData.lastOreType === oreType) {
                const dist = Math.abs(blockPos.x - playerData.lastOrePos.x) + Math.abs(blockPos.y - playerData.lastOrePos.y) + Math.abs(blockPos.z - playerData.lastOrePos.z);
                if (dist <= 3) {
                    isSameVein = true;
                }
            }
            playerData.lastOrePos = blockPos;
            playerData.lastOreType = oreType;

            const openness = getSurroundingOpenness(player);
            const isCave = openness > 0.45;

            // 経路の分析
            const pathAnalysis = analyzeMiningPath(playerData.miningPath);

            // X-ray検知ロジック
            if (!isSameVein) {
                if (!isCave) {
                    if (pathAnalysis.isWinding) {
                        // クネクネと軌道修正して掘り当てた
                        totalSuspicionPoints += 4;
                        suspicionReasons.add(`不自然な経路で地中鉱石へ到達(方向転換${pathAnalysis.turns}回)`);
                    } else if (pathAnalysis.isXrayStraight) {
                        // 目標に向かって3D空間を一直線にぶち抜いた
                        totalSuspicionPoints += 4;
                        suspicionReasons.add(`異常な3D斜め直行で地中鉱石へ到達`);
                    } else {
                        // ブラマイ等の真っ直ぐなトンネルで偶然見つけた
                        totalSuspicionPoints += 1;
                        suspicionReasons.add('地中の埋没鉱石を発見(ブラマイ等)');
                    }
                } else {
                    if (pathAnalysis.isWinding) {
                        totalSuspicionPoints += 1;
                        suspicionReasons.add(`洞窟内での方向転換(${pathAnalysis.turns}回)`);
                    }
                }
            }

            // 疑いの加算
            if (totalSuspicionPoints > 0) {
                playerData.suspiciousCount += totalSuspicionPoints;
                suspicionReasons.forEach(reason => {
                    playerData.reasons[reason] = (playerData.reasons[reason] || 0) + 1;
                });
            }

            // // デバッグ出力（テスト用）===================================
            // player.sendMessage(`§e[DEBUG] ${oreType.replace('minecraft:', '')} を採掘`);
            // player.sendMessage(` - 同じ鉱脈: ${isSameVein} | 空間の空気率: ${(openness * 100).toFixed(1)}% (45%以上で洞窟)`);
            // player.sendMessage(` - 経路判定: 蛇行=${pathAnalysis.isWinding}(${pathAnalysis.turns}回) | 3D斜め直行=${pathAnalysis.isXrayStraight}`);
            // player.sendMessage(` - 今回の追加点: §c${totalSuspicionPoints}§r (現在累計: §c${playerData.suspiciousCount}§r / 警告数: ${playerData.warnCount})`);
            // if (suspicionReasons.size > 0) {
            //     player.sendMessage(` - 理由: ${Array.from(suspicionReasons).join(', ')}`);
            // }
            // // デバッグ出力（テスト用）===================================

            // 統計更新
            playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
            globalStats[oreType] = (globalStats[oreType] || 0) + 1;
            saveGlobalStats();
        } else {
            playerData.nonOreBlocksMinedBeforeOre++;
        }

        // 警告レベルチェック
        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    if (playerOreCount > 0) {
                        const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                        const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                        oreStatsMessage += `\n  - §a${ore.split(':')[1]}§r: §b${playerOreRate.toFixed(2)}% §r(平均: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                world.sendMessage(`[§bSecurityCraft§r] §a${playerId} §rが§cX-ray§4の可能性`);
                if (oreStatsMessage) world.sendMessage(`§e-- プレイヤーの鉱石発見率 --§r${oreStatsMessage}`);

                let reasonMessage = '';
                for (const reason in playerData.reasons) {
                    reasonMessage += `\n  - ${reason}: ${playerData.reasons[reason]}回`;
                }
                if (reasonMessage) {
                    world.getAllPlayers().forEach(p => {
                        if (p.hasTag('SecurityOP')) {
                            p.sendMessage(`§6--- 検知理由 ---§r${reasonMessage}`);
                        }
                    });
                }

                system.run(() => {
                    player.setGameMode('Adventure');
                    world.getAllPlayers().forEach(p => {
                        p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                    });
                });

                // 警告後リセット
                playerData.warnCount = 0;
                playerData.reasons = {};
            }
        }

        saveTrackedPlayers();
    });

    world.beforeEvents.explosion.subscribe(event => {
        const X_RAYCheck_LEVEL = world.getDynamicProperty('X_RAYCheck_LEVEL');
        if (X_RAYCheck_LEVEL == 0) return;
        const { TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT } = LEVEL_CONFIGS[X_RAYCheck_LEVEL];
        const impactedBlocks = event.getImpactedBlocks();
        if (!impactedBlocks.length) return;

        let responsiblePlayerId = null;
        let totalX = 0,
            totalY = 0,
            totalZ = 0;
        for (const block of impactedBlocks) {
            totalX += block.location.x;
            totalY += block.location.y;
            totalZ += block.location.z;
        }
        const centerX = Math.floor(totalX / impactedBlocks.length);
        const centerY = Math.floor(totalY / impactedBlocks.length);
        const centerZ = Math.floor(totalZ / impactedBlocks.length);

        const BLAST_RADIUS = 7;
        for (let dx = -BLAST_RADIUS; dx <= BLAST_RADIUS; dx++) {
            for (let dy = -BLAST_RADIUS; dy <= BLAST_RADIUS; dy++) {
                for (let dz = -BLAST_RADIUS; dz <= BLAST_RADIUS; dz++) {
                    const checkX = centerX + dx;
                    const checkY = centerY + dy;
                    const checkZ = centerZ + dz;
                    const explosionKey = `${checkX},${checkY},${checkZ}`;
                    const explosiveData = placedExplosives.get(explosionKey);

                    if (explosiveData && Date.now() - explosiveData.timestamp < 10000) {
                        responsiblePlayerId = explosiveData.playerId;
                        placedExplosives.delete(explosionKey);
                        break;
                    }
                }
                if (responsiblePlayerId) break;
            }
            if (responsiblePlayerId) break;
        }

        if (!responsiblePlayerId) return;

        const playerData = trackedPlayers[responsiblePlayerId] || {
            ores: {},
            timestamp: Date.now(),
            lastBreakTime: 0,
            suspiciousCount: 0,
            warnCount: 0,
            lastBreakPos: null,
            totalBlocksMined: 0,
            reasons: {},
            straightMiningCount: 0,
            nearbyOreStreak: 0,
            nonOreBlocksMinedBeforeOre: 0,
            minedBlockHistory: [],
            miningPath: [],
        };
        trackedPlayers[responsiblePlayerId] = playerData;
        const now = Date.now();

        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.straightMiningCount = 0;
            playerData.nearbyOreStreak = 0;
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.minedBlockHistory = [];
        }

        for (const block of impactedBlocks) {
            const oreType = block.type.id;
            if (!(oreType in ORE_LIMITS)) continue;

            const Y_LIMIT = world.getDynamicProperty('XRAY_Y_LIMIT');
            if (Y_LIMIT !== undefined && block.location.y >= Y_LIMIT && event.dimension.id == 'minecraft:overworld') {
                continue; // 設定されたY座標以上なのでこのブロックは検知しない
            }

            const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
            if (placedBlocks.has(blockKey)) {
                placedBlocks.delete(blockKey);
                savePlacedBlocks();
                continue;
            }

            playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
            playerData.totalBlocksMined++;
            globalStats.totalMined++;
            globalStats[oreType] = (globalStats[oreType] || 0) + 1;

            if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
                playerData.suspiciousCount++;
                playerData.reasons['爆発で異常に多く鉱石を取得'] = (playerData.reasons['爆発で異常に多く鉱石を取得'] || 0) + 1;
            }

            const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
            const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
            if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
                playerData.suspiciousCount++;
                playerData.reasons['爆発による異常な鉱石発見率'] = (playerData.reasons['爆発による異常な鉱石発見率'] || 0) + 1;
            }
        }

        saveGlobalStats();
        saveTrackedPlayers();

        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += ` - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(平均: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                system.run(() => {
                    const player = world.getPlayers({ name: responsiblePlayerId })[0];
                    if (player) {
                        world.sendMessage(`[§bSecurityCraft§r] §b${responsiblePlayerId} §rが§cX-ray§4の可能性（爆発利用）`);
                        world.sendMessage('§e--プレイヤーの鉱石発見率--');
                        world.sendMessage(`${oreStatsMessage}`);
                        let reasonMessage = '';
                        for (const reason in playerData.reasons) {
                            reasonMessage += ` - ${reason}: ${playerData.reasons[reason]}回\n`;
                        }
                        if (reasonMessage) {
                            world.sendMessage('§6---検知の理由---');
                            world.sendMessage(`${reasonMessage}`);
                        }

                        player.setGameMode('Adventure');
                        world.getAllPlayers().forEach(p => {
                            p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                        });
                    }
                });
            }
        }
    });

    system.runInterval(() => {
        for (const player in trackedPlayers) {
            // 時間経過で疑いを少しずつ減らす
            if (trackedPlayers[player].suspiciousCount > 0) {
                trackedPlayers[player].suspiciousCount = Math.floor(trackedPlayers[player].suspiciousCount * 0.85);
            }
        }
        savePlacedBlocks();

        const now = Date.now();
        for (const [key, data] of placedExplosives) {
            if (now - data.timestamp > PLACED_BLOCK_EXPIRY) {
                placedExplosives.delete(key);
            }
        }
    }, 1200); // 30秒ごとに実行
}

// プレイヤーデータをリセットする関数 (変更なし)
export function resetPlayerXrayData(playerId) {
    if (trackedPlayers[playerId]) {
        delete trackedPlayers[playerId];
        saveTrackedPlayers();
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§a のX-ray検知データをリセットしました`);
    } else {
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§a のX-ray検知データが見つかりませんでした`);
    }
}

// 直線掘り判定 (簡易版)
function isMiningStraight(path) {
    if (path.length < 3) return false;
    const last = path[path.length - 1];
    const prev = path[path.length - 2];
    const prev2 = path[path.length - 3];

    // ベクトル計算
    const v1 = { x: last.x - prev.x, y: last.y - prev.y, z: last.z - prev.z };
    const v2 = { x: prev.x - prev2.x, y: prev.y - prev2.y, z: prev.z - prev2.z };

    // 同じ方向へ掘り進めているか
    return v1.x === v2.x && v1.y === v2.y && v1.z === v2.z;
}
