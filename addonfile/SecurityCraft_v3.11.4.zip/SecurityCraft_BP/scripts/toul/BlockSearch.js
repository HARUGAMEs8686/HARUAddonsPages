import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UI } from '../ui.js';

const LOGS_PER_PAGE = 40; // 1ページあたりの表示件数

export function BlockSearchMenu(player, previousInputs = null) {
    const { x, y, z } = player.location;

    const def = previousInputs || {
        logTypeIdx: 0,
        blockIdRaw: '',
        playerNameRaw: '',
        useRadius: false,
        radiusStr: '50',
        useAdditionalSearch: false,
    };

    new ModalFormData()
        .title('§0ブロックデータ検索')
        .dropdown('§e検索対象の履歴', ['設置履歴', '破壊履歴'], {
            defaultValueIndex: def.logTypeIdx,
        })
        .textField('§aブロックID ※空欄で全て', '例: chest (部分一致)', {
            defaultValue: def.blockIdRaw,
        })
        .textField('§bプレイヤー名 ※空欄で全て', '例: Steve (部分一致)', {
            defaultValue: def.playerNameRaw,
        })
        .toggle('範囲検索を有効にする', {
            defaultValue: def.useRadius,
        })
        .textField('§d検索半径', '半角数字', {
            defaultValue: def.radiusStr,
        })
        .toggle('復元データのみに存在する履歴も追加検索する\n§8※オンにすると通常記録にないデータも表示します', {
            defaultValue: def.useAdditionalSearch,
        })
        .submitButton('§0検索')
        .show(player)
        .then(res => {
            if (res.canceled) {
                UI(player);
                return;
            }
            const [logTypeIdx, blockIdRaw, playerNameRaw, useRadius, radiusStr, useAdditionalSearch] = res.formValues;

            const inputs = { logTypeIdx, blockIdRaw, playerNameRaw, useRadius, radiusStr, useAdditionalSearch };

            const mode = logTypeIdx === 0 ? 'place' : 'break';
            const blockId = blockIdRaw.trim().replace('minecraft:', '').toLowerCase();
            const playerName = playerNameRaw.trim().toLowerCase();
            const radius = useRadius ? parseInt(radiusStr, 10) : 0;

            if (useRadius && (isNaN(radius) || radius <= 0)) {
                player.sendMessage('§r[§bSecurityCraft§r] §c無効な半径です。');
                BlockSearchMenu(player, inputs);
                return;
            }

            runSearch(player, mode, blockId, playerName, useRadius, radius, x, y, z, useAdditionalSearch, inputs);
        });
}

function runSearch(player, mode, blockId, playerName, useRadius, radius, x, y, z, useAdditionalSearch, inputs) {
    player.sendMessage('§r[§bSecurityCraft§r] §e検索中... 処理に時間がかかる場合があります');

    system.runTimeout(() => {
        const results = executeSearch(mode, blockId, playerName, useRadius, radius, x, y, z, useAdditionalSearch);
        showSearchResults(player, results, 1, { mode, blockId, playerName, useRadius, radius, x, y, z, inputs });
    }, 1);
}

function executeSearch(mode, targetBlockId, targetPlayerName, useRadius, radius, centerX, centerY, centerZ, useAdditionalSearch) {
    const rawNormalLogs = [];
    const rawRestoreLogs = [];
    const radiusSq = radius * radius;
    const allKeys = world.getDynamicPropertyIds();

    // 1. 各システムからログを抽出する
    for (const key of allKeys) {
        if (mode === 'break' && key.startsWith('break_') && key.includes('_part')) {
            processNormalLog(key, rawNormalLogs, 'break', useRadius, radiusSq, centerX, centerY, centerZ);
        } else if (mode === 'place' && key.startsWith('place_') && key.includes('_part')) {
            processNormalLog(key, rawNormalLogs, 'place', useRadius, radiusSq, centerX, centerY, centerZ);
        }

        // 復元データは「ID補完」のために常時読み込む
        if (key.startsWith('restore_') && key.includes('_part_')) {
            processRestoreLog(key, rawRestoreLogs, mode, useRadius, radiusSq, centerX, centerY, centerZ);
        }
    }

    const mergedResults = [];

    // 2. 通常ログをベースにしつつ、復元データと合致するなら情報を自動補完する
    for (const nLog of rawNormalLogs) {
        // 同じ座標・1秒以内の時間誤差であれば同一データとみなす
        const rIndex = rawRestoreLogs.findIndex(rLog => rLog.x === nLog.x && rLog.y === nLog.y && rLog.z === nLog.z && Math.abs(rLog.timestamp - nLog.timestamp) <= 1000);

        if (rIndex !== -1) {
            const rLog = rawRestoreLogs[rIndex];
            // IDやプレイヤー名が不明なら補完する
            if (nLog.blockId === '不明' && rLog.blockId !== '不明') nLog.blockId = rLog.blockId;
            if (nLog.player.includes('不明') && !rLog.player.includes('不明')) nLog.player = rLog.player;

            // 補完に使った復元データはリストから削除（追加検索で二重に表示されないようにするため）
            rawRestoreLogs.splice(rIndex, 1);
        }

        mergedResults.push(nLog);
    }

    // 3. 追加検索がONの場合、補完に使われずに残った復元データ（爆発・燃焼など）を追加する
    if (useAdditionalSearch) {
        for (const rLog of rawRestoreLogs) {
            mergedResults.push(rLog);
        }
    }

    // 4. 検索条件（ID・プレイヤー名の部分一致）で最終的な絞り込み
    const finalResults = [];
    for (const log of mergedResults) {
        if (targetPlayerName && !log.player.toLowerCase().includes(targetPlayerName)) continue;
        if (targetBlockId && !log.blockId.includes(targetBlockId)) continue;

        finalResults.push(log);
    }

    // 日付の新しい順（降順）にソート
    finalResults.sort((a, b) => b.timestamp - a.timestamp);
    return finalResults;
}

// 通常の設置・破壊記録からの抽出
function processNormalLog(key, resultsArray, type, useRadius, radiusSq, centerX, centerY, centerZ) {
    try {
        const dataStr = world.getDynamicProperty(key);
        if (!dataStr) return;
        const dataObj = JSON.parse(dataStr);

        for (const [posKey, record] of Object.entries(dataObj)) {
            const recordPlayer = record[0];
            const timestamp = record[1];
            // 破壊のみIDがある。設置は不明とする
            const recordBlockId = type === 'break' && record[2] ? record[2].replace('minecraft:', '').toLowerCase() : '不明';

            const [bx, by, bz] = posKey.split(',').map(Number);
            if (useRadius) {
                const distSq = (centerX - bx) ** 2 + (centerY - by) ** 2 + (centerZ - bz) ** 2;
                if (distSq > radiusSq) continue;
            }
            resultsArray.push({ x: bx, y: by, z: bz, player: recordPlayer, timestamp: timestamp, blockId: recordBlockId });
        }
    } catch (e) {}
}

// 復元システムからの抽出
function processRestoreLog(key, resultsArray, mode, useRadius, radiusSq, centerX, centerY, centerZ) {
    try {
        const dataStr = world.getDynamicProperty(key);
        if (!dataStr) return;
        const entries = JSON.parse(dataStr); // [[posKey, logEntry], ...]

        for (const [posKey, log] of entries) {
            const isPlace = log.t === 'p';
            if (mode === 'place' && !isPlace) continue; // 検索モードが設置なら、設置以外はスルー
            if (mode === 'break' && isPlace) continue; // 検索モードが破壊なら、設置はスルー

            const recordBlockId = log.p.typeId.replace('minecraft:', '').toLowerCase();
            const recordPlayer = log.c ? log.c.replace('Player: ', '') : '不明(非プレイヤー)';
            const timestamp = log.ts;

            // 復元データのposKeyは "x,y,z,timestamp" なのでパースする
            const coords = posKey.split(',');
            const bx = Number(coords[0]);
            const by = Number(coords[1]);
            const bz = Number(coords[2]);

            if (useRadius) {
                const distSq = (centerX - bx) ** 2 + (centerY - by) ** 2 + (centerZ - bz) ** 2;
                if (distSq > radiusSq) continue;
            }
            resultsArray.push({ x: bx, y: by, z: bz, player: recordPlayer, timestamp: timestamp, blockId: recordBlockId });
        }
    } catch (e) {}
}

// === UI表示部分 ===

function showSearchResults(player, results, page, searchContext) {
    if (results.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a条件に一致する履歴は見つかりませんでした。');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        BlockSearchMenu(player, searchContext.inputs); // 検索結果0件でも入力を保持して戻す
        return;
    }

    const totalPages = Math.ceil(results.length / LOGS_PER_PAGE);
    const startIndex = (page - 1) * LOGS_PER_PAGE;
    const logsToShow = results.slice(startIndex, startIndex + LOGS_PER_PAGE);

    const typeStr = searchContext.mode === 'break' ? '破壊' : '設置';
    const form = new ActionFormData().title(`§0ブロックデータ検索結果`).body(`§e${typeStr}履歴 §r| §b${page} §r/ §b${totalPages} §rページ | §d総件数§r: §b${results.length}§r件`);

    const buttonActions = [];

    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttonActions.push(() => BlockSearchMenu(player, searchContext.inputs));

    if (page > 1) {
        form.button('§1前のページへ', 'textures/ui/arrow_left.png');
        buttonActions.push(() => showSearchResults(player, results, page - 1, searchContext));
    }

    if (page < totalPages) {
        form.button('§1次のページへ', 'textures/ui/arrow_right.png');
        buttonActions.push(() => showSearchResults(player, results, page + 1, searchContext));
    }

    logsToShow.forEach(log => {
        const time = toJST(log.timestamp);
        const label = `§0${time}\n§1${log.player} §r: §5${log.blockId} §8(${log.x}, ${log.y}, ${log.z})`;
        form.button(label);
        buttonActions.push(() => showLogDetails(player, log, () => showSearchResults(player, results, page, searchContext)));
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        buttonActions[res.selection]();
    });
}

function showLogDetails(player, log, backCallback) {
    const time = toJST(log.timestamp);

    new ActionFormData()
        .title('§0履歴詳細')
        .body(`§aプレイヤー§r: §b${log.player}\n§aブロック§r: §b${log.blockId}\n§a座標§r: §b${log.x}, ${log.y}, ${log.z}\n§a記録時刻§r: §e${time}`)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button(`§0この座標にテレポート`, 'textures/items/ender_pearl.png')
        .show(player)
        .then(res => {
            if (res.canceled) return;
            if (res.selection === 0) {
                backCallback();
            } else if (res.selection === 1) {
                try {
                    player.teleport({ x: log.x, y: log.y, z: log.z }, { dimension: player.dimension });
                    player.sendMessage(`§r[§bSecurityCraft§r] §a(${log.x}, ${log.y}, ${log.z}) へテレポートしました。`);
                } catch (e) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §cテレポートに失敗しました。`);
                    backCallback();
                }
            }
        });
}

function toJST(timestamp) {
    const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
    const date = new Date(timestamp + timeSetting * 60 * 60 * 1000);
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');
    return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
}
