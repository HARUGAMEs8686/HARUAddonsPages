import { world, system } from '@minecraft/server';
import { playerCheckModeStatus } from '../main';

let chunkDataCache = new Map();
system.runInterval(() => {
    chunkDataCache.clear();
}, 1200);

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
const MAX_PROPERTY_SIZE = 30000;

let DAYS_TO_KEEP = 4;
let SEARCH_RADIUS = 7;
let pendingUpdates = new Map();

const SCRIPT_DATA_VERSION = 2;

//ワールドに保存された設定値を読み込みます
export function breload() {
    try {
        const storedDays = world.getDynamicProperty('breakblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }

        // 範囲設定の読み込みを追加
        const storedRadius = world.getDynamicProperty('breakblock_search_radius');
        if (typeof storedRadius === 'number' && !isNaN(storedRadius) && storedRadius > 0) {
            SEARCH_RADIUS = storedRadius;
        }
    } catch (e) {
        console.warn(`[BreakBlock] Error loading settings: ${e.message}`);
    }
}

world.afterEvents.worldLoad.subscribe(() => {
    checkDataVersionAndInitialize();
    breload(); // 次に設定をリロード
});

// スクリプトの初回読み込み時にも実行
checkDataVersionAndInitialize();
breload();

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `break_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    const entries = Object.entries(chunkData);

    if (entries.length === 0) {
        let part = 1;
        while (world.getDynamicProperty(`${chunkKey}_part${part}`)) {
            world.setDynamicProperty(`${chunkKey}_part${part}`, undefined);
            part++;
        }
        pendingUpdates.delete(chunkKey);
        return;
    }

    const newParts = [];
    let currentPartObject = {};
    let currentPartLength = 2;

    for (const [positionKey, data] of entries) {
        const entryString = JSON.stringify(positionKey) + ':' + JSON.stringify(data);
        const entryLength = entryString.length + (Object.keys(currentPartObject).length > 0 ? 1 : 0);

        if (currentPartLength + entryLength > MAX_PROPERTY_SIZE) {
            if (Object.keys(currentPartObject).length > 0) {
                newParts.push(JSON.stringify(currentPartObject));
            }
            currentPartObject = { [positionKey]: data };
            currentPartLength = 2 + entryString.length;
        } else {
            currentPartObject[positionKey] = data;
            currentPartLength += entryLength;
        }
    }

    if (Object.keys(currentPartObject).length > 0) {
        newParts.push(JSON.stringify(currentPartObject));
    }

    try {
        for (let i = 0; i < newParts.length; i++) {
            world.setDynamicProperty(`${chunkKey}_part${i + 1}`, newParts[i]);
        }
        let oldPart = newParts.length + 1;
        while (world.getDynamicProperty(`${chunkKey}_part${oldPart}`)) {
            world.setDynamicProperty(`${chunkKey}_part${oldPart}`, undefined);
            oldPart++;
        }
    } catch (e) {
        console.warn(`[Block System] Error saving chunk data for ${chunkKey}: ${e}`);
    } finally {
        chunkDataCache.set(chunkKey, chunkData); // キャッシュを最新に更新
        pendingUpdates.delete(chunkKey);
    }
}

function getChunkData(chunkKey) {
    if (chunkDataCache.has(chunkKey)) {
        return chunkDataCache.get(chunkKey);
    }
    const combinedData = {};
    let part = 1;
    while (true) {
        const storedData = world.getDynamicProperty(`${chunkKey}_part${part}`);
        if (!storedData) break;
        try {
            Object.assign(combinedData, JSON.parse(storedData));
        } catch (e) {
            console.warn(`[Block System] Failed to parse data for ${chunkKey}_part${part}: ${e}`);
        }
        part++;
    }
    chunkDataCache.set(chunkKey, combinedData);
    return combinedData;
}

function getChunkDataForBlock(x, z) {
    const mergedData = new Map();
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);

        const data = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);

        for (const [pos, value] of Object.entries(data)) {
            if (!mergedData.has(pos) || value[1] > (mergedData.get(pos)?.[1] || 0)) {
                mergedData.set(pos, value);
            }
        }
    }
    return mergedData;
}

// 保留中の更新を一定間隔で保存
system.runInterval(() => {
    const updatesToProcess = new Map(pendingUpdates);
    for (const [chunkKey, chunkData] of updatesToProcess) {
        saveChunkData(chunkKey, chunkData);
    }
}, 400); // 20秒ごと

// 古いデータを一定間隔で削除
system.runInterval(() => {
    try {
        const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
        const expirationDay = currentDay - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();

        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                const match = key.match(/break_-?\d+_-?\d+_(\d+)_part\d+/);
                if (match && parseInt(match[1], 10) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[BreakBlock] Error cleaning old data: ${e.message}`);
    }
}, 1200); // 60秒ごと

export function clearAllBreakData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('break_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
        pendingUpdates.clear();
        chunkDataCache.clear();
        console.log('[BreakBlock] すべての破壊情報をクリアしました。');
    } catch (e) {
        console.warn(`[BreakBlock] Error clearing break data: ${e.message}`);
    }
}

// --- メイン処理 ---
export function BreakBlock() {
    const lastBreakTime = new Map();
    const lastCheckTime = new Map();

    world.afterEvents.playerBreakBlock.subscribe(event => {
        if (!world.getDynamicProperty('BreakBlock_system')) return;

        const { player, block, brokenBlockPermutation } = event;
        const { x, y, z } = block.location;
        const now = Date.now();

        if (now - (lastBreakTime.get(player.name) || 0) < 100) return;
        lastBreakTime.set(player.name, now);

        const chunkKey = getChunkKey(x, z, now);
        const positionKey = getPositionKey(x, y, z);

        const chunkData = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);

        chunkData[positionKey] = [player.name, now, brokenBlockPermutation.type.id.replace('minecraft:', '')];

        pendingUpdates.set(chunkKey, chunkData);
    });

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const { player, block } = event;
            if (!playerCheckModeStatus || !playerCheckModeStatus[player.name] || !block) return;

            const now = Date.now();
            if (now - (lastCheckTime.get(player.name) || 0) < 1000) return;
            lastCheckTime.set(player.name, now);

            const nearbyBreaks = getNearbyBreakHistory(block.location);

            if (nearbyBreaks.length > 0) {
                displayBreakSummary(player, nearbyBreaks);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurityCraft§r] §eこの周辺に最近の破壊履歴はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }
        });
    });
}

function getNearbyBreakHistory(centerPos) {
    const history = [];
    const radius = SEARCH_RADIUS;
    const radiusSq = radius * radius;
    const { x, y, z } = centerPos;

    const minChunkX = Math.floor((x - radius) / CHUNK_SIZE);
    const maxChunkX = Math.floor((x + radius) / CHUNK_SIZE);
    const minChunkZ = Math.floor((z - radius) / CHUNK_SIZE);
    const maxChunkZ = Math.floor((z + radius) / CHUNK_SIZE);

    const checkedChunks = new Set();

    for (let cx = minChunkX; cx <= maxChunkX; cx++) {
        for (let cz = minChunkZ; cz <= maxChunkZ; cz++) {
            const chunkId = `${cx},${cz}`;
            if (checkedChunks.has(chunkId)) continue;
            checkedChunks.add(chunkId);

            const chunkData = getChunkDataForBlock(cx * CHUNK_SIZE, cz * CHUNK_SIZE);

            for (const [posKey, record] of chunkData.entries()) {
                const [recX, recY, recZ] = posKey.split(',').map(Number);
                const distSq = (x - recX) ** 2 + (y - recY) ** 2 + (z - recZ) ** 2;

                if (distSq <= radiusSq) {
                    history.push({
                        position: `(${recX},${recY},${recZ})`,
                        breaker: record[0],
                        timestamp: record[1],
                        blockType: record[2],
                    });
                }
            }
        }
    }
    return history;
}

function toJST(timestamp) {
    const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
    const date = new Date(timestamp + timeSetting * 60 * 60 * 1000);
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');
    return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
}

function displayBreakSummary(player, breaks) {
    if (breaks.length === 0) return;

    player.sendMessage(`§7[§b破壊概要§r] (範囲: ${SEARCH_RADIUS})`);

    const breakCount = new Map();
    const latestBreaks = new Map();
    const brokenTypes = new Map(); // プレイヤーごとの破壊ブロック種類リスト

    for (const record of breaks) {
        breakCount.set(record.breaker, (breakCount.get(record.breaker) || 0) + 1);
        if (!latestBreaks.has(record.breaker) || record.timestamp > latestBreaks.get(record.breaker).timestamp) {
            latestBreaks.set(record.breaker, {
                timestamp: record.timestamp,
                position: record.position,
            });
        }

        // ブロック種類の収集
        if (!brokenTypes.has(record.breaker)) brokenTypes.set(record.breaker, new Set());
        brokenTypes.get(record.breaker).add(record.blockType);
    }

    const sortedBreakers = Array.from(breakCount.entries()).sort((a, b) => b[1] - a[1]);

    sortedBreakers.forEach(([breaker, count], index) => {
        const latest = latestBreaks.get(breaker);
        const types = Array.from(brokenTypes.get(breaker)).join(', ');

        player.sendMessage(`§a#${index + 1} §c${breaker} §e${toJST(latest.timestamp)} §6${latest.position} §b${count}個 §7[${types}]`);
    });

    player.sendMessage(`§7合計: §f${breaks.length}件 (§f${breakCount.size}人)`);
}

function checkDataVersionAndInitialize() {
    try {
        const storedVersion = world.getDynamicProperty('breakblock_data_version');

        if (storedVersion !== SCRIPT_DATA_VERSION) {
            console.warn(`[BreakBlock] 旧バージョン(${storedVersion})のデータを検出しました。新バージョン(${SCRIPT_DATA_VERSION})への更新のため、全破壊記録を初期化します。`);

            clearAllBreakData();

            world.setDynamicProperty('breakblock_data_version', SCRIPT_DATA_VERSION);
            console.log(`[BreakBlock] データバージョンを ${SCRIPT_DATA_VERSION} に更新しました。`);
        }
    } catch (e) {
        console.error(`[BreakBlock] データバージョンの確認・更新中にエラーが発生しました: ${e}`);
    }
}
