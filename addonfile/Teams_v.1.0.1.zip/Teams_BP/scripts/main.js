import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

// ==========================================
// 定数・初期設定
// ==========================================

// UIで使用する色のリスト
const AVAILABLE_COLORS = [
    { name: '赤 (Red)', code: '§c' },
    { name: '青 (Blue)', code: '§9' },
    { name: '緑 (Green)', code: '§a' },
    { name: '黄 (Yellow)', code: '§e' },
    { name: '金 (Gold)', code: '§6' },
    { name: '水色 (Aqua)', code: '§b' },
    { name: 'ピンク (Light Purple)', code: '§d' },
    { name: '白 (White)', code: '§f' },
    { name: 'グレー (Gray)', code: '§7' },
    { name: '黒 (Black)', code: '§0' },
];

// データを保存するDynamicPropertyのキー
const KEY_TEAMS = 'my_addon:teams';
const KEY_SETTINGS = 'my_addon:settings';

// ==========================================
// データ管理用関数
// ==========================================

// 設定の取得 (デフォルト: FF有効=true, チャット・ネームタグ変更有効=true)
function getSettings() {
    const data = world.getDynamicProperty(KEY_SETTINGS);
    // デフォルト値に chatColorEnabled と nameTagColorEnabled を追加
    const defaults = { friendlyFire: true, chatColorEnabled: true, nameTagColorEnabled: true };
    if (!data) return defaults;
    try {
        // 既存の設定とデフォルト値をマージして、新しい設定項目がなくてもエラーにならないようにする
        return { ...defaults, ...JSON.parse(data) };
    } catch (e) {
        return defaults;
    }
}

// チームデータの取得
function getTeams() {
    const data = world.getDynamicProperty(KEY_TEAMS);
    if (!data) return [];
    try {
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

// チームデータの保存
function saveTeams(teams) {
    world.setDynamicProperty(KEY_TEAMS, JSON.stringify(teams));
}

// 設定の保存
function saveSettings(settings) {
    world.setDynamicProperty(KEY_SETTINGS, JSON.stringify(settings));
}

// プレイヤーの所属チームを取得
function getPlayerTeam(player, teams = getTeams()) {
    const playerTags = player.getTags();
    return teams.find(team => playerTags.includes(team.tag));
}

// プレイヤーから全チームタグを削除（チーム移動用）
function clearPlayerTeamTags(player) {
    const teams = getTeams();
    teams.forEach(t => {
        if (player.hasTag(t.tag)) {
            player.removeTag(t.tag);
        }
    });
}

// ==========================================
// UI (User Interface) システム
// ==========================================

/**
 * メインメニューを表示
 */
function showMainMenu(player) {
    const form = new ActionFormData().title('§0チーム管理').body('>>> §e選択してください').button('§0チーム一覧・作成・削除', 'textures/ui/bubble_empty').button('§0プレイヤー管理', 'textures/ui/bubble_empty').button('§0システム設定', 'textures/ui/icon_setting');

    form.show(player).then(response => {
        if (response.canceled) return;

        switch (response.selection) {
            case 0:
                showTeamListUI(player);
                break;
            case 1:
                showPlayerManagerUI(player);
                break;
            case 2:
                showSettingsUI(player);
                break;
        }
    });
}

/**
 * チーム一覧 & 作成画面
 */
function showTeamListUI(player) {
    const teams = getTeams();
    const form = new ActionFormData().title('§0チーム一覧').body(`>>> §e現在のチーム数: §b${teams.length}`).button(`§l戻る`, 'textures/ui/icon_import.png').button('§1新しいチームを作成', 'textures/ui/bubble_empty');

    teams.forEach(team => {
        form.button(`${team.color}${team.name}§r\n§0(Tag: ${team.tag})`, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            showMainMenu(player);
            return;
        }
        if (response.selection === 1) {
            showCreateTeamUI(player);
        } else {
            // 既存チームを選択した場合、削除確認へ
            const selectedTeam = teams[response.selection - 2];
            showDeleteTeamUI(player, selectedTeam);
        }
    });
}

/**
 * チーム作成画面
 */
function showCreateTeamUI(player) {
    const form = new ModalFormData()
        .title('§1チーム作成')
        .textField('チーム名 (表示用)', '例: Red Team')
        .textField('タグ名 (識別用)', '例: team:red', {
            defaultValue: 'team:',
        }) // 初期値team:
        .dropdown(
            'チームカラー',
            AVAILABLE_COLORS.map(c => c.name),
            {
                defaultValueIndex: 0,
            },
        )
        .submitButton('§1作成');

    form.show(player).then(response => {
        if (response.canceled) {
            showTeamListUI(player);
            return;
        }
        const [name, tagInput, colorIndex] = response.formValues;

        // バリデーション
        if (!name || !tagInput) {
            player.sendMessage('[§bTeams§r] §c名前とタグは必須です。');
            return;
        }

        const teams = getTeams();
        // 重複チェック
        if (teams.some(t => t.tag === tagInput)) {
            player.sendMessage(`[§bTeams§r] §cタグ '${tagInput}' は既に存在します`);
            return;
        }

        const newTeam = {
            id: Date.now().toString(), // ユニークID
            name: name,
            tag: tagInput,
            color: AVAILABLE_COLORS[colorIndex].code,
        };

        teams.push(newTeam);
        saveTeams(teams);
        player.sendMessage(`[§bTeams§r] §aチーム '${name}' を作成しました`);
        // 再度リストを表示
        showTeamListUI(player);
    });
}

/**
 * チーム削除確認画面
 */
function showDeleteTeamUI(player, team) {
    const form = new MessageFormData().title('§4チーム削除').body(`チーム '${team.color}${team.name}§r' を削除します`).button1('§4確認(削除)').button2('§0キャンセル');

    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            let teams = getTeams();
            teams = teams.filter(t => t.id !== team.id);
            saveTeams(teams);

            player.sendMessage(`[§bTeams§r] §eチーム '${team.name}' を削除しました`);
        } else {
            showTeamListUI(player);
        }
    });
}

/**
 * プレイヤー管理画面
 */
function showPlayerManagerUI(player) {
    const players = [...world.getPlayers()];
    const teams = getTeams();

    const form = new ActionFormData().title('§0プレイヤー管理').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');

    players.forEach(p => {
        const currentTeam = getPlayerTeam(p, teams);
        const teamName = currentTeam ? `${currentTeam.color}${currentTeam.name}` : '§0無所属';
        form.button(`§1${p.name}\n§0(${teamName}§0)`, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainMenu(player);
            return;
        }

        const targetPlayer = players[response.selection - 1];
        showPlayerTeamAssignUI(player, targetPlayer);
    });
}

/**
 * プレイヤーへのチーム割り当て画面
 */
function showPlayerTeamAssignUI(admin, targetPlayer) {
    const teams = getTeams();
    const teamNames = ['無所属 (脱退)', ...teams.map(t => `${t.color}${t.name}`)];

    // 現在のチームを探してデフォルト選択位置を決める
    const currentTeam = getPlayerTeam(targetPlayer, teams);
    let defaultIndex = 0;
    if (currentTeam) {
        defaultIndex = teams.findIndex(t => t.id === currentTeam.id) + 1;
    }

    const form = new ModalFormData()
        .title(`§0設定: ${targetPlayer.name}`)
        .dropdown('所属チームを選択', teamNames, {
            defaultValueIndex: defaultIndex,
        })
        .submitButton('§0適用');

    form.show(admin).then(response => {
        if (response.canceled) {
            showPlayerManagerUI(admin);
            return;
        }

        const selectionIndex = response.formValues[0];
        clearPlayerTeamTags(targetPlayer); // まず全てのチームタグを消す

        if (selectionIndex === 0) {
            admin.sendMessage(`[§bTeams§r] §e${targetPlayer.name} をチームから外しました`);
        } else {
            const selectedTeam = teams[selectionIndex - 1];
            targetPlayer.addTag(selectedTeam.tag);
            admin.sendMessage(`[§bTeams§r] §a${targetPlayer.name} を ${selectedTeam.color}${selectedTeam.name} §aに参加させました`);
        }
    });
}

/**
 * 設定画面 (FF設定など)
 */
function showSettingsUI(player) {
    const settings = getSettings();

    const form = new ModalFormData()
        .title('§0システム設定')
        .label('>>> §e選択してください')
        .divider()
        .toggle('§cフレンドリーファイア (味方への攻撃)', {
            defaultValue: settings.friendlyFire,
        })
        .divider()
        .toggle('§bチャットの色を変更', { defaultValue: settings.chatColorEnabled })
        .divider()
        .toggle('§eネームタグの色を変更', { defaultValue: settings.nameTagColorEnabled })
        .submitButton('§0適用');

    form.show(player).then(response => {
        if (response.canceled) {
            showMainMenu(player);
            return;
        }

        const ffEnabled = response.formValues[2];
        const chatEnabled = response.formValues[4];
        const nametagEnabled = response.formValues[6];

        // 新しい設定を保存
        saveSettings({
            friendlyFire: ffEnabled,
            chatColorEnabled: chatEnabled,
            nameTagColorEnabled: nametagEnabled,
        });

        player.sendMessage(`[§bTeams§r] §a設定を保存しました`);
        showMainMenu(player);
    });
}

// ==========================================
// イベントリスナー (ロジック部分)
// ==========================================

system.afterEvents.scriptEventReceive.subscribe(event => {
    if (event.id === 'team:s') {
        const player = event.sourceEntity;

        if (player && player.typeId === 'minecraft:player') {
            // UIを表示
            showMainMenu(player);
        } else {
            console.warn('このコマンドはプレイヤーのみ実行可能です');
        }
    }
});

// チャットの色変更
world.beforeEvents.chatSend.subscribe(event => {
    const settings = getSettings();
    if (!settings.chatColorEnabled) return;
    const player = event.sender;
    const team = getPlayerTeam(player);

    if (team) {
        event.cancel = true;
        world.sendMessage(`${team.color}[${team.name}] ${player.name}§r: ${event.message}`);
    }
});

// フレンドリーファイア制御
world.beforeEvents.entityHurt.subscribe(event => {
    const victim = event.hurtEntity;
    const attacker = event.damageSource.damagingEntity;

    if (!attacker || attacker.typeId !== 'minecraft:player' || victim.typeId !== 'minecraft:player') {
        return;
    }

    const settings = getSettings();
    if (settings.friendlyFire) {
        return;
    }

    const teams = getTeams(); // 最新のチーム情報を取得
    const victimTeam = getPlayerTeam(victim, teams);
    const attackerTeam = getPlayerTeam(attacker, teams);

    // 同じチームならキャンセル
    if (victimTeam && attackerTeam && victimTeam.tag === attackerTeam.tag) {
        event.cancel = true;
    }
});

// ネームタグリセット完了を記録するフラグ
let isNameTagReset = false;

// ネームタグの常時更新
system.runInterval(() => {
    const settings = getSettings(); // 設定を取得

    if (!settings.nameTagColorEnabled) {
        if (!isNameTagReset) {
            // まだリセットしていなければ、全員をデフォルトに戻す
            for (const player of world.getPlayers()) {
                if (player.nameTag !== player.name) {
                    player.nameTag = player.name;
                }
            }
            isNameTagReset = true;
        }
        return;
    }

    isNameTagReset = false;
    const teams = getTeams();

    for (const player of world.getPlayers()) {
        const team = getPlayerTeam(player, teams);

        if (team) {
            // チームに所属している場合
            const newTag = `${team.color}${player.name}`;
            if (player.nameTag !== newTag) {
                player.nameTag = newTag;
            }
        } else {
            // チームに所属していない場合
            if (player.nameTag !== player.name) {
                player.nameTag = player.name;
            }
        }
    }
}, 5);
