import { world,system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

var player_Cash_Data = {}
export function blockrun(eventData){

    if(eventData.block.typeId === "addblock:commandsrun") {
        const player = eventData.player
        player_Cash_Data[player.name]={}
        system.run(() => {
            if (!player_Cash_Data[player.name].TitaniumStop) {
                player_Cash_Data[player.name].TitaniumStop = true
                //ここから実行

            player_Cash_Data[player.id] = {}

            //command取得
            player_Cash_Data[player.id].CommandList = world.getDynamicProperty('commandList')
            if(player_Cash_Data[player.id].CommandList==undefined){
                player_Cash_Data[player.id].CommandList=[]
            }else{
                player_Cash_Data[player.id].CommandList = JSON.parse( player_Cash_Data[player.id].CommandList);
            }

            //HOME画面
            var form = new ActionFormData();
            form.title("メニュー");
            form.body(`§5>>>§s選択してください`);
            for (let i = 0; i < player_Cash_Data[player.id].CommandList.length; i++){
             form.button(`${player_Cash_Data[player.id].CommandList[i][0]}`);
            }
            if (player.hasTag('commandsrunOP')) {
                form.button("§5コマンドカスタマイズ");
            }
            if(!player.hasTag('commandsrunOP')&&player_Cash_Data[player.id].CommandList.length==0){
                player.sendMessage(`§5>>>§sCommandsをカスタマイズする場合は  §6/function commandsOP §sを§e実行§sしてください`)
                 //通知音
                 player.playSound("random.toast", {
                    pitch: 1.7, 
                    volume: 1.0
                });
                return;
            }
            form.show(player).then(r => {
                if (r.canceled) return;
                player_Cash_Data[player.id].selectcommand = r.selection;
                //コマンドカスタマイズ
                if(player_Cash_Data[player.id].CommandList.length==player_Cash_Data[player.id].selectcommand){
                    var form = new ActionFormData();
                        form.title("コマンドカスタマイズ");
                        form.body(`§5>>>§s選択してください`);
                        form.button(`§1追加`);
                        form.button("§0編集");
                        form.button("§5削除");
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            let response = r.selection;
                            switch (response) {
                                case 0:
                                    var form = new ModalFormData();
                                    form.title("コマンドカスタマイズ:追加");
                                    form.textField(`機能表示名`, "")
                                    form.textField(`コマンド`, "スラッシュ必須")
                                    form.textField(`コマンド実行時メッセージ`, "")
                                    form.show(player).then(r => {
                                        if (r.canceled) {
                                             return;
                                        };
                                     //command取得
                                         player_Cash_Data[player.id].CommandList = world.getDynamicProperty('commandList')
                                        if(player_Cash_Data[player.id].CommandList==undefined){
                                          player_Cash_Data[player.id].CommandList=[]
                                        }else{
                                         player_Cash_Data[player.id].CommandList = JSON.parse( player_Cash_Data[player.id].CommandList);
                                        }
                                        player_Cash_Data[player.id].CommandList.push([r.formValues[0],r.formValues[1],r.formValues[2]])
                                        world.setDynamicProperty('commandList',JSON.stringify(player_Cash_Data[player.id].CommandList))
                                        player.sendMessage(`§5>>>§a追加しました`)
                                        //通知音
                                        player.playSound("random.toast", {
                                            pitch: 1.7, 
                                            volume: 1.0
                                        });
                                    })
                                break;
                                case 1:
                                    //command取得
                                    player_Cash_Data[player.id].CommandList = world.getDynamicProperty('commandList')
                                    if(player_Cash_Data[player.id].CommandList==undefined){
                                      player_Cash_Data[player.id].CommandList=[]
                                    }else{
                                     player_Cash_Data[player.id].CommandList = JSON.parse( player_Cash_Data[player.id].CommandList);
                                    }
                                        var form = new ActionFormData();
                                        form.title("コマンドカスタマイズ:編集");
                                        form.body(`§5>>>§s編集するコマンド選択してください`);
                                        for (let i = 0; i < player_Cash_Data[player.id].CommandList.length; i++){
                                         form.button(`§0${player_Cash_Data[player.id].CommandList[i][0]}\n§5>>>§1${player_Cash_Data[player.id].CommandList[i][1]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            player_Cash_Data[player.id].selectcommand = r.selection;
                                            
                                            var form = new ModalFormData();
                                            form.title("コマンドカスタマイズ:編集");
                                            form.textField(`機能表示名`, `${player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][0]}`)
                                            form.textField(`コマンド`, `${player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][1]}`)
                                            form.textField(`コマンド実行時メッセージ`, `${player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][2]}`)
                                            form.show(player).then(r => {
                                                if (r.canceled) {
                                                     return;
                                                };
                                            if(r.formValues[0]!==''){
                                               player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][0]=r.formValues[0]
                                            }
                                            if(r.formValues[1]!==''){
                                               player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][1]=r.formValues[1]
                                            }
                                            if(r.formValues[2]!==''){
                                               player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][2]=r.formValues[2]
                                            }
                                               world.setDynamicProperty('commandList',JSON.stringify(player_Cash_Data[player.id].CommandList))
                                            player.sendMessage(`§5>>>§a編集しました`)
                                            //通知音
                                            player.playSound("random.toast", {
                                               pitch: 1.7, 
                                               volume: 1.0
                                            });
                                          })
                                        })
                                break;
                                case 2:
                                    //command取得
                                    player_Cash_Data[player.id].CommandList = world.getDynamicProperty('commandList')
                                    if(player_Cash_Data[player.id].CommandList==undefined){
                                      player_Cash_Data[player.id].CommandList=[]
                                    }else{
                                     player_Cash_Data[player.id].CommandList = JSON.parse( player_Cash_Data[player.id].CommandList);
                                    }
                                        var form = new ActionFormData();
                                        form.title("コマンドカスタマイズ:削除");
                                        form.body(`§5>>>§s削除するコマンド選択してください`);
                                        for (let i = 0; i < player_Cash_Data[player.id].CommandList.length; i++){
                                         form.button(`§0${player_Cash_Data[player.id].CommandList[i][0]}\n§5>>>§1${player_Cash_Data[player.id].CommandList[i][1]}`);
                                        }
                                        form.show(player).then(r => {
                                            if (r.canceled) return;
                                            player_Cash_Data[player.id].selectcommand = r.selection;
                                            player_Cash_Data[player.id].CommandList.splice(player_Cash_Data[player.id].selectcommand,1)
                                            world.setDynamicProperty('commandList',JSON.stringify(player_Cash_Data[player.id].CommandList))
                                            player.sendMessage(`§5>>>§a削除しました`)
                                            //通知音
                                            player.playSound("random.toast", {
                                               pitch: 1.7, 
                                               volume: 1.0
                                            });
                                        })
                                break;
                            }
                        })
                }else{
                     player.runCommand(`${player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][1]}`)
                     player.sendMessage(`${player_Cash_Data[player.id].CommandList[player_Cash_Data[player.id].selectcommand][2]}`)
                     player.playSound("random.toast", {
                        pitch: 1.7, 
                        volume: 1.0
                     });
                }
            })
                //ここまで
                system.runTimeout(() => {
                    player_Cash_Data[player.name].TitaniumStop = false
                }, 20); 
        }
        })
    }
}