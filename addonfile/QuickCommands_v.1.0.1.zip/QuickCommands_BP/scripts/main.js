import { world, system } from "@minecraft/server";
import { commandsrun } from "./itemrun.js"
import { blockrun } from "./blockrun.js"
import { ActionFormData,MessageFormData,ModalFormData } from "@minecraft/server-ui";

world.beforeEvents.playerInteractWithBlock.subscribe((eventData) =>{
    blockrun(eventData);
}) 

//アイテムでの実行
world.beforeEvents.itemUse.subscribe(eventData => {
    //実行アイテム=additem:haruphone1
    commandsrun(eventData)
})
