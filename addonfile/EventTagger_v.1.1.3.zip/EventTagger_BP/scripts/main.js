import { world, system } from '@minecraft/server';

// 設置
world.afterEvents.playerPlaceBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    if (!player) return;
    try {
        player.addTag('PlaceBlock');
        player.addTag(`PlaceBlock_${block.typeId}`);
        player.addTag(`PlaceBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
        system.runTimeout(() => {
            try {
                if (player.hasTag('PlaceBlock')) {
                    player.removeTag('PlaceBlock');
                    player.removeTag(`PlaceBlock_${block.typeId}`);
                    player.removeTag(`PlaceBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                }
            } catch (e) {}
        }, 1);
    } catch (e) {}
});

// 破壊
world.afterEvents.playerBreakBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    const brokenBlockPermutation = event.brokenBlockPermutation;
    if (!player) return;
    try {
        system.run(() => {
            try {
                player.addTag('BreakBlock');
                player.addTag(`BreakBlock_${brokenBlockPermutation.type.id}`);
                player.addTag(`BreakBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                system.runTimeout(() => {
                    try {
                        if (player.hasTag('BreakBlock')) {
                            player.removeTag('BreakBlock');
                            player.removeTag(`BreakBlock_${brokenBlockPermutation.type.id}`);
                            player.removeTag(`BreakBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                        }
                    } catch (e) {}
                }, 1);
            } catch (e) {}
        });
    } catch (e) {}
});

// ブロック右クリック
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    if (!player) return;
    try {
        system.run(() => {
            try {
                player.addTag('InteractWithBlock');
                player.addTag(`InteractWithBlock_${block.typeId}`);
                player.addTag(`InteractWithBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                system.runTimeout(() => {
                    try {
                        if (player.hasTag('InteractWithBlock')) {
                            player.removeTag('InteractWithBlock');
                            player.removeTag(`InteractWithBlock_${block.typeId}`);
                            player.removeTag(`InteractWithBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                        }
                    } catch (e) {}
                }, 1);
            } catch (e) {}
        });
    } catch (e) {}
});

// ブロック攻撃
world.afterEvents.entityHitBlock.subscribe(event => {
    const damagingEntity = event.damagingEntity;
    const block = event.hitBlock;
    if (!damagingEntity) return;
    try {
        damagingEntity.addTag('HitBlock');
        damagingEntity.addTag(`HitBlock_${event.hitBlockPermutation.type.id}`);
        damagingEntity.addTag(`HitBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
        system.runTimeout(() => {
            try {
                if (damagingEntity.hasTag('HitBlock')) {
                    damagingEntity.removeTag('HitBlock');
                    damagingEntity.removeTag(`HitBlock_${event.hitBlockPermutation.type.id}`);
                    damagingEntity.removeTag(`HitBlock_location_${block.location.x},${block.location.y},${block.location.z}`);
                }
            } catch (e) {}
        }, 1);
    } catch (e) {}
});

// エンティティ右クリック
world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    system.run(() => {
        const player = event.player;
        const target = event.target;
        if (!player) return;
        try {
            player.addTag('InteractWithEntity');
            player.addTag(`InteractWithEntity_${target.id}`);
            player.addTag(`InteractWithEntity_nametag_${target.nameTag}`);
            system.runTimeout(() => {
                try {
                    if (player.hasTag('InteractWithEntity')) {
                        player.removeTag('InteractWithEntity');
                        player.removeTag(`InteractWithEntity_${target.id}`);
                        player.removeTag(`InteractWithEntity_nametag_${target.nameTag}`);
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    });
});

// アイテム使用
world.afterEvents.itemUse.subscribe(event => {
    const source = event.source;
    const item = event.itemStack;
    if (!source) return;
    try {
        source.addTag('itemUse');
        source.addTag(`itemUse_${item.type.id}`);
        source.addTag(`itemUse_nametag_${item.nameTag}`);
        system.runTimeout(() => {
            try {
                if (source.hasTag('itemUse')) {
                    source.removeTag('itemUse');
                    source.removeTag(`itemUse_${item.type.id}`);
                    source.removeTag(`itemUse_nametag_${item.nameTag}`);
                }
            } catch (e) {}
        }, 1);
    } catch (e) {}
});

// エンティティ死亡
world.afterEvents.entityDie.subscribe(event => {
    const playerA = event.damageSource.damagingEntity; // キラー
    const playerB = event.deadEntity; // 死亡者

    // キラー
    if (playerA) {
        try {
            playerA.addTag('entityDieA');
            playerA.addTag(`entityDieA_${playerA.id}`);
            playerA.addTag(`entityDieA_nameTag_${playerA.nameTag}`);
            if (playerB) {
                playerA.addTag(`entityDieA_target_${playerB.id}`);
                playerA.addTag(`entityDieA_targetNameTag_${playerB.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (playerA.hasTag('entityDieA')) {
                        playerA.removeTag('entityDieA');
                        playerA.removeTag(`entityDieA_${playerA.id}`);
                        playerA.removeTag(`entityDieA_nameTag_${playerA.nameTag}`);
                        if (playerB) {
                            playerA.removeTag(`entityDieA_target_${playerB.id}`);
                            playerA.removeTag(`entityDieA_targetNameTag_${playerB.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }

    // 死亡者
    if (playerB) {
        try {
            playerB.addTag('entityDieB');
            playerB.addTag(`entityDieB_${playerB.id}`);
            playerB.addTag(`entityDieB_nameTag_${playerB.nameTag}`);
            if (playerA) {
                playerB.addTag(`entityDieB_killer_${playerA.id}`);
                playerB.addTag(`entityDieB_killerNameTag_${playerA.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (playerB.hasTag('entityDieB')) {
                        playerB.removeTag('entityDieB');
                        playerB.removeTag(`entityDieB_${playerB.id}`);
                        playerB.removeTag(`entityDieB_nameTag_${playerB.nameTag}`);
                        if (playerA) {
                            playerB.removeTag(`entityDieB_killer_${playerA.id}`);
                            playerB.removeTag(`entityDieB_killerNameTag_${playerA.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }
});

// エンティティがダメージを受けた時
world.afterEvents.entityHurt.subscribe(event => {
    const damagingEntity = event.damageSource.damagingEntity; // 攻撃者
    const hurtEntity = event.hurtEntity; // 被害者

    //攻撃者
    if (damagingEntity) {
        try {
            damagingEntity.addTag('entityHurt');
            damagingEntity.addTag(`entityHurt_${damagingEntity.id}`);
            damagingEntity.addTag(`entityHurt_nameTag_${damagingEntity.nameTag}`);
            if (hurtEntity) {
                damagingEntity.addTag(`entityHurt_target_${hurtEntity.id}`);
                damagingEntity.addTag(`entityHurt_targetNameTag_${hurtEntity.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (damagingEntity.hasTag('entityHurt')) {
                        damagingEntity.removeTag('entityHurt');
                        damagingEntity.removeTag(`entityHurt_${damagingEntity.id}`);
                        damagingEntity.removeTag(`entityHurt_nameTag_${damagingEntity.nameTag}`);
                        if (hurtEntity) {
                            damagingEntity.removeTag(`entityHurt_target_${hurtEntity.id}`);
                            damagingEntity.removeTag(`entityHurt_targetNameTag_${hurtEntity.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }

    //被害者
    if (hurtEntity) {
        try {
            hurtEntity.addTag('entityHurt_victim');
            hurtEntity.addTag(`entityHurt_victim_${hurtEntity.id}`);
            hurtEntity.addTag(`entityHurt_victim_nameTag_${hurtEntity.nameTag}`);
            if (damagingEntity) {
                hurtEntity.addTag(`entityHurt_victim_attacker_${damagingEntity.id}`);
                hurtEntity.addTag(`entityHurt_victim_attackerNameTag_${damagingEntity.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (hurtEntity.hasTag('entityHurt_victim')) {
                        hurtEntity.removeTag('entityHurt_victim');
                        hurtEntity.removeTag(`entityHurt_victim_${hurtEntity.id}`);
                        hurtEntity.removeTag(`entityHurt_victim_nameTag_${hurtEntity.nameTag}`);
                        if (damagingEntity) {
                            hurtEntity.removeTag(`entityHurt_victim_attacker_${damagingEntity.id}`);
                            hurtEntity.removeTag(`entityHurt_victim_attackerNameTag_${damagingEntity.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }
});

// エンティティがエンティティを攻撃した時 (お互いの情報を追加)
world.afterEvents.entityHitEntity.subscribe(event => {
    const damagingEntity = event.damagingEntity; // 攻撃者
    const hitEntity = event.hitEntity; // 被害者

    //被害者
    if (hitEntity) {
        try {
            hitEntity.addTag('entityHitEntity');
            hitEntity.addTag(`entityHitEntity_${hitEntity.id}`);
            hitEntity.addTag(`entityHitEntity_nameTag_${hitEntity.nameTag}`);
            if (damagingEntity) {
                hitEntity.addTag(`entityHitEntity_attacker_${damagingEntity.id}`);
                hitEntity.addTag(`entityHitEntity_attackerNameTag_${damagingEntity.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (hitEntity.hasTag('entityHitEntity')) {
                        hitEntity.removeTag('entityHitEntity');
                        hitEntity.removeTag(`entityHitEntity_${hitEntity.id}`);
                        hitEntity.removeTag(`entityHitEntity_nameTag_${hitEntity.nameTag}`);
                        if (damagingEntity) {
                            hitEntity.removeTag(`entityHitEntity_attacker_${damagingEntity.id}`);
                            hitEntity.removeTag(`entityHitEntity_attackerNameTag_${damagingEntity.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }

    //攻撃者
    if (damagingEntity) {
        try {
            damagingEntity.addTag('entityHitEntity_attacker');
            damagingEntity.addTag(`entityHitEntity_attacker_${damagingEntity.id}`);
            damagingEntity.addTag(`entityHitEntity_attacker_nameTag_${damagingEntity.nameTag}`);
            if (hitEntity) {
                damagingEntity.addTag(`entityHitEntity_attacker_target_${hitEntity.id}`);
                damagingEntity.addTag(`entityHitEntity_attacker_targetNameTag_${hitEntity.nameTag}`);
            }
            system.runTimeout(() => {
                try {
                    if (damagingEntity.hasTag('entityHitEntity_attacker')) {
                        damagingEntity.removeTag('entityHitEntity_attacker');
                        damagingEntity.removeTag(`entityHitEntity_attacker_${damagingEntity.id}`);
                        damagingEntity.removeTag(`entityHitEntity_attacker_nameTag_${damagingEntity.nameTag}`);
                        if (hitEntity) {
                            damagingEntity.removeTag(`entityHitEntity_attacker_target_${hitEntity.id}`);
                            damagingEntity.removeTag(`entityHitEntity_attacker_targetNameTag_${hitEntity.nameTag}`);
                        }
                    }
                } catch (e) {}
            }, 1);
        } catch (e) {}
    }
});

// 左クリック
world.afterEvents.playerSwingStart.subscribe(event => {
    const player = event.player;
    const handitem = event.heldItemStack;
    if (!player) return;
    try {
        player.addTag('playerSwingStart');
        if (handitem) {
            player.addTag(`playerSwingStart_${handitem.type.id}`);
        }
        system.runTimeout(() => {
            try {
                if (player.hasTag('playerSwingStart')) {
                    player.removeTag('playerSwingStart');
                    if (handitem) {
                        player.removeTag(`playerSwingStart_${handitem.type.id}`);
                    }
                }
            } catch (e) {}
        }, 1);
    } catch (e) {}
});

// ジャンプ
const playerJumpCooldowns = new Map();
system.runInterval(() => {
    for (const [playerId, ticks] of playerJumpCooldowns.entries()) {
        if (ticks <= 1) playerJumpCooldowns.delete(playerId);
        else playerJumpCooldowns.set(playerId, ticks - 1);
    }

    for (const player of world.getAllPlayers()) {
        const isCooldown = playerJumpCooldowns.has(player.id);
        if (player.isJumping && !isCooldown) {
            try {
                player.addTag('playerJump');
                system.runTimeout(() => {
                    try {
                        player.removeTag('playerJump');
                    } catch (e) {}
                }, 1);
                playerJumpCooldowns.set(player.id, 10);
            } catch (e) {}
        }
    }
});

// スニーク
const playerSneakingCooldowns = new Map();
system.runInterval(() => {
    for (const [playerId, ticks] of playerSneakingCooldowns.entries()) {
        if (ticks <= 1) playerSneakingCooldowns.delete(playerId);
        else playerSneakingCooldowns.set(playerId, ticks - 1);
    }

    for (const player of world.getAllPlayers()) {
        const isCooldown = playerSneakingCooldowns.has(player.id);
        if (player.isSneaking && !isCooldown) {
            try {
                player.addTag('playerSneak');
                system.runTimeout(() => {
                    try {
                        player.removeTag('playerSneak');
                    } catch (e) {}
                }, 1);
                playerSneakingCooldowns.set(player.id, 10);
            } catch (e) {}
        }
    }
});
