import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UI } from '../ui';

// --- 設定項目 ---
let DAYS_TO_KEEP = 7; // データ保存期間（日数）
const LOG_INTERVAL = 1200; // ログ記録間隔（tick、1200 = 1分）
const MAX_LOGS_PER_PART = 400; // 1プロパティあたりの最大ログ数
const LOGS_PER_PAGE = 40; // 1ページに表示するログの件数

// --- 内部変数 ---
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
export let securityLogNames = [];

// --- 初期化・リロード処理 ---
export function lreload() {
    try {
        const storedDays = world.getDynamicProperty('location_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[Location] Error loading location_delete_speed: ${e}`);
    }
    loadPlayerNames();
}

// --- ヘルパー関数 ---

function getDateKey(timestamp) {
    const date = new Date(timestamp);
    return `${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(date.getUTCDate()).padStart(2, '0')}`;
}

function getJapanTimeString(timestamp) {
    try {
        const timeOffset = world.getDynamicProperty('Time_Setting') || 9;
        const japanTime = new Date(timestamp + timeOffset * 60 * 60 * 1000);
        const year = japanTime.getUTCFullYear();
        const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
        const day = String(japanTime.getUTCDate()).padStart(2, '0');
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        const seconds = String(japanTime.getUTCSeconds()).padStart(2, '0');
        return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
    } catch {
        return '時刻取得エラー';
    }
}

/**
 * [新規追加] ディメンションIDを日本語名に変換する関数
 * @param {string | undefined} dimensionId - ディメンションID
 * @returns {string} 日本語のディメンション名
 */
function getDimensionName(dimensionId) {
    switch (dimensionId) {
        case 'minecraft:overworld':
            return 'オーバーワールド';
        case 'minecraft:nether':
            return 'ネザー';
        case 'minecraft:the_end':
            return 'エンド';
        default:
            // dimensionIdが存在しない古いデータの場合は「データなし」を返す
            return 'データなし';
    }
}

function getLogKeyBase(playerName, timestamp) {
    return `location_${playerName}_${getDateKey(timestamp)}`;
}

/**
 * [修正] プレイヤー名保存処理を堅牢化
 * 既存の保存データとメモリ上のデータをマージしてから保存することで、オフラインプレイヤーが消えるのを防ぐ
 */
function savePlayerNames() {
    try {
        let existingNames = [];
        try {
            const storedNames = world.getDynamicProperty('location_names');
            if (typeof storedNames === 'string' && storedNames.length > 2) {
                const parsed = JSON.parse(storedNames);
                if (Array.isArray(parsed)) {
                    existingNames = parsed;
                }
            }
        } catch (e) {
            console.warn(`[Location] 保存前に既存のプレイヤーリスト読み込みに失敗: ${e}`);
        }

        // 現在のメモリ上のリストと、ストレージから読み込んだリストを結合し、重複を削除
        const mergedNames = [...new Set([...existingNames, ...securityLogNames])];
        world.setDynamicProperty('location_names', JSON.stringify(mergedNames));
    } catch (e) {
        console.warn(`[Location] プレイヤー名保存エラー: ${e}`);
    }
}

// [修正済み] データ読み込み処理を堅牢化
function loadPlayerNames() {
    let loadedNames = [];
    try {
        const storedNames = world.getDynamicProperty('location_names');
        // 保存されているデータが文字列であり、空でないことを確認
        if (typeof storedNames === 'string' && storedNames.length > 2) {
            // "[]" より大きい
            const parsedNames = JSON.parse(storedNames);
            if (Array.isArray(parsedNames)) {
                loadedNames = parsedNames;
            } else {
                console.warn(`[Location] 動的プロパティ 'location_names' のデータが不正です。`);
            }
        }
    } catch (e) {
        console.warn(`[Location] プレイヤー名リストの読み込みに失敗しました。データ破損の可能性があります: ${e}`);
    }
    // メモリ上の既存のリストと、ストレージから読み込んだリストを結合し、重複を削除する
    const mergedNames = new Set([...securityLogNames, ...loadedNames]);
    securityLogNames = [...mergedNames];
}

// --- データ管理（記録・読み込み・削除） ---

system.runInterval(() => {
    if (world.getDynamicProperty('Log_system') !== true) return;

    const players = world.getPlayers();
    if (players.length === 0) return;

    const now = Date.now();
    let playerNamesModified = false;

    // 現在オンラインのプレイヤーをリストに追加
    for (const player of players) {
        if (!securityLogNames.includes(player.name)) {
            securityLogNames.push(player.name);
            playerNamesModified = true;
        }
    }
    // リストに変更があれば保存
    if (playerNamesModified) savePlayerNames();

    for (const player of players) {
        // [修正] ログにディメンション情報を追加
        const logEntry = {
            x: Math.round(player.location.x),
            y: Math.round(player.location.y),
            z: Math.round(player.location.z),
            dimension: player.dimension.id, // ディメンションIDを記録
            timestamp: now,
        };

        const keyBase = getLogKeyBase(player.name, now);
        let part = 1;
        let targetKey = `${keyBase}_part${part}`;

        while (true) {
            try {
                const storedData = world.getDynamicProperty(targetKey);
                if (!storedData) break;
                const logData = JSON.parse(storedData);
                if (logData.length < MAX_LOGS_PER_PART) break;
                part++;
                targetKey = `${keyBase}_part${part}`;
            } catch {
                // JSONパースエラーなどで無限ループに陥るのを防ぐ
                break;
            }
        }

        try {
            const storedData = world.getDynamicProperty(targetKey);
            const currentLogs = storedData ? JSON.parse(storedData) : [];
            currentLogs.push(logEntry);
            world.setDynamicProperty(targetKey, JSON.stringify(currentLogs));
        } catch (e) {
            console.warn(`[Location] ログデータ保存エラー (${targetKey}): ${e}`);
        }
    }
}, LOG_INTERVAL);

// [修正済み] 古いログの削除処理を修正
system.runInterval(() => {
    try {
        const expirationDay = parseInt(getDateKey(Date.now() - DAYS_TO_KEEP * MILLISECONDS_PER_DAY), 10);
        const allKeys = world.getDynamicPropertyIds();

        for (const key of allKeys) {
            // 'location_names' キーは絶対に削除しないように明示的に除外する
            if (key.startsWith('location_') && key !== 'location_names' && key !== 'location_delete_speed') {
                // キーのフォーマット `location_PLAYERNAME_YYYYMMDD...` から日付部分を抽出
                const match = key.match(/_(\d{8})/);
                if (match) {
                    const datePart = parseInt(match[1], 10);
                    // 設定された保存期間より古いデータを削除
                    if (datePart < expirationDay) {
                        world.setDynamicProperty(key, undefined);
                    }
                }
            }
        }
    } catch (e) {
        console.warn(`[Location] 古いログの削除処理中にエラーが発生しました: ${e}`);
    }
}, 36000); // 30分ごとに実行 (36000 ticks)

// [修正済み] 古いデータ形式も読み込めるように互換性を追加
function getAllLogsForPlayer(playerName) {
    let allLogs = [];
    const today = Date.now();

    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const timestamp = today - i * MILLISECONDS_PER_DAY;
        const keyBase = getLogKeyBase(playerName, timestamp);

        // --- ここからが互換性対応部分 ---
        // 1. 古い形式のキー（_partなし）を読み込む
        try {
            const oldFormatData = world.getDynamicProperty(keyBase);
            if (oldFormatData) {
                const parsed = JSON.parse(oldFormatData);
                if (Array.isArray(parsed)) {
                    allLogs = allLogs.concat(parsed);
                }
            }
        } catch (e) {
            console.warn(`[Location] 旧形式ログの読み込みエラー (${keyBase}): ${e}`);
        }
        // --- 互換性対応部分ここまで ---

        // 2. 新しい形式（_part付き）のキーを読み込む
        let part = 1;
        while (true) {
            const key = `${keyBase}_part${part}`;
            try {
                const storedData = world.getDynamicProperty(key);
                if (!storedData) break;
                const parsedData = JSON.parse(storedData);
                if (Array.isArray(parsedData)) {
                    allLogs = allLogs.concat(parsedData);
                }
            } catch (e) {
                console.warn(`[Location] ログデータ取得エラー (${key}): ${e}`);
                break; // エラー発生時はループを抜ける
            }
            part++;
        }
    }
    return allLogs.sort((a, b) => b.timestamp - a.timestamp); // 最新順にソート
}

// --- UI関連 ---

export function showMainMenu_Location(player) {
    new ActionFormData()
        .title('§0§lSecureCraft')
        .body('検索方法を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1プレイヤー選択', 'textures/ui/icon_multiplayer.png')
        .button('§5座標範囲で検索', 'textures/ui/icon_map.png')
        .show(player)
        .then(response => {
            if (response.canceled) return;
            if (response.selection === 0) UI(player);
            else if (response.selection === 1) showPlayerList_Location(player);
            else if (response.selection === 2) showCoordinateInput(player);
        });
}

function showPlayerList_Location(player) {
    loadPlayerNames(); // 最新のリストを読み込む
    if (securityLogNames.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §aログデータがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        return;
    }

    const form = new ActionFormData().title('§0§lSecureCraft').body('確認したいプレイヤーを選んでください').button('§l§l戻る', 'textures/ui/icon_import.png');
    // リストをソートして表示
    securityLogNames.sort().forEach(name => form.button(`§1${name}`));
    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainMenu_Location(player);
            return;
        }
        const selectedPlayer = securityLogNames.sort()[response.selection - 1];
        const allLogs = getAllLogsForPlayer(selectedPlayer);
        showPaginatedLogs(player, {
            logs: allLogs,
            title: `§1${selectedPlayer} の全ログ`,
            targetName: selectedPlayer,
            page: 1,
            backCallback: () => showPlayerList_Location(player),
        });
    });
}

function showPaginatedLogs(player, context) {
    const { logs, title, targetName, page, backCallback } = context;

    if (logs.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a表示できるログデータがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        backCallback();
        return;
    }

    const totalPages = Math.ceil(logs.length / LOGS_PER_PAGE);
    const startIndex = (page - 1) * LOGS_PER_PAGE;
    const logsToShow = logs.slice(startIndex, startIndex + LOGS_PER_PAGE);

    const form = new ActionFormData().title(title).body(`§eページ: ${page} / ${totalPages} §r| §e総件数: ${logs.length}件\n§aログを選択してください`);

    const buttonActions = [];

    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttonActions.push(backCallback);

    if (page > 1) {
        form.button('§1前のページへ', 'textures/ui/arrow_left.png');
        buttonActions.push(() => showPaginatedLogs(player, { ...context, page: page - 1 }));
    }

    // [修正] ログ一覧にディメンション情報を表示
    logsToShow.forEach(log => {
        const time = getJapanTimeString(log.timestamp);
        const dimensionName = getDimensionName(log.dimension);
        form.button(`§0${time} §5(${log.x}, ${log.y}, ${log.z}) \n§1[${dimensionName}]`);
        buttonActions.push(() => showLogDetails(player, targetName, log, () => showPaginatedLogs(player, context)));
    });

    if (page < totalPages) {
        form.button('§1次のページへ', 'textures/ui/arrow_right.png');
        buttonActions.push(() => showPaginatedLogs(player, { ...context, page: page + 1 }));
    }

    form.show(player).then(response => {
        if (response.canceled) return;
        buttonActions[response.selection]();
    });
}

function showCoordinateInput(player) {
    const { x, y, z } = player.location;
    new ModalFormData()
        .title('§1座標からプレイヤー検索')
        .textField('X座標', '半角数字', { defaultValue: `${String(Math.round(x))}` })
        .textField('Y座標', '半角数字', { defaultValue: `${String(Math.round(y))}` })
        .textField('Z座標', '半角数字', { defaultValue: `${String(Math.round(z))}` })
        .dropdown('検索半径', ['10', '30', '50', '80'])
        .show(player)
        .then(response => {
            if (response.canceled) {
                showMainMenu_Location(player);
                return;
            }
            const [xStr, yStr, zStr, radiusIndex] = response.formValues;
            const radius = [10, 30, 50, 80][radiusIndex];
            const centerX = parseFloat(xStr);
            const centerY = parseFloat(yStr);
            const centerZ = parseFloat(zStr);

            if (isNaN(centerX) || isNaN(centerY) || isNaN(centerZ)) {
                player.sendMessage('§r[§bSecurityCraft§r] §c無効な座標が入力されました。');
                return;
            }
            showPlayersByCoordinates(player, { centerX, centerY, centerZ, radius });
        });
}

function showPlayersByCoordinates(player, searchParams) {
    const { centerX, centerY, centerZ, radius } = searchParams;
    const playerLogs = {};

    loadPlayerNames(); // 最新のリストを読み込む
    for (const playerName of securityLogNames) {
        const allLogs = getAllLogsForPlayer(playerName);
        const filtered = allLogs.filter(log => Math.abs(log.x - centerX) <= radius && Math.abs(log.y - centerY) <= radius && Math.abs(log.z - centerZ) <= radius);
        if (filtered.length > 0) {
            playerLogs[playerName] = filtered;
        }
    }

    if (Object.keys(playerLogs).length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a指定範囲にプレイヤーのログはありませんでした。');
        showCoordinateInput(player);
        return;
    }

    const form = new ActionFormData().title('§1座標範囲内のプレイヤー').body(`中心: §b${centerX}, ${centerY}, ${centerZ} §r(半径: §b${radius}ブロック§r)\n§aプレイヤーを選択してください`).button('§l戻る', 'textures/ui/icon_import.png');

    const playerNames = Object.keys(playerLogs).sort();
    playerNames.forEach(name => form.button(`§1${name} §0(${playerLogs[name].length}件)`));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showCoordinateInput(player);
            return;
        }
        const selectedPlayer = playerNames[response.selection - 1];
        showPaginatedLogs(player, {
            logs: playerLogs[selectedPlayer],
            title: `§1${selectedPlayer} のログ（座標範囲）`,
            targetName: selectedPlayer,
            page: 1,
            backCallback: () => showPlayersByCoordinates(player, searchParams),
        });
    });
}

// [修正] ログ詳細にディメンション情報を表示
function showLogDetails(player, targetName, log, backCallback) {
    const time = getJapanTimeString(log.timestamp);
    const dimensionName = getDimensionName(log.dimension);
    const logText = `§a§b${targetName} §rの§6座標ログ`;
    new ActionFormData()
        .title('§0§lSecureCraft')
        .body(logText)
        .divider() // .divider() や .label() はボタンインデックスに影響しない
        .label(`§aDimension§r: §b${dimensionName}\n§aX§r: §b${log.x} §aY§r: §b${log.y} §aZ§r: §b${log.z}\n\n§a記録時刻§r:§e${time}`)
        .button('§l戻る', 'textures/ui/icon_import.png') // selection: 0
        .button(`§0記録座標にテレポート`, 'textures/items/ender_pearl.png') // selection: 1
        .show(player)
        .then(response => {
            if (response.canceled) return;

            if (response.selection === 0) {
                backCallback();
            } else if (response.selection === 1) {
                if (log.dimension) {
                    try {
                        const dimension = world.getDimension(log.dimension);
                        player.teleport({ x: log.x, y: log.y, z: log.z }, { dimension: dimension });
                        player.sendMessage(`§r[§bSecurityCraft§r] §a(${log.x}, ${log.y}, ${log.z}) [${dimensionName}] へテレポートしました。`);
                    } catch (e) {
                        player.sendMessage(`§r[§bSecurityCraft§r] §cテレポートに失敗しました。ディメンションが見つからない可能性があります。`);
                        console.warn(`[Location] Teleport failed: ${e}`);
                        backCallback(); // 失敗したら前の画面に戻る
                    }
                } else {
                    player.sendMessage('§r[§bSecurityCraft§r] §eログにディメンション情報がありません。オーバーワールドの座標へテレポートします。');
                    try {
                        const overworld = world.getDimension('minecraft:overworld');
                        player.teleport({ x: log.x, y: log.y, z: log.z }, { dimension: overworld });
                        player.sendMessage(`§r[§bSecurityCraft§r] §a(${log.x}, ${log.y}, ${log.z}) [オーバーワールド] へテレポートしました。`);
                    } catch (e) {
                        player.sendMessage(`§r[§bSecurityCraft§r] §cオーバーワールドへのテレポートに失敗しました。`);
                        console.warn(`[Location] Teleport to Overworld failed: ${e}`);
                        backCallback(); // 失敗したら前の画面に戻る
                    }
                }
            }
        });
}

world.afterEvents.worldLoad.subscribe(() => {
    lreload();
});
