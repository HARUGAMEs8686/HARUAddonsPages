import { world, system } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';

// ダイナミックプロパティに保存する際のIDを変更
const BORDER_SIZES_PROPERTY_ID = 'worldborder:sizes'; // オブジェクトを保存するためID名を変更
const OP_PROPERTY_ID = 'worldborder:op';
// 境界を超えた場合に少し戻す座標のマージン
const SAFE_MARGIN = 0.5;
// この距離だけ境界の外に出たらテレポートしない
const TELEPORT_BUFFER = 5.0;

// 現在の境界値をディメンションごとに保持する変数
let currentBorderSizes;

let currentOPLimit;

/**
 * 座標が境界内にあるかチェックし、範囲外なら修正した座標を返す関数
 * @param {number} x - プレイヤーのX座標
 * @param {number} z - プレイヤーのZ座標
 * @param {number} borderSize - このディメンションでの境界サイズ
 * @returns {{x: number, z: number} | null} - 修正後の座標、または修正不要ならnull
 */
function getClampedCoordinates(x, z, borderSize) {
    let clampedX = x;
    let clampedZ = z;
    let needsTeleport = false;

    if (x > borderSize && x <= borderSize + TELEPORT_BUFFER) {
        clampedX = borderSize - SAFE_MARGIN;
        needsTeleport = true;
    } else if (x < -borderSize && x >= -borderSize - TELEPORT_BUFFER) {
        clampedX = -borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    if (z > borderSize && z <= borderSize + TELEPORT_BUFFER) {
        clampedZ = borderSize - SAFE_MARGIN;
        needsTeleport = true;
    } else if (z < -borderSize && z >= -borderSize - TELEPORT_BUFFER) {
        clampedZ = -borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    if (needsTeleport) {
        return { x: clampedX, z: clampedZ };
    }
    return null;
}

// 5ティック（0.25秒）ごとにプレイヤーの座標をチェックする処理
system.runInterval(() => {
    if (typeof currentBorderSizes === 'undefined') return;

    for (const player of world.getAllPlayers()) {
        const dimensionId = player.dimension.id.split(':')[1]; // "overworld", "nether", "the_end"
        const borderSize = currentBorderSizes[dimensionId];
        if (typeof borderSize === 'undefined') {
            continue;
        }

        const location = player.location;
        const clampedCoords = getClampedCoordinates(location.x, location.z, borderSize);

        if (clampedCoords) {
            if (!player.hasTag('WorldorderOP') || (player.hasTag('WorldorderOP') && !currentOPLimit)) {
                player.teleport({ x: clampedCoords.x, y: location.y, z: clampedCoords.z }, { rotation: { x: player.getRotation().x, y: player.getRotation().y } });
                player.onScreenDisplay.setActionBar('§c世界の果てに到達した');
            }
        } else {
            const isOutsideBorder = Math.abs(location.x) > borderSize || Math.abs(location.z) > borderSize;

            if (isOutsideBorder) {
                player.onScreenDisplay.setActionBar('§e制限範囲内に戻ると制限が有効になります');
            }
        }
    }
}, 5);

//スクリプトイベント
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'worldborder:s' && eventData.sourceEntity) {
        const player = eventData.sourceEntity;
        if (!player.hasTag('WorldorderOP')) {
            player.sendMessage(`[§bシステム§r] §a設定を行うにはOPタグが必要です\n §r>>> §eWorldorderOP`);
            return;
        }

        const form = new ModalFormData().title('§1ワールドボーダー設定').textField('オーバーワールドの範囲', '10以上の数値を入力', `${currentBorderSizes.overworld}`).textField('ネザーの範囲', '10以上の数値を入力', `${currentBorderSizes.nether}`).textField('エンドの範囲', '10以上の数値を入力', `${currentBorderSizes.the_end}`);

        form.toggle('OP無制限', currentOPLimit);

        form.show(player).then(response => {
            if (response.canceled) return;

            const [newOverworldSizeStr, newNetherSizeStr, newEndSizeStr] = response.formValues;
            const newOPLimit = response.formValues[3];

            const newOverworldSize = Number(newOverworldSizeStr);
            const newNetherSize = Number(newNetherSizeStr);
            const newEndSize = Number(newEndSizeStr);

            // 有効な数値かチェック
            if (isNaN(newOverworldSize) || newOverworldSize <= 0 || isNaN(newNetherSize) || newNetherSize <= 0 || isNaN(newEndSize) || newEndSize <= 0) {
                player.sendMessage('§cエラー: 全ての範囲に正の数値を指定してください。');
                return;
            }

            const newSizes = {
                overworld: newOverworldSize,
                nether: newNetherSize,
                the_end: newEndSize,
            };

            // ダイナミックプロパティに新しい値をJSON文字列として保存
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(newSizes));
            world.setDynamicProperty(OP_PROPERTY_ID, newOPLimit);

            // 実行中の変数を更新
            currentBorderSizes = newSizes;
            currentOPLimit = newOPLimit;

            player.sendMessage(`[§bシステム§r] §aワールドボーダー設定を更新しました`);
        });
    }
});

// ワールド読み込み
system.run(() => {
    const OLD_BORDER_PROPERTY_ID = 'worldborder:size'; // データ移行元（旧バージョン）のID
    const savedOldBorderSize = world.getDynamicProperty(OLD_BORDER_PROPERTY_ID);
    const savedSizesJSON = world.getDynamicProperty(BORDER_SIZES_PROPERTY_ID);

    if (savedSizesJSON === undefined) {
        // 新しい形式のデータがまだない場合
        if (savedOldBorderSize !== undefined) {
            const migratedSizes = {
                overworld: savedOldBorderSize, // 古い設定値をオーバーワールドに設定
                nether: savedOldBorderSize / 2, // ネザーは半分の値をデフォルトとして設定
                the_end: savedOldBorderSize * 2, // ジ・エンドは2倍の値をデフォルトとして設定
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(migratedSizes));
            currentBorderSizes = migratedSizes;

            world.setDynamicProperty(OLD_BORDER_PROPERTY_ID, undefined);
        } else {
            const defaultSizes = {
                overworld: 1000,
                nether: 500,
                the_end: 2000,
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(defaultSizes));
            currentBorderSizes = defaultSizes;
        }
    } else {
        // 新しい形式のデータが既に存在する場合は、それを読み込む
        currentBorderSizes = JSON.parse(savedSizesJSON);
    }

    const savedOPLimit = world.getDynamicProperty(OP_PROPERTY_ID);
    if (savedOPLimit === undefined) {
        world.setDynamicProperty(OP_PROPERTY_ID, false);
        currentOPLimit = false;
    } else {
        currentOPLimit = savedOPLimit;
    }
});
