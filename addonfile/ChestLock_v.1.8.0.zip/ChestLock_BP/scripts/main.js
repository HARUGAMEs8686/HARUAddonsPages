import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

const RACE_EVENT_ID = 'haruapps:chestlock';
const MESSAGE_COOLDOWN = 60; // 3秒（20tick/秒 × 3）
const playerLastMessage = new Map(); // プレイヤーごとの最終メッセージ時刻

// チェスト管理モードのプレイヤー管理 (インタラクトで指定用)
const manageMode = new Set();

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            showChestLockForm(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    if (eventData.itemStack.typeId === 'additem:chestlock') {
        if (registerMode.has(player.name) || manageMode.has(player.name)) {
            // manageModeも追加
            eventData.cancel = true;
            return;
        }
        system.run(() => {
            showChestLockForm(player);
        });
    }
});

world.beforeEvents.chatSend.subscribe(event => {
    const player = event.sender;
    const message = event.message;

    if (message == '!icl') {
        event.cancel = true;
        system.run(() => {
            player.getComponent('inventory').container.addItem(new ItemStack('additem:chestlock', 1));
            player.sendMessage('§r[§bChest Lock§r] §aChestLockアイテムを付与しました。');
        });
    }
});

// 保護対象のブロックタイプ
const protectableBlocks = [
    'minecraft:chest',
    'minecraft:barrel',
    'minecraft:undyed_shulker_box',
    'minecraft:white_shulker_box',
    'minecraft:orange_shulker_box',
    'minecraft:magenta_shulker_box',
    'minecraft:light_blue_shulker_box',
    'minecraft:yellow_shulker_box',
    'minecraft:lime_shulker_box',
    'minecraft:pink_shulker_box',
    'minecraft:gray_shulker_box',
    'minecraft:silver_shulker_box',
    'minecraft:cyan_shulker_box',
    'minecraft:purple_shulker_box',
    'minecraft:blue_shulker_box',
    'minecraft:brown_shulker_box',
    'minecraft:green_shulker_box',
    'minecraft:red_shulker_box',
    'minecraft:black_shulker_box',
];

// 禁止するブロックタイプ
const restrictedBlocks = ['minecraft:hopper', 'minecraft:dispenser', 'minecraft:dropper'];

// チェスト登録モードのプレイヤー管理
const registerMode = new Set();

// 向きの一致度閾値（0～100%）。この値以上で設置禁止
const MATCH_THRESHOLD = 1;

// 保護チェストデータの保存
function saveChestData(x, y, z, data) {
    const key = `chest_${x}_${y}_${z}`;
    try {
        world.setDynamicProperty(key, JSON.stringify(data));
    } catch (e) {
        console.error(`Failed to save chest data at ${key}: ${e}`);
    }
}

// 保護チェストデータの取得
function getChestData(x, y, z, dimension) {
    const key = `chest_${x}_${y}_${z}`;
    try {
        const data = world.getDynamicProperty(key);
        if (data) return JSON.parse(data);
        const neighbors = [
            { x: x + 1, y, z },
            { x: x - 1, y, z },
            { x, y, z: z + 1 },
            { x, y, z: z - 1 },
        ];
        for (const pos of neighbors) {
            const neighborKey = `chest_${pos.x}_${pos.y}_${pos.z}`;
            const neighborData = world.getDynamicProperty(neighborKey);
            if (neighborData) {
                const block = dimension.getBlock(pos);
                if (block && protectableBlocks.includes(block.typeId)) {
                    // protectableBlocks を使用
                    return JSON.parse(neighborData);
                }
            }
        }
        return null;
    } catch (e) {
        console.error(`Failed to load chest data at ${key}: ${e}`);
        return null;
    }
}

// 保護チェストデータの削除
function deleteChestData(x, y, z, dimension) {
    const key = `chest_${x}_${y}_${z}`;
    try {
        world.setDynamicProperty(key, undefined);
        const neighbors = [
            { x: x + 1, y, z },
            { x: x - 1, y, z },
            { x, y, z: z + 1 },
            { x, y, z: z - 1 },
        ];
        for (const pos of neighbors) {
            const neighborKey = `chest_${pos.x}_${pos.y}_${pos.z}`;
            world.setDynamicProperty(neighborKey, undefined);
        }
    } catch (e) {
        console.error(`Failed to delete chest data at ${key}: ${e}`);
    }
}

// メッセージ送信（クールダウン付き）
function sendMessageWithCooldown(player, message, soundOptions) {
    const currentTick = system.currentTick;
    const lastMessageTick = playerLastMessage.get(player.name) || 0;
    if (currentTick - lastMessageTick >= MESSAGE_COOLDOWN) {
        player.sendMessage(message);
        if (soundOptions) {
            system.run(() => {
                player.playSound(soundOptions.sound, { pitch: soundOptions.pitch, volume: soundOptions.volume });
            });
        }
        playerLastMessage.set(player.name, currentTick);
    }
}

// アクションフォームを表示
export function showChestLockForm(player) {
    const form = new ActionFormData().title('§1ChestLock').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§4保護チェスト登録', 'textures/ui/bubble_empty').button('§5チェスト管理', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            player.runCommand('scriptevent haruphone1:apps');
        } else if (response.selection === 1) {
            registerMode.add(player.name);
            player.sendMessage(`§r[§bChest Lock§r] §a収納ブロック(チェスト)をインタラクトして保護登録してください。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            });
        } else if (response.selection === 2) {
            showChestManagementSelectionForm(player); // 新しいチェスト管理選択フォームへ
        }
    });
}

// チェスト管理方法選択フォーム
function showChestManagementSelectionForm(player) {
    const form = new ActionFormData().title('§1保護チェスト管理').body('§e管理するチェストの指定方法を選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1インタラクトで指定', 'textures/ui/bubble_empty').button('§5チェスト一覧から指定', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showChestLockForm(player); // 戻る
        } else if (response.selection === 1) {
            // インタラクトで指定モード
            manageMode.add(player.name);
            player.sendMessage(`§r[§bChest Lock§r] §a管理したい収納ブロック(チェスト)をインタラクトしてください。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            });
        } else if (response.selection === 2) {
            // チェスト一覧から指定モード
            showShareChestForm(player);
        }
    });
}

// 共有チェスト選択フォーム (既存のチェスト一覧から指定)
function showShareChestForm(player) {
    const form = new ActionFormData().title('§1保護チェスト管理').body('§e操作したいチェストを選択してください。').button(`§l戻る`, 'textures/ui/icon_import.png');

    const ownedChests = [];
    const allProperties = world.getDynamicPropertyIds();
    const processedLocations = new Set();

    for (const key of allProperties) {
        if (key.startsWith('chest_')) {
            const data = world.getDynamicProperty(key);
            if (data) {
                const parsed = JSON.parse(data);
                if (parsed.owner === player.name) {
                    const coords = key.replace('chest_', '').split('_').map(Number);
                    const baseKey = `chest_${coords[0]}_${coords[1]}_${coords[2]}`;
                    if (!processedLocations.has(baseKey)) {
                        processedLocations.add(baseKey);
                        ownedChests.push({ key: baseKey, coords: coords.join(', ') });
                        form.button(`§4チェスト§0: §1${coords.join(', ')}`, 'textures/ui/bubble_empty');
                    }
                }
            }
        }
    }

    if (ownedChests.length === 0) {
        player.sendMessage(`§r[§bChest Lock§r] §cあなたが所有する保護チェストはありません。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        });
        return; // フォームを表示せずに終了
    }

    form.show(player).then(response => {
        if (response.canceled || response.selection == null) return;
        if (response.selection === 0) {
            showChestManagementSelectionForm(player); // 戻る
            return;
        }

        const selectedChest = ownedChests[response.selection - 1];
        showChestManagementForm(player, selectedChest.key, selectedChest.coords);
    });
}

// チェスト管理フォーム（共有プレイヤーの管理、保護解除）
function showChestManagementForm(player, chestKey, coords) {
    const form = new ActionFormData()
        .title('§1チェスト管理')
        .body(`>>>§eチェスト§a(${coords})\n§c選択してください`)
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1共有プレイヤーの管理', 'textures/ui/bubble_empty') // 共有プレイヤーの管理ボタン
        .button('§4保護解除', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled || response.selection == null) return;

        if (response.selection === 1) {
            showSharedPlayerManagementOptions(player, chestKey, coords); // 共有プレイヤー管理オプションへ
        } else if (response.selection === 2) {
            confirmUnprotectChest(player, chestKey, coords);
        } else if (response.selection === 0) {
            showChestManagementSelectionForm(player); // 戻る
        }
    });
}

// 共有プレイヤー管理オプションフォーム
function showSharedPlayerManagementOptions(player, chestKey, coords) {
    const form = new ActionFormData().title('§1共有プレイヤー管理').body(`>>>§eチェスト§a(${coords})\n§c選択してください`).button(`§l戻る`, 'textures/ui/icon_import.png').button('§1共有プレイヤー追加', 'textures/ui/bubble_empty').button('§5共有プレイヤー削除', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled || response.selection == null) return;

        if (response.selection === 1) {
            showPlayerSelectionForm(player, chestKey, coords); // 共有プレイヤー追加
        } else if (response.selection === 2) {
            showRemoveSharedPlayerForm(player, chestKey, coords); // 共有プレイヤー削除
        } else if (response.selection === 0) {
            showChestManagementForm(player, chestKey, coords); // 戻る
        }
    });
}

// プレイヤー選択フォーム（自分を除外）
function showPlayerSelectionForm(player, chestKey, coords) {
    const otherPlayers = world
        .getAllPlayers()
        .filter(p => p.name !== player.name)
        .map(p => p.name);
    if (otherPlayers.length === 0) {
        player.sendMessage(`§r[§bChest Lock§r] §c共有可能なオンラインプレイヤーがいません。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        });
        showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
        return;
    }

    const form = new ModalFormData().title('§1プレイヤー選択').dropdown('§e共有するプレイヤーを選択:', otherPlayers);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
            return;
        }

        const selectedPlayerName = otherPlayers[response.formValues[0]];
        const data = world.getDynamicProperty(chestKey);
        if (!data) {
            player.sendMessage(`§r[§bChest Lock§r] §cチェストデータが見つかりません。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            });
            showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
            return;
        }

        const chestData = JSON.parse(data);
        if (!chestData.shared) chestData.shared = [];
        if (!chestData.shared.includes(selectedPlayerName)) {
            chestData.shared.push(selectedPlayerName);
            saveChestData(...chestKey.replace('chest_', '').split('_').map(Number), chestData);
            player.sendMessage(`§r[§bChest Lock§r] §aチェストを${selectedPlayerName}と共有しました。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            });
        } else {
            player.sendMessage(`§r[§bChest Lock§r] §cこのプレイヤーはすでに共有されています。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            });
        }
        showSharedPlayerManagementOptions(player, chestKey, coords); // 処理後も共有プレイヤー管理オプションに戻る
    });
}

function showRemoveSharedPlayerForm(player, chestKey, coords) {
    const chestData = world.getDynamicProperty(chestKey);
    if (!chestData) {
        player.sendMessage(`§r[§bChest Lock§r] §cチェストデータが見つかりません。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        });
        showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
        return;
    }

    const parsedData = JSON.parse(chestData);
    const sharedPlayers = parsedData.shared || [];
    if (sharedPlayers.length === 0) {
        player.sendMessage(`§r[§bChest Lock§r] §cこのチェストに共有プレイヤーはいません。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        });
        showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
        return;
    }

    const form = new ModalFormData().title('§1共有プレイヤー削除').dropdown('§e削除するプレイヤーを選択:', sharedPlayers);

    form.show(player).then(response => {
        if (response.canceled || !response.formValues) {
            showSharedPlayerManagementOptions(player, chestKey, coords); // 戻る
            return;
        }

        const selectedPlayer = sharedPlayers[response.formValues[0]];
        parsedData.shared = parsedData.shared.filter(name => name !== selectedPlayer);
        saveChestData(...chestKey.replace('chest_', '').split('_').map(Number), parsedData);
        player.sendMessage(`§r[§bChest Lock§r] §a${selectedPlayer}を共有リストから削除しました。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
        });
        showSharedPlayerManagementOptions(player, chestKey, coords); // 処理後も共有プレイヤー管理オプションに戻る
    });
}

function confirmUnprotectChest(player, chestKey, coords) {
    const form = new MessageFormData().title('§1保護解除確認').body(`§eチェスト(${coords})の保護を解除しますか？\n§cこの操作は元に戻せません。`).button1('§1いいえ').button2('§5はい');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showChestManagementForm(player, chestKey, coords); // 戻る
            return;
        }

        if (response.selection === 1) {
            deleteChestData(...chestKey.replace('chest_', '').split('_').map(Number));
            player.sendMessage(`§r[§bChest Lock§r] §aチェスト(${coords})の保護を解除しました。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            });
            showChestManagementSelectionForm(player); // 保護解除後はチェスト管理選択フォームに戻る
        }
    });
}

// チェスト登録処理
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;

    // 登録モード
    if (registerMode.has(player.name)) {
        if (protectableBlocks.includes(block.typeId)) {
            const baseLocation = getChestBaseLocation(block);
            const { x, y, z } = baseLocation;
            const existingData = getChestData(x, y, z, block.dimension);

            if (existingData) {
                player.sendMessage(`§r[§bChest Lock§r] §cこのチェストはすでに保護されています。`);
                system.run(() => {
                    player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                });
                registerMode.delete(player.name);
                event.cancel = true;
                return;
            }

            saveChestData(x, y, z, { owner: player.name, shared: [] });

            player.sendMessage(`§r[§bChest Lock§r] §aチェスト(${x}, ${y}, ${z})を保護登録しました。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
            });
            registerMode.delete(player.name);
            event.cancel = true;
        } else {
            player.sendMessage(`§r[§bChest Lock§r] §c保護対象外のブロックをインタラクトしたため、登録モードを解除しました。`);
            system.run(() => {
                player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            });
            registerMode.delete(player.name);
            event.cancel = true;
        }
    }

    // チェスト管理モード (インタラクトで指定)
    if (manageMode.has(player.name)) {
        if (protectableBlocks.includes(block.typeId)) {
            const baseLocation = getChestBaseLocation(block);
            const { x, y, z } = baseLocation;
            const chestData = getChestData(x, y, z, block.dimension);

            if (chestData && chestData.owner === player.name) {
                system.run(() => {
                    // プレイヤーが所有するチェストであれば管理フォームを表示
                    showChestManagementForm(player, `chest_${x}_${y}_${z}`, `${x}, ${y}, ${z}`);
                });
            } else {
                sendMessageWithCooldown(player, `§r[§bChest Lock§r] §cこのチェストはあなたの保護チェストではありません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
            }
        } else {
            sendMessageWithCooldown(player, `§r[§bChest Lock§r] §c収納ブロック(チェスト)をインタラクトしてください。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
        }
        manageMode.delete(player.name); // インタラクト後はモードを解除
        event.cancel = true;
    }
});

// チェスト保護（アクセス制限）
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;
    if (!protectableBlocks.includes(block.typeId)) return;

    // 登録モードや管理モードの場合は処理をスキップ
    if (registerMode.has(player.name) || manageMode.has(player.name)) return;

    const baseLocation = getChestBaseLocation(block);
    const { x, y, z } = baseLocation;
    const chestData = getChestData(x, y, z, block.dimension);
    if (!chestData) return;

    if (player.hasTag('ChestOP')) return;

    if (chestData.owner !== player.name && !chestData.shared?.includes(player.name)) {
        sendMessageWithCooldown(player, `§r[§bChest Lock§r] §cこのチェストは保護されており、アクセスできません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
        event.cancel = true;
    }
});

// チェスト破壊保護
world.beforeEvents.playerBreakBlock.subscribe(event => {
    const { player, block } = event;
    if (!protectableBlocks.includes(block.typeId)) return;

    const baseLocation = getChestBaseLocation(block);
    const { x, y, z } = baseLocation;
    const chestData = getChestData(x, y, z, block.dimension);
    if (!chestData) return;

    if (player.hasTag('ChestOP')) {
        deleteChestData(x, y, z, block.dimension);
        player.sendMessage(`§r[§bChest Lock§r] §aチェスト(${x}, ${y}, ${z})の保護を解除しました（ChestOP）。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
        });
        return;
    }

    if (chestData.owner !== player.name && !chestData.shared?.includes(player.name)) {
        sendMessageWithCooldown(player, `§r[§bChest Lock§r] §cこのチェストは保護されており、破壊できません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
        event.cancel = true;
    } else {
        deleteChestData(x, y, z, block.dimension);
        player.sendMessage(`§r[§bChest Lock§r] §aチェスト(${x}, ${y}, ${z})の保護を解除しました。`);
        system.run(() => {
            player.playSound('random.toast', { pitch: 1.7, volume: 1.0 });
        });
    }
});

// 爆発によるチェスト破壊保護
world.beforeEvents.explosion.subscribe(event => {
    const impactedBlocks = event.getImpactedBlocks();
    const filteredBlocks = impactedBlocks.filter(block => {
        if (protectableBlocks.includes(block.typeId)) {
            const baseLocation = getChestBaseLocation(block);
            const chestData = getChestData(baseLocation.x, baseLocation.y, baseLocation.z, block.dimension);
            return !chestData; // 保護されているチェストは除外
        }
        return true; // 保護されていないブロックはそのまま
    });
    event.setImpactedBlocks(filteredBlocks);
});

// 周辺ブロック設置制限
world.beforeEvents.playerPlaceBlock.subscribe(event => {
    const { player, block, permutationToPlace } = event;
    const placedBlockType = permutationToPlace.type.id;

    // --- 既存の隣接ブロック設置制限ロジック ---
    if (restrictedBlocks.includes(placedBlockType)) {
        const { x, y, z } = block.location;
        const nearby = [
            { x: x + 1, y, z },
            { x: x - 1, y, z },
            { x, y: y + 1, z },
            { x, y: y - 1, z },
            { x, y, z: z + 1 },
            { x, y, z: z - 1 },
        ];

        for (const pos of nearby) {
            const nearbyBlock = block.dimension.getBlock(pos);
            if (nearbyBlock && protectableBlocks.includes(nearbyBlock.typeId)) {
                const baseLocation = getChestBaseLocation(nearbyBlock);
                const chestData = getChestData(baseLocation.x, baseLocation.y, baseLocation.z, block.dimension);
                if (chestData) {
                    sendMessageWithCooldown(player, `§r[§bChest Lock§r] §c保護チェストの近くにこのブロックは設置できません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
                    event.cancel = true;
                    return;
                }
            }
        }
    }

    if (placedBlockType === 'minecraft:piston' || placedBlockType === 'minecraft:sticky_piston') {
        const { x: placeX, y: placeY, z: placeZ } = block.location;
        const searchRange = 14;
        const bufferRange = 1; // 十字の太さを定義（例: 1マス）

        const allProperties = world.getDynamicPropertyIds();
        for (const key of allProperties) {
            if (key.startsWith('chest_')) {
                const data = world.getDynamicProperty(key);
                if (data) {
                    const [chestX, chestY, chestZ] = key.replace('chest_', '').split('_').map(Number);

                    // 設置場所と保護チェストの各軸の距離を計算
                    const dx = Math.abs(placeX - chestX);
                    const dy = Math.abs(placeY - chestY);
                    const dz = Math.abs(placeZ - chestZ);

                    // 設置場所が「太い十字」範囲内にあるかチェック
                    const isWithinThickCross =
                        (dx <= searchRange && dy <= bufferRange && dz <= bufferRange) || // X軸方向
                        (dx <= bufferRange && dy <= searchRange && dz <= bufferRange) || // Y軸方向
                        (dx <= bufferRange && dy <= bufferRange && dz <= searchRange); // Z軸方向

                    if (isWithinThickCross) {
                        sendMessageWithCooldown(player, `§r[§bChest Lock§r] §c保護チェストの近くにピストンは設置できません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
                        event.cancel = true;
                        return;
                    }
                }
            }
        }
    }
});

//ホッパートロッコの対策
world.beforeEvents.playerPlaceBlock.subscribe(event => {
    const { player, permutationToPlace } = event;
    const placedBlockType = permutationToPlace.type.id;
    const isRail = placedBlockType.includes('rail'); // 線路かどうかを判定

    // 線路ブロックでない場合はスキップ
    if (!isRail) return;

    const { x: placeX, y: placeY, z: placeZ } = event.block.location;
    const searchRange = 3;

    // すべての保護チェストの座標をループで取得
    const allProperties = world.getDynamicPropertyIds();
    for (const key of allProperties) {
        if (key.startsWith('chest_')) {
            const data = world.getDynamicProperty(key);
            if (data) {
                const [chestX, chestY, chestZ] = key.replace('chest_', '').split('_').map(Number);

                // 保護チェストからの距離を計算
                const distanceX = Math.abs(placeX - chestX);
                const distanceY = Math.abs(placeY - chestY);
                const distanceZ = Math.abs(placeZ - chestZ);

                // 各軸の距離が3マス以内かチェック
                if (distanceX <= searchRange && distanceY <= searchRange && distanceZ <= searchRange) {
                    // 3マス以内に保護チェストがあれば設置をキャンセル
                    event.cancel = true;
                    sendMessageWithCooldown(player, `§r[§bChest Lock§r] §c保護チェストの近くに線路は設置できません。`, { sound: 'random.toast', pitch: 0.4, volume: 1.0 });
                    return; // 処理を終了
                }
            }
        }
    }
});

// 5ティック（約0.25秒）ごとに実行
system.runInterval(() => {
    // 保護チェストが存在しない場合はスキップ
    const allProperties = world.getDynamicPropertyIds();
    const chestProperties = allProperties.filter(key => key.startsWith('chest_'));
    if (chestProperties.length === 0) return;

    const dimensions = [world.getDimension('overworld'), world.getDimension('nether'), world.getDimension('the_end')];
    for (const dimension of dimensions) {
        const hopperMinecarts = dimension.getEntities({ type: 'minecraft:hopper_minecart' });
        if (hopperMinecarts.length === 0) continue;
        for (const minecart of hopperMinecarts) {
            const { x: minecartX, y: minecartY, z: minecartZ } = minecart.location;
            const searchRange = 3;

            for (const key of chestProperties) {
                const data = world.getDynamicProperty(key);
                if (data) {
                    const [chestX, chestY, chestZ] = key.replace('chest_', '').split('_').map(Number);

                    const distanceX = Math.abs(minecartX - chestX);
                    const distanceY = Math.abs(minecartY - chestY);
                    const distanceZ = Math.abs(minecartZ - chestZ);

                    // 各軸の距離が3マス以内かチェック
                    if (distanceX <= searchRange && distanceY <= searchRange && distanceZ <= searchRange) {
                        // 保護チェストの近くであればキル
                        minecart.kill();
                        break; // 近くにチェストが1つでも見つかったら、次のトロッコへ
                    }
                }
            }
        }
    }
}, 5);

// ダブルチェストの基準座標を取得
function getChestBaseLocation(block) {
    const { x, y, z } = block.location;
    const dimension = block.dimension;

    const neighbors = [
        { x: x + 1, y, z },
        { x: x - 1, y, z },
        { x, y, z: z + 1 },
        { x, y, z: z - 1 },
    ];

    for (const pos of neighbors) {
        const neighborBlock = dimension.getBlock(pos);
        if (neighborBlock && protectableBlocks.includes(neighborBlock.typeId)) {
            // protectableBlocks を使用
            return {
                x: Math.min(x, pos.x),
                y,
                z: Math.min(z, pos.z),
            };
        }
    }
    return { x, y, z };
}
