import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

//アイテム実行
import { HARUPhone1 } from './itemrun/haruphone1.js';
import { Advance } from './itemrun/advance.js';

//ブロック実行
import { Game } from './blockrun/game.js';
import { Atm } from './blockrun/atm.js';
import { Register } from './blockrun/register.js';
import { Post } from './itemrun/post.js';

//常時実行
import { systemrun } from './systemrun.js';

//ダメージ発生時実行
import { entityPOINT } from './EntityPOINT.js';

//自動販売機
import { registerShopInteractions, handleShopInteraction } from './blockrun/penjualan.js';

//ブロック
world.beforeEvents.playerInteractWithBlock.subscribe(eventData => {
    const player = eventData.player;
    
    if (eventData.block.typeId === 'addblock:game') {
        Game(eventData);
    }

    if (eventData.block.typeId === 'addblock:register') {
        Register(eventData);
    }

    if (eventData.block.typeId === 'addblock:atm') {
        Atm(eventData);
    }
});

//アイテム
world.beforeEvents.itemUse.subscribe(eventData => {
    const player = eventData.source;
    if (eventData.itemStack.typeId === 'additem:haruphone1') {
        HARUPhone1(player);
    }
    if (eventData.itemStack.typeId === 'additem:advance') {
        Advance(player);
    }
    if (eventData.itemStack.typeId === 'additem:post') {
        Post(player);
    }
});

//ダメージ
world.afterEvents.entityHurt.subscribe(event => {
    entityPOINT(event);
});

//常時
system.runInterval(() => {
    systemrun();
});

//初期設定 >>>
//UI設定
const HARUPhone1_AppNumber = [1, 3, 4, 5, 6, 7, 9, 10, 12, 14, 16, 13, 11, 17];

//HARUPAY
if (world.getDynamicProperty('harupay_op_money') == undefined) {
    world.setDynamicProperty('harupay_op_money', 0);
}
if (world.getDynamicProperty('MoneyList_allow') == undefined) {
    world.setDynamicProperty('MoneyList_allow', true);
}
//QuickSAVE
if (world.getDynamicProperty('Quick_DataSAVE') == undefined) {
    world.setDynamicProperty('Quick_DataSAVE', false);
}
//Quick初期化
if (world.getDynamicProperty('Quick_DataSAVE') == false) {
    world.setDynamicProperty('shop_menu', undefined);
}
//AppNumber
if (world.getDynamicProperty('HARUPhone1_AppNumber') == undefined) {
    world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber));
}

//UI修正
import { config } from './config.js';

var HARUPhone1_AppNumber_Data = JSON.parse(world.getDynamicProperty('HARUPhone1_AppNumber'));
var Check = false;

for (let i = 0; i < HARUPhone1_AppNumber_Data.length; i++) {
    if (config.AppData[HARUPhone1_AppNumber_Data[i]] == 'Operator Controller') {
        Check = true;
    }
}

if (Check == false) {
    console.warn('[§bHARUPhone1§r] §cHARUPhone1UIをアップデートしています');
    console.warn('[§bHARUPhone1§r] §aデータをアップデートしました');
    HARUPhone1_AppNumber_Data.push(config.AppData.length - 1);
    world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber_Data));
}

//MoneyItems
if (world.getDynamicProperty('MoneyItems_score') == undefined) {
    const MoneyItems_score = [0, 0, 0, 0, 0, 0, 0, 0];
    world.setDynamicProperty('MoneyItems_score', JSON.stringify(MoneyItems_score));
}
//browser初期マネー
if (world.getDynamicProperty('browser_newpage_money') == undefined) {
    world.setDynamicProperty('browser_newpage_money', 0);
}
if (world.getDynamicProperty('browser_performance_money') == undefined) {
    world.setDynamicProperty('browser_performance_money', 0);
}
//社会システム関連
if (world.getDynamicProperty('WorldgroupName') == undefined) {
    world.setDynamicProperty('WorldgroupName', '国');
}
if (world.getDynamicProperty('DANGEROUS_ITEMS') == undefined) {
    const DANGEROUS_ITEMS = ['additem:haruphone1', 'additem:advance'];
    world.setDynamicProperty('DANGEROUS_ITEMS', JSON.stringify(DANGEROUS_ITEMS));
}

if (world.getDynamicProperty('WorldspaceNAME') == undefined) {
    world.setDynamicProperty('WorldspaceNAME', '無主の地');
}

if (world.getDynamicProperty('WorldTitle') == undefined) {
    world.setDynamicProperty('WorldTitle', true);
}

const UNOWNED_LAND_INTERACTION = 'unowned_land_interaction';
if (world.getDynamicProperty(UNOWNED_LAND_INTERACTION) == undefined) {
    world.setDynamicProperty(UNOWNED_LAND_INTERACTION, true);
}
const MONEY_OBJECTIVE = 'money';
const CHUNK_PRICE_PROPERTY = 'chunk_price';
const SYSTEM_ENABLED_PROPERTY = 'nation_system_enabled';
const NATION_CREATION_COST_PROPERTY = 'nation_creation_cost';
const ALLOW_MULTIPLE_NATIONS_PROPERTY = 'allow_multiple_nations';
const MAX_PURCHASE_CHUNKS_PROPERTY = 'max_purchase_chunks';
const CHUNK_SELL_PRICE_PROPERTY = 'chunk_sell_price';
if (!world.scoreboard.getObjective(MONEY_OBJECTIVE)) {
    world.scoreboard.addObjective(MONEY_OBJECTIVE, 'money');
}
if (world.getDynamicProperty(CHUNK_PRICE_PROPERTY) == undefined) {
    world.setDynamicProperty(CHUNK_PRICE_PROPERTY, 100);
}
if (world.getDynamicProperty(NATION_CREATION_COST_PROPERTY) == undefined) {
    world.setDynamicProperty(NATION_CREATION_COST_PROPERTY, 500);
}
if (world.getDynamicProperty(SYSTEM_ENABLED_PROPERTY) === undefined) {
    world.setDynamicProperty(SYSTEM_ENABLED_PROPERTY, false);
}
if (world.getDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY) === undefined) {
    world.setDynamicProperty(ALLOW_MULTIPLE_NATIONS_PROPERTY, false);
}
if(world.getDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY) === undefined){
    world.setDynamicProperty(MAX_PURCHASE_CHUNKS_PROPERTY,10)
}
if(world.getDynamicProperty(CHUNK_SELL_PRICE_PROPERTY) === undefined){
    world.setDynamicProperty(CHUNK_SELL_PRICE_PROPERTY, 50)
}

//GAME関連
if (world.getDynamicProperty('MULTIPLIER') == undefined) {
    world.setDynamicProperty('MULTIPLIER', 1);
}
if (world.getDynamicProperty('TOTAL_LETTERS') == undefined) {
    world.setDynamicProperty('TOTAL_LETTERS', 4);
}
if (world.getDynamicProperty('WINNING_COUNT') == undefined) {
    world.setDynamicProperty('WINNING_COUNT', 1);
}
if (world.getDynamicProperty('BET_AMOUNTS') == undefined) {
    world.setDynamicProperty('BET_AMOUNTS', '10,100,1000');
}

//時刻
if (world.getDynamicProperty('Time_Setting') == undefined) {
    world.setDynamicProperty('Time_Setting', 9);
}

//OPMONEY
const settings = { browser: true, socialSystem: true, post: true };
if (world.getDynamicProperty('harupay_op_settings') == undefined) {
    world.setDynamicProperty('harupay_op_settings', JSON.stringify(settings));
}
//<<<

//scriptEvents実行
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'killcount:off') {
            world.setDynamicProperty('killPointSystem', false);
        }
        if (eventData.id === 'killcount:on') {
            world.setDynamicProperty('killPointSystem', true);
        }
        if (eventData.id === 'ui:reset') {
            world.setDynamicProperty('HARUPhone1_AppNumber', JSON.stringify(HARUPhone1_AppNumber));
            player.sendMessage(`§r[§bシステム§r] §aUIをリセットしました`);
            player.playSound('random.toast', {
                pitch: 1.6,
                volume: 1.0,
            });
            HARUPhone1(player);
        }
    });
});

//自動販売機
registerShopInteractions();
