import { world, system } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from '../config';
import { HARU_XEditor_LiteFrame_NewApp } from '../HARU-XEditor/LiteFrame/NewApp';
import { LiteFrame_editor } from '../HARU-XEditor/LiteFrame/editor/LiteFrame_editor';
import { Operator_Controller } from '../system/Operator_Controller';

var player_Cash_Data = {};
export function HARU_XEditor(player) {
    system.run(() => {
        if (!player.hasTag('HARUPhoneOP')) {
            player.sendMessage(`§r[§bHARU-XEditor§r] §4管理者のみ利用できます`);
            player.playSound('random.toast', {
                pitch: 0.6,
                volume: 1.0,
            });
            return;
        }

        //MyAPP取得
        var MY_AppData = player.getDynamicProperty(`MY_AppData`);
        if (MY_AppData == undefined) {
            var MY_AppData = [];
        } else {
            var MY_AppData = JSON.parse(MY_AppData);
        }

        //時刻を取得
        const now = new Date();
        const japanTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        var time = `${hours}:${minutes}`;
        var form = new ActionFormData();
        form.title(`${config['main'][0]}`);
        form.body(`§l§b${time}\n§r§a>>>§rHARU-XEditor`);
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
        form.button(`§5新規作成`);
        for (let i = 0; i < MY_AppData.length; i++) {
            form.button(`§1${MY_AppData[i][0]}`);
        }
        form.show(player).then(r => {
            if (r.canceled) return;
            if (r.selection == 0) {
                Operator_Controller(player);
                return;
            }
            if (r.selection == 1) {
                HARU_XEditor_NewApp(player, time);
                return;
            }
            const target = MY_AppData[r.selection - 2][1];
            const LiteFrame = ['LiteFrameA', 'LiteFrameB', 'LiteFrameC', 'LiteFrameD'];

            if (LiteFrame.includes(target)) {
                LiteFrame_editor(player, MY_AppData[r.selection - 2]);
            }
        });
    });
}

//新規作成
export function HARU_XEditor_NewApp(player, time) {
    var form = new ActionFormData();
    form.title(`${config['main'][0]}`);
    form.body(`§l§b${time}\n§r§5>>>§rどの§bフレームワーク§rを利用して、§e開発§rを行いますか？`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§1LiteFrame`);
    form.button(`§5Vortex\n§8利用不可`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                HARU_XEditor(player);
                break;
            case 1:
                HARU_XEditor_LiteFrame_NewApp(player);
                break;
            case 2:
                HARU_XEditor_NewApp(player, time);
                break;
        }
    });
}
