import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

// プレイヤーデータを管理するオブジェクト
const player_Cash_Data = {};
// 支払いログ
const harupay_logs = [];

export function Register(eventData) {
    const player = eventData.player;
    const playerId = player.id;

    // プレイヤーデータの初期化
    if (!player_Cash_Data[playerId]) {
        player_Cash_Data[playerId] = {
            cash: 0,
            isRegistering: false,
            RegisterStop: false,
            lastTransaction: null
        };
    }

    // クールダウン中なら何もせず終了
    if (player_Cash_Data[playerId].RegisterStop) {
        return;
    }

    // クールダウン開始（1秒=20tick）
    player_Cash_Data[playerId].RegisterStop = true;
    system.runTimeout(() => {
        player_Cash_Data[playerId].RegisterStop = false;
    }, 20);

    system.run(() => {
        try {
            // 支払い方法選択UIを最初に表示
            const paymentForm = new ActionFormData()
                .title("レジ")
                .body("お支払い方法を選択してください...")
                .button("§sHARUPAY");

            paymentForm.show(player).then((response) => {
                if (response.canceled) {
                    return;
                }

                if (response.selection === 0) {
                    // プレイヤーの座標を取得
                    const { x: playerX, y: playerY, z: playerZ } = player.location;

                    // 全てのプレイヤーを取得し、手動で距離を計算
                    const allPlayers = world.getPlayers();
                    const nearbyPlayers = [];
                    const maxDistance = 4; // 4ブロック以内

                    for (const target of allPlayers) {
                        if (target.name === player.name) continue; // 自分を除外
                        const { x: targetX, y: targetY, z: targetZ } = target.location;
                        const distance = Math.sqrt(
                            Math.pow(targetX - playerX, 2) +
                            Math.pow(targetY - playerY, 2) +
                            Math.pow(targetZ - playerZ, 2)
                        );
                        if (distance <= maxDistance) {
                            nearbyPlayers.push(target);
                        }
                    }

                    if (nearbyPlayers.length === 0) {
                        player.sendMessage("§r[§bレジ§r] §c取引可能なプレイヤーが見つかりませんでした");
                        player.playSound("random.toast", {
                            pitch: 0.4, 
                            volume: 1.0
                        });  
                        return;
                    }

                    // 取引相手選択UI
                    const targetForm = new ActionFormData()
                        .title("レジ")
                        .body("支払いを受けるプレイヤーを選択してください。");
                    nearbyPlayers.forEach((target, index) => {
                        targetForm.button(target.name);
                    });

                    targetForm.show(player).then((targetResponse) => {
                        if (targetResponse.canceled) {
                            return;
                        }

                        const targetPlayer = nearbyPlayers[targetResponse.selection];
                        player.sendMessage("§r[§bレジ§r] §e管理者が確認中です。しばらくお待ちください...");

                        // 管理者（受け取り側）向け金額入力UI
                        const amountForm = new ModalFormData()
                            .title("レジ")
                            .textField("合計金額(半角数字)", "0");

                        amountForm.show(targetPlayer).then((amountResponse) => {
                            if (amountResponse.canceled) {
                                player.sendMessage("§r[§bレジ§r] §4支払いを管理者がキャンセルしました");
                                player.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                return;
                            }

                            const amount = amountResponse.formValues[0];
                            if (!amount || isNaN(amount)) {
                                targetPlayer.sendMessage("§4半角数字で入力してください");
                                player.sendMessage("§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください");
                                player.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                return;
                            }

                            const cashAmount = parseInt(amount);
                            if (cashAmount > 100000000) {
                                targetPlayer.sendMessage("§4設定した金額は上限を超えています(1億以下で設定してください)");
                                player.sendMessage("§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください");
                                player.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                return;
                            }
                            if (cashAmount < 0) {
                                targetPlayer.sendMessage("§40以下は設定出来ません");
                                player.sendMessage("§r[§bレジ§r] §4支払いに失敗しました。もう一度お試しください");
                                player.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                targetPlayer.playSound("random.toast", {
                                    pitch: 0.4, 
                                    volume: 1.0
                                });  
                                return;
                            }
                            
                            // 支払い確認UI
                            const confirmForm = new ActionFormData()
                                .title("レジ")
                                .body(`支払い金額は§b${cashAmount}です\n\n§6相手§r:§c${targetPlayer.name}`)
                                .button("§sHARUPAYで支払う")
                                .button("§1キャンセル");

                            confirmForm.show(player).then((confirmResponse) => {
                                if (confirmResponse.canceled || confirmResponse.selection === 1) {
                                    return;
                                }

                                if (confirmResponse.selection === 0) {
                                    const playerScore = world.scoreboard.getObjective("money").getScore(player.scoreboardIdentity);
                                    if (playerScore >= cashAmount) {
                                        // 支払い処理
                                        targetPlayer.runCommand(`scoreboard players add @s account ${cashAmount}`);
                                        player.runCommand(`scoreboard players remove @s money ${cashAmount}`);
                                        player.sendMessage("§r[§bレジ§r] §e正常に支払いが完了しました");
                                        targetPlayer.sendMessage("§r[§bレジ§r] §e正常に支払われました");
                                        player.playSound("random.toast", {
                                            pitch: 1.7, 
                                            volume: 1.0
                                        });  
                                        targetPlayer.playSound("random.toast", {
                                            pitch: 1.7, 
                                            volume: 1.0
                                        });  
                                        // ログ記録
                                        const timer = new Date();
                                        harupay_logs.push(`[${timer.getHours()}:${timer.getMinutes()}] ${player.name}が${targetPlayer.name}へ${cashAmount}PAY送信(レジ)`);
                                    } else {
                                        player.sendMessage("§r[§bレジ§r] §eHARUPAY残高が不足しています");
                                        player.sendMessage("§r[§bレジ§r] §e支払いが残高不足により中止されました");
                                        player.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                        targetPlayer.playSound("random.toast", {
                                            pitch: 0.4, 
                                            volume: 1.0
                                        });  
                                    }
                                }
                            });
                        }).catch((error) => {
                            console.error("管理者向けUIエラー:", error);
                            player.sendMessage("§4エラーが発生しました。");
                        });
                    }).catch((error) => {
                        console.error("取引相手選択UIエラー:", error);
                        player.sendMessage("§4エラーが発生しました。");
                    });
                }
            }).catch((error) => {
                console.error("支払い方法選択UIエラー:", error);
                player.sendMessage("§4エラーが発生しました。");
            });
        } catch (error) {
            console.error("レジ処理エラー:", error);
            player.sendMessage("§4予期せぬエラーが発生しました。");
        }
    });
}