import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';

// データ保存期間（日数）
var DAYS_TO_KEEP = world.getDynamicProperty('location_delete_speed')
export function lreload() {
    DAYS_TO_KEEP = world.getDynamicProperty('location_delete_speed');
}
// 1日のミリ秒数
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
// ログ記録間隔（tick、1200tick = 1分）
const LOG_INTERVAL = 1200;
// 1プロパティあたりの最大ログ数（64KB制限対策）
const MAX_LOGS_PER_PROPERTY = 500;

// プレイヤー名のリスト
export let securityLogNames = [];

// 日付キーを生成（例：20250528）
function getDateKey(timestamp) {
    const date = new Date(timestamp);
    return `${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(date.getUTCDate()).padStart(2, '0')}`;
}

// 日本時間フォーマットの文字列を取得
function getJapanTimeString(timestamp) {
    const timeOffset = world.getDynamicProperty('Time_Setting') || 9; // デフォルト9時間（JST）
    const japanTime = new Date(timestamp + timeOffset * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const day = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    const seconds = String(japanTime.getUTCSeconds()).padStart(2, '0');
    return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
}

// プレイヤーごとのログキー生成
function getLogKey(playerName, timestamp) {
    return `location_${playerName}_${getDateKey(timestamp)}`;
}

// 古いログを削除
function cleanOldLogs(logData) {
    const currentTime = Date.now();
    const expirationTime = currentTime - DAYS_TO_KEEP * MILLISECONDS_PER_DAY;
    return logData.filter(log => log.timestamp >= expirationTime);
}

// プレイヤー名リストを保存
function savePlayerNames() {
    try {
        world.setDynamicProperty('location_names', JSON.stringify(securityLogNames));
    } catch (e) {
        console.warn(`プレイヤー名保存エラー: ${e}`);
    }
}

// プレイヤー名リストを読み込み
function loadPlayerNames() {
    try {
        const storedNames = world.getDynamicProperty('location_names');
        if (storedNames) {
            securityLogNames = JSON.parse(storedNames) || [];
        }
    } catch (e) {
        console.warn(`プレイヤー名読み込みエラー: ${e}`);
    }
}

// ログ記録
export function LocationLog() {
    if (world.getDynamicProperty('Log_system') !== true) {
        system.runTimeout(LocationLog, LOG_INTERVAL);
        return;
    }

    const players = world.getPlayers();
    const now = Date.now();
    const dateKey = getDateKey(now);

    players.forEach(player => {
        // プレイヤー名を保存
        if (!securityLogNames.includes(player.name)) {
            securityLogNames.push(player.name);
            savePlayerNames();
        }

        // 位置情報を取得
        const pos = player.location;
        const logEntry = {
            x: Math.round(pos.x),
            y: Math.round(pos.y),
            z: Math.round(pos.z),
            timestamp: now,
        };

        // プレイヤーごとのログを取得
        let logData = [];
        const logKey = getLogKey(player.name, now);
        try {
            const storedData = world.getDynamicProperty(logKey);
            if (storedData) {
                logData = JSON.parse(storedData);
                if (!Array.isArray(logData)) {
                    logData = [];
                }
            }
        } catch (e) {
            console.warn(`ログデータ取得エラー (${logKey}): ${e}`);
        }

        // 新しいログを追加
        logData.push(logEntry);

        // 古いログを削除
        logData = cleanOldLogs(logData);

        // ログ数が多すぎる場合は分割
        if (logData.length > MAX_LOGS_PER_PROPERTY) {
            const newLogData = logData.slice(-MAX_LOGS_PER_PROPERTY);
            logData = logData.slice(0, MAX_LOGS_PER_PROPERTY);
            try {
                world.setDynamicProperty(logKey, JSON.stringify(logData));
                const nextKey = `location_${player.name}_${dateKey}_split_${now}`;
                world.setDynamicProperty(nextKey, JSON.stringify(newLogData));
            } catch (e) {
                console.warn(`ログデータ保存エラー (${logKey}): ${e}`);
            }
        } else {
            try {
                world.setDynamicProperty(logKey, JSON.stringify(logData));
            } catch (e) {
                console.warn(`ログデータ保存エラー (${logKey}): ${e}`);
            }
        }
    });

    // 古い日付のログを削除
    cleanOldProperties();

    // 1分後に再実行
    system.runTimeout(LocationLog, LOG_INTERVAL);
}

// 古いプロパティを削除
function cleanOldProperties() {
    const currentTime = Date.now();
    const dateKeys = [];
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const date = new Date(currentTime - i * MILLISECONDS_PER_DAY);
        dateKeys.push(getDateKey(date.getTime()));
    }

    loadPlayerNames();
    securityLogNames.forEach(playerName => {
        const properties = world.getDynamicPropertyIds().filter(id => id.startsWith(`location_${playerName}_`));
        properties.forEach(prop => {
            const datePart = prop.match(/location_.*_(\d{8})/)?.[1];
            if (datePart && !dateKeys.includes(datePart)) {
                try {
                    world.setDynamicProperty(prop, undefined);
                } catch (e) {
                    console.warn(`プロパティ削除エラー (${prop}): ${e}`);
                }
            }
        });
    });
}

// 初期画面
export function showMainMenu_Location(player) {
    const form = new ActionFormData().title('§0§lSecureCraft').body('検索方法を選択してください').button('§1プレイヤー選択', 'textures/ui/icon_multiplayer.png').button('§5座標範囲で検索', 'textures/ui/icon_map.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showPlayerList_Location(player);
        } else {
            showCoordinateInput(player);
        }
    });
}

// プレイヤーリスト表示
function showPlayerList_Location(player) {
    loadPlayerNames();
    if (securityLogNames.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §aログデータがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        return;
    }

    const form = new ActionFormData().title('§0§lSecureCraft').body('確認したいプレイヤーを選んでください').button('§l§l戻る', 'textures/ui/icon_import.png');
    securityLogNames.forEach(name => form.button(`§1${name}`));

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainMenu_Location(player);
            return;
        }
        const selectedPlayer = securityLogNames[response.selection - 1];
        showSearchOptions(player, selectedPlayer);
    });
}

// 検索オプション表示
function showSearchOptions(player, targetName) {
    const form = new ActionFormData().title(`§1${targetName} のログ検索`).body('§a検索方法を選択してください').button('§1時間範囲で検索').button('§5座標範囲で検索').button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showTimeRangeInput(player, targetName);
                break;
            case 1:
                showCoordinateRangeSelection(player, targetName);
                break;
            case 2:
                showPlayerList_Location(player);
                break;
        }
    });
}

// 時間範囲入力画面
function showTimeRangeInput(player, targetName) {
    const now = getJapanTimeString(Date.now());
    const form = new ModalFormData()
        .title(`§1${targetName} の時間範囲検索`)
        .textField('開始時間 (例: 2025/05/28 03:44:00)', '', { defaultValue: `${now}` })
        .textField('終了時間 (例: 2025/05/28 03:44:00)', '', { defaultValue: `${now}` });

    form.show(player).then(response => {
        if (response.canceled) return;
        const [startTime, endTime] = response.formValues;
        if (!startTime || !endTime) {
            player.sendMessage('§r[§bSecurityCraft§r] §c時間入力を確認してください');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            return;
        }

        try {
            const startTimestamp = new Date(startTime).getTime();
            const endTimestamp = new Date(endTime).getTime();
            if (isNaN(startTimestamp) || isNaN(endTimestamp)) {
                throw new Error('無効な時間形式');
            }
            showFilteredLogsByTime(player, targetName, startTime, endTime);
        } catch (e) {
            player.sendMessage('§r[§bSecurityCraft§r] §c時間形式が無効です（例: 2025/05/28 03:44:00）');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            showSearchOptions(player, targetName);
        }
    });
}

// 時間範囲でフィルタリングされたログ表示
function showFilteredLogsByTime(player, targetName, startTime, endTime) {
    let logData = [];
    const startDate = new Date(startTime);
    const endDate = new Date(endTime);
    const dateKeys = [];
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        dateKeys.push(getDateKey(d.getTime()));
    }

    for (const dateKey of dateKeys) {
        try {
            const storedData = world.getDynamicProperty(`location_${targetName}_${dateKey}`);
            if (storedData) {
                const parsedData = JSON.parse(storedData);
                if (Array.isArray(parsedData)) {
                    logData = logData.concat(parsedData);
                }
            }
        } catch (e) {
            console.warn(`ログデータ取得エラー (${targetName}_${dateKey}): ${e}`);
        }
    }

    const startTimestamp = startDate.getTime();
    const endTimestamp = endDate.getTime();

    const filteredLogs = logData.filter(log => log.timestamp >= startTimestamp && log.timestamp <= endTimestamp).sort((a, b) => b.timestamp - a.timestamp); // 最新順にソート

    if (filteredLogs.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a指定された時間範囲にログがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showSearchOptions(player, targetName);
        return;
    }

    const form = new ActionFormData().title(`§1${targetName} のログ（時間範囲）`).body(`時間範囲: ${startTime} ～ ${endTime}\nログを選択してください`);

    filteredLogs.forEach(log => {
        const time = getJapanTimeString(log.timestamp);
        form.button(`${time} (${log.x}, ${log.y}, ${log.z})`);
    });
    form.button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === filteredLogs.length) {
            showSearchOptions(player, targetName);
            return;
        }

        showLogDetails(player, targetName, filteredLogs[response.selection], () => showFilteredLogsByTime(player, targetName, startTime, endTime));
    });
}

// 座標範囲検索画面（プレイヤーごと）
function showCoordinateRangeSelection(player, targetName) {
    const pos = player.location;
    const x = Math.round(pos.x);
    const y = Math.round(pos.y);
    const z = Math.round(pos.z);
    const now = getJapanTimeString(Date.now());

    const form = new ModalFormData()
        .title(`§1${targetName} の座標範囲検索`)
        .textField('X座標', '', { defaultValue: `${x}` })
        .textField('Y座標', '', { defaultValue: `${y}` })
        .textField('Z座標', '', { defaultValue: `${z}` })
        .dropdown('検索半径', ['10', '30', '50', '80'], { defaultValueIndex: 0 })
        .textField('開始時間 (例: 2025/05/28 03:44:00, 任意)', '')
        .textField('終了時間 (例: 2025/05/28 03:44:00, 任意)', '');

    form.show(player).then(response => {
        if (response.canceled) return;
        const [x, y, z, radiusIndex, startTime, endTime] = response.formValues;
        const radius = [10, 30, 50, 80][radiusIndex];

        try {
            const centerX = parseFloat(x);
            const centerY = parseFloat(y);
            const centerZ = parseFloat(z);
            if (isNaN(centerX) || isNaN(centerY) || isNaN(centerZ)) {
                throw new Error('無効な座標');
            }

            let startTimestamp = -Infinity;
            let endTimestamp = Infinity;
            if (startTime) startTimestamp = new Date(startTime).getTime();
            if (endTime) endTimestamp = new Date(endTime).getTime();
            if ((startTime && isNaN(startTimestamp)) || (endTime && isNaN(endTimestamp))) {
                throw new Error('無効な時間形式');
            }

            showFilteredLogsByCoordinates(player, targetName, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp);
        } catch (e) {
            player.sendMessage('§r[§bSecurityCraft§r] §c入力が無効です（座標は数値、時間は例: 2025/05/28 03:44:00）');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            showSearchOptions(player, targetName);
        }
    });
}

// 座標範囲でフィルタリングされたログ表示（プレイヤーごと）
function showFilteredLogsByCoordinates(player, targetName, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp) {
    let logData = [];
    const dateKeys = [];
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const date = new Date(currentTime - i * MILLISECONDS_PER_DAY);
        dateKeys.push(getDateKey(date.getTime()));
    }

    for (const dateKey of dateKeys) {
        try {
            const storedData = world.getDynamicProperty(`location_${targetName}_${dateKey}`);
            if (storedData) {
                const parsedData = JSON.parse(storedData);
                if (Array.isArray(parsedData)) {
                    logData = logData.concat(parsedData);
                }
            }
        } catch (e) {
            console.warn(`ログデータ取得エラー (${targetName}_${dateKey}): ${e}`);
        }
    }

    const filteredLogs = logData
        .filter(log => {
            const dx = log.x - centerX;
            const dy = log.y - centerY;
            const dz = log.z - centerZ;
            return Math.abs(dx) <= radius && Math.abs(dy) <= radius && Math.abs(dz) <= radius && log.timestamp >= startTimestamp && log.timestamp <= endTimestamp;
        })
        .sort((a, b) => b.timestamp - a.timestamp); // 最新順にソート

    if (filteredLogs.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a指定された範囲にログがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showSearchOptions(player, targetName);
        return;
    }

    const form = new ActionFormData().title(`§1${targetName} のログ（座標範囲）`).body(`中心: (${Math.round(centerX)}, ${Math.round(centerY)}, ${Math.round(centerZ)})\n範囲: ±${radius} ブロック\nログを選択してください`);

    filteredLogs.forEach(log => {
        const time = getJapanTimeString(log.timestamp);
        form.button(`${time} (${log.x}, ${log.y}, ${log.z})`);
    });
    form.button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === filteredLogs.length) {
            showSearchOptions(player, targetName);
            return;
        }

        showLogDetails(player, targetName, filteredLogs[response.selection], () => showFilteredLogsByCoordinates(player, targetName, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp));
    });
}

// 座標入力画面（全プレイヤー検索）
function showCoordinateInput(player) {
    const pos = player.location;
    const x = Math.round(pos.x);
    const y = Math.round(pos.y);
    const z = Math.round(pos.z);
    const now = getJapanTimeString(Date.now());

    const form = new ModalFormData()
        .title('§1座標からプレイヤー検索')
        .textField('X座標', '', { defaultValue: `${x}` })
        .textField('Y座標', '', { defaultValue: `${y}` })
        .textField('Z座標', '', { defaultValue: `${z}` })
        .dropdown('検索半径', ['10', '30', '50', '80'], { defaultValueIndex: 0 })
        .textField('開始時間 (例: 2025/05/28 03:44:00, 任意)', '')
        .textField('終了時間 (例: 2025/05/28 03:44:00, 任意)', '');

    form.show(player).then(response => {
        if (response.canceled) return;
        const [x, y, z, radiusIndex, startTime, endTime] = response.formValues;
        const radius = [10, 30, 50, 80][radiusIndex];

        try {
            const centerX = parseFloat(x);
            const centerY = parseFloat(y);
            const centerZ = parseFloat(z);
            if (isNaN(centerX) || isNaN(centerY) || isNaN(centerZ)) {
                throw new Error('無効な座標');
            }

            let startTimestamp = -Infinity;
            let endTimestamp = Infinity;
            if (startTime) startTimestamp = new Date(startTime).getTime();
            if (endTime) endTimestamp = new Date(endTime).getTime();
            if ((startTime && isNaN(startTimestamp)) || (endTime && isNaN(endTimestamp))) {
                throw new Error('無効な時間形式');
            }

            showPlayersByCoordinates(player, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp);
        } catch (e) {
            player.sendMessage('§r[§bSecurityCraft§r] §c入力が無効です（座標は数値、時間は例: 2025/05/28 03:44:00）');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            showMainMenu_Location(player);
        }
    });
}

// 座標範囲内のプレイヤー表示
function showPlayersByCoordinates(player, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp) {
    const playerLogs = {};
    const dateKeys = [];
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const date = new Date(currentTime - i * MILLISECONDS_PER_DAY);
        dateKeys.push(getDateKey(date.getTime()));
    }

    loadPlayerNames();
    for (const playerName of securityLogNames) {
        let logData = [];
        for (const dateKey of dateKeys) {
            try {
                const storedData = world.getDynamicProperty(`location_${playerName}_${dateKey}`);
                if (storedData) {
                    const parsedData = JSON.parse(storedData);
                    if (Array.isArray(parsedData)) {
                        logData = logData.concat(parsedData);
                    }
                }
            } catch (e) {
                console.warn(`ログデータ取得エラー (${playerName}_${dateKey}): ${e}`);
            }
        }

        const filteredLogs = logData
            .filter(log => {
                const dx = log.x - centerX;
                const dy = log.y - centerY;
                const dz = log.z - centerZ;
                return Math.abs(dx) <= radius && Math.abs(dy) <= radius && Math.abs(dz) <= radius && log.timestamp >= startTimestamp && log.timestamp <= endTimestamp;
            })
            .sort((a, b) => b.timestamp - a.timestamp); // 最新順にソート

        if (filteredLogs.length > 0) {
            playerLogs[playerName] = filteredLogs;
        }
    }

    if (Object.keys(playerLogs).length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a指定された範囲にプレイヤーログがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        showMainMenu_Location(player);
        return;
    }

    const form = new ActionFormData().title('§1座標範囲内のプレイヤー').body(`中心: (${Math.round(centerX)}, ${Math.round(centerY)}, ${Math.round(centerZ)})\n範囲: ±${radius} ブロック\nプレイヤーを選択してください`);

    Object.keys(playerLogs).forEach(playerName => {
        form.button(`${playerName} (${playerLogs[playerName].length}件)`);
    });
    form.button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === Object.keys(playerLogs).length) {
            showMainMenu_Location(player);
            return;
        }

        const selectedPlayer = Object.keys(playerLogs)[response.selection];
        showFilteredLogsByCoordinates(player, selectedPlayer, centerX, centerY, centerZ, radius, startTimestamp, endTimestamp);
    });
}

// ログ詳細表示
function showLogDetails(player, targetName, log, backCallback) {
    const time = getJapanTimeString(log.timestamp);
    const logText = `§a${targetName} §rの§6座標ログ\n§aX§r: §b${log.x}\n§aY§r: §b${log.y}\n§aZ§r: §b${log.z}\n§a時間§r: §b${time}`;

    const form = new ActionFormData().title('§0§lSecureCraft').body(logText).button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        backCallback(); // 呼び出し元の画面に戻る
    });
}
