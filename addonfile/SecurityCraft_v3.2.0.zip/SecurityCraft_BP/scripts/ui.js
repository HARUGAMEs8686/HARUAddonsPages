import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { checkModePlayers, playerCheckModeStatus, currentTPS } from './main';

import { resetPlayerXrayData } from './detection/x-ray';

import { showMainMenu_Location } from './log/Location';

import { securityLogNames, lreload } from './log/Location';

import { clearAllBreakData, breload } from './log/BreakBlock';
import { clearAllPlaceData, preload } from './log/PlaceBlock';

world.beforeEvents.chatSend.subscribe(event => {
    if (world.getDynamicProperty('CHAT_LEVEL') == 0) {
        return;
    }
    const player = event.sender;
    const message = event.message;

    if (message == '!scp' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (checkModePlayers.has(player.name)) {
                checkModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                checkModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scb' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (playerCheckModeStatus[player.name] == true) {
                playerCheckModeStatus[player.name] = false;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                playerCheckModeStatus[player.name] = true;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§e破壊された周辺のブロックタッチすると破壊者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
});

export function UI(eventData, player) {
    var players = world.getPlayers();
    var form = new ActionFormData();
    form.title('§0§lSecurityCraft');
    form.body(
        `§a-ワールド情報-\n§r・§3プレイヤー人数§r: §r§b${players.length}\n§r・§eTPS§r:§b${currentTPS}\n\n§c-セキュリティー情報-§r\n§r・§3座標ログ§r: §r§b${world.getDynamicProperty('Log_system')}\n§r・§2禁止アイテム設置検知§r:§b${world.getDynamicProperty('itemUseOn_system')}\n§r・§eX-ray検知Level§r:§b${world.getDynamicProperty('X_RAY_LEVEL')}\n§r・§dチャット検知Level§r:§b${world.getDynamicProperty(
            'CHAT_LEVEL'
        )}\n\n§5>>>§7選択してください...`
    );
    form.button('§1§o座標ログ');
    form.button('§5§o信頼メンバー\n§1追加§0/§4解除');
    form.button('§0§oブロック§4解除');
    form.button('§3§oCheckMode', 'textures/ui/sidebar_icons/star');
    form.button('§8§o設定\n§9操作', 'textures/ui/icon_setting');
    form.button('§0アドオン情報\n§8Version', 'textures/items/stick');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                showMainMenu_Location(player);
                break;
            case 1:
                // 特定のアイテムを使用したときにフォームを表示する関数
                function showPlayerSelector(player) {
                    // すべてのプレイヤーを取得
                    const allPlayers = world.getAllPlayers();
                    const playerNames = allPlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                    playerNames.unshift('全プレイヤー'); // ドロップダウンの先頭に「全プレイヤー」を追加

                    // フォームを作成
                    var form = new ModalFormData()
                        .title('§0§lSecurityCraft')
                        .dropdown('プレイヤーを選択してください', playerNames, {
                            defaultValueIndex: 0, // デフォルトは「全プレイヤー」
                            tooltip: 'プレイヤーを選択', // 必要に応じてツールチップを追加（任意）
                        })
                        .toggle('§cオフ§r:§aオン§r=§c解除§r:§a追加', {
                            defaultValue: true, // タグを付与するか削除するかのデフォルト値
                            tooltip: 'タグの追加または解除を選択', // 必要に応じてツールチップを追加（任意）
                        });

                    // フォームを表示
                    form.show(player).then(response => {
                        if (response.canceled) return; // フォームがキャンセルされた場合は終了

                        const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス
                        const addTag = response.formValues[1]; // タグを付与するか削除するか（true/false）

                        if (selectedIndex === 0) {
                            // 「全プレイヤー」が選択された場合
                            for (const targetPlayer of allPlayers) {
                                if (addTag) {
                                    targetPlayer.addTag('SecurityMember');
                                    player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rに§a追加しました`);
                                } else {
                                    targetPlayer.removeTag('SecurityMember');
                                    player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rから§c解除しました`);
                                }
                            }
                        } else {
                            // 個別のプレイヤーが選択された場合
                            const selectedPlayer = allPlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                            if (addTag) {
                                selectedPlayer.addTag('SecurityMember');
                                player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rに§a追加しました`);
                            } else {
                                selectedPlayer.removeTag('SecurityMember');
                                player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rから§c解除しました`);
                            }
                        }
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                    });
                }
                showPlayerSelector(player);
                break;
            case 2:
                // プレイヤーを取得
                const adventurePlayers = Array.from(players).filter(player => player.getGameMode() === 'Adventure');
                if (adventurePlayers.length == 0) {
                    player.sendMessage('[§bSecurity§r] §a解除可能なプレイヤーが見つかりませんでした');
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.6 0.7`);
                    return;
                }
                const playerNames = adventurePlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                playerNames.unshift('全員解除'); // ドロップダウンの先頭に「全プレイヤー」を追加

                // フォームを作成
                var form = new ModalFormData().title('§0§lSecurityCraft').dropdown('プレイヤーを選択してください', playerNames, {
                    defaultValueIndex: 0, // デフォルトは「全プレイヤー」
                    tooltip: 'プレイヤーを選択', // 必要に応じてツールチップを追加（任意）
                });

                // フォームを表示
                form.show(player).then(response => {
                    if (response.canceled) return; // フォームがキャンセルされた場合は終了

                    const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス

                    if (selectedIndex === 0) {
                        // 「全プレイヤー」が選択された場合
                        for (const targetPlayer of adventurePlayers) {
                            targetPlayer.runCommand('gamemode default @s');
                            player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§e解除しました`);
                            resetPlayerXrayData(`${targetPlayer.name}`);
                        }
                    } else {
                        // 個別のプレイヤーが選択された場合
                        const selectedPlayer = adventurePlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                        selectedPlayer.runCommand('gamemode default @s');
                        player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§e解除しました`);
                        resetPlayerXrayData(`${selectedPlayer.name}`);
                    }
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                });
                break;
            case 3:
                var form = new ModalFormData();
                form.title('§0§lSecurityCraft');
                form.toggle('§9設置確認モード', {
                    defaultValue: checkModePlayers.has(player.name),
                    tooltip: '設置確認モードを切り替える', // 任意でツールチップを追加
                });
                form.toggle('§4破壊確認モード', {
                    defaultValue: playerCheckModeStatus[player.name] ?? false,
                    tooltip: '破壊確認モードを切り替える', // 任意でツールチップを追加
                });
                form.show(player).then(r => {
                    if (r.canceled) return;

                    const [setPlacementCheck, setBreakCheck] = r.formValues;
                    const wasPlacementCheck = checkModePlayers.has(player.name);
                    const wasBreakCheck = playerCheckModeStatus[player.name] ?? false;

                    // 設置チェック切替
                    if (setPlacementCheck !== wasPlacementCheck) {
                        if (setPlacementCheck) {
                            checkModePlayers.add(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                        } else {
                            checkModePlayers.delete(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                        }
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                    }

                    // 破壊チェック切替
                    if (setBreakCheck !== wasBreakCheck) {
                        playerCheckModeStatus[player.name] = setBreakCheck;
                        if (setBreakCheck) {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§eブロック周辺をタッチで破壊履歴を確認');
                        } else {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                        }
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                    }
                });
                break;
            case 4:
                // メインメニュー
                var form = new ActionFormData();
                form.title('§0§lSecurityCraft');
                form.body('選択してください。');
                form.button('§l戻る', 'textures/ui/back_button_hover'); // 順番1
                form.button('§o§4検知システム\n§r§1X-ray§r・§5チャット'); // カテゴリー1 (元2, 3)
                form.button('§o§2座標ログ\n§r§9システム・データ削除'); // カテゴリー2 (元4, 7)
                form.button('§o§c禁止アイテム\n§r§9システム・アイテム設定'); // カテゴリー3 (元5, 6)
                form.button('§o§1ログ削除期間');
                form.button('§o§5設置/破壊記録削除');

                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0: // 戻る
                            UI(eventData, player);
                            break;
                        case 1: // 検知システム
                            openDetectionMenu(eventData, player);
                            break;
                        case 2: // 座標ログ
                            openLogMenu(eventData, player);
                            break;
                        case 3: // 禁止アイテム
                            openBanItemMenu(eventData, player);
                            break;
                        case 4:
                            var form = new ActionFormData();
                            form.title('§0§lSecurityCraft');
                            form.body('選択してください。');
                            form.button('§l戻る', 'textures/ui/back_button_hover');
                            form.button('§o§9座標ログ削除期間');
                            form.button('§o§5設置ログ削除期間');
                            form.button('§o§4破壊ログ削除期間');
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0: // 戻る
                                        UI(eventData, player);
                                        break;
                                    case 1:
                                        var form = new ModalFormData();
                                        form.title('§0§lSecurityCraft');
                                        form.textField('プレイヤーを選択してください', '3', { defaultValue: `${world.getDynamicProperty('location_delete_speed')}` });

                                        form.show(player).then(response => {
                                            if (response.canceled) return;

                                            const selectedIndex = Number(response.formValues[0]);
                                            world.setDynamicProperty('location_delete_speed', selectedIndex);
                                            player.sendMessage(`§r[§bSecurityCraft§r] §c座標ログ削除期間を§b${selectedIndex}日§cに変更しました`);
                                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                            lreload();
                                        });
                                        break;
                                    case 2:
                                        var form = new ModalFormData();
                                        form.title('§0§lSecurityCraft');
                                        form.textField('プレイヤーを選択してください', '3', { defaultValue: `${world.getDynamicProperty('placeblock_delete_speed')}` });

                                        form.show(player).then(response => {
                                            if (response.canceled) return;

                                            const selectedIndex = Number(response.formValues[0]);
                                            world.setDynamicProperty('placeblock_delete_speed', selectedIndex);
                                            player.sendMessage(`§r[§bSecurityCraft§r] §c設置ログ削除期間を§b${selectedIndex}日§cに変更しました`);
                                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                            preload();
                                        });
                                        break;
                                    case 3:
                                        var form = new ModalFormData();
                                        form.title('§0§lSecurityCraft');
                                        form.textField('プレイヤーを選択してください', '3', { defaultValue: `${world.getDynamicProperty('breakblock_delete_speed')}` });

                                        form.show(player).then(response => {
                                            if (response.canceled) return;

                                            const selectedIndex = Number(response.formValues[0]);
                                            world.setDynamicProperty('breakblock_delete_speed', selectedIndex);
                                            player.sendMessage(`§r[§bSecurityCraft§r] §c座標ログ削除期間を§b${selectedIndex}日§cに変更しました`);
                                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                            breload();
                                        });
                                        break;
                                }
                            });
                            break;
                        case 5:
                            var form = new ActionFormData();
                            form.title('§0§lSecurityCraft');
                            form.body('選択してください。');
                            form.button('§l戻る', 'textures/ui/back_button_hover');
                            form.button('§o§9設置ログ削除');
                            form.button('§o§5破壊ログ削除');
                            form.show(player).then(r => {
                                if (r.canceled) return;
                                let response = r.selection;
                                switch (response) {
                                    case 0: // 戻る
                                        UI(eventData, player);
                                        break;
                                    case 1: // 設置ログ削除
                                        let confirmPlaceForm = new ActionFormData();
                                        confirmPlaceForm.title('§0§l設置ログ削除確認');
                                        confirmPlaceForm.body('§c本当に設置ログを削除しますか？\nこの操作は元に戻せません。');
                                        confirmPlaceForm.button('§lキャンセル', 'textures/ui/cancel');
                                        confirmPlaceForm.button('§4削除する', 'textures/ui/confirm');
                                        confirmPlaceForm.show(player).then(res => {
                                            if (res.canceled || res.selection === 0) return;
                                            clearAllPlaceData();
                                            player.sendMessage(`§r[§bSecurityCraft§r] §c設置ログを削除しました`);
                                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                        });
                                        break;
                                    case 2: // 破壊ログ削除
                                        let confirmBreakForm = new ActionFormData();
                                        confirmBreakForm.title('§0§l破壊ログ削除確認');
                                        confirmBreakForm.body('§c本当に破壊ログを削除しますか？\nこの操作は元に戻せません。');
                                        confirmBreakForm.button('§lキャンセル', 'textures/ui/cancel');
                                        confirmBreakForm.button('§4削除する', 'textures/ui/confirm');
                                        confirmBreakForm.show(player).then(res => {
                                            if (res.canceled || res.selection === 0) return;
                                            clearAllBreakData();
                                            player.sendMessage(`§r[§bSecurityCraft§r] §c破壊ログを削除しました`);
                                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                                        });
                                        break;
                                }
                            });
                            break;
                    }
                });

                // 検知システムメニュー
                function openDetectionMenu(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body('選択してください。');
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§o§4X-ray検知\n§r§9Level選択§r/§5無効化');
                    form.button('§o§1不正チャット検知\n§r§9Level選択§r/§5無効化');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                UI(eventData, player);
                                break;
                            case 1: // X-ray検知
                                openXraySettings(eventData, player);
                                break;
                            case 2: // 不正チャット検知
                                openChatSettings(eventData, player);
                                break;
                        }
                    });
                }

                // X-ray検知設定
                function openXraySettings(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body(`X-ray検知レベル§r:§b${world.getDynamicProperty('X_RAY_LEVEL') || '無効'}\n選択してください。`);
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§1無効化 \n§8検知システムが実行されません');
                    form.button('§1Level-1 \n§8誤検知を最小限に抑える');
                    form.button('§1Level-2 \n§8バランスの取れた検知レベル');
                    form.button('§1Level-3 \n§8標準より少し厳しい検知');
                    form.button('§1Level-4 \n§8高速検知');
                    form.button('§1Level-5 \n§8即時検知');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        if (response === 0) {
                            UI(eventData, player);
                            return;
                        }
                        world.setDynamicProperty('X_RAY_LEVEL', response - 1);
                        UI(eventData, player);
                    });
                }

                // 不正チャット検知設定
                function openChatSettings(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body(`不正チャット検知レベル§r:§b${world.getDynamicProperty('CHAT_LEVEL') || '無効'}\n選択してください。`);
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§1無効化 \n§8検知システムが実行されません');
                    form.button('§1Level-1 \n§8弱い検知レベル - 最小限の対応');
                    form.button('§1Level-2 \n§8バランス検知レベル - 中程度の対応');
                    form.button('§1Level-3 \n§8強い検知レベル - 厳密な対応');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        if (response === 0) {
                            UI(eventData, player);
                            return;
                        }
                        world.setDynamicProperty('CHAT_LEVEL', response - 1);
                        UI(eventData, player);
                    });
                }

                // 座標ログメニュー
                function openLogMenu(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body('選択してください。');
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§o§2座標ログシステム\n§r§9有効化§r・§5無効化');
                    form.button('§o§4座標ログデータ削除');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                UI(eventData, player);
                                break;
                            case 1: // 座標ログシステム
                                toggleLogSystem(eventData, player);
                                break;
                            case 2: // 座標ログデータ削除
                                openLogDeleteMenu(eventData, player);
                                break;
                        }
                    });
                }

                // 座標ログシステム設定
                function toggleLogSystem(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body(`現在は${world.getDynamicProperty('Log_system') ? '有効' : '無効'}\n選択してください。`);
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§o§9有効化');
                    form.button('§o§4無効化');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                UI(eventData, player);
                                break;
                            case 1: // 有効化
                                world.setDynamicProperty('Log_system', true);
                                UI(eventData, player);
                                break;
                            case 2: // 無効化
                                world.setDynamicProperty('Log_system', false);
                                UI(eventData, player);
                                break;
                        }
                    });
                }

                // ログデータ削除メニュー
                function openLogDeleteMenu(eventData, player) {
                    confirmDeleteData(eventData, player);
                }

                // データ削除確認
                function confirmDeleteData(eventData, player) {
                    const form = new ActionFormData().title('§0§lセキュリティログ').body('§9座標のログデータ\n\n§5>>> 本当に削除しますか？').button('§o§5削除').button('§o§1キャンセル');

                    form.show(player).then(response => {
                        if (response.canceled || response.selection === 1) {
                            UI(eventData, player);
                            return;
                        }

                        try {
                            // プレイヤー名リストを読み込み
                            const storedNames = world.getDynamicProperty('location_names');
                            if (storedNames) {
                                securityLogNames.length = 0; // リストをクリア
                                world.setDynamicProperty('location_names', JSON.stringify([])); // 保存
                            }

                            // すべてのログデータを削除
                            const properties = world.getDynamicPropertyIds().filter(id => id.startsWith('location_'));
                            properties.forEach(prop => {
                                try {
                                    world.setDynamicProperty(prop, undefined);
                                } catch (e) {
                                    console.warn(`プロパティ削除エラー (${prop}): ${e}`);
                                }
                            });

                            player.sendMessage('§r[§bSecurityCraft§r] §aすべてのログデータを削除しました');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } catch (e) {
                            console.warn(`データ削除エラー: ${e}`);
                            player.sendMessage('§r[§bSecurityCraft§r] §cデータ削除中にエラーが発生しました');
                            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
                        }

                        UI(eventData, player); // 削除後にメインメニューに戻る
                    });
                }

                // 禁止アイテムメニュー
                function openBanItemMenu(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body('選択してください。');
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§o§c禁止設置アイテムシステム\n§r§9有効化§r・§5無効化');
                    form.button('§o§c禁止設置アイテム\n§r§9追加§r・§5削除');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                UI(eventData, player);
                                break;
                            case 1: // 禁止設置アイテムシステム
                                toggleItemSystem(eventData, player);
                                break;
                            case 2: // 禁止設置アイテム
                                openBanMenu(player);
                                break;
                        }
                    });
                }

                // 禁止アイテムシステム設定
                function toggleItemSystem(eventData, player) {
                    var form = new ActionFormData();
                    form.title('§0§lSecurityCraft');
                    form.body(`現在は${world.getDynamicProperty('itemUseOn_system') ? '有効' : '無効'}\n選択してください。`);
                    form.button('§l戻る', 'textures/ui/back_button_hover');
                    form.button('§o§9有効化');
                    form.button('§o§4無効化');

                    form.show(player).then(r => {
                        if (r.canceled) return;
                        let response = r.selection;
                        switch (response) {
                            case 0: // 戻る
                                UI(eventData, player);
                                break;
                            case 1: // 有効化
                                world.setDynamicProperty('itemUseOn_system', true);
                                UI(eventData, player);
                                break;
                            case 2: // 無効化
                                world.setDynamicProperty('itemUseOn_system', false);
                                UI(eventData, player);
                                break;
                        }
                    });
                }

                // 禁止アイテム編集メニュー
                function openBanMenu(player) {
                    const form = new ActionFormData().title('§0§lSecurityCraft').body(`§c禁止アイテム§e操作§5>>>`).button('§l戻る', 'textures/ui/back_button_hover').button('§1追加').button('§4削除');

                    form.show(player).then(response => {
                        if (response.canceled || response.selection === 0) {
                            UI(eventData, player);
                            return;
                        }
                        if (response.selection === 1) {
                            addBannedBlock(player);
                        } else if (response.selection === 2) {
                            removeBannedBlock(player);
                        }
                    });
                }

                // アイテム追加
                function addBannedBlock(player) {
                    const form = new ModalFormData().title('§0§lSecurityCraft').textField('§a追加する§eアイテムID§aを入力:', '例:minecraft:tnt');

                    form.show(player).then(response => {
                        if (response.canceled) return;
                        const newBlock = response.formValues[0].trim();
                        if (!newBlock) return;

                        let bannedBlocks = world.getDynamicProperty('bannedBlocks') ? JSON.parse(world.getDynamicProperty('bannedBlocks')) : [];
                        if (!bannedBlocks.includes(newBlock)) {
                            bannedBlocks.push(newBlock);
                            world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
                            player.sendMessage(`[§bSecurity§r] §b${newBlock}§rを禁止アイテムに§e追加しました`);
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                            openBanMenu(player);
                        } else {
                            player.sendMessage(`[§bSecurity§r] §b${newBlock}§rは既に§c禁止されています`);
                            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.4 0.7`);
                            openBanMenu(player);
                        }
                    });
                }

                // アイテム削除
                function removeBannedBlock(player) {
                    let bannedBlocks = world.getDynamicProperty('bannedBlocks') ? JSON.parse(world.getDynamicProperty('bannedBlocks')) : [];
                    if (bannedBlocks.length === 0) {
                        player.sendMessage('[§bSecurity§r] §c削除できる禁止アイテムはありません');
                        return;
                    }

                    const form = new ModalFormData().title('§0§lSecurityCraft').dropdown('削除するアイテムを選択:', bannedBlocks);

                    form.show(player).then(response => {
                        if (response.canceled) return;
                        const selectedBlock = bannedBlocks[response.formValues[0]];
                        confirmRemove(player, selectedBlock);
                        openBanMenu(player);
                    });
                }

                // 削除確認
                function confirmRemove(player, block) {
                    const form = new ActionFormData().title('§0§lSecurityCraft').body(`本当に ${block} を削除しますか？`).button('§4削除する').button('§1キャンセル');

                    form.show(player).then(response => {
                        if (response.canceled || response.selection !== 0) {
                            openBanMenu(player);
                            return;
                        }

                        let bannedBlocks = JSON.parse(world.getDynamicProperty('bannedBlocks'));
                        bannedBlocks = bannedBlocks.filter(item => item !== block);
                        world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
                        player.sendMessage(`[§bSecurity§r] §b${block}§rを禁止アイテムから§e削除しました`);
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                    });
                }
                break;
            case 5:
                var form = new ActionFormData();
                form.title(`§l§0SecurityCraft`);
                form.body(`§aアドオン名§r:§bSecurityCraft\n§eVersion§r:§b3.2.0\n§cリリース日§r:§b2025/07/17`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //戻る
                            UI(eventData, player);
                            break;
                    }
                });
                break;
            default:
                break;
        }
    });
}
