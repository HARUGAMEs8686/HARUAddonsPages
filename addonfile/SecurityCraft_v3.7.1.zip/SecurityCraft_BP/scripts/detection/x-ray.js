import { world, system } from '@minecraft/server';

// プレイヤーの追跡データを読み込み
function loadTrackedPlayers() {
    const data = world.getDynamicProperty('trackedPlayers');
    return data ? JSON.parse(data) : {};
}
const trackedPlayers = loadTrackedPlayers();

// プレイヤーの追跡データを保存
function saveTrackedPlayers() {
    world.setDynamicProperty('trackedPlayers', JSON.stringify(trackedPlayers));
}

// グローバル統計データを読み込み
function loadGlobalStats() {
    const data = world.getDynamicProperty('globalStats');
    return data
        ? JSON.parse(data)
        : {
              totalMined: 0,
              'minecraft:diamond_ore': 0,
              'minecraft:deepslate_diamond_ore': 0,
              'minecraft:ancient_debris': 0,
              'minecraft:emerald_ore': 0,
              'minecraft:deepslate_emerald_ore': 0,
          };
}
const globalStats = loadGlobalStats();

// グローバル統計データを保存
function saveGlobalStats() {
    world.setDynamicProperty('globalStats', JSON.stringify(globalStats));
}

// 設置されたブロックのデータを読み込み
function loadPlacedBlocks() {
    const data = world.getDynamicProperty('placedBlocks');
    return data ? new Map(JSON.parse(data)) : new Map();
}
let placedBlocks = loadPlacedBlocks();

// 24時間（ミリ秒）
const PLACED_BLOCK_EXPIRY = 24 * 60 * 60 * 1000;

// 設置されたブロックのデータを保存
function savePlacedBlocks() {
    const now = Date.now();
    for (const [key, timestamp] of placedBlocks) {
        // 古いブロックデータを削除
        if (now - timestamp > PLACED_BLOCK_EXPIRY) {
            placedBlocks.delete(key);
        }
    }
    const serialized = JSON.stringify([...placedBlocks]);
    // データサイズが大きくなりすぎた場合、半分にトリミング
    if (serialized.length > 30000) {
        trimPlacedBlocks();
    }
    world.setDynamicProperty('placedBlocks', JSON.stringify([...placedBlocks]));
}

// 設置されたブロックのデータをトリミング
function trimPlacedBlocks() {
    const entries = [...placedBlocks.entries()];
    const halfLength = Math.floor(entries.length / 2);
    placedBlocks = new Map(entries.slice(halfLength));
}

function getSurroundingOpenness(player) {
    let airBlocks = 0;
    const sampleSize = 4; // 周囲4x4x4ブロックをサンプリング
    const totalSamples = Math.pow(sampleSize * 2 + 1, 3);
    const { x, y, z } = player.location;

    for (let dx = -sampleSize; dx <= sampleSize; dx++) {
        for (let dy = -sampleSize; dy <= sampleSize; dy++) {
            for (let dz = -sampleSize; dz <= sampleSize; dz++) {
                try {
                    const block = player.dimension.getBlock({ x: Math.floor(x + dx), y: Math.floor(y + dy), z: Math.floor(z + dz) });
                    if (block && block.isAir) {
                        airBlocks++;
                    }
                } catch (e) {
                    // 読み込めないチャンクは無視
                }
            }
        }
    }
    return airBlocks / totalSamples;
}

function analyzeMiningPath(path) {
    if (path.length < 3) return { isWinding: false, turns: 0 };

    let turns = 0;
    let lastVector = null;

    for (let i = 1; i < path.length; i++) {
        const p1 = path[i - 1];
        const p2 = path[i];
        const currentVector = { x: p2.x - p1.x, y: p2.y - p1.y, z: p2.z - p1.z };

        if (lastVector) {
            // ベクトルが変化したか（方向転換したか）をチェック
            if (currentVector.x !== lastVector.x || currentVector.y !== lastVector.y || currentVector.z !== lastVector.z) {
                turns++;
            }
        }
        lastVector = currentVector;
    }

    // 経路長に対して方向転換が多すぎる場合に「蛇行」と判断
    const isWinding = turns >= 3 && path.length / (turns + 1) < 4;
    return { isWinding, turns };
}

function getExposureLevel(block) {
    if (!block || !block.dimension) return 0;
    const { x, y, z } = block.location;
    const airId = 'minecraft:air';
    let exposedFaces = 0;
    const checkOffsets = [
        [0, 1, 0],
        [0, -1, 0],
        [1, 0, 0],
        [-1, 0, 0],
        [0, 0, 1],
        [0, 0, -1],
    ];
    for (const [dx, dy, dz] of checkOffsets) {
        try {
            const checkBlock = block.dimension.getBlock({ x: x + dx, y: y + dy, z: z + dz });
            if (checkBlock && checkBlock.typeId === airId) {
                exposedFaces++;
            }
        } catch (e) {
            // ブロックがロードされていないなどのエラーを無視
        }
    }
    return exposedFaces;
}

export function Xray() {
    const ORE_LIMITS = {
        'minecraft:diamond_ore': 10,
        'minecraft:deepslate_diamond_ore': 10,
        'minecraft:ancient_debris': 8,
        'minecraft:emerald_ore': 15,
        'minecraft:deepslate_emerald_ore': 15,
    };

    const SUSPICION_RESET_TIME = 290000; // 7分（ミリ秒）
    const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL') || 1;

    // ... (LEVEL_CONFIGS は変更なし)
    const LEVEL_CONFIGS = {
        1: { TIME_WINDOW: 150, SUSPICIOUS_THRESHOLD: 20, WARN_LIMIT: 8, DETECTION_RADIUS: 6, MAX_NON_ORE_BLOCKS_BEFORE_ORE: 12, MINED_HISTORY_SIZE: 10 },
        2: { TIME_WINDOW: 120, SUSPICIOUS_THRESHOLD: 18, WARN_LIMIT: 7, DETECTION_RADIUS: 6, MAX_NON_ORE_BLOCKS_BEFORE_ORE: 10, MINED_HISTORY_SIZE: 8 },
        3: { TIME_WINDOW: 90, SUSPICIOUS_THRESHOLD: 15, WARN_LIMIT: 6, DETECTION_RADIUS: 5, MAX_NON_ORE_BLOCKS_BEFORE_ORE: 8, MINED_HISTORY_SIZE: 6 },
        4: { TIME_WINDOW: 60, SUSPICIOUS_THRESHOLD: 13, WARN_LIMIT: 5, DETECTION_RADIUS: 4, MAX_NON_ORE_BLOCKS_BEFORE_ORE: 6, MINED_HISTORY_SIZE: 4 },
        5: { TIME_WINDOW: 45, SUSPICIOUS_THRESHOLD: 11, WARN_LIMIT: 4, DETECTION_RADIUS: 3, MAX_NON_ORE_BLOCKS_BEFORE_ORE: 4, MINED_HISTORY_SIZE: 2 },
    };

    let TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE;

    if (X_RAY_LEVEL != 0) {
        ({ TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE } = LEVEL_CONFIGS[X_RAY_LEVEL]);
    }

    const placedExplosives = new Map();

    // ... (getPlayerMiningSpeed, isBlockInPlayerSight, playerPlaceBlock は変更なし)
    function getPlayerMiningSpeed(player) {
        let speedMultiplier = 1.0;
        if (!player || typeof player !== 'object' || !player.getComponent) return speedMultiplier;
        const inventory = player.getComponent('minecraft:inventory');
        if (!inventory || !inventory.container) return speedMultiplier;
        const selectedSlot = player.selectedSlot;
        if (typeof selectedSlot !== 'number' || selectedSlot < 0) return speedMultiplier;
        const heldItem = inventory.container.getSlot(selectedSlot);
        if (heldItem && heldItem.typeId && heldItem.typeId.includes('pickaxe')) {
            const enchantments = heldItem.getComponent('minecraft:enchantments');
            if (enchantments) {
                const efficiency = enchantments.getEnchantment('efficiency');
                const efficiencyLevel = efficiency && typeof efficiency.level === 'number' ? efficiency.level : 0;
                speedMultiplier *= 1 + efficiencyLevel * 0.2;
            }
        }
        const effects = player.getEffects ? player.getEffects() : [];
        for (const effect of effects) {
            if (effect && effect.typeId === 'minecraft:haste' && typeof effect.amplifier === 'number') {
                speedMultiplier *= 1 + effect.amplifier * 0.2;
            }
        }
        if (player.hasTag && player.hasTag('beacon_haste')) {
            speedMultiplier *= 1.4;
        }
        return speedMultiplier;
    }
    function isBlockInPlayerSight(player, blockLocation, maxDistance = 8) {
        const playerLocation = player.location;
        const viewDirection = player.getViewDirection();
        const eyeHeightOffset = 1.62;
        const eyeLocation = {
            x: playerLocation.x,
            y: playerLocation.y + eyeHeightOffset,
            z: playerLocation.z,
        };
        const blockCenter = {
            x: blockLocation.x + 0.5,
            y: blockLocation.y + 0.5,
            z: blockLocation.z + 0.5,
        };
        const toBlockX = blockCenter.x - eyeLocation.x;
        const toBlockY = blockCenter.y - eyeLocation.y;
        const toBlockZ = blockCenter.z - eyeLocation.z;
        const distance = Math.sqrt(toBlockX * toBlockX + toBlockY * toBlockY + toBlockZ * toBlockZ);
        if (distance > maxDistance) return false;
        let normalizedToBlockX = 0,
            normalizedToBlockY = 0,
            normalizedToBlockZ = 0;
        if (distance > 0) {
            normalizedToBlockX = toBlockX / distance;
            normalizedToBlockY = toBlockY / distance;
            normalizedToBlockZ = toBlockZ / distance;
        }
        const dotProduct = viewDirection.x * normalizedToBlockX + viewDirection.y * normalizedToBlockY + viewDirection.z * normalizedToBlockZ;
        const FOV_THRESHOLD = Math.cos(Math.PI / 4);
        if (dotProduct < FOV_THRESHOLD) return false;
        try {
            const hitResult = player.dimension.getBlockFromRay(eyeLocation, viewDirection, {
                maxDistance: maxDistance,
                includePassableBlocks: false,
                ignoreBlockPermutation: false,
            });
            if (hitResult && hitResult.block) {
                const hitBlockLoc = hitResult.block.location;
                const targetBlockLoc = blockLocation;
                if (hitBlockLoc.x === targetBlockLoc.x && hitBlockLoc.y === targetBlockLoc.y && hitBlockLoc.z === targetBlockLoc.z) {
                    return true;
                }
            }
        } catch (e) {
            console.error(`Error in getBlockFromRay: ${e}`);
        }
        return false;
    }
    world.afterEvents.playerPlaceBlock.subscribe(event => {
        system.run(() => {
            const block = event.block;
            const blockType = block.type.id;
            const key = `${block.location.x},${block.location.y},${block.location.z}`;
            if (blockType in ORE_LIMITS) {
                placedBlocks.set(key, Date.now());
                savePlacedBlocks();
            }
            if (blockType === 'minecraft:tnt' || blockType === 'minecraft:respawn_anchor' || blockType === 'minecraft:bed') {
                placedExplosives.set(key, {
                    playerId: event.player.name,
                    type: blockType,
                    timestamp: Date.now(),
                });
            }
        });
    });

    // ▼▼▼ メインの検知ロジック (playerBreakBlock) を刷新 ▼▼▼
    world.beforeEvents.playerBreakBlock.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        const { TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, DETECTION_RADIUS, MAX_NON_ORE_BLOCKS_BEFORE_ORE, MINED_HISTORY_SIZE } = LEVEL_CONFIGS[X_RAY_LEVEL];

        const player = event.player;
        const block = event.block;
        if (!block) return;

        const playerId = player.name;
        const blockPos = block.location;
        const oreType = block.type.id;
        const now = Date.now();

        const blockKey = `${blockPos.x},${blockPos.y},${blockPos.z}`;
        if (placedBlocks.has(blockKey)) {
            placedBlocks.delete(blockKey);
            savePlacedBlocks();
            return;
        }

        if (!trackedPlayers[playerId]) {
            trackedPlayers[playerId] = {
                ores: {},
                timestamp: now,
                suspiciousCount: 0,
                warnCount: 0,
                totalBlocksMined: 0,
                reasons: {},
                nonOreBlocksMinedBeforeOre: 0,
                miningPath: [], // 掘削経路を追跡
            };
        }

        let playerData = trackedPlayers[playerId];
        const isOre = oreType in ORE_LIMITS;

        // 時間ウィンドウが経過した場合、データをリセット
        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.suspiciousCount = Math.floor(playerData.suspiciousCount / 2); // 疑いは半分だけ残す
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.miningPath = [];
        }

        playerData.totalBlocksMined++;
        globalStats.totalMined++;

        if (isOre) {
            // --- ここからが新しい複合的な検知ロジック ---
            let totalSuspicionPoints = 0;
            const suspicionReasons = new Set();

            // 状況評価
            const exposure = getExposureLevel(block);
            const openness = getSurroundingOpenness(player);
            const isCave = openness > 0.45; // 45%以上が空気なら洞窟と判断

            // --- 証拠1: 視線 ---
            const inSight = isBlockInPlayerSight(player, blockPos, DETECTION_RADIUS);
            if (!inSight) {
                totalSuspicionPoints += 3;
                suspicionReasons.add('視線外の鉱石を採掘');
            }

            // --- 証拠2: 露出度 (洞窟環境を考慮) ---
            const isExposed = exposure >= 2;
            if (!isExposed && !isCave) {
                // 露出しておらず、かつ洞窟でもない場合
                totalSuspicionPoints += 2;
                suspicionReasons.add('非露出の鉱石(閉所)');
            }

            // --- 証拠3: 掘削経路 (グネグネ掘り) ---
            const pathAnalysis = analyzeMiningPath(playerData.miningPath);
            if (pathAnalysis.isWinding) {
                totalSuspicionPoints += 2;
                suspicionReasons.add(`不自然な経路(方向転換${pathAnalysis.turns}回)`);
            }

            // --- 証拠4: 鉱石への直行 (ブランチマイニング誤検知対策) ---
            // グネグネ掘り or 非露出鉱石の場合に、このチェックの重みを増す
            if (playerData.nonOreBlocksMinedBeforeOre <= MAX_NON_ORE_BLOCKS_BEFORE_ORE && (!isExposed || pathAnalysis.isWinding)) {
                totalSuspicionPoints += 1;
                suspicionReasons.add('鉱石への到達が早い');
            }

            // 複数の証拠が揃った場合、ボーナスポイント
            if (suspicionReasons.size >= 2) {
                totalSuspicionPoints += suspicionReasons.size; // 証拠の数だけ追加
                suspicionReasons.add(`複合的な証拠(${suspicionReasons.size}件)`);
            }

            // 最終的な疑いを加算
            if (totalSuspicionPoints > 0) {
                playerData.suspiciousCount += totalSuspicionPoints;
                suspicionReasons.forEach(reason => {
                    playerData.reasons[reason] = (playerData.reasons[reason] || 0) + 1;
                });
            }

            // 統計データ更新
            playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
            globalStats[oreType] = (globalStats[oreType] || 0) + 1;
            saveGlobalStats();

            // 鉱石を掘ったので、次の検知のためにリセット
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.miningPath = [];
        } else {
            // 鉱石以外を掘った場合、経路を記録
            playerData.nonOreBlocksMinedBeforeOre++;
            playerData.miningPath.push(blockPos);
            // 経路データが大きくなりすぎないように制限
            if (playerData.miningPath.length > 15) {
                playerData.miningPath.shift();
            }
        }

        // --- 警告レベルのチェック (変更なし) ---
        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    if (playerOreCount > 0) {
                        const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                        const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                        oreStatsMessage += `\n  - §a${ore.split(':')[1]}§r: §b${playerOreRate.toFixed(2)}% §r(平均: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                world.sendMessage(`[§bSecurityCraft§r] §a${playerId} §rが§cX-ray§4の可能性`);
                if (oreStatsMessage) world.sendMessage(`§e-- プレイヤーの鉱石発見率 --§r${oreStatsMessage}`);

                let reasonMessage = '';
                for (const reason in playerData.reasons) {
                    reasonMessage += `\n  - ${reason}: ${playerData.reasons[reason]}回`;
                }
                if (reasonMessage) {
                    world.getAllPlayers().forEach(p => {
                        if (p.hasTag('SecurityOP')) {
                            p.sendMessage(`§6--- 検知理由 ---§r${reasonMessage}`);
                        }
                    });
                }

                system.run(() => {
                    player.setGameMode('Adventure');
                    world.getAllPlayers().forEach(p => {
                        p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                    });
                });

                // 警告後、データをリセットして再犯を監視
                playerData.warnCount = 0;
                playerData.reasons = {};
            }
        }

        saveTrackedPlayers();
    });
    // ▲▲▲ メインの検知ロジック (playerBreakBlock) ここまで ▲▲▲

    world.beforeEvents.explosion.subscribe(event => {
        const X_RAY_LEVEL = world.getDynamicProperty('X_RAY_LEVEL');
        if (X_RAY_LEVEL == 0) return;
        const { TIME_WINDOW, SUSPICIOUS_THRESHOLD, WARN_LIMIT, NEARBY_RADIUS } = LEVEL_CONFIGS[X_RAY_LEVEL];
        const impactedBlocks = event.getImpactedBlocks();
        if (!impactedBlocks.length) return;

        let responsiblePlayerId = null;
        let totalX = 0,
            totalY = 0,
            totalZ = 0;
        for (const block of impactedBlocks) {
            totalX += block.location.x;
            totalY += block.location.y;
            totalZ += block.location.z;
        }
        const centerX = Math.floor(totalX / impactedBlocks.length);
        const centerY = Math.floor(totalY / impactedBlocks.length);
        const centerZ = Math.floor(totalZ / impactedBlocks.length);

        const BLAST_RADIUS = 7;
        for (let dx = -BLAST_RADIUS; dx <= BLAST_RADIUS; dx++) {
            for (let dy = -BLAST_RADIUS; dy <= BLAST_RADIUS; dy++) {
                for (let dz = -BLAST_RADIUS; dz <= BLAST_RADIUS; dz++) {
                    const checkX = centerX + dx;
                    const checkY = centerY + dy;
                    const checkZ = centerZ + dz;
                    const explosionKey = `${checkX},${checkY},${checkZ}`;
                    const explosiveData = placedExplosives.get(explosionKey);

                    if (explosiveData && Date.now() - explosiveData.timestamp < 10000) {
                        responsiblePlayerId = explosiveData.playerId;
                        placedExplosives.delete(explosionKey);
                        break;
                    }
                }
                if (responsiblePlayerId) break;
            }
            if (responsiblePlayerId) break;
        }

        if (!responsiblePlayerId) return;

        const playerData = trackedPlayers[responsiblePlayerId] || {
            ores: {},
            timestamp: Date.now(),
            lastBreakTime: 0,
            suspiciousCount: 0,
            warnCount: 0,
            lastBreakPos: null,
            totalBlocksMined: 0,
            reasons: {},
            straightMiningCount: 0,
            nearbyOreStreak: 0,
            nonOreBlocksMinedBeforeOre: 0,
            minedBlockHistory: [],
            miningPath: [], 
        };
        trackedPlayers[responsiblePlayerId] = playerData;
        const now = Date.now();

        if (now - playerData.timestamp > TIME_WINDOW * 1000) {
            playerData.ores = {};
            playerData.timestamp = now;
            playerData.totalBlocksMined = 0;
            playerData.reasons = {};
            playerData.straightMiningCount = 0;
            playerData.nearbyOreStreak = 0;
            playerData.nonOreBlocksMinedBeforeOre = 0;
            playerData.minedBlockHistory = [];
        }

        for (const block of impactedBlocks) {
            const oreType = block.type.id;
            if (!(oreType in ORE_LIMITS)) continue;

            const blockKey = `${block.location.x},${block.location.y},${block.location.z}`;
            if (placedBlocks.has(blockKey)) {
                placedBlocks.delete(blockKey);
                savePlacedBlocks();
                continue;
            }

            playerData.ores[oreType] = (playerData.ores[oreType] || 0) + 1;
            playerData.totalBlocksMined++;
            globalStats.totalMined++;
            globalStats[oreType] = (globalStats[oreType] || 0) + 1;

            if (playerData.ores[oreType] > ORE_LIMITS[oreType]) {
                playerData.suspiciousCount++;
                playerData.reasons['爆発で異常に多く鉱石を取得'] = (playerData.reasons['爆発で異常に多く鉱石を取得'] || 0) + 1;
            }

            const worldOreRate = (globalStats[oreType] / globalStats.totalMined) * 100 || 0;
            const playerOreRate = (playerData.ores[oreType] / playerData.totalBlocksMined) * 100 || 0;
            if (playerData.totalBlocksMined > 50 && playerOreRate > worldOreRate * 2) {
                playerData.suspiciousCount++;
                playerData.reasons['爆発による異常な鉱石発見率'] = (playerData.reasons['爆発による異常な鉱石発見率'] || 0) + 1;
            }
        }

        saveGlobalStats();
        saveTrackedPlayers();

        if (playerData.suspiciousCount >= SUSPICIOUS_THRESHOLD) {
            playerData.warnCount++;
            playerData.suspiciousCount = 0;

            const WARNING_COOLDOWN = 60000;
            if (playerData.warnCount >= WARN_LIMIT && (!playerData.lastWarningTime || now - playerData.lastWarningTime > WARNING_COOLDOWN)) {
                playerData.lastWarningTime = now;

                let oreStatsMessage = '';
                for (const ore in ORE_LIMITS) {
                    const playerOreCount = playerData.ores[ore] || 0;
                    const playerOreRate = (playerOreCount / playerData.totalBlocksMined) * 100;
                    const worldOreRate = (globalStats[ore] / globalStats.totalMined) * 100 || 0;
                    if (playerOreCount > 0) {
                        oreStatsMessage += ` - §a${ore}§r: §b${playerOreRate.toFixed(2)}% §r(平均: §c${worldOreRate.toFixed(2)}%§r)`;
                    }
                }

                system.run(() => {
                    const player = world.getPlayers({ name: responsiblePlayerId })[0];
                    if (player) {
                        world.sendMessage(`[§bSecurityCraft§r] §b${responsiblePlayerId} §rが§cX-ray§4の可能性（爆発利用）`);
                        world.sendMessage('§e--プレイヤーの鉱石発見率--')
                        world.sendMessage(`${oreStatsMessage}`);
                        let reasonMessage = '';
                        for (const reason in playerData.reasons) {
                            reasonMessage += ` - ${reason}: ${playerData.reasons[reason]}回\n`;
                        }
                        if (reasonMessage) {
                            world.sendMessage('§6---検知の理由---')
                            world.sendMessage(`${reasonMessage}`);
                        }

                        player.setGameMode('Adventure');
                        world.getAllPlayers().forEach(p => {
                            p.playSound('random.toast', { pitch: 0.6, volume: 1.0 });
                        });
                    }
                });
            }
        }
    });

    system.runInterval(() => {
        for (const player in trackedPlayers) {
            // 時間経過で疑いを少しずつ減らす
            if (trackedPlayers[player].suspiciousCount > 0) {
                trackedPlayers[player].suspiciousCount = Math.floor(trackedPlayers[player].suspiciousCount * 0.9);
            }
        }
        savePlacedBlocks();

        const now = Date.now();
        for (const [key, data] of placedExplosives) {
            if (now - data.timestamp > PLACED_BLOCK_EXPIRY) {
                placedExplosives.delete(key);
            }
        }
    }, 600); // 30秒ごとに実行
}

// プレイヤーデータをリセットする関数 (変更なし)
export function resetPlayerXrayData(playerId) {
    if (trackedPlayers[playerId]) {
        delete trackedPlayers[playerId];
        saveTrackedPlayers();
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データをリセットしました。`);
        console.warn(`[SecurityCraft] Reset X-ray data for player: ${playerId}`);
    } else {
        world.sendMessage(`[§bSecurityCraft§r] §b${playerId}§r のX-ray検知データが見つかりませんでした。`);
    }
}
