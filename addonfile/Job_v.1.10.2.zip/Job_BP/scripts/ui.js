import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UpdateConfig, getConfig, DEFAULT_CONFIG } from './system'; // getConfigとDEFAULT_CONFIGもインポート

var player_Cash_Data = {};

// 職業の表示名マッピング
const PROFESSION_DISPLAY_NAMES = {
    livestock: '家畜',
    miner: '鉱夫',
    builder: '林業', // 林業はbuilderタグを使用
    farming: '農業',
    adventurer: '冒険家',
    Angler: '釣り人',
    architect: '建築家', // 新しく追加
    land_leveling: '整地', // 新しく追加
};

// 設定の保存
function saveConfig(config) {
    world.setDynamicProperty('business_config', JSON.stringify(config));
    UpdateConfig(); // system.js のグローバルconfigを更新
}

// メッセージ送信関数
function sendMessage(player, message, success = true) {
    player.sendMessage(`[§b職業システム§r] ${message}`);
    player.playSound('random.toast', { pitch: success ? 1.7 : 0.4, volume: 1.0 });
}

// エフェクトの常時適用
async function applyProfessionEffects(player) {
    const effectsToApply = new Map();
    const professions = getPlayerProfessions(player);
    const config = getConfig();

    professions.forEach(prof => {
        // 建築家はエフェクトがないのでスキップ
        if (prof === 'architect') return;

        const level = player.getDynamicProperty(`${prof}_level`) || 1;
        const rewards = config.levelRewards[prof] || {};

        Object.keys(rewards)
            .map(Number)
            .forEach(lvl => {
                if (lvl <= level) {
                    const selectedEffectId = player.getDynamicProperty(`${prof}_selected_effect_${lvl}`);
                    const isEffectEnabled = player.getDynamicProperty(`${prof}_effect_enabled_${lvl}`) !== false;
                    const reward = rewards[lvl];

                    if (reward.effect && reward.effect.id === selectedEffectId && isEffectEnabled) {
                        const effectId = reward.effect.id;
                        const amplifier = reward.effect.amplifier;

                        if (!effectsToApply.has(effectId) || effectsToApply.get(effectId) < amplifier) {
                            effectsToApply.set(effectId, amplifier);
                        }
                    }
                }
            });
    });

    const allManagedEffectIds = new Set();
    Object.values(config.levelRewards).forEach(profRewards => {
        Object.values(profRewards).forEach(reward => {
            if (reward.effect && reward.effect.id) {
                allManagedEffectIds.add(reward.effect.id);
            }
        });
    });

    // プレイヤーの現在のエフェクトを取得
    const currentEffects = player.getEffects();

    currentEffects.forEach(currentEffect => {
        const effectId = currentEffect.typeId;
        if (allManagedEffectIds.has(effectId) && !effectsToApply.has(effectId)) {
            player.removeEffect(effectId);
        }
    });

    for (const [effectId, amplifier] of effectsToApply.entries()) {
        player.addEffect(effectId, 20 * 50, {
            amplifier: amplifier,
            showParticles: false,
        });
    }
}

world.getAllPlayers().forEach(player => {
    applyProfessionEffects(player);
});

// エフェクトの定期更新
system.runInterval(() => {
    world.getAllPlayers().forEach(player => {
        applyProfessionEffects(player);
    });
}, 20 * 10); // 30秒ごとに更新

// 管理者UI
function showAdminUI(player) {
    if (!player.hasTag('HARUPhoneOP')) {
        sendMessage(player, '§c管理者権限が必要です', false);
        return;
    }

    const form = new ActionFormData().title('§1管理者設定').body('>>> §e選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§0システム設定', 'textures/ui/normalicon1.png').button('§1職業設定', 'textures/ui/normalicon1.png').button('§4職業表示設定', 'textures/ui/normalicon1.png').button('§5プレイヤーの職業レベル変更', 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                showPlayerUI(player);
                return;
            case 1:
                //システム設定
                showSystemConfigUI(player);
                break;
            case 2:
                //職業設定
                showProfessionConfigUI(player);
                break;
            case 3:
                showProfessionVisibilityConfigUI(player);
                break;
            case 4:
                showAdminPlayerLevelSelectUI(player);
                break;
        }
    });
}

// プレイヤー選択UI
function showAdminPlayerLevelSelectUI(adminPlayer) {
    const form = new ActionFormData().title('§1プレイヤー選択').body('>>> §eプレイヤーを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    const onlinePlayers = world.getAllPlayers();
    const playerNames = [];
    onlinePlayers.forEach(p => {
        form.button(`§0${p.name}\n§5>>>§1${p.id}`, 'textures/ui/normalicon1.png');
        playerNames.push(p.name);
    });

    form.show(adminPlayer).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminUI(adminPlayer);
            return;
        }
        const selectedPlayerName = playerNames[response.selection - 1];
        const targetPlayer = world.getAllPlayers().find(p => p.name === selectedPlayerName);

        if (targetPlayer) {
            showAdminProfessionLevelSelectUI(adminPlayer, targetPlayer); // 関数名を変更
        } else {
            sendMessage(adminPlayer, '§cプレイヤーが見つかりませんでした。', false);
            showAdminPlayerLevelSelectUI(adminPlayer);
        }
    });
}

export function setPlayerProfessionLevel(player, profession, level) {
    player.setDynamicProperty(`${profession}_level`, level);
}

export function getPlayerProfessionLevel(player, profession) {
    return player.getDynamicProperty(`${profession}_level`) || 1;
}

// 職業選択UI (関数名を変更)
function showAdminProfessionLevelSelectUI(adminPlayer, targetPlayer) {
    const form = new ActionFormData().title(`§1${targetPlayer.name} の職業選択`).body('>>> §e職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    const professions = Object.keys(PROFESSION_DISPLAY_NAMES);
    professions.forEach(profKey => {
        form.button(`§1${PROFESSION_DISPLAY_NAMES[profKey]}`, 'textures/ui/normalicon1.png');
    });

    form.show(adminPlayer).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminPlayerLevelSelectUI(adminPlayer); // 関数名を変更
            return;
        }
        const selectedProfessionKey = professions[response.selection - 1];
        showAdminLevelChangeInputUI(adminPlayer, targetPlayer, selectedProfessionKey); // 関数名を変更
    });
}

// レベル変更UI (関数名を変更)
function showAdminLevelChangeInputUI(adminPlayer, targetPlayer, profession) {
    const currentLevel = getPlayerProfessionLevel(targetPlayer, profession); // 新しいヘルパー関数を使用
    const form = new ModalFormData().title(`§1${targetPlayer.name} §0の§4${PROFESSION_DISPLAY_NAMES[profession]}レベル変更`).textField('新しいレベル', '数値を入力', currentLevel.toString());

    form.show(adminPlayer).then(response => {
        if (response.canceled) {
            showAdminProfessionLevelSelectUI(adminPlayer, targetPlayer); // 関数名を変更
            return;
        }
        const newLevel = parseInt(response.formValues[0]);

        if (isNaN(newLevel) || newLevel < 1) {
            sendMessage(adminPlayer, '§c無効なレベルです。1以上の数値を入力してください。', false);
            showAdminLevelChangeInputUI(adminPlayer, targetPlayer, profession); // 再度表示 // 関数名を変更
            return;
        }

        setPlayerProfessionLevel(targetPlayer, profession, newLevel); // 新しいヘルパー関数を使用
        sendMessage(adminPlayer, `§a${targetPlayer.name} の ${PROFESSION_DISPLAY_NAMES[profession]} レベルを ${newLevel} に変更しました`);
        showAdminUI(adminPlayer); // 管理者UIに戻る
    });
}

// システム設定UI
function showSystemConfigUI(player) {
    const config = getConfig();
    var form = new ActionFormData();
    form.title('§1システム設定');
    form.body('>>> §e選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button(`§1職業システム\n§0(${config.system.businessSystemEnabled ? '§0有効' : '§4無効'}§0)`, 'textures/ui/normalicon1.png');
    form.button('§1職業解除可能日数', 'textures/ui/normalicon1.png');
    form.button('§4最大職業数', 'textures/ui/normalicon1.png');
    form.button(`§0レベルランキング表示\n§0(${config.system.levelRankingEnabled ? '§0有効' : '§4無効'}§0)`, 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminUI(player);
            return;
        }
        switch (response.selection) {
            case 1:
                toggleJobSystemUI(player);
                break;
            case 2:
                showSystemRemoveDaysUI(player);
                break;
            case 3:
                showSystemMaxProfessionsUI(player);
                break;
            case 4:
                showLevelRankingConfigUI(player);
                break;
        }
    });
}

//職業システム有効無効UI
function toggleJobSystemUI(player) {
    const config = getConfig();
    var form = new ActionFormData();
    form.title('§1職業システム設定');
    form.body('>>> §e選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button(`${config.system.businessSystemEnabled ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemConfigUI(player);
            return;
        }
        const newConfig = getConfig();
        const systemEnabled = !newConfig.system.businessSystemEnabled;
        newConfig.system.businessSystemEnabled = systemEnabled;
        saveConfig(newConfig);
        sendMessage(player, '§a職業システム設定を更新しました');
        showSystemConfigUI(player);
    });
}

//職業解除可能日数UI
function showSystemRemoveDaysUI(player) {
    const config = getConfig();
    const form = new ModalFormData().title('§1職業解除可能日数').textField('職業解除までの日数', '日数を入力', `${config.system.professionRemoveDays}`);

    form.show(player).then(response => {
        if (response.canceled) {
            showSystemConfigUI(player);
            return;
        }
        const [removeDays] = response.formValues;
        const newConfig = getConfig();
        newConfig.system.professionRemoveDays = parseInt(removeDays);
        saveConfig(newConfig);
        sendMessage(player, '§a職業解除可能日数を更新しました');
        showSystemConfigUI(player);
    });
}
//最大職業数変更UI
function showSystemMaxProfessionsUI(player) {
    const config = getConfig();
    const form = new ModalFormData().title('§4最大職業数設定').textField('最大職業数', '数を入力', `${config.system.maxProfessions}`);

    form.show(player).then(response => {
        if (response.canceled) {
            showSystemConfigUI(player);
            return;
        }
        const [maxProfessions] = response.formValues;
        const newConfig = getConfig();
        newConfig.system.maxProfessions = parseInt(maxProfessions);
        saveConfig(newConfig);
        sendMessage(player, '§a最大職業数を更新しました');
        showSystemConfigUI(player);
    });
}

// レベルランキング表示設定UI
function showLevelRankingConfigUI(player) {
    const config = getConfig();
    var form = new ActionFormData();
    form.title('§0レベルランキング表示設定');
    form.body('>>> §e選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');
    form.button(`${config.system.levelRankingEnabled ? '§4無効化' : '§1有効化'}`, 'textures/ui/normalicon1.png');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSystemConfigUI(player);
            return;
        }
        const newConfig = getConfig();
        const systemEnabled = !newConfig.system.levelRankingEnabled;
        newConfig.system.levelRankingEnabled = systemEnabled;
        saveConfig(newConfig);
        sendMessage(player, '§aレベルランキング表示設定を更新しました');
        showSystemConfigUI(player);
    });
}

// 職業設定UI (既存)
function showProfessionConfigUI(player) {
    const form = new ActionFormData()
        .title('§1職業設定')
        .body('>>> §e職業を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1家畜', 'textures/ui/normalicon1.png')
        .button('§1鉱夫', 'textures/ui/normalicon1.png')
        .button('§1林業', 'textures/ui/normalicon1.png')
        .button('§1農業', 'textures/ui/normalicon1.png')
        .button('§1冒険家', 'textures/ui/normalicon1.png')
        .button('§1釣り人', 'textures/ui/normalicon1.png')
        .button('§1建築家', 'textures/ui/normalicon1.png') // 新しく追加
        .button('§1整地', 'textures/ui/normalicon1.png'); // 新しく追加

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminUI(player);
            return;
        }
        const professions = ['livestock', 'miner', 'builder', 'farming', 'adventurer', 'Angler', 'architect', 'land_leveling'];
        const selectedProfession = professions[response.selection - 1];
        showProfessionDetailUI(player, selectedProfession);
    });
}

// 職業詳細設定UI (既存)
function showProfessionDetailUI(player, profession) {
    const newConfig = getConfig();
    const pointsEnabled = newConfig.professions[profession].pointsEnabled;
    const limitEnabled = newConfig.professions[profession].limitEnabled;
    const form = new ActionFormData()
        .title(`§1${PROFESSION_DISPLAY_NAMES[profession]} 設定`)
        .body('>>> §e選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§4ポイント設定', 'textures/ui/normalicon1.png')
        .button('§0レベルアップアクション数設定', 'textures/ui/normalicon1.png')
        .button('§1アクション対象ID設定', 'textures/ui/normalicon1.png')
        .button('§5レベル報酬設定', 'textures/ui/normalicon1.png')
        .button(`§9制限\n§0(${limitEnabled ? '§0有効' : '§4無効'}§0)`, 'textures/ui/normalicon1.png')
        .button(`§9ポイントorレベル付与\n§0(${pointsEnabled ? '§0有効' : '§4無効'}§0)`, 'textures/ui/normalicon1.png');
    if (profession === 'land_leveling') {
        form.button('§1ポイント付与間隔設定', 'textures/ui/normalicon1.png');
    }
    form.show(player).then(response => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0:
                //戻る
                showProfessionConfigUI(player);
                return;
            case 1:
                //ポイント設定
                if (profession === 'architect') {
                    sendMessage(player, '§c建築家にはポイントレベル設定がありません', false);
                    showProfessionDetailUI(player, profession);
                    return;
                }
                showItemPointsConfigUI(player, profession);
                break;
            case 2:
                //レベルアップアクション
                if (profession === 'architect') {
                    sendMessage(player, '§c建築家にはレベルアップアクション数設定がありません', false);
                    showProfessionDetailUI(player, profession);
                    return;
                }
                showLevelUpActionsConfigUI(player, profession);
                break;
            case 3:
                //アイテム編集
                showItemConfigUI(player, profession);
                break;
            case 4:
                if (profession === 'architect') {
                    sendMessage(player, '§c建築家にはレベル報酬設定がありません', false);
                    showProfessionDetailUI(player, profession);
                    return;
                }
                //レベル報酬設定
                showLevelRewardLevelsUI(player, profession);
                break;
            case 5:
                //制限設定
                showProfessionLimitDetailUI(player, profession);
                break;
            case 6:
                if (profession === 'architect') {
                    sendMessage(player, '§c建築家にはポイントorレベル付与の設定がありません', false);
                    showProfessionDetailUI(player, profession);
                    return;
                }
                //ポイントレベル機能 有効無効
                showProfessionPointDetailUI(player, profession);
                break;
            case 7:
                //ポイント付与間隔 (整地のみ)
                if (profession === 'land_leveling') {
                    showPointsPerBreaksUI(player, profession);
                }
                break;
        }
    });
}

function showPointsPerBreaksUI(player, profession) {
    const config = getConfig();
    const professionConfig = config.professions[profession];

    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ポイント付与間隔設定`).textField('ポイント付与間隔（破壊ブロック数）', '数を入力（例：10）', `${professionConfig.pointsPerBreaks || 10}`);

    form.show(player).then(response => {
        if (response.canceled) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        newConfig.professions[profession].pointsPerBreaks = parseInt(response.formValues[0]) || 10;

        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のポイント付与間隔を更新しました`);
        showProfessionDetailUI(player, profession);
    });
}

// アイテムごとのポイント設定UI (既存)
function showItemPointsConfigUI(player, profession) {
    const config = getConfig();
    const items = config.professions[profession].items;
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ポイント設定`).body('設定するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(`§1${item}`, 'textures/ui/icon_crafting.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showItemPointsUI(player, profession, selectedItem);
    });
}

function showItemPointsUI(player, profession, item) {
    const config = getConfig();
    const currentPoints = config.professions[profession].points?.[item] ?? 10;
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ${item} ポイント設定`).textField('ポイント', 'ポイントを入力', currentPoints.toString());

    form.show(player).then(response => {
        if (response.canceled) {
            showItemPointsConfigUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        if (!newConfig.professions[profession].points) newConfig.professions[profession].points = {};
        newConfig.professions[profession].points[item] = parseInt(response.formValues[0]) ?? currentPoints;
        saveConfig(newConfig);
        sendMessage(player, `§a${item}のポイントを更新しました`);
        showItemPointsConfigUI(player, profession);
    });
}

// レベルアップアクション数設定UI (既存)
function showLevelUpActionsConfigUI(player, profession) {
    const config = getConfig();
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベルアップアクション数設定`).textField('アクション数', '必要アクション数を入力', config.professions[profession].levelUpActions.toString());

    form.show(player).then(response => {
        if (response.canceled) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        newConfig.professions[profession].levelUpActions = parseInt(response.formValues[0]) || newConfig.professions[profession].levelUpActions;
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベルアップアクション数を更新しました`);
        showProfessionDetailUI(player, profession);
    });
}

// アイテム/ブロック/モブ設定UI (既存)
function showItemConfigUI(player, profession) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム設定`).body('>>> §e選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1追加', 'textures/ui/normalicon1').button('§0編集', 'textures/ui/normalicon1').button('§4削除', 'textures/ui/normalicon1');

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showProfessionDetailUI(player, profession);
        } else if (response.selection === 1) {
            showAddItemUI(player, profession);
        } else if (response.selection === 2) {
            showEditItemUI(player, profession);
        } else if (response.selection === 3) {
            showDeleteItemUI(player, profession);
        }
    });
}

// アイテム追加UI (既存)
function showAddItemUI(player, profession) {
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム追加`).textField('アイテム/ブロック/モブID', 'IDを入力 (例: minecraft:coal_ore)');

    form.show(player).then(response => {
        if (response.canceled) {
            showItemConfigUI(player, profession);
            return;
        }
        const itemId = response.formValues[0].trim();
        if (itemId) {
            const newConfig = getConfig();
            if (!newConfig.professions[profession].items.includes(itemId)) {
                newConfig.professions[profession].items.push(itemId);
                saveConfig(newConfig);
                sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}に${itemId}を追加しました`);
            } else {
                sendMessage(player, `§c${itemId}はすでに登録されています`, false);
            }
        }
        showItemConfigUI(player, profession);
    });
}

// アイテム編集UI (既存)
function showEditItemUI(player, profession) {
    const config = getConfig();
    const items = config.professions[profession].items;
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム編集`).body('編集するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(`§1${item}`, 'textures/ui/normalicon1.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showItemConfigUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        showEditItemDetailUI(player, profession, selectedItem);
    });
}

// アイテム編集詳細UI (既存)
function showEditItemDetailUI(player, profession, item) {
    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム編集`).textField('新しいID', '新しいIDを入力', item);

    form.show(player).then(response => {
        if (response.canceled) {
            showEditItemUI(player, profession);
            return;
        }
        const newId = response.formValues[0].trim();
        if (newId) {
            const newConfig = getConfig();
            const index = newConfig.professions[profession].items.indexOf(item);
            newConfig.professions[profession].items[index] = newId;
            saveConfig(newConfig);
            sendMessage(player, `§a${item}を${newId}に更新しました`);
        }
        showItemConfigUI(player, profession);
    });
}

// アイテム削除UI (既存)
function showDeleteItemUI(player, profession) {
    const config = getConfig();
    const items = config.professions[profession].items;
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} アイテム削除`).body('削除するアイテムを選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    items.forEach(item => form.button(`§1${item}`, 'textures/ui/normalicon1.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showItemConfigUI(player, profession);
            return;
        }
        const selectedItem = items[response.selection - 1];
        const newConfig = getConfig();
        newConfig.professions[profession].items = newConfig.professions[profession].items.filter(item => item !== selectedItem);
        saveConfig(newConfig);
        sendMessage(player, `§a${selectedItem}を削除しました`);
        showItemConfigUI(player, profession);
    });
}

// レベル報酬レベル選択UI (既存)
function showLevelRewardLevelsUI(player, profession) {
    const config = getConfig();
    const levels = Object.keys(config.levelRewards[profession])
        .map(Number)
        .sort((a, b) => a - b);
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル報酬設定`).body('設定するレベルを選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1新規レベル追加', 'textures/ui/plus.png'); // 新規追加ボタンを緑で強調

    levels.forEach(level => form.button(`§1レベル ${level}`, 'textures/ui/icon_book_writable.png'));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionDetailUI(player, profession);
        } else if (response.selection === 1) {
            showAddLevelRewardUI(player, profession);
        } else {
            const selectedLevel = levels[response.selection - 2];
            showLevelRewardActionUI(player, profession, selectedLevel); // 編集/削除選択UIへ
        }
    });
}

// レベル報酬のアクション選択UI（編集/削除） (既存)
function showLevelRewardActionUI(player, profession, level) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル${level}`).body('>>> §e選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§1編集').button('§4削除');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showLevelRewardLevelsUI(player, profession);
        } else if (response.selection === 1) {
            showLevelRewardDetailUI(player, profession, level);
        } else if (response.selection === 2) {
            showDeleteLevelRewardUI(player, profession, level);
        }
    });
}

// レベル報酬削除UI (既存)
function showDeleteLevelRewardUI(player, profession, level) {
    const form = new ActionFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル${level} 削除`).body(`レベル${level}の報酬を削除しますか？`).button('§4削除').button('§1キャンセル');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 1) {
            showLevelRewardLevelsUI(player, profession);
        } else {
            const newConfig = getConfig();
            delete newConfig.levelRewards[profession][level];
            saveConfig(newConfig);
            sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベル${level}報酬を削除しました`);
            showLevelRewardLevelsUI(player, profession);
        }
    });
}

// 新規レベル報酬追加UI (既存)
function showAddLevelRewardUI(player, profession) {
    const form = new ModalFormData()
        .title(`§1${PROFESSION_DISPLAY_NAMES[profession]} 新規レベル報酬`)
        .textField('レベル', 'レベルを入力 (例: 5)')
        .textField('エフェクト ID (任意)', 'エフェクトID (例: night_vision)', '')
        .textField('エフェクト 強さ (任意)', '強さ (例: 1)', '0')
        .textField('Money (任意)', '付与するMoneyの量', '0')
        .textField('アイテムID (任意)', '付与するアイテムID (例: minecraft:diamond)', '')
        .textField('アイテム数量 (任意)', '付与するアイテムの数量', '1');

    form.show(player).then(response => {
        if (response.canceled) {
            showLevelRewardLevelsUI(player, profession);
            return;
        }
        const [level, effId, effAmp, money, itemId, itemAmount] = response.formValues;
        const newConfig = getConfig();
        const levelNum = parseInt(level);
        if (isNaN(levelNum) || levelNum < 0) {
            sendMessage(player, '§c有効なレベルを入力してください', false);
            showLevelRewardLevelsUI(player, profession);
            return;
        }

        const newReward = {
            effect: effId ? { id: effId.trim(), amplifier: parseInt(effAmp) || 0 } : null,
            money: parseInt(money) || 0,
            items: itemId ? [{ id: itemId.trim(), amount: parseInt(itemAmount) || 1 }] : [],
        };

        newConfig.levelRewards[profession][levelNum] = newReward;
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベル${levelNum}報酬を追加しました`);
        showLevelRewardLevelsUI(player, profession);
    });
}

// レベル報酬詳細UI (編集) (既存)
function showLevelRewardDetailUI(player, profession, level) {
    const config = getConfig();
    const reward = config.levelRewards[profession][level];
    const form = new ModalFormData()
        .title(`§1${PROFESSION_DISPLAY_NAMES[profession]} レベル${level} 報酬編集`)
        .textField('エフェクト ID (任意)', 'エフェクトID', reward.effect?.id || '')
        .textField('エフェクト 強さ (任意)', '強さ', reward.effect?.amplifier?.toString() || '0')
        .textField('Money (任意)', '付与するMoneyの量', reward.money?.toString() || '0')
        .textField('アイテムID (任意)', '付与するアイテムID', reward.items[0]?.id || '')
        .textField('アイテム数量 (任意)', '付与するアイテムの数量', reward.items[0]?.amount?.toString() || '1');

    form.show(player).then(response => {
        if (response.canceled) {
            showLevelRewardLevelsUI(player, profession);
            return;
        }
        const [effId, effAmp, money, itemId, itemAmount] = response.formValues;
        const newConfig = getConfig();

        const newEffectId = effId ? effId.trim() : null;
        const newEffectAmplifier = parseInt(effAmp) || 0;
        const newMoney = parseInt(money) || 0;
        const newItemId = itemId ? itemId.trim() : null;
        const newItemAmount = parseInt(itemAmount) || 1;

        const updatedReward = {
            effect: newEffectId ? { id: newEffectId, amplifier: newEffectAmplifier } : null,
            money: newMoney,
            items: newItemId ? [{ id: newItemId, amount: newItemAmount }] : [],
        };

        newConfig.levelRewards[profession][level] = updatedReward;
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のレベル${level}報酬を更新しました`);

        world.getAllPlayers().forEach(p => {
            const playerProfessionLevel = p.getDynamicProperty(`${profession}_level`) || 1;
            const playerSelectedEffect = p.getDynamicProperty(`${profession}_selected_effect_${level}`);
            if (p.hasTag(profession) && playerProfessionLevel >= level && playerSelectedEffect) {
                p.setDynamicProperty(`${profession}_selected_effect_${level}`, newEffectId);
                applyProfessionEffects(p);
            }
        });

        showLevelRewardLevelsUI(player, profession);
    });
}

// プレイヤーUI（職業選択/ステータス確認/職業解除） (既存)
export function showPlayerUI(player) {
    const config = getConfig();
    if (world.scoreboard.getObjective('money') == undefined) {
        player.sendMessage(`§r[§b職業システム§r] §c初期設定が完了していません`);
        player.sendMessage(`§5>>> §a詳細は配布ページをご確認ください`);
        player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
        return;
    }

    const score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
    const form = new ActionFormData().title('§1職業').body(`>>> §e選択してください`);

    // ボタンと対応するアクションを定義
    const buttons = [];

    if (world.getDynamicProperty('HARUPhone1_System')) {
        buttons.push({ label: '§l戻る', icon: 'textures/ui/icon_import.png', action: () => player.runCommand('scriptevent haruphone1:apps') });
    } else {
        buttons.push({ label: `§9HARUPAY\n§0残高:§s${score}`, icon: 'textures/ui/pay', action: () => HARUPAY(player) });
    }

    // レベルランキングが有効な場合のみボタンを追加
    if (config.system.levelRankingEnabled) {
        buttons.push({ label: '§0レベルランキング', icon: 'textures/ui/normalicon1', action: () => showLevelRankingProfessionSelectUI(player) });
    }

    buttons.push({ label: '§1職業に就く', icon: 'textures/ui/normalicon1', action: () => showProfessionSelectUI(player) });
    buttons.push({ label: '§4職業解除', icon: 'textures/ui/normalicon1', action: () => showProfessionRemoveUI(player) });
    buttons.push({ label: '§5ステータス確認', icon: 'textures/ui/normalicon1', action: () => showStatusUI(player) });
    buttons.push({ label: '§9報酬の受け取り', icon: 'textures/ui/normalicon1', action: () => showProfessionRewardSelectUI(player) });
    buttons.push({ label: '§0エフェクト管理', icon: 'textures/ui/normalicon1', action: () => showEffectToggleUI(player) });

    if (player.hasTag('HARUPhoneOP')) {
        buttons.push({ label: '§0管理者設定', icon: 'textures/ui/operatorcontroller', action: () => showAdminUI(player) });
    }

    // 定義されたボタンをフォームに追加
    buttons.forEach(button => {
        form.button(button.label, button.icon);
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        // 選択されたボタンに対応するアクションを実行
        buttons[response.selection].action();
    });
}

// レベルランキング: 職業選択UI
function showLevelRankingProfessionSelectUI(player) {
    const form = new ActionFormData().title('§0レベルランキング').body('>>> §e表示する職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    // レベルが存在する職業のみをリストアップ (architectは除外)
    const professionsWithLevels = Object.keys(PROFESSION_DISPLAY_NAMES).filter(prof => prof !== 'architect');

    professionsWithLevels.forEach(profKey => {
        form.button(`§1${PROFESSION_DISPLAY_NAMES[profKey]}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        const selectedProfession = professionsWithLevels[response.selection - 1];
        showLevelRankingUI(player, selectedProfession);
    });
}

// レベルランキング: ランキング表示UI
function showLevelRankingUI(player, profession) {
    const allPlayers = world.getAllPlayers();
    const rankedPlayers = [];

    allPlayers.forEach(p => {
        const level = p.getDynamicProperty(`${profession}_level`) || 1;
        rankedPlayers.push({ name: p.name, level: level });
    });

    // レベルの高い順にソート
    rankedPlayers.sort((a, b) => b.level - a.level);

    let bodyText = `§e${PROFESSION_DISPLAY_NAMES[profession]} のレベルランキング\n\n`;
    if (rankedPlayers.length > 0) {
        bodyText += rankedPlayers.map((p, index) => `§f${index + 1}位: §a${p.name} §r- §bレベル ${p.level}`).join('\n');
    } else {
        bodyText += '§7(ランキング対象のプレイヤーがいません)';
    }

    const form = new ActionFormData().title('§0レベルランキング').body(bodyText).button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (!response.canceled) {
            showLevelRankingProfessionSelectUI(player);
        }
    });
}

//HARUPAY (既存)
function HARUPAY(player) {
    player_Cash_Data[player.id] = {};
    //money取得
    var score = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
    //HARUPAY画面
    var form = new ActionFormData();
    form.title(`§1職業`);
    form.body(`§r§6 >>>§a所持金§r:§s${score}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§9送る', `textures/ui/normalicon1`);
    form.button('§4残高リスト', `textures/ui/normalicon1`);
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                showPlayerUI(player);
                break;
            case 1:
                //全プレイヤー取得
                player_Cash_Data[player.id].players = world.getAllPlayers();
                //HARIPAY送信画面
                form = new ActionFormData();
                form.title(`§1職業`);
                form.body(`§r§5 >>>§r送り先のプレイヤーを選択`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                for (let i = 0; i < player_Cash_Data[player.id].players.length; i++) {
                    form.button(`§1${player_Cash_Data[player.id].players[i].name}\n§4>>>§8${player_Cash_Data[player.id].players[i].id}`);
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }

                    if (r.selection == 0) {
                        //戻る
                        HARUPAY(player);
                        return;
                    }
                    //送信先プレイヤーの設定
                    player_Cash_Data[player.id].select_player = player_Cash_Data[player.id].players[r.selection - 1];

                    if (player.id === player_Cash_Data[player.id].players[r.selection - 1].id) {
                        player.sendMessage(`§r[§bHARUPAY§r] §c自分は選択できません`);
                        player.playSound('random.toast', {
                            pitch: 0.4,
                            volume: 1.0,
                        });
                        return;
                    }

                    //送金額設定画面
                    form = new ModalFormData();
                    form.title(`§1職業`);
                    form.textField(`§r§b送金額§r(半角数字)`, '0');
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        }
                        if (isNaN(r.formValues[0])) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4半角数字で入力してください`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        if (r.formValues[0] > 100000000) {
                            player.sendMessage(`§r[§bHARUPAY§r] §4設定した金額は上限をオーバーしています.1億以下で設定してください`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        if (r.formValues[0] < 0) {
                            player.sendMessage(`§r[§bHARUPAY§r] §40以下は設定できません`);
                            player.playSound('random.toast', {
                                pitch: 0.4,
                                volume: 1.0,
                            });
                            return;
                        }
                        //送金額を保存
                        if (r.formValues[0] == '') {
                            player_Cash_Data[player.id].select_money = 0;
                        } else {
                            player_Cash_Data[player.id].select_money = Number(r.formValues[0]);
                        }
                        //playerの残高の取得
                        player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);

                        var form = new ActionFormData();
                        form.title(`§1職業`);
                        form.body(
                            `§a送信先プレイヤー§r:§b${player_Cash_Data[player.id].select_player.name} \n§e送金額§r:§b${player_Cash_Data[player.id].select_money}\n\n§1///////////////////\n§r処理後残高\n§5>>>§u${player_Cash_Data[player.id].money}§r-§2${player_Cash_Data[player.id].select_money}\n§r=§b${
                                player_Cash_Data[player.id].money - player_Cash_Data[player.id].select_money
                            }\n§1///////////////////`
                        );
                        form.button(`§s送金`);
                        form.button(`キャンセル`);
                        form.show(player).then(r => {
                            if (r.canceled) return;
                            switch (r.selection) {
                                case 0:
                                    //playerの残高の取得
                                    player_Cash_Data[player.id].money = world.scoreboard.getObjective('money').getScore(player.scoreboardIdentity);
                                    if (player_Cash_Data[player.id].money >= player_Cash_Data[player.id].select_money) {
                                        //マネー操作
                                        player.runCommand(`scoreboard players remove @s money ${player_Cash_Data[player.id].select_money}`);
                                        player_Cash_Data[player.id].select_player.runCommand(`scoreboard players add @s money ${player_Cash_Data[player.id].select_money}`);

                                        //メッセージ
                                        player.sendMessage(`§r[§bHARUPAY§r] §a${player_Cash_Data[player.id].select_player.name}§rへ§b${player_Cash_Data[player.id].select_money}§rPAY送信されました`);
                                        player_Cash_Data[player.id].select_player.sendMessage(`§r[§bHARUPAY§r] §a${player.name}§rから§b${player_Cash_Data[player.id].select_money}§rPAY受け取りました`);

                                        //通知音
                                        player.playSound('random.toast', {
                                            pitch: 1.7,
                                            volume: 1.0,
                                        });
                                        player_Cash_Data[player.id].select_player.playSound('random.toast', {
                                            pitch: 1.7,
                                            volume: 1.0,
                                        });
                                    } else {
                                        player.sendMessage(`§r[§bHARUPAY§r] §4Moneyが不足しています`);
                                        player.playSound('random.toast', {
                                            pitch: 0.4,
                                            volume: 1.0,
                                        });
                                    }
                                    break;
                            }
                        });
                    });
                });
                break;
            case 2:
                const TITLE = '§1職業' ?? 'ランキング';

                // ランキング表示（スコアボードID・プレイヤー）
                function showRanking(objectiveId, player) {
                    const obj = world.scoreboard.getObjective(objectiveId);
                    if (!obj) {
                        player.sendMessage(`§cスコアボード '${objectiveId}' が見つかりません。`);
                        return;
                    }

                    const onlineNames = [...world.getPlayers()].map(p => p.name);

                    const scores = obj
                        .getScores()
                        .filter(e => e.participant?.displayName)
                        .map(e => {
                            const name = e.participant.displayName;
                            const isOnline = onlineNames.includes(name);
                            return {
                                name: isOnline ? name : '§7(オフライン)',
                                score: e.score,
                            };
                        })
                        .sort((a, b) => b.score - a.score);

                    const text = scores.length === 0 ? '§7（データなし）' : scores.map((e, i) => `§f${i + 1}. ${e.name}：§a${e.score}`).join('\n');

                    new ActionFormData()
                        .title(`${TITLE}`)
                        .body(text)
                        .button('§l戻る', 'textures/ui/icon_import.png')
                        .show(player)
                        .then(res => {
                            if (!res.canceled && res.selection === 0) {
                                HARUPAY(player);
                            }
                        });
                }

                // メインの選択フォーム（money）
                function showRankingSelector(player) {
                    new ActionFormData()
                        .title(`${TITLE}`)
                        .body('表示したいスコアボードを選んでください')
                        .button('§l戻る', 'textures/ui/icon_import.png')
                        .button('§1HARUPAY')
                        .show(player)
                        .then(res => {
                            if (res.canceled) return;

                            switch (res.selection) {
                                case 0:
                                    HARUPAY(player);
                                    break;
                                case 1:
                                    showRanking('money', player);
                                    break;
                            }
                        });
                }
                showRankingSelector(player);
                break;
        }
    });
}

// エフェクトオン/オフUI（新規） (既存)
function showEffectToggleUI(player) {
    const professions = getPlayerProfessions(player);
    const form = new ActionFormData().title('§0エフェクト管理').body('>>> §eエフェクト管理する職業を選択').button('§l戻る', 'textures/ui/icon_import.png');

    professions.forEach(prof => {
        // 建築家はエフェクトなしなのでスキップ
        if (prof === 'architect') {
            return;
        }
        form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        // 建築家をスキップした分のインデックス調整が必要
        const availableProfessions = professions.filter(prof => prof !== 'architect');
        const selectedProfession = availableProfessions[response.selection - 1];
        showProfessionEffectToggleUI(player, selectedProfession);
    });
}

// 職業ごとのエフェクトオン/オフUI（新規） (既存)
function showProfessionEffectToggleUI(player, profession) {
    const level = player.getDynamicProperty(`${profession}_level`) || 1;
    const config = getConfig();
    const rewards = config.levelRewards[profession] || {};
    const availableLevels = Object.keys(rewards)
        .map(Number)
        .filter(lvl => lvl <= level && player.getDynamicProperty(`${profession}_selected_effect_${lvl}`));

    if (availableLevels.length === 0) {
        sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[profession]}でオン/オフ可能なエフェクトがありません`, false);
        showEffectToggleUI(player);
        return;
    }

    const form = new ActionFormData().title(`§4${PROFESSION_DISPLAY_NAMES[profession]} §0エフェクト管理`).body('エフェクトのオン/オフを切り替えてください').button('§l戻る', 'textures/ui/icon_import.png');

    availableLevels.forEach(lvl => {
        const selectedEffect = player.getDynamicProperty(`${profession}_selected_effect_${lvl}`);
        const isEnabled = player.getDynamicProperty(`${profession}_effect_enabled_${lvl}`) !== false;
        const status = isEnabled ? '§1オン' : '§4オフ';
        const reward = rewards[lvl];
        const effectStrength = reward.effect && reward.effect.id === selectedEffect ? reward.effect.amplifier : 1;
        form.button(`§0${selectedEffect} (強さ: ${effectStrength})\n${status}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showEffectToggleUI(player);
            return;
        }
        const selectedLevel = availableLevels[response.selection - 1];
        const isEnabled = player.getDynamicProperty(`${profession}_effect_enabled_${selectedLevel}`) !== false;
        player.setDynamicProperty(`${profession}_effect_enabled_${selectedLevel}`, !isEnabled);
        applyProfessionEffects(player);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]} のエフェクトを${isEnabled ? '§cオフ' : '§eオン'}§aにしました`);
        showProfessionEffectToggleUI(player, profession);
    });
}

// 職業ごとの報酬選択UI (既存)
function showProfessionRewardSelectUI(player) {
    const professions = getPlayerProfessions(player);
    const form = new ActionFormData().title('§1報酬の受け取り').body('>>> §e確認する職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    professions.forEach(prof => {
        // 建築家は報酬なしなのでスキップ
        if (prof === 'architect') {
            return;
        }
        form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        // 建築家をスキップした分のインデックス調整が必要
        const availableProfessions = professions.filter(prof => prof !== 'architect');
        const selectedProfession = availableProfessions[response.selection - 1];
        checkLevelRewards(player, selectedProfession);
    });
}

// 職業選択UI (既存)
function showProfessionSelectUI(player) {
    const config = getConfig();
    const currentProfessions = getPlayerProfessions(player);

    if (currentProfessions.length >= config.system.maxProfessions) {
        sendMessage(player, `§a最大職業数§r:§e${config.system.maxProfessions} §cに達しています先に職業を解除してください`, false);
        showPlayerUI(player);
        return;
    }

    const form = new ActionFormData().title('§1職業選択').body('>>> §e職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    // config.professions.enabled が true の職業のみ表示
    Object.keys(config.professions).forEach(profKey => {
        if (config.professions[profKey].enabled) {
            form.button(`§1${PROFESSION_DISPLAY_NAMES[profKey]}`, 'textures/ui/normalicon1.png');
        }
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }
        // 表示されている職業のキーを抽出し、選択されたインデックスに対応させる
        const enabledProfessions = Object.keys(config.professions).filter(profKey => config.professions[profKey].enabled);
        const selectedProfession = enabledProfessions[response.selection - 1];

        if (currentProfessions.includes(selectedProfession)) {
            sendMessage(player, `§cすでに${PROFESSION_DISPLAY_NAMES[selectedProfession]}に就いています`, false);
            showProfessionSelectUI(player);
            return;
        }

        // 職業に就く前の確認画面を追加
        const confirmForm = new ActionFormData().title('§1職業確認').body(`§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}§rに就きますか？`).button('§4はい', 'textures/ui/confirm.png').button('§1いいえ', 'textures/ui/cancel.png');

        confirmForm.show(player).then(confirmResponse => {
            if (confirmResponse.canceled || confirmResponse.selection === 1) {
                // キャンセルされた場合、元の職業選択UIに戻る
                showProfessionSelectUI(player);
                return;
            }
            player.addTag(selectedProfession);
            player.setDynamicProperty(`profession_join_time_${selectedProfession}`, Date.now());
            sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}に就きました`);
            applyProfessionEffects(player);
            showPlayerUI(player);
        });
    });
}

// 職業解除UI (既存)
function showProfessionRemoveUI(player) {
    const config = getConfig();
    const currentProfessions = getPlayerProfessions(player);
    const now = Date.now();

    if (currentProfessions.length === 0) {
        sendMessage(player, '§c解除する職業がありません', false);
        showPlayerUI(player);
        return;
    }

    const form = new ActionFormData().title('§1職業解除').body('>>> §e職業を選択してください');
    form.button('§l戻る', 'textures/ui/icon_import.png');

    // 各職業の就職日を確認し、解除までの残り日数を計算
    currentProfessions.forEach(prof => {
        const joinTime = player.getDynamicProperty(`profession_join_time_${prof}`);
        let label = '§5解除可能'; // デフォルトは解除可能

        if (joinTime !== undefined) {
            const daysSinceJoin = (now - joinTime) / (1000 * 60 * 60 * 24);
            const daysLeft = config.system.professionRemoveDays - daysSinceJoin;
            if (daysLeft > 0) {
                label = `§0残り §4${daysLeft.toFixed(1)}日`;
            }
        }
        form.button(`§1${PROFESSION_DISPLAY_NAMES[prof]}\n§r${label}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showPlayerUI(player);
            return;
        }

        const selectedProfession = currentProfessions[response.selection - 1];
        const joinTime = player.getDynamicProperty(`profession_join_time_${selectedProfession}`);

        // 選択された職業が解除可能か再度チェック
        if (joinTime !== undefined) {
            const daysSinceJoin = (now - joinTime) / (1000 * 60 * 60 * 24);
            const daysLeft = config.system.professionRemoveDays - daysSinceJoin;
            if (daysLeft > 0) {
                sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[selectedProfession]}の解除まで${daysLeft.toFixed(1)}日必要です`, false);
                showProfessionRemoveUI(player);
                return;
            }
        }

        // 職業解除前の確認画面
        const confirmForm = new ActionFormData().title('§1職業解除確認').body(`§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}§rを解除しますか?`).button('§4はい', 'textures/ui/confirm.png').button('§1いいえ', 'textures/ui/cancel.png');

        confirmForm.show(player).then(confirmResponse => {
            if (confirmResponse.canceled || confirmResponse.selection === 1) {
                showProfessionRemoveUI(player);
                return;
            }

            player.removeTag(selectedProfession);
            // 職業ごとの就職日時データを削除
            player.setDynamicProperty(`profession_join_time_${selectedProfession}`, undefined);
            applyProfessionEffects(player);
            sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}を解除しました`);
            showPlayerUI(player);
        });
    });
}

// プレイヤーの職業を取得 (既存)
function getPlayerProfessions(player) {
    // 全ての職業キーを取得し、プレイヤーがタグを持っているものをフィルタリング
    const config = getConfig();
    return Object.keys(config.professions).filter(profKey => player.hasTag(profKey));
}

// ステータス確認UI (既存)
function showStatusUI(player) {
    const professions = getPlayerProfessions(player);
    const config = getConfig();

    let body = '§e現在の職業とレベル\n';
    if (professions.length > 0) {
        professions.forEach(prof => {
            const level = player.getDynamicProperty(`${prof}_level`) || 1;
            const actions = player.getDynamicProperty(`${prof}_level_actions`) || 0;
            const professionConfig = config.professions[prof];

            // 建築家はポイントレベルがないため、表示を調整
            if (prof === 'architect') {
                body += `§a${PROFESSION_DISPLAY_NAMES[prof]}§r: (ポイントレベルなし)\n`;
            } else {
                body += `§a${PROFESSION_DISPLAY_NAMES[prof]}§r: レベル§b${level} §rアクション §b${actions}§r/§b${professionConfig.levelUpActions}\n`;
                const rewards = config.levelRewards[prof] || {};
                Object.keys(rewards)
                    .map(Number)
                    .forEach(lvl => {
                        if (lvl <= level) {
                            const selectedEffect = player.getDynamicProperty(`${prof}_selected_effect_${lvl}`);
                            const reward = rewards[lvl];
                            let rewardDetails = [];
                            // エフェクトのみを表示する
                            if (selectedEffect) {
                                const effectStrength = reward.effect && reward.effect.id === selectedEffect ? reward.effect.amplifier : 1;
                                rewardDetails.push(`エフェクト: ${selectedEffect} (強さ: ${effectStrength})`);
                            }
                            if (rewardDetails.length > 0) {
                                body += `  §cレベル${lvl}報酬§r: ${rewardDetails.join(', ')}\n`;
                            }
                        }
                    });
            }
        });
    } else {
        body += '§7(現在、職業に就いていません)\n';
    }

    body += '\n§e未所属の職業ステータス\n';
    // 全ての職業キーを取得し、未所属のものをフィルタリング
    const allProfessionKeys = Object.keys(config.professions);
    const unassignedProfessions = allProfessionKeys.filter(profKey => !professions.includes(profKey));

    if (unassignedProfessions.length > 0) {
        unassignedProfessions.forEach(prof => {
            const level = player.getDynamicProperty(`${prof}_level`) || 1;
            const actions = player.getDynamicProperty(`${prof}_level_actions`) || 0;
            const professionConfig = config.professions[prof];

            // 建築家はポイントレベルがないため、表示を調整
            if (prof === 'architect') {
                body += `§7${PROFESSION_DISPLAY_NAMES[prof]}§r: (ポイントレベルなし)\n`;
            } else {
                body += `§7${PROFESSION_DISPLAY_NAMES[prof]}§r: レベル§b${level} §rアクション §b${actions}§r/§b${professionConfig.levelUpActions}\n`;
            }
        });
    } else {
        body += '§7(全ての職業に就いています)\n';
    }

    const form = new ActionFormData().title('§5ステータス').body(body).button('§l戻る', 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (!response.canceled) {
            showPlayerUI(player);
        }
    });
}

// レベル報酬チェックと選択UI (既存)
function checkLevelRewards(player, profession) {
    const level = player.getDynamicProperty(`${profession}_level`) || 1;
    const config = getConfig();
    const rewards = config.levelRewards[profession] || {};
    // 報酬を受け取っていないレベルのみをフィルタリング
    const availableLevels = Object.keys(rewards)
        .map(Number)
        .filter(lvl => lvl <= level && !player.getDynamicProperty(`${profession}_reward_claimed_${lvl}`));

    if (availableLevels.length === 0) {
        sendMessage(player, `§c${PROFESSION_DISPLAY_NAMES[profession]}で受け取り可能な報酬がありません`, false);
        showProfessionRewardSelectUI(player);
        return;
    }

    const form = new ActionFormData().title(`§4${PROFESSION_DISPLAY_NAMES[profession]} §1報酬の受け取り`).body('受け取るレベル報酬を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    availableLevels.forEach(lvl => {
        const reward = rewards[lvl];
        let rewardSummary = [];
        if (reward.effect) {
            rewardSummary.push(`エフェクト: ${reward.effect.id} (強さ: ${reward.effect.amplifier})`);
        }
        if (reward.money > 0) {
            rewardSummary.push(`Money: ${reward.money}`);
        }
        if (reward.items && reward.items.length > 0) {
            reward.items.forEach(item => {
                rewardSummary.push(`アイテム: ${item.id} x${item.amount}`);
            });
        }
        form.button(`§1レベル ${lvl} §4報酬\n§0${rewardSummary.join('\n§0')}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showProfessionRewardSelectUI(player);
            return;
        }
        const selectedLevel = availableLevels[response.selection - 1];
        claimLevelReward(player, profession, selectedLevel);
    });
}

// 報酬の受け取り処理 (既存)
function claimLevelReward(player, profession, level) {
    const config = getConfig();
    const reward = config.levelRewards[profession][level];

    if (!reward) {
        sendMessage(player, `§cレベル${level}の報酬が見つかりません`, false);
        showProfessionRewardSelectUI(player);
        return;
    }

    // エフェクトの付与
    if (reward.effect) {
        player.setDynamicProperty(`${profession}_selected_effect_${level}`, reward.effect.id);
        player.setDynamicProperty(`${profession}_effect_enabled_${level}`, true);
        sendMessage(player, `§r・§eレベル${level}§aのエフェクト§b${reward.effect.id}`);
        applyProfessionEffects(player);
    }

    // Moneyの付与
    if (reward.money > 0) {
        player.runCommandAsync(`scoreboard players add @s money ${reward.money}`);
        sendMessage(player, `§r・§e${reward.money} Money`);
    }

    // アイテムの付与
    if (reward.items && reward.items.length > 0) {
        reward.items.forEach(item => {
            try {
                const itemStack = new ItemStack(item.id, item.amount);
                player.getComponent('inventory').container.addItem(itemStack);
                sendMessage(player, `§r・§b${item.id}§aを§e${item.amount}個`);
            } catch (e) {
                sendMessage(player, `§cアイテム ${item.id} の付与に失敗しました`, false);
            }
        });
    }

    // 報酬を受け取ったことを記録
    player.setDynamicProperty(`${profession}_reward_claimed_${level}`, true);
    sendMessage(player, `§dレベル${level}の報酬を受け取りました！`);
    showProfessionRewardSelectUI(player);
}

world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
    // 全ての職業キーを取得
    const professions = Object.keys(DEFAULT_CONFIG.professions);

    const playerMigrationFlag = `migration_v2_0_0_done_${player.id}`; // プレイヤーごとの移行フラグ
    if (player.getDynamicProperty(playerMigrationFlag) !== true) {
        professions.forEach(prof => {
            const level = player.getDynamicProperty(`${prof}_level`) || 1;
            const config = getConfig(); // 最新のconfigをここで取得
            const rewards = config.levelRewards[prof] || {};

            Object.keys(rewards)
                .map(Number)
                .forEach(lvl => {
                    // 古い _selected_effect_ プロパティが存在し、新しい _reward_claimed_ がまだない場合
                    const oldSelectedEffect = player.getDynamicProperty(`${prof}_selected_effect_${lvl}`);
                    const newRewardClaimed = player.getDynamicProperty(`${prof}_reward_claimed_${lvl}`);

                    if (oldSelectedEffect !== undefined && newRewardClaimed === undefined) {
                        player.setDynamicProperty(`${prof}_reward_claimed_${lvl}`, true);
                        player.setDynamicProperty(`${prof}_effect_enabled_${lvl}`, true);

                        const reward = rewards[lvl];
                        if (reward && reward.effect && reward.effect.id) {
                            player.setDynamicProperty(`${prof}_selected_effect_${lvl}`, oldSelectedEffect);
                        } else {
                            player.setDynamicProperty(`${prof}_selected_effect_${lvl}`, undefined);
                        }
                        player.sendMessage(`§a[システム] §b${PROFESSION_DISPLAY_NAMES[prof]}レベル${lvl}報酬データを移行しました。`);
                    }
                });
        });
        player.setDynamicProperty(playerMigrationFlag, true);
        console.warn(`[職業システム] プレイヤー ${player.name} のデータ移行が完了しました。`);
    }

    applyProfessionEffects(player);
});

// 職業別制限詳細UI
function showProfessionLimitDetailUI(player, profession) {
    const config = getConfig();
    const professionConfig = config.professions[profession];

    const form = new ModalFormData().title(`§5${PROFESSION_DISPLAY_NAMES[profession]} 制限設定`).toggle('制限を有効/無効', professionConfig.limitEnabled);

    // 破壊/設置数制限がある職業のみ表示
    if (professionConfig.limit.maxBreaksPerPeriod !== undefined) {
        form.textField('最大破壊/設置数 (0で無制限)', '数を入力', `${professionConfig.limit.maxBreaksPerPeriod}`);
        form.textField('カウントリセット日数 (0でリセットなし)', '日数を入力', `${professionConfig.limit.periodDays}`);
    }

    form.show(player).then(response => {
        if (response.canceled) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        const newProfessionConfig = newConfig.professions[profession];

        newProfessionConfig.limitEnabled = response.formValues[0];

        if (professionConfig.limit.maxBreaksPerPeriod !== undefined) {
            newProfessionConfig.limit.maxBreaksPerPeriod = parseInt(response.formValues[1]) || 0;
            newProfessionConfig.limit.periodDays = parseInt(response.formValues[2]) || 0;
        }

        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}の制限設定を更新しました`);
        showProfessionDetailUI(player, profession);
    });
}

// 職業別ポイント詳細UI
function showProfessionPointDetailUI(player, profession) {
    const config = getConfig();
    const professionConfig = config.professions[profession];

    const form = new ModalFormData().title(`§1${PROFESSION_DISPLAY_NAMES[profession]} ポイント設定`).toggle('ポイント付与を有効/無効', professionConfig.pointsEnabled);

    form.show(player).then(response => {
        if (response.canceled) {
            showProfessionDetailUI(player, profession);
            return;
        }
        const newConfig = getConfig();
        newConfig.professions[profession].pointsEnabled = response.formValues[0];
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[profession]}のポイント設定を更新しました`);
        showProfessionDetailUI(player, profession);
    });
}

// 職業表示設定UI (新規追加)
function showProfessionVisibilityConfigUI(player) {
    const config = getConfig();
    const form = new ActionFormData().title('§1職業表示設定').body('>>> §e切り替える職業を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    Object.keys(config.professions).forEach(profKey => {
        const isEnabled = config.professions[profKey].enabled;
        const status = isEnabled ? '§5表示中' : '§0非表示';
        form.button(`§1${PROFESSION_DISPLAY_NAMES[profKey]}\n${status}`, 'textures/ui/normalicon1.png');
    });

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showAdminUI(player);
            return;
        }
        const allProfessionKeys = Object.keys(config.professions);
        const selectedProfession = allProfessionKeys[response.selection - 1];

        const newConfig = getConfig();
        newConfig.professions[selectedProfession].enabled = !newConfig.professions[selectedProfession].enabled;
        saveConfig(newConfig);
        sendMessage(player, `§a${PROFESSION_DISPLAY_NAMES[selectedProfession]}の表示設定を更新しました`);
        showProfessionVisibilityConfigUI(player); // 再表示して変更を反映
    });
}
