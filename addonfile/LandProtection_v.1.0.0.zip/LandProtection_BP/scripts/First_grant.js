import { world, system, ItemStack } from '@minecraft/server';

export function First_grant() {
    world.afterEvents.playerSpawn.subscribe(event => {
        const player = event.player;

        // 初回スポーンの場合のみ処理
        if (event.initialSpawn) {
            // システムが有効かつプレイヤーがHARUPAY_Memberタグを持っていない場合
            if (world.getDynamicProperty('Land_Start') === true && !player.hasTag('Land_Member')) {
                system.runTimeout(() => {
                    try {
                        // ネイティブAPIで処理
                        player.getComponent('inventory').container.addItem(new ItemStack('additem:land', 1));
                        player.addTag('Land_Member');
                    } catch (error) {
                        console.warn(`自動付与に失敗しました:対象${player.name} 再リクエストします`);
                        system.runTimeout(() => {
                            try {
                                player.getComponent('inventory').container.addItem(new ItemStack('additem:land', 1));
                                player.addTag('Land_Member');
                            } catch (retryError) {
                                console.warn(`リクエスト実行に失敗しました ${player.name}: ${retryError}`);
                            }
                        }, 70);
                    }
                }, 10);
            }
        }
    });
}
