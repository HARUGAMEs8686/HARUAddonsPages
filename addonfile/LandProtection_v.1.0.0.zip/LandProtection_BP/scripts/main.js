import { world, system, ItemStack } from '@minecraft/server';
import { Land } from './Land.js';
import { selectingPlayers } from './Land.js';
import { First_grant } from './First_grant.js';

var player_Cash_Data = {};

//スクリプトイベント
const RACE_EVENT_ID = 'haruapps:land';
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === RACE_EVENT_ID) {
            Land(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }

        if (eventData.id === 'op:land') {
            player.addTag('HARUPhoneOP');
            world.setDynamicProperty('Land_Start', true);
            world.setDynamicProperty('HARUPhone1_System', false);
            player.sendMessage('§r[§b土地§r] §aシステムを起動しました');

            const players = world.getAllPlayers();
            for (const player of players) {
                if (world.getDynamicProperty('Land_Start') === true && !player.hasTag('Land_Member')) {
                    player.getComponent('inventory').container.addItem(new ItemStack('additem:land', 1));
                    player.addTag('Land_Member');
                }
            }
        }

        if (eventData.id === 'stop:land') {
            world.setDynamicProperty('Land_Start', false);
            player.sendMessage('§r[§b土地§r] §a自動付与システムを無効にしました');
        }
    });
});

//初期設定
if (world.getDynamicProperty('socialsystem_open') == undefined) {
    world.setDynamicProperty('socialsystem_open', false);
}
if (world.getDynamicProperty('socialsystem_not') == undefined) {
    world.setDynamicProperty('socialsystem_not', false);
}
if (world.getDynamicProperty('socialsystem_mynot') == undefined) {
    world.setDynamicProperty('socialsystem_mynot', true);
}
if( world.getDynamicProperty('land_min_y') == undefined){
    world.setDynamicProperty('land_min_y', -64);
}
if( world.getDynamicProperty('land_max_y') == undefined){
    world.setDynamicProperty('land_max_y', 320);
}

//アイテムでの実行
world.beforeEvents.itemUse.subscribe(eventData => {
    if (eventData.itemStack.typeId === 'additem:land') {
        const player = eventData.source;
        system.run(() => {
            // 登録モード中のプレイヤーでなければ何もしない
            if (selectingPlayers.has(player.id)) {
                return;
            }
            Land(player);
        });
    }
});

First_grant();
