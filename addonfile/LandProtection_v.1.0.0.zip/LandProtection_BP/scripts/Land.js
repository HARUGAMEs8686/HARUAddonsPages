/**
 * Land.js with Economy Mode
 * Updated based on user request
 */

import { world, system, Player } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';

// --- Constants & Keys ---
const LAND_INDEX_KEY = 'land_index';
const LAND_PREFIX = 'land_';
const SHOP_INDEX_KEY = 'shop_index'; // ショップのインデックスキー
const SHOP_PREFIX = 'shop_'; // ショップデータの接頭辞

// Economy Settings Keys
const KEY_ECONOMY_MODE = 'eco_mode';
const KEY_PRICE_PER_BLOCK = 'eco_price_per_block';

export const selectingPlayers = new Map();
const interactionCooldown = new Map();

// --- Helper Functions: Land Data ---

function getLandIds() {
    const data = world.getDynamicProperty(LAND_INDEX_KEY);
    return data ? JSON.parse(data) : [];
}

function saveLandIds(ids) {
    world.setDynamicProperty(LAND_INDEX_KEY, JSON.stringify(ids));
}

function getLand(landId) {
    const data = world.getDynamicProperty(LAND_PREFIX + landId);
    return data ? JSON.parse(data) : null;
}

function saveLand(landId, landData) {
    world.setDynamicProperty(LAND_PREFIX + landId, JSON.stringify(landData));
}

function addNewLand(landId, landData) {
    const ids = getLandIds();
    if (!ids.includes(landId)) {
        ids.push(landId);
        saveLandIds(ids);
    }
    saveLand(landId, landData);
}

function deleteLand(landId) {
    let ids = getLandIds();
    const index = ids.indexOf(landId);
    if (index > -1) {
        ids.splice(index, 1);
        saveLandIds(ids);
    }
    world.setDynamicProperty(LAND_PREFIX + landId, undefined);

    // 土地削除時はショップからも削除
    removeShopListing(landId);
}

function getLands() {
    const ids = getLandIds();
    const lands = {};
    for (const id of ids) {
        const landData = getLand(id);
        if (landData) {
            lands[id] = landData;
        }
    }
    return lands;
}

function findLandAt(location, dimensionId) {
    const landIds = getLandIds();
    for (const landId of landIds) {
        const land = getLand(landId);
        if (!land || land.dimension !== dimensionId) continue;

        if (Array.isArray(land.regions)) {
            for (const region of land.regions) {
                const minX = Math.min(region.start.x, region.end.x);
                const maxX = Math.max(region.start.x, region.end.x);
                const minZ = Math.min(region.start.z, region.end.z);
                const maxZ = Math.max(region.start.z, region.end.z);
                if (location.x >= minX && location.x < maxX + 1 && location.z >= minZ && location.z < maxZ + 1) {
                    return { id: landId, ...land };
                }
            }
        }
    }
    return null;
}

// --- Helper Functions: Economy & Shop ---

function isEconomyEnabled() {
    return !!world.getDynamicProperty(KEY_ECONOMY_MODE);
}

function getPricePerBlock() {
    return world.getDynamicProperty(KEY_PRICE_PER_BLOCK) ?? 10; // デフォルト10
}

function getPlayerMoney(player) {
    const sb = world.scoreboard.getObjective('money');
    if (!sb) return 0;
    try {
        return sb.getScore(player) || 0;
    } catch {
        return 0;
    }
}

function addPlayerMoney(player, amount) {
    const sb = world.scoreboard.getObjective('money');
    if (!sb) return;
    try {
        sb.addScore(player, amount);
    } catch (e) {}
}

function reducePlayerMoney(player, amount) {
    const sb = world.scoreboard.getObjective('money');
    if (!sb) return false;
    const current = getPlayerMoney(player);
    if (current < amount) return false;

    // addScoreに負の値を渡すか、setScoreするか。安全のため計算してset
    sb.setScore(player, current - amount);
    return true;
}

// Shop Data Logic (Decomposed to avoid limits)
function getShopIds() {
    const data = world.getDynamicProperty(SHOP_INDEX_KEY);
    return data ? JSON.parse(data) : [];
}

function saveShopIds(ids) {
    world.setDynamicProperty(SHOP_INDEX_KEY, JSON.stringify(ids));
}

function getShopListing(landId) {
    const data = world.getDynamicProperty(SHOP_PREFIX + landId);
    return data ? JSON.parse(data) : null;
}

function addShopListing(landId, price, sellerId, sellerName) {
    const ids = getShopIds();
    if (!ids.includes(landId)) {
        ids.push(landId);
        saveShopIds(ids);
    }
    const listing = { landId, price, sellerId, sellerName, listedAt: Date.now() };
    world.setDynamicProperty(SHOP_PREFIX + landId, JSON.stringify(listing));
}

function removeShopListing(landId) {
    const ids = getShopIds();
    const index = ids.indexOf(landId);
    if (index > -1) {
        ids.splice(index, 1);
        saveShopIds(ids);
    }
    world.setDynamicProperty(SHOP_PREFIX + landId, undefined);
}

// --- Main Menu ---

export function Land(player) {
    const form = new ActionFormData().title('§1土地メニュー').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1新しい土地', 'textures/ui/bubble_empty').button('§4土地管理', 'textures/ui/bubble_empty').button('§5現在地情報', 'textures/ui/bubble_empty');

    // 経済モードがONならショップボタン表示
    if (isEconomyEnabled()) {
        form.button('§1土地ショップ', 'textures/ui/bubble_empty');
    }

    if (player.hasTag('HARUPhoneOP')) {
        form.button('§0管理者設定', 'textures/ui/icon_setting');
    }

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;

        // ボタンのインデックス調整
        let btnIndex = 0; // 戻る = 0
        const NEW_LAND = 1;
        const MANAGE_LAND = 2;
        const CHECK_INFO = 3;

        let SHOP = -1;
        if (isEconomyEnabled()) SHOP = 4;

        let ADMIN = isEconomyEnabled() ? 5 : 4;

        switch (selection) {
            case 0:
                player.runCommand('scriptevent haruphone1:apps');
                break;
            case NEW_LAND:
                startLandSelection(player);
                break;
            case MANAGE_LAND:
                manageMyLands(player);
                break;
            case CHECK_INFO:
                checkLandInfo(player);
                break;
            case SHOP:
                if (SHOP !== -1) LandShop(player);
                break;
            case ADMIN:
                Setting(player);
                break;
        }
    });
}

// --- Shop Menus ---

function LandShop(player) {
    const shopIds = getShopIds();
    const form = new ActionFormData()
        .title('§1土地ショップ')
        .body(`現在の所持金: §e${getPlayerMoney(player)}`)
        .button('§l戻る', 'textures/ui/icon_import.png');

    const listings = [];
    for (const id of shopIds) {
        const listing = getShopListing(id);
        const land = getLand(id);
        if (listing && land) {
            listings.push({ ...listing, landName: land.name });
            form.button(`§1${land.name}\n§5${listing.price} Money §0- §0${listing.sellerName}`, 'textures/ui/bubble_empty');
        }
    }

    if (listings.length === 0) {
        form.body('§a現在販売されている土地はありません');
    }

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            Land(player);
            return;
        }

        const selectedListing = listings[selection - 1];
        buyLandMenu(player, selectedListing);
    });
}

function buyLandMenu(player, listing) {
    const land = getLand(listing.landId);
    if (!land) {
        player.sendMessage('§cエラー: この土地は存在しなくなったようです');
        removeShopListing(listing.landId);
        return;
    }

    const form = new MessageFormData().title('§1購入確認').body(`以下の土地を購入しますか？\n\n§a土地名: §r${land.name}\n§a販売者: §r${listing.sellerName}\n§a価格: §e${listing.price} G\n\n§7※購入すると所有権があなたに移ります。\n§7※販売者がオンラインである必要があります`).button2('§1購入する').button1('§0キャンセル');

    form.show(player).then(({ selection }) => {
        if (selection !== 1) {
            // 1 = Buy
            LandShop(player);
            return;
        }

        // 1. お金チェック
        if (getPlayerMoney(player) < listing.price) {
            player.sendMessage('§r[§b土地§r]  お金が足りません');
            return;
        }

        // 2. 販売者オンラインチェック
        const seller = world.getPlayers().find(p => p.id === listing.sellerId);
        if (!seller) {
            player.sendMessage(`§r[§b土地§r]  販売者(${listing.sellerName})がオフラインのため、現在購入できません`);
            return;
        }

        // 3. 取引実行
        if (reducePlayerMoney(player, listing.price)) {
            addPlayerMoney(seller, listing.price);

            // 所有権移転
            land.owner = player.id;
            land.ownerName = player.name;
            land.sharedPlayers = []; // 共有者はリセット
            land.shareAll = false;
            saveLand(listing.landId, land);

            // ショップから削除
            removeShopListing(listing.landId);

            player.sendMessage(`§r[§b土地§r] 土地「${land.name}」を ${listing.price} Gで購入しました`);
            seller.sendMessage(`§r[§b土地§r] あなたの土地「${land.name}」が ${player.name} に購入され、${listing.price} G受け取りました`);
        } else {
            player.sendMessage('§r[§b土地§r] 処理中にエラーが発生しました');
        }
    });
}

function sellLandMenu(player, landId) {
    const land = getLand(landId);
    if (!land) return;

    // 既に販売中かチェック
    const existing = getShopListing(landId);
    if (existing) {
        const form = new MessageFormData().title('§1販売設定').body(`この土地は現在 §e${existing.price} G §rで販売中です。販売を取り消しますか？`).button2('§4販売取り消し').button1('§0戻る');

        form.show(player).then(({ selection }) => {
            if (selection === 1) {
                removeShopListing(landId);
                player.sendMessage('§r[§b土地§r]  販売を取り消しました');
                manageMyLands(player);
            } else {
                landOptionsMenu(player, landId);
            }
        });
        return;
    }

    const form = new ModalFormData().title('§1土地を販売').textField('販売価格を入力してください', '例: 1000');

    form.show(player).then(res => {
        if (res.canceled) {
            landOptionsMenu(player, landId);
            return;
        }

        const priceStr = res.formValues[0];
        const price = parseInt(priceStr, 10);

        if (isNaN(price) || price < 0) {
            player.sendMessage('§r[§b土地§r]  正しい数値を入力してください');
            return;
        }

        addShopListing(landId, price, player.id, player.name);
        player.sendMessage(`§r[§b土地§r]  土地「${land.name}」を §e${price} G §aでショップに出品しました`);
    });
}

// --- Admin Settings ---

function Setting(player) {
    const form = new ActionFormData().title('§0管理者設定').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§0HARUPhone1連携設定', 'textures/ui/bubble_empty').button('§4管理者用土地管理', 'textures/ui/bubble_empty').button('§0保護Y座標設定', 'textures/ui/bubble_empty').button('§1経済設定', 'textures/ui/bubble_empty');

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;

        switch (selection) {
            case 0:
                Land(player);
                break;
            case 1:
                HARUPhone1_Setting(player);
                break;
            case 2:
                adminLandMenu(player);
                break;
            case 3:
                manageProtectionY(player);
                break;
            case 4:
                EconomySetting(player);
                break;
        }
    });
}

function EconomySetting(player) {
    const isEnabled = isEconomyEnabled();
    const currentPrice = getPricePerBlock();

    const form = new ActionFormData()
        .title('§1経済設定')
        .body(`現在: ${isEnabled ? '§a有効' : '§c無効'}\n§r1ブロックあたりの価格: §e${currentPrice} Money`)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button(`${isEnabled ? '§4無効化' : '§1有効化'}`, 'textures/ui/bubble_empty')
        .button('§0価格設定 (1ブロック)', 'textures/ui/bubble_empty');

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;

        switch (selection) {
            case 0:
                Setting(player);
                break;
            case 1:
                world.setDynamicProperty(KEY_ECONOMY_MODE, !isEnabled);
                player.sendMessage(`§r[§b土地§r] §a経済モードを ${!isEnabled ? '有効' : '無効'} にしました`);
                EconomySetting(player);
                break;
            case 2:
                const modal = new ModalFormData().title('§0価格設定').textField('1ブロックあたりの価格 (小数可)', '例: 1.5', String(currentPrice));

                modal.show(player).then(res => {
                    if (res.canceled) {
                        EconomySetting(player);
                        return;
                    }
                    const val = parseFloat(res.formValues[0]);
                    if (isNaN(val) || val < 0) {
                        player.sendMessage('§r[§b土地§r] §c不正な値です');
                    } else {
                        world.setDynamicProperty(KEY_PRICE_PER_BLOCK, val);
                        player.sendMessage(`§r[§b土地§r] §a単価を ${val} Money に設定しました`);
                    }
                    EconomySetting(player);
                });
                break;
        }
    });
}

// --- Modified Existing Functions ---

// 保護Y座標設定メニュー
function manageProtectionY(player) {
    const minY = world.getDynamicProperty('land_min_y') ?? -64;
    const maxY = world.getDynamicProperty('land_max_y') ?? 320;

    const form = new ModalFormData().title('§1保護Y座標設定').textField('保護する最低Y座標', '数値を入力', String(minY)).textField('保護する最高Y座標', '数値を入力', String(maxY));

    form.show(player).then(r => {
        if (r.canceled) {
            Setting(player);
            return;
        }

        const [newMinYStr, newMaxYStr] = r.formValues;
        const newMinY = parseInt(newMinYStr, 10);
        const newMaxY = parseInt(newMaxYStr, 10);

        if (isNaN(newMinY) || isNaN(newMaxY)) {
            player.sendMessage('§r[§b土地§r] §cエラー: Y座標には数値を入力してください');
            manageProtectionY(player);
            return;
        }

        if (newMinY >= newMaxY) {
            player.sendMessage('§r[§b土地§r] §cエラー: 最低Y座標は最高Y座標より小さい値を設定してください');
            manageProtectionY(player);
            return;
        }
        world.setDynamicProperty('land_min_y', newMinY);
        world.setDynamicProperty('land_max_y', newMaxY);

        player.sendMessage(`§r[§b土地§r] §a保護Y座標を ${newMinY} から ${newMaxY} に設定しました`);
        Setting(player);
    });
}

function Setting_Status(status) {
    if (status) {
        return '§4禁止';
    } else {
        return '§1許可';
    }
}
function HARUPhone1_Setting(player) {
    const form = new ActionFormData()
        .title('§0管理者設定')
        .body('>>> §e選択してください')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button(`§0未購入の土地での保護\n(${Setting_Status(world.getDynamicProperty('socialsystem_not'))}§0)`, 'textures/ui/bubble_empty')
        .button(`§4公共土地での保護\n§0(${Setting_Status(world.getDynamicProperty('socialsystem_open'))}§0)`, 'textures/ui/bubble_empty')
        .button(`§5未所属の土地での保護\n§0(${Setting_Status(world.getDynamicProperty('socialsystem_mynot'))}§0)`, 'textures/ui/bubble_empty');
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;

        switch (selection) {
            case 0:
                Setting(player);
                break;
            case 1:
                if (world.getDynamicProperty('socialsystem_not')) {
                    world.setDynamicProperty('socialsystem_not', false);
                } else {
                    world.setDynamicProperty('socialsystem_not', true);
                }
                break;
            case 2:
                if (world.getDynamicProperty('socialsystem_open')) {
                    world.setDynamicProperty('socialsystem_open', false);
                } else {
                    world.setDynamicProperty('socialsystem_open', true);
                }
                break;
            case 3:
                if (world.getDynamicProperty('socialsystem_mynot')) {
                    world.setDynamicProperty('socialsystem_mynot', false);
                } else {
                    world.setDynamicProperty('socialsystem_mynot', true);
                }
                break;
        }

        if (selection !== 0) {
            player.playSound('random.toast', {
                pitch: 1.7,
                volume: 1.0,
            });
            HARUPhone1_Setting(player);
        }
    });
}
function isLandOverlapping(newStart, newEnd, dimensionId, excludeLandId = null) {
    const landIds = getLandIds();
    const newMinX = Math.min(newStart.x, newEnd.x);
    const newMaxX = Math.max(newStart.x, newEnd.x);
    const newMinZ = Math.min(newStart.z, newEnd.z);
    const newMaxZ = Math.max(newStart.z, newEnd.z);
    for (const landId of landIds) {
        if (landId === excludeLandId) continue;
        const land = getLand(landId);
        if (!land || land.dimension !== dimensionId || !Array.isArray(land.regions)) continue;
        for (const region of land.regions) {
            const existingMinX = Math.min(region.start.x, region.end.x);
            const existingMaxX = Math.max(region.start.x, region.end.x);
            const existingMinZ = Math.min(region.start.z, region.end.z);
            const existingMaxZ = Math.max(region.start.z, region.end.z);
            const overlapX = newMinX <= existingMaxX && newMaxX >= existingMinX;
            const overlapZ = newMinZ <= existingMaxZ && newMaxZ >= existingMinZ;
            if (overlapX && overlapZ) {
                return true;
            }
        }
    }
    return false;
}
function startLandSelection(player) {
    if (selectingPlayers.has(player.id)) {
        selectingPlayers.delete(player.id);
        player.sendMessage('§r[§b土地§r] §e土地の範囲選択をキャンセルしました');
        return;
    }
    selectingPlayers.set(player.id, { step: 1, cancelStrikes: 0, mode: 'new' });
    player.sendMessage('§r[§b土地§r] §a土地保護の範囲選択を開始します');
    player.sendMessage('§r[§b土地§r] §a[1/2] 始点となるブロックをインタラクトしてください');
    player.sendMessage('§7(アイテムを3回使うことで中断できます)');
}
function startAddRegionSelection(player, landId, isAdmin = false) {
    if (selectingPlayers.has(player.id)) {
        selectingPlayers.delete(player.id);
        player.sendMessage('§r[§b土地§r] §e他の範囲選択をキャンセルしました');
    }
    selectingPlayers.set(player.id, { step: 1, cancelStrikes: 0, mode: 'add', landId: landId, isAdmin: isAdmin });
    player.sendMessage('§r[§b土地§r] §a追加する土地の範囲選択を開始します');
    player.sendMessage('§r[§b土地§r] §a[1/2] 始点となるブロックをインタラクトしてください');
    player.sendMessage('§7(アイテムを3回使うことで中断できます)');
}

// 修正: 土地作成時のプロンプト (経済対応)
function promptLandDetails(player, start, end) {
    player.runCommand(`scriptevent country:now @s`);
    system.run(() => {
        if (player.hasTag('open_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_open')) {
            player.sendMessage('[§b社会システム§r] §c公共土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }
        if (player.hasTag('not_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_not')) {
            player.sendMessage('[§b社会システム§r] §c未購入の土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }
        if (player.hasTag('notmy_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_mynot')) {
            player.sendMessage('[§b社会システム§r] §c未所属の土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }

        // 面積計算
        const width = Math.abs(end.x - start.x) + 1;
        const length = Math.abs(end.z - start.z) + 1;
        const area = width * length;

        let cost = 0;
        let ecoEnabled = isEconomyEnabled();
        if (ecoEnabled) {
            cost = Math.round(area * getPricePerBlock());
        }

        const form = new ModalFormData().title('§0新しい土地の保護').textField('保護の名前 (例: 自宅)', '土地の名前を入力');
        form.show(player).then(r => {
            if (r.canceled) {
                player.sendMessage('§r[§b土地§r] §c土地保護をキャンセルしました');
                return;
            }
            const [name] = r.formValues;
            if (!name) {
                player.sendMessage('§r[§b土地§r] §cエラー: 名前を入力してください');
                return;
            }

            let bodyText = `§e以下の内容で土地を保護しますか？§r\n\n名前: §a${name}§r\n範囲(XZ): §a(${start.x}, ${start.z})§r から §a(${end.x}, ${end.z})§r まで\n面積: §a${area}ブロック§r`;

            if (ecoEnabled) {
                bodyText += `\n\n§e価格: §a${cost} G§r (所持金: ${getPlayerMoney(player)} G)`;
            }

            const confirmForm = new MessageFormData()
                .title('§1保護の確認')
                .body(bodyText)
                .button2(ecoEnabled ? `§1購入 (${cost} G)` : '§1保護')
                .button1('§0キャンセル');

            confirmForm.show(player).then(r => {
                if (r.selection !== 1) {
                    player.sendMessage('§r[§b土地§r] §c土地保護をキャンセルしました');
                    return;
                }

                if (isLandOverlapping(start, end, player.dimension.id)) {
                    player.sendMessage('§r[§b土地§r] §c指定された範囲は、他の保護された土地と重複しています');
                    return;
                }

                // お金処理
                if (ecoEnabled) {
                    if (!reducePlayerMoney(player, cost)) {
                        player.sendMessage(`§c[§b土地§r] §cお金が足りません (必要: ${cost} G, 所持: ${getPlayerMoney(player)} G)`);
                        return;
                    }
                }

                const landId = `land_${Date.now()}`;
                const newLandData = {
                    name: name,
                    owner: player.id,
                    ownerName: player.name,
                    dimension: player.dimension.id,
                    regions: [
                        {
                            start: { x: start.x, y: -64, z: start.z },
                            end: { x: end.x, y: 320, z: end.z },
                        },
                    ],
                    sharedPlayers: [],
                    shareAll: false,
                };
                addNewLand(landId, newLandData);
                player.sendMessage(`§r[§b土地§r] §a土地「${name}」を保護しました${ecoEnabled ? ` (${cost} G)` : ''}`);
            });
        });
    });
}

// 修正: 範囲追加時のプロンプト (経済対応)
function addRegionToLand(player, landId, start, end) {
    const land = getLand(landId);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §c対象の土地が見つかりませんでした');
        return;
    }
    player.runCommand(`scriptevent country:now @s`);
    system.run(() => {
        if (player.hasTag('open_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_open')) {
            player.sendMessage('[§b社会システム§r] §c公共土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }
        if (player.hasTag('not_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_not')) {
            player.sendMessage('[§b社会システム§r] §c未購入の土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }
        if (player.hasTag('notmy_country_now') && !player.hasTag('LandOP') && world.getDynamicProperty('socialsystem_mynot')) {
            player.sendMessage('[§b社会システム§r] §c未所属の土地での保護操作は許可されていません');
            player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
            return;
        }

        // 面積・コスト計算
        const width = Math.abs(end.x - start.x) + 1;
        const length = Math.abs(end.z - start.z) + 1;
        const area = width * length;

        let cost = 0;
        let ecoEnabled = isEconomyEnabled();
        if (ecoEnabled) {
            cost = Math.round(area * getPricePerBlock());
        }

        let bodyText = `§e土地「§a${land.name}§e」に新しい範囲を追加しますか？\n\n追加範囲(XZ): §a(${start.x}, ${start.z})§r から §a(${end.x}, ${end.z})§r まで\n面積: §a${area}ブロック§r`;

        if (ecoEnabled) {
            bodyText += `\n\n§e追加価格: §a${cost} G§r (所持金: ${getPlayerMoney(player)} G)`;
        }

        const confirmForm = new MessageFormData()
            .title('§1範囲追加の確認')
            .body(bodyText)
            .button2(ecoEnabled ? `§1購入 (${cost} G)` : '§1追加')
            .button1('§0キャンセル');

        confirmForm.show(player).then(r => {
            if (r.selection !== 1) {
                player.sendMessage('§r[§b土地§r] §c範囲の追加をキャンセルしました');
                return;
            }
            if (isLandOverlapping(start, end, player.dimension.id, landId)) {
                player.sendMessage('§r[§b土地§r] §c指定された範囲は、他の保護された土地と重複しています');
                return;
            }

            // お金処理
            if (ecoEnabled) {
                if (!reducePlayerMoney(player, cost)) {
                    player.sendMessage(`§c[§b土地§r] §cお金が足りません (必要: ${cost} G)`);
                    return;
                }
            }

            land.regions.push({
                start: { x: start.x, y: -64, z: start.z },
                end: { x: end.x, y: 320, z: end.z },
            });
            saveLand(landId, land);
            player.sendMessage(`§r[§b土地§r] §a土地「${land.name}」に新しい範囲を追加しました`);
        });
    });
}
function manageMyLands(player) {
    const lands = getLands();
    const myLands = Object.entries(lands).filter(([id, data]) => data.owner === player.id);
    if (myLands.length === 0) {
        player.sendMessage('§r[§b土地§r] §cあなたが所有している土地はありません');
        return;
    }
    const form = new ActionFormData().title('§1土地管理').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    myLands.forEach(([id, data]) => {
        const firstRegion = data.regions?.[0];
        const rangeText = firstRegion ? `(X:${firstRegion.start.x}, Z:${firstRegion.start.z}) - ...` : '範囲情報なし';
        form.button(`§0${data.name}\n§1${rangeText}`, 'textures/ui/bubble_empty');
    });
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            Land(player);
            return;
        }
        const [selectedLandId] = myLands[selection - 1];
        landOptionsMenu(player, selectedLandId);
    });
}

function landOptionsMenu(player, landId) {
    const land = getLand(landId);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §cその土地は存在しません');
        return;
    }
    const form = new ActionFormData()
        .title(`§4${land.name}§1の管理`)
        .body('>>> §e選択してください')
        .button(`§l戻る`, 'textures/ui/icon_import.png')
        .button('§1プレイヤー共有', 'textures/ui/bubble_empty')
        .button('§2範囲を追加', 'textures/ui/bubble_empty')
        .button('§4範囲を削除', 'textures/ui/bubble_empty')
        .button('§0名前を変更', 'textures/ui/bubble_empty')
        .button('§4所有権を譲渡', 'textures/ui/bubble_empty')
        .button('§5保護解除', 'textures/ui/bubble_empty');

    // 経済モードなら販売ボタン追加
    if (isEconomyEnabled()) {
        form.button('§1土地を販売', 'textures/ui/bubble_empty');
    }

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            manageMyLands(player);
            return;
        }

        let SELL = -1;
        if (isEconomyEnabled()) SELL = 7;

        switch (selection) {
            case 1:
                shareLandMenu(player, landId);
                break;
            case 2:
                startAddRegionSelection(player, landId);
                break;
            case 3:
                removeRegionMenu(player, landId);
                break;
            case 4:
                renameLand(player, landId);
                break;
            case 5:
                transferLand(player, landId);
                break;
            case 6:
                unprotectLand(player, landId);
                break;
            case SELL:
                if (SELL !== -1) sellLandMenu(player, landId);
                break;
        }
    });
}
function renameLand(player, landId, isAdmin = false) {
    const land = getLand(landId);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §cその土地は存在しません');
        return;
    }
    const form = new ModalFormData().title('§0名前の変更').textField('新しい土地の名前', '新しい名前を入力', land.name);
    form.show(player).then(r => {
        if (r.canceled) {
            if (isAdmin) {
                adminLandOptionsMenu(player, landId);
            } else {
                landOptionsMenu(player, landId);
            }
            return;
        }
        const [newName] = r.formValues;
        if (!newName) {
            player.sendMessage('§r[§b土地§r] §cエラー: 名前を入力してください');
            return;
        }
        const oldName = land.name;
        land.name = newName;
        saveLand(landId, land);
        player.sendMessage(`§r[§b土地§r] §a土地の名前を「${oldName}」から「${newName}」に変更しました`);

        if (isAdmin) {
            adminLandOptionsMenu(player, landId);
        } else {
            landOptionsMenu(player, landId);
        }
    });
}
function removeRegionMenu(player, landId, isAdmin = false) {
    const land = getLand(landId);
    if (!land || !land.regions) return;
    if (land.regions.length === 0) {
        player.sendMessage('§r[§b土地§r] §c削除できる範囲がありません');
        if (isAdmin) {
            adminLandOptionsMenu(player, landId);
        } else {
            landOptionsMenu(player, landId);
        }
        return;
    }
    const form = new ActionFormData().title('§4削除する範囲を選択').body('§e削除したい範囲を選択してください。\n§c最後の範囲を削除すると、土地の保護自体が解除されます。').button('§l戻る', 'textures/ui/icon_import.png');
    land.regions.forEach((region, index) => {
        form.button(`§1範囲 ${index + 1}\n§0(X:${region.start.x}, Z:${region.start.z}) - (X:${region.end.x}, Z:${region.end.z})`, 'textures/ui/bubble_empty');
    });
    form.show(player).then(({ selection, canceled }) => {
        if (canceled || selection === 0) {
            if (isAdmin) {
                adminLandOptionsMenu(player, landId);
            } else {
                landOptionsMenu(player, landId);
            }
            return;
        }
        const regionIndex = selection - 1;
        const confirmForm = new MessageFormData().title('§4範囲削除の確認').body('§c本当にこの範囲を保護から削除しますか？\nこの操作は元に戻せません。').button2('§4削除').button1('§0キャンセル');
        confirmForm.show(player).then(r => {
            if (r.selection !== 1) {
                removeRegionMenu(player, landId, isAdmin);
                return;
            }
            const landToUpdate = getLand(landId);
            if (!landToUpdate) return;
            landToUpdate.regions.splice(regionIndex, 1);
            if (landToUpdate.regions.length === 0) {
                deleteLand(landId); // ショップからも削除される
                player.sendMessage(`§r[§b土地§r] §a土地「${landToUpdate.name}」の最後の範囲が削除されたため、保護を完全に解除しました`);
            } else {
                saveLand(landId, landToUpdate);
                player.sendMessage(`§r[§b土地§r] §a土地「${landToUpdate.name}」から選択した範囲を削除しました`);
                removeRegionMenu(player, landId, isAdmin);
            }
        });
    });
}
function shareLandMenu(player, landId, isAdmin = false) {
    const form = new ActionFormData().title('§1共有メニュー').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png').button('§1オンラインプレイヤーと共有', 'textures/ui/bubble_empty').button('§5すべてのプレイヤーと共有', 'textures/ui/bubble_empty').button('§4共有解除', 'textures/ui/bubble_empty');
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            if (isAdmin) {
                adminLandOptionsMenu(player, landId);
            } else {
                landOptionsMenu(player, landId);
            }
            return;
        }
        switch (selection - 1) {
            case 0:
                shareWithOnlinePlayer(player, landId, isAdmin);
                break;
            case 1:
                shareWithAll(player, landId, isAdmin);
                break;
            case 2:
                unsharePlayer(player, landId, isAdmin);
                break;
        }
    });
}
function shareWithOnlinePlayer(player, landId, isAdmin = false) {
    const onlinePlayers = world.getPlayers({ exclude: [player] });
    if (onlinePlayers.length === 0) {
        player.sendMessage('§r[§b土地§r] §c共有できる他のプレイヤーがオンラインにいません');
        shareLandMenu(player, landId, isAdmin);
        return;
    }
    const form = new ActionFormData().title('§1共有するプレイヤーを選択').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    onlinePlayers.forEach(p => form.button(`§1${p.name}`, 'textures/ui/bubble_empty'));
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            shareLandMenu(player, landId, isAdmin);
            return;
        }
        const targetPlayer = onlinePlayers[selection - 1];
        const confirmForm = new MessageFormData().title('§1共有の確認').body(`§a${targetPlayer.name} §eと土地を共有しますか？`).button2('§1共有').button1('§0戻る');
        confirmForm.show(player).then(({ selection: confirmSelection }) => {
            if (confirmSelection !== 1) {
                shareWithOnlinePlayer(player, landId, isAdmin);
                return;
            }
            const land = getLand(landId);
            if (land && !land.sharedPlayers.find(p => p.id === targetPlayer.id)) {
                land.sharedPlayers.push({ id: targetPlayer.id, name: targetPlayer.name });
                saveLand(landId, land);
                player.sendMessage(`§r[§b土地§r] §a${targetPlayer.name} と土地を共有しました`);
            } else {
                player.sendMessage(`§r[§b土地§r] §e${targetPlayer.name} とは既に共有済みです`);
            }
            shareLandMenu(player, landId, isAdmin);
        });
    });
}
function shareWithAll(player, landId, isAdmin = false) {
    const confirmForm = new MessageFormData().title('§5共有の確認').body(`本当にすべてのプレイヤーと土地を共有しますか？\n§c誰でもあなたの土地を操作できるようになります`).button2('§1共有').button1('§0戻る');
    confirmForm.show(player).then(({ selection: confirmSelection }) => {
        if (confirmSelection !== 1) {
            shareLandMenu(player, landId, isAdmin);
            return;
        }
        const land = getLand(landId);
        if (land) {
            land.shareAll = true;
            saveLand(landId, land);
            player.sendMessage(`§r[§b土地§r] §aこの土地をすべてのプレイヤーと共有しました`);
            shareLandMenu(player, landId, isAdmin);
        }
    });
}
function unsharePlayer(player, landId, isAdmin = false) {
    const land = getLand(landId);
    if (!land) return;
    const form = new ActionFormData().title('§1共有解除').body('>>> §e解除するプレイヤーを選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    let hasOptions = false,
        shareAllIndex = -1,
        playerShareStartIndex = 0;
    if (land.shareAll) {
        form.button('§4すべてのプレイヤーとの共有を解除', 'textures/ui/bubble_empty');
        hasOptions = true;
        shareAllIndex = 0;
        playerShareStartIndex = 1;
    }
    land.sharedPlayers.forEach(p => {
        form.button(`§1${p.name}`, 'textures/ui/bubble_empty');
        hasOptions = true;
    });
    if (!hasOptions) {
        player.sendMessage('§r[§b土地§r] §c共有しているプレイヤーがいません');
        shareLandMenu(player, landId, isAdmin);
        return;
    }
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            shareLandMenu(player, landId, isAdmin);
            return;
        }
        const landToUpdate = getLand(landId);
        if (!landToUpdate) return;
        if (shareAllIndex === selection - 1) {
            landToUpdate.shareAll = false;
            player.sendMessage('§r[§b土地§r] §aすべてのプレイヤーとの共有を解除しました');
        } else {
            const playerIndex = selection - 1 - playerShareStartIndex;
            const removedPlayer = landToUpdate.sharedPlayers.splice(playerIndex, 1);
            player.sendMessage(`§r[§b土地§r] §a${removedPlayer[0].name} との共有を解除しました`);
        }
        saveLand(landId, landToUpdate);
        shareLandMenu(player, landId, isAdmin);
    });
}
function transferLand(player, landId, isAdmin = false) {
    const onlinePlayers = world.getPlayers({ exclude: [player] });
    if (onlinePlayers.length === 0) {
        player.sendMessage('§r[§b土地§r] §c譲渡できる他のプレイヤーがオンラインにいません');
        return;
    }
    const form = new ActionFormData().title('§4譲渡するプレイヤーを選択').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    onlinePlayers.forEach(p => form.button(`§1${p.name}`, 'textures/ui/bubble_empty'));
    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            if (isAdmin) {
                adminLandOptionsMenu(player, landId);
            } else {
                landOptionsMenu(player, landId);
            }
            return;
        }
        const targetPlayer = onlinePlayers[selection - 1];
        const confirmForm = new MessageFormData().title('§4譲渡確認').body(`§a${targetPlayer.name} §eに土地を譲渡しますか？\n§cこの操作を行うと、あなたはこの土地の所有権を失い、管理できなくなります`).button2('§4譲渡').button1('§0戻る');
        confirmForm.show(player).then(({ selection: confirmSelection }) => {
            if (confirmSelection !== 1) {
                transferLand(player, landId, isAdmin);
                return;
            }
            const land = getLand(landId);
            if (land) {
                land.owner = targetPlayer.id;
                land.ownerName = targetPlayer.name;
                land.sharedPlayers = [];
                land.shareAll = false;
                saveLand(landId, land);

                // 譲渡したらショップ出品は取り下げる
                removeShopListing(landId);

                player.sendMessage(`§r[§b土地§r] §a土地の所有権を ${targetPlayer.name} に譲渡しました`);
                targetPlayer.sendMessage(`§r[§b土地§r] §a${player.name} から土地「${land.name}」の所有権を譲渡されました`);
            }
        });
    });
}
function unprotectLand(player, landId, isAdmin = false) {
    const land = getLand(landId);
    if (!land) return;
    const landName = land.name;

    const confirmForm = new MessageFormData().title('§4保護解除の最終確認').body(`§a${landName}§eの保護を解除しますか？\n§cこの操作は元に戻せません`).button2('§4解除').button1('§0戻る');
    confirmForm.show(player).then(({ selection: confirmSelection }) => {
        if (confirmSelection !== 1) {
            if (isAdmin) {
                adminLandOptionsMenu(player, landId);
            } else {
                landOptionsMenu(player, landId);
            }
            return;
        }
        deleteLand(landId); // ショップからも削除
        player.sendMessage(`§r[§b土地§r] §a土地「${landName}」の保護を解除しました`);
    });
}
function checkLandInfo(player) {
    const land = findLandAt(player.location, player.dimension.id);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §aこの場所は保護されていません');
        return;
    }
    let sharedText = land.shareAll ? 'すべてのプレイヤー' : land.sharedPlayers.length > 0 ? land.sharedPlayers.map(p => p.name).join(', ') : 'なし';
    const regionsText = (land.regions || []).map(region => `§b(${region.start.x}, ${region.start.z}) - (${region.end.x}, ${region.end.z})`).join('\n  ');

    // ショップ情報があれば表示
    let shopInfo = '';
    if (isEconomyEnabled()) {
        const listing = getShopListing(land.id);
        if (listing) {
            shopInfo = `\n§6販売中§r: §e${listing.price} G`;
        }
    }

    const info = `§r§l--- §e土地情報 §r§l---§r\n§a名前§r: §b${land.name}\n§a所有者§r: §b${land.ownerName}\n§a共有者§r: §b${sharedText}\n§a範囲(XZ)§r:\n  ${regionsText}\n§aディメンション§r: §b${land.dimension}${shopInfo}`;
    player.sendMessage(info);
}
function protectionEventHandler(event) {
    if (!(event.player instanceof Player)) return;
    const player = event.player;
    if (player.hasTag('HARUPhoneOP')) return;
    let location = null;
    if ('block' in event && event.block) location = event.block.location;
    else if ('entity' in event && event.entity) location = event.entity.location;
    else return;
    const land = findLandAt(location, player.dimension.id);
    if (land) {
        const minY = world.getDynamicProperty('land_min_y') ?? -64;
        const maxY = world.getDynamicProperty('land_max_y') ?? 320;

        if (location.y < minY || location.y > maxY) {
            return;
        }
        const isOwner = land.owner === player.id;
        const isShared = land.shareAll || land.sharedPlayers.some(p => p.id === player.id);
        if (!isOwner && !isShared) event.cancel = true;
    }
}

//【追加】管理者用メニュー
function adminLandMenu(player) {
    const form = new ActionFormData().title('§4管理者用土地管理').body('>>> §e操作を選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§0すべての土地を一覧表示', 'textures/ui/bubble_empty').button('§1現在地の土地を管理', 'textures/ui/bubble_empty');

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        switch (selection) {
            case 0:
                Setting(player);
                break;
            case 1:
                manageAllLands(player);
                break;
            case 2:
                manageCurrentLandAdmin(player);
                break;
        }
    });
}
function manageAllLands(player) {
    const lands = getLands();
    const allLands = Object.entries(lands);

    if (allLands.length === 0) {
        player.sendMessage('§r[§b土地§r] §c保護されている土地はありません');
        adminLandMenu(player);
        return;
    }

    const form = new ActionFormData().title('§0すべての土地を管理').body('>>> §e管理する土地を選択してください').button('§l戻る', 'textures/ui/icon_import.png');

    allLands.forEach(([id, data]) => {
        form.button(`§0${data.name}\n§1所有者: ${data.ownerName}`, 'textures/ui/bubble_empty');
    });

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            adminLandMenu(player);
            return;
        }
        const [selectedLandId] = allLands[selection - 1];
        adminLandOptionsMenu(player, selectedLandId);
    });
}
function manageCurrentLandAdmin(player) {
    const land = findLandAt(player.location, player.dimension.id);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §aこの場所は保護されていません');
        adminLandMenu(player);
        return;
    }
    player.sendMessage(`§r[§b土地§r] §a現在地の土地「${land.name}」(所有者: ${land.ownerName}) の管理メニューを開きます`);
    adminLandOptionsMenu(player, land.id);
}
function adminLandOptionsMenu(player, landId) {
    const land = getLand(landId);
    if (!land) {
        player.sendMessage('§r[§b土地§r] §cその土地は存在しません');
        manageAllLands(player);
        return;
    }

    const form = new ActionFormData()
        .title(`§4(管) ${land.name} の管理`)
        .body(`§a所有者: ${land.ownerName}\n§r>>> §e操作を選択してください`)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1プレイヤー共有', 'textures/ui/bubble_empty')
        .button('§2範囲を追加', 'textures/ui/bubble_empty')
        .button('§c範囲を削除', 'textures/ui/bubble_empty')
        .button('§0名前を変更', 'textures/ui/bubble_empty')
        .button('§4所有権を譲渡', 'textures/ui/bubble_empty')
        .button('§4§l強制保護解除', 'textures/ui/icon_trash');

    form.show(player).then(({ selection, canceled }) => {
        if (canceled) return;
        if (selection === 0) {
            manageAllLands(player);
            return;
        }
        switch (selection) {
            case 1:
                shareLandMenu(player, landId, true);
                break;
            case 2:
                startAddRegionSelection(player, landId, true);
                break;
            case 3:
                removeRegionMenu(player, landId, true);
                break;
            case 4:
                renameLand(player, landId, true);
                break;
            case 5:
                transferLand(player, landId, true);
                break;
            case 6:
                unprotectLand(player, landId, true);
                break;
        }
    });
}

// --- イベント処理 ---
world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const { player, block } = event;
    if (!selectingPlayers.has(player.id)) {
        protectionEventHandler(event);
        return;
    }
    const now = Date.now();
    const lastInteraction = interactionCooldown.get(player.id) || 0;
    if (now - lastInteraction < 500) return;
    interactionCooldown.set(player.id, now);
    event.cancel = true;
    const selectionState = selectingPlayers.get(player.id);
    if (selectionState.step === 1) {
        selectionState.step = 2;
        selectionState.start = block.location;
        selectingPlayers.set(player.id, selectionState);
        player.sendMessage(`§r[§b土地§r] §a始点を設定しました: (X:${block.location.x}, Z:${block.location.z})`);
        player.sendMessage('§r[§b土地§r] §a[2/2] 次に対角線の終点となるブロックをインタラクトしてください');
    } else if (selectionState.step === 2) {
        const start = selectionState.start;
        const end = block.location;
        const landIdToExclude = selectionState.mode === 'add' ? selectionState.landId : null;
        if (isLandOverlapping(start, end, player.dimension.id, landIdToExclude)) {
            player.sendMessage(`§r[§b土地§r] §a終点を設定しました: (X:${block.location.x}, Z:${block.location.z})`);
            player.sendMessage('§r[§b土地§r] §c指定された範囲は、他の保護された土地と重複しています');
            selectingPlayers.delete(player.id);
            interactionCooldown.delete(player.id);
            return;
        }
        player.sendMessage(`§r[§b土地§r] §a終点を設定しました: (X:${block.location.x}, Z:${block.location.z})`);
        system.run(() => {
            if (selectionState.mode === 'add') {
                addRegionToLand(player, selectionState.landId, start, end);
            } else {
                promptLandDetails(player, start, end);
            }
            system.run(() => {
                selectingPlayers.delete(player.id);
                interactionCooldown.delete(player.id);
            });
        });
    }
});

world.beforeEvents.itemUse.subscribe(event => {
    const player = event.source;
    if (!selectingPlayers.has(player.id)) return;
    event.cancel = true;
    const now = Date.now();
    const lastInteraction = interactionCooldown.get(player.id) || 0;
    if (now - lastInteraction < 500) return;
    interactionCooldown.set(player.id, now);
    const selectionState = selectingPlayers.get(player.id);
    selectionState.cancelStrikes++;
    if (selectionState.cancelStrikes >= 3) {
        selectingPlayers.delete(player.id);
        interactionCooldown.delete(player.id);
        player.sendMessage('§r[§b土地§r] §eアイテムを3回使用したため、土地の範囲選択をキャンセルしました');
    } else {
        selectingPlayers.set(player.id, selectionState);
        const remaining = 3 - selectionState.cancelStrikes;
        player.sendMessage(`§r[§b土地§r] §eあと${remaining}回アイテムを使用するとキャンセルされます`);
    }
});

world.beforeEvents.playerBreakBlock.subscribe(protectionEventHandler);
world.beforeEvents.playerInteractWithEntity.subscribe(protectionEventHandler);

world.beforeEvents.explosion.subscribe(event => {
    const dimension = event.dimension;
    const minY = world.getDynamicProperty('land_min_y') ?? -64;
    const maxY = world.getDynamicProperty('land_max_y') ?? 320;

    const originalImpactedBlocks = event.getImpactedBlocks();
    const allowedImpactedBlocks = originalImpactedBlocks.filter(block => {
        if (block.location.y < minY || block.location.y > maxY) {
            return true;
        }
        return !findLandAt(block.location, dimension.id);
    });
    event.setImpactedBlocks(allowedImpactedBlocks);
});
