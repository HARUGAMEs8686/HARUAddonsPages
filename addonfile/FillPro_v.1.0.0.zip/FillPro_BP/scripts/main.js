import { world, system, CommandPermissionLevel, CustomCommandStatus, CustomCommandParamType, BlockPermutation } from '@minecraft/server';

const BLOCKS_PER_TICK = 64;

system.beforeEvents.startup.subscribe(ev => {
    ev.customCommandRegistry.registerEnum('hd:mode', ['replace', 'keep', 'outline', 'hollow', 'destroy']);
    const fillCommand = {
        name: 'hd:pfill',
        description: '範囲制限のないFillコマンドを実行します',
        permissionLevel: CommandPermissionLevel.GameDirectors,
        mandatoryParameters: [
            { name: 'pos1', type: CustomCommandParamType.Location },
            { name: 'pos2', type: CustomCommandParamType.Location },
            { name: 'blockId', type: CustomCommandParamType.BlockType },
        ],
        optionalParameters: [
            { name: 'hd:mode', type: CustomCommandParamType.Enum },
            { name: 'replaceBlockId', type: CustomCommandParamType.BlockType },
        ],
    };

    // コマンドの処理関数を登録
    ev.customCommandRegistry.registerCommand(fillCommand, (origin, pos1, pos2, blockId, mode, replaceBlockId) => {
        if (origin.sourceEntity?.typeId !== 'minecraft:player') {
            return {
                status: CustomCommandStatus.Failure,
                message: '実行者はプレイヤーである必要があります',
            };
        }

        const player = origin.sourceEntity;
        mode = mode ? mode.toLowerCase() : 'replace';

        const x1 = Math.floor(pos1.x);
        const y1 = Math.floor(pos1.y);
        const z1 = Math.floor(pos1.z);
        const x2 = Math.floor(pos2.x);
        const y2 = Math.floor(pos2.y);
        const z2 = Math.floor(pos2.z);

        const ensureNamespace = id => {
            const idString = typeof id === 'object' ? id.id : id;
            return idString.includes(':') ? idString : `minecraft:${idString}`;
        };

        let blockPerm;
        try {
            blockPerm = BlockPermutation.resolve(ensureNamespace(blockId));
        } catch (e) {
            return {
                status: CustomCommandStatus.Failure,
                message: `ブロックID "${blockId}" が見つかりません`,
            };
        }

        const fullReplaceBlockId = replaceBlockId ? ensureNamespace(replaceBlockId) : null;

        const minX = Math.min(x1, x2),
            maxX = Math.max(x1, x2);
        const minY = Math.min(y1, y2),
            maxY = Math.max(y1, y2);
        const minZ = Math.min(z1, z2),
            maxZ = Math.max(z1, z2);

        const totalVolume = (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);

        player.sendMessage(`[§bFillPro§r] §e範囲制限なしのFillを開始します...\n§7(モード: ${mode} / 対象範囲: ${totalVolume} ブロック)`);

        const dimension = player.dimension;
        const initialLocation = player.location;
        const tickingAreaName = `fillpro_temp_${Math.floor(Math.random() * 100000)}`;

        try {
            dimension.runCommand(`tickingarea add circle ${minX} ${minY} ${minZ} 4 ${tickingAreaName}`);
        } catch (e) {}

        system.runJob(
            (function* () {
                let count = 0;
                let currentStep = 0;
                let processedInTick = 0;
                const barLength = 20;
                const failedPositions = [];

                for (let x = minX; x <= maxX; x++) {
                    for (let z = minZ; z <= maxZ; z++) {
                        for (let y = minY; y <= maxY; y++) {
                            if (!player.isValid) {
                                try {
                                    dimension.runCommand(`tickingarea remove ${tickingAreaName}`);
                                } catch (e) {}
                                return;
                            }
                            currentStep++;

                            // 高さ制限チェック
                            if (y < dimension.heightRange.min || y >= dimension.heightRange.max) continue;

                            const isBorder = x === minX || x === maxX || y === minY || y === maxY || z === minZ || z === maxZ;
                            const targetLocation = { x, y, z };

                            processedInTick++;
                            if (processedInTick >= BLOCKS_PER_TICK) {
                                processedInTick = 0;
                                const percent = Math.floor((currentStep / totalVolume) * 100);
                                const filled = Math.min(barLength, Math.floor((percent / 100) * barLength));
                                const empty = barLength - filled;
                                const bar = `§a${'|'.repeat(filled)}§7${'|'.repeat(empty)}`;
                                try {
                                    player.onScreenDisplay.setActionBar(`§r[FillPro] ${bar} §e${percent}% §7(${currentStep}/${totalVolume})`);
                                } catch (e) {}
                                yield;
                            }

                            let targetBlock;
                            let waitAttempts = 0;
                            let currentBlockId;

                            // ブロック取得とチャンクロードの待機
                            while (waitAttempts < 20) {
                                try {
                                    targetBlock = dimension.getBlock(targetLocation);

                                    if (targetBlock !== undefined) {
                                        currentBlockId = targetBlock.typeId;
                                        break;
                                    }

                                    throw new Error('Chunk is unloaded');
                                } catch (e) {
                                    try {
                                        player.teleport(targetLocation, { dimension: dimension });
                                    } catch (err) {}

                                    for (let i = 0; i < 20; i++) yield;
                                    waitAttempts++;
                                }
                            }

                            if (!targetBlock || currentBlockId === undefined) {
                                failedPositions.push(targetLocation);
                                continue;
                            }

                            let shouldSet = false;
                            let shouldAir = false;

                            switch (mode) {
                                case 'replace':
                                    if (!fullReplaceBlockId || currentBlockId === fullReplaceBlockId) shouldSet = true;
                                    break;
                                case 'keep':
                                    if (currentBlockId === 'minecraft:air') shouldSet = true;
                                    break;
                                case 'outline':
                                    if (isBorder) shouldSet = true;
                                    break;
                                case 'hollow':
                                    if (isBorder) shouldSet = true;
                                    else shouldAir = true;
                                    break;
                                case 'destroy':
                                    shouldSet = true;
                                    break;
                            }

                            if (shouldSet || shouldAir) {
                                try {
                                    if (mode === 'destroy' && currentBlockId !== 'minecraft:air') {
                                        try {
                                            dimension.runCommand(`setblock ${x} ${y} ${z} air destroy`);
                                        } catch (e) {}

                                        yield;

                                        try {
                                            targetBlock = dimension.getBlock(targetLocation);
                                            if (!targetBlock) {
                                                failedPositions.push(targetLocation);
                                                continue;
                                            }
                                        } catch (e) {
                                            failedPositions.push(targetLocation);
                                            continue;
                                        }
                                    }

                                    const permToSet = shouldAir ? BlockPermutation.resolve('minecraft:air') : blockPerm;
                                    targetBlock.setPermutation(permToSet);
                                    count++;
                                } catch (e) {
                                    failedPositions.push(targetLocation);
                                }
                            }
                        }
                    }
                }

                if (failedPositions.length > 0) {
                    player.sendMessage(`[§bFillPro§r] §e未処理のブロックが ${failedPositions.length} 個ありました >>> §a再試行します`);

                    let retryStep = 0;
                    const retryTotal = failedPositions.length;

                    for (const targetLocation of failedPositions) {
                        retryStep++;
                        processedInTick++;

                        if (processedInTick >= BLOCKS_PER_TICK) {
                            processedInTick = 0;
                            const percent = Math.floor((retryStep / retryTotal) * 100);
                            const filled = Math.min(barLength, Math.floor((percent / 100) * barLength));
                            const empty = barLength - filled;
                            const bar = `§a${'|'.repeat(filled)}§7${'|'.repeat(empty)}`;
                            try {
                                player.onScreenDisplay.setActionBar(`§r[FillPro] ${bar} §e${percent}% §7(再試行: ${retryStep}/${retryTotal})`);
                            } catch (e) {}
                            yield;
                        }

                        let targetBlock;
                        let waitAttempts = 0;
                        let currentBlockId;

                        while (waitAttempts < 20) {
                            try {
                                targetBlock = dimension.getBlock(targetLocation);
                                if (targetBlock !== undefined) {
                                    currentBlockId = targetBlock.typeId;
                                    break;
                                }
                                throw new Error('Chunk is unloaded');
                            } catch (e) {
                                try {
                                    player.teleport(targetLocation, { dimension: dimension });
                                } catch (err) {}
                                for (let i = 0; i < 20; i++) yield;
                                waitAttempts++;
                            }
                        }

                        if (!targetBlock || currentBlockId === undefined) continue;

                        const isBorder = targetLocation.x === minX || targetLocation.x === maxX || targetLocation.y === minY || targetLocation.y === maxY || targetLocation.z === minZ || targetLocation.z === maxZ;

                        let shouldSet = false;
                        let shouldAir = false;

                        switch (mode) {
                            case 'replace':
                                if (!fullReplaceBlockId || currentBlockId === fullReplaceBlockId) shouldSet = true;
                                break;
                            case 'keep':
                                if (currentBlockId === 'minecraft:air') shouldSet = true;
                                break;
                            case 'outline':
                                if (isBorder) shouldSet = true;
                                break;
                            case 'hollow':
                                if (isBorder) shouldSet = true;
                                else shouldAir = true;
                                break;
                            case 'destroy':
                                shouldSet = true;
                                break;
                        }

                        if (shouldSet || shouldAir) {
                            try {
                                if (mode === 'destroy' && currentBlockId !== 'minecraft:air') {
                                    try {
                                        dimension.runCommand(`setblock ${targetLocation.x} ${targetLocation.y} ${targetLocation.z} air destroy`);
                                    } catch (e) {}
                                    yield;
                                    try {
                                        targetBlock = dimension.getBlock(targetLocation);
                                        if (!targetBlock) continue;
                                    } catch (e) {
                                        continue;
                                    }
                                }

                                const permToSet = shouldAir ? BlockPermutation.resolve('minecraft:air') : blockPerm;
                                targetBlock.setPermutation(permToSet);
                                count++;
                            } catch (e) {}
                        }
                    }
                }

                try {
                    dimension.runCommand(`tickingarea remove ${tickingAreaName}`);
                } catch (e) {}

                try {
                    player.teleport(initialLocation, { dimension: dimension });
                } catch (e) {}

                try {
                    player.onScreenDisplay.setActionBar(`§a${'|'.repeat(barLength)} §e100%`);
                    player.sendMessage(`[§bFillPro§r] 処理完了\n§r§7(実際に変更されたブロック数: ${count} / 範囲全体: ${totalVolume})`);
                } catch (e) {}
            })(),
        );

        return {
            status: CustomCommandStatus.Success,
            message: `対象範囲 ${totalVolume} ブロックのFill処理を開始しました`,
        };
    });
});
