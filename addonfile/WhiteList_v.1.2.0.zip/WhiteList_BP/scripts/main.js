import * as admin from '@minecraft/server-admin';
import { world, system, CommandPermissionLevel } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { config } from './config.js';
export var playerHARUAppsOpen = {};

// ==========================================
// データの取得・保存系 (Dynamic Propertiesを使用)
// ==========================================

// UI等で手動追加されたリスト(ダイナミックプロパティ)のみを取得
function getDynamicWhitelist() {
    const listStr = world.getDynamicProperty('whitelist');
    return listStr ? JSON.parse(listStr) : [];
}

function isWhitelisted(name) {
    const lowerName = (name || '').toLowerCase();
    const dynamicList = getDynamicWhitelist();
    const configList = (config.defaultWhitelist || []).map(n => n.toLowerCase());

    return dynamicList.includes(lowerName) || configList.includes(lowerName);
}

function saveWhitelist(list) {
    world.setDynamicProperty('whitelist', JSON.stringify(list));
}

function addWhitelist(name) {
    const list = getDynamicWhitelist();
    const lowerName = (name || '').toLowerCase();
    const configList = (config.defaultWhitelist || []).map(n => n.toLowerCase());

    if (!list.includes(lowerName) && !configList.includes(lowerName)) {
        list.push(lowerName);
        saveWhitelist(list);
    }

    removeFromRecentCanceled(lowerName);
}

function removeWhitelist(name) {
    const list = getDynamicWhitelist();
    const lowerName = (name || '').toLowerCase();
    const newList = list.filter(n => n !== lowerName);
    saveWhitelist(newList);
}

function getRecentCanceled() {
    const listStr = world.getDynamicProperty('recentCanceled');
    return listStr ? JSON.parse(listStr) : [];
}

function addRecentCanceled(name) {
    let list = getRecentCanceled();
    const lowerName = (name || '').toLowerCase();
    // 既にリストにあれば削除して一番上(最新)に追加
    list = list.filter(n => n !== lowerName);
    list.unshift(lowerName);
    // 最大20件まで保存
    if (list.length > 20) list.pop();
    world.setDynamicProperty('recentCanceled', JSON.stringify(list));
}

// キャンセル履歴から特定のプレイヤーを削除する関数
function removeFromRecentCanceled(name) {
    const list = getRecentCanceled();
    const lowerName = (name || '').toLowerCase();
    const newList = list.filter(n => n !== lowerName);
    world.setDynamicProperty('recentCanceled', JSON.stringify(newList));
}

// ==========================================
// 設定データの取得・保存系
// ==========================================

function getSettings() {
    const raw = world.getDynamicProperty('whitelist_settings');
    let settings = {};
    if (raw) {
        try {
            settings = JSON.parse(raw);
        } catch (e) {}
    }
    return {
        kickMessage: settings.kickMessage ?? 'ホワイトリストに登録されていません',
        resetHistoryOnStartup: settings.resetHistoryOnStartup ?? false,
        cancelMessageMode: settings.cancelMessageMode ?? 0, // 0: 常に表示, 1: 履歴にないもののみ, 2: 非表示
    };
}

function saveSettings(settings) {
    world.setDynamicProperty('whitelist_settings', JSON.stringify(settings));
}

// ==========================================
// ロード時・プレイヤー参加前のチェック
// ==========================================

system.run(() => {
    // ロード時の履歴リセット処理
    const settings = getSettings();
    if (settings.resetHistoryOnStartup) {
        world.setDynamicProperty('recentCanceled', JSON.stringify([]));
    }

    admin.beforeEvents.asyncPlayerJoin.subscribe(data => {
        const name = (data.name || '不明').toLowerCase();

        if (world.getAllPlayers().length > 0 && !isWhitelisted(name)) {
            const currentSettings = getSettings();

            // キックメッセージ（タイムアウト文字）を動的に設定
            data.disallowJoin(currentSettings.kickMessage);

            const recent = getRecentCanceled();
            const isNew = !recent.includes(name);

            // キャンセルメッセージの設定に応じた表示
            if (currentSettings.cancelMessageMode === 0) {
                world.sendMessage(`[§bWhitelist§r] §a未登録プレイヤーの参加をキャンセルしました§r\n §r>>> §e${name}`);
            } else if (currentSettings.cancelMessageMode === 1 && isNew) {
                world.sendMessage(`[§bWhitelist§r] §a未登録プレイヤーの参加をキャンセルしました§r\n §r>>> §e${name}`);
            }
            // mode が 2(非表示) の場合は何も表示しない

            system.run(() => {
                addRecentCanceled(name);
            });
        }

        return Promise.resolve();
    });
});

// ==========================================
// 管理用UIの表示イベント
// ==========================================

world.afterEvents.itemUse.subscribe(event => {
    const { source, itemStack } = event;

    // プレイヤーが、指定のアイテムを持ち、管理者タグを持っている場合
    if (source.typeId === 'minecraft:player' && itemStack.typeId === config.uiItem) {
        system.run(() => {
            playerHARUAppsOpen[source.id] = false;
            showMainUI(source);
        });
    }
});

const RACE_EVENT_ID = 'haruapps:whitelist';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    const player = eventData.sourceEntity;
    system.run(() => {
        if (eventData.id === 'hd:whitelist') {
            playerHARUAppsOpen[player.id] = false;
            showMainUI(player);
        }
        if (eventData.id === RACE_EVENT_ID) {
            playerHARUAppsOpen[player.id] = true;
            showMainUI(player);
            player.addTag('haruapps');
            system.runTimeout(() => {
                player.removeTag('haruapps');
            }, 2);
        }
    });
});

system.beforeEvents.startup.subscribe(eventData => {
    // 起動コマンド
    const Command = {
        name: 'hd:whitelist',
        description: '§aWhiteList§eUI§rを開きます',
        permissionLevel: CommandPermissionLevel.Admin,
        mandatoryParameters: [],
        optionalParameters: [],
    };
    eventData.customCommandRegistry.registerCommand(Command, StartUI);
});

function StartUI(origin) {
    const player = origin.sourceEntity;
    system.run(() => {
        playerHARUAppsOpen[player.id] = true;
        showMainUI(player);
    });
}

// ==========================================
// UI画面の構築
// ==========================================

function showMainUI(player) {
    if (!player.hasTag(config.adminTag)) {
        player.sendMessage('[§bWhitelist§r] §c管理者ではありません');
        return;
    }
    const form = new ActionFormData().title('§0ホワイトリスト管理').body('>>> §e選択してください');
    if (playerHARUAppsOpen[player.id]) {
        form.button(`§l戻る`, 'textures/ui/icon_import.png');
    } else {
        form.button(`§0閉じる`, 'textures/ui/icon_import.png');
    }
    form.button('§1接続履歴から追加', 'textures/ui/bubble_empty').button('§0手動で追加 (ゲーマータグ入力)', 'textures/ui/bubble_empty').button('§4リストから削除', 'textures/ui/bubble_empty').button('§0設定', 'textures/ui/icon_setting');

    form.show(player)
        .then(response => {
            if (response.canceled) return;
            if (response.selection === 0) {
                if (playerHARUAppsOpen[player.id]) {
                    player.runCommand('scriptevent haruphone1:apps');
                }
                return;
            }
            if (response.selection === 1) showHistoryUI(player);
            if (response.selection === 2) showManualAddUI(player);
            if (response.selection === 3) showRemoveUI(player);
            if (response.selection === 4) showSettingsUI(player);
        })
        .catch(e => console.error(e));
}

function showHistoryUI(player) {
    const history = getRecentCanceled();
    if (history.length === 0) {
        player.sendMessage('[§bWhitelist§r] §c最近キャンセルされたプレイヤーの履歴はありません');
        return;
    }

    const form = new ActionFormData().title('§0履歴から追加').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');

    history.forEach(name => {
        form.button('§0' + name, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainUI(player);
            return;
        }
        const selectedName = history[response.selection - 1];
        addWhitelist(selectedName);
        player.sendMessage(`[§bWhitelist§r] (§e${selectedName}§r)§aをホワイトリストに追加しました`);
    });
}

function showManualAddUI(player) {
    const form = new ModalFormData().title('§0手動で追加').textField('>>> §e追加するゲーマータグを入力\n§a(大文字・小文字は区別されません)', 'ゲーマータグ');

    form.show(player).then(response => {
        if (response.canceled) {
            showMainUI(player);
            return;
        }
        const name = response.formValues[0].trim();
        if (name) {
            addWhitelist(name);
            player.sendMessage(`[§bWhitelist§r] (§e${name}§r)§aをホワイトリストに追加しました`);
        } else {
            player.sendMessage('[§bWhitelist§r] §cゲーマータグが入力されていません');
        }
    });
}

function showRemoveUI(player) {
    const whitelist = getDynamicWhitelist();
    if (whitelist.length === 0) {
        player.sendMessage('[§bWhitelist§r] §cホワイトリスト登録者が居ません');
        return;
    }

    const form = new ActionFormData().title('§4リストから削除').body('>>> §e選択してください').button(`§l戻る`, 'textures/ui/icon_import.png');
    whitelist.forEach(name => {
        form.button('§0' + name, 'textures/ui/bubble_empty');
    });

    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainUI(player);
            return;
        }
        const selectedName = whitelist[response.selection - 1];
        removeWhitelist(selectedName);
        player.sendMessage(`[§bWhitelist§r] (§e${selectedName}§r) §aをホワイトリストから削除しました`);
    });
}

// ==========================================
// 設定画面UI
// ==========================================

function showSettingsUI(player) {
    const settings = getSettings();
    const modeTexts = ['常に表示', '履歴にないもののみ表示', '非表示'];
    const resetText = settings.resetHistoryOnStartup ? '§4有効' : '§1無効';

    const form = new ActionFormData()
        .title('§0設定')
        .body('>>> §e選択してください\n§rVersion:§b1.2.0')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button(`§0ロード時の接続履歴リセット\n§0(${resetText}§0)`, 'textures/ui/bubble_empty')
        .button(`§0接続キャンセル通知の設定\n§0(${modeTexts[settings.cancelMessageMode]}§0)`, 'textures/ui/bubble_empty')
        .button(`§0キックメッセージの設定`, 'textures/ui/bubble_empty');
    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainUI(player);
        } else if (response.selection === 1) {
            // トグル処理
            settings.resetHistoryOnStartup = !settings.resetHistoryOnStartup;
            saveSettings(settings);
            player.sendMessage(`[§bWhitelist§r] §aロード時の接続履歴リセットを${settings.resetHistoryOnStartup ? '§c有効' : '§b無効'}§aにしました`);
            showSettingsUI(player); // 再描画
        } else if (response.selection === 2) {
            showCancelMessageModeUI(player, settings);
        } else if (response.selection === 3) {
            showKickMessageUI(player, settings);
        }
    });
}

function showKickMessageUI(player, settings) {
    const form = new ModalFormData().title('§0キックメッセージの設定').textField('>>> §e接続キャンセル時に表示されるテキスト\n§a※空欄にした場合はデフォルトが使用されます', 'メッセージ', {
        defaultValue: settings.kickMessage,
    });

    form.show(player).then(response => {
        if (response.canceled) {
            showSettingsUI(player);
            return;
        }
        const newMsg = response.formValues[0].trim();
        if (newMsg) {
            settings.kickMessage = newMsg;
        } else {
            settings.kickMessage = 'ホワイトリストに登録されていません';
        }
        saveSettings(settings);
        player.sendMessage(`[§bWhitelist§r] §aキックメッセージを更新しました`);
        showSettingsUI(player);
    });
}

function showCancelMessageModeUI(player, settings) {
    const form = new ActionFormData().title('§0キャンセル通知の設定').body('>>> §e接続キャンセル時のチャット通知を選択してください').button('§l戻る', 'textures/ui/icon_import.png').button('§0常に表示', 'textures/ui/bubble_empty').button('§0履歴にないもののみ表示', 'textures/ui/bubble_empty').button('§0非表示', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showSettingsUI(player);
            return;
        }
        // selection: 1=常に表示(0), 2=履歴にないもののみ(1), 3=非表示(2)
        settings.cancelMessageMode = response.selection - 1;
        saveSettings(settings);
        player.sendMessage(`[§bWhitelist§r] §aキャンセル通知の設定を更新しました`);
        showSettingsUI(player);
    });
}
