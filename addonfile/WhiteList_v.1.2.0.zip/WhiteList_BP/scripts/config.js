export const config = {
    defaultWhitelist: ['HARUAddons8'],
    uiItem: 'additem:whitelist',
    adminTag: 'SecurityOP',
};
