import { world, system } from '@minecraft/server';
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';

// ダイナミックプロパティに保存する際のIDを変更
const BORDER_SIZES_PROPERTY_ID = 'worldborder:sizes'; // オブジェクトを保存するためID名を変更
const OP_PROPERTY_ID = 'worldborder:op';

const BORDER_CENTER_PROPERTY_ID = 'worldborder:center';
// 境界を超えた場合に少し戻す座標のマージン
const SAFE_MARGIN = 0.5;
// この距離だけ境界の外に出たらテレポートしない
const TELEPORT_BUFFER = 8.5;

// 現在の境界値をディメンションごとに保持する変数
let currentBorderSizes;

let currentOPLimit;

let currentCenter;

// プレイヤーごとの「最後にいた安全な場所」を記録するマップ
const playerLastValidLocations = new Map();

/**
 * 座標が境界内にあるかチェックし、範囲外なら修正した座標を返す関数
 * @param {number} x - プレイヤーのX座標
 * @param {number} z - プレイヤーのZ座標
 * @param {number} borderSize - このディメンションでの境界サイズ
 * @returns {{x: number, z: number} | null} - 修正後の座標、または修正不要ならnull
 */
function getClampedCoordinates(x, z, borderSize, centerX, centerZ) {
    let clampedX = x;
    let clampedZ = z;
    let needsTeleport = false;

    // xの判定
    if (x > centerX + borderSize + 1 && x <= centerX + borderSize + 1 + TELEPORT_BUFFER) {
        clampedX = centerX + borderSize + 1 - SAFE_MARGIN;
        needsTeleport = true;
    } else if (x < centerX - borderSize && x >= centerX - borderSize - TELEPORT_BUFFER) {
        clampedX = centerX - borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    // zの判定
    if (z > centerZ + borderSize + 1 && z <= centerZ + borderSize + 1 + TELEPORT_BUFFER) {
        clampedZ = centerZ + borderSize + 1 - SAFE_MARGIN;
        needsTeleport = true;
    } else if (z < centerZ - borderSize && z >= centerZ - borderSize - TELEPORT_BUFFER) {
        clampedZ = centerZ - borderSize + SAFE_MARGIN;
        needsTeleport = true;
    }

    if (needsTeleport) {
        return { x: clampedX, z: clampedZ };
    }
    return null;
}

/**
 * 指定した座標が、そのディメンションのボーダー内にあるかチェックする関数
 */
function isLocationInsideBorder(loc, dimensionId) {
    if (typeof currentBorderSizes === 'undefined' || typeof currentCenter === 'undefined') return false;
    const dimKey = dimensionId.includes(':') ? dimensionId.split(':')[1] : dimensionId;
    const borderSize = currentBorderSizes[dimKey];
    const center = currentCenter[dimKey];
    if (typeof borderSize === 'undefined' || typeof center === 'undefined') return false;

    const isOutside = loc.x > center.x + borderSize + 1 || loc.x < center.x - borderSize || loc.z > center.z + borderSize + 1 || loc.z < center.z - borderSize;

    return !isOutside;
}

// プレイヤーの座標をチェックする処理
system.runInterval(() => {
    if (typeof currentBorderSizes === 'undefined' || typeof currentCenter === 'undefined') return;

    for (const player of world.getAllPlayers()) {
        const dimensionId = player.dimension.id.split(':')[1]; // "overworld", "nether", "the_end"
        const borderSize = currentBorderSizes[dimensionId];
        const center = currentCenter[dimensionId];

        if (typeof borderSize === 'undefined' || !player.location) {
            continue;
        }

        const location = player.location;
        const clampedCoords = getClampedCoordinates(location.x, location.z, borderSize, center.x, center.z);

        if (clampedCoords) {
            if (!player.hasTag('WorldorderOP') || (player.hasTag('WorldorderOP') && !currentOPLimit)) {
                player.teleport({ x: clampedCoords.x, y: location.y, z: clampedCoords.z }, { rotation: { x: player.getRotation().x, y: player.getRotation().y } });
                player.onScreenDisplay.setActionBar('§c世界の果てに到達した');
            }
        } else {
            const isOutsideBorder = location.x > center.x + borderSize + 1 || location.x < center.x - borderSize || location.z > center.z + borderSize + 1 || location.z < center.z - borderSize;

            if (isOutsideBorder) {
                if (!player.hasTag('WorldorderOP') || (player.hasTag('WorldorderOP') && !currentOPLimit)) {
                    const lastData = playerLastValidLocations.get(player.id);
                    if (lastData && isLocationInsideBorder(lastData.location, lastData.dimensionId)) {
                        const fromDim = world.getDimension(lastData.dimensionId);
                        player.teleport(lastData.location, {
                            dimension: fromDim,
                            rotation: lastData.rotation,
                        });
                        player.onScreenDisplay.setActionBar('§c移動先が世界の果てのため、元の位置に戻されました');
                    } else {
                        player.onScreenDisplay.setActionBar('§e制限範囲内に戻ると制限が有効になります');
                    }
                }
            } else {
                // 範囲内、かつ正常な位置なら記録更新
                playerLastValidLocations.set(player.id, {
                    dimensionId: player.dimension.id,
                    location: { x: location.x, y: location.y, z: location.z },
                    rotation: { x: player.getRotation().x, y: player.getRotation().y },
                });
            }
        }
    }
}, 5);

system.runInterval(() => {
    if (typeof currentBorderSizes === 'undefined' || typeof currentCenter === 'undefined') return;

    const dimensionIds = ['overworld', 'nether', 'the_end'];

    for (const dimId of dimensionIds) {
        const borderSize = currentBorderSizes[dimId];
        const center = currentCenter[dimId];
        if (typeof borderSize === 'undefined' || typeof center === 'undefined') continue;

        const dimension = world.getDimension(dimId);

        // そのディメンションに存在する全てのエンダーパールを取得
        const pearls = dimension.getEntities({ type: 'minecraft:ender_pearl' });

        for (const pearl of pearls) {
            const location = pearl.location;

            if (location.x > center.x + borderSize + 1 || location.x < center.x - borderSize || location.z > center.z + borderSize + 1 || location.z < center.z - borderSize) {
                const projectileComp = pearl.getComponent('minecraft:projectile');
                const owner = projectileComp ? projectileComp.owner : undefined;

                if (currentOPLimit && owner && owner.typeId === 'minecraft:player' && owner.hasTag('WorldorderOP')) {
                    continue;
                }

                try {
                    pearl.remove();
                } catch (e) {}
            }
        }
    }
}, 2);

// ディメンション表示名マップ
const DIMENSION_NAMES = {
    overworld: 'オーバーワールド',
    nether: 'ネザー',
    the_end: 'エンド',
};

// メインメニュー（ActionFormData）
function showMainMenu(player) {
    const opStatusText = currentOPLimit ? '§1有効' : '§4無効';

    const actionForm = new ActionFormData().title('§1ワールドボーダー設定').body('>>> §e選択してください').button(`§0OP無制限の切替\n§0(${opStatusText}§0)`, 'textures/ui/bubble_empty').button('§2オーバーワールド設定', 'textures/ui/bubble_empty').button('§4ネザー設定', 'textures/ui/bubble_empty').button('§5エンド設定', 'textures/ui/bubble_empty');

    actionForm.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            // ワンタップでOP無制限をトグル切り替え
            currentOPLimit = !currentOPLimit;
            world.setDynamicProperty(OP_PROPERTY_ID, currentOPLimit);
            player.sendMessage(`[§bWorldBorder§r] §aOP無制限を ${currentOPLimit ? '§e有効' : '§c無効'} §aに切り替えました`);
            // 切り替え後、メニューを再表示
            showMainMenu(player);
        } else if (response.selection === 1) {
            showDimensionSettings(player, 'overworld');
        } else if (response.selection === 2) {
            showDimensionSettings(player, 'nether');
        } else if (response.selection === 3) {
            showDimensionSettings(player, 'the_end');
        }
    });
}

// 各ディメンションの詳細設定
function showDimensionSettings(player, dimId) {
    const dimName = DIMENSION_NAMES[dimId];
    const center = currentCenter[dimId];
    const size = currentBorderSizes[dimId];

    const form = new ModalFormData().title(`§1${dimName}設定`).textField('§a中心のX座標', '数値を入力', `${center.x}`).textField('§e中心のZ座標', '数値を入力', `${center.z}`).textField('§bボーダーの範囲 (半径)', '10以上の数値を入力', `${size}`).submitButton('§0適用');

    form.show(player).then(response => {
        if (response.canceled) {
            showMainMenu(player);
            return;
        }

        const [centerXStr, centerZStr, sizeStr] = response.formValues;
        const newCenterX = Number(centerXStr);
        const newCenterZ = Number(centerZStr);
        const newSize = Number(sizeStr);

        if (isNaN(newCenterX) || isNaN(newCenterZ) || isNaN(newSize) || newSize <= 0) {
            player.sendMessage('§cエラー: 中心座標は数値、範囲には正の数値を指定してください');
            return;
        }

        currentCenter[dimId] = { x: newCenterX, z: newCenterZ };
        currentBorderSizes[dimId] = newSize;

        world.setDynamicProperty(BORDER_CENTER_PROPERTY_ID, JSON.stringify(currentCenter));
        world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(currentBorderSizes));

        player.sendMessage(`[§bWorldBorder§r] §a${dimName}の設定を更新しました (中心: [${newCenterX}, ${newCenterZ}], 範囲: ${newSize})`);
    });
}

//スクリプトイベント
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'worldborder:s' && eventData.sourceEntity) {
        const player = eventData.sourceEntity;
        if (!player.hasTag('WorldorderOP')) {
            player.sendMessage(`[§bWorldBorder§r] §a設定を行うにはOPタグが必要です\n §r>>> §eWorldorderOP`);
            return;
        }
        showMainMenu(player);
    }
});

// ワールド読み込み
system.run(() => {
    const OLD_BORDER_PROPERTY_ID = 'worldborder:size';
    const savedOldBorderSize = world.getDynamicProperty(OLD_BORDER_PROPERTY_ID);
    const savedSizesJSON = world.getDynamicProperty(BORDER_SIZES_PROPERTY_ID);

    if (savedSizesJSON === undefined) {
        if (savedOldBorderSize !== undefined) {
            const migratedSizes = {
                overworld: savedOldBorderSize,
                nether: savedOldBorderSize / 2,
                the_end: savedOldBorderSize * 2,
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(migratedSizes));
            currentBorderSizes = migratedSizes;

            world.setDynamicProperty(OLD_BORDER_PROPERTY_ID, undefined);
        } else {
            const defaultSizes = {
                overworld: 1000,
                nether: 500,
                the_end: 2000,
            };
            world.setDynamicProperty(BORDER_SIZES_PROPERTY_ID, JSON.stringify(defaultSizes));
            currentBorderSizes = defaultSizes;
        }
    } else {
        // 新しい形式のデータが既に存在する場合は、それを読み込む
        currentBorderSizes = JSON.parse(savedSizesJSON);
    }

    const savedOPLimit = world.getDynamicProperty(OP_PROPERTY_ID);
    if (savedOPLimit === undefined) {
        world.setDynamicProperty(OP_PROPERTY_ID, false);
        currentOPLimit = false;
    } else {
        currentOPLimit = savedOPLimit;
    }

    const savedCenterJSON = world.getDynamicProperty(BORDER_CENTER_PROPERTY_ID);
    if (savedCenterJSON === undefined) {
        currentCenter = {
            overworld: { x: 0, z: 0 },
            nether: { x: 0, z: 0 },
            the_end: { x: 0, z: 0 },
        };
        world.setDynamicProperty(BORDER_CENTER_PROPERTY_ID, JSON.stringify(currentCenter));
    } else {
        const parsed = JSON.parse(savedCenterJSON);
        if (typeof parsed.x === 'number') {
            currentCenter = {
                overworld: { x: parsed.x, z: parsed.z },
                nether: { x: 0, z: 0 },
                the_end: { x: 0, z: 0 },
            };
            world.setDynamicProperty(BORDER_CENTER_PROPERTY_ID, JSON.stringify(currentCenter));
        } else {
            currentCenter = parsed;
        }
    }
});

// ディメンション移動を検知
world.afterEvents.playerDimensionChange.subscribe(event => {
    const player = event.player;
    const toDimension = event.toDimension;
    const dimensionId = toDimension.id.split(':')[1];

    if (typeof currentBorderSizes === 'undefined' || typeof currentCenter === 'undefined') return;

    const borderSize = currentBorderSizes[dimensionId];
    const center = currentCenter[dimensionId];
    if (typeof borderSize === 'undefined' || typeof center === 'undefined') return;

    system.runTimeout(() => {
        if (!player.isValid()) return;

        if (player.hasTag('WorldorderOP') && currentOPLimit) return;

        const location = player.location;
        const isOutside = location.x > center.x + borderSize + 1 || location.x < center.x - borderSize || location.z > center.z + borderSize + 1 || location.z < center.z - borderSize;

        if (isOutside) {
            // 範囲外に出る移動だった場合
            const lastData = playerLastValidLocations.get(player.id);
            if (lastData && lastData.dimensionId === event.fromDimension.id && isLocationInsideBorder(lastData.location, lastData.dimensionId)) {
                const fromDim = world.getDimension(lastData.dimensionId);

                player.teleport(lastData.location, {
                    dimension: fromDim,
                    rotation: lastData.rotation,
                });

                player.onScreenDisplay.setActionBar('§c移動先が世界の果てのため、移動できませんでした');
                player.sendMessage('§c[システム] §e移動先の座標がワールドボーダー外のため、元の場所に戻されました');
            }
        }
    }, 10);
});
