import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { UI } from '../ui';

// --- 設定項目 ---
let DAYS_TO_KEEP = 7; // データ保存期間（日数）
const LOG_INTERVAL = 1200; // ログ記録間隔（tick、1200 = 1分）
const MAX_LOGS_PER_PART = 500; // 1プロパティあたりの最大ログ数
const LOGS_PER_PAGE = 40; // 1ページに表示するログの件数

// --- 内部変数 ---
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
export let securityLogNames = [];

// --- 初期化・リロード処理 ---
export function lreload() {
    try {
        const storedDays = world.getDynamicProperty('location_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[Location] Error loading location_delete_speed: ${e}`);
    }
    loadPlayerNames();
}

// --- ヘルパー関数 ---

function getDateKey(timestamp) {
    const date = new Date(timestamp);
    return `${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(date.getUTCDate()).padStart(2, '0')}`;
}

function getJapanTimeString(timestamp) {
    try {
        const timeOffset = world.getDynamicProperty('Time_Setting') || 9;
        const japanTime = new Date(timestamp + timeOffset * 60 * 60 * 1000);
        const year = japanTime.getUTCFullYear();
        const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
        const day = String(japanTime.getUTCDate()).padStart(2, '0');
        const hours = String(japanTime.getUTCHours()).padStart(2, '0');
        const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
        const seconds = String(japanTime.getUTCSeconds()).padStart(2, '0');
        return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
    } catch {
        return "時刻取得エラー";
    }
}

function getLogKeyBase(playerName, timestamp) {
    return `location_${playerName}_${getDateKey(timestamp)}`;
}

function savePlayerNames() {
    try {
        world.setDynamicProperty('location_names', JSON.stringify([...securityLogNames]));
    } catch (e) {
        console.warn(`[Location] プレイヤー名保存エラー: ${e}`);
    }
}

// [修正] データ読み込みの堅牢性を向上させ、オフラインプレイヤーが消えないようにする
function loadPlayerNames() {
    try {
        const storedNames = world.getDynamicProperty('location_names');
        // 保存されているデータがある場合のみ処理を行う
        if (storedNames) {
            const parsedNames = JSON.parse(storedNames);
            // 読み込んだデータが配列形式であることを確認する
            if (Array.isArray(parsedNames)) {
                securityLogNames = parsedNames;
            } else {
                // 配列でない場合は警告を出し、既存のデータを上書きしない
                console.warn(`[Location] 動的プロパティ 'location_names' のデータが不正です。`);
            }
        }
        // storedNamesが存在しない場合（初回起動時など）は何もしない。
        // これにより、現在のセッションで記録されたプレイヤー名が保持される。
    } catch (e) {
        // JSONのパースに失敗した場合(データ破損など)でも、
        // 実行中のsecurityLogNamesを空にせず、データを保護する。
        console.warn(`[Location] プレイヤー名リストの読み込みに失敗しました。データ破損の可能性があります: ${e}`);
    }
}


// --- データ管理（記録・読み込み・削除） ---

system.runInterval(() => {
    if (world.getDynamicProperty('Log_system') !== true) return;

    const players = world.getPlayers();
    if (players.length === 0) return;

    const now = Date.now();
    let playerNamesModified = false;

    for (const player of players) {
        if (!securityLogNames.includes(player.name)) {
            securityLogNames.push(player.name);
            playerNamesModified = true;
        }
    }
    if (playerNamesModified) savePlayerNames();

    for (const player of players) {
        const logEntry = {
            x: Math.round(player.location.x),
            y: Math.round(player.location.y),
            z: Math.round(player.location.z),
            timestamp: now,
        };

        const keyBase = getLogKeyBase(player.name, now);
        let part = 1;
        let targetKey = `${keyBase}_part${part}`;

        while (true) {
            const storedData = world.getDynamicProperty(targetKey);
            if (!storedData) break;
            const logData = JSON.parse(storedData);
            if (logData.length < MAX_LOGS_PER_PART) break;
            part++;
            targetKey = `${keyBase}_part${part}`;
        }
        
        try {
            const storedData = world.getDynamicProperty(targetKey);
            const currentLogs = storedData ? JSON.parse(storedData) : [];
            currentLogs.push(logEntry);
            world.setDynamicProperty(targetKey, JSON.stringify(currentLogs));
        } catch (e) {
             console.warn(`[Location] ログデータ保存エラー (${targetKey}): ${e}`);
        }
    }
}, LOG_INTERVAL);

system.runInterval(() => {
    const expirationDay = parseInt(getDateKey(Date.now() - DAYS_TO_KEEP * MILLISECONDS_PER_DAY), 10);
    const allKeys = world.getDynamicPropertyIds();

    for (const key of allKeys) {
        // 両方の形式（古い_splitも含む）を削除対象にする
        if (key.startsWith('location_')) {
            const match = key.match(/location_.*_(\d{8})/);
            if (match) {
                const datePart = parseInt(match[1], 10);
                if (datePart < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    }
}, 36000);

// [修正] 古いデータ形式も読み込めるように互換性を追加
function getAllLogsForPlayer(playerName) {
    let allLogs = [];
    const today = Date.now();

    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const timestamp = today - i * MILLISECONDS_PER_DAY;
        const keyBase = getLogKeyBase(playerName, timestamp);
        
        // --- ここからが互換性対応部分 ---
        // 1. 古い形式のキー（_partなし）を読み込む
        try {
            const oldFormatData = world.getDynamicProperty(keyBase);
            if (oldFormatData) {
                const parsed = JSON.parse(oldFormatData);
                if (Array.isArray(parsed)) {
                    allLogs = allLogs.concat(parsed);
                }
            }
        } catch (e) {
            console.warn(`[Location] 旧形式ログの読み込みエラー (${keyBase}): ${e}`);
        }
        // --- 互換性対応部分ここまで ---

        // 2. 新しい形式（_part付き）のキーを読み込む
        let part = 1;
        while (true) {
            const key = `${keyBase}_part${part}`;
            try {
                const storedData = world.getDynamicProperty(key);
                if (!storedData) break;
                const parsedData = JSON.parse(storedData);
                if (Array.isArray(parsedData)) {
                    allLogs = allLogs.concat(parsedData);
                }
            } catch (e) {
                console.warn(`[Location] ログデータ取得エラー (${key}): ${e}`);
            }
            part++;
        }
    }
    return allLogs.sort((a, b) => b.timestamp - a.timestamp); // 最新順にソート
}


// --- UI関連 ---

export function showMainMenu_Location(player) {
    new ActionFormData()
        .title('§0§lSecureCraft')
        .body('検索方法を選択してください')
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1プレイヤー選択', 'textures/ui/icon_multiplayer.png')
        .button('§5座標範囲で検索', 'textures/ui/icon_map.png')
        .show(player).then(response => {
            if (response.canceled) return;
            if (response.selection === 0) UI(player);
            else if (response.selection === 1) showPlayerList_Location(player);
            else if (response.selection === 2) showCoordinateInput(player);
        });
}

function showPlayerList_Location(player) {
    loadPlayerNames();
    if (securityLogNames.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §aログデータがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        return;
    }

    const form = new ActionFormData().title('§0§lSecureCraft').body('確認したいプレイヤーを選んでください').button('§l§l戻る', 'textures/ui/icon_import.png');
    securityLogNames.forEach(name => form.button(`§1${name}`));
    form.show(player).then(response => {
        if (response.canceled) return;
        if (response.selection === 0) {
            showMainMenu_Location(player);
            return;
        }
        const selectedPlayer = securityLogNames[response.selection - 1];
        const allLogs = getAllLogsForPlayer(selectedPlayer);
        showPaginatedLogs(player, {
            logs: allLogs,
            title: `§1${selectedPlayer} の全ログ`,
            targetName: selectedPlayer,
            page: 1,
            backCallback: () => showPlayerList_Location(player)
        });
    });
}

function showPaginatedLogs(player, context) {
    const { logs, title, targetName, page, backCallback } = context;

    if (logs.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a表示できるログデータがありません');
        player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        backCallback();
        return;
    }

    const totalPages = Math.ceil(logs.length / LOGS_PER_PAGE);
    const startIndex = (page - 1) * LOGS_PER_PAGE;
    const logsToShow = logs.slice(startIndex, startIndex + LOGS_PER_PAGE);

    const form = new ActionFormData()
        .title(title)
        .body(`§eページ: ${page} / ${totalPages} §r| §e総件数: ${logs.length}件\n§aログを選択してください`);

    const buttonActions = [];

    form.button('§l戻る', 'textures/ui/icon_import.png');
    buttonActions.push(backCallback);

    if (page > 1) {
        form.button('§1前のページへ', 'textures/ui/arrow_left.png');
        buttonActions.push(() => showPaginatedLogs(player, { ...context, page: page - 1 }));
    }

    logsToShow.forEach(log => {
        const time = getJapanTimeString(log.timestamp);
        form.button(`§0${time} §5(${log.x}, ${log.y}, ${log.z})`);
        buttonActions.push(() => showLogDetails(player, targetName, log, () => showPaginatedLogs(player, context)));
    });

    if (page < totalPages) {
        form.button('§1次のページへ', 'textures/ui/arrow_right.png');
        buttonActions.push(() => showPaginatedLogs(player, { ...context, page: page + 1 }));
    }

    form.show(player).then(response => {
        if (response.canceled) return;
        buttonActions[response.selection]();
    });
}

function showCoordinateInput(player) {
    const { x, y, z } = player.location;
    new ModalFormData()
        .title('§1座標からプレイヤー検索')
        .textField('X座標', '半角数字' , { defaultValue: `${String(Math.round(x))}`})
        .textField('Y座標', '半角数字' , { defaultValue: `${String(Math.round(y))}`})
        .textField('Z座標', '半角数字' , { defaultValue: `${String(Math.round(z))}`})
        .dropdown('検索半径', ['10', '30', '50', '80'])
        .show(player).then(response => {
            if (response.canceled) {
                showMainMenu_Location(player);
                return;
            }
            const [xStr, yStr, zStr, radiusIndex] = response.formValues;
            const radius = [10, 30, 50, 80][radiusIndex];
            const centerX = parseFloat(xStr);
            const centerY = parseFloat(yStr);
            const centerZ = parseFloat(zStr);

            if (isNaN(centerX) || isNaN(centerY) || isNaN(centerZ)) {
                player.sendMessage('§r[§bSecurityCraft§r] §c無効な座標が入力されました。');
                return;
            }
            showPlayersByCoordinates(player, { centerX, centerY, centerZ, radius });
        });
}

function showPlayersByCoordinates(player, searchParams) {
    const { centerX, centerY, centerZ, radius } = searchParams;
    const playerLogs = {};

    loadPlayerNames();
    for (const playerName of securityLogNames) {
        const allLogs = getAllLogsForPlayer(playerName);
        const filtered = allLogs.filter(log =>
            Math.abs(log.x - centerX) <= radius &&
            Math.abs(log.y - centerY) <= radius &&
            Math.abs(log.z - centerZ) <= radius
        );
        if (filtered.length > 0) {
            playerLogs[playerName] = filtered;
        }
    }

    if (Object.keys(playerLogs).length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §a指定範囲にプレイヤーのログはありませんでした。');
        showCoordinateInput(player);
        return;
    }

    const form = new ActionFormData()
        .title('§1座標範囲内のプレイヤー')
        .body(`中心: §b${centerX}, ${centerY}, ${centerZ} §r(半径: §b${radius}ブロック§r)\n§aプレイヤーを選択してください`)
        .button('§l戻る', 'textures/ui/icon_import.png');
    
    const playerNames = Object.keys(playerLogs);
    playerNames.forEach(name => form.button(`§1${name} §0(${playerLogs[name].length}件)`));

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            showCoordinateInput(player);
            return;
        }
        const selectedPlayer = playerNames[response.selection - 1];
        showPaginatedLogs(player, {
            logs: playerLogs[selectedPlayer],
            title: `§1${selectedPlayer} のログ（座標範囲）`,
            targetName: selectedPlayer,
            page: 1,
            backCallback: () => showPlayersByCoordinates(player, searchParams)
        });
    });
}

function showLogDetails(player, targetName, log, backCallback) {
    const time = getJapanTimeString(log.timestamp);
    const logText = `§a${targetName} §rの§6座標ログ\n§aX§r: §b${log.x}\n§aY§r: §b${log.y}\n§aZ§r: §b${log.z}\n§a時間§r: §b${time}`;
    new ActionFormData()
        .title('§0§lSecureCraft')
        .body(logText)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .show(player).then(() => {
            backCallback();
        });
}

world.afterEvents.worldLoad.subscribe(() => {
    lreload();
});