import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { chestCheckModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7; // デフォルトは7日間に設定
let pendingUpdates = new Map();

// 削除期間をロード
export function creload() {
    try {
        const storedDays = world.getDynamicProperty('chestlog_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[SecurityCraft] チェストログの削除期間のロード中にエラーが発生しました: ${e}`);
    }
}

// ワールドロード時にリロード
world.afterEvents.worldLoad.subscribe(() => {
    creload();
});

creload();

/**
 * チャンクキーを生成します。
 * タイムゾーンは考慮せず、UTCを基準とします。
 * @param {number} x - ブロックのX座標
 * @param {number} z - ブロックのZ座標
 * @param {number} [timestamp] - タイムスタンプ
 * @returns {string} - 生成されたチャンクキー
 */
function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    // UTCを基準とした日付でキーを生成
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `chest_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`[SecurityCraft] チャンクデータの保存中にエラーが発生しました: ${e}`);
    }
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        const parsedData = storedData ? JSON.parse(storedData) : [];
        return new Map(parsedData);
    } catch (e) {
        console.warn(`[SecurityCraft] チャンクデータのパース中にエラーが発生しました: ${e}`);
        return new Map();
    }
}

function cleanOldData() {
    try {
        const currentTime = Date.now();
        // UTCを基準として削除日を計算
        const expirationDay = Math.floor(currentTime / MILLISECONDS_PER_DAY) - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                const match = key.match(/chest_(-?\d+)_(-?\d+)_(\d+)/);
                if (match && parseInt(match[3]) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 古いデータのクリーンアップ中にエラーが発生しました: ${e}`);
    }
}

system.runInterval(() => {
    if (pendingUpdates.size > 0) {
        const updatesToProcess = new Map(pendingUpdates);
        for (const [chunkKey, chunkData] of updatesToProcess) {
            saveChunkData(chunkKey, chunkData);
        }
    }
    cleanOldData();
}, 20 * 10); // 1分に1回実行

export function addChestLog(block, player) {
    if (world.getDynamicProperty('ChestLog_system') !== true) return;

    const blockLocation = block.location;
    const chunkKey = getChunkKey(blockLocation.x, blockLocation.z);
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);

    let chunkData = pendingUpdates.has(chunkKey) ? pendingUpdates.get(chunkKey) : getChunkData(chunkKey);

    const logEntry = {
        n: player.name,
        t: Date.now(),
        id: block.typeId,
    };

    let logsForPosition = chunkData.has(positionKey) ? chunkData.get(positionKey) : [];
    logsForPosition.push(logEntry);

    // ログを最新の20件に制限
    if (logsForPosition.length > 20) {
        logsForPosition = logsForPosition.slice(-20);
    }

    chunkData.set(positionKey, logsForPosition);
    pendingUpdates.set(chunkKey, chunkData);
}

export function getChestLog(blockLocation) {
    const chunkData = getChunkData(getChunkKey(blockLocation.x, blockLocation.z));
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);
    return chunkData.get(positionKey) || [];
}

export function clearAllChestData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 全チェストログの削除中にエラーが発生しました: ${e}`);
    }
}

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    const blockType = block.typeId;

    // 記録対象のブロックを定義
    const loggableBlocks = ['minecraft:chest', 'minecraft:barrel'];

    // 記録システムが有効な場合、ログを記録
    if (world.getDynamicProperty('ChestLog_system') === true && loggableBlocks.includes(blockType) && !chestCheckModePlayers.has(player.name) ) {
        system.run(() => {
            addChestLog(block, player);
        });
    }

    // 確認モードが有効な場合、UIを表示
    if (chestCheckModePlayers.has(player.name) && loggableBlocks.includes(blockType)) {
        system.run(() => {
            const logs = getChestLog(block.location);
            const form = new ActionFormData().title('§0チェストアクセス履歴');

            if (logs.length > 0) {
                let body = `§a座標§r: §b${Math.floor(block.location.x)}, ${Math.floor(block.location.y)}, ${Math.floor(block.location.z)}\n§r`;
                logs.forEach(log => {
                    const japanTime = new Date(log.t + (world.getDynamicProperty('Time_Setting') || 0) * 60 * 60 * 1000);
                    const timeString = `${japanTime.getUTCFullYear()}/${String(japanTime.getUTCMonth() + 1).padStart(2, '0')}/${String(japanTime.getUTCDate()).padStart(2, '0')} ${String(japanTime.getUTCHours()).padStart(2, '0')}:${String(japanTime.getUTCMinutes()).padStart(2, '0')}:${String(japanTime.getUTCSeconds()).padStart(2, '0')}`;
                    body += `\n§r・§e${log.n} §7(${timeString})§r`;
                });
                form.body(body);
            } else {
                form.body(`§cこのチェスト/樽にはアクセス履歴がありません。`);
            }

            form.button('§l閉じる');
            form.show(player);
        });
        event.cancel = true;
    }
});
