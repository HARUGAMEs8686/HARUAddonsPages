import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { checkModePlayers, playerCheckModeStatus, currentTPS, chestCheckModePlayers } from './main';

import { resetPlayerXrayData } from './detection/x-ray';

import { showMainMenu_Location } from './log/Location';

import { SettingUI } from './setting';

world.beforeEvents.chatSend.subscribe(event => {
    if (world.getDynamicProperty('CHAT_LEVEL') == 0) {
        return;
    }
    const player = event.sender;
    const message = event.message;

    if (message == '!scp' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (checkModePlayers.has(player.name)) {
                checkModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                checkModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scb' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (playerCheckModeStatus[player.name] == true) {
                playerCheckModeStatus[player.name] = false;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                playerCheckModeStatus[player.name] = true;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§e破壊された周辺のブロックタッチすると破壊者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scc' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (chestCheckModePlayers.has(player.name)) {
                chestCheckModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aチェスト確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                chestCheckModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aチェスト確認モード§rを§5ON§rにしました.§eチェストや樽をタッチするとアクセス履歴を見れます');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
});

export function UI(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `[${year}/${month}/${date}] ${hours}:${minutes}`;

    var players = world.getPlayers();
    var form = new ActionFormData();
    form.title('§0§lSecurityCraft');
    form.body(`§a-ワールド情報-\n§r・§3プレイヤー人数§r: §r§b${players.length}\n§r・§eTPS§r:§b${currentTPS}\n§r・§a時刻§r:§b${time}`);
    form.divider();
    form.button('§0セキュリティー情報', 'textures/ui/blue_info_glyph.png');
    form.button('§1座標ログ', 'textures/ui/icon_timer.png');
    form.button('§3CheckMode', 'textures/ui/check.png');
    form.button('§0ブロック§4解除', 'textures/ui/wither_heart_flash.png');
    form.button('§5信頼メンバー\n§1追加§0/§4解除', 'textures/ui/permissions_member_star.png');
    form.button('§8設定\n§9操作', 'textures/ui/icon_setting');
    form.button('§0アドオン情報\n§8Version', 'textures/items/stick');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                Securityinformation(player);
                break;
            case 1:
                showMainMenu_Location(player);
                break;
            case 2:
                var form = new ModalFormData();
                form.title('§0§lSecurityCraft');
                form.toggle('§a設置確認モード', {
                    defaultValue: checkModePlayers.has(player.name),
                    tooltip: '設置確認モードを切り替える', // 任意でツールチップを追加
                });
                form.toggle('§c破壊確認モード', {
                    defaultValue: playerCheckModeStatus[player.name] ?? false,
                    tooltip: '破壊確認モードを切り替える', // 任意でツールチップを追加
                });
                form.toggle('§eチェスト確認モード', {
                    defaultValue: chestCheckModePlayers.has(player.name) ?? false,
                    tooltip: 'チェスト確認モードを切り替える', // 任意でツールチップを追加
                });
                form.show(player).then(r => {
                    if (r.canceled) return;

                    const [setPlacementCheck, setBreakCheck, setChestCheck] = r.formValues;
                    const wasPlacementCheck = checkModePlayers.has(player.name);
                    const wasBreakCheck = playerCheckModeStatus[player.name] ?? false;
                    const wasChestCheck = chestCheckModePlayers.has(player.name);

                    // 設置チェック切替
                    if (setPlacementCheck !== wasPlacementCheck) {
                        if (setPlacementCheck) {
                            checkModePlayers.add(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            checkModePlayers.delete(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }

                    // 破壊チェック切替
                    if (setBreakCheck !== wasBreakCheck) {
                        playerCheckModeStatus[player.name] = setBreakCheck;
                        if (setBreakCheck) {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5ON§rにしました.§eブロック周辺をタッチで破壊履歴を確認');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            player.sendMessage('§r[§bSecurityCraft§r] §a破壊確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }

                    if (setChestCheck !== wasChestCheck) {
                        if (setChestCheck) {
                            chestCheckModePlayers.add(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §aチェスト確認モード§rを§5ON§rにしました.§eチェストや樽をタッチするとアクセス履歴を見れます');
                            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                        } else {
                            chestCheckModePlayers.delete(player.name);
                            player.sendMessage('§r[§bSecurityCraft§r] §aチェスト確認モード§rを§5OFF§rにしました');
                            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
                        }
                    }
                });
                break;
            case 3:
                // プレイヤーを取得
                const adventurePlayers = Array.from(players).filter(player => player.getGameMode() === 'Adventure');
                if (adventurePlayers.length == 0) {
                    player.sendMessage('[§bSecurity§r] §a解除可能なプレイヤーが見つかりませんでした');
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.6 0.7`);
                    return;
                }
                const playerNames = adventurePlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                playerNames.unshift('全員解除'); // ドロップダウンの先頭に「全プレイヤー」を追加

                // フォームを作成
                var form = new ModalFormData().title('§0§lSecurityCraft').dropdown('プレイヤーを選択してください', playerNames, {
                    defaultValueIndex: 0, // デフォルトは「全プレイヤー」
                    tooltip: 'プレイヤーを選択', // 必要に応じてツールチップを追加（任意）
                });

                // フォームを表示
                form.show(player).then(response => {
                    if (response.canceled) return; // フォームがキャンセルされた場合は終了

                    const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス

                    if (selectedIndex === 0) {
                        // 「全プレイヤー」が選択された場合
                        for (const targetPlayer of adventurePlayers) {
                            targetPlayer.runCommand('gamemode default @s');
                            player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§e解除しました`);
                            resetPlayerXrayData(`${targetPlayer.name}`);
                        }
                    } else {
                        // 個別のプレイヤーが選択された場合
                        const selectedPlayer = adventurePlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                        selectedPlayer.runCommand('gamemode default @s');
                        player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§e解除しました`);
                        resetPlayerXrayData(`${selectedPlayer.name}`);
                    }
                    player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                });
                break;
            case 4:
                // 特定のアイテムを使用したときにフォームを表示する関数
                function showPlayerSelector(player) {
                    // すべてのプレイヤーを取得
                    const allPlayers = world.getAllPlayers();
                    const playerNames = allPlayers.map(p => p.name); // プレイヤーの名前を配列に変換
                    playerNames.unshift('全プレイヤー'); // ドロップダウンの先頭に「全プレイヤー」を追加

                    // フォームを作成
                    var form = new ModalFormData()
                        .title('§0§lSecurityCraft')
                        .dropdown('プレイヤーを選択してください', playerNames, {
                            defaultValueIndex: 0, // デフォルトは「全プレイヤー」
                            tooltip: 'プレイヤーを選択', // 必要に応じてツールチップを追加（任意）
                        })
                        .toggle('§cオフ§r:§aオン§r=§c解除§r:§a追加', {
                            defaultValue: true, // タグを付与するか削除するかのデフォルト値
                            tooltip: 'タグの追加または解除を選択', // 必要に応じてツールチップを追加（任意）
                        });

                    // フォームを表示
                    form.show(player).then(response => {
                        if (response.canceled) return; // フォームがキャンセルされた場合は終了

                        const selectedIndex = response.formValues[0]; // 選択したドロップダウンのインデックス
                        const addTag = response.formValues[1]; // タグを付与するか削除するか（true/false）

                        if (selectedIndex === 0) {
                            // 「全プレイヤー」が選択された場合
                            for (const targetPlayer of allPlayers) {
                                if (addTag) {
                                    targetPlayer.addTag('SecurityMember');
                                    player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rに§a追加しました`);
                                } else {
                                    targetPlayer.removeTag('SecurityMember');
                                    player.sendMessage(`§r[§bSecurity§r] §b${targetPlayer.name}§rを§eMember§rから§c解除しました`);
                                }
                            }
                        } else {
                            // 個別のプレイヤーが選択された場合
                            const selectedPlayer = allPlayers[selectedIndex - 1]; // インデックス調整（「全プレイヤー」を除く）
                            if (addTag) {
                                selectedPlayer.addTag('SecurityMember');
                                player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rに§a追加しました`);
                            } else {
                                selectedPlayer.removeTag('SecurityMember');
                                player.sendMessage(`§r[§bSecurity§r] §b${selectedPlayer.name}§rを§eMember§rから§c解除しました`);
                            }
                        }
                        player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
                    });
                }
                showPlayerSelector(player);
                break;
            case 5:
                SettingUI(player);
                break;
            case 6:
                var form = new ActionFormData();
                form.title(`§l§0SecurityCraft`);
                form.body(`§aアドオン名§r:§bSecurityCraft\n§eVersion§r:§b3.6.0\n§cリリース日§r:§b2025/08/13`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                form.show(player).then(r => {
                    if (r.canceled) return;
                    let response = r.selection;
                    switch (response) {
                        case 0:
                            //戻る
                            UI(player);
                            break;
                    }
                });
                break;
            default:
                break;
        }
    });
}

function Securityinformation(player) {
    var form = new ActionFormData();
    form.title(`§l§0SecurityCraft`);
    form.body(`§aセキュリティー情報`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.divider();
    form.label(
        `§r・§a座標ログ§r: §r§b${world.getDynamicProperty('Log_system')}\n§r・§v設置記録§r: §r§b${world.getDynamicProperty('PlaceBlock_system')}\n§r・§9破壊記録§r: §r§b${world.getDynamicProperty('BreakBlock_system')}\n§r・§c禁止アイテム設置検知§r:§b${world.getDynamicProperty('itemUseOn_system')}\n§r・§eX-ray検知Level§r:§b${world.getDynamicProperty(
            'X_RAY_LEVEL'
        )}\n§r・§dチャット検知Level§r:§b${world.getDynamicProperty('CHAT_LEVEL')}`
    );
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                UI(player);
                break;
        }
    });
}
