import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

import { securityLogNames, lreload } from './log/Location';
import { clearAllBreakData, breload } from './log/BreakBlock';
import { clearAllPlaceData, preload } from './log/PlaceBlock';
import { clearAllChestData, creload } from './log/AccessLog';

import { RestoreSettingUI } from './reset/BlockRestore';

import { clearAllEntityLogData, ereload } from './log/EntityLog';

import { UI } from './ui';

export function SettingUI(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4検知システム設定', 'textures/ui/bubble_empty');
    form.button('§2復元設定', 'textures/ui/bubble_empty');
    form.button('§1座標ログ設定', 'textures/ui/bubble_empty');
    form.button('§5設置記録設定', 'textures/ui/bubble_empty');
    form.button('§1破壊記録設定', 'textures/ui/bubble_empty');
    form.button('§0アクセス記録設定', 'textures/ui/bubble_empty');
    form.button('§1エンティティ記録設定', 'textures/ui/bubble_empty');
    form.button('§4禁止アイテム', 'textures/ui/bubble_empty');
    form.button('§0日本語化設定', 'textures/ui/language_glyph_color');
    form.button('§0時刻設定', 'textures/ui/world_glyph_color_2x');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: //戻る
                UI(player);
                break;
            case 1: //検知システム
                openDetectionMenu(player);
                break;
            case 2: // 復元設定
                RestoreSettingUI(player, SettingUI);
                break;
            case 3: // 座標ログ
                openLogMenu(player);
                break;
            case 4: //設置記録
                PlaceBlockMenu(player);
                break;
            case 5: //破壊記録
                BreakBlockMenu(player);
                break;
            case 6: //アクセス記録設定
                ChestLogMenu(player);
                break;
            case 7: //エンティティ記録設定
                EntityLogMenu(player);
                break;
            case 8: // 禁止アイテム
                openBanItemMenu(player);
                break;
            case 9: // 日本語化設定
                JPMenu(player);
                break;
            case 10: // 時刻設定
                setTime(player);
                break;
        }
    });
}

function setTime(player) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + 0 * 60 * 60 * 1000);
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `${hours}:${minutes}`;

    const Time_Setting = world.getDynamicProperty('Time_Setting');

    new ModalFormData()
        .title('§0SecurityCraft-§1Core')
        .textField(`§b${time} §aからの時差を入力してください`, `${Time_Setting}`)
        .show(player)
        .then(res => {
            if (res.canceled) {
                SettingUI(player);
                return;
            }
            const toggleValue = Number(res.formValues[0]);
            world.setDynamicProperty('Time_Setting', toggleValue);
            player.sendMessage(`[§bSecurityCraft§r] §a時刻を設定しました`);
            player.playSound('random.toast', {
                pitch: 1.7,
                volume: 1.0,
            });
            SettingUI(player);
        });
}

// ==== エンティティ記録メニュー ====
function EntityLogMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    const isLogSystemEnabled = world.getDynamicProperty('EntityLog_system');
    form.button(`§0エンティティ記録システム\n§0(${isLogSystemEnabled ? '§1有効' : '§5無効'}§0)`, 'textures/ui/bubble_empty');
    form.button('§1監視エンティティ\n§r§1追加§r・§4削除', 'textures/ui/bubble_empty');
    form.button('§1記録削除期間', 'textures/ui/bubble_empty');
    form.button('§4記録データ削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        switch (r.selection) {
            case 0:
                SettingUI(player);
                break;
            case 1: // 有効/無効切り替え
                world.setDynamicProperty('EntityLog_system', !isLogSystemEnabled);
                EntityLogMenu(player);
                break;
            case 2: // 追加・削除メニューへ
                openEntityTargetMenu(player);
                break;
            case 3: // 削除期間
                var speedForm = new ModalFormData();
                speedForm.title('§0SecurityCraft-§1Core');
                speedForm.textField('§a記録の削除期間\n§e※数値を大きくするとラグの原因になります', '7', { defaultValue: `${world.getDynamicProperty('entitylog_delete_speed')}` });

                speedForm.show(player).then(response => {
                    if (response.canceled) {
                        EntityLogMenu(player);
                        return;
                    }
                    const selectedIndex = Number(response.formValues[0]);
                    world.setDynamicProperty('entitylog_delete_speed', selectedIndex);
                    player.sendMessage(`§r[§bSecurityCraft§r] §c記録削除期間を§b${selectedIndex}日§cに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    if (typeof ereload === 'function') ereload();
                    EntityLogMenu(player);
                });
                break;
            case 4: // データ削除
                let confirmForm = new ActionFormData().title('§4記録削除確認').body('§e本当にエンティティ記録を削除しますか？\n§cこの操作は元に戻せません').button(`§l戻る`, 'textures/ui/icon_import.png').button('§4すべて削除', 'textures/ui/bubble_empty');
                confirmForm.show(player).then(res => {
                    if (res.canceled || res.selection === 0) {
                        EntityLogMenu(player);
                        return;
                    }
                    if (typeof clearAllEntityLogData === 'function') clearAllEntityLogData();
                    player.sendMessage(`§r[§bSecurityCraft§r] §cエンティティログを削除しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                });
                break;
        }
    });
}

function openEntityTargetMenu(player) {
    new ActionFormData()
        .title('§0SecurityCraft-§1Core')
        .body(`>>> §e監視エンティティ操作`)
        .button('§l戻る', 'textures/ui/icon_import.png')
        .button('§1追加', 'textures/ui/bubble_empty')
        .button('§4削除', 'textures/ui/bubble_empty')
        .show(player)
        .then(response => {
            if (response.canceled || response.selection === 0) {
                EntityLogMenu(player);
                return;
            }
            if (response.selection === 1) addEntityTarget(player);
            else if (response.selection === 2) removeEntityTarget(player);
        });
}

function addEntityTarget(player) {
    new ModalFormData()
        .title('§0SecurityCraft-§1Core')
        .textField('§a追加する§eエンティティID§aを入力:', '例:minecraft:armor_stand')
        .show(player)
        .then(response => {
            if (response.canceled) {
                openEntityTargetMenu(player);
                return;
            }
            const newEntity = response.formValues[0].trim();
            if (!newEntity) return openEntityTargetMenu(player);

            let targets = JSON.parse(world.getDynamicProperty('EntityLog_targets') || '[]');
            if (!targets.includes(newEntity)) {
                targets.push(newEntity);
                world.setDynamicProperty('EntityLog_targets', JSON.stringify(targets));
                player.sendMessage(`[§bSecurityCraft§r] §b${newEntity}§rを監視対象に§e追加しました`);
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                player.sendMessage(`[§bSecurityCraft§r] §b${newEntity}§rは既に§c追加されています`);
                player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            }
            openEntityTargetMenu(player);
        });
}

function removeEntityTarget(player) {
    let targets = JSON.parse(world.getDynamicProperty('EntityLog_targets') || '[]');
    if (targets.length === 0) {
        player.sendMessage('[§bSecurityCraft§r] §c削除できるエンティティはありません');
        openEntityTargetMenu(player);
        return;
    }

    new ModalFormData()
        .title('§0SecurityCraft-§1Core')
        .dropdown('削除するエンティティを選択:', targets)
        .show(player)
        .then(response => {
            if (response.canceled) {
                openEntityTargetMenu(player);
                return;
            }
            const selectedEntity = targets[response.formValues[0]];
            targets = targets.filter(item => item !== selectedEntity);
            world.setDynamicProperty('EntityLog_targets', JSON.stringify(targets));
            player.sendMessage(`[§bSecurityCraft§r] §b${selectedEntity}§rを監視対象から§e削除しました`);
            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            openEntityTargetMenu(player);
        });
}

//破壊メニュー
function BreakBlockMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (world.getDynamicProperty('BreakBlock_system')) {
        form.button(`§0破壊記録システム\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0破壊記録システム\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }
    form.button('§1破壊記録削除期間', 'textures/ui/bubble_empty');
    form.button('§1破壊検知範囲設定', 'textures/ui/bubble_empty');
    form.button('§4破壊記録データ削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // 破壊記録システム
                var form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                const isLogSystemEnabled = world.getDynamicProperty('BreakBlock_system');
                form.body(`破壊記録システム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                if (isLogSystemEnabled) {
                    form.button('§4無効化', 'textures/ui/bubble_empty');
                } else {
                    form.button('§9有効化', 'textures/ui/bubble_empty');
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    const selection = r.selection;
                    if (selection === 0) {
                        BreakBlockMenu(player);
                        return;
                    }
                    if (isLogSystemEnabled) {
                        world.setDynamicProperty('BreakBlock_system', false);
                    } else {
                        world.setDynamicProperty('BreakBlock_system', true);
                    }

                    BreakBlockMenu(player);
                });
                break;
            case 2: // 破壊記録データ削除期間
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                form.textField('§a破壊記録の削除期間\n§e※数値を大きくするとラグの原因になります', '3', { defaultValue: `${world.getDynamicProperty('breakblock_delete_speed')}` });

                form.show(player).then(response => {
                    if (response.canceled) {
                        BreakBlockMenu(player);
                        return;
                    }

                    const selectedIndex = Number(response.formValues[0]);
                    world.setDynamicProperty('breakblock_delete_speed', selectedIndex);
                    player.sendMessage(`§r[§bSecurityCraft§r] §c破壊記録削除期間を§b${selectedIndex}日§cに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    breload();
                    BreakBlockMenu(player);
                });
                break;
            case 3:
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                // 現在の設定値を取得してデフォルト値にする
                const currentRadius = world.getDynamicProperty('breakblock_search_radius') || 7;
                form.textField('§a破壊検知の半径を指定してください\n§e(デフォルト: 7)', '1～32', { defaultValue: `${currentRadius}` });

                form.show(player).then(response => {
                    if (response.canceled) {
                        BreakBlockMenu(player);
                        return;
                    }

                    let radius = Number(response.formValues[0]);
                    if (isNaN(radius) || radius < 1) radius = 7;

                    world.setDynamicProperty('breakblock_search_radius', radius);
                    player.sendMessage(`§r[§bSecurityCraft§r] §a検知範囲を半径§b${radius}§aブロックに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    breload(); // 設定を再読み込み
                    BreakBlockMenu(player);
                });
                break;
            case 4: // 破壊記録データ削除
                let confirmBreakForm = new ActionFormData();
                confirmBreakForm.title('§4破壊ログ削除確認');
                confirmBreakForm.body('§e本当に破壊ログを削除しますか？\n§cこの操作は元に戻せません');
                confirmBreakForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                confirmBreakForm.button('§4すべて削除', 'textures/ui/bubble_empty');
                confirmBreakForm.show(player).then(res => {
                    if (res.canceled || res.selection === 0) {
                        BreakBlockMenu(player);
                        return;
                    }
                    clearAllBreakData();
                    player.sendMessage(`§r[§bSecurityCraft§r] §c破壊ログを削除しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                });
                break;
        }
    });
}

//設置メニュー
function PlaceBlockMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (world.getDynamicProperty('PlaceBlock_system')) {
        form.button(`§0設置記録システム\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0設置記録システム\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }
    form.button('§1設置記録削除期間', 'textures/ui/bubble_empty');
    form.button('§4設置記録データ削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // 設置記録システム
                var form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                const isLogSystemEnabled = world.getDynamicProperty('PlaceBlock_system');
                form.body(`設置記録システム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                if (isLogSystemEnabled) {
                    form.button('§4無効化', 'textures/ui/bubble_empty');
                } else {
                    form.button('§9有効化', 'textures/ui/bubble_empty');
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    const selection = r.selection;
                    if (selection === 0) {
                        PlaceBlockMenu(player);
                        return;
                    }
                    if (isLogSystemEnabled) {
                        world.setDynamicProperty('PlaceBlock_system', false);
                    } else {
                        world.setDynamicProperty('PlaceBlock_system', true);
                    }

                    PlaceBlockMenu(player);
                });
                break;
            case 2: // 設置記録データ削除期間
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                form.textField('§a設置記録の削除期間\n§e※数値を大きくするとラグの原因になります', '3', { defaultValue: `${world.getDynamicProperty('placeblock_delete_speed')}` });

                form.show(player).then(response => {
                    if (response.canceled) {
                        PlaceBlockMenu(player);
                        return;
                    }

                    const selectedIndex = Number(response.formValues[0]);
                    world.setDynamicProperty('placeblock_delete_speed', selectedIndex);
                    player.sendMessage(`§r[§bSecurityCraft§r] §c設置記録削除期間を§b${selectedIndex}日§cに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    preload();
                    PlaceBlockMenu(player);
                });
                break;
            case 3: // 設置記録データ削除
                let confirmPlaceForm = new ActionFormData();
                confirmPlaceForm.title('§4設置ログ削除確認');
                confirmPlaceForm.body('§e本当に設置ログを削除しますか？\n§cこの操作は元に戻せません');
                confirmPlaceForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                confirmPlaceForm.button('§4すべて削除', 'textures/ui/bubble_empty');
                confirmPlaceForm.show(player).then(res => {
                    if (res.canceled || res.selection === 0) {
                        PlaceBlockMenu(player);
                        return;
                    }
                    clearAllPlaceData();
                    player.sendMessage(`§r[§bSecurityCraft§r] §c設置ログを削除しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                });
                break;
        }
    });
}

// 検知システムメニュー
function openDetectionMenu(player) {
    const Xray_system = world.getDynamicProperty('X_RAYCheck_LEVEL') ?? 0;
    let Xray_level_Text = '§4無効§r';
    if (Xray_system >= 1 && Xray_system <= 5) {
        Xray_level_Text = `レベル ${Xray_system}`;
    } else if (Xray_system === 6) {
        Xray_level_Text = 'ログのみ記録';
    }
    const Chat_system = world.getDynamicProperty('CHAT_LEVEL') ?? 0;

    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button(`§4X-ray検知\n§0(${Xray_level_Text}§0)`, 'textures/ui/bubble_empty');
    form.button(`§1不正チャット検知\n§0(${Chat_system > 0 ? `§0レベル ${Chat_system}` : '§4無効'}§0)`, 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1:
                openXraySettings(player);
                break;
            case 2:
                openChatSettings(player);
                break;
        }
    });
}

// X-ray検知設定
function openXraySettings(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');

    // 現在の設定値から表示文字列を分岐
    const currentLevel = world.getDynamicProperty('X_RAYCheck_LEVEL') ?? 0;
    let levelText = '無効';
    if (currentLevel >= 1 && currentLevel <= 5) {
        levelText = `Level-${currentLevel}`;
    } else if (currentLevel === 6) {
        levelText = 'ログのみ記録';
    }

    form.body(`X-ray検知レベル§r:§b${levelText}\n§r>>> §e選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png'); // response = 0
    form.button('§1無効化(推奨) \n§8検知システムが実行されません', 'textures/ui/bubble_empty'); // response = 1 -> 0
    form.button('§1Level-1 \n§8誤検知を最小限に抑える', 'textures/ui/bubble_empty'); // response = 2 -> 1
    form.button('§1Level-2 \n§8バランスの取れた検知レベル', 'textures/ui/bubble_empty'); // response = 3 -> 2
    form.button('§1Level-3 \n§8標準より少し厳しい検知', 'textures/ui/bubble_empty'); // response = 4 -> 3
    form.button('§1Level-4 \n§8高速検知', 'textures/ui/bubble_empty'); // response = 5 -> 4
    form.button('§1Level-5 \n§8即時検知', 'textures/ui/bubble_empty'); // response = 6 -> 5
    form.button('§1ログのみ記録 \n§8検知制限なし', 'textures/ui/bubble_empty'); // response = 7 -> 6

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        if (response === 0) {
            openDetectionMenu(player);
            return;
        }
        world.setDynamicProperty('X_RAYCheck_LEVEL', response - 1);
        openDetectionMenu(player);
    });
}
// 不正チャット検知設定
function openChatSettings(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`不正チャット検知レベル§r:§b${world.getDynamicProperty('CHAT_LEVEL') || '無効'}\n§r>>>§e 選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§1無効化 \n§8検知システムが実行されません', 'textures/ui/bubble_empty');
    form.button('§1Level-1 \n§8最小限の対応', 'textures/ui/bubble_empty');
    form.button('§1Level-2 \n§8中程度の対応', 'textures/ui/bubble_empty');
    form.button('§1Level-3 \n§8厳密な対応', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        if (response === 0) {
            openDetectionMenu(player);
            return;
        }
        world.setDynamicProperty('CHAT_LEVEL', response - 1);
        openDetectionMenu(player);
    });
}

// 座標ログメニュー
function openLogMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (world.getDynamicProperty('Log_system')) {
        form.button(`§0座標ログシステム\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0座標ログシステム\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }
    form.button('§1座標ログ削除期間', 'textures/ui/bubble_empty');
    form.button('§4座標ログデータ削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // 座標ログシステム
                toggleLogSystem(player);
                break;
            case 2: // 座標ログデータ削除期間
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                form.textField('§a座標ログの削除期間\n§e※数値を大きくするとラグの原因になります', '3', { defaultValue: `${world.getDynamicProperty('location_delete_speed')}` });

                form.show(player).then(response => {
                    if (response.canceled) {
                        openLogMenu(player);
                        return;
                    }

                    const selectedIndex = Number(response.formValues[0]);
                    world.setDynamicProperty('location_delete_speed', selectedIndex);
                    player.sendMessage(`§r[§bSecurityCraft§r] §c座標ログ削除期間を§b${selectedIndex}日§cに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    lreload();
                    openLogMenu(player);
                });
                break;
            case 3: // 座標ログデータ削除
                openLogDeleteMenu(player);
                break;
        }
    });
}

// 座標ログシステム設定
function toggleLogSystem(player) {
    const form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    const isLogSystemEnabled = world.getDynamicProperty('Log_system');
    form.body(`座標ログシステム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (isLogSystemEnabled) {
        form.button('§4無効化', 'textures/ui/bubble_empty');
    } else {
        form.button('§9有効化', 'textures/ui/bubble_empty');
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        const selection = r.selection;
        if (selection === 0) {
            openLogMenu(player);
            return;
        }
        if (isLogSystemEnabled) {
            world.setDynamicProperty('Log_system', false);
        } else {
            world.setDynamicProperty('Log_system', true);
        }

        openLogMenu(player);
    });
}

// ログデータ削除メニュー
function openLogDeleteMenu(player) {
    confirmDeleteData(player);
}

// データ削除確認
function confirmDeleteData(player) {
    const form = new ActionFormData();
    form.title('§4座標ログ削除確認');
    form.body('§e本当に座標ログを削除しますか？\n§cこの操作は元に戻せません');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§4すべて削除', 'textures/ui/bubble_empty');
    form.show(player).then(res => {
        if (res.canceled || res.selection === 0) {
            openLogMenu(player);
            return;
        }
        try {
            const allProperties = world.getDynamicPropertyIds();
            // ログデータ(キーに日付が含まれるもの)とプレイヤーリスト(location_names)のみを削除対象とする
            const propertiesToDelete = allProperties.filter(id => id.startsWith('location_') && (/_(\d{8})/.test(id) || id === 'location_names'));

            propertiesToDelete.forEach(prop => {
                try {
                    world.setDynamicProperty(prop, undefined);
                } catch (e) {
                    console.warn(`プロパティ削除エラー (${prop}): ${e}`);
                }
            });

            // メモリ上のプレイヤー名リストもクリア
            securityLogNames.length = 0;

            player.sendMessage('§r[§bSecurityCraft§r] §aすべてのログデータを削除しました');
            player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
        } catch (e) {
            console.warn(`データ削除エラー: ${e}`);
            player.sendMessage('§r[§bSecurityCraft§r] §cデータ削除中にエラーが発生しました');
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
        }

        openLogMenu(player); // 削除後にメインメニューに戻る
    });
}

// 禁止アイテムメニュー
function openBanItemMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (world.getDynamicProperty('itemUseOn_system')) {
        form.button(`§0禁止設置アイテムシステム\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0禁止設置アイテムシステム\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }
    form.button('§4禁止設置アイテム\n§r§1追加§r・§4削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // 禁止設置アイテムシステム
                toggleItemSystem(player);
                break;
            case 2: // 禁止設置アイテム
                openBanMenu(player);
                break;
        }
    });
}

// 禁止アイテムシステム設定
function toggleItemSystem(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    const isLogSystemEnabled = world.getDynamicProperty('itemUseOn_system');
    form.body(`禁止設置アイテムシステム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (isLogSystemEnabled) {
        form.button('§4無効化', 'textures/ui/bubble_empty');
    } else {
        form.button('§9有効化', 'textures/ui/bubble_empty');
    }
    form.show(player).then(r => {
        if (r.canceled) {
            return;
        }
        const selection = r.selection;
        if (selection === 0) {
            PlaceBlockMenu(player);
            return;
        }
        if (isLogSystemEnabled) {
            world.setDynamicProperty('itemUseOn_system', false);
        } else {
            world.setDynamicProperty('itemUseOn_system', true);
        }

        PlaceBlockMenu(player);
    });
}

// 禁止アイテム編集メニュー
function openBanMenu(player) {
    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body(`>>> §e禁止アイテム操作`).button('§l戻る', 'textures/ui/icon_import.png').button('§1追加', 'textures/ui/bubble_empty').button('§4削除', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled || response.selection === 0) {
            openBanItemMenu(player);
            return;
        }
        if (response.selection === 1) {
            addBannedBlock(player);
        } else if (response.selection === 2) {
            removeBannedBlock(player);
        }
    });
}

// アイテム追加
function addBannedBlock(player) {
    const form = new ModalFormData().title('§0SecurityCraft-§1Core').textField('§a追加する§eアイテムID§aを入力:', '例:minecraft:tnt');

    form.show(player).then(response => {
        if (response.canceled) {
            openBanMenu(player);
            return;
        }
        const newBlock = response.formValues[0].trim();
        if (!newBlock) {
            openBanMenu(player);
            return;
        }

        let bannedBlocks = world.getDynamicProperty('bannedBlocks') ? JSON.parse(world.getDynamicProperty('bannedBlocks')) : [];
        if (!bannedBlocks.includes(newBlock)) {
            bannedBlocks.push(newBlock);
            world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
            player.sendMessage(`[§bSecurityCraft§r] §b${newBlock}§rを禁止アイテムに§e追加しました`);
            player.runCommand(`playsound random.toast @s ~ ~ ~ 1.0 0.9 0.7`);
            player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            openBanMenu(player);
        } else {
            player.sendMessage(`[§bSecurityCraft§r] §b${newBlock}§rは既に§c禁止されています`);
            player.playSound('random.toast', { pitch: 0.4, volume: 0.7 });
            openBanMenu(player);
        }
    });
}

// アイテム削除
function removeBannedBlock(player) {
    let bannedBlocks = world.getDynamicProperty('bannedBlocks') ? JSON.parse(world.getDynamicProperty('bannedBlocks')) : [];
    if (bannedBlocks.length === 0) {
        player.sendMessage('[§bSecurityCraft§r] §c削除できる禁止アイテムはありません');
        return;
    }

    const form = new ModalFormData().title('§0SecurityCraft-§1Core').dropdown('すべて削除アイテムを選択:', bannedBlocks);

    form.show(player).then(response => {
        if (response.canceled) {
            openBanMenu(player);
            return;
        }
        const selectedBlock = bannedBlocks[response.formValues[0]];
        confirmRemove(player, selectedBlock);
    });
}

// 削除確認
function confirmRemove(player, block) {
    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body(`本当に ${block} を削除しますか？`).button('§4すべて削除', 'textures/ui/bubble_empty').button('§1キャンセル', 'textures/ui/bubble_empty');

    form.show(player).then(response => {
        if (response.canceled || response.selection !== 0) {
            openBanMenu(player);
            return;
        }

        let bannedBlocks = JSON.parse(world.getDynamicProperty('bannedBlocks'));
        bannedBlocks = bannedBlocks.filter(item => item !== block);
        world.setDynamicProperty('bannedBlocks', JSON.stringify(bannedBlocks));
        player.sendMessage(`[§bSecurityCraft§r] §b${block}§rを禁止アイテムから§e削除しました`);
        player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
        openBanMenu(player);
    });
}

// アクセス記録メニュー
function ChestLogMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    if (world.getDynamicProperty('ChestLog_system')) {
        form.button(`§0アクセス記録システム\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0アクセス記録システム\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }
    form.button('§1アクセス記録削除期間', 'textures/ui/bubble_empty');
    form.button('§4アクセス記録データ削除', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // アクセス記録システム
                var form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                const isLogSystemEnabled = world.getDynamicProperty('ChestLog_system');
                form.body(`アクセス記録システム - ${isLogSystemEnabled ? '§a有効' : '§c無効'}`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                if (isLogSystemEnabled) {
                    form.button('§4無効化', 'textures/ui/bubble_empty');
                } else {
                    form.button('§9有効化', 'textures/ui/bubble_empty');
                }
                form.show(player).then(r => {
                    if (r.canceled || r.selection === 0) {
                        ChestLogMenu(player);
                        return;
                    }
                    world.setDynamicProperty('ChestLog_system', !isLogSystemEnabled);
                    ChestLogMenu(player);
                });
                break;
            case 2: // 削除期間
                var form = new ModalFormData();
                form.title('§0SecurityCraft-§1Core');
                form.textField('§aアクセス記録の削除期間\n§e※数値を大きくするとラグの原因になります', '7', { defaultValue: `${world.getDynamicProperty('chestlog_delete_speed')}` });

                form.show(player).then(response => {
                    if (response.canceled) {
                        ChestLogMenu(player);
                        return;
                    }
                    const selectedIndex = Number(response.formValues[0]);
                    world.setDynamicProperty('chestlog_delete_speed', selectedIndex);
                    player.sendMessage(`§r[§bSecurityCraft§r] §cアクセス記録削除期間を§b${selectedIndex}日§cに変更しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                    creload();
                    ChestLogMenu(player);
                });
                break;
            case 3: // データ削除
                let confirmForm = new ActionFormData();
                confirmForm.title('§4アクセスログ削除確認');
                confirmForm.body('§e本当にアクセスログを削除しますか？\n§cこの操作は元に戻せません');
                confirmForm.button(`§l戻る`, 'textures/ui/icon_import.png');
                confirmForm.button('§4すべて削除', 'textures/ui/bubble_empty');
                confirmForm.show(player).then(res => {
                    if (res.canceled || res.selection === 0) {
                        ChestLogMenu(player);
                        return;
                    }
                    clearAllChestData();
                    player.sendMessage(`§r[§bSecurityCraft§r] §cアクセスログを削除しました`);
                    player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
                });
                break;
        }
    });
}

//日本語化メニュー
function JPMenu(player) {
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §e選択してください');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.label('※一部の機能でご利用いただけます');
    if (world.getDynamicProperty('JPChange')) {
        form.button(`§0日本語化\n§0(§1有効§0)`, 'textures/ui/bubble_empty');
    } else {
        form.button(`§0日本語化\n§0(§5無効§0)`, 'textures/ui/bubble_empty');
    }

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0: // 戻る
                SettingUI(player);
                break;
            case 1: // 日本語化システム
                var form = new ActionFormData();
                form.title('§0SecurityCraft-§1Core');
                const SystemEnabled = world.getDynamicProperty('JPChange');
                form.body(`日本語化 - ${SystemEnabled ? '§a有効' : '§c無効'}`);
                form.button(`§l戻る`, 'textures/ui/icon_import.png');
                if (SystemEnabled) {
                    form.button('§4無効化', 'textures/ui/bubble_empty');
                } else {
                    form.button('§9有効化', 'textures/ui/bubble_empty');
                }
                form.show(player).then(r => {
                    if (r.canceled) {
                        return;
                    }
                    const selection = r.selection;
                    if (selection === 0) {
                        JPMenu(player);
                        return;
                    }
                    if (SystemEnabled) {
                        world.setDynamicProperty('JPChange', false);
                    } else {
                        world.setDynamicProperty('JPChange', true);
                    }

                    JPMenu(player);
                });
                break;
        }
    });
}
