import { world, system } from '@minecraft/server';

const FLAMMABLE_TAGS = ['wood', 'log', 'leaves', 'wool', 'plant', 'carpet', 'fence', 'gate', 'bookshelf', 'tnt', 'planks', 'stairs', 'slab', 'door', 'trapdoor', 'sign', 'banner', 'bed', 'vine', 'scaffolding', 'bamboo'];

export class FireBurnDetector {
    constructor() {
        this.monitoredBlocks = new Map();
        this.recentlyBrokenByPlayer = new Set();
        this.callbacks = [];
        this.scanGenerator = null;

        this.checkInterval = null;
        this.scanInterval = null;
        this.playerBreakListener = null;

        this.isRunning = false;
        this.dimensionCache = new Map();
        this.checkIterator = null;
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;

        this._listenPlayerBreak();
        this._listenFireSources();
        this._startLoops();
    }

    stop() {
        if (!this.isRunning) return;
        this.isRunning = false;

        if (this.checkInterval) system.clearRun(this.checkInterval);
        if (this.playerBreakListener) world.afterEvents.playerBreakBlock.unsubscribe(this.playerBreakListener);

        if (this.interactBeforeListener) world.beforeEvents.playerInteractWithBlock.unsubscribe(this.interactBeforeListener);
        if (this.lightningListener) world.afterEvents.entitySpawn.unsubscribe(this.lightningListener);
        if (this.placeListener) world.afterEvents.playerPlaceBlock.unsubscribe(this.placeListener);
        if (this.projectileListener) world.afterEvents.projectileHitBlock.unsubscribe(this.projectileListener);

        this.monitoredBlocks.clear();
        this.recentlyBrokenByPlayer.clear();
    }

    onBurn(callback) {
        this.callbacks.push(callback);
    }

    _listenPlayerBreak() {
        this.playerBreakListener = world.afterEvents.playerBreakBlock.subscribe(ev => {
            const key = this._getKey(ev.block.location);
            this.recentlyBrokenByPlayer.add(key);
            system.runTimeout(() => this.recentlyBrokenByPlayer.delete(key), 2);
        });
    }

    _listenFireSources() {
        this.interactBeforeListener = world.beforeEvents.playerInteractWithBlock.subscribe(ev => {
            const player = ev.player;
            const item = ev.itemStack;

            if (!item) return;

            const type = item.typeId;
            if (type === 'minecraft:flint_and_steel' || type === 'minecraft:fire_charge' || type === 'minecraft:lava_bucket') {
                system.run(() => {
                    this._registerNeighbors(player.dimension, ev.block.location);
                });
            }
        });

        this.lightningListener = world.afterEvents.entitySpawn.subscribe(ev => {
            if (ev.entity?.typeId === 'minecraft:lightning_bolt') {
                this._registerNeighbors(ev.entity.dimension, ev.entity.location);
            }
        });

        this.placeListener = world.afterEvents.playerPlaceBlock.subscribe(ev => {
            const type = ev.block.typeId;
            if (type === 'minecraft:fire' || type === 'minecraft:soul_fire' || type === 'minecraft:lava') {
                this._registerNeighbors(ev.dimension, ev.block.location);
            }
        });

        this.projectileListener = world.afterEvents.projectileHitBlock.subscribe(ev => {
            const type = ev.projectile?.typeId;
            if (type === 'minecraft:fireball' || type === 'minecraft:small_fireball') {
                const hitBlock = ev.getBlockHit()?.block;
                if (hitBlock) this._registerNeighbors(ev.dimension, hitBlock.location);
            }
        });
    }

    _startLoops() {
        this.checkInterval = system.runInterval(() => {
            const dynamicChecks = Math.max(30, Math.ceil(this.monitoredBlocks.size / 20));
            this._checkMonitoredBlocksPartial(dynamicChecks);
        }, 1);
    }

    _checkMonitoredBlocksPartial(maxChecks) {
        if (this.monitoredBlocks.size === 0) return;

        if (!this.checkIterator) {
            this.checkIterator = this.monitoredBlocks.entries();
        }

        const now = Date.now();
        const timeoutMs = 5 * 60 * 1000;
        const toDelete = [];
        let checks = 0;

        while (checks < maxChecks) {
            const result = this.checkIterator.next();
            if (result.done) {
                this.checkIterator = null;
                break;
            }

            const [key, data] = result.value;
            const { location, dimensionId, oldTypeId, oldPermutation, timestamp } = data;

            if (now - timestamp > timeoutMs) {
                toDelete.push(key);
                continue;
            }

            let dimension = this.dimensionCache.get(dimensionId);
            if (!dimension) {
                dimension = world.getDimension(dimensionId);
                if (dimension) this.dimensionCache.set(dimensionId, dimension);
            }

            if (!dimension) {
                toDelete.push(key);
                continue;
            }

            let currentBlock;
            try {
                currentBlock = dimension.getBlock(location);
                checks++;
            } catch (e) {
                continue;
            }

            if (!currentBlock) continue;
            if (currentBlock.typeId === oldTypeId) continue;

            if (!this.recentlyBrokenByPlayer.has(key)) {
                const newId = currentBlock.typeId;
                if (newId === 'minecraft:air' || this._isFire(newId) || this._isLava(newId)) {
                    this._triggerEvent(currentBlock, oldPermutation);
                    this._registerNeighbors(dimension, location);
                }
            }
            toDelete.push(key);
        }

        for (const key of toDelete) {
            this.monitoredBlocks.delete(key);
        }
    }

    _registerNeighbors(dim, center) {
        system.runJob(this._registerNeighborsJob(dim, center));
    }

    *_registerNeighborsJob(dim, center) {
        const rangeXZ = 5;
        const rangeYDown = 5;
        const rangeYUp = 6;
        const dimRange = dim.heightRange || { min: -64, max: 320 };
        let blockChecks = 0;

        for (let dx = -rangeXZ; dx <= rangeXZ; dx++) {
            for (let dy = -rangeYDown; dy <= rangeYUp; dy++) {
                for (let dz = -rangeXZ; dz <= rangeXZ; dz++) {
                    if (dx === 0 && dy === 0 && dz === 0) continue;

                    const tLoc = {
                        x: Math.floor(center.x + dx),
                        y: Math.floor(center.y + dy),
                        z: Math.floor(center.z + dz),
                    };

                    if (tLoc.y < dimRange.min || tLoc.y >= dimRange.max) continue;

                    const key = this._getKey(tLoc);
                    if (this.monitoredBlocks.has(key)) {
                        this.monitoredBlocks.get(key).timestamp = Date.now();
                        continue;
                    }

                    try {
                        const target = dim.getBlock(tLoc);
                        if (!target) continue;

                        if (this._isFlammable(target)) {
                            this.monitoredBlocks.set(key, {
                                location: tLoc,
                                dimensionId: dim.id,
                                oldTypeId: target.typeId,
                                oldPermutation: target.permutation,
                                timestamp: Date.now(),
                            });
                        }
                    } catch (e) {}

                    blockChecks++;
                    if (blockChecks >= 50) {
                        blockChecks = 0;
                        yield;
                    }
                }
            }
        }
    }

    _isFlammable(block) {
        if (block.isAir || this._isFire(block.typeId) || this._isLava(block.typeId)) return false;

        for (const tag of FLAMMABLE_TAGS) {
            if (block.hasTag(tag)) return true;
        }

        const id = block.typeId;
        if (id === 'minecraft:tnt') return true;

        if (id.includes('fence') || id.includes('gate') || id.includes('bookshelf') || id.includes('planks') || id.includes('stairs') || id.includes('slab')) {
            if (id.includes('stone') || id.includes('brick') || id.includes('crimson') || id.includes('warped') || id.includes('copper')) return false;
            return true;
        }

        return false;
    }

    _triggerEvent(block, oldPermutation) {
        this.callbacks.forEach(cb => cb(block, oldPermutation));
    }

    _getKey(loc) {
        return `${loc.x},${loc.y},${loc.z}`;
    }

    _isFire(typeId) {
        return typeId === 'minecraft:fire' || typeId === 'minecraft:soul_fire';
    }

    _isLava(typeId) {
        return typeId === 'minecraft:lava' || typeId === 'minecraft:flowing_lava';
    }
}
