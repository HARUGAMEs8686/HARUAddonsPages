import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';
import { checkModePlayers, playerCheckModeStatus, currentTPS, chestCheckModePlayers } from './main';

import { showMainMenu_Location } from './log/Location';

import { showRestoreUI } from './reset/BlockRestore';

import { SettingUI } from './setting';

import { startPerformanceDiagnosis } from './toul/performance.js';

import { startMonitoring } from './toul/monitor.js';

import { showInventoryContents } from './toul/inventory_check.js';

import { resetPlayerXrayData, getPlayerXrayAlerts, clearPlayerXrayAlerts } from './detection/x-ray.js';

import { showMainMenu_EntityLog } from './log/EntityLog.js';

import { BlockSearchMenu } from './toul/BlockSearch.js';

import { searchPlayerBlockLogs } from './toul/BlockSearch.js';
import { showPlayerAccessLogs } from './log/AccessLog.js';
import { showPlayerEntityLogs } from './log/EntityLog.js';
import { showPlayerLocationLogs } from './log/Location';

world.beforeEvents.chatSend.subscribe(event => {
    if (world.getDynamicProperty('CHAT_LEVEL') == 0) {
        return;
    }
    const player = event.sender;
    const message = event.message;

    if (message == '!scp' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (checkModePlayers.has(player.name)) {
                checkModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                checkModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scb' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (playerCheckModeStatus[player.name] == true) {
                playerCheckModeStatus[player.name] = false;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊&燃焼確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                playerCheckModeStatus[player.name] = true;
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊&燃焼確認モード§rを§5ON§rにしました.§e破壊された周辺のブロックタッチすると破壊者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
    if (message == '!scc' && player.hasTag('SecurityOP')) {
        event.cancel = true;
        system.run(() => {
            if (chestCheckModePlayers.has(player.name)) {
                chestCheckModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            } else {
                chestCheckModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5ON§rにしました.§eチェストや樽をタッチするとアクセス履歴を見れます');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            }
        });
    }
});

export function UI(player) {
    // --- データ容量計算ロジック ---
    let totalStorageSize = '計算中...';
    try {
        let totalBytes = 0;
        const keys = world.getDynamicPropertyIds();

        for (const key of keys) {
            // キー自体の長さ
            totalBytes += key.length;

            const value = world.getDynamicProperty(key);
            if (typeof value === 'string') {
                // 文字列の長さ (JSONデータが大半なのでこれで概算)
                totalBytes += value.length;
            } else if (typeof value === 'number') {
                totalBytes += 8; // 数値は約8バイト
            } else if (typeof value === 'boolean') {
                totalBytes += 4; // 真偽値は約4バイト
            }
        }

        // 表示単位の調整
        if (totalBytes < 1024) {
            totalStorageSize = `${totalBytes} B`;
        } else if (totalBytes < 1024 * 1024) {
            totalStorageSize = `${(totalBytes / 1024).toFixed(2)} KB`;
        } else {
            totalStorageSize = `${(totalBytes / (1024 * 1024)).toFixed(2)} MB`;
        }
    } catch (e) {
        totalStorageSize = 'エラー';
    }

    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;

    var players = world.getPlayers();
    const xrayLevel = world.getDynamicProperty('X_RAYCheck_LEVEL') ?? 0;

    const menuItems = [
        { text: '§0確認モード切替', icon: 'textures/ui/confirm.png', action: () => CheckMode(player) },
        { text: '§1座標ログ', icon: 'textures/ui/icon_timer.png', action: () => showMainMenu_Location(player) },
        { text: '§5復元', icon: 'textures/ui/backup_replace.png', action: () => showRestoreUI(player) },
        { text: '§0プレイヤー §4監視§0/§1情報/§5記録', icon: 'textures/ui/dressing_room_customization', action: () => PlayerManagerPlayerSelector(player) },
        { text: '§4エンティティキル検索', icon: 'textures/ui/icon_recipe_equipment.png', action: () => showMainMenu_EntityLog(player) },
        { text: '§0ブロックデータ検索', icon: 'textures/ui/creative_icon.png', action: () => BlockSearchMenu(player) },
        { text: '§0パフォーマンス', icon: 'textures/ui/mashup_world', action: () => Performance(player) },
        { text: '§4信頼メンバー', icon: 'textures/ui/permissions_member_star.png', action: () => showPlayerSelector(player) },
    ];

    if (xrayLevel !== 0) {
        menuItems.push({ text: '§0X-ray検知', icon: 'textures/ui/vr_glyph_color.png', action: () => XrayDetectionMenu(player) });
    }

    menuItems.push({ text: '§1設定', icon: 'textures/ui/icon_setting', action: () => SettingUI(player) });
    menuItems.push({ text: '§0システム情報', icon: 'textures/items/stick', action: () => Systeminformation(player) });
    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`§b${time}`);
    form.divider();
    form.label(`§r・§aプレイヤー人数§r: §r§b${players.length}\n§r・§eTPS§r:§b${currentTPS}\n§r・§cデータ容量(約)§r:§b${totalStorageSize}`);
    form.divider();
    for (const item of menuItems) {
        form.button(item.text, item.icon);
    }
    form.show(player).then(r => {
        if (r.canceled) return;
        menuItems[r.selection].action();
    });
}

function CheckMode(player) {
    var form = new ModalFormData();
    form.title('§0SecurityCraft-§1Core');
    form.label('>>> §eモードを操作してください');
    form.toggle('§a設置確認', {
        defaultValue: checkModePlayers.has(player.name),
    });
    form.toggle('§c破壊&燃焼確認', {
        defaultValue: playerCheckModeStatus[player.name] ?? false,
    });
    form.toggle('§eアクセス確認', {
        defaultValue: chestCheckModePlayers.has(player.name) ?? false,
    });
    form.submitButton(`§1適用`);
    form.show(player).then(r => {
        if (r.canceled) {
            UI(player);
            return;
        }
        const [Text, setPlacementCheck, setBreakCheck, setChestCheck] = r.formValues;
        const wasPlacementCheck = checkModePlayers.has(player.name);
        const wasBreakCheck = playerCheckModeStatus[player.name] ?? false;
        const wasChestCheck = chestCheckModePlayers.has(player.name);

        // 設置チェック切替
        if (setPlacementCheck !== wasPlacementCheck) {
            if (setPlacementCheck) {
                checkModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5ON§rにしました.§eブロックをタッチすると設置者が分かります');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            } else {
                checkModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §a設置確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            }
        }

        // 破壊チェック切替
        if (setBreakCheck !== wasBreakCheck) {
            playerCheckModeStatus[player.name] = setBreakCheck;
            if (setBreakCheck) {
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊&燃焼確認モード§rを§5ON§rにしました.§eブロック周辺をタッチで破壊履歴を確認');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            } else {
                player.sendMessage('§r[§bSecurityCraft§r] §a破壊&燃焼確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            }
        }

        if (setChestCheck !== wasChestCheck) {
            if (setChestCheck) {
                chestCheckModePlayers.add(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5ON§rにしました.§e収納ブロック,竈,看板をタッチするとアクセス履歴を見れます');
                player.playSound('random.toast', { pitch: 1.5, volume: 0.7 });
            } else {
                chestCheckModePlayers.delete(player.name);
                player.sendMessage('§r[§bSecurityCraft§r] §aアクセス確認モード§rを§5OFF§rにしました');
                player.playSound('random.toast', { pitch: 0.9, volume: 0.7 });
            }
        }
    });
}

function XrayBlock(player) {
    // アドベンチャーモードのプレイヤーを取得
    const players = world.getAllPlayers();
    const adventurePlayers = Array.from(players).filter(p => p.getGameMode() === 'Adventure');

    if (adventurePlayers.length === 0) {
        player.sendMessage('[§bSecurityCraft§r] §c解除可能なプレイヤーが見つかりません');
        XrayDetectionMenu(player);
        return;
    }

    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body('>>> §e解除するプレイヤーを選択');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§5全員解除', 'textures/ui/bubble_empty');
    for (const target of adventurePlayers) {
        form.button(`§1${target.name}\n§r§4タップで解除`, 'textures/ui/bubble_empty');
    }

    // フォームを表示
    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection == 0) {
            XrayDetectionMenu(player);
            return;
        }
        const selection = response.selection - 1;

        if (selection === 0) {
            for (const targetPlayer of adventurePlayers) {
                resetPlayerXrayData(`${targetPlayer.name}`);
                targetPlayer.runCommand('gamemode default @s');
            }
        } else {
            const selectedPlayer = adventurePlayers[selection - 1];
            resetPlayerXrayData(`${selectedPlayer.name}`);
            selectedPlayer.runCommand('gamemode default @s');
        }

        player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
    });
}

function showPlayerSelector(player) {
    const allPlayers = world.getAllPlayers();
    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body('>>> §eプレイヤー選択して権限を切り替え');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    for (const targetPlayer of allPlayers) {
        const isMember = targetPlayer.hasTag('SecurityMember');

        if (isMember) {
            form.button(`§0${targetPlayer.name}§r\n§0(§1信頼済み§0)`, 'textures/ui/bubble_empty');
        } else {
            form.button(`§0${targetPlayer.name}§r\n§0(§4未設定§0)`, 'textures/ui/bubble_empty');
        }
    }

    // フォームを表示
    form.show(player).then(response => {
        if (response.canceled) {
            return;
        }

        if (response.selection === 0) {
            UI(player);
            return;
        }
        // 選択されたプレイヤーを取得
        const selectedPlayer = allPlayers[response.selection - 1];

        if (!selectedPlayer) return; // エラー回避

        // 権限のトグル処理（切り替え）
        const isMember = selectedPlayer.hasTag('SecurityMember');

        if (isMember) {
            selectedPlayer.removeTag('SecurityMember');
            player.sendMessage(`§r[§bSecurityCraft§r] §b${selectedPlayer.name}§rを§eMember§rから§c解除しました`);
            player.playSound('random.orb', { pitch: 0.8, volume: 1.0 });
        } else {
            selectedPlayer.addTag('SecurityMember');
            player.sendMessage(`§r[§bSecurityCraft§r] §b${selectedPlayer.name}§rを§eMember§rに§a追加しました`);
            player.playSound('random.toast', { pitch: 1.0, volume: 1.0 });
        }
        system.run(() => {
            showPlayerSelector(player);
        });
    });
}

function XrayDetectionMenu(player) {
    const xrayLevel = world.getDynamicProperty('X_RAYCheck_LEVEL') ?? 0;
    const form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body('>>> §eX-ray検知システム');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    // レベル6の時はテキストを変更
    if (xrayLevel === 6) {
        form.button('§0ブロック§4解除\n§0(現在この機能は無効)', 'textures/ui/bubble_empty');
    } else {
        form.button('§0ブロック§4解除', 'textures/ui/bubble_empty');
    }

    form.button('§0警戒ログ', 'textures/items/book_written');

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            UI(player);
            return;
        }

        if (r.selection === 1) {
            if (xrayLevel === 6) {
                player.sendMessage('[§bSecurityCraft§r] §c現在この機能は無効です');
                player.playSound('random.toast', { pitch: 0.5, volume: 0.7 });
                XrayDetectionMenu(player);
                return;
            }
            XrayBlock(player);
        } else if (r.selection === 2) {
            showAllXrayAlertsUI(player);
        }
    });
}

const offlineDisplayState = new Map();

export function PlayerManagerPlayerSelector(player) {
    const onlinePlayers = world.getAllPlayers();
    const onlinePlayerNames = onlinePlayers.map(p => p.name);

    const showOffline = offlineDisplayState.get(player.name) || false;

    let offlineNames = [];
    if (showOffline) {
        try {
            const rawData = world.getDynamicProperty('SC_KnownPlayers');
            if (rawData) {
                const parsed = JSON.parse(rawData);
                if (Array.isArray(parsed)) {
                    offlineNames = parsed.filter(name => !onlinePlayerNames.includes(name));
                }
            }
        } catch (e) {
            offlineNames = [];
        }
    }

    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`>>> §eプレイヤーを選択してください`);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.button(`§0オフライン表示\n§0(${showOffline ? '§1ON' : '§4OFF'}§0)`, 'textures/ui/refresh.png');

    for (let targetPlayer of onlinePlayers) {
        form.button(`§0${targetPlayer.name} §1(オンライン)`, 'textures/ui/bubble_empty');
    }

    if (showOffline) {
        if (offlineNames.length > 0) {
            for (let name of offlineNames) {
                form.button(`§0${name} §4(オフライン)`, 'textures/ui/bubble_empty');
            }
        } else {
            form.button(`§7(オフラインの記録はありません)`, 'textures/ui/cancel.png');
        }
    }

    form.show(player).then(r => {
        if (r.canceled) return;
        if (r.selection === 0) {
            import('./ui.js').then(({ UI }) => UI(player));
            return;
        }
        if (r.selection === 1) {
            offlineDisplayState.set(player.name, !showOffline);
            PlayerManagerPlayerSelector(player);
            return;
        }

        let response = r.selection - 2;

        if (response < onlinePlayers.length) {
            const selectedPlayer = onlinePlayers[response];
            PlayerManager(player, selectedPlayer, false);
        } else {
            if (offlineNames.length === 0) {
                PlayerManagerPlayerSelector(player);
                return;
            }
            const offlineName = offlineNames[response - onlinePlayers.length];
            PlayerManager(player, { name: offlineName }, true);
        }
    });
}

const GetinputModeText = {
    KeyboardAndMouse: 'キーボード&マウス',
    Gamepad: 'コントローラー',
    Touch: 'タッチ',
    MotionController: 'VRコントローラー',
};

export function PlayerManager(player, target, isOffline = false) {
    //時刻を取得
    const now = new Date();
    const japanTime = new Date(now.getTime() + world.getDynamicProperty('Time_Setting') * 60 * 60 * 1000);
    const year = japanTime.getUTCFullYear();
    const month = String(japanTime.getUTCMonth() + 1).padStart(2, '0');
    const date = String(japanTime.getUTCDate()).padStart(2, '0');
    const hours = String(japanTime.getUTCHours()).padStart(2, '0');
    const minutes = String(japanTime.getUTCMinutes()).padStart(2, '0');
    var time = `§l§b${hours}:${minutes} §r[ §d${year}/${month}/${date}§r ]`;

    var form = new ActionFormData();
    form.title(`§4${target.name}§0の管理`);
    form.body(`${time}`);
    form.divider();

    if (isOffline) {
        form.label(`名前:§a${target.name}§r\nID:§7不明§r\nゲームモード:§7不明§r\nプラットフォーム:§7不明§r\n操作方法:§7不明`);
    } else {
        form.label(`名前:§a${target.name}§r\nID:§e${target.id}§r\nゲームモード:§b${target.getGameMode()}§r\nプラットフォーム:§c${target.clientSystemInfo.platformType}§r\n操作方法:§6${GetinputModeText[target.inputInfo.lastInputModeUsed]}`);
    }
    form.divider();

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.button(isOffline ? '§8視点を監視 (不可)' : '§4視点を監視', 'textures/ui/bubble_empty');
    form.button(isOffline ? '§8インベントリー確認 (不可)' : '§5インベントリー確認', 'textures/ui/bubble_empty');

    form.button('§1設置記録確認', 'textures/ui/bubble_empty');
    form.button('§4破壊記録確認', 'textures/ui/bubble_empty');
    form.button('§0アクセス記録確認', 'textures/ui/bubble_empty');
    form.button('§1エンティティキル記録確認', 'textures/ui/bubble_empty');
    form.button('§0座標ログ確認', 'textures/ui/bubble_empty');

    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                PlayerManagerPlayerSelector(player);
                break;
            case 1:
                if (isOffline) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §cオフラインのプレイヤーは監視できません`);
                    player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                    return PlayerManager(player, target, isOffline);
                }
                if (player.id == target.id) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §c自分を視点監視できません`);
                    player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                    return PlayerManager(player, target, isOffline);
                }
                startMonitoring(player, target);
                break;
            case 2:
                if (isOffline) {
                    player.sendMessage(`§r[§bSecurityCraft§r] §cオフラインのプレイヤーのインベントリは確認できません`);
                    player.playSound('random.toast', { pitch: 0.4, volume: 1.0 });
                    return PlayerManager(player, target, isOffline);
                }
                showInventoryContents(player, target);
                break;
            case 3:
                searchPlayerBlockLogs(player, target.name, 'place', () => PlayerManager(player, target, isOffline));
                break;
            case 4:
                searchPlayerBlockLogs(player, target.name, 'break', () => PlayerManager(player, target, isOffline));
                break;
            case 5:
                showPlayerAccessLogs(player, target.name, () => PlayerManager(player, target, isOffline));
                break;
            case 6:
                showPlayerEntityLogs(player, target.name, () => PlayerManager(player, target, isOffline));
                break;
            case 7:
                showPlayerLocationLogs(player, target.name, () => PlayerManager(player, target, isOffline));
                break;
        }
    });
}

function Performance(player) {
    // --- データ容量計算ロジック ---
    let totalStorageSize = '計算中...';
    try {
        let totalBytes = 0;
        const keys = world.getDynamicPropertyIds();

        for (const key of keys) {
            // キー自体の長さ
            totalBytes += key.length;

            const value = world.getDynamicProperty(key);
            if (typeof value === 'string') {
                // 文字列の長さ (JSONデータが大半なのでこれで概算)
                totalBytes += value.length;
            } else if (typeof value === 'number') {
                totalBytes += 8; // 数値は約8バイト
            } else if (typeof value === 'boolean') {
                totalBytes += 4; // 真偽値は約4バイト
            }
        }

        // 表示単位の調整
        if (totalBytes < 1024) {
            totalStorageSize = `${totalBytes} B`;
        } else if (totalBytes < 1024 * 1024) {
            totalStorageSize = `${(totalBytes / 1024).toFixed(2)} KB`;
        } else {
            totalStorageSize = `${(totalBytes / (1024 * 1024)).toFixed(2)} MB`;
        }
    } catch (e) {
        totalStorageSize = 'エラー';
    }

    const players = world.getPlayers();

    var form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');
    form.body(`>>> §eパフォーマンス`);
    form.divider();
    form.label(`§r・§aプレイヤー人数§r: §r§b${players.length}\n§r・§eTPS§r:§b${currentTPS}\n§r・§cデータ容量(約)§r:§b${totalStorageSize}`);
    form.divider();
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.button('§0パフォーマンス診断開始 (約20秒)', 'textures/ui/bubble_empty');
    form.button('§1エンティティ情報', 'textures/ui/bubble_empty');
    form.show(player).then(r => {
        if (r.canceled) return;
        let response = r.selection;
        switch (response) {
            case 0:
                //戻る
                UI(player);
                break;
            case 1:
                //パフォーマンス診断開始
                startPerformanceDiagnosis(player);
                break;
            case 2:
                //エンティティ情報表示
                showEntityCountUI(player);
                break;
        }
    });
}

function showEntityCountUI(player) {
    const form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');

    let bodyText = '各ディメンションのエンティティ数\n\n';
    const dimensionIds = ['overworld', 'nether', 'the_end'];

    for (const dimId of dimensionIds) {
        bodyText += `${getDimensionName(dimId)}§r\n--------------------\n`;

        try {
            const dimension = world.getDimension(dimId);
            const entities = dimension.getEntities();
            if (entities.length === 0) {
                bodyText += '§7エンティティはいません\n\n';
                continue;
            }
            const entityCounts = new Map();
            for (const entity of entities) {
                const count = entityCounts.get(entity.typeId) || 0;
                entityCounts.set(entity.typeId, count + 1);
            }

            const sortedCounts = new Map([...entityCounts.entries()].sort());
            for (const [typeId, count] of sortedCounts) {
                const cleanTypeId = typeId.replace('minecraft:', '');
                bodyText += `§r- §e${cleanTypeId}§r: §b${count}\n`;
            }
        } catch (error) {
            bodyText += '§c読み込み失敗\n';
        }

        bodyText += '\n';
    }

    form.body(bodyText);
    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    form.show(player).then(response => {
        if (response.selection === 0) {
            Performance(player);
        }
    });
}

function getDimensionName(dimId) {
    switch (dimId) {
        case 'overworld':
            return '§2オーバーワールド§r';
        case 'nether':
            return '§4ネザー§r';
        case 'the_end':
            return '§5エンド§r';
        default:
            return dimId;
    }
}

function Systeminformation(player) {
    const form = new ActionFormData();

    form.title('§0SecurityCraft-§1Core');
    form.body(`>>> §eシステム情報`);

    const logSystem = world.getDynamicProperty('Log_system');
    const placeBlockSystem = world.getDynamicProperty('PlaceBlock_system');
    const breakBlockSystem = world.getDynamicProperty('BreakBlock_system');
    const chestLogSystem = world.getDynamicProperty('ChestLog_system');
    const entityLogSystem = world.getDynamicProperty('EntityLog_system');
    const BlockRestoreSystem = world.getDynamicProperty('BlockRestore_system');
    const itemUseOnSystem = world.getDynamicProperty('itemUseOn_system');
    const chatLevel = world.getDynamicProperty('CHAT_LEVEL');
    const xrayLevel = world.getDynamicProperty('X_RAYCheck_LEVEL');

    const getStatusText = status => {
        if (status === true || status === 'ON') {
            return `§a有効`; // 緑色
        }
        return `§c無効`; // 赤色
    };

    const getLevelText = level => {
        if (typeof level === 'number' && level > 0) {
            return `§eLevel ${level}`; // 黄色
        }
        return `§c無効`; // 灰色
    };

    const securityInfo = [
        `§7・座標ログ: ${getStatusText(logSystem)}`,
        `§7・設置記録: ${getStatusText(placeBlockSystem)}`,
        `§7・破壊記録: ${getStatusText(breakBlockSystem)}`,
        `§7・アクセス記録: ${getStatusText(chestLogSystem)}`,
        `§7・エンティティキル記録: ${getStatusText(entityLogSystem)}`,
        `§7・復元システム: ${getStatusText(BlockRestoreSystem)}`,
        `§7・禁止アイテム設置検知: ${getStatusText(itemUseOnSystem)}`,
        `§7・不正チャット検知: ${getLevelText(chatLevel)}`,
        `§7・X-ray検知: ${getLevelText(xrayLevel)}`,
    ].join('\n');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.divider();
    form.label(securityInfo);
    form.divider();
    form.label(`§7・アドオン名§r:§bSecurityCraft-Core\n§7・Version§r:§d3.12.6\n§7・リリース日§r:§e2026/08/04`);
    form.divider();

    // --- フォームを表示 ---
    form.show(player).then(response => {
        if (response.canceled) return;

        if (response.selection === 0) {
            UI(player);
        }
    });
}

// 全プレイヤー（オフライン含む）の警戒ログを一括で確認するUI
function showAllXrayAlertsUI(player) {
    const knownPlayersStr = world.getDynamicProperty('SC_KnownPlayers') || '[]';
    const knownPlayers = JSON.parse(knownPlayersStr);

    const form = new ActionFormData();
    form.title('§0SecurityCraft-§1Core');

    let bodyText = '';
    let hasAnyLog = false;

    // 全員分の動的プロパティをスキャンしてログを結合
    for (const name of knownPlayers) {
        const alerts = getPlayerXrayAlerts(name);
        if (alerts && alerts.length > 0) {
            hasAnyLog = true;
            bodyText += `§d${name} §r(検知数: §d${alerts.length}§r 回)\n`;
            bodyText += `--------------------------------\n`;
            const reversedAlerts = [...alerts].reverse(); // 最新の検知を上に

            reversedAlerts.forEach((alert, index) => {
                bodyText += `§c[#${reversedAlerts.length - index}] §8${alert.time}\n`;
                bodyText += `§r・§b採掘鉱石§r: `;
                const oreList = [];
                for (const [ore, count] of Object.entries(alert.ores)) {
                    oreList.push(`§a${ore}§r:§b${count}個`);
                }
                bodyText += (oreList.join(', ') || 'なし') + '\n';
                bodyText += `§r・§c不審な検知理由§r:\n`;
                for (const [reason, count] of Object.entries(alert.reasons)) {
                    bodyText += `  §r- §e${reason}§r: §b${count}回\n`;
                }
                bodyText += `\n`;
            });
            bodyText += `\n`;
        }
    }

    if (!hasAnyLog) {
        bodyText += '§7データなし';
    }
    form.body('>>> §eX-ray警戒ログ一覧');
    form.button(`§l戻る`, 'textures/ui/icon_import.png');
    form.label(bodyText);

    if (hasAnyLog) {
        form.button(`§4すべてのログを一括削除`, 'textures/ui/bubble_empty');
    }

    form.show(player).then(r => {
        if (r.canceled || r.selection === 0) {
            XrayDetectionMenu(player);
            return;
        }
        if (r.selection === 1) {
            // 全全員の警戒ログ動的プロパティを削除
            for (const name of knownPlayers) {
                clearPlayerXrayAlerts(name);
            }
            player.sendMessage('[§bSecurityCraft§r] §aすべての警戒ログを一括クリアしました');
            player.playSound('random.toast', { pitch: 1.5, volume: 1.0 });
            UI(player);
        }
    });
}
