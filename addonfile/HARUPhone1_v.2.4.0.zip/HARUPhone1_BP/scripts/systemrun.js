import { world } from "@minecraft/server";
export function systemrun(){
    if(world.getDynamicProperty('money_start_system1')===1){
        if(world.getDynamicProperty('money_start_system2')==0||world.getDynamicProperty('money_start_system2')==undefined){
        const players = world.getAllPlayers()
        for (const player2 of players) {
            player2.runCommand("give @s[tag=!HARUPAY_Member] additem:haruphone1");
            player2.runCommand(`scoreboard players set @s[tag=!HARUPAY_Member] money ${world.getDynamicProperty('start_money')}`);
            player2.runCommand("tag @s[tag=!HARUPAY_Member] add HARUPAY_Member")
        }
    }
    }
}