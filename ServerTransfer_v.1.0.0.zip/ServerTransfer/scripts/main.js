import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { transferPlayer } from '@minecraft/server-admin';

import { config } from './config.js';

system.afterEvents.scriptEventReceive.subscribe(eventData => {
    if (eventData.id === 'servertransfer:ui') {
        const args = eventData.message.trim().split(/\s+/);
        const inputselector = args[0];
        if (!inputselector) {
            console.warn(`[ServerTransfer] エラー: /scriptevent servertransfer:ui <selector|playerName> の形式で指定してください。入力: ${eventData.message}`);
            return;
        }

        const targetPlayers = parseSelector(args[0]);
        system.run(async () => {
            targetPlayers.forEach(player => {
                try {
                    const form = new ActionFormData().title('§0サーバー移動').body('>>>§e選択してください');
                    for (const server of config) {
                        form.button(`§1${server.name}`, 'textures/ui/bubble_empty');
                    }
                    form.show(player).then(r => {
                        if (r.canceled) {
                            return;
                        }
                        const selection = r.selection;
                        const selectedServer = config[selection];
                        transferPlayer(player, { hostname: selectedServer.ip, port: selectedServer.port });
                    });
                } catch (error) {
                    console.error('サーバー転送フォームの処理中にエラーが発生しました:', error);
                }
            });
        });
    }
});

//セレクター
function parseSelector(selector) {
    if (!selector) return [];

    // 単一プレイヤー名の場合はそのまま検索
    if (!selector.startsWith('@')) {
        const player = world.getPlayers({ name: selector })[0];
        return player ? [player] : [];
    }

    // セレクターの解析（例: @a[x=0,y=0,z=0,r=2]）
    const match = selector.match(/^@([aep])(?:\[(.+)\])?$/);
    if (!match) {
        console.log(`[ServerTransfer] エラー: 無効なセレクター: ${selector}`);
        return [];
    }

    const [, type, args] = match;
    const params = {};

    // 引数をパース（例: x=0,y=0,z=0,r=2）
    if (args) {
        const argList = args.split(',').map(arg => arg.trim());
        argList.forEach(arg => {
            const [key, value] = arg.split('=').map(s => s.trim());
            if (key && value) {
                params[key] = value;
            }
        });
    }

    // セレクタータイプに応じてプレイヤーを取得
    let players = [];
    if (type === 'a') {
        // @a: 全プレイヤー（座標や範囲でフィルタ）
        players = world.getPlayers({
            location: params.x && params.y && params.z ? { x: parseFloat(params.x), y: parseFloat(params.y), z: parseFloat(params.z) } : undefined,
            maxDistance: params.r ? parseFloat(params.r) : undefined,
        });
    } else if (type === 'p') {
        // @p: 最も近いプレイヤー（座標基準）
        if (params.x && params.y && params.z) {
            const location = { x: parseFloat(params.x), y: parseFloat(params.y), z: parseFloat(params.z) };
            const closestPlayer = world.getPlayers({
                location,
                maxDistance: params.r ? parseFloat(params.r) : undefined,
                closest: 1,
            })[0];
            players = closestPlayer ? [closestPlayer] : [];
        } else {
            // 座標指定なしなら実行者に近いプレイヤー（コマンドブロックでは機能しないので空）
            players = [];
        }
    } else {
        console.log(`[ServerTransfer] エラー: 非対応セレクター: ${selector}`);
        return [];
    }

    return players;
}
