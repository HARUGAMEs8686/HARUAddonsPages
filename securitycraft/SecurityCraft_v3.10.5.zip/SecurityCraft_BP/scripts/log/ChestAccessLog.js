import { world, system, ItemStack } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData, uiManager } from '@minecraft/server-ui';
import { chestCheckModePlayers } from '../main';

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
let DAYS_TO_KEEP = 7;
let pendingUpdates = new Map();

// プレイヤーごとの現在開いているチェストセッションを管理
const activeSessions = new Map();

const chestViewers = new Map();

// UIのクールダウン管理
const lastUITick = new Map();
const uiCooldownTicks = 10;

// ---------------------------------------------------
// 設定ロード関連
// ---------------------------------------------------

export function creload() {
    try {
        const storedDays = world.getDynamicProperty('chestlog_delete_speed');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[SecurityCraft] ロードエラー: ${e}`);
    }
}

world.afterEvents.worldLoad.subscribe(() => {
    creload();
});
creload();

// ---------------------------------------------------
// データ保存・取得関連
// ---------------------------------------------------

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `chest_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

function saveChunkData(chunkKey, chunkData) {
    try {
        const dataString = JSON.stringify([...chunkData]);
        if (dataString.length > 0) {
            world.setDynamicProperty(chunkKey, dataString);
        } else {
            world.setDynamicProperty(chunkKey, undefined);
        }
        pendingUpdates.delete(chunkKey);
    } catch (e) {
        console.warn(`[SecurityCraft] 保存エラー: ${e}`);
    }
}

function getChunkData(chunkKey) {
    try {
        const storedData = world.getDynamicProperty(chunkKey);
        const parsedData = storedData ? JSON.parse(storedData) : [];
        return new Map(parsedData);
    } catch (e) {
        return new Map();
    }
}

function cleanOldData() {
    try {
        const currentTime = Date.now();
        const expirationDay = Math.floor(currentTime / MILLISECONDS_PER_DAY) - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                const match = key.match(/chest_(-?\d+)_(-?\d+)_(\d+)/);
                if (match && parseInt(match[3]) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] クリーンアップエラー: ${e}`);
    }
}

system.runInterval(() => {
    if (pendingUpdates.size > 0) {
        const updatesToProcess = new Map(pendingUpdates);
        for (const [chunkKey, chunkData] of updatesToProcess) {
            saveChunkData(chunkKey, chunkData);
        }
    }
    cleanOldData();
}, 20 * 10);

// ---------------------------------------------------
// チェスト操作ログロジック
// ---------------------------------------------------

export function addChestLog(block, player, changes = [], isConcurrent = false) {
    if (world.getDynamicProperty('ChestLog_system') !== true) return;

    const blockLocation = block.location;
    const chunkKey = getChunkKey(blockLocation.x, blockLocation.z);
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);

    let chunkData = pendingUpdates.has(chunkKey) ? pendingUpdates.get(chunkKey) : getChunkData(chunkKey);

    const logEntry = {
        n: player.name,
        t: Date.now(),
        id: block.typeId,
        diff: changes,
        warn: isConcurrent, 
    };

    let logsForPosition = chunkData.has(positionKey) ? chunkData.get(positionKey) : [];
    logsForPosition.push(logEntry);

    if (logsForPosition.length > 20) {
        logsForPosition = logsForPosition.slice(-20);
    }

    chunkData.set(positionKey, logsForPosition);
    pendingUpdates.set(chunkKey, chunkData);
}

export function getChestLog(blockLocation) {
    let allLogs = [];
    const positionKey = getPositionKey(blockLocation.x, blockLocation.y, blockLocation.z);
    const currentTime = Date.now();

    for (let i = 0; i < DAYS_TO_KEEP; i++) {
        const pastTimestamp = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(blockLocation.x, blockLocation.z, pastTimestamp);
        let chunkData;
        if (pendingUpdates.has(chunkKey)) {
            chunkData = pendingUpdates.get(chunkKey);
        } else {
            chunkData = getChunkData(chunkKey);
        }

        if (chunkData.has(positionKey)) {
            allLogs.push(...chunkData.get(positionKey));
        }
    }

    allLogs.sort((a, b) => b.t - a.t);

    if (allLogs.length > 20) {
        allLogs = allLogs.slice(0, 20);
    }

    return allLogs;
}

export function clearAllChestData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('chest_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
    } catch (e) {
        console.warn(`[SecurityCraft] 全削除エラー: ${e}`);
    }
}

// ---------------------------------------------------
// インベントリ監視ロジック
// ---------------------------------------------------

function getContainerContents(container) {
    const contents = new Map();
    if (!container) return contents;
    for (let i = 0; i < container.size; i++) {
        const item = container.getItem(i);
        if (item) {
            const currentCount = contents.get(item.typeId) || 0;
            contents.set(item.typeId, currentCount + item.amount);
        }
    }
    return contents;
}

function compareContents(before, after) {
    const changes = [];
    const allKeys = new Set([...before.keys(), ...after.keys()]);
    for (const typeId of allKeys) {
        const countBefore = before.get(typeId) || 0;
        const countAfter = after.get(typeId) || 0;
        const diff = countAfter - countBefore;
        if (diff !== 0) {
            const shortName = typeId.replace('minecraft:', '');
            const sign = diff > 0 ? '+' : '-';
            const color = diff > 0 ? '§a' : '§c'; // 緑:追加, 赤:取出
            changes.push(`${color}${sign} ${shortName} x${Math.abs(diff)}§r`);
        }
    }
    return changes;
}

function addViewer(positionKey, playerName) {
    if (!chestViewers.has(positionKey)) {
        chestViewers.set(positionKey, new Set());
    }
    const viewers = chestViewers.get(positionKey);
    viewers.add(playerName);

    if (viewers.size > 1) {
        for (const pName of viewers) {
            if (activeSessions.has(pName)) {
                const s = activeSessions.get(pName);
                s.isConcurrent = true;
                activeSessions.set(pName, s);
            }
        }
    }
}

function removeViewer(positionKey, playerName) {
    if (chestViewers.has(positionKey)) {
        const viewers = chestViewers.get(positionKey);
        viewers.delete(playerName);
        if (viewers.size === 0) {
            chestViewers.delete(positionKey);
        }
    }
}

function processCloseSession(player, session) {
    try {
        const { blockLocation, dimensionId, initialContents, positionKey, isConcurrent } = session;

        // 閲覧者リストから削除
        removeViewer(positionKey, player.name);

        const dimension = world.getDimension(dimensionId);

        let finalContents = new Map();
        try {
            const block = dimension.getBlock(blockLocation);
            // ブロックが存在し、インベントリがある場合のみ中身を取得
            if (block) {
                const container = block.getComponent('inventory')?.container;
                if (container) {
                    finalContents = getContainerContents(container);
                }
            }

            // 差分計算とログ保存
            const changes = compareContents(initialContents, finalContents);
            if (block) {
                addChestLog(block, player, changes, isConcurrent);
            }
        } catch (e) {
        }
    } catch (e) {
        console.warn(`Error processing session close: ${e}`);
    }
}

// ---------------------------------------------------
// イベントハンドラ
// ---------------------------------------------------

world.beforeEvents.playerInteractWithBlock.subscribe(event => {
    const player = event.player;
    const block = event.block;
    const blockType = block.typeId;
    const loggableBlocks = ['minecraft:chest', 'minecraft:barrel', 'minecraft:trapped_chest'];

    if (activeSessions.has(player.name)) {
        const session = activeSessions.get(player.name);
        activeSessions.delete(player.name); // 二重処理防止
        system.run(() => {
            processCloseSession(player, session);
        });
    }

    const currentTick = system.currentTick;
    const lastTick = lastUITick.get(player.name);
    if (lastTick !== undefined && currentTick - lastTick < uiCooldownTicks) {
        return;
    }
    lastUITick.set(player.name, currentTick);

    // --- 対象ブロックへのアクセス処理 ---
    if (loggableBlocks.includes(blockType)) {
        if (chestCheckModePlayers.has(player.name)) {
            event.cancel = true;

            system.runTimeout(() => {
                uiManager.closeAllForms(player);
                const logs = getChestLog(block.location);
                const form = new ActionFormData().title('§0アクセス履歴');

                if (logs.length > 0) {
                    let body = `§a座標§r: §b${Math.floor(block.location.x)}, ${Math.floor(block.location.y)}, ${Math.floor(block.location.z)}\n§r`;
                    logs.forEach(log => {
                        const japanTime = new Date(log.t + (world.getDynamicProperty('Time_Setting') || 0) * 60 * 60 * 1000);
                        const timeString = `${String(japanTime.getUTCMonth() + 1).padStart(2, '0')}/${String(japanTime.getUTCDate()).padStart(2, '0')} ${String(japanTime.getUTCHours()).padStart(2, '0')}:${String(japanTime.getUTCMinutes()).padStart(2, '0')}:${String(japanTime.getUTCSeconds()).padStart(2, '0')}`;

                        body += `\n§e${log.n} §7(${timeString})§r`;

                        // 同時アクセスの警告
                        if (log.warn) {
                            body += ` §cデータ不適切 (同時アクセス)§r`;
                        }

                        if (log.diff && log.diff.length > 0) {
                            body += `\n  ${log.diff.join(' ')}`;
                        } else {
                            body += `\n  §7(操作なし)`;
                        }
                        body += `\n§8----------------§r`;
                    });
                    form.body(body);
                } else {
                    form.body(`§cアクセス履歴がありません`);
                }

                form.button('§l閉じる');
                form.show(player);
            }, 4);
            return;
        }

        if (world.getDynamicProperty('ChestLog_system') === true) {
            system.run(() => {
                const currentBlock = block.dimension.getBlock(block.location);
                const container = currentBlock?.getComponent('inventory')?.container;

                if (container) {
                    const positionKey = getPositionKey(block.location.x, block.location.y, block.location.z);
                    const initialContents = getContainerContents(container);
                    addViewer(positionKey, player.name);
                    const isConcurrent = chestViewers.get(positionKey)?.size > 1;

                    activeSessions.set(player.name, {
                        blockLocation: { x: block.location.x, y: block.location.y, z: block.location.z },
                        dimensionId: block.dimension.id,
                        initialContents: initialContents,
                        timestamp: Date.now(),
                        positionKey: positionKey,
                        isConcurrent: isConcurrent,
                    });
                }
            });
        }
    }
});

// ---------------------------------------------------
// 監視ループ (距離判定による閉じる処理)
// ---------------------------------------------------

system.runInterval(() => {
    if (activeSessions.size === 0) return;

    for (const [playerName, session] of activeSessions) {
        const player = world.getAllPlayers().find(p => p.name === playerName);

        if (!player) {
            activeSessions.delete(playerName);
            removeViewer(session.positionKey, playerName);
            continue;
        }

        // 距離判定 (6ブロック以上離れたら閉じたとみなす)
        const pLoc = player.location;
        const bLoc = session.blockLocation;
        let distanceSquared = 999;

        if (player.dimension.id === session.dimensionId) {
            distanceSquared = (pLoc.x - bLoc.x) ** 2 + (pLoc.y - bLoc.y) ** 2 + (pLoc.z - bLoc.z) ** 2;
        }

        if (distanceSquared > 36) {
            activeSessions.delete(playerName);
            processCloseSession(player, session);
        }
    }
}, 5);
