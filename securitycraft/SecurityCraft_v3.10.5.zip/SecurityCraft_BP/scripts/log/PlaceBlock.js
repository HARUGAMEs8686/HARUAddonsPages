import { world, system } from '@minecraft/server';
import { checkModePlayers } from '../main'; 

const CHUNK_SIZE = 16;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;
const MAX_PROPERTY_SIZE = 30000; 
const SCRIPT_DATA_VERSION = 2; 

let DAYS_TO_KEEP = 4;
let pendingUpdates = new Map();

function checkDataVersionAndInitialize() {
    try {
        const storedVersion = world.getDynamicProperty('placeblock_data_version');

        if (storedVersion !== SCRIPT_DATA_VERSION) {
            console.warn(`[PlaceBlock] 旧バージョン(${storedVersion})のデータを検出しました。新バージョン(${SCRIPT_DATA_VERSION})への更新のため、全設置記録を初期化します。`);

            clearAllPlaceData(); 

            world.setDynamicProperty('placeblock_data_version', SCRIPT_DATA_VERSION);
            console.log(`[PlaceBlock] データバージョンを ${SCRIPT_DATA_VERSION} に更新しました。`);
        }
    } catch (e) {
        console.error(`[PlaceBlock] データバージョンの確認・更新中にエラーが発生しました: ${e}`);
    }
}

/**
 * ワールドに保存された設定値を読み込み
 */
export function preload() {
    try {
        const storedDays = world.getDynamicProperty('placeblock_delete_days');
        if (typeof storedDays === 'number' && !isNaN(storedDays) && storedDays > 0) {
            DAYS_TO_KEEP = storedDays;
        }
    } catch (e) {
        console.warn(`[PlaceBlock] Failed to load 'placeblock_delete_days': ${e}`);
    }
}

// ワールド読み込み完了時のイベント
world.afterEvents.worldLoad.subscribe(() => {
    checkDataVersionAndInitialize(); 
    preload(); // 次に設定をリロード
});

// スクリプトの初回読み込み時にも実行
checkDataVersionAndInitialize();
preload();

// --- キー生成 ---

function getChunkKey(x, z, timestamp = Date.now()) {
    const chunkX = Math.floor(x / CHUNK_SIZE);
    const chunkZ = Math.floor(z / CHUNK_SIZE);
    const day = Math.floor(timestamp / MILLISECONDS_PER_DAY);
    return `place_${chunkX}_${chunkZ}_${day}`;
}

function getPositionKey(x, y, z) {
    return `${x},${y},${z}`;
}

// --- データ永続化 (軽量化版) ---

function saveChunkData(chunkKey, chunkData) {
    const entries = Object.entries(chunkData);

    if (entries.length === 0) {
        let part = 1;
        while (world.getDynamicProperty(`${chunkKey}_part${part}`)) {
            world.setDynamicProperty(`${chunkKey}_part${part}`, undefined);
            part++;
        }
        pendingUpdates.delete(chunkKey);
        return;
    }

    const newParts = [];
    let currentPartObject = {};

    for (const [positionKey, data] of entries) {
        const tempObject = { ...currentPartObject, [positionKey]: data };
        if (JSON.stringify(tempObject).length > MAX_PROPERTY_SIZE) {
            if (Object.keys(currentPartObject).length > 0) {
                newParts.push(JSON.stringify(currentPartObject));
            }
            currentPartObject = { [positionKey]: data };
        } else {
            currentPartObject = tempObject;
        }
    }

    if (Object.keys(currentPartObject).length > 0) {
        newParts.push(JSON.stringify(currentPartObject));
    }

    try {
        for (let i = 0; i < newParts.length; i++) {
            world.setDynamicProperty(`${chunkKey}_part${i + 1}`, newParts[i]);
        }
        let oldPart = newParts.length + 1;
        while (world.getDynamicProperty(`${chunkKey}_part${oldPart}`)) {
            world.setDynamicProperty(`${chunkKey}_part${oldPart}`, undefined);
            oldPart++;
        }
    } catch (e) {
        console.warn(`[PlaceBlock] Error saving chunk data for ${chunkKey}: ${e}`);
    } finally {
        pendingUpdates.delete(chunkKey);
    }
}

function getChunkData(chunkKey) {
    const combinedData = {};
    let part = 1;
    while (true) {
        const storedData = world.getDynamicProperty(`${chunkKey}_part${part}`);
        if (!storedData) break;
        try {
            Object.assign(combinedData, JSON.parse(storedData));
        } catch (e) {
            console.warn(`[PlaceBlock] Failed to parse data for ${chunkKey}_part${part}: ${e}`);
        }
        part++;
    }
    return combinedData;
}

function getChunkDataForBlock(x, z) {
    const mergedData = new Map();
    const currentTime = Date.now();
    for (let i = 0; i <= DAYS_TO_KEEP; i++) {
        const pastTime = currentTime - i * MILLISECONDS_PER_DAY;
        const chunkKey = getChunkKey(x, z, pastTime);

        const data = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);

        for (const [pos, value] of Object.entries(data)) {
            // value[1] はタイムスタンプ
            if (!mergedData.has(pos) || value[1] > (mergedData.get(pos)?.[1] || 0)) {
                mergedData.set(pos, value);
            }
        }
    }
    return mergedData;
}

// --- 定期実行タスク ---

system.runInterval(() => {
    const updatesToProcess = new Map(pendingUpdates);
    for (const [chunkKey, chunkData] of updatesToProcess) {
        saveChunkData(chunkKey, chunkData);
    }
}, 400); // 20秒ごと

system.runInterval(() => {
    try {
        const currentDay = Math.floor(Date.now() / MILLISECONDS_PER_DAY);
        const expirationDay = currentDay - DAYS_TO_KEEP;
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('place_')) {
                const match = key.match(/place_-?\d+_-?\d+_(\d+)_part\d+/);
                if (match && parseInt(match[1], 10) < expirationDay) {
                    world.setDynamicProperty(key, undefined);
                }
            }
        }
    } catch (e) {
        console.warn(`[PlaceBlock] Error cleaning old data: ${e.message}`);
    }
}, 1200); // 60秒ごと

export function clearAllPlaceData() {
    try {
        const allKeys = world.getDynamicPropertyIds();
        for (const key of allKeys) {
            if (key.startsWith('place_')) {
                world.setDynamicProperty(key, undefined);
            }
        }
        pendingUpdates.clear();
        console.log('[PlaceBlock] すべての設置者情報をクリアしました。');
    } catch (e) {
        console.warn(`[PlaceBlock] Error clearing place data: ${e.message}`);
    }
}

// --- メイン処理 ---

export function PlaceBlock() {
    const lastCheckTime = new Map();

    world.afterEvents.playerPlaceBlock.subscribe(event => {
        if (!world.getDynamicProperty('PlaceBlock_system')) return;

        const { player, block } = event;
        const { x, y, z } = block.location;
        const now = Date.now();
        const chunkKey = getChunkKey(x, z, now);
        const positionKey = getPositionKey(x, y, z);

        const chunkData = pendingUpdates.get(chunkKey) || getChunkData(chunkKey);
        chunkData[positionKey] = [player.name, now];

        pendingUpdates.set(chunkKey, chunkData);
    });

    world.afterEvents.playerBreakBlock.subscribe(event => {
        const { block } = event;
        const { x, y, z } = block.location;
        const positionKey = getPositionKey(x, y, z);

        const combinedChunkData = getChunkDataForBlock(x, z);
        const blockData = combinedChunkData.get(positionKey);

        if (blockData && blockData[1]) {
            const originalTimestamp = blockData[1];
            const originalChunkKey = getChunkKey(x, z, originalTimestamp);

            let originalChunkData = pendingUpdates.get(originalChunkKey) || getChunkData(originalChunkKey);

            if (originalChunkData[positionKey]) {
                delete originalChunkData[positionKey];
                pendingUpdates.set(originalChunkKey, originalChunkData);
            }
        }
    });

    world.beforeEvents.playerInteractWithBlock.subscribe(event => {
        system.run(() => {
            const { player, block } = event;
            if (!checkModePlayers.has(player.name) || !block) return;

            const now = Date.now();
            if (now - (lastCheckTime.get(player.name) || 0) < 1000) return;
            lastCheckTime.set(player.name, now);

            const { x, y, z } = block.location;
            const positionKey = getPositionKey(x, y, z);
            const chunkData = getChunkDataForBlock(x, z);
            const blockData = chunkData.get(positionKey);

            if (blockData) {
                const placerName = blockData[0]; // [軽量化] 配列の0番目
                const timestamp = blockData[1]; // [軽量化] 配列の1番目
                player.sendMessage(`§r[§bSecurityCraft§r] §5${placerName}§rによって§e設置 §r: §a${block.typeId.replace('minecraft:', '')}§r (§7${toJST(timestamp)}§r)`);
                player.playSound('random.toast', { pitch: 0.9, volume: 1.0 });
            } else {
                player.sendMessage('§r[§bSecurityCraft§r] §cこのブロックの設置者情報はありません');
                player.playSound('random.toast', { pitch: 0.7, volume: 1.0 });
            }
        });
    });
}

/**
 * タイムスタンプをJST（日本標準時）の文字列に変換
 */
function toJST(timestamp) {
    const timeSetting = world.getDynamicProperty('Time_Setting') || 9;
    const date = new Date(timestamp + timeSetting * 60 * 60 * 1000);
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');
    return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
}
