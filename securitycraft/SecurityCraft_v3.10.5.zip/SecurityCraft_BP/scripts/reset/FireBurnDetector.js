// --- FireBurnDetector.js ---
import { world, system } from "@minecraft/server";

export class FireBurnDetector {
    constructor() {
        this.monitoredBlocks = new Map();
        this.recentlyBrokenByPlayer = new Set();
        this.callbacks = [];
        this.scanGenerator = null;
        
        this.checkInterval = null;
        this.scanInterval = null;
        this.playerBreakListener = null;

        this.isRunning = false;
    }

    start() {
        if (this.isRunning) return;
        this.isRunning = true;

        this._listenPlayerBreak();
        this._startLoops();
    }

    stop() {
        if (!this.isRunning) return;
        this.isRunning = false;

        if (this.checkInterval) system.clearRun(this.checkInterval);
        if (this.scanInterval) system.clearRun(this.scanInterval);
        if (this.playerBreakListener) world.afterEvents.playerBreakBlock.unsubscribe(this.playerBreakListener);

        this.monitoredBlocks.clear();
        this.recentlyBrokenByPlayer.clear();
        this.scanGenerator = null;
    }

    onBurn(callback) {
        this.callbacks.push(callback);
    }

    _listenPlayerBreak() {
        this.playerBreakListener = world.afterEvents.playerBreakBlock.subscribe((ev) => {
            const key = this._getKey(ev.block.location);
            this.recentlyBrokenByPlayer.add(key);
            system.runTimeout(() => this.recentlyBrokenByPlayer.delete(key), 2);
        });
    }

    _startLoops() {
        this.checkInterval = system.runInterval(() => {
            this._checkMonitoredBlocks();
        }, 2);

        this.scanInterval = system.runInterval(() => {
            this._processScanJob();
        }, 1);
    }

    _processScanJob() {
        if (!this.scanGenerator) {
            this.scanGenerator = this._createGlobalScanIterator();
        }

        const blocksPerTick = 1500;

        for (let i = 0; i < blocksPerTick; i++) {
            const result = this.scanGenerator.next();
            if (result.done) {
                this.scanGenerator = null;
                return;
            }
        }
    }

    * _createGlobalScanIterator() {
        const players = world.getAllPlayers();
        // 範囲は維持
        const radiusXZ = 24;
        const radiusY = 8;

        for (const player of players) {
            if (!player) continue;
            const dim = player.dimension;
            const loc = player.location;
            const px = Math.floor(loc.x);
            const py = Math.floor(loc.y);
            const pz = Math.floor(loc.z);

            for (let x = -radiusXZ; x <= radiusXZ; x++) {
                for (let z = -radiusXZ; z <= radiusXZ; z++) {
                    for (let y = -radiusY; y <= radiusY; y++) {
                        
                        const targetLoc = { x: px + x, y: py + y, z: pz + z };
                        let block;
                        try { block = dim.getBlock(targetLoc); } catch (e) { continue; }
                        if (!block) continue;

                        // 既に火がある場所を見つけたら周囲を登録
                        if (this._isFire(block.typeId)) {
                            this._registerNeighbors(block.dimension, block.location);
                        }
                        yield; 
                    }
                }
            }
        }
    }

    _checkMonitoredBlocks() {
        if (this.monitoredBlocks.size === 0) return;

        // 削除用リスト
        const toDelete = [];

        for (const [key, data] of this.monitoredBlocks) {
            const { location, dimensionId, oldTypeId, oldPermutation } = data;
            const dimension = world.getDimension(dimensionId);
            if (!dimension) {
                toDelete.push(key);
                continue;
            }

            let currentBlock;
            try { currentBlock = dimension.getBlock(location); } catch (e) {
                toDelete.push(key);
                continue;
            }

            if (!currentBlock) continue;
            
            // ブロックが変わっていない場合はスキップ
            if (currentBlock.typeId === oldTypeId) continue;

            // プレイヤーが壊したものでなければ「燃えた」と判定
            if (!this.recentlyBrokenByPlayer.has(key)) {
                const newId = currentBlock.typeId;
                // 空気になる、または火に変わっている場合
                if (newId === "minecraft:air" || this._isFire(newId)) {
                    
                    this._triggerEvent(currentBlock, oldPermutation);

                    this._registerNeighbors(dimension, location);
                }
            }
            toDelete.push(key);
        }

        for (const key of toDelete) {
            this.monitoredBlocks.delete(key);
        }
    }

    /**
     * 指定座標の周囲を監視リストに加える
     * @param {Dimension} dim 
     * @param {Vector3} center 
     */
    _registerNeighbors(dim, center) {
        const offsets = [
            { x: 0, y: 1, z: 0 }, { x: 0, y: -1, z: 0 },
            { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
            { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 }
        ];
        const range = dim.heightRange || { min: -64, max: 320 };

        for (const offset of offsets) {
            const tLoc = { 
                x: Math.floor(center.x + offset.x), 
                y: Math.floor(center.y + offset.y), 
                z: Math.floor(center.z + offset.z) 
            };
            
            if (tLoc.y < range.min || tLoc.y >= range.max) continue;

            const key = this._getKey(tLoc);
            // 既に監視中ならスキップ
            if (this.monitoredBlocks.has(key)) continue;

            try {
                const target = dim.getBlock(tLoc);
                if (!target) continue;
                const typeId = target.typeId;

                if (typeId === "minecraft:air" || 
                    this._isFire(typeId) || 
                    typeId === "minecraft:bedrock" ||
                    typeId === "minecraft:water" || 
                    typeId === "minecraft:flowing_water" ||
                    typeId === "minecraft:lava" || 
                    typeId === "minecraft:flowing_lava") continue;

                this.monitoredBlocks.set(key, {
                    location: tLoc,
                    dimensionId: dim.id,
                    oldTypeId: typeId,
                    oldPermutation: target.permutation
                });
            } catch (e) {}
        }
    }

    _triggerEvent(block, oldPermutation) {
        this.callbacks.forEach(cb => cb(block, oldPermutation));
    }

    _getKey(loc) {
        return `${loc.x},${loc.y},${loc.z}`;
    }

    _isFire(typeId) {
        return typeId === "minecraft:fire" || typeId === "minecraft:soul_fire";
    }
}