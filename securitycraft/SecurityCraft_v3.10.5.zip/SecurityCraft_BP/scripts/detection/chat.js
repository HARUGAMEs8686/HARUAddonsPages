import { world, system } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui';

export function Chat() {
    const CHAT_LEVEL = world.getDynamicProperty('CHAT_LEVEL');
    const chatLogs = {};
    const CHAT_LEVEL_CONFIGS = {
        1: { MUTE_TIME: 30 * 1000, SPAM_LIMIT: 3, LONG_MESSAGE_LIMIT: 100, SIMILARITY_THRESHOLD: 0.8, FAST_SPAM_LIMIT: 3 },
        2: { MUTE_TIME: 60 * 1000, SPAM_LIMIT: 5, LONG_MESSAGE_LIMIT: 150, SIMILARITY_THRESHOLD: 0.85, FAST_SPAM_LIMIT: 4 },
        3: { MUTE_TIME: 120 * 1000, SPAM_LIMIT: 7, LONG_MESSAGE_LIMIT: 200, SIMILARITY_THRESHOLD: 0.95, FAST_SPAM_LIMIT: 6 },
    };

    // プレイヤーのレベルに基づく設定を取得
    let MUTE_TIME, SPAM_LIMIT, LONG_MESSAGE_LIMIT, SIMILARITY_THRESHOLD, FAST_SPAM_LIMIT;

    // CHAT_LEVEL に応じた設定を取得
    if (CHAT_LEVEL != 0) {
        ({ MUTE_TIME, SPAM_LIMIT, LONG_MESSAGE_LIMIT, SIMILARITY_THRESHOLD, FAST_SPAM_LIMIT } = CHAT_LEVEL_CONFIGS[CHAT_LEVEL]);
    }

    function isSimilarMessage(msg1, msg2) {
        if (!msg1 || !msg2) return false;
        let minLen = Math.min(msg1.length, msg2.length);
        let common = 0;
        for (let i = 0; i < minLen; i++) {
            if (msg1[i] === msg2[i]) common++;
        }
        return common / minLen >= SIMILARITY_THRESHOLD;
    }

    world.beforeEvents.chatSend.subscribe(event => {
        if (world.getDynamicProperty('CHAT_LEVEL') == 0) {
            return;
        }
        const player = event.sender;
        const message = event.message;
        const playerId = player.name;

        // **SecurityOP / SecurityMember は検知しない**
        if (player.hasTag('SecurityOP') || player.hasTag('SecurityMember')) return;

        if (!chatLogs[playerId]) {
            chatLogs[playerId] = { messages: [], warnings: 0, mutedUntil: 0 };
        }

        let playerData = chatLogs[playerId];
        let now = Date.now();

        // **ミュート中ならチャットをブロック**
        if (playerData.mutedUntil > now) {
            event.cancel = true;
            player.sendMessage('§r[§bSecurityCraft§r] §c現在チャットはご利用いただけません');
            return;
        }

        let violation = false;

        // **長文スパムチェック**
        if (message.length > LONG_MESSAGE_LIMIT) {
            playerData.warnings++;
            player.sendMessage(`§r[§bSecurityCraft§r] §cメッセージが長すぎます（${playerData.warnings}/${SPAM_LIMIT}）`);
            event.cancel = true;
            violation = true;
        }

        // **連投・コピペチェック**
        for (let pastMessage of playerData.messages) {
            if (isSimilarMessage(message, pastMessage)) {
                playerData.warnings++;
                player.sendMessage(`§r[§bSecurityCraft§r] §c同じ内容の連続送信は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
                event.cancel = true;
                violation = true;
                break;
            }
        }

        // **URL禁止（宣伝対策）**
        if (message.match(/http:\/\/|https:\/\//)) {
            playerData.warnings++;
            player.sendMessage(`§r[§bSecurityCraft§r] §cURLの送信は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
            event.cancel = true;
            violation = true;
        }

        // **高速連投スパム検知**
        if (now - playerData.lastMessageTime < 1000) {
            playerData.fastSpamCount++;
            if (playerData.fastSpamCount >= FAST_SPAM_LIMIT) {
                playerData.warnings++;
                player.sendMessage(`§r[§bSecurityCraft§r] §c短時間での連投は禁止されています（${playerData.warnings}/${SPAM_LIMIT}）`);
                event.cancel = true;
                violation = true;
            }
        } else {
            playerData.fastSpamCount = 0; // リセット
        }
        playerData.lastMessageTime = now;

        // **過去のメッセージを記録**
        if (!violation) {
            playerData.messages.push(message);
            if (playerData.messages.length > 5) playerData.messages.shift(); // 最新5件だけ保存
        }

        // **警告の処理**
        if (playerData.warnings >= SPAM_LIMIT) {
            player.sendMessage('§r[§bSecurityCraft§r] §cスパム行為が検出されました 一定時間チャットをご利用頂けません');
            playerData.mutedUntil = now + MUTE_TIME;
            playerData.warnings = 0; // リセット
        }
    });
}
