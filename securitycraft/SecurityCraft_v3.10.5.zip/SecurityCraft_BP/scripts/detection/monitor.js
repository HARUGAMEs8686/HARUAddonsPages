import { world, system, GameMode } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { UI } from '../ui.js';

// 監視中の管理者のリスト
const monitoringAdmins = new Map();

export function isMonitoringPlayer(player) {
    return monitoringAdmins.has(player.id);
}

export function stopMonitoringPlayer(player) {
    if (monitoringAdmins.has(player.id)) {
        const state = monitoringAdmins.get(player.id);
        endMonitoring(player, state.runId);
    }
}

// 監視対象プレイヤー選択UIを表示
export function showMonitorSelectUI(player) {
    const players = world.getPlayers();
    const targets = players.filter(p => p.id !== player.id);

    if (targets.length === 0) {
        player.sendMessage('§r[§bSecurityCraft§r] §c監視対象のプレイヤーがいません');
        return;
    }

    const form = new ActionFormData().title('§0SecurityCraft-§1Core').body('>>> §e選択してください');

    form.button(`§l戻る`, 'textures/ui/icon_import.png');

    targets.forEach(target => {
        form.button(`§0${target.name}`, 'textures/ui/permissions_member_star.png');
    });

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            UI(player);
            return;
        }

        const targetPlayer = targets[res.selection - 1];
        startMonitoring(player, targetPlayer);
    });
}

// 監視開始
function startMonitoring(admin, target) {
    if (monitoringAdmins.has(admin.id)) return;

    // 現在の状態（復帰用）を保存
    const originState = {
        location: admin.location,
        dimension: admin.dimension,
        gamemode: admin.getGameMode(),
    };

    // 状態管理用オブジェクト
    const state = {
        runId: undefined,
        origin: originState,
        lastY: undefined, // Y座標の変化検知用
    };
    monitoringAdmins.set(admin.id, state);

    // スペクテイターに変更してターゲットの次元・位置へTP
    try {
        admin.setGameMode(GameMode.Spectator);
        const firstTpLoc = {
            x: target.location.x,
            y: target.location.y + 30,
            z: target.location.z,
        };
        admin.teleport(firstTpLoc, { dimension: target.dimension });

        // TP直後のY座標を基準として保存
        state.lastY = admin.location.y;
    } catch (e) {
        admin.sendMessage('§c監視の開始に失敗しました');
        monitoringAdmins.delete(admin.id);
        return;
    }

    admin.sendMessage(`§r[§bSecurityCraft§r] §a${target.name}の監視を開始しました。`);
    admin.sendMessage(`§e解除するには「ジャンプ(上昇)」か「スニーク(下降)」して動いてください`);

    const runId = system.runInterval(() => {
        try {
            if (!target.isValid || !admin.isValid) throw new Error('Invalid Entity');
        } catch (e) {
            endMonitoring(admin, runId);
            return;
        }

        // 現在のY座標を取得
        const currentY = admin.location.y;

        if (admin.dimension.id !== target.dimension.id) {
            admin.teleport(target.location, { dimension: target.dimension });
            state.lastY = admin.location.y;
            return;
        }

        if (Math.abs(currentY - state.lastY) > 0.1) {
            endMonitoring(admin, runId);
            return;
        }

        state.lastY = currentY;

        // カメラ同期
        syncCamera(admin, target);

        // アクションバー表示
        admin.onScreenDisplay.setActionBar(`§c監視中: §f${target.name} §7(上昇/下降で解除)`);
    }, 1);

    state.runId = runId;
}

function syncCamera(admin, target) {
    const tLoc = target.location;
    const tRot = target.getRotation();

    const dist = 4;

    const radY = tRot.y * (Math.PI / 180); // Yaw (横回転)
    const radX = tRot.x * (Math.PI / 180); // Pitch (縦回転)

    const hDist = dist * Math.cos(radX);

    const camLoc = {
        x: tLoc.x + Math.sin(radY) * hDist,
        y: tLoc.y + 2.5 + Math.sin(radX) * dist,
        z: tLoc.z - Math.cos(radY) * hDist,
    };

    const camRot = { x: tRot.x, y: tRot.y };

    admin.camera.setCamera('minecraft:free', {
        location: camLoc,
        rotation: camRot,
        easeOptions: {
            easeTime: 0.1, // ここの値を大きくすると追従が遅れますが、視点移動解除が反応しやすくなります
            easeType: 'Linear',
        },
    });
}

// 監視終了処理
function endMonitoring(admin, runId) {
    if (runId !== undefined) system.clearRun(runId);

    // 状態を取得
    const state = monitoringAdmins.get(admin.id);

    // カメラ解除
    admin.camera.clear();
    admin.onScreenDisplay.setActionBar('');

    if (state && state.origin) {
        try {
            const { location, dimension, gamemode } = state.origin;

            admin.teleport(location, { dimension: dimension });

            admin.setGameMode(gamemode);
        } catch (e) {
            admin.setGameMode(GameMode.survival);
        }
    }

    system.runTimeout(() => {
        if (admin && admin.isValid) {
            admin.camera.clear();
        }
    }, 5);

    admin.sendMessage('§r[§bSecurityCraft§r] §a監視を終了し、元の場所へ戻りました');

    monitoringAdmins.delete(admin.id);
}
