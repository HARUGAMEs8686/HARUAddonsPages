import { world, system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';

import { currentTPS } from '../main';

// パフォーマンス診断システムの変数
let isDiagnosing = false; // 診断中かどうかのフラグ
const diagnosisDuration = 20; // 診断時間（秒）
const diagnosisInterval = 20; // 計測間隔（tick）= 1秒
let tpsHistory = []; // TPSの履歴を保存する配列
let entityCountHistory = []; // エンティティ数の履歴を保存する配列
let diagnosticPlayer = null; // 診断を実行したプレイヤー

function getTotalEntityCount() {
    let count = 0;
    const dimensionIds = ['overworld', 'the_nether', 'the_end'];

    for (const id of dimensionIds) {
        try {
            const dimension = world.getDimension(id);
            // getEntities() はイテレータを返すため、スプレッド構文で配列に変換して長さを取得
            count += [...dimension.getEntities()].length;
        } catch (e) {}
    }

    return count;
}

export function startPerformanceDiagnosis(player) {
    if (isDiagnosing) {
        player.sendMessage('[§bSecurityCraft§r] §c現在、他のプレイヤーがパフォーマンス診断を実行中です');
        return;
    }

    isDiagnosing = true;
    diagnosticPlayer = player;
    tpsHistory = [];
    entityCountHistory = [];

    player.sendMessage(`[§bSecurityCraft§r] §aパフォーマンス診断を開始します... `);

    // 一定間隔でTPSとエンティティ数を記録し、進捗を表示する
    const intervalId = system.runInterval(() => {
        // TPSとエンティティ数を記録
        tpsHistory.push(currentTPS);
        entityCountHistory.push(getTotalEntityCount());

        // 進捗を計算
        const progress = tpsHistory.length / diagnosisDuration;
        const percentage = Math.floor(progress * 100);
        const maxBarLength = 20;
        const currentBarLength = Math.round(maxBarLength * progress);

        const progressBar = '§a|'.repeat(currentBarLength) + '§7|'.repeat(maxBarLength - currentBarLength);

        diagnosticPlayer.onScreenDisplay.setActionBar(`§b診断中... §r[${progressBar}§r] §e${percentage}%`);

        if (tpsHistory.length >= diagnosisDuration) {
            system.clearRun(intervalId);
            diagnosticPlayer.onScreenDisplay.setActionBar('§a診断完了');
            showDiagnosisResult();
        }
    }, diagnosisInterval);
}

function showDiagnosisResult() {
    if (tpsHistory.length === 0) {
        diagnosticPlayer.sendMessage('[§bSecurityCraft§r] §cTPSデータの収集に失敗しました');
        isDiagnosing = false;
        return;
    }

    const sumTps = tpsHistory.reduce((a, b) => a + b, 0);
    const averageTPS = (sumTps / tpsHistory.length).toFixed(2);
    const minTPS = Math.min(...tpsHistory).toFixed(2);
    const maxTPS = Math.max(...tpsHistory).toFixed(2);

    const maxEntityCount = Math.max(...entityCountHistory);
    const initialEntityCount = entityCountHistory[0];
    const finalEntityCount = entityCountHistory[entityCountHistory.length - 1];
    const entityIncrease = finalEntityCount - initialEntityCount;

    const resultMessage = generateResultMessage(parseFloat(averageTPS), parseFloat(minTPS), { maxEntityCount, entityIncrease });

    const resultForm = new ActionFormData()
        .title('§1パフォーマンス診断結果')
        .body(`【サーバー負荷】§r\n` + `§a平均TPS: ${averageTPS}\n` + `§c最低TPS: ${minTPS}\n` + `§b最高TPS: ${maxTPS}\n\n` + `§l§r【エンティティ情報】§r\n` + `§d最大エンティティ数: ${maxEntityCount}\n` + `§6エンティティ増加数: ${entityIncrease > 0 ? `+${entityIncrease}` : entityIncrease}\n\n` + `§l§r【診断結果】§r\n${resultMessage}`)
        .button('§1閉じる');

    resultForm.show(diagnosticPlayer).then(() => {
        diagnosticPlayer.onScreenDisplay.setActionBar('');
        isDiagnosing = false;
        diagnosticPlayer = null;
    });
}

function generateResultMessage(avgTps, minTps, entityInfo) {
    let baseMessage = '';
    let entityMessage = '';

    if (avgTps >= 19.8 && minTps >= 19.0) {
        baseMessage = '§a【Sランク】理想的な状態です\nサーバーは非常に快適に動作しており、ラグの心配はほとんどありません。';
    } else if (avgTps >= 19.0 && minTps >= 17.0) {
        baseMessage = '§a【Aランク】非常に快適です\nほとんどのプレイヤーはラグを感じることなく、スムーズにプレイできるでしょう。';
    } else if (avgTps >= 19.0 && minTps < 17.0) {
        baseMessage = '§e【B+ランク】ほぼ快適ですが、一時的な低下が見られます\n全体的には非常に安定していますが、ごく稀に瞬間的なラグが発生しているようです。';
    } else if (avgTps >= 17.5 && minTps >= 15.0) {
        baseMessage = '§e【Bランク】快適です\nサーバーは快適に動作していますが、時折軽微なラグが発生する可能性があります。ゲームプレイに大きな支障はないレベルです。';
    } else if (avgTps >= 17.5 && minTps < 15.0) {
        baseMessage = '§6【C+ランク】やや不安定です\n普段は問題ないものの、瞬間的にやや大きなラグが発生することがあります。';
    } else if (avgTps >= 15.0) {
        baseMessage = '§6【Cランク】注意が必要です\nサーバーにややラグが発生しています。特定の状況で動作が重くなることがあり、一部のプレイヤーはストレスを感じるかもしれません。';
    } else if (avgTps >= 10.0) {
        baseMessage = '§c【Dランク】要対応\nサーバーに明らかなラグが発生しており、プレイヤーの体験に影響が出ている可能性が高いです。';
    } else {
        baseMessage = '§4【Fランク】深刻な状態です\nサーバーは非常に不安定で、深刻なラグが発生しています。ゲームプレイに大きな支障が出ています。';
    }

    const { maxEntityCount, entityIncrease } = entityInfo;
    let entityAdvice = [];

    if (maxEntityCount > 1000) {
        entityAdvice.push(`§cワールド全体のエンティティ数が非常に多く（最大${maxEntityCount}体）、これがパフォーマンスに深刻な影響を与えている可能性が極めて高いです。`);
    } else if (maxEntityCount > 500) {
        entityAdvice.push(`§6ワールド全体のエンティティ数が多め（最大${maxEntityCount}体）です。これがサーバー負荷の一因となっている可能性があります。`);
    }

    if (entityIncrease > 100) {
        entityAdvice.push(`§c診断中にエンティティが${entityIncrease}体も急増しました。特定の場所でのMOBの大量発生やアイテムの大量ドロップがラグの直接的な原因である可能性が高いです。`);
    } else if (entityIncrease > 50) {
        entityAdvice.push(`§6診断中にエンティティが${entityIncrease}体増加しました。MOBのスポーンやアイテムの散乱が一時的な負荷上昇を引き起こしているかもしれません。`);
    }

    if (entityAdvice.length > 0) {
        entityMessage = '§r【詳細分析】§r\n' + entityAdvice.join('\n');
        if (avgTps < 19.0) {
            baseMessage += ' MOBの数や大規模なレッドストーン回路の見直しを検討してください。';
        }
    } else {
        if (avgTps < 19.0 && minTps < 17.0) {
            entityMessage = '§r【詳細分析】§r\n§aエンティティ数は安定しており、ラグの主な原因ではなさそうです。§e大規模なレッドストーン回路、ワールドの読み込み、または他のスクリプトなどが影響している可能性があります。';
        } else {
            entityMessage = '§r【詳細分析】§r\n§aエンティティ数は安定しており、問題は見られませんでした。';
        }
    }

    return `${baseMessage}\n\n${entityMessage}`;
}
